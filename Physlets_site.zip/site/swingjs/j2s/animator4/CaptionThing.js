(function(){var P$=Clazz.newPackage("animator4"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CaptionThing", null, 'animator4.TextThing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$S$S$S$S', function (o, txt, cs, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S$S$S.apply(this, [o, txt, cs, xStr, yStr]);
C$.$init$.apply(this);
this.color = (I$[1]||$incl$(1)).black;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var caption = this.getText();
if (caption == null ) return;
g.setColor$java_awt_Color(this.color);
var f = g.getFont();
g.setFont$java_awt_Font(this.font);
var fm = g.getFontMetrics$java_awt_Font(this.font);
g.drawString$S$I$I(caption, ((this.canvas.iwidth - fm.stringWidth$S(caption))/2|0) + this.xDisplayOff, 25 - this.yDisplayOff);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:36:57
