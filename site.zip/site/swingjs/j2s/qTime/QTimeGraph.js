(function(){var P$=Clazz.newPackage("qTime"),I$=[['java.awt.Font','edu.davidson.display.Format','java.awt.Polygon','edu.davidson.graph.DataSet','java.awt.Color','edu.davidson.numerics.Parser','qTime.QTimeState']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "QTimeGraph", null, 'edu.davidson.graph.Graph2D');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.probability = false;
this.offsetFunction = false;
this.showPotential = false;
this.f = null;
this.g_drag = null;
this.caption = null;
this.numPts = 0;
this.count = 0;
this.osi2 = null;
this.osi = null;
this.state = null;
this.owner = null;
this.tempStopped = false;
this.parser = null;
this.iwidth = 0;
this.iheight = 0;
this.xpts = null;
this.ypts = null;
this.maxX = 0;
this.minX = 0;
this.maxY = 0;
this.minY = 0;
this.format = null;
this.formatAngle = null;
this.polyline = null;
this.data = null;
this.yaxis = null;
this.xaxis = null;
this.currentColor = null;
this.drag = false;
this.potentialStr = null;
this.realStr = null;
this.imaginaryStr = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.probability = true;
this.offsetFunction = true;
this.showPotential = true;
this.f = Clazz.new_((I$[1]||$incl$(1)).c$$S$I$I,["Helvetica", 1, 14]);
this.g_drag = null;
this.caption = "QTime";
this.count = 0;
this.osi2 = null;
this.osi = null;
this.tempStopped = false;
this.parser = null;
this.iwidth = 0;
this.iheight = 0;
this.maxX = 10;
this.minX = -10;
this.maxY = 10;
this.minY = -10;
this.format = Clazz.new_((I$[2]||$incl$(2)).c$$S,["%7.3g"]);
this.formatAngle = Clazz.new_((I$[2]||$incl$(2)).c$$S,["%3i"]);
this.polyline = Clazz.new_((I$[3]||$incl$(3)));
this.data = Clazz.new_((I$[4]||$incl$(4)));
this.currentColor = (I$[5]||$incl$(5)).black;
this.drag = false;
}, 1);

Clazz.newMeth(C$, 'c$$qTime_QTime$I', function (applet, numPts_) {
Clazz.super_(C$, this,1);
this.owner=applet;
this.caption=this.owner.label_qtime;
this.parser=Clazz.new_((I$[6]||$incl$(6)).c$$I,[1]);
this.parser.defineVariable$I$S(1, "x");
this.setBackground$java_awt_Color((I$[5]||$incl$(5)).white);
this.numPts=numPts_;
this.state=Clazz.new_((I$[7]||$incl$(7)).c$$D$D$I$edu_davidson_tools_SApplet,[this.minX, this.maxX, this.numPts, applet]);
this.borderTop=18;
this.borderBottom=15;
this.xaxis=this.createAxis$I(5);
this.xaxis.setTitleText$S("X");
this.xaxis.setLabelFont$java_awt_Font(Clazz.new_((I$[1]||$incl$(1)).c$$S$I$I,["Helvetica", 0, 10]));
this.xaxis.setTitleFont$java_awt_Font(Clazz.new_((I$[1]||$incl$(1)).c$$S$I$I,["TimesRoman", 0, 12]));
this.xaxis.setManualRange$Z$D$D(true, this.minX, this.maxX);
this.xaxis.maximum=this.maxX;
this.xaxis.minimum=this.minX;
this.yaxis=this.createAxis$I(2);
this.yaxis.setTitleText$S(this.owner.label_energy);
this.yaxis.setLabelFont$java_awt_Font(Clazz.new_((I$[1]||$incl$(1)).c$$S$I$I,["Helvetica", 0, 10]));
this.yaxis.setTitleFont$java_awt_Font(Clazz.new_((I$[1]||$incl$(1)).c$$S$I$I,["TimesRoman", 0, 12]));
this.data=Clazz.new_((I$[4]||$incl$(4)));
this.data.linecolor=this.currentColor;
this.xaxis.attachDataSet$edu_davidson_graph_DataSet(this.data);
this.yaxis.attachDataSet$edu_davidson_graph_DataSet(this.data);
this.attachDataSet$edu_davidson_graph_DataSet(this.data);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if ((this.getSize().width == 0) || (this.getSize().height == 0) ) {
return;
}if ((this.osi == null ) || (this.iwidth != this.getSize().width) || (this.iheight != this.getSize().height)  ) {
this.iwidth=this.getSize().width;
this.iheight=this.getSize().height;
this.osi=this.createImage$I$I(this.iwidth, this.iheight);
this.osi2=this.createImage$I$I(this.iwidth, this.iheight);
}var osg = this.osi.getGraphics();
osg.setColor$java_awt_Color(this.getBackground());
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
osg.setColor$java_awt_Color(g.getColor());
osg.clipRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [osg]);
osg.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
osg.setFont$java_awt_Font(this.f);
var fm = osg.getFontMetrics$java_awt_Font(this.f);
if (this.isShowAxis()) {
osg.drawString$S$I$I(this.caption, ((this.iwidth - fm.stringWidth$S(this.caption))/2|0), 10);
} else {
osg.drawString$S$I$I(this.caption, ((this.iwidth - fm.stringWidth$S(this.caption))/2|0), 30);
}osg.dispose();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
var tStr = this.format.form$D(this.owner.clock.getTime());
g.drawString$S$I$I(this.owner.label_time + " " + tStr , 10, this.iheight - 15);
if (this.polyline.npoints != this.iwidth + 1) {
this.xpts=Clazz.array(Integer.TYPE, [this.iwidth + 1]);
this.ypts=Clazz.array(Integer.TYPE, [this.iwidth + 1]);
for (var i = 0; i <= this.iwidth; i++) {
this.xpts[i]=i;
this.ypts[i]=(this.iheight/2|0);
}
this.polyline=Clazz.new_((I$[3]||$incl$(3)).c$$IA$IA$I,[this.xpts, this.ypts, this.iwidth + 1]);
}this.paintPsi$java_awt_Graphics(g);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
});

Clazz.newMeth(C$, 'stepState$D', function (dt) {
this.state.step$D(dt);
if (this.osi == null ) {
return;
}if (this.polyline.npoints == 0) {
return;
}var g = this.osi2.getGraphics();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
var tStr = this.format.form$D(this.owner.clock.getTime());
g.drawString$S$I$I(this.owner.label_time + " " + tStr , 10, this.iheight - 15);
this.paintPsi$java_awt_Graphics(g);
g.dispose();
g=this.getGraphics();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi2, 0, 0, this);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
g.dispose();
});

Clazz.newMeth(C$, 'paintPsi$java_awt_Graphics', function (g) {
if (this.polyline.npoints == 0) {
return;
}var aminx = this.xaxis.getInteger$D(this.minX);
var awidth = this.xaxis.getInteger$D(this.maxX) - aminx;
g.clipRect$I$I$I$I(aminx, 0, awidth, this.iheight);
this.state.setXScale$I$I(aminx, aminx + awidth);
if (this.probability) {
var basePix = (this.iheight/2|0);
if (this.offsetFunction) {
basePix=this.yaxis.getInteger$D(this.state.getEnergy());
}this.state.fillPolyProb$I$I$java_awt_Polygon$java_awt_Graphics(this.iheight, basePix, this.polyline, g);
} else {
this.state.setPolyProb$I$I$java_awt_Polygon(this.iheight, (this.iheight/2|0), this.polyline);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
g.drawPolygon$java_awt_Polygon(this.polyline);
this.state.setPolyProbNeg$I$I$java_awt_Polygon(this.iheight, (this.iheight/2|0), this.polyline);
g.drawPolygon$java_awt_Polygon(this.polyline);
this.state.setPolyReal$I$I$java_awt_Polygon(this.iheight, (this.iheight/2|0), this.polyline);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).red);
g.drawPolygon$java_awt_Polygon(this.polyline);
this.state.setPolyImaginary$I$I$java_awt_Polygon(this.iheight, (this.iheight/2|0), this.polyline);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).green);
g.drawPolygon$java_awt_Polygon(this.polyline);
}});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'setGutters$I$I$I$I', function (g1, g2, g3, g4) {
this.borderLeft=g1;
this.borderTop=g2;
this.borderRight=g3;
this.borderBottom=g4;
});

Clazz.newMeth(C$, 'setCaption$S', function (s) {
this.caption=s;
this.repaint();
});

Clazz.newMeth(C$, 'setXTitle$S', function (s) {
this.xaxis.setTitleText$S(s);
});

Clazz.newMeth(C$, 'setYTitle$S', function (s) {
this.yaxis.setTitleText$S(s);
});

Clazz.newMeth(C$, 'setPotential$S', function (potStr) {
this.parser.define$S(potStr);
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
System.out.println$S("Parse error: " + this.parser.getErrorString() + " at function potential, position " + this.parser.getErrorPosition() );
return false;
}this.potentialStr=potStr;
this.parsePotential();
return true;
});

Clazz.newMeth(C$, 'setReal$S', function (reStr) {
this.parser.define$S(reStr);
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
System.out.println$S("Parse error: " + this.parser.getErrorString() + " at function real, position " + this.parser.getErrorPosition() );
return false;
}this.realStr=reStr;
this.state.setReal$S(this.realStr);
return true;
});

Clazz.newMeth(C$, 'setImaginary$S', function (imStr) {
this.parser.define$S(imStr);
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
System.out.println$S("Parse error: " + this.parser.getErrorString() + " at function imaginary, position " + this.parser.getErrorPosition() );
return false;
}this.imaginaryStr=imStr;
this.state.setImaginary$S(this.imaginaryStr);
return true;
});

Clazz.newMeth(C$, 'parsePotential', function () {
var maximum = this.maxX;
var minimum = this.minX;
var x;
var y;
var count = 0;
var error = false;
this.parser.define$S(this.potentialStr);
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
System.out.println$S("Parse error: " + this.parser.getErrorString() + " at function potential, position " + this.parser.getErrorPosition() );
return;
}var d = Clazz.array(Double.TYPE, [2 * this.numPts]);
for (var i = 0; i < this.numPts; i++) {
x=minimum + i * (maximum - minimum) / (this.numPts - 1);
d[count]=x;
try {
y=this.parser.evaluate$D(x);
if (y == y ) {
d[count + 1]=y;
} else {
System.out.println$S("Divide by zero!");
y=this.parser.evaluate$D(x + 1.0E-32);
if (y == y ) {
d[count + 1]=y;
} else {
d[count + 1]=0;
}}count+=2;
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
error=true;
} else {
throw e;
}
}
}
if (count <= 2) {
System.out.println$S("Error NO POINTS to PLOT!");
return;
} else if (error) {
System.out.println$S("Error while calculating points!");
}this.data.deleteData();
if (this.showPotential) {
try {
this.data.append$DA$I(d, (count/2|0));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Error while appending data!");
return;
} else {
throw e;
}
}
}this.state.setPotential$S(this.potentialStr);
var delta = this.state.getMaxV() - this.state.getMinV();
if (delta < 1.0E-9 ) {
delta=1;
}this.setYMinMax$D$D(this.state.getMinV() - 0.25 * delta, this.state.getMaxV() + 0.25 * delta);
this.repaint();
});

Clazz.newMeth(C$, 'setRGBColor$I$I$I', function (r, g, b) {
this.currentColor=Clazz.new_((I$[5]||$incl$(5)).c$$I$I$I,[r, g, b]);
this.repaint();
});

Clazz.newMeth(C$, 'setYMinMax$D$D', function (min, max) {
this.minY=min;
this.maxY=max;
this.yaxis.minimum=min;
this.yaxis.maximum=max;
if (this.yaxis.isManualRange()) {
this.yaxis.setManualRange$Z$D$D(true, min, max);
}this.repaint();
});

Clazz.newMeth(C$, 'setXMinMax$D$D', function (min, max) {
if ((this.minX != min ) || (this.maxX != max ) ) {
if (min < max ) {
this.minX=min;
this.maxX=max;
} else {
this.minX=max;
this.maxX=min;
}this.xaxis.setManualRange$Z$D$D(true, this.minX, this.maxX);
this.state.setSpace$D$D(min, max);
this.parsePotential();
this.state.setReal$S(this.realStr);
this.state.setImaginary$S(this.imaginaryStr);
}});

Clazz.newMeth(C$, 'reset', function () {
this.state.reset();
if (this.yaxis.isManualRange()) {
return;
}var min = this.state.getMinV();
var max = this.state.getMaxV();
var en = this.state.getEnergy();
if (en > max ) {
max=en;
}if (en < min ) {
min=en;
}var delta = max - min;
if (delta < 1.0E-9 ) {
delta=1;
}if (en + delta / 2 > max ) {
max=en + delta / 2;
}if (en - delta / 2 < min ) {
min=en - delta / 2;
}this.setYMinMax$D$D(min, max);
});

Clazz.newMeth(C$, 'mouseDown$java_awt_Event$I$I', function (e, x, y) {
if (this.osi == null ) {
return false;
}if (((e.modifiers & 4) != 0) || ((e.modifiers & 8) != 0) ) {
return false;
}if ((this.xaxis == null ) || (this.yaxis == null ) ) {
return false;
}this.requestFocus();
if (this.g_drag != null ) {
this.g_drag.dispose();
}this.tempStopped=this.owner.clock.isRunning();
this.owner.clock.stopClock();
this.g_drag=this.getGraphics();
var g_temp = this.osi.getGraphics();
this.paintPsi$java_awt_Graphics(g_temp);
g_temp.dispose();
this.drawCoord$I$I(x, y);
return true;
});

Clazz.newMeth(C$, 'mouseUp$java_awt_Event$I$I', function (e, x, y) {
if (this.osi == null ) {
return false;
}if (((e.modifiers & 4) != 0) || ((e.modifiers & 8) != 0) ) {
return false;
}if ((this.xaxis == null ) || (this.yaxis == null ) ) {
return false;
}this.g_drag.dispose();
this.g_drag=null;
this.polyline=Clazz.new_((I$[3]||$incl$(3)).c$$IA$IA$I,[this.xpts, this.ypts, this.iwidth + 1]);
this.repaint();
if (this.tempStopped) {
this.owner.clock.startClock();
}return true;
});

Clazz.newMeth(C$, 'mouseDrag$java_awt_Event$I$I', function (e, x, y) {
if (((e.modifiers & 4) != 0) || ((e.modifiers & 8) != 0) ) {
return false;
}if (this.osi == null ) {
return false;
}if ((this.xaxis == null ) || (this.yaxis == null ) ) {
return false;
}this.drawCoord$I$I(x, y);
return true;
});

Clazz.newMeth(C$, 'setYManualRange$Z', function (mr) {
if (mr == this.yaxis.isManualRange() ) {
return;
}if (!this.yaxis.isManualRange()) {
this.minY=this.yaxis.minimum;
this.maxY=this.yaxis.maximum;
}this.yaxis.setManualRange$Z$D$D(mr, this.minY, this.maxY);
this.repaint();
});

Clazz.newMeth(C$, 'drawCoord$I$I', function (x, y) {
var xCoord = x;
var yCoord = y;
if (this.osi != null ) {
this.g_drag.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
}this.g_drag.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
this.g_drag.setFont$java_awt_Font(this.f);
if (x < (3 * this.iwidth/4|0)) {
this.g_drag.drawString$S$I$I("  X  : " + this.format.form$D(this.xaxis.getDouble$I(xCoord)), xCoord + 20, yCoord - 10);
this.g_drag.drawString$S$I$I(this.owner.label_magnitude + " " + this.format.form$D(this.getPsiFromPix$I(xCoord)) , xCoord + 20, yCoord + 10);
this.g_drag.drawString$S$I$I(this.owner.label_phase + " " + this.formatAngle.form$J(this.getAngleFromPix$I(xCoord)) , xCoord + 20, yCoord + 30);
} else {
this.g_drag.drawString$S$I$I("  X  : " + this.format.form$D(this.xaxis.getDouble$I(xCoord)), xCoord - 80, yCoord - 10);
this.g_drag.drawString$S$I$I(this.owner.label_magnitude + " " + this.format.form$D(this.getPsiFromPix$I(xCoord)) , xCoord - 80, yCoord + 10);
this.g_drag.drawString$S$I$I(this.owner.label_phase + " " + this.formatAngle.form$J(this.getAngleFromPix$I(xCoord)) , xCoord - 80, yCoord + 30);
}this.g_drag.drawLine$I$I$I$I(xCoord - 10, yCoord, xCoord + 10, yCoord);
this.g_drag.drawLine$I$I$I$I(xCoord, yCoord - 10, xCoord, yCoord + 10);
});

Clazz.newMeth(C$, 'getPsiFromPix$I', function (pix) {
return this.state.getPsiAtX$D(this.xaxis.getDouble$I(pix));
});

Clazz.newMeth(C$, 'getAngleFromPix$I', function (pix) {
return this.state.getAngleAtX$D(this.xaxis.getDouble$I(pix));
});

Clazz.newMeth(C$, 'getState', function () {
return this.state;
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:38
