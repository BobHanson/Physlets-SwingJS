(function(){var P$=Clazz.newPackage("animator4"),I$=[['edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Piston", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.hStr = null;
this.vStr = null;
this.hFunc = null;
this.vFunc = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$S$S$S$S', function (o, s, h, v, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.s = s;
this.hStr = h;
this.vStr = v;
this.hFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[1]);
this.hFunc.defineVariable$I$S(1, "t");
this.hFunc.define$S(this.hStr);
this.hFunc.parse();
if (this.hFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse horzizontal component of vector: " + this.hStr);
System.out.println$S("Parse error: " + this.hFunc.getErrorString() + " at function 1, position " + this.hFunc.getErrorPosition() );
return;
}this.vFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[1]);
this.vFunc.defineVariable$I$S(1, "t");
this.vFunc.define$S(this.vStr);
this.vFunc.parse();
if (this.vFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse vertical component of vector: " + this.vStr);
System.out.println$S("Parse error: " + this.vFunc.getErrorString() + " at function 1, position " + this.vFunc.getErrorPosition() );
return;
}}, 1);

Clazz.newMeth(C$, 'getHorz$D', function (t) {
var h = 0;
try {
h = this.hFunc.evaluate$D(t);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return h;
});

Clazz.newMeth(C$, 'getVert$D', function (t) {
var v = 0;
try {
v = this.vFunc.evaluate$D(t);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return v;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX = Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
var x = this.canvas.pixPerUnit * this.getHorz$D(this.vars[0]);
var y = this.canvas.pixPerUnit * this.getVert$D(this.vars[0]);
g.setColor$java_awt_Color(this.color);
g.setColor$java_awt_Color(this.color);
var x2 = ((ptX + x)|0);
var y2 = ((ptY - y)|0);
var h = Math.sqrt(x * x + y * y);
var w = (this.s/2|0);
var u = (w * x / h);
var v = -(w * y / h);
g.fillPolygon$IA$IA$I(Clazz.array(Integer.TYPE, -1, [((ptX - v)|0), ((x2 - v)|0), ((x2 + v)|0), ((ptX + v)|0), ((x2 + v)|0)]), Clazz.array(Integer.TYPE, -1, [((ptY + u)|0), ((y2 + u)|0), ((y2 - u)|0), ((ptY - u)|0)]), 4);
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:05:24
