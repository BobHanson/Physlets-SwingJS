(function(){var P$=Clazz.newPackage("dataGraph"),I$=[['java.awt.Color','edu.davidson.graphics.EtchedBorder','java.awt.BorderLayout',['dataGraph.Bar','.BarGraph'],'dataGraph.SLabel','java.awt.Panel','java.awt.Label','edu.davidson.graph.TextLine','Boolean']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Bar", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SDataListener');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.min = 0;
this.max = 0;
this.vert = false;
this.numBars = 0;
this.etchedBorder = null;
this.borderLayout1 = null;
this.value = 0;
this.negColor = null;
this.posColor = null;
this.bar = null;
this.borderLayout2 = null;
this.valField = null;
this.showControls = false;
this.autoScale = false;
this.panel1 = null;
this.barLabel = null;
this.title = null;
this.titleStr = null;
this.borderLayout3 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.numBars = 1;
this.etchedBorder = Clazz.new_((I$[2]||$incl$(2)));
this.borderLayout1 = Clazz.new_((I$[3]||$incl$(3)));
this.value = 0;
this.negColor = (I$[1]||$incl$(1)).blue;
this.posColor = (I$[1]||$incl$(1)).red;
this.bar = Clazz.new_((I$[4]||$incl$(4)), [this, null]);
this.borderLayout2 = Clazz.new_((I$[3]||$incl$(3)));
this.valField = Clazz.new_((I$[5]||$incl$(5)));
this.showControls = false;
this.autoScale = false;
this.panel1 = Clazz.new_((I$[6]||$incl$(6)));
this.barLabel = Clazz.new_((I$[7]||$incl$(7)));
this.title = Clazz.new_((I$[8]||$incl$(8)));
this.titleStr = "";
this.borderLayout3 = Clazz.new_((I$[3]||$incl$(3)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
var barWidth = 10;
var barText = "";
try {
this.min = Double.$valueOf(this.getParameter$S$S("Min", "0")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.max = Double.$valueOf(this.getParameter$S$S("Max", "100")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.value = Double.$valueOf(this.getParameter$S$S("Value", "10")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.vert = (I$[9]||$incl$(9)).$valueOf(this.getParameter$S$S("Vertical", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.autoScale = (I$[9]||$incl$(9)).$valueOf(this.getParameter$S$S("AutoScale", "false")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls = (I$[9]||$incl$(9)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
barWidth = Integer.parseInt(this.getParameter$S$S("BarWidth", "10"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.numBars = Integer.parseInt(this.getParameter$S$S("NumSeries", "1"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
barText = this.getParameter$S$S("Label", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.titleStr = this.getParameter$S$S("Title", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (!this.showControls) {
this.panel1.setVisible$Z(false);
}this.valField.setValue$D(this.value);
this.bar.barWidth = barWidth;
if (barText.equals$O("")) this.barLabel.setVisible$Z(false);
 else {
this.barLabel.setText$S(barText);
this.barLabel.setVisible$Z(true);
}edu.davidson.tools.SApplet.addDataListener$O(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.bar.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.barLabel.setAlignment$I(2);
this.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.panel1.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.etchedBorder.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.etchedBorder.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.add$java_awt_Component$O(this.etchedBorder, "Center");
this.add$java_awt_Component$O(this.panel1, "South");
this.panel1.add$java_awt_Component$O(this.barLabel, null);
this.panel1.add$java_awt_Component$O(this.valField, null);
this.etchedBorder.add$java_awt_Component$O(this.bar, "Center");
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Bar by W. Christian. Email:wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Min", "double", "Minimum value"]), Clazz.array(java.lang.String, -1, ["Max", "double", "Maximum value"]), Clazz.array(java.lang.String, -1, ["Vertical", "boolean", "Orientation"])]);
return pinfo;
});

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.firstTime) return 0;
 else return C$.superclazz.prototype.getAppletCount.apply(this, []);
});

Clazz.newMeth(C$, 'start', function () {
if (this.firstTime) {
this.firstTime = false;
}C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'setAutoscale$Z', function (scale) {
this.autoScale = scale;
this.bar.repaint();
});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
this.valField.setFormat$S(str);
});

Clazz.newMeth(C$, 'setLabel$S', function (newLabel) {
this.barLabel.setText$S(newLabel);
if (newLabel.equals$O("")) {
this.barLabel.setVisible$Z(false);
} else this.barLabel.setVisible$Z(true);
this.invalidate();
this.validate();
});

Clazz.newMeth(C$, 'setTtile$S', function (_title) {
this.titleStr = _title;
this.bar.repaint();
});

Clazz.newMeth(C$, 'setBarWidth$I', function (newWidth) {
this.bar.barWidth = newWidth;
this.bar.repaint();
});

Clazz.newMeth(C$, 'setMax$D', function (m) {
this.max = m;
this.bar.repaint();
});

Clazz.newMeth(C$, 'setMin$D', function (m) {
this.min = m;
this.bar.repaint();
});

Clazz.newMeth(C$, 'setValue$D', function (v) {
if (this.autoScale) {
if (v > this.max ) {
this.max = v;
}if (v < this.min ) {
this.min = v;
}}this.value = v;
this.valField.setValue$D(v);
this.bar.repaint();
});

Clazz.newMeth(C$, 'setPosRGB$I$I$I', function (r, g, b) {
this.posColor = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, 'setNegRGB$I$I$I', function (r, g, b) {
this.negColor = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, 'setNumericFormat$S', function (str) {
this.valField.setFormat$S(str);
});

Clazz.newMeth(C$, 'addDatum$I$D$D', function (id, x, y) {
this.setValue$D(x);
});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (s, id, x, y) {
this.setValue$D(x);
});

Clazz.newMeth(C$, 'addData$I$DA$DA', function (id, x, y) {
if (x == null ) {
return;
}var n = x.length;
if (n < 1) {
return;
}this.setValue$D(x[n - 1]);
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (s, id, x, y) {
this.addData$I$DA$DA(id, x, y);
});

Clazz.newMeth(C$, 'deleteSeries$I', function (id) {
this.setValue$D(0);
});

Clazz.newMeth(C$, 'clearSeries$I', function (id) {
this.setValue$D(0);
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});
;
(function(){var C$=Clazz.newClass(P$.Bar, "BarGraph", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.Panel');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.barWidth = 0;
this.osi = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.barWidth = 10;
this.osi = null;
}, 1);

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var w = this.getBounds().width;
var h = this.getBounds().height;
if ((w < 4) || (h < 4) ) {
return;
}if ((this.osi == null ) || (this.osi.getWidth$java_awt_image_ImageObserver(null) != w) || (this.osi.getHeight$java_awt_image_ImageObserver(null) != h)  ) {
this.osi = this.createImage$I$I(w, h);
}if (this.osi == null ) {
return;
}p$.paintOSI.apply(this, []);
g.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, w, h, this);
});

Clazz.newMeth(C$, 'paintOSI', function () {
var x;
var y;
var w;
var h;
var o;
var origin = 0;
if ((this.this$0.min <= 0 ) && (this.this$0.max > 0 ) ) {
origin = 0;
}var g = this.osi.getGraphics();
w = this.osi.getWidth$java_awt_image_ImageObserver(null);
h = this.osi.getHeight$java_awt_image_ImageObserver(null);
var bgColor = this.this$0.getBackground();
g.setColor$java_awt_Color(bgColor);
g.fillRect$I$I$I$I(0, 0, w, h);
if (this.this$0.vert) {
o = ((0.4999999 + h * this.this$0.max / (this.this$0.max - this.this$0.min))|0);
h = ((h * (this.this$0.value - origin) / (this.this$0.max - this.this$0.min))|0);
if (h >= 0) {
y = o - h;
g.setColor$java_awt_Color(this.this$0.posColor);
} else {
y = o;
h = -h;
g.setColor$java_awt_Color(this.this$0.negColor);
}g.fillRect$I$I$I$I((w/2|0) - this.barWidth, y, 2 * this.barWidth, h);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawLine$I$I$I$I(0, o, w - 1, o);
} else {
o = ((0.4999999 - w * this.this$0.min / (this.this$0.max - this.this$0.min))|0);
w = ((w * (this.this$0.value - origin) / (this.this$0.max - this.this$0.min))|0);
if (w >= 0) {
x = o;
g.setColor$java_awt_Color(this.this$0.posColor);
} else {
w = -w;
x = o - w;
g.setColor$java_awt_Color(this.this$0.negColor);
}g.fillRect$I$I$I$I(x, (h/2|0) - this.barWidth, w, 2 * this.barWidth);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawLine$I$I$I$I(o, 0, o, h - 1);
}if (!this.this$0.titleStr.equals$O("")) {
this.this$0.title.setText$S(this.this$0.titleStr);
this.this$0.title.draw$java_awt_Graphics$I$I$I(g, (w/2|0), 15, 0);
}g.dispose();
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-02-06 13:41:52
