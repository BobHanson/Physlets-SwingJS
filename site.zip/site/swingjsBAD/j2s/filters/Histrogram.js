(function(){var P$=Clazz.newPackage("filters"),I$=[['edu.davidson.graphics.EtchedBorder','java.awt.BorderLayout','java.awt.Button','java.awt.FlowLayout','java.awt.Panel','java.awt.Label','edu.davidson.display.SInteger','edu.davidson.display.SNumber','Boolean','filters.Histrogram$1']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Histrogram", null, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataListener', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.numberOfBins = 0;
this.minBin = 0;
this.maxBin = 0;
this.binSize = 0;
this.showControls = false;
this.autoReplace = false;
this.varStrings = null;
this.ds = null;
this.controlPanel = null;
this.borderLayout1 = null;
this.setBtn = null;
this.flowLayout1 = null;
this.panel1 = null;
this.numLabel = null;
this.numField = null;
this.minLabel1 = null;
this.maxField = null;
this.panel2 = null;
this.minLabel2 = null;
this.minField = null;
this.panel3 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.autoReplace = true;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y"]);
this.ds = null;
this.controlPanel = Clazz.new_((I$[1]||$incl$(1)));
this.borderLayout1 = Clazz.new_((I$[2]||$incl$(2)));
this.setBtn = Clazz.new_((I$[3]||$incl$(3)));
this.flowLayout1 = Clazz.new_((I$[4]||$incl$(4)));
this.panel1 = Clazz.new_((I$[5]||$incl$(5)));
this.numLabel = Clazz.new_((I$[6]||$incl$(6)));
this.numField = Clazz.new_((I$[7]||$incl$(7)));
this.minLabel1 = Clazz.new_((I$[6]||$incl$(6)));
this.maxField = Clazz.new_((I$[8]||$incl$(8)));
this.panel2 = Clazz.new_((I$[5]||$incl$(5)));
this.minLabel2 = Clazz.new_((I$[6]||$incl$(6)));
this.minField = Clazz.new_((I$[8]||$incl$(8)));
this.panel3 = Clazz.new_((I$[5]||$incl$(5)));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.numberOfBins=Integer.parseInt(this.getParameter$S$S("NumBins", "10"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.minBin=Double.$valueOf(this.getParameter$S$S("Min", "0")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.maxBin=Double.$valueOf(this.getParameter$S$S("Max", "100")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls=(I$[9]||$incl$(9)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.controlPanel.setVisible$Z(this.showControls);
this.setNumBins$I(this.numberOfBins);
this.minField.setValue$D(this.minBin);
this.maxField.setValue$D(this.maxBin);
this.numField.setValue$I(this.numberOfBins);
edu.davidson.tools.SApplet.addDataListener$O(this);
edu.davidson.tools.SApplet.addDataSource$O(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.setBtn.setLabel$S("Set");
this.setBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Histrogram$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['filters.Histrogram'].setBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[10]||$incl$(10)).$init$, [this, null])));
this.controlPanel.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.minLabel1.setText$S("Max");
this.minLabel1.setAlignment$I(2);
this.minLabel2.setText$S("Min");
this.minLabel2.setAlignment$I(2);
this.maxField.setValue$D(100.0);
this.numField.setValue$I(10);
this.add$java_awt_Component$O(this.controlPanel, "Center");
this.controlPanel.add$java_awt_Component$O(this.setBtn, null);
this.controlPanel.add$java_awt_Component$O(this.panel3, null);
this.panel3.add$java_awt_Component$O(this.minLabel2, null);
this.panel3.add$java_awt_Component$O(this.minField, null);
this.controlPanel.add$java_awt_Component$O(this.panel2, null);
this.panel2.add$java_awt_Component$O(this.minLabel1, null);
this.panel2.add$java_awt_Component$O(this.maxField, null);
this.controlPanel.add$java_awt_Component$O(this.panel1, null);
this.panel1.add$java_awt_Component$O(this.numLabel, null);
this.panel1.add$java_awt_Component$O(this.numField, null);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Histogram Physlet written by W. Christian.  Sort data from a data sourct into bins.";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["NumBins", "int", "Number of bins."]), Clazz.array(java.lang.String, -1, ["Min", "double", "Minimum value for data sorting."]), Clazz.array(java.lang.String, -1, ["Max", "double", "Maximum value for data sortting."]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show user inteface."])]);
return pinfo;
});

Clazz.newMeth(C$, ['setNumBins$I','setNumBins'], function (n) {
if (n < 1) {
System.out.println$S("Number of bins must be >0.");
}this.numberOfBins=Math.max(1, n);
if (this.maxBin < this.minBin ) {
System.out.println$S("Bin maximum must be > bin minimum.");
var temp = this.maxBin;
this.maxBin=this.minBin;
this.minBin=temp;
}if (this.maxBin == this.minBin ) {
System.out.println$S("Bin maximum cannot be = bin minimum.");
this.maxBin=this.maxBin + 1.0;
}this.binSize=(this.maxBin - this.minBin) / this.numberOfBins;
this.ds=Clazz.array(Double.TYPE, [this.numberOfBins, 2]);
var binVal = this.minBin + this.binSize / 2.0;
for (var i = 0; i < this.numberOfBins; i++) {
this.ds[i][0]=binVal;
binVal += this.binSize;
}
if (this.showControls) {
this.minField.setValue$D(this.minBin);
this.maxField.setValue$D(this.maxBin);
this.numField.setValue$I(this.numberOfBins);
}this.updateDataConnections();
});

Clazz.newMeth(C$, ['setMinMaxBins$D$D','setMinMaxBins'], function (min, max) {
this.maxBin=max;
this.minBin=min;
if (this.maxBin < this.minBin ) {
System.out.println$S("Bin maximum must be > bin minimum.");
var temp = this.maxBin;
this.maxBin=this.minBin;
this.minBin=temp;
}if (this.maxBin == this.minBin ) {
System.out.println$S("Bin maximum cannot be = bin minimum.");
this.maxBin=this.maxBin + 1.0;
}this.binSize=(this.maxBin - this.minBin) / this.numberOfBins;
var binVal = this.minBin + this.binSize / 2.0;
for (var i = 0; i < this.numberOfBins; i++) {
this.ds[i][0]=binVal;
this.ds[i][1]=0;
binVal += this.binSize;
}
if (this.showControls) {
this.minField.setValue$D(this.minBin);
this.maxField.setValue$D(this.maxBin);
}this.updateDataConnections();
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, x, y) {
var bin = (((x - this.minBin) / this.binSize)|0);
if (bin < 0) return;
if (bin > this.numberOfBins - 1) return;
this.ds[bin][1] += y;
this.updateDataConnections();
});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
if (this.autoReplace) for (var i = 0; i < this.numberOfBins; i++) {
this.ds[i][1]=0;
}
var n = x.length;
for (var i = 0; i < n; i++) {
var bin = (((x[i] - this.minBin) / this.binSize)|0);
if ((bin >= 0) && (bin < this.numberOfBins) ) this.ds[bin][1] += y[i];
}
});

Clazz.newMeth(C$, 'reset', function () {
for (var i = 0; i < this.numberOfBins; i++) {
this.ds[i][1]=0;
}
this.updateDataConnections();
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.reset();
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
if (this.autoReplace) this.reset();
});

Clazz.newMeth(C$, ['setAutoReplaceData$I$Z','setAutoReplaceData'], function (id, replace) {
this.autoReplace=replace;
});

Clazz.newMeth(C$, 'setBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.minBin=this.minField.getValue();
this.maxBin=this.maxField.getValue();
this.numberOfBins=this.numField.getValue();
if (this.numberOfBins != this.numField.getValue()) this.setNumBins$I(this.numField.getValue());
 else this.setMinMaxBins$D$D(this.minBin, this.maxBin);
});
})();
//Created 2018-07-23 12:59:28 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
