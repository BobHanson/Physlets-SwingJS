(function(){var P$=Clazz.newPackage("eField4"),I$=[['java.awt.Color','edu.davidson.numerics.SRK45','java.lang.Thread','Thread','eField4.ArrowHead','java.util.Vector','java.awt.Font','edu.davidson.display.SContour','eField4.VectorField','edu.davidson.display.Format','eField4.OdeCanvas_mouseMotionAdapter','eField4.OdeCanvas_mouseAdapter','java.util.StringTokenizer','edu.davidson.graphics.Util','eField4.TrailThing','edu.davidson.numerics.Parser','java.awt.MediaTracker','eField4.ImageThing','eField4.ShapeThing','eField4.TestCharge','eField4.Pole','edu.davidson.tools.SUtil','eField4.CollisionThing',['eField4.OdeCanvas','.FieldSolver'],'java.awt.Cursor','java.awt.Rectangle']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "OdeCanvas", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'a2s.Canvas', ['edu.davidson.tools.SStepable', 'Runnable']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.collisionDataSource = null;
this.newData = false;
this.delayLock = null;
this.delayThread = null;
this.sketchImage = null;
this.darkBlue = null;
this.lightBlue = null;
this.message = null;
this.time = 0;
this.arrowHeads = null;
this.testCharges = null;
this.poles = null;
this.fieldSolvers = null;
this.fieldPoles = null;
this.drawThings = null;
this.fieldLines = null;
this.parser = null;
this.potStr = null;
this.f = null;
this.caption = null;
this.bz = 0;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.tolerance = 0;
this.polemin = 0;
this.polemax = 0;
this.showContours = false;
this.showFieldLines = false;
this.showPoles = false;
this.showFieldVectors = false;
this.showCoordOnDrag = false;
this.showVOnDrag = false;
this.showEOnDrag = false;
this.showFieldLineOnClick = false;
this.showFieldLineOnDoubleClick = false;
this.showEquipotentialOnClick = false;
this.showEquipotentialOnDoubleClick = false;
this.autoRefresh = false;
this.showTime = false;
this.pointChargeMode = false;
this.collision = false;
this.dampOnMousePressed = false;
this.calculatingFieldLines = false;
this.dragShape = null;
this.contour = null;
this.field = null;
this.osi = null;
this.osi2 = null;
this.osiInvalid = false;
this.iwidth = 0;
this.iheight = 0;
this.boxWidth = 0;
this.format = null;
this.isDrag = false;
this.dragV = false;
this.parentSApplet = null;
this.mouseX = 0;
this.mouseY = 0;
this.gridSize = 0;
this.skip = 0;
this.fieldLinesInvalid = false;
this.sketchMode = false;
this.trailThing = null;
this.allPositive = false;
this.allNegative = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.newData = false;
this.delayLock =  Clazz.new_();
this.delayThread = null;
this.sketchImage = null;
this.darkBlue = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 0, 128]);
this.lightBlue = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[128, 128, 255]);
this.message = null;
this.time = 0;
this.arrowHeads = Clazz.new_((I$[6]||$incl$(6)));
this.testCharges = Clazz.new_((I$[6]||$incl$(6)));
this.poles = Clazz.new_((I$[6]||$incl$(6)));
this.fieldSolvers = Clazz.new_((I$[6]||$incl$(6)));
this.fieldPoles = Clazz.new_((I$[6]||$incl$(6)).c$$I,[10]);
this.drawThings = Clazz.new_((I$[6]||$incl$(6)).c$$I,[20]);
this.fieldLines = Clazz.new_((I$[6]||$incl$(6)).c$$I,[20]);
this.parser = null;
this.potStr = null;
this.f = Clazz.new_((I$[7]||$incl$(7)).c$$S$I$I,["Helvetica", 1, 14]);
this.caption = null;
this.bz = 0;
this.xmin = -1;
this.xmax = 1;
this.ymin = -1;
this.ymax = 1;
this.tolerance = 1.0E-5;
this.polemin = 0;
this.polemax = 0;
this.showContours = true;
this.showFieldLines = false;
this.showPoles = true;
this.showFieldVectors = true;
this.showCoordOnDrag = true;
this.showVOnDrag = false;
this.showEOnDrag = false;
this.showFieldLineOnClick = false;
this.showFieldLineOnDoubleClick = false;
this.showEquipotentialOnClick = false;
this.showEquipotentialOnDoubleClick = false;
this.autoRefresh = true;
this.showTime = true;
this.pointChargeMode = true;
this.collision = false;
this.dampOnMousePressed = false;
this.calculatingFieldLines = false;
this.dragShape = null;
this.contour = Clazz.new_((I$[8]||$incl$(8)));
this.field = Clazz.new_((I$[9]||$incl$(9)).c$$I$I,[4, 4]);
this.osi = null;
this.osi2 = null;
this.osiInvalid = true;
this.iwidth = 0;
this.iheight = 0;
this.boxWidth = 0;
this.format = Clazz.new_((I$[10]||$incl$(10)).c$$S,["%-+8.4g"]);
this.isDrag = false;
this.dragV = false;
this.parentSApplet = null;
this.gridSize = 64;
this.skip = 2;
this.fieldLinesInvalid = false;
this.sketchMode = false;
this.trailThing = null;
this.allPositive = true;
this.allNegative = true;
}, 1);

Clazz.newMeth(C$, 'c$$eField4_EField', function (applet) {
Clazz.super_(C$, this,1);
this.parentSApplet = applet;
this.contour.setShowAxis$Z(false);
this.contour.setDataBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.contour.setLabelColor$java_awt_Color((I$[1]||$incl$(1)).green);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(Clazz.new_((I$[11]||$incl$(11)).c$$eField4_OdeCanvas,[this]));
this.addMouseListener$java_awt_event_MouseListener(Clazz.new_((I$[12]||$incl$(12)).c$$eField4_OdeCanvas,[this]));
this.contour.setOwner$edu_davidson_tools_SApplet(applet);
this.delayThread = Clazz.new_((I$[3]||$incl$(3)).c$$Runnable,[this]);
this.delayThread.start();
}, 1);

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.parentSApplet;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.collisionDataSource = null;
this.dragShape = null;
this.sketchMode = false;
this.stopFieldThreads();
this.parentSApplet.lock.getBusyFlag();
this.time = 0;
this.tolerance = 1.0E-5;
this.message = null;
this.showFieldLineOnClick = false;
this.showFieldLineOnDoubleClick = false;
this.showEquipotentialOnClick = false;
this.showEquipotentialOnDoubleClick = false;
this.showTime = true;
this.showCoordOnDrag = true;
this.showVOnDrag = false;
this.showEOnDrag = false;
this.setXRange$D$D(this.xmin, this.xmax);
this.message = null;
this.allPositive = true;
this.allNegative = true;
this.clearPoles();
this.clearTestCharges();
this.clearDrawThings();
this.contour.deleteAllSeries();
this.parentSApplet.lock.freeBusyFlag();
});

Clazz.newMeth(C$, 'setMessage$S', function (msg) {
if ((msg == null ) || msg.trim().equals$O("") ) {
this.message = null;
} else {
this.message = msg;
}if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setAutoRefresh$Z', function (ar) {
this.autoRefresh = ar;
if (this.autoRefresh) {
this.setFields();
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setBz$D', function (bz) {
this.bz = bz;
});

Clazz.newMeth(C$, 'setCaption$S', function (s) {
this.caption = s;
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setXRange$D$D', function (min, max) {
if (max == min ) {
this.xmin = min - 0.5;
this.xmax = max + 0.5;
} else if (max > min ) {
this.xmin = min;
this.xmax = max;
} else {
this.xmin = max;
this.xmax = min;
}if (this.iwidth == 0) {
return;
}var scale = (this.xmax - this.xmin) / this.iwidth;
this.ymin = (this.ymax + this.ymin) / 2 - scale * this.iheight / 2.0;
this.ymax = this.ymin + scale * this.iheight;
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setYRange$D$D', function (min, max) {
if (max == min ) {
this.ymin = min - 0.5;
this.ymax = max + 0.5;
} else if (max > min ) {
this.ymin = min;
this.ymax = max;
} else {
this.ymin = max;
this.ymax = min;
}if (this.iheight == 0) {
return;
}var scale = (this.ymax - this.ymin) / this.iheight;
this.xmin = (this.xmax + this.xmin) / 2 - scale * this.iwidth / 2.0;
this.xmax = this.xmin + scale * this.iwidth;
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setRange$S', function (rs) {
var error = false;
var range = Clazz.array(Double.TYPE, [4]);
var tokens = Clazz.new_((I$[13]||$incl$(13)).c$$S$S,[rs.trim(), ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
if (tokens.countTokens() < 4) {
error = true;
} else {
for (var i = 0; i < 4; i++) {
try {
range[i] = Double.$valueOf(tokens.nextToken().trim()).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
System.out.println$S("Error setting range:" + rs);
error = true;
} else {
throw e;
}
}
}
}if (!error) {
this.xmin = range[0];
this.xmax = range[1];
this.ymin = range[2];
this.ymax = range[3];
this.setXRange$D$D(this.xmin, this.xmax);
} else {
return false;
}return true;
});

Clazz.newMeth(C$, 'setPotStr$S$D$D$D$D', function (ps, x1, x2, y1, y2) {
this.xmin = x1;
this.xmax = x2;
this.ymin = y1;
this.ymax = y2;
this.setXRange$D$D(this.xmin, this.xmax);
return this.setPotStr$S(ps);
});

Clazz.newMeth(C$, 'setPotStr$S$S', function (ps, rs) {
this.setRange$S(rs);
return this.setPotStr$S(ps);
});

Clazz.newMeth(C$, 'setShowContours$Z', function (sc) {
this.showContours = sc;
this.contour.setNoContours$Z(!sc);
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setShowFieldLines$Z', function (sf) {
this.showFieldLines = sf;
if (!this.showFieldLines) this.message = null;
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setShowFieldVectors$Z', function (sfv) {
this.showFieldVectors = sfv;
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setShowPoles$Z', function (sp) {
this.showPoles = sp;
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setSketchMode$Z', function (sm) {
var applet = (I$[14]||$incl$(14)).getApplet$java_awt_Component(this);
this.sketchImage = (I$[14]||$incl$(14)).getImage$S$a2s_Applet("pencil.gif", applet);
this.sketchMode = sm;
if (!sm) {
this.trailThing = null;
return 0;
}this.trailThing = Clazz.new_((I$[15]||$incl$(15)).c$$eField4_OdeCanvas$I,[this, 1]);
this.trailThing.trailSize = 2000;
return this.trailThing.hashCode();
});

Clazz.newMeth(C$, 'setTolerance$D', function (t) {
this.tolerance = t;
});

Clazz.newMeth(C$, 'setTrajectory$I$S$S', function (id, xStr, yStr) {
var t = null;
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (t.hashCode() == id) {
var result = t.setTrajectory$S$S(xStr, yStr);
if (Clazz.instanceOf(t, "eField4.Charge")) {
this.setFields();
}return result;
}}
return false;
});

Clazz.newMeth(C$, 'setShowFComponents$I$Z', function (cid, sc) {
var c = null;
for (var e = this.poles.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hashCode() == cid) {
c.showFComponents = sc;
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}}
for (var e = this.testCharges.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hashCode() == cid) {
c.showFComponents = sc;
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}}
return false;
});

Clazz.newMeth(C$, 'setShowFOnDrag$I$Z', function (cid, sf) {
var t = null;
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (t.hashCode() == cid) {
t.showFOnDrag = sf;
return true;
}}
return false;
});

Clazz.newMeth(C$, 'setShowFVector$I$Z', function (cid, sf) {
var c = null;
for (var e = this.poles.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hashCode() == cid) {
c.setShowFVector$Z(sf);
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}}
for (var e = this.testCharges.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hashCode() == cid) {
c.setShowFVector$Z(sf);
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}}
return false;
});

Clazz.newMeth(C$, 'setShowVVector$I$Z', function (cid, sv) {
var c = null;
for (var e = this.poles.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hashCode() == cid) {
c.setShowV$Z(sv);
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}}
for (var e = this.testCharges.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hashCode() == cid) {
c.setShowV$Z(sv);
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}}
return false;
});

Clazz.newMeth(C$, 'setSpeed$I$D', function (cid, speed) {
var c = null;
for (var e = this.testCharges.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hashCode() == cid) {
c.setSpeed$D(speed);
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}}
return false;
});

Clazz.newMeth(C$, 'setShowVComponents$I$Z', function (cid, svc) {
var c = null;
for (var e = this.poles.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hashCode() == cid) {
c.showVComponents = svc;
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}}
for (var e = this.testCharges.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hashCode() == cid) {
c.showVComponents = svc;
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}}
return false;
});

Clazz.newMeth(C$, 'setShowTime$Z', function (st) {
this.showTime = st;
});

Clazz.newMeth(C$, 'setShowCoordOnDrag$Z', function (sc) {
this.showCoordOnDrag = sc;
});

Clazz.newMeth(C$, 'setShowVOnDrag$Z', function (sv) {
this.showVOnDrag = sv;
});

Clazz.newMeth(C$, 'setShowEOnDrag$Z', function (se) {
this.showEOnDrag = se;
});

Clazz.newMeth(C$, 'setShowFieldLineOnClick$Z', function (sfl) {
if (this.showFieldLineOnClick == sfl ) {
return;
}this.showFieldLineOnClick = sfl;
this.showFieldLineOnDoubleClick = false;
this.showEquipotentialOnClick = false;
this.showEquipotentialOnDoubleClick = false;
});

Clazz.newMeth(C$, 'setShowFieldLineOnDoubleClick$Z', function (sfl) {
if (this.showFieldLineOnDoubleClick == sfl ) {
return;
}this.showFieldLineOnDoubleClick = sfl;
this.showFieldLineOnClick = false;
this.showEquipotentialOnClick = false;
this.showEquipotentialOnDoubleClick = false;
});

Clazz.newMeth(C$, 'setShowEquipotentialOnClick$Z', function (sp) {
if (this.showEquipotentialOnClick == sp ) {
return;
}this.showEquipotentialOnClick = sp;
this.showEquipotentialOnDoubleClick = false;
this.showFieldLineOnClick = false;
this.showFieldLineOnDoubleClick = false;
});

Clazz.newMeth(C$, 'setShowEquipotentialOnDoubleClick$Z', function (sp) {
if (this.showEquipotentialOnDoubleClick == sp ) {
return;
}this.showEquipotentialOnDoubleClick = sp;
this.showEquipotentialOnClick = false;
this.showFieldLineOnClick = false;
this.showFieldLineOnDoubleClick = false;
});

Clazz.newMeth(C$, 'setShowLabels$Z', function (sl) {
this.contour.setDrawLabels$Z(sl);
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setPotStr$S', function (s) {
this.potStr = s.trim();
if (this.potStr.equals$O("") || this.potStr.equals$O("0") ) {
this.parser = null;
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}this.parser = Clazz.new_((I$[16]||$incl$(16)).c$$I,[2]);
this.parser.defineVariable$I$S(1, "x");
this.parser.defineVariable$I$S(2, "y");
this.parser.define$S(this.potStr);
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
System.out.println$S("Failed to parse U(x,y): " + this.parser.getFunctionString());
System.out.println$S("Parse error: " + this.parser.getErrorString() + " at function 1, position " + this.parser.getErrorPosition() );
return false;
} else {
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
}});

Clazz.newMeth(C$, 'resetTime', function () {
this.time = 0.0;
this.dragShape = null;
var c;
var n = this.testCharges.size();
for (var i = 0; i < n; i++) {
c = this.testCharges.elementAt$I(i);
if (c.hasTrajectory()) {
c.setTime$D$D(this.time, 0.001);
} else {
c.resetTime();
}c.clearTrail();
c.updateMySlaves();
}
this.time = 0;
for (var e = this.poles.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hasTrajectory()) {
c.setTime$D$D(this.time, 0.001);
c.clearTrail();
c.updateMySlaves();
}}
this.setFields();
this.message = null;
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}if (this.parentSApplet != null ) {
this.parentSApplet.clearAllData();
}this.parentSApplet.updateDataConnections();
});

Clazz.newMeth(C$, 'deleteObject$I', function (id) {
var t = null;
t = this.getThing$I(id);
if (t == null ) {
return false;
}if (this.parentSApplet != null ) {
this.parentSApplet.stop();
}this.stopFieldThreads();
this.drawThings.removeElement$O(t);
this.testCharges.removeElement$O(t);
this.poles.removeElement$O(t);
if (this.parentSApplet != null ) {
this.parentSApplet.removeDataSource$I(t.hashCode());
this.parentSApplet.cleanupDataConnections();
}this.polemin = 0;
this.polemax = 0;
this.setFields();
this.clearAnchors();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return true;
});

Clazz.newMeth(C$, 'clearAnchors', function () {
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
var t = e.nextElement();
if ((Clazz.instanceOf(t, "eField4.LineAnchor")) && this.drawThings.contains$O((t).thing) ) {
this.drawThings.removeElement$O(t);
}}
});

Clazz.newMeth(C$, 'clearDrawThings', function () {
var v;
var t;
{
v = this.drawThings.clone();
this.drawThings.removeAllElements();
}for (var e = v.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
this.parentSApplet.removeDataSource$I(t.hashCode());
}
if (this.parentSApplet != null ) {
this.parentSApplet.cleanupDataConnections();
}});

Clazz.newMeth(C$, 'clearTestCharges', function () {
var v;
{
v = this.testCharges.clone();
this.testCharges.removeAllElements();
}for (var e = v.elements(); e.hasMoreElements(); ) {
var c = e.nextElement();
if (this.drawThings.contains$O(c)) {
this.drawThings.removeElement$O(c);
}this.parentSApplet.removeDataSource$I(c.hashCode());
}
if (this.parentSApplet != null ) {
this.parentSApplet.cleanupDataConnections();
}this.clearAnchors();
});

Clazz.newMeth(C$, 'clearPoles', function () {
this.stopFieldThreads();
var v;
{
v = this.poles.clone();
this.poles.removeAllElements();
}for (var e = v.elements(); e.hasMoreElements(); ) {
var c = e.nextElement();
if (this.drawThings.contains$O(c)) {
this.drawThings.removeElement$O(c);
}this.parentSApplet.removeDataSource$I(c.hashCode());
}
if (this.parentSApplet != null ) {
this.parentSApplet.cleanupDataConnections();
}this.polemin = 0;
this.polemax = 0;
this.setFields();
this.clearAnchors();
this.newData = true;
if (this.autoRefresh) {
this.repaint();
}});

Clazz.newMeth(C$, 'clearTrails', function () {
var c;
var n = this.testCharges.size();
for (var i = 0; i < n; i++) {
c = this.testCharges.elementAt$I(i);
c.clearTrail();
}
});

Clazz.newMeth(C$, 'addImage$java_awt_Image$D$D', function (im, x, y) {
if (im == null ) {
return 0;
}var tracker = Clazz.new_((I$[17]||$incl$(17)).c$$java_awt_Component,[this]);
try {
tracker.addImage$java_awt_Image$I(im, 0);
tracker.waitForID$I$J(0, 1000);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
var t = Clazz.new_((I$[18]||$incl$(18)).c$$eField4_OdeCanvas$java_awt_Image$D$D,[this, im, x, y]);
this.drawThings.addElement$TE(t);
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return t.hashCode();
});

Clazz.newMeth(C$, 'addPolyShape$I$IA$IA$D$D', function (n, h, v, x, y) {
var t = Clazz.new_((I$[19]||$incl$(19)).c$$eField4_OdeCanvas$I$IA$IA$D$D,[this, n, h, v, x, y]);
this.drawThings.addElement$TE(t);
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return t.hashCode();
});

Clazz.newMeth(C$, 'addTestCharge', function () {
var x = this.xmin + (this.xmax - this.xmin) * Math.random();
var y = this.ymin + (this.ymax - this.ymin) * Math.random();
var c = this.addTestCharge$D$D$D$D(x, y, 0, 0);
c.setShowFVector$Z(true);
c.setShowV$Z(true);
return c;
});

Clazz.newMeth(C$, 'addTestCharge$D$D$D$D', function (x, y, vx, vy) {
var c = Clazz.new_((I$[20]||$incl$(20)).c$$eField4_OdeCanvas$D$D$D$D,[this, x, y, vx, vy]);
c.setAcceleration();
this.drawThings.addElement$TE(c);
this.testCharges.addElement$TE(c);
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return c;
});

Clazz.newMeth(C$, 'addPole$D', function (m) {
var x = this.xmin + (this.xmax - this.xmin) * Math.random();
var y = this.ymin + (this.ymax - this.ymin) * Math.random();
var c = this.addPole$D$D$D(x, y, m);
return c;
});

Clazz.newMeth(C$, 'addPole$D$D$D', function (x, y, m) {
var p = Clazz.new_((I$[21]||$incl$(21)).c$$eField4_OdeCanvas$D$D$D,[this, x, y, m]);
this.drawThings.addElement$TE(p);
this.stopFieldThreads();
this.poles.addElement$TE(p);
this.setFields();
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}return p;
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'getBackground', function () {
if (this.contour != null ) {
return this.contour.getDataBackground();
} else {
return (I$[1]||$incl$(1)).DARK_GRAY;
}});

Clazz.newMeth(C$, 'paintOSI', function () {
if (this.parentSApplet.destroyed) return;
var newImage = false;
if ((this.osi == null ) || (this.iwidth != this.getSize().width) || (this.iheight != this.getSize().height)  ) {
this.iwidth = this.getSize().width;
this.iheight = this.getSize().height;
this.osi = null;
this.setXRange$D$D(this.xmin, this.xmax);
this.osi = this.createImage$I$I(this.iwidth, this.iheight);
this.osi2 = this.createImage$I$I(this.iwidth, this.iheight);
newImage = true;
}if (this.osi == null  || this.parentSApplet.destroyed ) {
return;
}var osg = this.osi.getGraphics();
if (osg == null ) {
return;
}osg.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
this.osiInvalid = false;
if (this.contour != null ) {
var r = this.getBounds();
r.x = 0;
r.y = 0;
if (this.showContours) {
this.contour.noContours = false;
} else {
this.contour.noContours = true;
}this.contour.paint$java_awt_Graphics$java_awt_Rectangle(osg, r);
this.paintArrowHeads$java_awt_Graphics$java_awt_Rectangle(osg, r);
if (this.showFieldVectors) {
this.field.paint$java_awt_Graphics$java_awt_Rectangle$I(osg, r, this.skip);
}} else {
osg.setColor$java_awt_Color(this.getBackground());
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
osg.setColor$java_awt_Color(osg.getColor());
osg.clipRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
}osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
osg.drawRect$I$I$I$I(0, 0, this.iwidth - 1, this.iheight - 1);
osg.dispose();
if (newImage) {
this.clearTrails();
}return;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.parentSApplet.destroyed) return;
{
this.newData = true;
this.delayLock.notify();
}});

Clazz.newMeth(C$, 'paint', function () {
if (this.parentSApplet.destroyed) return;
try {
if ((this.getSize().width == 0) || (this.getSize().height == 0) ) {
return;
}if ((this.osi == null ) || this.osiInvalid || (this.iwidth != this.getSize().width) || (this.iheight != this.getSize().height)  ) {
if (this.getSize().width == 0) {
return;
} else {
this.paintOSI();
}}if ((this.osi == null ) || (this.osi2 == null ) ) {
return;
}var g = this.osi2.getGraphics();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
this.paintThings$java_awt_Graphics(g);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
this.paintMessage$java_awt_Graphics$S(g, this.message);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
var fm = g.getFontMetrics$java_awt_Font(this.f);
if (this.caption != null ) {
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawString$S$I$I(this.caption, ((this.iwidth - fm.stringWidth$S(this.caption))/2|0), 25);
}if (this.showTime) {
var tStr = Clazz.new_((I$[10]||$incl$(10)).c$$S,["%7.4g"]).form$D(this.time);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
if (this.iwidth > 150) {
g.drawString$S$I$I(this.parentSApplet.label_time + tStr, 10, 15);
} else {
g.drawString$S$I$I(this.parentSApplet.label_time + tStr, 10, this.iheight - 40);
}}g.setFont$java_awt_Font(oldFont);
g.dispose();
g = this.getGraphics();
if ((g == null ) || (this.osi2 == null ) ) {
return;
}g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi2, 0, 0, this);
g.dispose();
if (this.fieldLinesInvalid && (this.dragShape == null ) ) {
this.paintFieldLines();
this.fieldLinesInvalid = false;
}} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
this.repaint();
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'paintMessage$java_awt_Graphics$S', function (osg, msg) {
if (msg == null ) {
return;
}var fm = osg.getFontMetrics$java_awt_Font(this.f);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).yellow);
var w = 15 + fm.stringWidth$S(msg);
osg.fillRect$I$I$I$I(this.iwidth - w - 5 , this.iheight - 15, w, 15);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
osg.drawString$S$I$I(msg, this.iwidth - w + 2, this.iheight - 3);
osg.drawRect$I$I$I$I(this.iwidth - w - 5 , this.iheight - 15, w, 15);
});

Clazz.newMeth(C$, 'paintForceOnCharge$java_awt_Graphics$eField4_Charge', function (g, c) {
var x = c.getX();
var y = c.getY();
var m = c.getMag();
var fx = m * (-this.dudx$D$D(x, y) + this.getPoleFx$D$D$eField4_Charge(x, y, c) + this.bz * c.getVY() );
var fy = m * (-this.dudy$D$D(x, y) + this.getPoleFy$D$D$eField4_Charge(x, y, c) - this.bz * c.getVX());
var x0 = this.pixFromX$D(x);
var y0 = this.pixFromY$D(y);
var x1 = this.pixFromX$D(x + fx);
var y1 = this.pixFromY$D(y + fy);
var oldColor = g.getColor();
if (c.showFComponents) {
g.setColor$java_awt_Color(this.lightBlue);
(I$[22]||$incl$(22)).drawArrow$java_awt_Graphics$I$I$I$I(g, x0, y0, x1, y0);
(I$[22]||$incl$(22)).drawArrow$java_awt_Graphics$I$I$I$I(g, x1, y0, x1, y1);
}g.setColor$java_awt_Color(this.darkBlue);
(I$[22]||$incl$(22)).drawArrow$java_awt_Graphics$I$I$I$I(g, x0, y0, x1, y1);
g.setColor$java_awt_Color(oldColor);
});

Clazz.newMeth(C$, 'paintTestCharges$java_awt_Graphics', function (g) {
var c;
var n = this.testCharges.size();
for (var i = 0; i < n; i++) {
c = this.testCharges.elementAt$I(i);
if (this.dragShape !== c ) {
c.paint$java_awt_Graphics(g);
if (c.isShowFVector()) {
this.paintForceOnCharge$java_awt_Graphics$eField4_Charge(g, c);
}}}
});

Clazz.newMeth(C$, 'paintPoles$java_awt_Graphics', function (g) {
var p;
var n = this.poles.size();
for (var i = 0; i < n; i++) {
p = this.poles.elementAt$I(i);
if (this.dragShape !== p ) {
p.paint$java_awt_Graphics(g);
if (p.isShowFVector()) {
this.paintForceOnCharge$java_awt_Graphics$eField4_Charge(g, p);
}}}
});

Clazz.newMeth(C$, 'paintThings$java_awt_Graphics', function (g) {
var v;
{
v = this.drawThings.clone();
}for (var e = v.elements(); e.hasMoreElements(); ) {
var t = e.nextElement();
t.paint$java_awt_Graphics(g);
if ((Clazz.instanceOf(t, "eField4.Charge")) && (t).isShowFVector() ) {
this.paintForceOnCharge$java_awt_Graphics$eField4_Charge(g, t);
}}
});

Clazz.newMeth(C$, 'paintArrowHeads$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var ah;
var n = this.arrowHeads.size();
for (var i = 0; i < n; i++) {
ah = this.arrowHeads.elementAt$I(i);
ah.paint$java_awt_Graphics$java_awt_Rectangle(g, r);
}
});

Clazz.newMeth(C$, 'getPotential$D$D', function (x, y) {
if (this.parser != null ) {
return this.parser.evaluate$D$D(x, y) + this.getPoleU$D$D(x, y);
}return this.getPoleU$D$D(x, y);
});

Clazz.newMeth(C$, 'getPE$eField4_Charge', function (c) {
if (c == null ) {
return 0;
}var x1 = c.getX();
var y1 = c.getY();
var m1 = c.getMag();
if (this.poles == null ) {
return 0;
}var p;
var x = 0;
var y = 0;
var m = 0;
var u = 0;
var r2 = 0;
var n = this.poles.size();
for (var i = 0; i < n; i++) {
p = this.poles.elementAt$I(i);
if (p !== c ) {
x = p.getX();
y = p.getY();
m = p.getMag();
r2 = (x - x1) * (x - x1) + (y - y1) * (y - y1);
if (r2 != 0 ) {
if (this.pointChargeMode) {
u += m * m1 / Math.sqrt(r2);
} else {
u += 2 * m * m1 * Math.log(r2) ;
}} else {
u = NaN;
}}}
if (this.parser != null ) {
u += m1 * this.parser.evaluate$D$D(x1, y1);
}return u;
});

Clazz.newMeth(C$, 'getPoleU$D$D', function (x1, y1) {
if (this.poles == null ) {
return 0;
}var p;
var x = 0;
var y = 0;
var m = 0;
var u = 0;
var r2 = 0;
var n = this.poles.size();
for (var i = 0; i < n; i++) {
p = this.poles.elementAt$I(i);
x = p.getX();
y = p.getY();
m = p.getMag();
r2 = (x - x1) * (x - x1) + (y - y1) * (y - y1);
if (r2 != 0 ) {
if (this.pointChargeMode) {
u += m / Math.sqrt(r2);
} else {
u += 2 * m * Math.log(r2) ;
}}}
return u;
});

Clazz.newMeth(C$, 'getFx$eField4_Charge', function (c) {
var x = c.getX();
var y = c.getY();
var m = c.getMag();
return m * (-this.dudx$D$D(x, y) + this.getPoleFx$D$D$eField4_Charge(x, y, c) + this.bz * c.getVY() );
});

Clazz.newMeth(C$, 'getFy$eField4_Charge', function (c) {
var x = c.getX();
var y = c.getY();
var m = c.getMag();
return m * (-this.dudy$D$D(x, y) + this.getPoleFy$D$D$eField4_Charge(x, y, c) - this.bz * c.getVX());
});

Clazz.newMeth(C$, 'getPoleFx$D$D$eField4_Charge', function (x1, y1, c) {
if (this.poles == null ) {
return 0;
}var p;
var x = 0;
var y = 0;
var m = 0;
var fx = 0;
var n = this.poles.size();
for (var i = 0; i < n; i++) {
p = this.poles.elementAt$I(i);
if (c !== p ) {
x = p.getX();
y = p.getY();
m = p.getMag();
if (this.pointChargeMode) {
fx += m * (x1 - x) / Math.pow((x - x1) * (x - x1) + (y - y1) * (y - y1), 1.5);
} else {
fx += 2 * m * (x1 - x)  / ((x - x1) * (x - x1) + (y - y1) * (y - y1));
}}}
return fx;
});

Clazz.newMeth(C$, 'getPoleFx_Cyl$D$D$eField4_Charge', function (x1, y1, c) {
if (this.poles == null ) {
return 0;
}var p;
var x = 0;
var y = 0;
var m = 0;
var fx = 0;
var n = this.poles.size();
for (var i = 0; i < n; i++) {
p = this.poles.elementAt$I(i);
if (c !== p ) {
x = p.getX();
y = p.getY();
m = p.getMag();
fx += 2 * m * (x1 - x)  / ((x - x1) * (x - x1) + (y - y1) * (y - y1));
}}
return fx;
});

Clazz.newMeth(C$, 'getPoleFy$D$D$eField4_Charge', function (x1, y1, c) {
if (this.poles == null ) {
return 0;
}var p;
var x = 0;
var y = 0;
var m = 0;
var fy = 0;
var n = this.poles.size();
for (var i = 0; i < n; i++) {
p = this.poles.elementAt$I(i);
if (c !== p ) {
x = p.getX();
y = p.getY();
m = p.getMag();
if (this.pointChargeMode) {
fy += m * (y1 - y) / Math.pow((x - x1) * (x - x1) + (y - y1) * (y - y1), 1.5);
} else {
fy += 2 * m * (y1 - y)  / ((x - x1) * (x - x1) + (y - y1) * (y - y1));
}}}
return fy;
});

Clazz.newMeth(C$, 'getPoleFy_Cyl$D$D$eField4_Charge', function (x1, y1, c) {
if (this.poles == null ) {
return 0;
}var p;
var x = 0;
var y = 0;
var m = 0;
var fy = 0;
var n = this.poles.size();
for (var i = 0; i < n; i++) {
p = this.poles.elementAt$I(i);
if (c !== p ) {
x = p.getX();
y = p.getY();
m = p.getMag();
fy += 2 * m * (y1 - y)  / ((x - x1) * (x - x1) + (y - y1) * (y - y1));
}}
return fy;
});

Clazz.newMeth(C$, 'dudx$D$D', function (x, y) {
var h = 1.0E-7;
if (this.parser == null ) {
return 0;
}var y1 = this.parser.evaluate$D$D(x - 2 * h, y);
var y2 = this.parser.evaluate$D$D(x - h, y);
var y3 = this.parser.evaluate$D$D(x + h, y);
var y4 = this.parser.evaluate$D$D(x + 2 * h, y);
return (-y4 + 8 * y3 - 8 * y2 + y1) / (12 * h);
});

Clazz.newMeth(C$, 'dudy$D$D', function (x, y) {
var h = 1.0E-7;
if (this.parser == null ) {
return 0;
}var y1 = this.parser.evaluate$D$D(x, y - 2 * h);
var y2 = this.parser.evaluate$D$D(x, y - h);
var y3 = this.parser.evaluate$D$D(x, y + h);
var y4 = this.parser.evaluate$D$D(x, y + 2 * h);
return (-y4 + 8 * y3 - 8 * y2 + y1) / (12 * h);
});

Clazz.newMeth(C$, 'getTime', function () {
return this.time;
});

Clazz.newMeth(C$, 'getThing$I', function (id) {
var t = null;
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (t.hashCode() == id) {
return t;
}}
return null;
});

Clazz.newMeth(C$, 'getCollisionThing', function () {
if (this.collisionDataSource != null ) {
return this.collisionDataSource;
}this.collisionDataSource = Clazz.new_((I$[23]||$incl$(23)).c$$eField4_OdeCanvas,[this]);
this.drawThings.addElement$TE(this.collisionDataSource);
return this.collisionDataSource;
});

Clazz.newMeth(C$, 'getParticleEnergy$eField4_Charge', function (s) {
var x = s.getX();
var y = s.getY();
var vx = s.getVX();
var vy = s.getVY();
var u;
if (this.parser != null ) {
u = this.parser.evaluate$D$D(x, y) + this.getPoleU$D$D(x, y);
} else {
u = this.getPoleU$D$D(x, y);
}return vx * vx / 2 + vy * vy / 2 + u;
});

Clazz.newMeth(C$, 'testForCollision', function () {
var c;
var n = this.testCharges.size();
for (var i = 0; i < n; i++) {
c = this.testCharges.elementAt$I(i);
if (!c.disabled) {
if ((Clazz.instanceOf(c, "eField4.TestCharge")) && this.isInsideStickyThing$I$I$eField4_Thing(this.pixFromX$D(c.vars[1]), this.pixFromY$D(c.vars[2]), c) ) {
return true;
}}}
return false;
});

Clazz.newMeth(C$, 'run', function () {
while (this.delayThread != null ){
{
if (!this.newData && (this.delayThread != null ) ) {
try {
this.delayLock.wait();
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
return;
} else {
throw ie;
}
}
}this.newData = false;
if (this.delayThread != null ) {
this.paint();
if (this.isDrag) {
this.paintCoordinates$D$D(this.mouseX, this.mouseY);
}}}if (this.delayThread != null ) {
try {
(I$[4]||$incl$(4)).sleep$J(50);
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
return;
} else {
throw ie;
}
}
}}
this.delayThread = null;
});

Clazz.newMeth(C$, 'step$D$D', function (dt, t_) {
this.time = t_ + dt;
var c;
var n = this.testCharges.size();
for (var i = 0; i < n; i++) {
c = this.testCharges.elementAt$I(i);
if (!c.disabled && (c.myMaster == null ) ) {
if (c.hasTrajectory()) {
c.setTime$D$D(this.time, dt);
} else {
(c).enforceConstraintOnXY();
(c).odeSolver.step$D$DA(dt, c.getVars());
}c.incTrail();
if ((Clazz.instanceOf(c, "eField4.TestCharge")) && this.isInsideStickyThing$I$I$eField4_Thing(this.pixFromX$D(c.vars[1]), this.pixFromY$D(c.vars[2]), c) ) {
this.collision = true;
c.vars[3] = 0;
c.vars[4] = 0;
if (this.collisionDataSource != null ) {
this.collisionDataSource.setXYT$D$D$D(c.vars[1], c.vars[1], this.time);
this.collisionDataSource.setBlock$Z(false);
this.parentSApplet.updateDataConnection$I(this.collisionDataSource.hashCode());
this.collisionDataSource.setBlock$Z(true);
}}}}
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
var t = e.nextElement();
if (t.myMaster != null ) {
t.setVarsFromMaster();
t.incTrail();
}}
var hasMoved = false;
for (var e = this.poles.elements(); e.hasMoreElements(); ) {
c = e.nextElement();
if (c.hasTrajectory()) {
hasMoved = true;
c.setTime$D$D(this.time, dt);
c.incTrail();
}}
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
var t = e.nextElement();
if (!(Clazz.instanceOf(t, "eField4.Charge"))) {
t.setTime$D$D(this.time, dt);
}}
if (hasMoved && this.showContours ) {
this.setFields();
} else if (hasMoved && this.showFieldVectors ) {
this.setDirectionVectors();
this.osiInvalid = true;
}if (this.parentSApplet != null ) {
this.parentSApplet.updateDataConnections();
}if (this.autoRefresh) {
{
this.newData = true;
this.delayLock.notify();
}}if (this.collision) {
this.setMessage$S(this.parentSApplet.label_collision);
this.parentSApplet.stopClock();
}});

Clazz.newMeth(C$, 'stopDrawingThread', function () {
{
this.delayLock.notify();
}try {
this.delayThread.interrupt();
this.delayThread.join$J(1000);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
;} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'destroy', function () {
{
this.stopFieldThreads();
}p$.stopDrawingThread.apply(this, []);
this.contour.destroy();
});

Clazz.newMeth(C$, 'stopFieldThreads', function () {
var v;
{
v = this.fieldSolvers.clone();
}if (v.size() == 0) {
return;
}var fs;
for (var e = v.elements(); e.hasMoreElements(); ) {
fs = e.nextElement();
fs.interrupt();
this.fieldSolvers.removeElement$O(fs);
}
this.parentSApplet.lock.getBusyFlag();
this.arrowHeads.removeAllElements();
this.contour.deleteAllNonSeriesData();
v = null;
this.parentSApplet.lock.freeBusyFlag();
this.calculatingFieldLines = false;
});

Clazz.newMeth(C$, 'setZRange', function () {
var p;
this.polemin = 0;
this.polemax = 0;
var n = this.fieldPoles.size();
for (var i = 0; i < n; i++) {
p = this.fieldPoles.elementAt$I(i);
if (this.polemin > p.getMaxU() ) {
this.polemin = p.getMaxU();
}if (this.polemax < p.getMaxU() ) {
this.polemax = p.getMaxU();
}}
});

Clazz.newMeth(C$, 'setFieldResolution$I', function (r) {
if (this.skip == r) {
return;
}this.skip = r;
if (this.autoRefresh) {
this.setFields();
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setGridSize$I', function (n) {
if (this.gridSize == n) {
return;
}this.gridSize = n;
if (this.autoRefresh) {
this.setFields();
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
try {
this.format = Clazz.new_((I$[10]||$incl$(10)).c$$S,[str]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.IllegalArgumentException")){
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'deleteFieldLines', function () {
var dataSet;
for (var e = this.fieldLines.elements(); e.hasMoreElements(); ) {
dataSet = e.nextElement();
this.contour.detachDataSet$edu_davidson_graph_DataSet(dataSet);
}
this.arrowHeads.removeAllElements();
this.fieldLines.removeAllElements();
});

Clazz.newMeth(C$, 'setFields', function () {
if (!this.autoRefresh) {
return;
}this.stopFieldThreads();
this.clearTrails();
this.parentSApplet.lock.getBusyFlag();
var nx = this.gridSize;
var ny = this.gridSize;
p$.deleteFieldLines.apply(this, []);
this.contour.deleteContours();
var z = Clazz.array(Double.TYPE, [nx, ny]);
var i;
var j;
var x;
var y;
this.calcFieldPoles();
this.setZRange();
for (j = 0; j < ny; j++) {
y = (this.ymax - this.ymin) * j / (ny - 1) + this.ymin;
for (i = 0; i < nx; i++) {
x = (this.xmax - this.xmin) * i / (nx - 1) + this.xmin;
var u = this.getPoleU$D$D(x, y);
if (u > this.polemax ) {
u = this.polemax;
}if (u < this.polemin ) {
u = this.polemin;
}if (this.parser != null ) {
z[i][j] = this.parser.evaluate$D$D(x, y) + u;
} else {
z[i][j] = u;
}}
}
this.contour.setGrid$DAA$D$D$D$D(z, this.xmin, this.xmax, this.ymin, this.ymax);
nx = (this.gridSize/this.skip|0);
ny = (this.gridSize/this.skip|0);
var force = this.field.resize$I$I(ny, nx);
for (j = 0; j < nx; j++) {
x = (this.xmax - this.xmin) * j / (nx - 1) + this.xmin;
for (i = 0; i < ny; i++) {
y = (this.ymax - this.ymin) * i / (ny - 1) + this.ymin;
var fx = -this.dudx$D$D(x, y) + this.getPoleFx$D$D$eField4_Charge(x, y, null);
var fy = -this.dudy$D$D(x, y) + this.getPoleFy$D$D$eField4_Charge(x, y, null);
var mag = Math.sqrt(fx * fx + fy * fy);
if (mag > 0 ) {
force[i][j][0] = fx / mag;
force[i][j][1] = fy / mag;
force[i][j][2] = mag;
} else {
force[i][j][0] = 0;
force[i][j][1] = 0;
force[i][j][2] = 0;
}}
}
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
var t = e.nextElement();
t.setAcceleration();
}
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
var t = e.nextElement();
t.setVarsFromMaster();
}
this.osiInvalid = true;
this.parentSApplet.lock.freeBusyFlag();
if (this.showFieldLines) {
this.fieldLinesInvalid = true;
}});

Clazz.newMeth(C$, 'setDirectionVectors', function () {
var x;
var y;
var nx = (this.gridSize/this.skip|0);
var ny = (this.gridSize/this.skip|0);
var force = this.field.resize$I$I(ny, nx);
for (var j = 0; j < nx; j++) {
x = (this.xmax - this.xmin) * j / (nx - 1) + this.xmin;
for (var i = 0; i < ny; i++) {
y = (this.ymax - this.ymin) * i / (ny - 1) + this.ymin;
var fx = -this.dudx$D$D(x, y) + this.getPoleFx$D$D$eField4_Charge(x, y, null);
var fy = -this.dudy$D$D(x, y) + this.getPoleFy$D$D$eField4_Charge(x, y, null);
var mag = Math.sqrt(fx * fx + fy * fy);
if (mag > 0 ) {
force[i][j][0] = fx / mag;
force[i][j][1] = fy / mag;
force[i][j][2] = mag;
} else {
force[i][j][0] = 0;
force[i][j][1] = 0;
force[i][j][2] = 0;
}}
}
});

Clazz.newMeth(C$, 'xFromPix$I', function (pix) {
if (this.contour != null ) {
return this.contour.xFromPix$I(pix);
} else {
return pix;
}});

Clazz.newMeth(C$, 'pixFromX$D', function (x) {
if (this.contour != null ) {
return this.contour.pixFromX$D(x);
} else {
return (Math.round(x)|0);
}});

Clazz.newMeth(C$, 'yFromPix$I', function (pix) {
if (this.contour != null ) {
return this.contour.yFromPix$I(pix);
} else {
return pix;
}});

Clazz.newMeth(C$, 'pixFromY$D', function (y) {
if (this.contour != null ) {
return this.contour.pixFromY$D(y);
} else {
return (Math.round(y)|0);
}});

Clazz.newMeth(C$, 'calcFieldPoles', function () {
var p;
{
this.fieldPoles.removeAllElements();
var n = this.poles.size();
this.allPositive = true;
this.allNegative = true;
if (n > 0) {
p = (this.poles.elementAt$I(0)).clone();
} else {
return;
}this.fieldPoles.addElement$TE(p);
if (p.mag < 0 ) {
this.allPositive = false;
}if (p.mag > 0 ) {
this.allNegative = false;
}for (var i = 1; i < n; i++) {
p = (this.poles.elementAt$I(i)).clone();
if (p.mag < 0 ) {
this.allPositive = false;
}if (p.mag > 0 ) {
this.allNegative = false;
}var noOverlap = true;
for (var j = 0; j < this.fieldPoles.size(); j++) {
var fp = this.fieldPoles.elementAt$I(j);
if (fp.doesOverlap$eField4_Charge(p)) {
noOverlap = false;
fp.mag = fp.mag + p.mag;
break;
}}
if (noOverlap) {
this.fieldPoles.addElement$TE(p);
}}
}});

Clazz.newMeth(C$, 'paintFieldLines', function () {
if (this.parentSApplet.destroyed) return;
if ((this.parser == null ) && (this.fieldPoles.size() == 0) ) {
return;
}var pole;
var x0;
var y0;
var x1;
var y1;
var a = 0;
var totalCharge = 0;
var numLines = 12;
var n = this.fieldPoles.size();
for (var i = 0; i < n; i++) {
pole = this.fieldPoles.elementAt$I(i);
totalCharge += pole.mag;
}
for (var i = 0; i < n; i++) {
pole = this.fieldPoles.elementAt$I(i);
if (Math.abs(pole.mag) < 4.94E-322 ) {
continue;
}numLines = (Math.round(Math.abs(12.0 * pole.mag))|0);
if (numLines > 48) {
numLines = 32;
}x0 = pole.getX();
y0 = pole.getY();
var r = pole.getRadius();
for (var j = 0; j < numLines; j++) {
a = 2 * 3.141592653589793 * j  / numLines;
x1 = r * Math.cos(a);
y1 = r * Math.sin(a);
if ((pole.mag > 0 ) && (totalCharge >= 0 ) ) {
Clazz.new_((I$[24]||$incl$(24)).c$$D$D$Z$eField4_Charge, [this, null, x0 + x1, y0 + y1, true, pole]);
}if ((pole.mag < 0 ) && (totalCharge < 0 ) ) {
Clazz.new_((I$[24]||$incl$(24)).c$$D$D$Z$eField4_Charge, [this, null, x0 + x1, y0 + y1, false, pole]);
}}
}
var dx = (this.xmax - this.xmin) / 100.0;
var integral = 0;
if (dx <= 0 ) {
dx = 0.01;
}if (this.parser != null ) {
var plus = (totalCharge >= 0 );
integral = this.paintLeftFieldLines$D$D$Z(integral, dx, plus);
integral = this.paintTopFieldLines$D$D$Z(integral, dx, plus);
integral = this.paintRightFieldLines$D$D$Z(integral, dx, plus);
integral = this.paintBottomFieldLines$D$D$Z(integral, dx, plus);
}return;
});

Clazz.newMeth(C$, 'paintLeftFieldLines$D$D$Z', function (integral, ds, plus) {
var x = this.xmin;
var y = this.ymin;
while (y < this.ymax ){
y += ds;
var fx = -(-this.dudx$D$D(x, y) + this.getPoleFx_Cyl$D$D$eField4_Charge(x, y, null));
if (plus && (fx < 0 ) ) {
integral += Math.abs(fx * ds);
}if (!plus && (fx > 0 ) ) {
integral += fx * ds;
}if (integral > 0.52 ) {
integral -= 0.52;
Clazz.new_((I$[24]||$incl$(24)).c$$D$D$Z, [this, null, x, y, plus]);
}}
return integral;
});

Clazz.newMeth(C$, 'paintTopFieldLines$D$D$Z', function (integral, ds, plus) {
var x = this.xmin;
var y = this.ymax;
while (x < this.xmax ){
x += ds;
var fy = -this.dudy$D$D(x, y) + this.getPoleFy_Cyl$D$D$eField4_Charge(x, y, null);
if (plus && (fy < 0 ) ) {
integral += Math.abs(fy * ds);
}if (!plus && (fy > 0 ) ) {
integral += fy * ds;
}if (integral > 0.52 ) {
integral -= 0.52;
Clazz.new_((I$[24]||$incl$(24)).c$$D$D$Z, [this, null, x, y, plus]);
}}
return integral;
});

Clazz.newMeth(C$, 'paintRightFieldLines$D$D$Z', function (integral, ds, plus) {
var x = this.xmax;
var y = this.ymax;
while (y > this.ymin ){
y -= ds;
var fx = -this.dudx$D$D(x, y) + this.getPoleFx_Cyl$D$D$eField4_Charge(x, y, null);
if (plus && (fx < 0 ) ) {
integral += Math.abs(fx * ds);
}if (!plus && (fx > 0 ) ) {
integral += fx * ds;
}if (integral > 0.52 ) {
integral -= 0.52;
Clazz.new_((I$[24]||$incl$(24)).c$$D$D$Z, [this, null, x, y, plus]);
}}
return integral;
});

Clazz.newMeth(C$, 'paintBottomFieldLines$D$D$Z', function (integral, ds, plus) {
var x = this.xmax;
var y = this.ymin;
while (x > this.xmin ){
x -= ds;
var fy = -(-this.dudy$D$D(x, y) + this.getPoleFy_Cyl$D$D$eField4_Charge(x, y, null));
if (plus && (fy < 0 ) ) {
integral += Math.abs(fy * ds);
}if (!plus && (fy > 0 ) ) {
integral += fy * ds;
}if (integral > 0.52 ) {
integral -= 0.52;
Clazz.new_((I$[24]||$incl$(24)).c$$D$D$Z, [this, null, x, y, plus]);
}}
return integral;
});

Clazz.newMeth(C$, 'isInsideStickyThing$I$I$eField4_Thing', function (x, y, exclude) {
var t = null;
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if ((t !== exclude ) && t.sticky && t.isInsideThing$I$I(x, y)  ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'isInsideDragableThing$I$I', function (x, y) {
var t = null;
for (var e = this.drawThings.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (!t.noDrag && t.isInsideThing$I$I(x, y) ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'isInsidePole$D$D', function (x, y) {
var pole;
var n = this.poles.size();
for (var i = 0; i < n; i++) {
pole = this.poles.elementAt$I(i);
if (pole.isInsidePole$D$D$eField4_OdeCanvas(x, y, this) && (pole !== this.dragShape ) ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'paintCoordinates$D$D', function (x, y) {
var g = this.getGraphics();
this.paintCoordinates$java_awt_Graphics$D$D(g, x, y);
g.dispose();
});

Clazz.newMeth(C$, 'paintCoordinates$java_awt_Graphics$D$D', function (g, x, y) {
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
var msg = "";
if (this.showCoordOnDrag) {
msg = "x=" + this.format.form$D(x) + " y=" + this.format.form$D(y) ;
}var infinite = this.isInsidePole$D$D(x, y);
if (this.showVOnDrag) {
if (infinite || ((this.dragShape != null ) && (Clazz.instanceOf(this.dragShape, "eField4.Pole")) ) ) {
msg = msg + " " + this.parentSApplet.label_volt_undefined ;
} else {
var u;
if (this.parser != null ) {
u = this.parser.evaluate$D$D(x, y) + this.getPoleU$D$D(x, y);
} else {
u = this.getPoleU$D$D(x, y);
}msg = msg + " " + this.parentSApplet.label_volt + this.format.form$D(u) ;
}}if ((this.dragShape != null ) && this.dragShape.showFOnDrag && (Clazz.instanceOf(this.dragShape, "eField4.Charge"))  ) {
var fx = this.dragShape.mag * (-this.dudx$D$D(x, y) + this.getPoleFx$D$D$eField4_Charge(x, y, this.dragShape) + this.bz * this.dragShape.getVY() );
var fy = this.dragShape.mag * (-this.dudy$D$D(x, y) + this.getPoleFy$D$D$eField4_Charge(x, y, this.dragShape) - this.bz * this.dragShape.getVX());
if (infinite) {
msg = msg + " " + this.parentSApplet.label_force_undefined ;
} else {
msg = msg + " " + this.parentSApplet.label_force + this.format.form$D(Math.sqrt(fx * fx + fy * fy)) ;
}} else if (this.showEOnDrag) {
if (infinite || (Clazz.instanceOf(this.dragShape, "eField4.Pole")) ) {
infinite = true;
msg = msg + " " + this.parentSApplet.label_field_undefined ;
} else {
var fx = -this.dudx$D$D(x, y) + this.getPoleFx$D$D$eField4_Charge(x, y, null);
var fy = -this.dudy$D$D(x, y) + this.getPoleFy$D$D$eField4_Charge(x, y, null);
msg = msg + " " + this.parentSApplet.label_field + this.format.form$D(Math.sqrt(fx * fx + fy * fy)) ;
}}g.setColor$java_awt_Color((I$[1]||$incl$(1)).yellow);
if (!msg.equals$O("")) {
this.boxWidth = Math.max(this.boxWidth, 20 + fm.stringWidth$S(msg));
}if (this.boxWidth == 0) {
return;
}g.fillRect$I$I$I$I(0, this.getBounds().height - 15, this.boxWidth, 15);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawString$S$I$I(msg, 8, this.getBounds().height - 2);
g.drawRect$I$I$I$I(0, this.getBounds().height - 15, this.boxWidth, 15);
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.boxWidth = 0;
var xpt = e.getX();
if (xpt < 1) {
xpt = 1;
} else if (xpt > this.iwidth - 2) {
xpt = this.iwidth - 2;
}var ypt = e.getY();
if (ypt < 1) {
ypt = 1;
} else if (ypt > this.iheight - 2) {
ypt = this.iheight - 2;
}var x = this.xFromPix$I(xpt);
var y = this.yFromPix$I(ypt);
if (this.dragShape != null ) {
if (this.dragV) {
this.dragShape.setVX$D(x - this.dragShape.getX());
this.dragShape.setVY$D(y - this.dragShape.getY());
} else {
if (this.dampOnMousePressed) {
this.dragShape.setVX$D(0);
this.dragShape.setVY$D(0);
}}this.dragShape.updateMySlaves();
if (Clazz.instanceOf(this.dragShape, "eField4.Pole")) {
this.setFields();
} else {
this.dragShape.clearTrail();
this.osiInvalid = true;
}if (!this.testForCollision()) {
this.collision = false;
this.message = null;
}this.repaint();
}if (this.isDrag) {
this.isDrag = false;
if (this.fieldSolvers.size() == 0) {
this.repaint();
}}this.dragShape = null;
this.this_mouseMoved$java_awt_event_MouseEvent(e);
if (this.sketchMode && (this.trailThing != null ) ) {
this.contour.attachDataSet$edu_davidson_graph_DataSet(this.trailThing.dataset);
this.contour.xaxis.attachDataSet$edu_davidson_graph_DataSet(this.trailThing.dataset);
this.contour.yaxis.attachDataSet$edu_davidson_graph_DataSet(this.trailThing.dataset);
{
this.newData = true;
this.delayLock.notify();
}}});

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
var x = this.xFromPix$I(e.getX());
var y = this.yFromPix$I(e.getY());
if ((e.isShiftDown() && this.showFieldLines ) || this.showFieldLineOnClick || ((e.getClickCount() == 2) && this.showFieldLineOnDoubleClick )  ) {
Clazz.new_((I$[24]||$incl$(24)).c$$D$D$Z, [this, null, x, y, true]);
Clazz.new_((I$[24]||$incl$(24)).c$$D$D$Z, [this, null, x, y, false]);
return;
}if (this.showEquipotentialOnClick || ((e.getClickCount() == 2) && this.showEquipotentialOnDoubleClick ) ) {
this.contour.calculateCurve$D(this.getPotential$D$D(x, y));
this.osiInvalid = true;
this.repaint();
return;
}var shape;
this.isDrag = true;
this.dragShape = null;
if (e.isControlDown()) {
this.dragV = true;
} else {
this.dragV = false;
}var g = this.getGraphics();
var n = this.drawThings.size();
for (var i = 0; i < n; i++) {
shape = this.drawThings.elementAt$I(i);
if (!shape.noDrag && shape.isInsideThing$I$I(e.getX(), e.getY()) ) {
this.dragShape = shape;
}}
this.osiInvalid = true;
if (this.dragShape != null ) {
if (Clazz.instanceOf(this.dragShape, "eField4.Pole")) {
this.stopFieldThreads();
}g.setXORMode$java_awt_Color(this.getBackground());
this.dragShape.paintHighlight$java_awt_Graphics(g);
if (this.dragV) {
this.dragShape.setVX$D(x - this.dragShape.getX());
this.dragShape.setVY$D(y - this.dragShape.getY());
} else {
if (this.dampOnMousePressed) {
this.dragShape.setVX$D(0);
this.dragShape.setVY$D(0);
}}this.dragShape.paint$java_awt_Graphics(g);
if ((Clazz.instanceOf(this.dragShape, "eField4.Charge")) && this.dragShape.isShowFVector() ) {
this.paintForceOnCharge$java_awt_Graphics$eField4_Charge(g, this.dragShape);
}g.setPaintMode();
}this.mouseX = x;
this.mouseY = y;
g.dispose();
this.paintCoordinates$D$D(x, y);
if (this.sketchMode && (this.trailThing != null ) ) {
this.trailThing.clearTrail();
this.parentSApplet.clearData$I(this.trailThing.hashCode());
this.setCursor$java_awt_Cursor((I$[25]||$incl$(25)).getPredefinedCursor$I(1));
this.this_mouseDragged$java_awt_event_MouseEvent(e);
}});

Clazz.newMeth(C$, 'this_mouseMoved$java_awt_event_MouseEvent', function (e) {
var xpt = e.getX();
var ypt = e.getY();
if (this.isInsideDragableThing$I$I(xpt, ypt)) {
this.setCursor$java_awt_Cursor((I$[25]||$incl$(25)).getPredefinedCursor$I(12));
} else if (this.sketchMode) {
this.setCursor$java_awt_Cursor((I$[25]||$incl$(25)).getPredefinedCursor$I(13));
} else {
this.setCursor$java_awt_Cursor((I$[25]||$incl$(25)).getPredefinedCursor$I(1));
}});

Clazz.newMeth(C$, 'charge_Dragged$java_awt_event_MouseEvent$Z', function (e, calcVectors) {
var xpt = e.getX();
if (xpt < 1) {
xpt = 1;
} else if (xpt > this.iwidth - 2) {
xpt = this.iwidth - 2;
}var x = this.xFromPix$I(xpt);
var y;
var ypt = e.getY();
if (ypt < 1) {
ypt = 1;
} else if (ypt > this.iheight - 2) {
ypt = this.iheight - 2;
}y = this.yFromPix$I(ypt);
this.mouseX = x;
this.mouseY = y;
if (this.isDrag) {
var g = this.getGraphics();
if (this.dragShape != null ) {
if (this.dragV) {
this.dragShape.setVX$D(x - this.dragShape.getX());
this.dragShape.setVY$D(y - this.dragShape.getY());
} else {
this.dragShape.setXY$D$D(x, y);
if (this.dampOnMousePressed) {
this.dragShape.setVX$D(0);
this.dragShape.setVY$D(0);
}this.dragShape.setAcceleration();
}if (this.parentSApplet.isClockRunning()) {
this.paintCoordinates$D$D(x, y);
return;
}this.parentSApplet.updateDataConnections();
if (this.osi == null ) {
this.osi = this.createImage$I$I(this.iwidth, this.iheight);
this.osi2 = this.createImage$I$I(this.iwidth, this.iheight);
}this.osiInvalid = false;
var osg = this.osi.getGraphics();
var r = Clazz.new_((I$[26]||$incl$(26)).c$$I$I,[this.iwidth, this.iheight]);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
if (calcVectors) {
this.setDirectionVectors();
this.field.paint$java_awt_Graphics$java_awt_Rectangle$I(osg, r, this.skip);
} else {
var tmpLabels = this.contour.getDrawLabels();
this.contour.setDrawLabels$Z(false);
this.contour.paint$java_awt_Graphics$java_awt_Rectangle(osg, r);
this.contour.setDrawLabels$Z(tmpLabels);
if (this.showFieldVectors) {
this.field.paint$java_awt_Graphics$java_awt_Rectangle$I(osg, r, this.skip);
}}for (var en = this.drawThings.elements(); en.hasMoreElements(); ) {
var t = en.nextElement();
if (Clazz.instanceOf(t, "eField4.TextThing")) {
t.setVarsFromMaster();
}}
this.dragShape.updateMySlaves();
this.paintThings$java_awt_Graphics(osg);
osg.dispose();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
if (this.showTime) {
var tStr = Clazz.new_((I$[10]||$incl$(10)).c$$S,["%7.4g"]).form$D(this.time);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
if (this.iwidth > 150) {
g.drawString$S$I$I(this.parentSApplet.label_time + tStr, 10, 15);
} else {
g.drawString$S$I$I(this.parentSApplet.label_time + tStr, 10, this.iheight - 40);
}}if (this.caption != null ) {
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
var fm = g.getFontMetrics$java_awt_Font(this.f);
g.drawString$S$I$I(this.caption, ((this.iwidth - fm.stringWidth$S(this.caption))/2|0), 25);
}g.setFont$java_awt_Font(oldFont);
}this.mouseX = x;
this.mouseY = y;
this.paintCoordinates$java_awt_Graphics$D$D(g, x, y);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawRect$I$I$I$I(0, 0, this.iwidth - 1, this.iheight - 1);
g.dispose();
}});

Clazz.newMeth(C$, 'this_mouseDragged$java_awt_event_MouseEvent', function (e) {
if (Clazz.instanceOf(this.dragShape, "eField4.Pole")) {
this.stopFieldThreads();
}if ((Clazz.instanceOf(this.dragShape, "eField4.Pole")) && (this.showFieldVectors) ) {
this.charge_Dragged$java_awt_event_MouseEvent$Z(e, true);
return;
}if (Clazz.instanceOf(this.dragShape, "eField4.Charge")) {
this.charge_Dragged$java_awt_event_MouseEvent$Z(e, false);
return;
}var xpt = e.getX();
if (xpt < 1) {
xpt = 1;
} else if (xpt > this.iwidth - 2) {
xpt = this.iwidth - 2;
}var x = this.xFromPix$I(xpt);
var y;
var ypt = e.getY();
if (ypt < 1) {
ypt = 1;
} else if (ypt > this.iheight - 2) {
ypt = this.iheight - 2;
}y = this.yFromPix$I(ypt);
this.mouseX = x;
this.mouseY = y;
if (this.isDrag && (this.dragShape != null ) ) {
if (this.dragV) {
this.dragShape.setVX$D(x - this.dragShape.getX());
this.dragShape.setVY$D(y - this.dragShape.getY());
} else {
this.dragShape.setXY$D$D(x, y);
if (this.dampOnMousePressed) {
this.dragShape.setVX$D(0);
this.dragShape.setVY$D(0);
}this.dragShape.setAcceleration();
}if (this.parentSApplet.isClockRunning()) {
this.paintCoordinates$D$D(x, y);
return;
}if (this.parentSApplet != null ) {
this.parentSApplet.updateDataConnections();
}for (var en = this.drawThings.elements(); en.hasMoreElements(); ) {
var t = en.nextElement();
if (Clazz.instanceOf(t, "eField4.TextThing")) {
t.setVarsFromMaster();
}}
this.dragShape.updateMySlaves();
if (this.autoRefresh) {
this.paint();
}} else {
this.paintCoordinates$D$D(x, y);
if (this.sketchMode && (this.trailThing != null ) ) {
x = Math.min(x, this.contour.xaxis.maximum);
x = Math.max(x, this.contour.xaxis.minimum);
y = Math.min(y, this.contour.yaxis.maximum);
y = Math.max(y, this.contour.yaxis.minimum);
this.trailThing.incTrail$D$D(x, y);
var g = this.getGraphics();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi2, 0, 0, this);
this.paintCoordinates$java_awt_Graphics$D$D(g, x, y);
if (this.sketchImage != null ) {
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.sketchImage, xpt, ypt - this.sketchImage.getHeight$java_awt_image_ImageObserver(this), this);
}this.trailThing.paint$java_awt_Graphics(g);
g.dispose();
this.parentSApplet.updateDataConnection$I(this.trailThing.hashCode());
}}});
;
(function(){var C$=Clazz.newClass(P$.OdeCanvas, "FieldSolver", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, ['Runnable', 'edu.davidson.numerics.SDifferentiable']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fieldColor = null;
this.odeSolver = null;
this.fieldThread = null;
this.fieldLine = null;
this.plus = false;
this.keepRunning = false;
this.interrupted = false;
this.data = null;
this.np = 0;
this.maxPts = 0;
this.points = null;
this.scale = 0;
this.origin = null;
this.dydx = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.fieldColor = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[128, 128, 255]);
this.odeSolver = Clazz.new_((I$[2]||$incl$(2)));
this.fieldThread = null;
this.fieldLine = Clazz.array(Double.TYPE, [2]);
this.plus = true;
this.keepRunning = true;
this.interrupted = false;
this.np = 0;
this.maxPts = 300;
this.points = Clazz.array(Double.TYPE, [2 * this.maxPts]);
this.scale = 1;
this.origin = null;
this.dydx = Clazz.array(Double.TYPE, [2]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$Z$eField4_Charge', function (x, y, p, or) {
C$.c$$D$D$Z.apply(this, [x, y, p]);
this.origin = or;
}, 1);

Clazz.newMeth(C$, 'c$$D$D$Z', function (x, y, p) {
C$.$init$.apply(this);
this.this$0.calculatingFieldLines = true;
if (this.this$0.parentSApplet.clock.isRunning()) {
this.this$0.parentSApplet.clock.stopClock();
}this.plus = p;
this.fieldLine[0] = x;
this.fieldLine[1] = y;
this.points[this.np] = x;
this.points[this.np + 1] = y;
this.np = this.np + 2;
this.odeSolver.setDifferentials$edu_davidson_numerics_SDifferentiable(this);
this.odeSolver.setTol$D(this.this$0.tolerance);
if (this.fieldThread == null ) {
this.fieldThread = Clazz.new_((I$[3]||$incl$(3)).c$$Runnable,[this]);
this.fieldThread.start();
}this.this$0.message = this.this$0.parentSApplet.label_calculating;
var g = this.this$0.getGraphics();
this.this$0.paintMessage$java_awt_Graphics$S(g, this.this$0.message);
g.dispose();
this.this$0.fieldSolvers.addElement$TE(this);
}, 1);

Clazz.newMeth(C$, 'getNumEqu', function () {
return 2;
});

Clazz.newMeth(C$, 'rate$DA', function (x) {
var fx = -this.this$0.dudx$D$D(x[0], x[1]) + this.this$0.getPoleFx$D$D$eField4_Charge(x[0], x[1], null);
var fy = -this.this$0.dudy$D$D(x[0], x[1]) + this.this$0.getPoleFy$D$D$eField4_Charge(x[0], x[1], null);
var f = Math.sqrt(fx * fx + fy * fy);
if (!this.plus) {
fy = -fy;
fx = -fx;
}if (f <= 0 ) {
this.dydx[0] = 0;
this.dydx[1] = 0;
this.keepRunning = false;
} else {
this.dydx[0] = this.scale * fx / f;
this.dydx[1] = this.scale * fy / f;
}return this.dydx;
});

Clazz.newMeth(C$, 'stepField', function () {
var ds = (this.this$0.xmax - this.this$0.xmin) / 20.0;
this.this$0.parentSApplet.lock.getBusyFlag();
var x0 = this.this$0.pixFromX$D(this.fieldLine[0]);
var y0 = this.this$0.pixFromY$D(this.fieldLine[1]);
this.odeSolver.setH$D(ds);
this.odeSolver.stepRK45$DA(this.fieldLine);
var x1 = this.this$0.pixFromX$D(this.fieldLine[0]);
var y1 = this.this$0.pixFromY$D(this.fieldLine[1]);
this.this$0.parentSApplet.lock.freeBusyFlag();
if (this.np < this.maxPts * 2) {
this.points[this.np] = this.fieldLine[0];
this.points[this.np + 1] = this.fieldLine[1];
this.np = this.np + 2;
}if ((Math.abs((this.this$0.iwidth/2|0) - x1) > (this.this$0.iwidth / 1.8) ) || (Math.abs((this.this$0.iheight/2|0) - y1) > (this.this$0.iheight / 1.8) ) ) {
this.scale = 20;
} else {
this.scale = 1;
}this.this$0.parentSApplet.lock.getBusyFlag();
var g = this.this$0.getGraphics();
g.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
g.drawLine$I$I$I$I(x0, y0, x1, y1);
g.dispose();
if (this.this$0.osi != null ) {
g = this.this$0.osi.getGraphics();
g.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
g.drawLine$I$I$I$I(x0, y0, x1, y1);
g.dispose();
}if (this.this$0.osi2 != null ) {
g = this.this$0.osi2.getGraphics();
g.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
g.drawLine$I$I$I$I(x0, y0, x1, y1);
g.dispose();
}this.this$0.parentSApplet.lock.freeBusyFlag();
if ((this.this$0.allPositive || this.this$0.allNegative ) && ((x0 < -1) || (y0 < -1) || (x0 > this.this$0.iwidth) || (y0 > this.this$0.iheight)  ) ) {
this.keepRunning = false;
}});

Clazz.newMeth(C$, 'endOfFieldLine', function () {
var n = this.this$0.fieldPoles.size();
for (var i = 0; i < n; i++) {
var c = this.this$0.fieldPoles.elementAt$I(i);
if (c !== this.origin ) {
var s = c.getSize();
var x0 = this.this$0.pixFromX$D(c.getX());
var y0 = this.this$0.pixFromY$D(c.getY());
var x1 = this.this$0.pixFromX$D(this.fieldLine[0]);
var y1 = this.this$0.pixFromY$D(this.fieldLine[1]);
var r = (x0 - x1) * (x0 - x1) + (y0 - y1) * (y0 - y1);
if (r < s * s) {
return true;
}}}
return false;
});

Clazz.newMeth(C$, 'interrupt', function () {
this.this$0.parentSApplet.lock.getBusyFlag();
this.interrupted = true;
this.this$0.parentSApplet.lock.freeBusyFlag();
var temp = this.fieldThread;
if (temp != null ) {
temp.interrupt();
}});

Clazz.newMeth(C$, 'run', function () {
var count = 0;
this.keepRunning = true;
while (this.keepRunning){
try {
while (this.this$0.osi == null ){
(I$[4]||$incl$(4)).sleep$J(50);
}
this.stepField();
(I$[4]||$incl$(4)).sleep$J(20);
count++;
if ((count >= this.maxPts) || this.endOfFieldLine() || this.interrupted  ) {
this.keepRunning = false;
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
return;
} else {
throw e;
}
}
}
this.fieldThread = null;
this.this$0.fieldSolvers.removeElement$O(this);
if (this.interrupted) {
this.points = null;
return;
}this.this$0.parentSApplet.lock.getBusyFlag();
this.data = this.this$0.contour.addDataSet$DA$I(this.points, count);
this.data.linecolor = this.fieldColor;
this.this$0.fieldLines.addElement$TE(this.data);
this.this$0.parentSApplet.lock.freeBusyFlag();
var index = 0;
if (count > 150) {
index = 10;
} else if (count > 8) {
index = (count/2|0);
}if (index > 0) {
var x = this.points[index * 2];
var y = this.points[index * 2 + 1];
var fx = -this.this$0.dudx$D$D(x, y) + this.this$0.getPoleFx$D$D$eField4_Charge(x, y, null);
var fy = -this.this$0.dudy$D$D(x, y) + this.this$0.getPoleFy$D$D$eField4_Charge(x, y, null);
var f = Math.sqrt(fx * fx + fy * fy);
if ((x > this.this$0.xmin ) && (x < this.this$0.xmax ) && (y > this.this$0.ymin ) && (y < this.this$0.ymax )  ) {
this.this$0.arrowHeads.addElement$TE(Clazz.new_((I$[5]||$incl$(5)).c$$eField4_OdeCanvas$D$D$D$D$java_awt_Color,[this.this$0, x, y, fx / f, fy / f, this.fieldColor]));
}}if (this.this$0.fieldSolvers.size() == 0) {
this.this$0.calculatingFieldLines = false;
this.this$0.message = null;
this.this$0.osiInvalid = true;
this.this$0.repaint();
}});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:20
