(function(){var P$=Clazz.newPackage("edu.davidson.surfaceplotter"),I$=[['edu.davidson.surfaceplotter.Controller','edu.davidson.surfaceplotter.DataGenerator','edu.davidson.surfaceplotter.SurfaceVertex','java.awt.Point','edu.davidson.surfaceplotter.LineAccumulator','edu.davidson.surfaceplotter.Projector','java.lang.Thread','java.awt.Color','java.awt.Rectangle','java.awt.Font','java.awt.Dimension']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SurfaceCanvas", null, 'a2s.Canvas', 'Runnable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.gutter = 0;
this.controller = null;
this.dataGenerator = null;
this.message = null;
this.calc_divisions = 0;
this.$mouseDown = false;
this.defaultFont = null;
this.forceNewImage = false;
this.Buffer = null;
this.BufferGC = null;
this.image_drawn = false;
this.paintThread = null;
this.vertex = null;
this.vertex_new = null;
this.shouldRun = false;
this.running = false;
this.runLock = null;
this.vertexLock = null;
this.data_available = false;
this.interrupted = false;
this.critical = false;
this.rotate = false;
this.$printing = false;
this.prevwidth = 0;
this.prevheight = 0;
this.printwidth = 0;
this.printheight = 0;
this.color = 0;
this.cop = null;
this.contour = false;
this.density = false;
this.noDrawing = false;
this.projector = null;
this.plot_mode = 0;
this.plotfunc1 = false;
this.plotfunc2 = false;
this.plotboth = false;
this.isBoxed = false;
this.isMesh = false;
this.isScaleBox = false;
this.isDisplayXY = false;
this.isDisplayZ = false;
this.isDisplayGrids = false;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.zmin = 0;
this.zmax = 0;
this.zminV = 0;
this.zmaxV = 0;
this.zfactorV = 0;
this.master_project_indexV = 0;
this.is_data_available = false;
this.dragged = false;
this.click_x = 0;
this.click_y = 0;
this.factor_x = 0;
this.factor_y = 0;
this.t_x = 0;
this.t_y = 0;
this.t_z = 0;
this.color_factor = 0;
this.projection = null;
this.line_color = null;
this.poly_x = null;
this.poly_y = null;
this.upperpart = null;
this.lowerpart = null;
this.values1 = null;
this.values2 = null;
this.testpoint = null;
this.contour_center_x = 0;
this.contour_center_y = 0;
this.contour_space_x = 0;
this.legend_width = 0;
this.legend_space = 0;
this.legend_length = 0;
this.legend_label = null;
this.contour_width_x = 0;
this.contour_width_y = 0;
this.contour_color = null;
this.ylabels = null;
this.xpoints = null;
this.ypoints = null;
this.contour_x = null;
this.contour_y = null;
this.contour_n = 0;
this.contour_lines = 0;
this.delta = null;
this.intersection = null;
this.contour_stepz = 0;
this.contour_vertex = null;
this.accumulator = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.gutter = 0;
this.controller = Clazz.new_((I$[1]||$incl$(1)));
this.dataGenerator = Clazz.new_((I$[2]||$incl$(2)).c$$edu_davidson_surfaceplotter_SurfaceCanvas,[this]);
this.message = null;
this.$mouseDown = false;
this.defaultFont = null;
this.forceNewImage = true;
this.vertex_new = null;
this.shouldRun = true;
this.running = false;
this.runLock =  Clazz.new_();
this.vertexLock =  Clazz.new_();
this.noDrawing = false;
this.master_project_indexV = 0;
this.poly_x = Clazz.array(Integer.TYPE, [9]);
this.poly_y = Clazz.array(Integer.TYPE, [9]);
this.upperpart = Clazz.array((I$[3]||$incl$(3)), [8]);
this.lowerpart = Clazz.array((I$[3]||$incl$(3)), [8]);
this.values1 = Clazz.array((I$[3]||$incl$(3)), [4]);
this.values2 = Clazz.array((I$[3]||$incl$(3)), [4]);
this.testpoint = Clazz.array((I$[4]||$incl$(4)), [5]);
this.contour_center_x = 0;
this.contour_center_y = 0;
this.contour_space_x = 0;
this.legend_width = 0;
this.legend_space = 0;
this.legend_length = 0;
this.legend_label = null;
this.contour_width_x = 0.0;
this.contour_width_y = 0.0;
this.contour_color = null;
this.ylabels = null;
this.xpoints = Clazz.array(Integer.TYPE, [8]);
this.ypoints = Clazz.array(Integer.TYPE, [8]);
this.contour_x = Clazz.array(Integer.TYPE, [8]);
this.contour_y = Clazz.array(Integer.TYPE, [8]);
this.contour_n = 0;
this.contour_lines = 10;
this.delta = Clazz.array(Float.TYPE, [4]);
this.intersection = Clazz.array(Float.TYPE, [4]);
this.contour_vertex = Clazz.array((I$[3]||$incl$(3)), [4]);
this.accumulator = Clazz.new_((I$[5]||$incl$(5)));
}, 1);

Clazz.newMeth(C$, 'setMessage$S', function (msg) {
if (msg == null  || msg.trim().equals$O("") ) this.message = null;
 else this.message = msg;
});

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.Buffer = null;
this.BufferGC = null;
this.image_drawn = this.interrupted = false;
this.data_available = false;
this.$printing = this.rotate = false;
this.contour = this.density = false;
this.prevwidth = this.prevheight = -1;
this.projector = Clazz.new_((I$[6]||$incl$(6)));
this.projector.setDistance$F(200);
this.projector.set2DScaling$F(10);
this.projector.setRotationAngle$F(125);
this.projector.setElevationAngle$F(10);
this.vertex = Clazz.array((I$[3]||$incl$(3)), [2, null]);
this.paintThread = Clazz.new_((I$[7]||$incl$(7)).c$$Runnable,[this]);
this.paintThread.start();
}, 1);

Clazz.newMeth(C$, 'destroyThread', function () {
this.paintThread.stop();
this.shouldRun = false;
this.rotate = false;
this.paintThread.interrupt();
this.running = true;
this.runLock.notify();
});

Clazz.newMeth(C$, 'destroyImage', function () {
this.image_drawn = false;
});

Clazz.newMeth(C$, 'setContour$Z', function (contour) {
this.noDrawing = false;
if (this.contour == contour ) return;
{
this.contour = contour;
if (contour) this.density = false;
}});

Clazz.newMeth(C$, 'setNoDrawing$Z', function (noDrawing) {
{
this.noDrawing = noDrawing;
}});

Clazz.newMeth(C$, 'setDensity$Z', function (density) {
this.noDrawing = false;
if (this.density == density ) return;
{
this.density = density;
if (density) this.contour = false;
}});

Clazz.newMeth(C$, 'setRanges$F$F$F$F', function (xmin, xmax, ymin, ymax) {
this.xmin = xmin;
this.xmax = xmax;
this.ymin = ymin;
this.ymax = ymax;
});

Clazz.newMeth(C$, 'getRanges', function () {
var ranges = Clazz.array(Float.TYPE, [6]);
ranges[0] = this.xmin;
ranges[1] = this.xmax;
ranges[2] = this.ymin;
ranges[3] = this.ymax;
ranges[4] = this.zmin;
ranges[5] = this.zmax;
return ranges;
});

Clazz.newMeth(C$, 'setDataAvailability$Z', function (avail) {
this.data_available = avail;
this.is_data_available = avail;
if (avail) {
this.image_drawn = false;
this.repaint();
}});

Clazz.newMeth(C$, 'setNewData$edu_davidson_surfaceplotter_SurfaceVertexAA', function (newVertex) {
{
if (this.vertex_new == null ) this.vertex = newVertex;
this.vertex_new = newVertex;
this.data_available = true;
this.is_data_available = true;
this.image_drawn = false;
this.repaint();
return this.vertex;
}});

Clazz.newMeth(C$, 'syncNewData', function () {
{
if (this.vertex_new != null ) this.vertex = this.vertex_new;
}});

Clazz.newMeth(C$, 'getValuesArray', function () {
if (!this.data_available) return null;
return this.vertex;
});

Clazz.newMeth(C$, 'mouseDown$java_awt_Event$I$I', function (e, x, y) {
this.click_x = x;
this.click_y = y;
this.$mouseDown = true;
return true;
});

Clazz.newMeth(C$, 'mouseUp$java_awt_Event$I$I', function (e, x, y) {
this.destroyImage();
this.data_available = this.is_data_available;
this.repaint();
this.dragged = false;
this.$mouseDown = false;
return true;
});

Clazz.newMeth(C$, 'mouseEnter$java_awt_Event$I$I', function (e, x, y) {
this.repaint();
return true;
});

Clazz.newMeth(C$, 'mouseDrag$java_awt_Event$I$I', function (e, x, y) {
var new_value = 0.0;
if (this.rotate || this.contour || this.density  ) return true;
if (!this.running || !this.data_available ) {
if (e != null  && e.controlDown() ) {
this.projector.set2D_xTranslation$I(this.projector.get2D_xTranslation() + (x - this.click_x));
this.projector.set2D_yTranslation$I(this.projector.get2D_yTranslation() + (y - this.click_y));
} else if (e != null  && e.shiftDown() ) {
new_value = this.projector.get2DScaling() + (y - this.click_y) * 0.5;
if (new_value > 60.0 ) new_value = 60.0;
if (new_value < 2.0 ) new_value = 2.0;
this.projector.set2DScaling$F(new_value);
} else {
new_value = this.projector.getRotationAngle() + (x - this.click_x);
while (new_value > 360 )new_value -= 360;

while (new_value < 0 )new_value += 360;

this.projector.setRotationAngle$F(new_value);
new_value = this.projector.getElevationAngle() + (y - this.click_y);
if (new_value > 90 ) new_value = 90;
 else if (new_value < 0 ) new_value = 0;
this.projector.setElevationAngle$F(new_value);
}this.image_drawn = false;
if (!this.controller.isExpectDelay()) {
this.repaint();
} else {
if (!this.dragged) {
this.is_data_available = this.data_available;
this.dragged = true;
}this.data_available = false;
this.repaint();
}}this.click_x = x;
this.click_y = y;
return true;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if ((this.getBounds().width <= 0) || (this.getBounds().height <= 0) ) return;
if (this.noDrawing) {
g.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
g.fillRect$I$I$I$I(0, 0, this.getBounds().width, this.getBounds().height);
return;
}if ((this.getBounds().width != this.prevwidth) || (this.getBounds().height != this.prevheight) || (this.BufferGC == null )  ) {
this.setMessage$S("New image size: " + this.getBounds().width + "x" + this.getBounds().height );
this.projector.setProjectionArea$java_awt_Rectangle(Clazz.new_((I$[9]||$incl$(9)).c$$I$I$I$I,[0, 0, this.getBounds().width, this.getBounds().height]));
this.image_drawn = false;
if (this.Buffer != null ) this.Buffer.flush();
this.Buffer = this.createImage$I$I(this.getBounds().width, this.getBounds().height);
if (this.BufferGC != null ) this.BufferGC.dispose();
this.BufferGC = this.Buffer.getGraphics();
this.setFont$java_awt_Font(this.defaultFont);
this.prevwidth = this.getBounds().width;
this.prevheight = this.getBounds().height;
}p$.importVariables.apply(this, []);
if (this.image_drawn && (this.Buffer != null ) ) {
if (g == null ) return;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.Buffer, 0, 0, this);
} else if (this.data_available && !this.interrupted ) {
{
this.running = true;
this.runLock.notify();
}} else {
if (this.Buffer == null ) {
g.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
g.fillRect$I$I$I$I(0, 0, this.getBounds().width, this.getBounds().height);
if (!this.contour && !this.density ) p$.drawBoxGridsTicksLabels$java_awt_Graphics$Z.apply(this, [g, true]);
}}this.interrupted = false;
var bb = this.getBounds();
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'setFont$java_awt_Font', function (df) {
this.defaultFont = df;
if (this.projector == null ) return;
var fontsize = ((Math.round(this.projector.get2DScaling() * 0.5))|0);
fontsize = Math.max(fontsize, 10);
if (this.defaultFont == null ) this.BufferGC.setFont$java_awt_Font(Clazz.new_((I$[10]||$incl$(10)).c$$S$I$I,["Helvetica", 0, fontsize]));
 else this.BufferGC.setFont$java_awt_Font(this.defaultFont);
});

Clazz.newMeth(C$, 'run', function () {
while (this.shouldRun){
{
while (!this.running)try {
this.runLock.wait();
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.Exception")){
} else {
throw ie;
}
}

if (this.shouldRun) this.running = p$.doCalc.apply(this, []);
}{

}
}
this.paintThread = null;
});

Clazz.newMeth(C$, 'doCalc', function () {
p$.syncNewData.apply(this, []);
this.master_project_indexV++;
if (this.contour) p$.plotContour.apply(this, []);
 else if (this.density) p$.plotDensity.apply(this, []);
 else {
if (this.plot_mode == 0) p$.plotWireframe.apply(this, []);
 else p$.plotSurface.apply(this, []);
}p$.cleanUpMemory.apply(this, []);
if (this.$printing) return false;
var g = this.getGraphics();
if (g == null ) return false;
this.paint$java_awt_Graphics(g);
g.dispose();
if (this.rotate) {
{

}
var newrot = this.projector.getRotationAngle() + 5;
while (newrot > 360 )newrot -= 360;

while (newrot < 0 )newrot += 360;

this.projector.setRotationAngle$F(newrot);
}return this.rotate;
});

Clazz.newMeth(C$, 'startRotation', function () {
{
this.rotate = true;
this.destroyImage();
this.controller.rotationStarts();
}this.repaint();
});

Clazz.newMeth(C$, 'stopRotation', function () {
if (!this.rotate) return;
this.rotate = false;
{
this.controller.rotationStops();
}});

Clazz.newMeth(C$, 'interrupt', function () {
this.running = false;
this.rotate = false;
{
this.setMessage$S("Interrupted");
p$.cleanUpMemory.apply(this, []);
this.image_drawn = false;
this.interrupted = true;
}this.repaint();
});

Clazz.newMeth(C$, 'preferredSize', function () {
return Clazz.new_((I$[11]||$incl$(11)).c$$I$I,[550, 550]);
});

Clazz.newMeth(C$, 'drawBoundingBox', function () {
var startingpoint;
var projection;
startingpoint = this.projector.project$F$F$F(this.factor_x * 10, this.factor_y * 10, 10);
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).black);
projection = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 10, 10);
this.BufferGC.drawLine$I$I$I$I(startingpoint.x, startingpoint.y, projection.x, projection.y);
projection = this.projector.project$F$F$F(this.factor_x * 10, -this.factor_y * 10, 10);
this.BufferGC.drawLine$I$I$I$I(startingpoint.x, startingpoint.y, projection.x, projection.y);
projection = this.projector.project$F$F$F(this.factor_x * 10, this.factor_y * 10, -10);
this.BufferGC.drawLine$I$I$I$I(startingpoint.x, startingpoint.y, projection.x, projection.y);
});

Clazz.newMeth(C$, 'drawBase$java_awt_Graphics$IA$IA', function (g, x, y) {
var projection = this.projector.project$F$F$F(-10, -10, -10);
x[0] = projection.x;
y[0] = projection.y;
projection = this.projector.project$F$F$F(-10, 10, -10);
x[1] = projection.x;
y[1] = projection.y;
projection = this.projector.project$F$F$F(10, 10, -10);
x[2] = projection.x;
y[2] = projection.y;
projection = this.projector.project$F$F$F(10, -10, -10);
x[3] = projection.x;
y[3] = projection.y;
x[4] = x[0];
y[4] = y[0];
if (this.plot_mode != 0) {
if (this.plot_mode == 1) g.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
 else g.setColor$java_awt_Color(Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I,[192, 220, 192]));
g.fillPolygon$IA$IA$I(x, y, 4);
}g.setColor$java_awt_Color((I$[8]||$incl$(8)).black);
g.drawPolygon$IA$IA$I(x, y, 5);
});

Clazz.newMeth(C$, 'drawBoxGridsTicksLabels$java_awt_Graphics$Z', function (g, draw_axes) {
var projection;
var tickpos;
var x_left = false;
var y_left = false;
var x;
var y;
var i;
x = Clazz.array(Integer.TYPE, [5]);
y = Clazz.array(Integer.TYPE, [5]);
if (this.projector == null ) return;
if (draw_axes) {
p$.drawBase$java_awt_Graphics$IA$IA.apply(this, [g, x, y]);
projection = this.projector.project$F$F$F(0, 0, -10);
x[0] = projection.x;
y[0] = projection.y;
projection = this.projector.project$F$F$F(10.5, 0, -10);
g.drawLine$I$I$I$I(x[0], y[0], projection.x, projection.y);
if (projection.x < x[0]) p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [g, ((1.05 * (projection.x - x[0]))|0) + x[0], ((1.05 * (projection.y - y[0]))|0) + y[0], "x", 4, 0]);
 else p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [g, ((1.05 * (projection.x - x[0]))|0) + x[0], ((1.05 * (projection.y - y[0]))|0) + y[0], "x", 2, 0]);
projection = this.projector.project$F$F$F(0, 11.5, -10);
g.drawLine$I$I$I$I(x[0], y[0], projection.x, projection.y);
if (projection.x < x[0]) p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [g, ((1.05 * (projection.x - x[0]))|0) + x[0], ((1.05 * (projection.y - y[0]))|0) + y[0], "y", 4, 0]);
 else p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [g, ((1.05 * (projection.x - x[0]))|0) + x[0], ((1.05 * (projection.y - y[0]))|0) + y[0], "y", 2, 0]);
projection = this.projector.project$F$F$F(0, 0, 10.5);
g.drawLine$I$I$I$I(x[0], y[0], projection.x, projection.y);
p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [g, ((1.05 * (projection.x - x[0]))|0) + x[0], ((1.05 * (projection.y - y[0]))|0) + y[0], "z", 0, 1]);
} else {
this.factor_x = this.factor_y = 1;
projection = this.projector.project$F$F$F(0, 0, -10);
x[0] = projection.x;
projection = this.projector.project$F$F$F(10.5, 0, -10);
y_left = projection.x > x[0];
i = projection.y;
projection = this.projector.project$F$F$F(-10.5, 0, -10);
if (projection.y > i) {
this.factor_x = -1;
y_left = projection.x > x[0];
}projection = this.projector.project$F$F$F(0, 10.5, -10);
x_left = projection.x > x[0];
i = projection.y;
projection = this.projector.project$F$F$F(0, -10.5, -10);
if (projection.y > i) {
this.factor_y = -1;
x_left = projection.x > x[0];
}p$.setAxesScale.apply(this, []);
p$.drawBase$java_awt_Graphics$IA$IA.apply(this, [g, x, y]);
if (this.isBoxed) {
projection = this.projector.project$F$F$F(-this.factor_x * 10, -this.factor_y * 10, -10);
x[0] = projection.x;
y[0] = projection.y;
projection = this.projector.project$F$F$F(-this.factor_x * 10, -this.factor_y * 10, 10);
x[1] = projection.x;
y[1] = projection.y;
projection = this.projector.project$F$F$F(this.factor_x * 10, -this.factor_y * 10, 10);
x[2] = projection.x;
y[2] = projection.y;
projection = this.projector.project$F$F$F(this.factor_x * 10, -this.factor_y * 10, -10);
x[3] = projection.x;
y[3] = projection.y;
x[4] = x[0];
y[4] = y[0];
if (this.plot_mode != 0) {
if (this.plot_mode == 1) g.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
 else g.setColor$java_awt_Color(Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I,[192, 220, 192]));
g.fillPolygon$IA$IA$I(x, y, 4);
}g.setColor$java_awt_Color((I$[8]||$incl$(8)).black);
g.drawPolygon$IA$IA$I(x, y, 5);
projection = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 10, 10);
x[2] = projection.x;
y[2] = projection.y;
projection = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 10, -10);
x[3] = projection.x;
y[3] = projection.y;
x[4] = x[0];
y[4] = y[0];
if (this.plot_mode != 0) {
if (this.plot_mode == 1) g.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
 else g.setColor$java_awt_Color(Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I,[192, 220, 192]));
g.fillPolygon$IA$IA$I(x, y, 4);
}g.setColor$java_awt_Color((I$[8]||$incl$(8)).black);
g.drawPolygon$IA$IA$I(x, y, 5);
} else if (this.isDisplayZ) {
projection = this.projector.project$F$F$F(this.factor_x * 10, -this.factor_y * 10, -10);
x[0] = projection.x;
y[0] = projection.y;
projection = this.projector.project$F$F$F(this.factor_x * 10, -this.factor_y * 10, 10);
g.drawLine$I$I$I$I(x[0], y[0], projection.x, projection.y);
projection = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 10, -10);
x[0] = projection.x;
y[0] = projection.y;
projection = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 10, 10);
g.drawLine$I$I$I$I(x[0], y[0], projection.x, projection.y);
}for (i = -9; i <= 9; i++) {
if (this.isDisplayXY || this.isDisplayGrids ) {
if (!this.isDisplayGrids || (i % ((this.t_y/2|0)) == 0) || this.isDisplayXY  ) {
if (this.isDisplayGrids && (i % this.t_y == 0) ) projection = this.projector.project$F$F$F(-this.factor_x * 10, i, -10);
 else {
if (i % this.t_y != 0) projection = this.projector.project$F$F$F(this.factor_x * 9.8, i, -10);
 else projection = this.projector.project$F$F$F(this.factor_x * 9.5, i, -10);
}tickpos = this.projector.project$F$F$F(this.factor_x * 10, i, -10);
g.drawLine$I$I$I$I(projection.x, projection.y, tickpos.x, tickpos.y);
if ((i % this.t_y == 0) && this.isDisplayXY ) {
tickpos = this.projector.project$F$F$F(this.factor_x * 10.5, i, -10);
if (y_left) p$.outFloat$java_awt_Graphics$I$I$F$I$I.apply(this, [g, tickpos.x, tickpos.y, ((i + 10) / 20 * (this.ymax - this.ymin) + this.ymin), 2, 0]);
 else p$.outFloat$java_awt_Graphics$I$I$F$I$I.apply(this, [g, tickpos.x, tickpos.y, ((i + 10) / 20 * (this.ymax - this.ymin) + this.ymin), 4, 0]);
}}if (!this.isDisplayGrids || (i % ((this.t_x/2|0)) == 0) || this.isDisplayXY  ) {
if (this.isDisplayGrids && (i % this.t_x == 0) ) projection = this.projector.project$F$F$F(i, -this.factor_y * 10, -10);
 else {
if (i % this.t_x != 0) projection = this.projector.project$F$F$F(i, this.factor_y * 9.8, -10);
 else projection = this.projector.project$F$F$F(i, this.factor_y * 9.5, -10);
}tickpos = this.projector.project$F$F$F(i, this.factor_y * 10, -10);
g.drawLine$I$I$I$I(projection.x, projection.y, tickpos.x, tickpos.y);
if ((i % this.t_x == 0) && this.isDisplayXY ) {
tickpos = this.projector.project$F$F$F(i, this.factor_y * 10.5, -10);
if (x_left) p$.outFloat$java_awt_Graphics$I$I$F$I$I.apply(this, [g, tickpos.x, tickpos.y, ((i + 10) / 20 * (this.xmax - this.xmin) + this.xmin), 2, 0]);
 else p$.outFloat$java_awt_Graphics$I$I$F$I$I.apply(this, [g, tickpos.x, tickpos.y, ((i + 10) / 20 * (this.xmax - this.xmin) + this.xmin), 4, 0]);
}}}if (this.isDisplayXY) {
tickpos = this.projector.project$F$F$F(0, this.factor_y * 14, -10);
p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [g, tickpos.x, tickpos.y, "X", 0, 0]);
tickpos = this.projector.project$F$F$F(this.factor_x * 14, 0, -10);
p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [g, tickpos.x, tickpos.y, "Y", 0, 0]);
}if (this.isDisplayZ || (this.isDisplayGrids && this.isBoxed ) ) {
if (!this.isDisplayGrids || (i % ((this.t_z/2|0)) == 0) || this.isDisplayZ  ) {
if (this.isBoxed && this.isDisplayGrids && (i % this.t_z == 0)  ) {
projection = this.projector.project$F$F$F(-this.factor_x * 10, -this.factor_y * 10, i);
tickpos = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 10, i);
} else {
if (i % this.t_z == 0) projection = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 9.5, i);
 else projection = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 9.8, i);
tickpos = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 10, i);
}g.drawLine$I$I$I$I(projection.x, projection.y, tickpos.x, tickpos.y);
if (this.isDisplayZ) {
tickpos = this.projector.project$F$F$F(-this.factor_x * 10, this.factor_y * 10.5, i);
if (i % this.t_z == 0) {
if (x_left) p$.outFloat$java_awt_Graphics$I$I$F$I$I.apply(this, [g, tickpos.x, tickpos.y, ((i + 10) / 20 * (this.zmax - this.zmin) + this.zmin), 2, 1]);
 else p$.outFloat$java_awt_Graphics$I$I$F$I$I.apply(this, [g, tickpos.x, tickpos.y, ((i + 10) / 20 * (this.zmax - this.zmin) + this.zmin), 4, 1]);
}}if (this.isDisplayGrids && this.isBoxed && (i % this.t_z == 0)  ) {
projection = this.projector.project$F$F$F(-this.factor_x * 10, -this.factor_y * 10, i);
tickpos = this.projector.project$F$F$F(this.factor_x * 10, -this.factor_y * 10, i);
} else {
if (i % this.t_z == 0) projection = this.projector.project$F$F$F(this.factor_x * 9.5, -this.factor_y * 10, i);
 else projection = this.projector.project$F$F$F(this.factor_x * 9.8, -this.factor_y * 10, i);
tickpos = this.projector.project$F$F$F(this.factor_x * 10, -this.factor_y * 10, i);
}g.drawLine$I$I$I$I(projection.x, projection.y, tickpos.x, tickpos.y);
if (this.isDisplayZ) {
tickpos = this.projector.project$F$F$F(this.factor_x * 10.5, -this.factor_y * 10, i);
if (i % this.t_z == 0) {
if (y_left) p$.outFloat$java_awt_Graphics$I$I$F$I$I.apply(this, [g, tickpos.x, tickpos.y, ((i + 10) / 20 * (this.zmax - this.zmin) + this.zmin), 2, 1]);
 else p$.outFloat$java_awt_Graphics$I$I$F$I$I.apply(this, [g, tickpos.x, tickpos.y, ((i + 10) / 20 * (this.zmax - this.zmin) + this.zmin), 4, 1]);
}}if (this.isDisplayGrids && this.isBoxed ) {
if (i % this.t_y == 0) {
projection = this.projector.project$F$F$F(-this.factor_x * 10, i, -10);
tickpos = this.projector.project$F$F$F(-this.factor_x * 10, i, 10);
g.drawLine$I$I$I$I(projection.x, projection.y, tickpos.x, tickpos.y);
}if (i % this.t_x == 0) {
projection = this.projector.project$F$F$F(i, -this.factor_y * 10, -10);
tickpos = this.projector.project$F$F$F(i, -this.factor_y * 10, 10);
g.drawLine$I$I$I$I(projection.x, projection.y, tickpos.x, tickpos.y);
}}}}}
}});

Clazz.newMeth(C$, 'importVariables', function () {
this.plot_mode = this.controller.getPlotMode();
if (this.$mouseDown && !this.contour && !this.density  ) this.plot_mode = 0;
this.isBoxed = this.controller.isBoxed();
this.isMesh = this.controller.isMesh();
this.isScaleBox = this.controller.isScaleBox();
this.isDisplayXY = this.controller.isDisplayXY();
this.isDisplayZ = this.controller.isDisplayZ();
this.isDisplayGrids = this.controller.isDisplayGrids();
this.calc_divisions = this.controller.getCalcDivisions();
this.plotfunc1 = this.controller.isPlotFunction1() || (this.dataGenerator.isExternalData()) ;
this.plotfunc2 = this.controller.isPlotFunction2();
this.plotboth = this.plotfunc1 && this.plotfunc2 ;
});

Clazz.newMeth(C$, 'setAxesScale', function () {
var scale_x;
var scale_y;
var scale_z;
var divisor;
var longest;
if (!this.isScaleBox) {
this.projector.setScaling$F(1);
this.t_x = this.t_y = this.t_z = 4;
return;
}scale_x = this.xmax - this.xmin;
scale_y = this.ymax - this.ymin;
scale_z = this.zmax - this.zmin;
if (scale_x < scale_y ) {
if (scale_y < scale_z ) {
longest = 3;
divisor = scale_z;
} else {
longest = 2;
divisor = scale_y;
}} else {
if (scale_x < scale_z ) {
longest = 3;
divisor = scale_z;
} else {
longest = 1;
divisor = scale_x;
}}scale_x /= divisor;
scale_y /= divisor;
scale_z /= divisor;
if ((scale_x < 0.2 ) || (scale_y < 0.2 ) && (scale_z < 0.2 )  ) {
switch (longest) {
case 1:
if (scale_y < scale_z ) {
scale_y /= scale_z;
scale_z = 1.0;
} else {
scale_z /= scale_y;
scale_y = 1.0;
}break;
case 2:
if (scale_x < scale_z ) {
scale_x /= scale_z;
scale_z = 1.0;
} else {
scale_z /= scale_x;
scale_x = 1.0;
}break;
case 3:
if (scale_y < scale_x ) {
scale_y /= scale_x;
scale_x = 1.0;
} else {
scale_x /= scale_y;
scale_y = 1.0;
}break;
}
}if (scale_x < 0.2 ) scale_x = 1.0;
this.projector.setXScaling$F(scale_x);
if (scale_y < 0.2 ) scale_y = 1.0;
this.projector.setYScaling$F(scale_y);
if (scale_z < 0.2 ) scale_z = 1.0;
this.projector.setZScaling$F(scale_z);
if (scale_x < 0.5 ) this.t_x = 8;
 else this.t_x = 4;
if (scale_y < 0.5 ) this.t_y = 8;
 else this.t_y = 4;
if (scale_z < 0.5 ) this.t_z = 8;
 else this.t_z = 4;
});

Clazz.newMeth(C$, 'outString$java_awt_Graphics$I$I$S$I$I', function (g, x, y, s, x_align, y_align) {
switch (y_align) {
case 0:
y = y+(g.getFontMetrics$java_awt_Font(g.getFont()).getAscent());
break;
case 1:
y = y+((g.getFontMetrics$java_awt_Font(g.getFont()).getAscent()/2|0));
break;
}
switch (x_align) {
case 2:
g.drawString$S$I$I(s, x, y);
break;
case 4:
g.drawString$S$I$I(s, x - g.getFontMetrics$java_awt_Font(g.getFont()).stringWidth$S(s), y);
break;
case 0:
g.drawString$S$I$I(s, x - (g.getFontMetrics$java_awt_Font(g.getFont()).stringWidth$S(s)/2|0), y);
break;
}
});

Clazz.newMeth(C$, 'outFloat$java_awt_Graphics$I$I$F$I$I', function (g, x, y, f, x_align, y_align) {
var s = Float.toString(f);
p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [g, x, y, s, x_align, y_align]);
});

Clazz.newMeth(C$, 'plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I', function (vertex, verticescount) {
var count;
var loop;
var index;
var z;
var result;
var low1;
var low2;
var valid1;
var valid2;
if (verticescount < 3) return;
count = 0;
z = 0.0;
this.line_color = (I$[8]||$incl$(8)).black;
low1 = (vertex[0].z < this.zmin );
valid1 = !low1 && (vertex[0].z <= this.zmax ) ;
index = 1;
for (loop = 0; loop < verticescount; loop++) {
low2 = (vertex[index].z < this.zmin );
valid2 = !low2 && (vertex[index].z <= this.zmax ) ;
if ((valid1 || valid2 ) || (!!(low1 ^ low2)) ) {
if (!valid1) {
if (low1) result = this.zmin;
 else result = this.zmax;
var ratio = (result - vertex[index].z) / (vertex[loop].z - vertex[index].z);
var new_x = ratio * (vertex[loop].x - vertex[index].x) + vertex[index].x;
var new_y = ratio * (vertex[loop].y - vertex[index].y) + vertex[index].y;
if (low1) this.projection = this.projector.project$F$F$F(new_x, new_y, -10);
 else this.projection = this.projector.project$F$F$F(new_x, new_y, 10);
this.poly_x[count] = this.projection.x;
this.poly_y[count] = this.projection.y;
count++;
z += result;
}if (valid2) {
this.projection = vertex[index].projection();
this.poly_x[count] = this.projection.x;
this.poly_y[count] = this.projection.y;
count++;
z += vertex[index].z;
} else {
if (low2) result = this.zmin;
 else result = this.zmax;
var ratio = (result - vertex[loop].z) / (vertex[index].z - vertex[loop].z);
var new_x = ratio * (vertex[index].x - vertex[loop].x) + vertex[loop].x;
var new_y = ratio * (vertex[index].y - vertex[loop].y) + vertex[loop].y;
if (low2) this.projection = this.projector.project$F$F$F(new_x, new_y, -10);
 else this.projection = this.projector.project$F$F$F(new_x, new_y, 10);
this.poly_x[count] = this.projection.x;
this.poly_y[count] = this.projection.y;
count++;
z += result;
}}if (++index == verticescount) index = 0;
valid1 = valid2;
low1 = low2;
}
if (count > 0) {
switch (this.plot_mode) {
case 1:
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
break;
case 2:
z = 0.8 - (z / count - this.zmin) * this.color_factor;
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).getHSBColor$F$F$F(z, 1.0, 1.0));
break;
case 3:
z = (z / count - this.zmin) * this.color_factor;
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).getHSBColor$F$F$F(0, 0, z));
if (z < 0.3 ) this.line_color = Clazz.new_((I$[8]||$incl$(8)).c$$F$F$F,[0.6, 0.6, 0.6]);
break;
case 4:
z = (z / count - this.zmin) * this.color_factor + 0.4;
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).getHSBColor$F$F$F(this.color, 0.7, z));
break;
}
this.BufferGC.fillPolygon$IA$IA$I(this.poly_x, this.poly_y, count);
this.BufferGC.setColor$java_awt_Color(this.line_color);
if (this.isMesh || (this.plot_mode == 1) ) {
this.poly_x[count] = this.poly_x[0];
this.poly_y[count] = this.poly_y[0];
count++;
this.BufferGC.drawPolygon$IA$IA$I(this.poly_x, this.poly_y, count);
}}});

Clazz.newMeth(C$, 'splitPlotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$edu_davidson_surfaceplotter_SurfaceVertexA', function (values1, values2) {
var trackposition = 0;
var uppercount = 0;
var lowercount = 0;
var coincide = true;
var upper_first = false;
var factor;
var xi;
var yi;
var zi;
var i = 0;
var j = 0;
for (var counter = 0; counter <= 4; counter++) {
if (values1[i].z < values2[i].z ) {
coincide = false;
if (trackposition == 0) {
trackposition = 1;
this.upperpart[uppercount++] = values2[i];
} else if (trackposition != 1) {
factor = (values1[i].z - values2[i].z) / (values1[i].z - values2[i].z + values2[j].z - values1[j].z);
if (values1[i].x == values1[j].x ) {
yi = factor * (values1[j].y - values1[i].y) + values1[i].y;
xi = values1[i].x;
} else {
xi = factor * (values1[j].x - values1[i].x) + values1[i].x;
yi = values1[i].y;
}zi = factor * (values2[j].z - values2[i].z) + values2[i].z;
this.upperpart[uppercount++] = this.lowerpart[lowercount++] = Clazz.new_((I$[3]||$incl$(3)).c$$F$F$F$edu_davidson_surfaceplotter_SurfaceCanvas,[xi, yi, zi, this]);
this.upperpart[uppercount++] = values2[i];
trackposition = 1;
} else {
this.upperpart[uppercount++] = values2[i];
}} else if (values1[i].z > values2[i].z ) {
coincide = false;
if (trackposition == 0) {
trackposition = -1;
this.lowerpart[lowercount++] = values2[i];
} else if (trackposition != -1) {
factor = (values1[i].z - values2[i].z) / (values1[i].z - values2[i].z + values2[j].z - values1[j].z);
if (values1[i].x == values1[j].x ) {
yi = factor * (values1[j].y - values1[i].y) + values1[i].y;
xi = values1[i].x;
} else {
xi = factor * (values1[j].x - values1[i].x) + values1[i].x;
yi = values1[i].y;
}zi = factor * (values2[j].z - values2[i].z) + values2[i].z;
this.lowerpart[lowercount++] = this.upperpart[uppercount++] = Clazz.new_((I$[3]||$incl$(3)).c$$F$F$F$edu_davidson_surfaceplotter_SurfaceCanvas,[xi, yi, zi, this]);
this.lowerpart[lowercount++] = values2[i];
trackposition = -1;
} else {
this.lowerpart[lowercount++] = values2[i];
}} else {
this.upperpart[uppercount++] = values2[i];
this.lowerpart[lowercount++] = values2[i];
trackposition = 0;
}j = i;
i = (i + 1) % 4;
}
if (coincide) {
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [values1, 4]);
} else {
if (this.critical) upper_first = false;
 else {
if (values1[1].x == values1[2].x ) {
upper_first = (values1[2].z - values1[3].z) * (this.cop.x - values1[3].x) / (values1[2].x - values1[3].x) + values1[3].z + (values1[2].z - values1[1].z) * (this.cop.y - values1[1].y) / (values1[2].y - values1[1].y) + values1[1].z - values1[2].z > this.cop.z ;
} else {
upper_first = (values1[2].z - values1[1].z) * (this.cop.x - values1[1].x) / (values1[2].x - values1[1].x) + values1[1].z + (values1[2].z - values1[3].z) * (this.cop.y - values1[3].y) / (values1[2].y - values1[3].y) + values1[3].z - values1[2].z > this.cop.z ;
}}if (lowercount < 3) {
if (upper_first) {
this.color = 0.7;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.upperpart, uppercount]);
this.color = 0.2;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [values1, 4]);
} else {
this.color = 0.2;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [values1, 4]);
this.color = 0.7;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.upperpart, uppercount]);
}} else if (uppercount < 3) {
if (upper_first) {
this.color = 0.2;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [values1, 4]);
this.color = 0.7;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.lowerpart, lowercount]);
} else {
this.color = 0.7;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.lowerpart, lowercount]);
this.color = 0.2;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [values1, 4]);
}} else {
if (upper_first) {
this.color = 0.7;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.upperpart, uppercount]);
this.color = 0.2;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [values1, 4]);
this.color = 0.7;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.lowerpart, lowercount]);
} else {
this.color = 0.7;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.lowerpart, lowercount]);
this.color = 0.2;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [values1, 4]);
this.color = 0.7;
p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.upperpart, uppercount]);
}}}});

Clazz.newMeth(C$, 'plottable$edu_davidson_surfaceplotter_SurfaceVertexA', function (values) {
return (!values[0].isInvalid() && !values[1].isInvalid() && !values[2].isInvalid() && !values[3].isInvalid()  );
});

Clazz.newMeth(C$, 'plotArea$I$I$I$I$I$I', function (start_lx, start_ly, end_lx, end_ly, sx, sy) {
start_lx = start_lx*(this.calc_divisions + 1);
sx = sx*(this.calc_divisions + 1);
end_lx = end_lx*(this.calc_divisions + 1);
var lx = start_lx;
var ly = start_ly;
while (ly != end_ly){
if (this.plotfunc1) {
this.values1[1] = this.vertex[0][lx + ly];
this.values1[2] = this.vertex[0][lx + ly + sy ];
}if (this.plotfunc2) {
this.values2[1] = this.vertex[1][lx + ly];
this.values2[2] = this.vertex[1][lx + ly + sy ];
}while (lx != end_lx){
if (this.plotfunc1) {
this.values1[0] = this.values1[1];
this.values1[1] = this.vertex[0][lx + sx + ly ];
this.values1[3] = this.values1[2];
this.values1[2] = this.vertex[0][lx + sx + ly + sy ];
}if (this.plotfunc2) {
this.values2[0] = this.values2[1];
this.values2[1] = this.vertex[1][lx + sx + ly ];
this.values2[3] = this.values2[2];
this.values2[2] = this.vertex[1][lx + sx + ly + sy ];
}if (!this.plotboth) {
if (this.plotfunc1) {
if (this.plot_mode == 4) this.color = 0.2;
if (p$.plottable$edu_davidson_surfaceplotter_SurfaceVertexA.apply(this, [this.values1])) p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.values1, 4]);
} else {
if (this.plot_mode == 4) this.color = 0.7;
if (p$.plottable$edu_davidson_surfaceplotter_SurfaceVertexA.apply(this, [this.values2])) p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.values2, 4]);
}} else {
if (p$.plottable$edu_davidson_surfaceplotter_SurfaceVertexA.apply(this, [this.values1])) {
if (p$.plottable$edu_davidson_surfaceplotter_SurfaceVertexA.apply(this, [this.values2])) p$.splitPlotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$edu_davidson_surfaceplotter_SurfaceVertexA.apply(this, [this.values1, this.values2]);
 else p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.values1, 4]);
} else {
if (p$.plottable$edu_davidson_surfaceplotter_SurfaceVertexA.apply(this, [this.values2])) p$.plotPlane$edu_davidson_surfaceplotter_SurfaceVertexA$I.apply(this, [this.values2, 4]);
}}lx = lx+(sx);
}
ly = ly+(sy);
lx = start_lx;
}
});

Clazz.newMeth(C$, 'plotSurface', function () {
var zi;
var zx;
var sx;
var sy;
var start_lx;
var end_lx;
var start_ly;
var end_ly;
this.image_drawn = false;
try {
zi = this.controller.getZMin();
zx = this.controller.getZMax();
if (zi >= zx ) throw Clazz.new_(Clazz.load('java.lang.NumberFormatException'));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
this.setMessage$S("Error in ranges");
this.rotate = false;
return;
} else {
throw e;
}
}
var plot_density = this.controller.getDispDivisions();
var multiple_factor = (this.calc_divisions/plot_density|0);
this.controller.setDispDivisions$I(plot_density);
this.zmin = zi;
this.zmax = zx;
if (this.rotate) {
this.setMessage$S("rotating ...");
} else {
this.setMessage$S("regenerating ...");
}this.color_factor = 0.8 / (this.zmax - this.zmin);
if (this.plot_mode == 4) this.color_factor *= 0.75;
if (!this.$printing) {
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
this.BufferGC.fillRect$I$I$I$I(0, 0, this.getBounds().width, this.getBounds().height);
}p$.drawBoxGridsTicksLabels$java_awt_Graphics$Z.apply(this, [this.BufferGC, false]);
if (!this.plotfunc1 && !this.plotfunc2 ) {
if (this.isBoxed) p$.drawBoundingBox.apply(this, []);
if (!this.rotate) this.setMessage$S("completed");
this.image_drawn = true;
return;
}this.zmaxV = this.zmax;
this.zminV = this.zmin;
this.zfactorV = 20 / (this.zmaxV - this.zminV);
var distance = this.projector.getDistance() * this.projector.getCosElevationAngle();
this.cop = Clazz.new_((I$[3]||$incl$(3)).c$$F$F$F$edu_davidson_surfaceplotter_SurfaceCanvas,[distance * this.projector.getSinRotationAngle(), distance * this.projector.getCosRotationAngle(), this.projector.getDistance() * this.projector.getSinElevationAngle(), this]);
this.cop.transform();
var inc_x = this.cop.x > 0 ;
var inc_y = this.cop.y > 0 ;
this.critical = false;
if (inc_x) {
start_lx = 0;
end_lx = this.calc_divisions;
sx = multiple_factor;
} else {
start_lx = this.calc_divisions;
end_lx = 0;
sx = -multiple_factor;
}if (inc_y) {
start_ly = 0;
end_ly = this.calc_divisions;
sy = multiple_factor;
} else {
start_ly = this.calc_divisions;
end_ly = 0;
sy = -multiple_factor;
}if ((this.cop.x > 10 ) || (this.cop.x < -10 ) ) {
if ((this.cop.y > 10 ) || (this.cop.y < -10 ) ) {
p$.plotArea$I$I$I$I$I$I.apply(this, [start_lx, start_ly, end_lx, end_ly, sx, sy]);
} else {
var split_y = (((this.cop.y + 10) * plot_density / 20)|0) * multiple_factor;
p$.plotArea$I$I$I$I$I$I.apply(this, [start_lx, 0, end_lx, split_y, sx, multiple_factor]);
p$.plotArea$I$I$I$I$I$I.apply(this, [start_lx, this.calc_divisions, end_lx, split_y, sx, -multiple_factor]);
}} else {
if ((this.cop.y > 10 ) || (this.cop.y < -10 ) ) {
var split_x = (((this.cop.x + 10) * plot_density / 20)|0) * multiple_factor;
p$.plotArea$I$I$I$I$I$I.apply(this, [0, start_ly, split_x, end_ly, multiple_factor, sy]);
p$.plotArea$I$I$I$I$I$I.apply(this, [this.calc_divisions, start_ly, split_x, end_ly, -multiple_factor, sy]);
} else {
var split_x = (((this.cop.x + 10) * plot_density / 20)|0) * multiple_factor;
var split_y = (((this.cop.y + 10) * plot_density / 20)|0) * multiple_factor;
this.critical = true;
p$.plotArea$I$I$I$I$I$I.apply(this, [0, 0, split_x, split_y, multiple_factor, multiple_factor]);
p$.plotArea$I$I$I$I$I$I.apply(this, [0, this.calc_divisions, split_x, split_y, multiple_factor, -multiple_factor]);
p$.plotArea$I$I$I$I$I$I.apply(this, [this.calc_divisions, 0, split_x, split_y, -multiple_factor, multiple_factor]);
p$.plotArea$I$I$I$I$I$I.apply(this, [this.calc_divisions, this.calc_divisions, split_x, split_y, -multiple_factor, -multiple_factor]);
}}if (this.isBoxed) p$.drawBoundingBox.apply(this, []);
if (!this.rotate) this.setMessage$S("completed");
this.image_drawn = true;
});

Clazz.newMeth(C$, 'contourConvertX$F', function (x) {
return Math.round(x * this.contour_width_x + this.contour_center_x);
});

Clazz.newMeth(C$, 'contourConvertY$F', function (y) {
return Math.round(-y * this.contour_width_y + this.contour_center_y);
});

Clazz.newMeth(C$, 'drawBoundingRect', function () {
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).black);
var x1 = p$.contourConvertX$F.apply(this, [-10]);
var y1 = p$.contourConvertY$F.apply(this, [10]);
var x2 = p$.contourConvertX$F.apply(this, [10]);
var y2 = p$.contourConvertY$F.apply(this, [-10]);
this.BufferGC.drawRect$I$I$I$I(x1, y1, x2 - x1, y2 - y1);
if (this.isDisplayXY || this.isDisplayGrids ) {
if (this.isDisplayXY) {
x1 = p$.contourConvertX$F.apply(this, [-10.5]);
y1 = p$.contourConvertY$F.apply(this, [10.5]);
x2 = p$.contourConvertX$F.apply(this, [10.5]);
y2 = p$.contourConvertY$F.apply(this, [-10.5]);
this.BufferGC.drawRect$I$I$I$I(x1, y1, x2 - x1, y2 - y1);
}var xc;
var yc;
var labelindex = 0;
for (var i = -10; i <= 10; i++) {
if (!this.isDisplayGrids || (i % ((this.t_y/2|0)) == 0) || this.isDisplayXY  ) {
yc = p$.contourConvertY$F.apply(this, [i]);
if ((this.isDisplayGrids) && (i % this.t_y == 0) ) {
this.BufferGC.drawLine$I$I$I$I(p$.contourConvertX$F.apply(this, [-10.0]), yc, p$.contourConvertX$F.apply(this, [10.0]), yc);
}if (this.isDisplayXY) {
if (i % this.t_y != 0) {
this.BufferGC.drawLine$I$I$I$I(p$.contourConvertX$F.apply(this, [10.3]), yc, x2, yc);
this.BufferGC.drawLine$I$I$I$I(p$.contourConvertX$F.apply(this, [-10.3]), yc, x1, yc);
} else {
this.BufferGC.drawLine$I$I$I$I(p$.contourConvertX$F.apply(this, [10.0]), yc, x2, yc);
this.BufferGC.drawLine$I$I$I$I(p$.contourConvertX$F.apply(this, [-10.0]), yc, x1, yc);
}}if ((i % this.t_y == 0) && this.isDisplayXY ) {
p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [this.BufferGC, p$.contourConvertX$F.apply(this, [10.7]), yc, this.ylabels[labelindex++], 2, 1]);
}}if (!this.isDisplayGrids || (i % ((this.t_x/2|0)) == 0) || this.isDisplayXY  ) {
xc = p$.contourConvertX$F.apply(this, [i]);
if ((this.isDisplayGrids) && (i % this.t_x == 0) ) {
this.BufferGC.drawLine$I$I$I$I(xc, p$.contourConvertY$F.apply(this, [-10.0]), xc, p$.contourConvertY$F.apply(this, [10.0]));
}if (this.isDisplayXY) {
if (i % this.t_x != 0) {
this.BufferGC.drawLine$I$I$I$I(xc, p$.contourConvertY$F.apply(this, [-10.3]), xc, y2);
this.BufferGC.drawLine$I$I$I$I(xc, p$.contourConvertY$F.apply(this, [10.3]), xc, y1);
} else {
this.BufferGC.drawLine$I$I$I$I(xc, p$.contourConvertY$F.apply(this, [-10.0]), xc, y2);
this.BufferGC.drawLine$I$I$I$I(xc, p$.contourConvertY$F.apply(this, [10.0]), xc, y1);
}}if ((i % this.t_x == 0) && this.isDisplayXY ) {
p$.outFloat$java_awt_Graphics$I$I$F$I$I.apply(this, [this.BufferGC, xc, p$.contourConvertY$F.apply(this, [-10.7]), ((i + 10) / 20 * (this.xmax - this.xmin) + this.xmin), 0, 0]);
}}if (this.isDisplayXY) {
p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [this.BufferGC, ((x1 + x2)/2|0), p$.contourConvertY$F.apply(this, [-11.4]), "X", 0, 0]);
p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [this.BufferGC, p$.contourConvertX$F.apply(this, [10.7]), p$.contourConvertY$F.apply(this, [-1.0]), "Y", 2, 1]);
}}
}if (this.isDisplayZ) {
var lasty = y2;
var height = y2 - y1;
var divisions = this.contour_lines;
x2 = x2+(this.contour_space_x);
x1 = x2 - (this.legend_space + this.legend_width + this.legend_length );
x2 = x2-(this.legend_length);
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).black);
p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [this.BufferGC, x2, y2, this.legend_label[0], 2, 1]);
for (var i = 1; i <= divisions + 1; i++) {
var y = y2 - ((i * height/(divisions + 1)|0));
this.BufferGC.setColor$java_awt_Color(this.contour_color[i - 1]);
this.BufferGC.fillRect$I$I$I$I(x1, y, this.legend_width, lasty - y);
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).black);
this.BufferGC.drawRect$I$I$I$I(x1, y, this.legend_width, lasty - y);
p$.outString$java_awt_Graphics$I$I$S$I$I.apply(this, [this.BufferGC, x2, y, this.legend_label[i], 2, 1]);
lasty = y;
}
}});

Clazz.newMeth(C$, 'cleanUpMemory', function () {
this.legend_label = null;
this.contour_color = null;
this.ylabels = null;
this.accumulator.clearAccumulator();
});

Clazz.newMeth(C$, 'computePlotArea', function () {
p$.setAxesScale.apply(this, []);
this.contour_lines = this.controller.getContourLines();
var ratio = this.projector.getYScaling() / this.projector.getXScaling();
var width = 0.0;
var height = 0.0;
if (this.$printing) {
width = this.printwidth;
height = this.printheight;
} else {
width = this.getBounds().width;
height = this.getBounds().height;
}var fontsize = 0;
if (width < height ) fontsize = ((width / 48)|0);
 else fontsize = ((height / 48)|0);
fontsize = Math.max(fontsize, 10);
if (this.defaultFont == null ) this.BufferGC.setFont$java_awt_Font(Clazz.new_((I$[10]||$incl$(10)).c$$S$I$I,["Helvetica", 0, fontsize]));
 else this.BufferGC.setFont$java_awt_Font(this.defaultFont);
var fm = this.BufferGC.getFontMetrics();
width -= this.gutter;
height -= this.gutter;
var spacex = 0;
var spacey = 0;
if (this.isDisplayXY) {
var labelscount = 0;
var index = 0;
var maxwidth = 0;
for (var i = -10; i < 10; i++) if (i % this.t_y == 0) labelscount++;

this.ylabels = Clazz.array(java.lang.String, [labelscount]);
for (var i = -10; i < 10; i++) {
if (i % this.t_y == 0) {
this.ylabels[index] =  String.instantialize(Float.toString(((i + 10) / 20 * (this.ymax - this.ymin) + this.ymin)));
var strwidth = fm.stringWidth$S(this.ylabels[index++]);
if (strwidth > maxwidth) maxwidth = strwidth;
}}
spacex = spacex+(maxwidth);
spacey = spacey+(fm.getMaxAscent());
}if (this.isDisplayZ) {
if (((this.plot_mode == 0) || (this.plot_mode == 1) ) && this.contour ) this.isDisplayZ = false;
 else {
this.legend_width = ((width * 0.05)|0);
spacex = spacex+(this.legend_width * 2);
this.legend_space = fontsize;
var counts = this.contour_lines;
this.legend_length = 0;
counts = counts+(2);
this.legend_label = Clazz.array(java.lang.String, [counts]);
for (var i = 0; i < counts; i++) {
var label = ((i) / (counts - 1) * (this.zmax - this.zmin) + this.zmin);
this.legend_label[i] =  String.instantialize(Float.toString(label));
var labelwidth = fm.stringWidth$S(this.legend_label[i]);
if (labelwidth > this.legend_length) this.legend_length = labelwidth;
}
spacex = spacex+(this.legend_length + this.legend_space);
}}width -= spacex;
height -= spacey;
this.contour_width_x = width;
this.contour_width_y = width * ratio;
if (this.contour_width_y > height ) {
this.contour_width_y = height;
this.contour_width_x = height / ratio;
}var scaling_factor = 10.0;
if (this.isDisplayXY) scaling_factor = 10.7;
this.contour_width_x = this.contour_width_x / scaling_factor / 2 ;
this.contour_width_y = this.contour_width_y / scaling_factor / 2 ;
this.contour_center_x = 0;
this.contour_center_y = 0;
var x1 = p$.contourConvertX$F.apply(this, [-scaling_factor]);
var y1 = p$.contourConvertY$F.apply(this, [+scaling_factor]);
var x2 = p$.contourConvertX$F.apply(this, [+scaling_factor]) + spacex;
var y2 = p$.contourConvertY$F.apply(this, [-scaling_factor]) + spacey;
this.contour_center_x = ((this.getBounds().width - (x1 + x2))/2|0);
this.contour_center_y = ((this.getBounds().height - (y1 + y2))/2|0);
this.contour_space_x = spacex;
this.setContourColor();
});

Clazz.newMeth(C$, 'setContourColor', function () {
this.contour_color = Clazz.array((I$[8]||$incl$(8)), [this.contour_lines + 1]);
for (var i = 0; i <= this.contour_lines; i++) {
var level = i / this.contour_lines * 0.8;
var r = 0;
var b = 0;
switch (this.plot_mode) {
case 4:
r = ((Math.max(0, -this.contour_lines + i * 2) * 255)/this.contour_lines|0);
b = ((Math.max(0, this.contour_lines - i * 2) * 255)/this.contour_lines|0);
this.contour_color[i] = Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I,[r, 0, b]);
break;
case 2:
level = 0.8 - level;
this.contour_color[i] = (I$[8]||$incl$(8)).getHSBColor$F$F$F(level, 1.0, 1.0);
break;
default:
this.contour_color[i] = (I$[8]||$incl$(8)).getHSBColor$F$F$F(0, 0, level);
break;
}
}
});

Clazz.newMeth(C$, 'createContour', function () {
var z = this.zmin;
var fill = true;
var xmin = this.xpoints[0] = p$.contourConvertX$F.apply(this, [this.contour_vertex[0].x]);
var xmax = this.xpoints[4] = p$.contourConvertX$F.apply(this, [this.contour_vertex[2].x]);
this.ypoints[0] = p$.contourConvertY$F.apply(this, [this.contour_vertex[0].y]);
this.xpoints[2] = p$.contourConvertX$F.apply(this, [this.contour_vertex[1].x]);
this.ypoints[4] = p$.contourConvertY$F.apply(this, [this.contour_vertex[2].y]);
this.xpoints[6] = p$.contourConvertX$F.apply(this, [this.contour_vertex[3].x]);
this.ypoints[2] = this.ypoints[3] = p$.contourConvertY$F.apply(this, [this.contour_vertex[1].y]);
this.ypoints[6] = this.ypoints[7] = p$.contourConvertY$F.apply(this, [this.contour_vertex[3].y]);
this.xpoints[1] = this.xpoints[3] = this.xpoints[5] = this.xpoints[7] = -1;
for (var counter = 0; counter <= this.contour_lines + 1; counter++) {
for (var edge = 0; edge < 4; edge++) {
var index = (edge << 1) + 1;
var nextedge = (edge + 1) & 3;
if (z > this.contour_vertex[edge].z ) {
this.xpoints[index - 1] = -2;
if (z > this.contour_vertex[nextedge].z ) {
this.xpoints[(index + 1) & 7] = -2;
this.xpoints[index] = -2;
}} else if (z > this.contour_vertex[nextedge].z ) this.xpoints[(index + 1) & 7] = -2;
if (this.xpoints[index] != -2) {
if (this.xpoints[index] != -1) {
this.intersection[edge] += this.delta[edge];
if ((index == 1) || (index == 5) ) this.ypoints[index] = p$.contourConvertY$F.apply(this, [this.intersection[edge]]);
 else this.xpoints[index] = p$.contourConvertX$F.apply(this, [this.intersection[edge]]);
} else {
if ((z > this.contour_vertex[edge].z ) || (z > this.contour_vertex[nextedge].z ) ) {
switch (index) {
case 1:
this.delta[edge] = (this.contour_vertex[nextedge].y - this.contour_vertex[edge].y) * this.contour_stepz / (this.contour_vertex[nextedge].z - this.contour_vertex[edge].z);
this.intersection[edge] = (this.contour_vertex[nextedge].y * (z - this.contour_vertex[edge].z) + this.contour_vertex[edge].y * (this.contour_vertex[nextedge].z - z)) / (this.contour_vertex[nextedge].z - this.contour_vertex[edge].z);
this.xpoints[index] = xmin;
this.ypoints[index] = p$.contourConvertY$F.apply(this, [this.intersection[edge]]);
break;
case 3:
this.delta[edge] = (this.contour_vertex[nextedge].x - this.contour_vertex[edge].x) * this.contour_stepz / (this.contour_vertex[nextedge].z - this.contour_vertex[edge].z);
this.intersection[edge] = (this.contour_vertex[nextedge].x * (z - this.contour_vertex[edge].z) + this.contour_vertex[edge].x * (this.contour_vertex[nextedge].z - z)) / (this.contour_vertex[nextedge].z - this.contour_vertex[edge].z);
this.xpoints[index] = p$.contourConvertX$F.apply(this, [this.intersection[edge]]);
break;
case 5:
this.delta[edge] = (this.contour_vertex[edge].y - this.contour_vertex[nextedge].y) * this.contour_stepz / (this.contour_vertex[edge].z - this.contour_vertex[nextedge].z);
this.intersection[edge] = (this.contour_vertex[edge].y * (z - this.contour_vertex[nextedge].z) + this.contour_vertex[nextedge].y * (this.contour_vertex[edge].z - z)) / (this.contour_vertex[edge].z - this.contour_vertex[nextedge].z);
this.xpoints[index] = xmax;
this.ypoints[index] = p$.contourConvertY$F.apply(this, [this.intersection[edge]]);
break;
case 7:
this.delta[edge] = (this.contour_vertex[edge].x - this.contour_vertex[nextedge].x) * this.contour_stepz / (this.contour_vertex[edge].z - this.contour_vertex[nextedge].z);
this.intersection[edge] = (this.contour_vertex[edge].x * (z - this.contour_vertex[nextedge].z) + this.contour_vertex[nextedge].x * (this.contour_vertex[edge].z - z)) / (this.contour_vertex[edge].z - this.contour_vertex[nextedge].z);
this.xpoints[index] = p$.contourConvertX$F.apply(this, [this.intersection[edge]]);
break;
}
}}}}
this.contour_n = 0;
for (var index = 0; index < 8; index++) {
if (this.xpoints[index] >= 0) {
this.contour_x[this.contour_n] = this.xpoints[index];
this.contour_y[this.contour_n] = this.ypoints[index];
this.contour_n++;
}}
if ((this.plot_mode != 0) && (this.plot_mode != 1) ) {
if (counter > this.contour_lines) {
if (this.$printing) this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).white);
 else this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
} else this.BufferGC.setColor$java_awt_Color(this.contour_color[counter]);
this.BufferGC.fillPolygon$IA$IA$I(this.contour_x, this.contour_y, this.contour_n);
}if (this.isMesh || !fill ) {
var x = -1;
var y = -1;
for (var index = 1; index < 8; index = index+(2)) {
if (this.xpoints[index] >= 0) {
if (x != -1) this.accumulator.addLine$I$I$I$I(x, y, this.xpoints[index], this.ypoints[index]);
x = this.xpoints[index];
y = this.ypoints[index];
}}
if ((this.xpoints[1] > 0) && (x != -1) ) this.accumulator.addLine$I$I$I$I(x, y, this.xpoints[1], this.ypoints[1]);
}if (this.contour_n < 3) break;
z += this.contour_stepz;
}
});

Clazz.newMeth(C$, 'plotContour', function () {
var zi;
var zx;
this.image_drawn = false;
this.accumulator.clearAccumulator();
try {
zi = this.controller.getZMin();
zx = this.controller.getZMax();
if (zi >= zx ) throw Clazz.new_(Clazz.load('java.lang.NumberFormatException'));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
this.setMessage$S("Error in ranges");
this.rotate = false;
return;
} else {
throw e;
}
}
this.zmin = zi;
this.zmax = zx;
p$.computePlotArea.apply(this, []);
var plot_density = this.controller.getDispDivisions();
var multiple_factor = (this.calc_divisions/plot_density|0);
this.controller.setDispDivisions$I(plot_density);
this.contour_stepz = (zx - zi) / (this.contour_lines + 1);
this.setMessage$S("regenerating ...");
if (!this.$printing) {
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
this.BufferGC.fillRect$I$I$I$I(0, 0, this.getBounds().width, this.getBounds().height);
}if (this.plotfunc1 || this.plotfunc2 ) {
var index = 0;
var func = 0;
if (!this.plotfunc1) func = 1;
var delta = (this.calc_divisions + 1) * multiple_factor;
for (var i = 0; i < this.calc_divisions; i = i+(multiple_factor)) {
index = i * (this.calc_divisions + 1);
for (var j = 0; j < this.calc_divisions; j = j+(multiple_factor)) {
this.contour_vertex[0] = this.vertex[func][index];
this.contour_vertex[1] = this.vertex[func][index + multiple_factor];
this.contour_vertex[2] = this.vertex[func][index + delta + multiple_factor ];
this.contour_vertex[3] = this.vertex[func][index + delta];
p$.createContour.apply(this, []);
index = index+(multiple_factor);
}
}
}if (this.plot_mode == 4) this.BufferGC.setColor$java_awt_Color(Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I,[0, 64, 0]));
 else this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).black);
this.accumulator.drawAll$java_awt_Graphics(this.BufferGC);
p$.drawBoundingRect.apply(this, []);
this.setMessage$S("completed");
this.image_drawn = true;
});

Clazz.newMeth(C$, 'plotDensity', function () {
var zi;
var zx;
var z;
this.image_drawn = false;
try {
zi = this.controller.getZMin();
zx = this.controller.getZMax();
if (zi >= zx ) throw Clazz.new_(Clazz.load('java.lang.NumberFormatException'));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
this.setMessage$S("Error in ranges");
this.rotate = false;
return;
} else {
throw e;
}
}
this.zmin = zi;
this.zmax = zx;
p$.computePlotArea.apply(this, []);
var plot_density = this.controller.getDispDivisions();
var multiple_factor = (this.calc_divisions/plot_density|0);
this.controller.setDispDivisions$I(plot_density);
this.setMessage$S("regenerating ...");
this.color_factor = 0.8 / (zx - zi);
if (this.plot_mode == 4) this.color_factor *= 0.75;
if (!this.$printing) {
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
this.BufferGC.fillRect$I$I$I$I(0, 0, this.getBounds().width, this.getBounds().height);
}if (this.plotfunc1 || this.plotfunc2 ) {
var index = 0;
var func = 0;
if (!this.plotfunc1) func = 1;
var delta = (this.calc_divisions + 1) * multiple_factor;
for (var i = 0; i < this.calc_divisions; i = i+(multiple_factor)) {
index = i * (this.calc_divisions + 1);
for (var j = 0; j < this.calc_divisions; j = j+(multiple_factor)) {
this.contour_vertex[0] = this.vertex[func][index];
this.contour_vertex[1] = this.vertex[func][index + multiple_factor];
this.contour_vertex[2] = this.vertex[func][index + delta + multiple_factor ];
this.contour_vertex[3] = this.vertex[func][index + delta];
var x = p$.contourConvertX$F.apply(this, [this.contour_vertex[1].x]);
var y = p$.contourConvertY$F.apply(this, [this.contour_vertex[1].y]);
var w = p$.contourConvertX$F.apply(this, [this.contour_vertex[3].x]) - x;
var h = p$.contourConvertY$F.apply(this, [this.contour_vertex[3].y]) - y;
z = 0.0;
var error = false;
for (var loop = 0; loop < 4; loop++) {
if (Float.isNaN(this.contour_vertex[loop].z)) {
error = true;
break;
}z += this.contour_vertex[loop].z;
}
if (error) {
index = index+(multiple_factor);
continue;
}z /= 4;
this.line_color = (I$[8]||$incl$(8)).black;
switch (this.plot_mode) {
case 4:
case 2:
z = 0.8 - (z - zi) * this.color_factor;
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).getHSBColor$F$F$F(z, 1.0, 1.0));
break;
default:
z = (z - zi) * this.color_factor;
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).getHSBColor$F$F$F(0, 0, z));
if (z < 0.3 ) this.line_color = Clazz.new_((I$[8]||$incl$(8)).c$$F$F$F,[0.6, 0.6, 0.6]);
break;
}
this.BufferGC.fillRect$I$I$I$I(x, y, w, h);
if (this.isMesh) {
this.BufferGC.setColor$java_awt_Color(this.line_color);
this.BufferGC.drawRect$I$I$I$I(x, y, w, h);
}index = index+(multiple_factor);
}
}
}p$.drawBoundingRect.apply(this, []);
this.setMessage$S("completed");
this.image_drawn = true;
});

Clazz.newMeth(C$, 'plotWireframe', function () {
var i;
var j;
var k;
var plot_density;
var multiple_factor;
var counter;
var zi;
var zx;
var z;
var lx = 0;
var ly = 0;
var lastz = 0;
var lastproj = Clazz.new_((I$[4]||$incl$(4)).c$$I$I,[0, 0]);
var error;
var lasterror;
var invalid;
this.image_drawn = false;
this.projection = Clazz.new_((I$[4]||$incl$(4)).c$$I$I,[0, 0]);
try {
zi = this.controller.getZMin();
zx = this.controller.getZMax();
if (zi >= zx ) throw Clazz.new_(Clazz.load('java.lang.NumberFormatException'));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
this.setMessage$S("Error in ranges");
this.rotate = false;
return;
} else {
throw e;
}
}
plot_density = this.controller.getDispDivisions();
multiple_factor = (this.calc_divisions/plot_density|0);
this.controller.setDispDivisions$I(plot_density);
this.zmin = zi;
this.zmax = zx;
if (this.rotate) {
this.setMessage$S("rotating ...");
} else {
this.setMessage$S("regenerating ...");
}if (!this.$printing) {
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).lightGray);
this.BufferGC.fillRect$I$I$I$I(0, 0, this.getBounds().width, this.getBounds().height);
}p$.drawBoxGridsTicksLabels$java_awt_Graphics$Z.apply(this, [this.BufferGC, false]);
this.BufferGC.setColor$java_awt_Color((I$[8]||$incl$(8)).black);
this.zmaxV = this.zmax;
this.zminV = this.zmin;
this.zfactorV = 20 / (this.zmaxV - this.zminV);
for (var func = 0; func < 2; func++) {
if ((func == 0) && !this.plotfunc1 ) continue;
if ((func == 1) && !this.plotfunc2 ) continue;
i = 0;
j = 0;
k = 0;
counter = 0;
while (i <= this.calc_divisions){
lasterror = true;
if (counter == 0) {
while (j <= this.calc_divisions){
z = this.vertex[func][k].z;
invalid = Float.isNaN(z);
if (!invalid) {
if (z < this.zmin ) {
error = true;
var ratio = (this.zmin - lastz) / (z - lastz);
this.projection = this.projector.project$F$F$F(ratio * (this.vertex[func][k].x - lx) + lx, ratio * (this.vertex[func][k].y - ly) + ly, -10);
} else if (z > this.zmax ) {
error = true;
var ratio = (this.zmax - lastz) / (z - lastz);
this.projection = this.projector.project$F$F$F(ratio * (this.vertex[func][k].x - lx) + lx, ratio * (this.vertex[func][k].y - ly) + ly, 10);
} else {
error = false;
this.projection = this.vertex[func][k].projection();
}if (lasterror && (!error) && (j != 0)  ) {
if (lastz > this.zmax ) {
var ratio = (this.zmax - z) / (lastz - z);
lastproj = this.projector.project$F$F$F(ratio * (lx - this.vertex[func][k].x) + this.vertex[func][k].x, ratio * (ly - this.vertex[func][k].y) + this.vertex[func][k].y, 10);
} else if (lastz < this.zmin ) {
var ratio = (this.zmin - z) / (lastz - z);
lastproj = this.projector.project$F$F$F(ratio * (lx - this.vertex[func][k].x) + this.vertex[func][k].x, ratio * (ly - this.vertex[func][k].y) + this.vertex[func][k].y, -10);
}} else invalid = error && lasterror ;
} else error = true;
if (!invalid && (j != 0) ) {
this.BufferGC.drawLine$I$I$I$I(lastproj.x, lastproj.y, this.projection.x, this.projection.y);
}lastproj = this.projection;
lasterror = error;
lx = this.vertex[func][k].x;
ly = this.vertex[func][k].y;
lastz = z;
j++;
k++;
}
} else k = k+(this.calc_divisions + 1);
j = 0;
i++;
counter = (counter + 1) % multiple_factor;
}
i = 0;
j = 0;
k = 0;
counter = 0;
while (j <= this.calc_divisions){
lasterror = true;
if (counter == 0) {
while (i <= this.calc_divisions){
z = this.vertex[func][k].z;
invalid = Float.isNaN(z);
if (!invalid) {
if (z < this.zmin ) {
error = true;
var ratio = (this.zmin - lastz) / (z - lastz);
this.projection = this.projector.project$F$F$F(ratio * (this.vertex[func][k].x - lx) + lx, ratio * (this.vertex[func][k].y - ly) + ly, -10);
} else if (z > this.zmax ) {
error = true;
var ratio = (this.zmax - lastz) / (z - lastz);
this.projection = this.projector.project$F$F$F(ratio * (this.vertex[func][k].x - lx) + lx, ratio * (this.vertex[func][k].y - ly) + ly, 10);
} else {
error = false;
this.projection = this.vertex[func][k].projection();
}if (lasterror && (!error) && (i != 0)  ) {
if (lastz > this.zmax ) {
var ratio = (this.zmax - z) / (lastz - z);
lastproj = this.projector.project$F$F$F(ratio * (lx - this.vertex[func][k].x) + this.vertex[func][k].x, ratio * (ly - this.vertex[func][k].y) + this.vertex[func][k].y, 10);
} else if (lastz < this.zmin ) {
var ratio = (this.zmin - z) / (lastz - z);
lastproj = this.projector.project$F$F$F(ratio * (lx - this.vertex[func][k].x) + this.vertex[func][k].x, ratio * (ly - this.vertex[func][k].y) + this.vertex[func][k].y, -10);
}} else invalid = error && lasterror ;
} else error = true;
if (!invalid && (i != 0) ) {
this.BufferGC.drawLine$I$I$I$I(lastproj.x, lastproj.y, this.projection.x, this.projection.y);
}lastproj = this.projection;
lasterror = error;
lx = this.vertex[func][k].x;
ly = this.vertex[func][k].y;
lastz = z;
i++;
k = k+(this.calc_divisions + 1);
}
}i = 0;
k = ++j;
counter = (counter + 1) % multiple_factor;
}
}
if (this.isBoxed) p$.drawBoundingBox.apply(this, []);
if (!this.rotate) this.setMessage$S("completed");
this.image_drawn = true;
});
})();
//Created 2018-02-24 16:21:02
