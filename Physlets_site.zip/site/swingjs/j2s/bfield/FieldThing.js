(function(){var P$=Clazz.newPackage("bfield"),I$=[];
var C$=Clazz.newClass(P$, "FieldThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.p = null;
this.field = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$bfield_FieldPanel', function (p) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [p, 0, 0]);
C$.$init$.apply(this);
this.p = p;
this.field = p.field;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (this.visible) this.field.paint$java_awt_Graphics$java_awt_Rectangle(osg, this.p.fieldBounds);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:05:21
