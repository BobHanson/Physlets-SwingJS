(function(){var P$=Clazz.newPackage("faraday"),I$=[];
var C$=Clazz.newInterface(P$, "Fluxable");
})();
//Created 2018-02-24 16:21:06
