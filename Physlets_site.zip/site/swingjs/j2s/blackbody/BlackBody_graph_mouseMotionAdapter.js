(function(){var P$=Clazz.newPackage("blackbody"),I$=[];
var C$=Clazz.newClass(P$, "BlackBody_graph_mouseMotionAdapter", null, 'java.awt.event.MouseMotionAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$blackbody_BlackBody', function (adaptee) {
Clazz.super_(C$, this,1);
this.adaptee=adaptee;
}, 1);

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
this.adaptee.graph_mouseDragged$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:46 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
