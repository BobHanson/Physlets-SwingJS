(function(){var P$=Clazz.newPackage("bfield"),I$=[['java.awt.Color','edu.davidson.numerics.SRK45','java.lang.Thread','Thread','bfield.ArrowHead','java.util.Vector','edu.davidson.display.Format','bfield.VectorField','edu.davidson.display.SGraph','java.awt.Font','bfield.FieldPanel_mouseMotionAdapter','bfield.FieldPanel_mouseAdapter','bfield.Wire','bfield.Coil','bfield.FieldThing','edu.davidson.tools.SUtil','edu.davidson.graphics.Util','bfield.SketchThing','java.awt.Cursor',['bfield.FieldPanel','.FieldSolver'],'java.util.StringTokenizer','edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FieldPanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.Panel', 'edu.davidson.display.SScalable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.tolerance = 0;
this.fieldSolvers = null;
this.arrowHeads = null;
this.format = null;
this.field = null;
this.fieldBounds = null;
this.graph = null;
this.fieldThing = null;
this.osi = null;
this.message = null;
this.caption = null;
this.wires = null;
this.things = null;
this.f = null;
this.osiInvalid = false;
this.iwidth = 0;
this.iheight = 0;
this.boxWidth = 0;
this.isDrag = false;
this.hotSpot = 0;
this.dragWire = null;
this.dragThing = null;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.showFieldVectors = false;
this.showWires = false;
this.showCoordOnDrag = false;
this.showBOnDrag = false;
this.showFieldLineOnClick = false;
this.showFieldLineOnDoubleClick = false;
this.owner = null;
this.bxStr = null;
this.byStr = null;
this.parserBx = null;
this.parserBy = null;
this.gridSize = 0;
this.autoRefresh = false;
this.sketchMode = false;
this.trailThing = null;
this.sketchImage = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.tolerance = 1.0E-5;
this.fieldSolvers = Clazz.new_((I$[6]||$incl$(6)));
this.arrowHeads = Clazz.new_((I$[6]||$incl$(6)));
this.format = Clazz.new_((I$[7]||$incl$(7)).c$$S,["%-+8.4g"]);
this.field = Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[4, 4]);
this.fieldBounds = null;
this.graph = Clazz.new_((I$[9]||$incl$(9)));
this.fieldThing = null;
this.osi = null;
this.message = null;
this.caption = null;
this.wires = Clazz.new_((I$[6]||$incl$(6)));
this.things = Clazz.new_((I$[6]||$incl$(6)));
this.f = Clazz.new_((I$[10]||$incl$(10)).c$$S$I$I,["Helvetica", 1, 14]);
this.osiInvalid = true;
this.iwidth = 0;
this.iheight = 0;
this.boxWidth = 0;
this.isDrag = false;
this.hotSpot = 0;
this.dragWire = null;
this.dragThing = null;
this.xmin = -1;
this.xmax = 1;
this.ymin = -1;
this.ymax = 1;
this.showFieldVectors = true;
this.showWires = true;
this.showCoordOnDrag = true;
this.showBOnDrag = false;
this.showFieldLineOnClick = false;
this.showFieldLineOnDoubleClick = false;
this.bxStr = "0";
this.byStr = "0";
this.parserBx = null;
this.parserBy = null;
this.gridSize = 32;
this.autoRefresh = true;
this.sketchMode = false;
this.trailThing = null;
this.sketchImage = null;
}, 1);

Clazz.newMeth(C$, 'c$$bfield_BField', function (applet) {
Clazz.super_(C$, this,1);
this.owner = applet;
this.graph.setAutoscaleX$Z(false);
this.graph.setAutoscaleY$Z(false);
this.graph.setMinMaxX$D$D(this.xmin, this.xmax);
this.graph.setMinMaxY$D$D(this.ymin, this.ymax);
this.graph.setShowAxis$Z(false);
this.graph.setDataBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(Clazz.new_((I$[11]||$incl$(11)).c$$bfield_FieldPanel,[this]));
this.addMouseListener$java_awt_event_MouseListener(Clazz.new_((I$[12]||$incl$(12)).c$$bfield_FieldPanel,[this]));
}, 1);

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'getPixWidth', function () {
return this.iwidth;
});

Clazz.newMeth(C$, 'getPixHeight', function () {
return this.iheight;
});

Clazz.newMeth(C$, 'addThing$edu_davidson_display_Thing', function (t) {
this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint();
}});

Clazz.newMeth(C$, 'addWire$D', function (current) {
var x = this.xmin + (this.xmax - this.xmin) * Math.random();
var y = this.ymin + (this.ymax - this.ymin) * Math.random();
var w = this.addWire$D$D$D(x, y, current);
w.setDragable$Z(true);
w.noOptionDrag = false;
return w;
});

Clazz.newMeth(C$, 'addWire$D$D$D', function (x, y, current) {
this.owner.lock.getBusyFlag();
this.stopFieldThreads();
if (this.hasCoils()) {
this.fieldThing = null;
this.wires.removeAllElements();
this.things.removeAllElements();
}var w = Clazz.new_((I$[13]||$incl$(13)).c$$bfield_FieldPanel$D$D$D,[this, x, y, current]);
this.wires.addElement$TE(w);
this.things.addElement$TE(w);
this.owner.lock.freeBusyFlag();
if (this.autoRefresh) {
this.setFields();
this.repaint();
}return w;
});

Clazz.newMeth(C$, 'addCoil$D', function (current) {
var x = this.xmin + (this.xmax - this.xmin) * Math.random();
var y = this.ymin + (this.ymax - this.ymin) * Math.random();
var w = this.addCoil$D$D$D(x, y, current);
w.setDragable$Z(true);
w.noOptionDrag = false;
return w;
});

Clazz.newMeth(C$, 'addCoil$D$D$D', function (x, y, current) {
this.owner.lock.getBusyFlag();
this.stopFieldThreads();
if (this.hasWires()) {
this.fieldThing = null;
this.wires.removeAllElements();
this.things.removeAllElements();
}var w = Clazz.new_((I$[14]||$incl$(14)).c$$bfield_FieldPanel$D$D$D,[this, x, y, current]);
this.wires.addElement$TE(w);
this.things.addElement$TE(w);
this.owner.lock.freeBusyFlag();
if (this.autoRefresh) {
this.setFields();
this.repaint();
}return w;
});

Clazz.newMeth(C$, 'addField', function () {
this.owner.lock.getBusyFlag();
this.stopFieldThreads();
var ft = Clazz.new_((I$[15]||$incl$(15)).c$$bfield_FieldPanel,[this]);
this.fieldThing = ft;
this.things.addElement$TE(ft);
this.owner.lock.freeBusyFlag();
if (this.autoRefresh) {
this.repaint();
}return ft;
});

Clazz.newMeth(C$, 'clearAll', function () {
this.owner.lock.getBusyFlag();
this.stopFieldThreads();
this.fieldThing = null;
this.wires.removeAllElements();
this.things.removeAllElements();
this.arrowHeads.removeAllElements();
this.owner.lock.freeBusyFlag();
if (this.autoRefresh) {
this.setFields();
this.repaint();
}});

Clazz.newMeth(C$, 'setWireXY$bfield_Wire$D$D', function (w, x, y) {
this.owner.lock.getBusyFlag();
this.stopFieldThreads();
w.setXY$D$D(x, y);
this.owner.lock.freeBusyFlag();
this.osiInvalid = true;
if (this.autoRefresh) {
this.setFields();
this.repaint();
}});

Clazz.newMeth(C$, 'invalidateOSI', function () {
this.osiInvalid = true;
});

Clazz.newMeth(C$, 'isInsideDragableThing$I$I', function (x, y) {
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (!t.isNoDrag() && t.isInsideThing$I$I(x, y) ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'hasCoils', function () {
var wire;
var n = this.wires.size();
for (var i = 0; i < n; i++) {
wire = this.wires.elementAt$I(i);
if (Clazz.instanceOf(wire, "bfield.Coil")) return true;
}
return false;
});

Clazz.newMeth(C$, 'hasWires', function () {
var wire;
var n = this.wires.size();
for (var i = 0; i < n; i++) {
wire = this.wires.elementAt$I(i);
if (!(Clazz.instanceOf(wire, "bfield.Coil"))) return true;
}
return false;
});

Clazz.newMeth(C$, 'isInsideAnyWire$D$D', function (x, y) {
var tempNoOpDrag = false;
var tempNoDrag = false;
var wire;
var n = this.wires.size();
for (var i = 0; i < n; i++) {
wire = this.wires.elementAt$I(i);
tempNoDrag = wire.isNoDrag();
tempNoOpDrag = wire.noOptionDrag;
wire.setNoDrag$Z(false);
wire.noOptionDrag = false;
if (!(Clazz.instanceOf(wire, "bfield.Coil")) && wire.isInsideWire$D$D$I(x, y, 0) && wire !== this.dragWire   ) {
wire.setNoDrag$Z(tempNoDrag);
wire.noOptionDrag = tempNoOpDrag;
return true;
} else if ((Clazz.instanceOf(wire, "bfield.Coil")) && (wire.isInsideWire$D$D$I(x, y, -1) || wire.isInsideWire$D$D$I(x, y, 1) ) && wire !== this.dragWire   ) {
wire.setNoDrag$Z(tempNoDrag);
wire.noOptionDrag = tempNoOpDrag;
return true;
}wire.setNoDrag$Z(tempNoDrag);
wire.noOptionDrag = tempNoOpDrag;
}
return false;
});

Clazz.newMeth(C$, 'getThing$I', function (id) {
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (t.hashCode() == id) return t;
}
if (this.trailThing != null  && this.trailThing.hashCode() == id ) return this.trailThing;
return null;
});

Clazz.newMeth(C$, 'getWireFromID$I', function (id) {
for (var i = 0; i < this.wires.size(); i++) {
var w = this.wires.elementAt$I(i);
if (w.getID() == id) return w;
}
return null;
});

Clazz.newMeth(C$, 'getCurl$D$D$bfield_Wire', function (x1, y1, w) {
var del = 1.0E-8;
var dbdx = (this.getBy$D$D$bfield_Wire(x1 + del, y1, w) - this.getBy$D$D$bfield_Wire(x1 - del, y1, w)) / 2 / del ;
var dbdy = (this.getBx$D$D$bfield_Wire(x1, y1 + del, w) - this.getBx$D$D$bfield_Wire(x1, y1 - del, w)) / 2 / del ;
return dbdx - dbdy;
});

Clazz.newMeth(C$, 'getB$D$D$bfield_Wire', function (x1, y1, w) {
var bx = 0;
var by = 0;
var temp = Clazz.array(Double.TYPE, [2]);
if (this.parserBx != null ) bx = this.parserBx.evaluate$D$D(x1, y1);
if (this.parserBy != null ) by = this.parserBy.evaluate$D$D(x1, y1);
if (this.wires == null ) return Clazz.array(Double.TYPE, -1, [bx, by]);
var p;
var n = this.wires.size();
for (var i = 0; i < n; i++) {
p = this.wires.elementAt$I(i);
if (w !== p ) {
temp[0] = x1;
temp[1] = y1;
temp = p.getB$DA(temp);
bx += temp[0];
by += temp[1];
}}
return Clazz.array(Double.TYPE, -1, [bx, by]);
});

Clazz.newMeth(C$, 'getBx$D$D$bfield_Wire', function (x1, y1, w) {
var bx = 0;
if (this.parserBx != null ) bx = this.parserBx.evaluate$D$D(x1, y1);
if (this.wires == null ) return bx;
var p;
var n = this.wires.size();
for (var i = 0; i < n; i++) {
p = this.wires.elementAt$I(i);
if (w !== p ) {
bx += p.getWireBx$D$D(x1, y1);
}}
return bx;
});

Clazz.newMeth(C$, 'getBy$D$D$bfield_Wire', function (x1, y1, w) {
var by = 0;
if (this.parserBy != null ) by = this.parserBy.evaluate$D$D(x1, y1);
if (this.wires == null ) return by;
var p;
var n = this.wires.size();
for (var i = 0; i < n; i++) {
p = this.wires.elementAt$I(i);
if (w !== p ) {
by += p.getWireBy$D$D(x1, y1);
}}
return by;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.getSize().width == 0 || this.getSize().height == 0 ) return;
if (this.osi == null  || this.osiInvalid  || this.iwidth != this.getSize().width  || this.iheight != this.getSize().height ) {
if (this.getSize().width == 0) return;
 else this.paintOSI();
}if (!this.autoRefresh) return;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
this.paintMessage$java_awt_Graphics$S(g, this.message);
var fm = g.getFontMetrics$java_awt_Font(this.f);
if (this.caption != null ) g.drawString$S$I$I(this.caption, ((this.iwidth - fm.stringWidth$S(this.caption))/2|0), 25);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'paintMessage$java_awt_Graphics$S', function (osg, msg) {
if (msg == null ) return;
var fm = osg.getFontMetrics$java_awt_Font(this.f);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).yellow);
var w = 15 + fm.stringWidth$S(msg);
osg.fillRect$I$I$I$I(this.iwidth - w - 5 , this.iheight - 15, w, 15);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
osg.drawString$S$I$I(msg, this.iwidth - w + 2, this.iheight - 3);
});

Clazz.newMeth(C$, 'paintThings$java_awt_Graphics', function (g) {
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
t.paint$java_awt_Graphics(g);
if ((Clazz.instanceOf(t, "bfield.Wire")) && (t).isShowF() ) this.paintForceOnWire$java_awt_Graphics$bfield_Wire(g, t);
}
});

Clazz.newMeth(C$, 'paintArrowHeads$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var ah;
var n = this.arrowHeads.size();
for (var i = 0; i < n; i++) {
ah = this.arrowHeads.elementAt$I(i);
ah.paint$java_awt_Graphics$java_awt_Rectangle(g, r);
}
});

Clazz.newMeth(C$, 'paintForceOnWire$java_awt_Graphics$bfield_Wire', function (g, w) {
var x = w.getX() - w.xo;
var y = w.getY() - w.yo;
var c = w.getCurrent();
var bvec = this.getB$D$D$bfield_Wire(x, y, w);
var bx = bvec[0];
var by = bvec[1];
var x0 = this.pixFromX$D(x);
var y0 = this.pixFromY$D(y);
var x1 = this.pixFromX$D(x - c * by);
var y1 = this.pixFromY$D(y + c * bx);
var oldColor = g.getColor();
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
(I$[16]||$incl$(16)).drawArrow$java_awt_Graphics$I$I$I$I(g, x0, y0, x1, y1);
g.setColor$java_awt_Color(oldColor);
});

Clazz.newMeth(C$, 'paintCoordinates$java_awt_Graphics$D$D', function (g, x, y) {
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
var msg = "";
if (this.showCoordOnDrag) msg = "x=" + this.format.form$D(x) + " y=" + this.format.form$D(y) ;
var infinite = this.isInsideAnyWire$D$D(x, y);
if (this.dragWire != null  && this.dragWire.isShowF() ) {
var bvec = this.getB$D$D$bfield_Wire(x, y, this.dragWire);
var fx = bvec[0];
var fy = bvec[1];
var f = Math.abs(this.dragWire.getCurrent()) * Math.sqrt(fx * fx + fy * fy);
if (infinite) msg = msg + " " + this.owner.label_force_undefined ;
 else msg = msg + " |F|=" + this.format.form$D(f) + "N/m " ;
} else if (this.showBOnDrag) {
var bvec = this.getB$D$D$bfield_Wire(x, y, null);
var bx = bvec[0];
var by = bvec[1];
if ((this.dragWire != null  && !(Clazz.instanceOf(this.dragWire, "bfield.Coil")) ) || infinite ) msg = msg + " " + this.owner.label_field_undefined ;
 else msg = msg + " |B|=" + this.format.form$D(Math.sqrt(bx * bx + by * by)) ;
}g.setColor$java_awt_Color((I$[1]||$incl$(1)).yellow);
g.fillRect$I$I$I$I(0, this.getBounds().height - 15, this.boxWidth, 15);
this.boxWidth = 20 + fm.stringWidth$S(msg);
g.fillRect$I$I$I$I(0, this.getBounds().height - 15, this.boxWidth, 15);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawString$S$I$I(msg, 8, this.getBounds().height - 2);
});

Clazz.newMeth(C$, 'paintOSI', function () {
this.owner.lock.getBusyFlag();
if (this.osi == null  || this.iwidth != this.getSize().width  || this.iheight != this.getSize().height ) {
this.iwidth = this.getSize().width;
this.iheight = this.getSize().height;
if (this.iwidth <= 0 || this.iheight <= 0 ) {
this.owner.lock.freeBusyFlag();
return;
}var osi_temp = this.createImage$I$I(this.iwidth, this.iheight);
this.osi = osi_temp;
this.setXRange$D$D(this.xmin, this.xmax);
this.setFields();
}if (this.osi == null ) {
this.owner.lock.freeBusyFlag();
return;
}var osg = this.osi.getGraphics();
if (osg == null ) {
this.owner.lock.freeBusyFlag();
return;
}osg.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
this.osiInvalid = false;
if (this.graph != null ) {
var r = this.getBounds();
r.x = 0;
r.y = 0;
this.graph.paint$java_awt_Graphics$java_awt_Rectangle(osg, r);
r.width = this.pixFromX$D(this.xFromPix$I(this.iwidth)) - this.pixFromX$D(this.xFromPix$I(0));
r.height = this.pixFromY$D(this.yFromPix$I(this.iheight)) - this.pixFromY$D(this.yFromPix$I(0));
this.fieldBounds = r;
this.paintArrowHeads$java_awt_Graphics$java_awt_Rectangle(osg, r);
if (this.showWires) this.paintThings$java_awt_Graphics(osg);
if (this.showFieldVectors && this.fieldThing == null  ) this.field.paint$java_awt_Graphics$java_awt_Rectangle(osg, r);
} else {
osg.setColor$java_awt_Color(this.getBackground());
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
osg.setColor$java_awt_Color(osg.getColor());
}osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
osg.drawRect$I$I$I$I(0, 0, this.iwidth - 1, this.iheight - 1);
osg.dispose();
this.owner.lock.freeBusyFlag();
return;
});

Clazz.newMeth(C$, 'xFromPix$I', function (pix) {
if (this.graph != null ) return this.graph.xFromPix$I(pix);
 else return pix;
});

Clazz.newMeth(C$, 'pixFromX$D', function (x) {
if (this.graph != null ) return this.graph.pixFromX$D(x);
 else return (Math.round(x)|0);
});

Clazz.newMeth(C$, 'yFromPix$I', function (pix) {
if (this.graph != null ) return this.graph.yFromPix$I(pix);
 else return pix;
});

Clazz.newMeth(C$, 'pixFromY$D', function (y) {
if (this.graph != null ) return this.graph.pixFromY$D(y);
 else return (Math.round(y)|0);
});

Clazz.newMeth(C$, 'wire_Dragged$java_awt_event_MouseEvent$Z', function (e, drawVectors) {
var xpt = e.getX();
if (xpt < 1) xpt = 1;
 else if (xpt > this.iwidth - 2) xpt = this.iwidth - 2;
var ypt = e.getY();
if (ypt < 1) ypt = 1;
 else if (ypt > this.iheight - 2) ypt = this.iheight - 2;
var x = this.xFromPix$I(xpt);
var y = this.yFromPix$I(ypt);
if (this.isDrag) {
var g = this.getGraphics();
if (this.dragWire != null ) {
this.owner.lock.getBusyFlag();
if (this.osi == null ) {
this.osi = this.createImage$I$I(this.iwidth, this.iheight);
}this.osiInvalid = false;
var osg = this.osi.getGraphics();
var r = this.getBounds();
r.x = 0;
r.y = 0;
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
if (this.hotSpot == 0) {
this.dragWire.setXY$D$D(x, y);
this.dragWire.updateMySlaves();
} else if (this.hotSpot == 1) {
this.dragWire.radius = Math.abs(y - this.dragWire.getY());
if (y < this.dragWire.getY() ) {
this.hotSpot = -1;
this.dragWire.current = -this.dragWire.current;
}} else if (this.hotSpot == -1) {
this.dragWire.radius = Math.abs(y - this.dragWire.getY());
if (y > this.dragWire.getY() ) {
this.hotSpot = 1;
this.dragWire.current = -this.dragWire.current;
}}if (drawVectors || (this.fieldThing != null  && this.fieldThing.isVisible() ) ) {
this.setDirectionVectors();
r.width = this.pixFromX$D(this.xFromPix$I(this.iwidth)) - this.pixFromX$D(this.xFromPix$I(0));
r.height = this.pixFromY$D(this.yFromPix$I(this.iheight)) - this.pixFromY$D(this.yFromPix$I(0));
}if (this.showWires) this.paintThings$java_awt_Graphics(osg);
if (drawVectors && this.fieldThing == null  ) {
this.field.paint$java_awt_Graphics$java_awt_Rectangle(osg, r);
}this.dragWire.paintInfo$java_awt_Graphics$I(osg, this.hotSpot);
if (this.dragWire.isShowF()) this.paintForceOnWire$java_awt_Graphics$bfield_Wire(osg, this.dragWire);
osg.dispose();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
this.owner.lock.freeBusyFlag();
if (this.owner != null ) this.owner.updateDataConnections();
}g.setPaintMode();
this.paintCoordinates$java_awt_Graphics$D$D(g, x, y);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawRect$I$I$I$I(0, 0, this.iwidth - 1, this.iheight - 1);
g.dispose();
}});

Clazz.newMeth(C$, 'wire_Moved$D$D', function (x, y) {
var g = this.getGraphics();
this.owner.lock.getBusyFlag();
if (this.osi == null ) {
this.osi = this.createImage$I$I(this.iwidth, this.iheight);
}this.osiInvalid = false;
var osg = this.osi.getGraphics();
var r = this.getBounds();
r.x = 0;
r.y = 0;
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
this.setDirectionVectors();
r.width = this.pixFromX$D(this.xFromPix$I(this.iwidth)) - this.pixFromX$D(this.xFromPix$I(0));
r.height = this.pixFromY$D(this.yFromPix$I(this.iheight)) - this.pixFromY$D(this.yFromPix$I(0));
if (this.showWires) this.paintThings$java_awt_Graphics(osg);
if (this.fieldThing == null ) {
this.field.paint$java_awt_Graphics$java_awt_Rectangle(osg, r);
}osg.dispose();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
this.owner.lock.freeBusyFlag();
g.setPaintMode();
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawRect$I$I$I$I(0, 0, this.iwidth - 1, this.iheight - 1);
this.paintCoordinates$java_awt_Graphics$D$D(g, x, y);
g.dispose();
});

Clazz.newMeth(C$, 'setShowFieldVectors$Z', function (sfv) {
this.showFieldVectors = sfv;
this.osiInvalid = true;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setShowFieldLineOnClick$Z', function (sfl) {
this.showFieldLineOnClick = sfl;
this.showFieldLineOnDoubleClick = false;
});

Clazz.newMeth(C$, 'setShowFieldLineOnDoubleClick$Z', function (sfl) {
this.showFieldLineOnDoubleClick = sfl;
this.showFieldLineOnClick = false;
});

Clazz.newMeth(C$, 'setLabel$I$S', function (id, str) {
var w = this.getWireFromID$I(id);
if (w == null ) return false;
w.setLabel$S(str);
this.osiInvalid = true;
if (this.autoRefresh) this.repaint();
return true;
});

Clazz.newMeth(C$, 'setAutoRefresh$Z', function (ar) {
this.autoRefresh = ar;
});

Clazz.newMeth(C$, 'setColor$I$java_awt_Color', function (id, c) {
var t = this.getThing$I(id);
if (t == null ) return false;
t.setColor$java_awt_Color(c);
this.osiInvalid = true;
if (this.autoRefresh) this.repaint();
return true;
});

Clazz.newMeth(C$, 'setCurrent$I$D', function (id, c) {
var w = this.getWireFromID$I(id);
if (w == null ) return false;
w.setCurrent$D(c);
if (this.autoRefresh) this.setFields();
this.osiInvalid = true;
if (this.autoRefresh) this.repaint();
return true;
});

Clazz.newMeth(C$, 'setRadius$I$D', function (id, r) {
var w = this.getWireFromID$I(id);
if (w == null ) return false;
w.setRadius$D(r);
if (this.autoRefresh) this.setFields();
this.osiInvalid = true;
if (this.autoRefresh) this.repaint();
return true;
});

Clazz.newMeth(C$, 'setDragable$I$Z', function (id, drag) {
var t = this.getThing$I(id);
if (t == null ) return false;
t.setDragable$Z(drag);
return true;
});

Clazz.newMeth(C$, 'setOptionDrag$I$Z', function (id, isDrag) {
var w = this.getWireFromID$I(id);
if (w == null ) return false;
w.noOptionDrag = !isDrag;
return true;
});

Clazz.newMeth(C$, 'setVisibility$I$Z', function (id, v) {
var t = this.getThing$I(id);
if (t == null ) return false;
t.setVisible$Z(v);
this.osiInvalid = true;
if (this.autoRefresh) this.repaint();
return true;
});

Clazz.newMeth(C$, 'setShowForce$I$Z', function (id, showForce) {
var w = this.getWireFromID$I(id);
if (w == null ) return false;
w.setShowF$Z(showForce);
return true;
});

Clazz.newMeth(C$, 'setShowFComponents$I$Z', function (id, sfc) {
var w = this.getWireFromID$I(id);
if (w == null ) return false;
w.setShowFComponents$Z(sfc);
return true;
});

Clazz.newMeth(C$, 'setShowInfo$I$Z', function (id, si) {
var w = this.getWireFromID$I(id);
if (w == null ) return false;
w.showInfo = si;
return true;
});

Clazz.newMeth(C$, 'setShowCoordOnDrag$Z', function (sc) {
this.showCoordOnDrag = sc;
});

Clazz.newMeth(C$, 'setShowBOnDrag$Z', function (sb) {
this.showBOnDrag = sb;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.owner.lock.getBusyFlag();
this.stopFieldThreads();
this.tolerance = 1.0E-5;
this.message = null;
this.showFieldLineOnClick = false;
this.showFieldLineOnDoubleClick = false;
this.showCoordOnDrag = true;
this.showBOnDrag = false;
this.setXRange$D$D(this.xmin, this.xmax);
this.message = null;
this.fieldThing = null;
this.wires.removeAllElements();
this.things.removeAllElements();
this.arrowHeads.removeAllElements();
this.owner.lock.freeBusyFlag();
if (this.autoRefresh) this.setFields();
this.osiInvalid = true;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'reset', function () {
this.owner.lock.getBusyFlag();
this.stopFieldThreads();
this.owner.lock.freeBusyFlag();
if (this.autoRefresh) this.setFields();
this.osiInvalid = true;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setSketchMode$Z', function (sm) {
this.sketchImage = (I$[17]||$incl$(17)).getImage$S$java_applet_Applet("pencil.gif", this.owner);
this.sketchMode = sm;
if (!sm) {
this.trailThing = null;
return 0;
}this.trailThing = Clazz.new_((I$[18]||$incl$(18)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$I,[this.owner, this, 1]);
this.trailThing.setTrailSize$I(2000);
return this.trailThing.hashCode();
});

Clazz.newMeth(C$, 'setGridSize$I', function (gs) {
this.gridSize = gs;
if (this.autoRefresh) this.setFields();
this.osiInvalid = true;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setDirectionVectors', function () {
var x;
var y;
var nx = this.gridSize;
var ny = this.gridSize;
var force = this.field.resize$I$I(ny, nx);
var xmin = this.xFromPix$I(0);
var xmax = this.xFromPix$I(this.iwidth);
var ymin = this.yFromPix$I(this.iheight);
var ymax = this.yFromPix$I(0);
for (var j = 0; j < nx; j++) {
x = (xmax - xmin) * j / (nx - 1) + xmin;
for (var i = 0; i < ny; i++) {
y = (ymax - ymin) * i / (ny - 1) + ymin;
var bvec = this.getB$D$D$bfield_Wire(x, y, null);
var bx = bvec[0];
var by = bvec[1];
var b = Math.sqrt(bx * bx + by * by);
if (b > 0 ) {
force[i][j][0] = bx / b;
force[i][j][1] = by / b;
force[i][j][2] = b;
} else {
force[i][j][0] = 0;
force[i][j][1] = 0;
force[i][j][2] = 0;
}}
}
});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
try {
this.format = Clazz.new_((I$[7]||$incl$(7)).c$$S,[str]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.IllegalArgumentException")){
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'swapZOrder$I$I', function (id1, id2) {
var t1 = this.getThing$I(id1);
var t2 = this.getThing$I(id2);
if (t1 == null  || t2 == null  ) return false;
var index1 = this.things.indexOf$O(t1);
var index2 = this.things.indexOf$O(t2);
this.things.removeElementAt$I(index1);
this.things.insertElementAt$TE$I(t2, index1);
this.things.removeElementAt$I(index2);
this.things.insertElementAt$TE$I(t1, index2);
if (this.autoRefresh) this.repaint();
return true;
});

Clazz.newMeth(C$, 'stopFieldThreads', function () {
var v;
{
v = this.fieldSolvers.clone();
}var fs;
var n = v.size();
for (var i = 0; i < n; i++) {
fs = v.elementAt$I(i);
fs.interrupted = true;
}
this.arrowHeads.removeAllElements();
v = null;
});

Clazz.newMeth(C$, 'setFields', function () {
this.owner.lock.getBusyFlag();
this.stopFieldThreads();
var nx = this.gridSize;
var ny = this.gridSize;
this.graph.deleteAllSeries();
this.arrowHeads.removeAllElements();
var i;
var j;
var x;
var y;
var xmin = this.xFromPix$I(0);
var xmax = this.xFromPix$I(this.iwidth);
var ymin = this.yFromPix$I(this.iheight);
var ymax = this.yFromPix$I(0);
var force = this.field.resize$I$I(ny, nx);
for (j = 0; j < nx; j++) {
x = (xmax - xmin) * j / (nx - 1) + xmin;
for (i = 0; i < ny; i++) {
y = (ymax - ymin) * i / (ny - 1) + ymin;
var bvec = this.getB$D$D$bfield_Wire(x, y, null);
var fx = bvec[0];
var fy = bvec[1];
var mag = Math.sqrt(fx * fx + fy * fy);
if (mag > 0 ) {
force[i][j][0] = fx / mag;
force[i][j][1] = fy / mag;
force[i][j][2] = mag;
} else {
force[i][j][0] = 0;
force[i][j][1] = 0;
force[i][j][2] = 0;
}}
}
this.osiInvalid = true;
this.owner.lock.freeBusyFlag();
});

Clazz.newMeth(C$, 'setXRange$D$D', function (min, max) {
if (max == min ) {
this.xmin = min - 0.5;
this.xmax = max + 0.5;
} else if (max > min ) {
this.xmin = min;
this.xmax = max;
} else {
this.xmin = max;
this.xmax = min;
}if (this.iwidth == 0) return;
var scale = (this.xmax - this.xmin) / this.iwidth;
this.ymin = (this.ymax + this.ymin) / 2 - scale * this.iheight / 2.0;
this.ymax = this.ymin + scale * this.iheight;
this.graph.setMinMaxX$D$D(this.xmin, this.xmax);
this.graph.setMinMaxY$D$D(this.ymin, this.ymax);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'this_mouseMoved$java_awt_event_MouseEvent', function (e) {
if (this.isInsideDragableThing$I$I(e.getX(), e.getY())) this.setCursor$java_awt_Cursor((I$[19]||$incl$(19)).getPredefinedCursor$I(12));
 else if (this.sketchMode) this.setCursor$java_awt_Cursor((I$[19]||$incl$(19)).getPredefinedCursor$I(13));
 else this.setCursor$java_awt_Cursor((I$[19]||$incl$(19)).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.boxWidth = 0;
var xpt = e.getX();
if (xpt < 1) xpt = 1;
 else if (xpt > this.iwidth - 2) xpt = this.iwidth - 2;
var ypt = e.getY();
if (ypt < 1) ypt = 1;
 else if (ypt > this.iheight - 2) ypt = this.iheight - 2;
var x = this.xFromPix$I(xpt);
var y = this.yFromPix$I(ypt);
if (this.dragWire != null ) {
if (this.hotSpot == 0) {
this.dragWire.setXY$D$D(x, y);
this.dragWire.updateMySlaves();
} else if (this.hotSpot == 1) {
this.dragWire.radius = Math.abs(y - this.dragWire.getY());
if (y < this.dragWire.getY() ) {
this.hotSpot = -1;
this.dragWire.current = -this.dragWire.current;
}} else if (this.hotSpot == -1) {
this.dragWire.radius = Math.abs(y - this.dragWire.getY());
if (y > this.dragWire.getY() ) {
this.hotSpot = 1;
this.dragWire.current = -this.dragWire.current;
}}this.setFields();
if (this.owner != null ) this.owner.updateDataConnections();
} else if (this.dragThing != null ) {
if (this.containsWires$edu_davidson_display_Thing(this.dragThing)) {
this.setFields();
}this.dragThing.setXY$D$D(x, y);
this.dragThing.updateMySlaves();
this.osiInvalid = true;
if (this.owner != null ) this.owner.updateDataConnections();
}this.isDrag = false;
this.dragWire = null;
this.dragThing = null;
this.hotSpot = 0;
if (this.sketchMode && this.trailThing != null  ) {
var dataset = this.trailThing.getDataSet();
this.graph.attachDataSet$edu_davidson_graph_DataSet(dataset);
this.graph.xaxis.attachDataSet$edu_davidson_graph_DataSet(dataset);
this.graph.yaxis.attachDataSet$edu_davidson_graph_DataSet(dataset);
this.osiInvalid = true;
}this.this_mouseMoved$java_awt_event_MouseEvent(e);
this.repaint();
});

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
var xpt = e.getX();
var ypt = e.getY();
var x = this.xFromPix$I(xpt);
var y = this.yFromPix$I(ypt);
if (this.showFieldLineOnClick || (e.getClickCount() == 2 && this.showFieldLineOnDoubleClick ) ) {
Clazz.new_((I$[20]||$incl$(20)).c$$D$D$Z, [this, null, x, y, true]);
return;
}this.isDrag = true;
this.dragWire = null;
this.dragThing = null;
for (var enumThing = this.things.elements(); enumThing.hasMoreElements(); ) {
var t = enumThing.nextElement();
if (!t.isNoDrag() && t.isInsideThing$I$I(xpt, ypt) ) {
this.dragThing = t;
}}
if (Clazz.instanceOf(this.dragThing, "bfield.Wire")) this.dragWire = this.dragThing;
if (this.dragWire != null ) {
this.hotSpot = this.dragWire.getHotSpot$I$I(xpt, ypt);
if (this.hotSpot == 0) {
this.dragWire.setXY$D$D(x, y);
this.dragWire.updateMySlaves();
} else if (this.hotSpot == 1) {
this.dragWire.radius = Math.abs(y - this.dragWire.getY());
if (y < this.dragWire.getY() ) {
this.hotSpot = -1;
this.dragWire.current = -this.dragWire.current;
}} else if (this.hotSpot == -1) {
this.dragWire.radius = Math.abs(y - this.dragWire.getY());
if (y > this.dragWire.getY() ) {
this.hotSpot = 1;
this.dragWire.current = -this.dragWire.current;
}}if (this.owner != null ) this.owner.updateDataConnections();
} else if (this.dragThing != null ) {
this.dragThing.setXY$D$D(x, y);
this.dragThing.updateMySlaves();
if (this.owner != null ) this.owner.updateDataConnections();
}this.paintOSI();
var g = this.getGraphics();
this.paint$java_awt_Graphics(g);
this.paintCoordinates$java_awt_Graphics$D$D(g, x, y);
g.dispose();
if (this.sketchMode && this.trailThing != null  ) {
this.trailThing.clearTrail();
this.owner.clearData$I(this.trailThing.hashCode());
this.setCursor$java_awt_Cursor((I$[19]||$incl$(19)).getPredefinedCursor$I(1));
this.this_mouseDragged$java_awt_event_MouseEvent(e);
}});

Clazz.newMeth(C$, 'this_mouseDragged$java_awt_event_MouseEvent', function (e) {
if (this.dragWire != null ) {
this.wire_Dragged$java_awt_event_MouseEvent$Z(e, this.showFieldVectors);
return;
}var xpt = e.getX();
if (xpt < 1) xpt = 1;
 else if (xpt > this.iwidth - 2) xpt = this.iwidth - 2;
var ypt = e.getY();
if (ypt < 1) ypt = 1;
 else if (ypt > this.iheight - 2) ypt = this.iheight - 2;
var x = this.xFromPix$I(xpt);
var y = this.yFromPix$I(ypt);
var g = null;
if (this.isDrag && !this.sketchMode ) {
if (this.dragThing != null ) {
this.dragThing.setXY$D$D(x, y);
this.dragThing.updateMySlaves();
this.owner.updateDataConnection$I(this.dragThing.hashCode());
}if (this.dragThing != null  && p$.containsWires$edu_davidson_display_Thing.apply(this, [this.dragThing]) ) {
this.wire_Moved$D$D(x, y);
return;
}this.paintOSI();
g = this.getGraphics();
this.paint$java_awt_Graphics(g);
this.paintCoordinates$java_awt_Graphics$D$D(g, x, y);
g.dispose();
}if (this.sketchMode && this.trailThing != null  ) {
g = this.getGraphics();
this.trailThing.incTrail$D$D(x, y);
g = this.getGraphics();
this.paint$java_awt_Graphics(g);
this.trailThing.paint$java_awt_Graphics(g);
this.paintCoordinates$java_awt_Graphics$D$D(g, x, y);
if (this.sketchImage != null ) g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.sketchImage, xpt, ypt - this.sketchImage.getHeight$java_awt_image_ImageObserver(this), this);
g.dispose();
this.owner.updateDataConnection$I(this.trailThing.hashCode());
}});

Clazz.newMeth(C$, 'containsWires$edu_davidson_display_Thing', function (thing) {
if (thing == null ) return false;
var slaves = thing.getSlaves();
if (slaves == null ) return false;
var slave = null;
for (var e = slaves.elements(); e.hasMoreElements(); ) {
slave = e.nextElement();
if (Clazz.instanceOf(slave, "bfield.Wire")) return true;
}
return false;
});

Clazz.newMeth(C$, 'setRange$S', function (rs) {
var error = false;
var range = Clazz.array(Double.TYPE, [4]);
var tokens = Clazz.new_((I$[21]||$incl$(21)).c$$S$S,[rs.trim(), ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
if (tokens.countTokens() < 4) error = true;
 else for (var i = 0; i < 4; i++) {
try {
range[i] = Double.$valueOf(tokens.nextToken().trim()).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
System.out.println$S("Error setting range:" + rs);
error = true;
} else {
throw e;
}
}
}
if (!error) {
this.xmin = range[0];
this.xmax = range[1];
this.ymin = range[2];
this.ymax = range[3];
} else {
return false;
}return true;
});

Clazz.newMeth(C$, 'parseBx$S', function (s) {
this.bxStr = s.trim();
if (this.bxStr.equals$O("") || this.bxStr.equals$O("0") ) {
this.parserBx = null;
return true;
}this.parserBx = Clazz.new_((I$[22]||$incl$(22)).c$$I,[2]);
this.parserBx.defineVariable$I$S(1, "x");
this.parserBx.defineVariable$I$S(2, "y");
this.parserBx.define$S(this.bxStr);
this.parserBx.parse();
if (this.parserBx.getErrorCode() != 0) {
System.out.println$S("Failed to parse Bx(x,y): " + this.bxStr);
System.out.println$S("Parse error: " + this.parserBx.getErrorString() + " at function 1, position " + this.parserBx.getErrorPosition() );
return false;
} else return true;
});

Clazz.newMeth(C$, 'parseBy$S', function (s) {
this.byStr = s.trim();
if (this.byStr.equals$O("") || this.byStr.equals$O("0") ) {
this.parserBy = null;
return true;
}this.parserBy = Clazz.new_((I$[22]||$incl$(22)).c$$I,[2]);
this.parserBy.defineVariable$I$S(1, "x");
this.parserBy.defineVariable$I$S(2, "y");
this.parserBy.define$S(this.byStr);
this.parserBy.parse();
if (this.parserBy.getErrorCode() != 0) {
System.out.println$S("Failed to parse By(x,y): " + this.byStr);
System.out.println$S("Parse error: " + this.parserBy.getErrorString() + " at function 1, position " + this.parserBy.getErrorPosition() );
return false;
} else return true;
});

Clazz.newMeth(C$, 'setBFunctions$S$S', function (bx, by) {
this.owner.lock.getBusyFlag();
if (p$.parseBx$S.apply(this, [bx]) && p$.parseBy$S.apply(this, [by]) ) {
if (this.autoRefresh) {
this.setFields();
this.repaint();
}this.owner.lock.freeBusyFlag();
return true;
}this.owner.lock.freeBusyFlag();
return false;
});

Clazz.newMeth(C$, 'setBFunctions$S$S$D$D$D$D', function (bx, by, x1, x2, y1, y2) {
this.xmin = x1;
this.xmax = x2;
this.ymin = y1;
this.ymax = y2;
return this.setBFunctions$S$S(bx, by);
});
;
(function(){var C$=Clazz.newClass(P$.FieldPanel, "FieldSolver", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, ['Runnable', 'edu.davidson.numerics.SDifferentiable']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fieldColor = null;
this.odeSolver = null;
this.fieldThread = null;
this.fieldLine = null;
this.plus = false;
this.keepRunning = false;
this.outOfBounds = false;
this.interrupted = false;
this.data = null;
this.np = 0;
this.maxPts = 0;
this.points = null;
this.scale = 0;
this.dydx = null;
this.res = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.fieldColor = (I$[1]||$incl$(1)).black;
this.odeSolver = Clazz.new_((I$[2]||$incl$(2)));
this.fieldThread = null;
this.fieldLine = Clazz.array(Double.TYPE, [2]);
this.plus = true;
this.keepRunning = true;
this.outOfBounds = false;
this.interrupted = false;
this.np = 0;
this.maxPts = 150;
this.points = Clazz.array(Double.TYPE, [2 * this.maxPts]);
this.scale = 1;
this.dydx = Clazz.array(Double.TYPE, [2]);
this.res = 0;
}, 1);

Clazz.newMeth(C$, 'c$$D$D$Z', function (x, y, p) {
C$.$init$.apply(this);
this.plus = p;
this.fieldLine[0] = x;
this.fieldLine[1] = y;
this.points[this.np] = x;
this.points[this.np + 1] = y;
this.np = this.np + 2;
this.odeSolver.setDifferentials$edu_davidson_numerics_SDifferentiable(this);
this.odeSolver.setTol$D(this.this$0.tolerance);
if (this.fieldThread == null ) {
this.fieldThread = Clazz.new_((I$[3]||$incl$(3)).c$$Runnable,[this]);
this.fieldThread.start();
}this.this$0.fieldSolvers.addElement$TE(this);
this.res = this.this$0.graph.xFromPix$I(3) - this.this$0.graph.xFromPix$I(0);
}, 1);

Clazz.newMeth(C$, 'getNumEqu', function () {
return 2;
});

Clazz.newMeth(C$, 'rate$DA', function (x) {
var bvec = this.this$0.getB$D$D$bfield_Wire(x[0], x[1], null);
var fx = bvec[0];
var fy = bvec[1];
var f = Math.sqrt(fx * fx + fy * fy);
if (!this.plus) {
fy = -fy;
fx = -fx;
}if (f <= 0 ) {
this.dydx[0] = 0;
this.dydx[1] = 0;
this.keepRunning = false;
} else {
this.dydx[0] = this.scale * fx / f;
this.dydx[1] = this.scale * fy / f;
}return this.dydx;
});

Clazz.newMeth(C$, 'stepField', function () {
var ds = (this.this$0.xmax - this.this$0.xmin) / 25.0;
this.odeSolver.setH$D(ds);
this.odeSolver.stepRK45$DA(this.fieldLine);
var x1 = this.this$0.pixFromX$D(this.fieldLine[0]);
var y1 = this.this$0.pixFromY$D(this.fieldLine[1]);
if (this.np < this.maxPts * 2) {
this.points[this.np] = this.fieldLine[0];
this.points[this.np + 1] = this.fieldLine[1];
this.np = this.np + 2;
}if ((x1 < -30 || y1 < -30  || x1 > this.this$0.iwidth + 30  || y1 > this.this$0.iheight + 30 )) {
this.outOfBounds = true;
return false;
}if (this.np > 4 && this.insideBox$D$D$D$D$D$D(this.fieldLine[0], this.fieldLine[1], this.points[0], this.points[1], this.points[2], this.points[3]) ) {
this.outOfBounds = false;
return false;
}return true;
});

Clazz.newMeth(C$, 'insideBox$D$D$D$D$D$D', function (x, y, x0, y0, x1, y1) {
var temp;
if (x0 > x1 ) {
temp = x1;
x1 = x0;
x0 = temp;
}if (y0 > y1 ) {
temp = y1;
y1 = y0;
y0 = temp;
}if (x >= x0 - this.res  && x <= x1 + this.res   && y >= y0 - this.res   && y <= y1 + this.res  ) return true;
 else return false;
});

Clazz.newMeth(C$, 'run', function () {
var count = 0;
this.keepRunning = true;
while (this.keepRunning && !this.interrupted ){
try {
while (this.this$0.osi == null ){
(I$[4]||$incl$(4)).sleep$J(50);
}
if (!this.interrupted) this.keepRunning = this.stepField();
if (!this.interrupted) (I$[4]||$incl$(4)).sleep$J(20);
count++;
if (count >= this.maxPts) {
this.keepRunning = false;
this.outOfBounds = true;
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
}
this.this$0.fieldSolvers.removeElement$O(this);
if (this.interrupted) {
this.fieldThread.stop();
this.fieldThread = null;
return;
}this.this$0.owner.lock.getBusyFlag();
this.data = this.this$0.graph.addDataSet$DA$I(this.points, count);
this.data.linecolor = this.fieldColor;
this.this$0.owner.lock.freeBusyFlag();
var index = 0;
var x = this.points[index * 2];
var y = this.points[index * 2 + 1];
var bvec = this.this$0.getB$D$D$bfield_Wire(x, y, null);
var bx = bvec[0];
var by = bvec[1];
var b = Math.sqrt(bx * bx + by * by);
this.this$0.arrowHeads.addElement$TE(Clazz.new_((I$[5]||$incl$(5)).c$$bfield_FieldPanel$D$D$D$D$java_awt_Color,[this.this$0, x, y, bx / b, by / b, this.fieldColor]));
index = (count/2|0);
if (index > 20) {
x = this.points[index * 2];
y = this.points[index * 2 + 1];
if (x > this.this$0.xmin  && x < this.this$0.xmax   && y > this.this$0.ymin   && y < this.this$0.ymax  ) {
bvec = this.this$0.getB$D$D$bfield_Wire(x, y, null);
bx = bvec[0];
by = bvec[1];
b = Math.sqrt(bx * bx + by * by);
this.this$0.arrowHeads.addElement$TE(Clazz.new_((I$[5]||$incl$(5)).c$$bfield_FieldPanel$D$D$D$D$java_awt_Color,[this.this$0, x, y, bx / b, by / b, this.fieldColor]));
}}this.this$0.osiInvalid = true;
this.this$0.repaint();
if (this.plus && this.outOfBounds && this.points != null   ) Clazz.new_(C$.c$$D$D$Z, [this, null, this.points[0], this.points[1], false]);
this.points = null;
this.fieldThread.stop();
this.fieldThread = null;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:41:42
