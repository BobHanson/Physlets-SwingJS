(function(){var P$=Clazz.newPackage("bfield"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VectorField");
C$.halfWidth = 0;
C$.saturation = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.halfWidth = 175;
C$.saturation = Clazz.array(Integer.TYPE, [C$.halfWidth * 2]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.field = null;
this.row = 0;
this.col = 0;
this.scale = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.row = 0;
this.col = 0;
this.scale = 1.0;
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (r, c) {
C$.$init$.apply(this);
this.field = Clazz.array(Double.TYPE, [r, c, 3]);
C$.calSaturation();
this.row = r;
this.col = c;
}, 1);

Clazz.newMeth(C$, 'calSaturation', function () {
var w = C$.halfWidth * 2;
for (var i = 0; i < w; i++) {
var arg = 1.4 * (i - C$.halfWidth) / C$.halfWidth;
C$.saturation[i] = ((255 * Math.exp(-arg * arg))|0);
;}
}, 1);

Clazz.newMeth(C$, 'resize$I$I', function (r, c) {
if ((r == this.row) && (c == this.col) ) return this.field;
this.field = Clazz.array(Double.TYPE, [r, c, 3]);
this.row = r;
this.col = c;
return this.field;
});

Clazz.newMeth(C$, 'setGridValue$I$I$D$D$D', function (r, c, fx, fy, mag) {
this.field[r][c][0] = fx;
this.field[r][c][1] = fy;
this.field[r][c][2] = mag;
});

Clazz.newMeth(C$, 'getColor$D', function (x) {
var r = 0;
var g = 0;
var b = 0;
var index = ((100 * x)|0);
if (index > 100 - C$.halfWidth && index < 100 + C$.halfWidth ) {
b = C$.saturation[index - 100 + C$.halfWidth];
}if (index > 275 - C$.halfWidth && index < 275 + C$.halfWidth ) {
g = C$.saturation[index - 275 + C$.halfWidth];
}if (index > 450 - C$.halfWidth && index < 450 + C$.halfWidth ) {
r = C$.saturation[index - 450 + C$.halfWidth];
}return Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, 'colorFromMag$D', function (m) {
var rv;
var gv;
var bv;
m *= this.scale;
if (m > 1 ) {
return p$.getColor$D.apply(this, [m]);
} else {
rv = ((255 * (1 - m))|0);
gv = ((255 * (1 - m))|0);
bv = 255;
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[rv, gv, bv]);
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var i;
var j;
var x1;
var y1;
var x2;
var y2;
var x;
var y;
var dx;
var dy;
var h;
var temp;
var fx;
var fy;
var mag;
var w = 2;
dx = r.width / (this.col - 1);
dy = r.height / (this.row - 1);
h = (0.7 * dx);
for (i = 0; i < this.row; i++) {
y1 = r.height - ((i * dy)|0);
temp = y1;
for (j = 0; j < this.col; j++) {
x1 = ((j * dx)|0);
fx = this.field[i][j][0];
fy = this.field[i][j][1];
mag = this.field[i][j][2];
g.setColor$java_awt_Color(p$.colorFromMag$D.apply(this, [mag]));
x = h * fx;
y = -h * fy;
x2 = ((x1 + x / 2)|0);
y2 = ((y1 + y / 2)|0);
x1 = ((x2 - x)|0);
y1 = ((y2 - y)|0);
g.drawLine$I$I$I$I(x1, y1, x2, y2);
var u = w * fx;
var v = -w * fy;
var base_x = x2 - 3 * u;
var base_y = y2 - 3 * v;
g.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x2, y2);
g.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x2, y2);
y1 = temp;
}
}
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:36:55
