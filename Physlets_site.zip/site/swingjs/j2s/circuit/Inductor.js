(function(){var P$=Clazz.newPackage("circuit"),I$=[[0,'java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Inductor", null, 'circuit.Part');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I', function (o, c, i1, j1, i2, j2) {
C$.superclazz.c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I.apply(this, [o, c, i1, j1, i2, j2]);
C$.$init$.apply(this);
this.label="L";
this.voltRMS=0;
this.res=0;
this.ind=1.0;
this.showV=true;
this.showL=true;
this.showZ=false;
this.showR=false;
}, 1);

Clazz.newMeth(C$, 'drawLabel$java_awt_Graphics$I$I$I$I', function (g, x, y, xOff, yOff) {
if (this.label == null ) return;
var oldFont=g.getFont$();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color(Clazz.load('java.awt.Color').black);
if (this.i1 == this.i2) g.drawString$S$I$I(this.label, x - 4, y - 8);
 else if (this.j1 == this.j2) g.drawString$S$I$I(this.label, x - 18, y + 5);
 else g.drawString$S$I$I(this.label, x, y);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'drawSymbol$java_awt_Graphics$I$I$I$I$I', function (g, xx1, yy1, xx2, yy2, s) {
g.setColor$java_awt_Color(this.color);
var x=xx2 - xx1;
var y=-(yy2 - yy1);
var h=Math.sqrt(x * x + y * y);
if (h < 2 ) return;
var w=(h / 2.0 - s / 4.0);
var base_x1=((xx1 + (x * w) / h)|0);
var base_y1=((yy1 - (y * w) / h)|0);
var base_x2=((xx2 - (x * w) / h)|0);
var base_y2=((yy2 + (y * w) / h)|0);
g.drawLine$I$I$I$I(xx1, yy1, base_x1, base_y1);
g.drawLine$I$I$I$I(xx2, yy2, base_x2, base_y2);
var x1;
var y1;
var x2;
var y2;
if (this.i1 * this.i1 + this.j1 * this.j1 < this.i2 * this.i2 + this.j2 * this.j2) {
x1=base_x1;
y1=base_y1;
x2=base_x2;
y2=base_y2;
} else {
x2=base_x1;
y2=base_y1;
x1=base_x2;
y1=base_y2;
}x=x2 - x1;
y=-(y2 - y1);
h=Math.sqrt(x * x + y * y);
var u=(x / 16.0);
var v=-(y / 16.0);
var u0=8 * x / h;
var v0=-8 * y / h;
x2=((x1 + u)|0);
y2=((y1 + v)|0);
var x3=(x1 + 2 * u);
var y3=(y1 + 2 * v);
var start=0;
var end=180;
var xoffset=0;
var yoffset=0;
if (this.i1 == this.i2) {
start=0;
yoffset=-h / 4 + 1;
} else if (this.j1 == this.j2) start=90;
 else {
start=90 + ((360 * Math.atan2(u0, v0) / 2 / 3.141592653589793)|0);
xoffset=-h / 16 + 1;
yoffset=-h / 8 + 1;
}for (var count=0; count < 4; count++) {
x2=((x2 - v0)|0);
y2=((y2 + u0)|0);
g.drawArc$I$I$I$I$I$I((((x1 + x2) / 2 - xoffset)|0), (((y1 + y2) / 2 + yoffset)|0), ((h / 4)|0), ((h / 4)|0), start, end);
x1=x3;
y1=y3;
x2=x1 + u;
y2=y1 + v;
x3=x1 + 2 * u;
y3=y1 + 2 * v;
x2=x2 + v0;
y2=y2 - u0;
x1=x3;
y1=y3;
x2=x1 + u;
y2=y1 + v;
x3=x1 + 2 * u;
y3=y1 + 2 * v;
}
var oldFont=g.getFont$();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color($I$(1).black);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:14 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
