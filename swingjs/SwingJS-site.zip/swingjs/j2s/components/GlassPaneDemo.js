(function(){var P$=Clazz.newPackage("components"),p$1={},I$=[[0,'javax.swing.JFrame','javax.swing.JCheckBox','java.awt.FlowLayout','javax.swing.JButton','javax.swing.JMenuBar','javax.swing.JMenu','javax.swing.JMenuItem','test.components.GlassPaneDemo','test.components.MyGlassPane','javax.swing.SwingUtilities','java.awt.Color','test.components.CBListener','java.awt.Toolkit','java.awt.event.MouseEvent']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GlassPaneDemo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['myGlassPane','test.components.MyGlassPane']]]

Clazz.newMeth(C$, 'createAndShowGUI$', function () {
var frame=Clazz.new_($I$(1,1).c$$S,["GlassPaneDemo"]);
frame.setDefaultCloseOperation$I(3);
var changeButton=Clazz.new_($I$(2,1).c$$S,["Glass pane \"visible\""]);
changeButton.setSelected$Z(false);
var contentPane=frame.getContentPane$();
contentPane.setLayout$java_awt_LayoutManager(Clazz.new_($I$(3,1)));
contentPane.add$java_awt_Component(changeButton);
contentPane.add$java_awt_Component(Clazz.new_($I$(4,1).c$$S,["Button 1"]));
contentPane.add$java_awt_Component(Clazz.new_($I$(4,1).c$$S,["Button 2"]));
var menuBar=Clazz.new_($I$(5,1));
var menu=Clazz.new_($I$(6,1).c$$S,["Menu"]);
menu.add$javax_swing_JMenuItem(Clazz.new_($I$(7,1).c$$S,["Do nothing"]));
menuBar.add$javax_swing_JMenu(menu);
frame.setJMenuBar$javax_swing_JMenuBar(menuBar);
$I$(8).myGlassPane=Clazz.new_([changeButton, menuBar, frame.getContentPane$()],$I$(9,1).c$$javax_swing_AbstractButton$javax_swing_JMenuBar$java_awt_Container);
changeButton.addItemListener$java_awt_event_ItemListener($I$(8).myGlassPane);
frame.setGlassPane$java_awt_Component($I$(8).myGlassPane);
frame.pack$();
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'main$SA', function (args) {
$I$(10,"invokeLater$Runnable",[((P$.test.components.GlassPaneDemo$3711||
(function(){/*a*/var C$=Clazz.newClass(P$, "test.components.GlassPaneDemo$3711", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$', function () {
$I$(8).createAndShowGUI$();
});
})()
), Clazz.new_(test.components.GlassPaneDemo$3711.$init$,[this, null]))]);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-16 19:32:09 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
