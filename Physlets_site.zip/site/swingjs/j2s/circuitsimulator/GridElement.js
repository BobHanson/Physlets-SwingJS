(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "GridElement");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.vIndex=0;
this.nOfUntreatedCons=0;
this.bpIndex=0;
this.vEquation=null;
this.branchPoint=null;
this.connection=null;
this.defined=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.connection=Clazz.array(Clazz.load('circuitsimulator.CircuitElement'), [4]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.vIndex=0;
this.bpIndex=0;
this.nOfUntreatedCons=0;
this.defined=false;
this.vEquation=null;
this.branchPoint=null;
}, 1);

Clazz.newMeth(C$, 'connected$circuitsimulator_VEquation', function (veq) {
this.vEquation=veq;
this.defined=true;
});

Clazz.newMeth(C$, 'connected$circuitsimulator_BranchPoint', function (bp) {
this.branchPoint=bp;
});

Clazz.newMeth(C$, 'getVIndex$', function () {
var v=-1;
if (this.vEquation != null ) v=this.vEquation.indexV1;
return v;
});

Clazz.newMeth(C$, 'numberOfCons$', function () {
var n=0;
for (var i=0; i < 4; i++) if (this.connection[i] != null ) n++;

return n;
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:15 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
