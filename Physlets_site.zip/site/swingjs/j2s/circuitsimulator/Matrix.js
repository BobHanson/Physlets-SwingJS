(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['java.lang.StringBuffer']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Matrix");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.rows = 0;
this.cols = 0;
this.data = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (r, c) {
C$.$init$.apply(this);
this.data = Clazz.array(Double.TYPE, [r, c]);
this.rows = r;
this.cols = c;
for (var i = 0; i < this.rows; i++) for (var j = 0; j < this.cols; j++) this.data[i][j] = 0;


}, 1);

Clazz.newMeth(C$, 'c$$I$I$DAA', function (r, c, elem) {
C$.$init$.apply(this);
this.data = Clazz.array(Double.TYPE, [r, c]);
this.rows = r;
this.cols = c;
for (var i = 0; i < this.rows; i++) for (var j = 0; j < this.cols; j++) this.data[i][j] = elem[i][j];


}, 1);

Clazz.newMeth(C$, 'get_elem$I$I', function (r, c) {
if (r < 0 || r >= this.rows ) return 0;
if (c < 0 || c >= this.cols ) return 0;
return this.data[r][c];
});

Clazz.newMeth(C$, 'set_elem$I$I$D', function (r, c, x) {
if (r < 0 || r >= this.rows ) return;
if (c < 0 || c >= this.cols ) return;
this.data[r][c] = x;
});

Clazz.newMeth(C$, 'print', function () {
System.out.println$S("Rows = " + this.rows + " Cols = " + this.cols );
for (var i = 0; i < this.rows; i++) {
var s = Clazz.new_((I$[1]||$incl$(1)));
for (var j = 0; j < this.cols; j++) {
s.append$D(this.get_elem$I$I(i, j));
if (j < this.cols - 1) s.append$S(",\u0009");
}
System.out.println$S(s.toString());
}
});

Clazz.newMeth(C$, 'matmul$circuitsimulator_Matrix$circuitsimulator_Matrix', function (a, b) {
if ((a.cols != b.rows) || (a.rows != this.rows) || (b.cols != this.cols)  ) return;
for (var i = 0; i < this.rows; i++) for (var j = 0; j < this.cols; j++) {
var s = 0;
for (var k = 0; k < a.cols; k++) s += a.data[i][k] * b.data[k][j];

this.set_elem$I$I$D(i, j, s);
}

});

Clazz.newMeth(C$, 'matmul$DA', function (x) {
var sol = Clazz.array(Double.TYPE, [this.rows]);
for (var j = 0; j < this.rows; j++) {
sol[j] = 0;
for (var k = 0; k < this.cols; k++) sol[j] += this.data[j][k] * x[k];

}
return sol;
});

Clazz.newMeth(C$, 'resolve$DA', function (x) {
var sol;
for (var j = 0; j < this.rows; j++) {
sol = 0;
for (var k = 0; k < this.cols; k++) sol += this.data[j][k] * x[k];

x[j] = sol;
}
});

Clazz.newMeth(C$, 'copy$circuitsimulator_Matrix', function (a) {
for (var i = 0; i < this.rows; i++) for (var j = 0; j < this.cols; j++) this.set_elem$I$I$D(i, j, a.get_elem$I$I(i, j));


});

Clazz.newMeth(C$, 'matinv$circuitsimulator_Matrix', function (a) {
var te;
if (a.rows < 1 || a.rows != a.cols  || a.rows != this.rows  || a.cols != this.cols ) return;
if (a.rows == 1) {
te = a.get_elem$I$I(0, 0);
this.set_elem$I$I$D(0, 0, 1.0 / (te == 0  ? 1.0E-30 : te));
return;
}var b = Clazz.new_(C$.c$$I$I,[this.rows, this.cols]);
b.copy$circuitsimulator_Matrix(a);
var n = this.rows;
for (var i = 0; i < n; i++) for (var j = 0; j < n; j++) if (i == j) this.set_elem$I$I$D(i, j, 1);
 else this.set_elem$I$I$D(i, j, 0);


for (var i = 0; i < n; i++) {
var mag = 0;
var pivot = -1;
for (var j = i; j < n; j++) {
var mag2 = Math.abs(b.get_elem$I$I(j, i));
if (mag2 > mag ) {
mag = mag2;
pivot = j;
}}
if (pivot == -1 || mag == 0  ) return;
if (pivot != i) {
var temp;
for (var j = i; j < n; j++) {
temp = b.get_elem$I$I(i, j);
b.set_elem$I$I$D(i, j, b.get_elem$I$I(pivot, j));
b.set_elem$I$I$D(pivot, j, temp);
}
for (var j = 0; j < n; j++) {
temp = this.get_elem$I$I(i, j);
this.set_elem$I$I$D(i, j, this.get_elem$I$I(pivot, j));
this.set_elem$I$I$D(pivot, j, temp);
}
}mag = b.get_elem$I$I(i, i);
mag = mag == 0  ? 1.0E-30 : mag;
for (var j = i; j < n; j++) b.set_elem$I$I$D(i, j, b.get_elem$I$I(i, j) / mag);

for (var j = 0; j < n; j++) this.set_elem$I$I$D(i, j, this.get_elem$I$I(i, j) / mag);

for (var k = 0; k < n; k++) {
if (k == i) continue;
var mag2 = b.get_elem$I$I(k, i);
for (var j = i; j < n; j++) b.set_elem$I$I$D(k, j, b.get_elem$I$I(k, j) - mag2 * b.get_elem$I$I(i, j));

for (var j = 0; j < n; j++) this.set_elem$I$I$D(k, j, this.get_elem$I$I(k, j) - mag2 * this.get_elem$I$I(i, j));

}
}
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 06:55:33
