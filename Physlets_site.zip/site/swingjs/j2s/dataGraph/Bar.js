(function(){var P$=Clazz.newPackage("dataGraph"),p$1={},p$2={},I$=[[0,'java.awt.Color','edu.davidson.graphics.EtchedBorder','java.awt.BorderLayout',['dataGraph.Bar','.BarGraph'],'dataGraph.SLabel','java.awt.Panel','java.awt.Label','edu.davidson.graph.TextLine','Boolean']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Bar", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SDataListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.min=0;
this.max=0;
this.vert=false;
this.numBars=0;
this.etchedBorder=null;
this.borderLayout1=null;
this.value=0;
this.negColor=null;
this.posColor=null;
this.bar=null;
this.borderLayout2=null;
this.valField=null;
this.showControls=false;
this.autoScale=false;
this.panel1=null;
this.barLabel=null;
this.title=null;
this.titleStr=null;
this.borderLayout3=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.numBars=1;
this.etchedBorder=Clazz.new_(Clazz.load('edu.davidson.graphics.EtchedBorder'));
this.borderLayout1=Clazz.new_(Clazz.load('java.awt.BorderLayout'));
this.value=0;
this.negColor=$I$(1).blue;
this.posColor=$I$(1).red;
this.bar=Clazz.new_(Clazz.load(['dataGraph.Bar','.BarGraph']), [this, null]);
this.borderLayout2=Clazz.new_($I$(3));
this.valField=Clazz.new_(Clazz.load('dataGraph.SLabel'));
this.showControls=false;
this.autoScale=false;
this.panel1=Clazz.new_(Clazz.load('java.awt.Panel'));
this.barLabel=Clazz.new_(Clazz.load('java.awt.Label'));
this.title=Clazz.new_(Clazz.load('edu.davidson.graph.TextLine'));
this.titleStr="";
this.borderLayout3=Clazz.new_($I$(3));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
this.initResources$S(null);
var barWidth=10;
var barText="";
try {
this.min=Double.valueOf$S(this.getParameter$S$S("Min", "0")).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.max=Double.valueOf$S(this.getParameter$S$S("Max", "100")).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.value=Double.valueOf$S(this.getParameter$S$S("Value", "10")).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.vert=Clazz.load('Boolean').valueOf$S(this.getParameter$S$S("Vertical", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.autoScale=$I$(9).valueOf$S(this.getParameter$S$S("AutoScale", "false")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.showControls=$I$(9).valueOf$S(this.getParameter$S$S("ShowControls", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
barWidth=Integer.parseInt$S(this.getParameter$S$S("BarWidth", "10"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.numBars=Integer.parseInt$S(this.getParameter$S$S("NumSeries", "1"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
barText=this.getParameter$S$S("Label", "");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.titleStr=this.getParameter$S$S("Title", "");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
p$2.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
if (!this.showControls) {
this.panel1.setVisible$Z(false);
}this.valField.setValue$D(this.value);
this.bar.barWidth=barWidth;
if (barText.equals$O("")) this.barLabel.setVisible$Z(false);
 else {
this.barLabel.setText$S(barText);
this.barLabel.setVisible$Z(true);
}edu.davidson.tools.SApplet.addDataListener$O(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.bar.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.barLabel.setAlignment$I(2);
this.setBackground$java_awt_Color($I$(1).lightGray);
this.panel1.setBackground$java_awt_Color($I$(1).lightGray);
this.etchedBorder.setBackground$java_awt_Color($I$(1).lightGray);
this.etchedBorder.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.add$java_awt_Component$O(this.etchedBorder, "Center");
this.add$java_awt_Component$O(this.panel1, "South");
this.panel1.add$java_awt_Component$O(this.barLabel, null);
this.panel1.add$java_awt_Component$O(this.valField, null);
this.etchedBorder.add$java_awt_Component$O(this.bar, "Center");
}, p$2);

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'], function () {
return "Bar by W. Christian. Email:wochristian@davidson.edu";
});

Clazz.newMeth(C$, ['getParameterInfo$','getParameterInfo'], function () {
var pinfo=Clazz.array(String, -2, [Clazz.array(String, -1, ["Min", "double", "Minimum value"]), Clazz.array(String, -1, ["Max", "double", "Maximum value"]), Clazz.array(String, -1, ["Vertical", "boolean", "Orientation"])]);
return pinfo;
});

Clazz.newMeth(C$, ['getAppletCount$','getAppletCount'], function () {
if (this.firstTime) return 0;
 else return C$.superclazz.prototype.getAppletCount$.apply(this, []);
});

Clazz.newMeth(C$, ['start$','start'], function () {
if (this.firstTime) {
this.firstTime=false;
}C$.superclazz.prototype.start$.apply(this, []);
});

Clazz.newMeth(C$, ['setAutoscale$Z','setAutoscale'], function (scale) {
this.autoScale=scale;
this.bar.repaint$();
});

Clazz.newMeth(C$, ['setFormat$S','setFormat'], function (str) {
this.valField.setFormat$S(str);
});

Clazz.newMeth(C$, ['setLabel$S','setLabel'], function (newLabel) {
this.barLabel.setText$S(newLabel);
if (newLabel.equals$O("")) {
this.barLabel.setVisible$Z(false);
} else this.barLabel.setVisible$Z(true);
this.invalidate$();
this.validate$();
});

Clazz.newMeth(C$, ['setTtile$S','setTtile'], function (_title) {
this.titleStr=_title;
this.bar.repaint$();
});

Clazz.newMeth(C$, ['setBarWidth$I','setBarWidth'], function (newWidth) {
this.bar.barWidth=newWidth;
this.bar.repaint$();
});

Clazz.newMeth(C$, ['setMax$D','setMax'], function (m) {
this.max=m;
this.bar.repaint$();
});

Clazz.newMeth(C$, ['setMin$D','setMin'], function (m) {
this.min=m;
this.bar.repaint$();
});

Clazz.newMeth(C$, ['setValue$D','setValue'], function (v) {
if (this.autoScale) {
if (v > this.max ) {
this.max=v;
}if (v < this.min ) {
this.min=v;
}}this.value=v;
this.valField.setValue$D(v);
this.bar.repaint$();
});

Clazz.newMeth(C$, ['setPosRGB$I$I$I','setPosRGB'], function (r, g, b) {
this.posColor=Clazz.new_($I$(1).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, ['setNegRGB$I$I$I','setNegRGB'], function (r, g, b) {
this.negColor=Clazz.new_($I$(1).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, ['setNumericFormat$S','setNumericFormat'], function (str) {
this.valField.setFormat$S(str);
});

Clazz.newMeth(C$, ['addDatum$I$D$D','addDatum'], function (id, x, y) {
this.setValue$D(x);
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, x, y) {
this.setValue$D(x);
});

Clazz.newMeth(C$, ['addData$I$DA$DA','addData'], function (id, x, y) {
if (x == null ) {
return;
}var n=x.length;
if (n < 1) {
return;
}this.setValue$D(x[n - 1]);
});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
this.addData$I$DA$DA(id, x, y);
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.setValue$D(0);
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
this.setValue$D(0);
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
});

Clazz.newMeth(C$, ['getOwner$','getOwner'], function () {
return this;
});
;
(function(){var C$=Clazz.newClass(P$.Bar, "BarGraph", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.barWidth=0;
this.osi=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.barWidth=10;
this.osi=null;
}, 1);

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var w=this.getBounds$().width;
var h=this.getBounds$().height;
if ((w < 4) || (h < 4) ) {
return;
}if ((this.osi == null ) || (this.osi.getWidth$java_awt_image_ImageObserver(null) != w) || (this.osi.getHeight$java_awt_image_ImageObserver(null) != h)  ) {
this.osi=this.createImage$I$I(w, h);
}if (this.osi == null ) {
return;
}p$1.paintOSI.apply(this, []);
g.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, w, h, this);
});

Clazz.newMeth(C$, 'paintOSI', function () {
var x;
var y;
var w;
var h;
var o;
var origin=0;
if ((this.this$0.min <= 0 ) && (this.this$0.max > 0 ) ) {
origin=0;
}var g=this.osi.getGraphics$();
w=this.osi.getWidth$java_awt_image_ImageObserver(null);
h=this.osi.getHeight$java_awt_image_ImageObserver(null);
var bgColor=this.this$0.getBackground$();
g.setColor$java_awt_Color(bgColor);
g.fillRect$I$I$I$I(0, 0, w, h);
if (this.this$0.vert) {
o=((0.4999999 + h * this.this$0.max / (this.this$0.max - this.this$0.min))|0);
h=((h * (this.this$0.value - origin) / (this.this$0.max - this.this$0.min))|0);
if (h >= 0) {
y=o - h;
g.setColor$java_awt_Color(this.this$0.posColor);
} else {
y=o;
h=-h;
g.setColor$java_awt_Color(this.this$0.negColor);
}g.fillRect$I$I$I$I((w/2|0) - this.barWidth, y, 2 * this.barWidth, h);
g.setColor$java_awt_Color(Clazz.load('java.awt.Color').black);
g.drawLine$I$I$I$I(0, o, w - 1, o);
} else {
o=((0.4999999 - w * this.this$0.min / (this.this$0.max - this.this$0.min))|0);
w=((w * (this.this$0.value - origin) / (this.this$0.max - this.this$0.min))|0);
if (w >= 0) {
x=o;
g.setColor$java_awt_Color(this.this$0.posColor);
} else {
w=-w;
x=o - w;
g.setColor$java_awt_Color(this.this$0.negColor);
}g.fillRect$I$I$I$I(x, (h/2|0) - this.barWidth, w, 2 * this.barWidth);
g.setColor$java_awt_Color($I$(1).black);
g.drawLine$I$I$I$I(o, 0, o, h - 1);
}if (!this.this$0.titleStr.equals$O("")) {
this.this$0.title.setText$S(this.this$0.titleStr);
this.this$0.title.draw$java_awt_Graphics$I$I$I(g, (w/2|0), 15, 0);
}g.dispose$();
}, p$1);

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:17 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
