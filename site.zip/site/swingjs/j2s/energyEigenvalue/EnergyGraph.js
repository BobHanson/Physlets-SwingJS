(function(){var P$=Clazz.newPackage("energyEigenvalue"),I$=[['edu.davidson.tools.SApplet','java.util.Vector','java.util.Hashtable','edu.davidson.display.Format','java.awt.Color','edu.davidson.numerics.Parser','java.awt.SystemColor','java.awt.event.MouseMotionAdapter','java.awt.event.MouseAdapter','edu.davidson.display.SGraphFrame','java.awt.Cursor',['energyEigenvalue.EnergyGraph','.ActiveWavefunction'],['energyEigenvalue.EnergyGraph','.ActiveState'],['energyEigenvalue.EnergyGraph','.Wavefunction']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EnergyGraph", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.display.SGraph');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.dataSources = null;
this.activeWavefunction = null;
this.activeState = null;
this.potFunc = null;
this.showLevels = false;
this.rclicked = false;
this.lines = false;
this.divergence = false;
this.broke = false;
this.resetE = false;
this.updated = false;
this.showWavefunction = false;
this.active = 0;
this.breakv = 0;
this.eValues = null;
this.$boxWidth = 0;
this.ktemp = 0;
this.kcheck = 0;
this.maxiterations = 0;
this.$format = null;
this.numPts = 0;
this.psi = null;
this.psigraphed = null;
this.$y = null;
this.$x = null;
this.eGuess = 0;
this.h = 0;
this.energy = 0;
this.dx = 0;
this.eMax = 0;
this.eMin = 0;
this.datamax = 0;
this.funcmin = 0;
this.funcmax = 0;
this.tolerance = 0;
this.owner = null;
this.autoscalePotential = false;
this.sum = 0;
this.scalearea = false;
this.energyDragMode = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.dataSources = Clazz.new_((I$[2]||$incl$(2)));
this.activeWavefunction = null;
this.activeState = null;
this.divergence = false;
this.broke = false;
this.resetE = false;
this.showWavefunction = true;
this.active = 0;
this.eValues = Clazz.new_((I$[3]||$incl$(3)));
this.$boxWidth = 0;
this.ktemp = 0;
this.kcheck = 0;
this.$format = Clazz.new_((I$[4]||$incl$(4)).c$$S,["%-+6.3g"]);
this.psi = null;
this.psigraphed = null;
this.$y = null;
this.$x = null;
this.owner = null;
this.autoscalePotential = false;
this.sum = 0;
this.scalearea = false;
this.energyDragMode = false;
}, 1);

Clazz.newMeth(C$, 'c$$energyEigenvalue_EnergyEigenvalue', function (a) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.owner=a;
this.setOwner$edu_davidson_tools_SApplet(a);
try {
p$.jbInit.apply(this, []);
this.setSeriesStyle$I$java_awt_Color$Z$I(1, (I$[5]||$incl$(5)).red, true, 0);
this.setSeriesStyle$I$java_awt_Color$Z$I(2, (I$[5]||$incl$(5)).blue, true, 0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'setAutoscalePotential$Z', function (as) {
this.autoscalePotential=as;
});

Clazz.newMeth(C$, 'setPotential$S', function (str) {
var parseError = false;
this.datamax=0;
this.funcmin=0;
this.potFunc=Clazz.new_((I$[6]||$incl$(6)).c$$I,[1]);
this.potFunc.defineVariable$I$S(1, "x");
this.potFunc.define$S(str);
this.potFunc.parse();
if (this.potFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse V(x): " + str);
System.out.println$S("Parse error: " + this.potFunc.getErrorString() + " at function 1, position " + this.potFunc.getErrorPosition() );
parseError=true;
str="0";
this.potFunc.define$S(str);
this.potFunc.parse();
} else parseError=false;
this.dx=(this.getMaxX() - this.getMinX()) / (this.numPts - 1);
this.$x[0]=this.getMinX();
this.$y[0]=this.potFunc.evaluate$D(this.$x[0]);
this.funcmin=this.$y[0];
this.funcmax=this.$y[0];
for (var i = 1; i < this.numPts; i++) {
this.$x[i]=this.$x[i - 1] + this.dx;
this.$y[i]=this.potFunc.evaluate$D(this.$x[i]);
if (this.$y[i] > this.funcmax ) this.funcmax=this.$y[i];
if (this.$y[i] < this.funcmin ) this.funcmin=this.$y[i];
}
this.eMin=this.funcmin;
this.eMax=this.funcmax;
this.setAutoRefresh$Z(false);
if (this.autoscalePotential) this.setAutoscaleY$Z(true);
this.setAutoReplaceData$I$Z(1, false);
this.setAutoReplaceData$I$Z(2, false);
this.clearSeriesData$I(2);
this.clearSeriesData$I(1);
this.setAutoReplaceData$I$Z(1, true);
this.setAutoReplaceData$I$Z(2, true);
if (this.showWavefunction) this.addData$I$DA$DA(1, this.$x, this.$y);
if (!this.updated) {
if (this.showWavefunction) this.addData$I$DA$DA(2, this.$x, this.psigraphed);
if (this.activeWavefunction != null ) this.activeWavefunction.updateValues$D(this.energy);
if (this.activeState != null ) this.activeState.updateValues$D$I(this.energy, this.active);
}if (this.autoscalePotential) this.setAutoscaleY$Z(false);
if (this.autoscalePotential) {
var lowE = this.funcmin;
var highE = this.funcmax;
var levels = this.eValues.elements();
while (levels.hasMoreElements()){
var en = (levels.nextElement()).doubleValue();
lowE=Math.min(lowE, en);
highE=Math.max(highE, en);
}
var range = highE - lowE;
this.setMinMaxY$D$D(lowE - 0.12 * range, highE + 0.12 * range);
}this.setAutoRefresh$Z(true);
return !parseError;
});

Clazz.newMeth(C$, 'setIterations$I', function (it) {
this.maxiterations=it;
});

Clazz.newMeth(C$, 'setBreakValue$D', function (bv) {
this.breakv=bv;
});

Clazz.newMeth(C$, 'setEnergy$D', function (en) {
this.energy=en;
this.active=0;
});

Clazz.newMeth(C$, 'sethBar$D', function (h) {
this.h=h;
});

Clazz.newMeth(C$, 'setNumpts$I', function (num) {
this.numPts=num;
this.psi=Clazz.array(Double.TYPE, [this.numPts]);
this.psigraphed=Clazz.array(Double.TYPE, [this.numPts]);
this.$x=Clazz.array(Double.TYPE, [this.numPts]);
this.$y=Clazz.array(Double.TYPE, [this.numPts]);
});

Clazz.newMeth(C$, 'setTolerance$D', function (t) {
this.tolerance=t;
});

Clazz.newMeth(C$, 'scaleToArea$Z', function (sa) {
this.scalearea=sa;
});

Clazz.newMeth(C$, 'setShowWavefunction$Z', function (show) {
this.showWavefunction=show;
if (show) {
this.setShowAxis$Z(true);
this.frame=true;
this.setDataBackground$java_awt_Color((I$[5]||$incl$(5)).white);
} else {
this.setShowAxis$Z(false);
this.frame=false;
this.setDataBackground$java_awt_Color((I$[7]||$incl$(7)).control);
}});

Clazz.newMeth(C$, 'calculatePsi$D', function (energy) {
if (this.psi == null ) {
this.divergence=true;
return 0;
}this.divergence=false;
var count = 0;
var alpha;
var beta;
var tendx = this.h * (10.0 * this.dx * this.dx ) / 12.0;
var twlvedx = (this.h * this.dx * this.dx ) / 12.0;
this.psi[0]=0;
this.psi[1]=1.0E-12;
this.sum=this.psi[1] * this.psi[1] * this.dx ;
for (var i = 1; i < (this.numPts - 1); i++) {
alpha=this.psi[i] * (2 + tendx * (this.$y[i] - energy)) - this.psi[i - 1] * (1 - twlvedx * (this.$y[i - 1] - energy));
beta=1 - twlvedx * (this.$y[i + 1] - energy);
this.psi[i + 1]=(alpha / beta);
if (this.psi[i + 1] > this.breakv ) {
this.broke=true;
System.out.println$S("psi>breakvalue: wavefunction not accurate");
break;
}this.sum=this.sum + (this.psi[i + 1] * this.psi[i + 1] * this.dx );
}
var lastCross = 0;
for (var i = 1; i < this.numPts; i++) {
if (this.psi[i] == 0  || (this.psi[i - 1] / this.psi[i]) < 0  ) {
count++;
lastCross=i;
}}
if (count < 1 || lastCross < 4 ) lastCross=this.numPts;
this.datamax=0;
var tmp = 0;
for (var i = 1; i < lastCross; i++) {
tmp=Math.abs(this.psi[i]);
if (this.datamax < tmp ) this.datamax=tmp;
}
if (Math.abs(this.psi[this.numPts - 1]) >= this.datamax ) {
this.divergence=true;
}return count;
});

Clazz.newMeth(C$, 'purgeHashtable', function () {
var keys = this.eValues.keys();
while (keys.hasMoreElements()){
this.eValues.remove$O(keys.nextElement());
}
this.dataSources.removeAllElements();
this.owner.deleteDataConnections();
});

Clazz.newMeth(C$, 'findElevel$I$Z', function (n, shouldPlot) {
this.active=n;
p$.checkPotential$I.apply(this, [n]);
var key = "" + n;
var count = 0;
if (this.resetE) {
this.eMax=this.funcmax;
this.eMin=this.funcmin;
this.energy=(this.funcmax - this.funcmin) / 2.0;
this.resetE=false;
}if (this.eValues.get$O(key) != null ) {
this.energy=(this.eValues.get$O(key)).doubleValue();
this.calculatePsi$D(this.energy);
this.active=n;
this.scaleData$D$Z(this.energy, shouldPlot);
this.setTitle$S(null);
} else {
var ii = 0;
while (this.calculatePsi$D(this.eMax) < n && ii < 100 ){
this.eMax=1.1 * this.eMax + 1.0;
ii++;
}
for (var i = 1; i < this.maxiterations; i++) {
count=this.calculatePsi$D(this.energy);
if ((Math.abs(this.psi[this.numPts - 1]) < this.tolerance ) && count == n ) break;
 else {
if (count > n) this.eMax=this.energy;
if (count < n) this.eMin=this.energy;
if (count == n) {
if (this.psi[this.numPts - 1] < 0 ) {
this.eMax=this.energy;
this.eGuess=this.eMax;
}if (this.psi[this.numPts - 1] > 0 ) {
this.eMax=this.energy;
this.eGuess=this.eMax;
}}if (count > n) {
this.eGuess=(this.eGuess + this.eMin) / 2.0;
this.energy=this.eGuess;
} else if (count < n) {
this.eGuess=(this.eMax + this.eGuess) / 2.0;
this.energy=this.eGuess;
} else {
if (count == n) {
if (this.psi[this.numPts - 1] < 0 ) {
this.energy=(this.eMax + this.eMin) / 2.0;
}if (this.psi[this.numPts - 1] > 0 ) {
this.energy=(this.eMax + this.eMin) / 2.0;
}}}if (i == (this.maxiterations - 1)) {
System.out.println$S("Hit maximum iterations. n=" + n);
}}}
if (!!(this.divergence || !!(this.broke | (!this.autoscalePotential && this.energy > this.getMaxY()  )))) {
} else {
this.eValues.put$TK$TV(key,  new Double(this.energy));
this.divergence=false;
}}if (this.energy > this.getMaxY()  && !this.autoscalePotential ) {
this.owner.noscale=true;
this.setTitle$S("Level out of Range");
} else {
this.owner.noscale=false;
}this.active=n;
return this.energy;
});

Clazz.newMeth(C$, 'scaleData$D$Z', function (en, plotWavefunction) {
this.setAutoRefresh$Z(false);
this.clearSeriesData$I(2);
var energyRange = this.getMaxY() - this.getMinY();
if (this.autoscalePotential && en > this.getMaxY() - 0.12 * energyRange  ) {
var newMax = en;
var oldMin = this.getMinY();
this.setMinMaxY$D$D(oldMin, newMax + 0.12 * (newMax - oldMin));
}if (this.autoscalePotential && en < this.getMinY()  ) {
var oldMax = this.getMaxY();
var newMin = en;
if (en < this.funcmax ) {
} else {
this.setMinMaxY$D$D(newMin - 0.12 * (newMin - oldMax), oldMax);
}}var height = (this.getMaxY() - this.getMinY()) * 0.1 / this.datamax;
var area = (this.getMaxY() - this.getMinY()) * (this.getMaxX() - this.getMinX()) * 0.02  / Math.sqrt(this.sum);
for (var i = 0; i < this.numPts; i++) {
if (this.scalearea) {
this.psigraphed[i]=(area * (this.psi[i])) + en;
} else {
this.psigraphed[i]=(height * this.psi[i]) + en;
}}
if (this.showWavefunction) this.addData$I$DA$DA(2, this.$x, this.psigraphed);
if (this.activeWavefunction != null ) this.activeWavefunction.updateValues$D(this.energy);
if (this.activeState != null ) this.activeState.updateValues$D$I(this.energy, this.active);
if ((this.divergence || this.broke ) && !this.rclicked ) {
this.setTitle$S("No Convergence");
} else {
this.setTitle$S(null);
}if (this.rclicked) {
this.setTitle$S(null);
}this.divergence=false;
this.broke=false;
this.setAutoRefresh$Z(true);
});

Clazz.newMeth(C$, 'checkPotential$I', function (n) {
if (this.eMax == this.eMin ) {
this.eMax=this.eMin + 10.0;
this.energy=(this.eMax + this.eMin) / 2.0;
var count = this.calculatePsi$D(this.energy);
if (count < n) {
while (count < n){
this.eMax=this.eMax + 10.0;
this.eMin=this.energy;
this.energy=(this.eMax + this.eMin) / 2.0;
count=this.calculatePsi$D(this.energy);
}
}}});

Clazz.newMeth(C$, 'showSpectrum$Z', function (show) {
this.showLevels=show;
});

Clazz.newMeth(C$, 'calculateLevels$I$I', function (lowest, highest) {
if (lowest > highest || lowest == 0 ) {
System.out.println$S("Error: parameter Higher>Lower");
} else {
var level = highest;
for (var i = (highest); i > (lowest - 1); i--) {
this.energy=(this.funcmax - this.funcmin) / 2.0;
this.eMax=this.funcmax;
this.eMin=this.funcmin;
this.findElevel$I$Z(level, true);
if (level == lowest) {
this.scaleData$D$Z(this.energy, true);
this.owner.evalue.setValue$D(this.energy);
this.owner.elevel.setValue$I(lowest);
}level--;
}
}var lowE = this.funcmin;
var highE = this.funcmax;
if (this.autoscalePotential) {
var levels = this.eValues.elements();
while (levels.hasMoreElements()){
var en = (levels.nextElement()).doubleValue();
lowE=Math.min(lowE, en);
highE=Math.max(highE, en);
}
var range = highE - lowE;
this.setMinMaxY$D$D(lowE - 0.12 * range, highE + 0.12 * range);
this.findElevel$I$Z(lowest, true);
}});

Clazz.newMeth(C$, 'paintLast$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
C$.superclazz.prototype.paintLast$java_awt_Graphics$java_awt_Rectangle.apply(this, [g, r]);
g.setClip$I$I$I$I(0, 0, this.getBounds().width, this.getBounds().width);
if (this.energyDragMode) this.drawMyEnergy$java_awt_Graphics$D(g, this.energy);
});

Clazz.newMeth(C$, 'paintBeforeData$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var activex = 0;
var activey = 0;
var paintActive = false;
var y = 0;
var x = 0;
var b = 0;
x=this.getSize().width;
if (this.showLevels) {
this.borderRight=80;
b=this.borderRight;
g.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
var fm = g.getFontMetrics();
var a = fm.getAscent();
var s1 = this.owner.label_levels;
g.drawString$S$I$I(s1, x - (((this.borderRight / 2.0)|0) + ((fm.stringWidth$S(s1) / 2.0)|0)), a);
g.fillRect$I$I$I$I(x - (this.borderRight - 5), a + 2, (this.borderRight - 10), (this.pixFromY$D(this.getMinY()) - this.pixFromY$D(this.getMaxY())));
this.borderTop=a + 2;
var levels = this.eValues.elements();
var keys = this.eValues.keys();
g.setColor$java_awt_Color((I$[5]||$incl$(5)).green);
while (levels.hasMoreElements()){
y=this.pixFromY$D((levels.nextElement()).doubleValue());
if (this.active == (Integer.$valueOf(keys.nextElement()).intValue()) && !this.lines ) {
g.setColor$java_awt_Color((I$[5]||$incl$(5)).red);
paintActive=true;
activex=x;
activey=y;
} else {
g.setColor$java_awt_Color((I$[5]||$incl$(5)).green);
}g.drawLine$I$I$I$I(x - (b - 9), y, x - 9, y);
}
if (paintActive) {
g.setColor$java_awt_Color((I$[5]||$incl$(5)).red);
g.drawLine$I$I$I$I(activex - (b - 9), activey, activex - 9, activey);
}} else {
this.borderRight=10;
}this.lines=false;
});

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet', function (o) {
Clazz.super_(C$, this,1);
this.setOwner$edu_davidson_tools_SApplet(o);
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'jbInit', function () {
this.setSampleData$Z(false);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyGraph$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseMotionAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
this.b$['energyEigenvalue.EnergyGraph'].this_mouseDragged$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[8]||$incl$(8)), [this, null],P$.EnergyGraph$1)));
this.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyGraph$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.b$['energyEigenvalue.EnergyGraph'].this_mouseReleased$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.b$['energyEigenvalue.EnergyGraph'].this_mousePressed$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
this.b$['energyEigenvalue.EnergyGraph'].this_mouseEntered$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
this.b$['energyEigenvalue.EnergyGraph'].this_mouseExited$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[9]||$incl$(9)), [this, null],P$.EnergyGraph$2)));
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.energyDragMode=false;
this.setAutoRefresh$Z(false);
var yPix = e.getY();
var x = this.getSize().width;
var dr = this.getBounds();
this.repaint$I$I$I$I(0, dr.height - 20, this.$boxWidth, 20);
this.$boxWidth=0;
if (this.rclicked) {
var g = this.getGraphics();
g.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
g.drawLine$I$I$I$I(x - (this.borderRight - 9), yPix, x - 9, yPix);
this.owner.evalue.setValue$D(this.yFromPix$I(yPix));
g.dispose();
this.rclicked=false;
}this.setAutoRefresh$Z(true);
});

Clazz.newMeth(C$, 'determineClosest$I$I', function (xPix, yPix) {
var pt = 0;
var q = 0;
var n = 0;
var k = 0;
var difference = 0.0;
var closest = 70000.0;
var x = this.getSize().width;
var levels = this.eValues.elements();
var keys = this.eValues.keys();
this.ktemp=this.active;
if (xPix > (x - (this.borderRight - 5)) && (xPix < (x - 5))  && (yPix > this.pixFromY$D(this.getMaxY()))  && (yPix < this.pixFromY$D(this.getMinY())) ) {
while (levels.hasMoreElements()){
pt=(levels.nextElement()).doubleValue();
k=Integer.$valueOf(keys.nextElement()).intValue();
q=this.yFromPix$I(yPix);
difference=Math.abs(pt - q);
if (difference < closest ) {
closest=difference;
this.energy=pt;
n=k;
this.kcheck=n;
this.active=n;
}}
if (this.ktemp == this.kcheck && !this.rclicked ) {
return;
} else {
if (this.energy == this.funcmax ) {
this.resetE=true;
this.findElevel$I$Z(n, true);
this.active=n;
this.scaleData$D$Z(this.energy, true);
this.owner.elevel.setValue$I(n);
this.owner.evalue.setValue$D(this.energy);
} else {
this.calculatePsi$D(this.energy);
this.active=n;
this.scaleData$D$Z(this.energy, true);
this.owner.elevel.setValue$I(n);
this.owner.evalue.setValue$D(this.energy);
}}}});

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
var x = this.getSize().width;
var xPix = e.getX();
var yPix = e.getY();
if (((e.getModifiers() & 4) != 0) && (xPix > (x - (this.borderRight - 5))) && (xPix < (x - 5))  ) {
if ((yPix > this.pixFromY$D(this.getMaxY())) && (yPix < this.pixFromY$D(this.funcmin)) ) {
this.setAutoRefresh$Z(false);
this.rclicked=true;
this.active=0;
this.energy=this.yFromPix$I(yPix);
if (this.energy > 10 * this.funcmax ) {
} else {
this.calculatePsi$D(this.energy);
this.scaleData$D$Z(this.energy, true);
if ((this.autoscalePotential && yPix < this.pixFromY$D(10 * this.funcmax) )) {
this.drawEnergyLine$I(this.pixFromY$D(10 * this.funcmax));
} else {
this.drawEnergyLine$I(yPix);
}}this.drawMyCoords$I$I(xPix, yPix);
}} else if ((xPix > (x - (this.borderRight - 5))) && (xPix < (x - 5)) && (yPix > this.pixFromY$D(this.getMaxY())) && (yPix < this.pixFromY$D(this.getMinY()))  ) {
this.determineClosest$I$I(xPix, yPix);
} else if (xPix < (x - (this.borderRight - 5)) && !((e.getModifiers() & 4) != 0) ) {
this.drawMyCoords$I$I(xPix, yPix);
} else if ((e.getModifiers() & 4) != 0) {
var graphFrame = Clazz.new_((I$[10]||$incl$(10)).c$$edu_davidson_display_SGraph,[this.clone()]);
graphFrame.setSize$I$I(this.getSize().width, this.getSize().height);
graphFrame.show();
}});

Clazz.newMeth(C$, 'this_mouseDragged$java_awt_event_MouseEvent', function (e) {
var x = this.getSize().width;
var xPix = e.getX();
var yPix = e.getY();
if (((e.getModifiers() & 4) != 0) && (xPix > (x - (this.borderRight - 5))) && (xPix < (x - 5))  ) {
if ((yPix > this.pixFromY$D(this.getMaxY())) && (yPix < this.pixFromY$D(this.funcmin)) ) {
this.setAutoRefresh$Z(false);
this.rclicked=true;
this.active=0;
this.energy=this.yFromPix$I(yPix);
if (this.energy > 10 * this.funcmax ) {
} else {
this.calculatePsi$D(this.energy);
this.scaleData$D$Z(this.energy, true);
if ((this.autoscalePotential && yPix < this.pixFromY$D(10 * this.funcmax) )) {
this.drawEnergyLine$I(this.pixFromY$D(10 * this.funcmax));
} else {
this.drawEnergyLine$I(yPix);
}}this.drawMyCoords$I$I(xPix, yPix);
}} else if ((xPix > (x - (this.borderRight - 5))) && (xPix < (x - 5)) && (yPix > this.pixFromY$D(this.getMaxY())) && (yPix < this.pixFromY$D(this.getMinY()))  ) {
this.determineClosest$I$I(xPix, yPix);
} else if (xPix < (x - (this.borderRight - 5)) && !((e.getModifiers() & 4) != 0) ) {
this.drawMyCoords$I$I(xPix, yPix);
}});

Clazz.newMeth(C$, 'drawEnergyLine$I', function (yPix) {
this.lines=true;
var w = this.getSize().width;
var lg = this.getGraphics();
lg.setColor$java_awt_Color((I$[5]||$incl$(5)).red);
lg.drawLine$I$I$I$I(w - (this.borderRight - 9), yPix, w - 9, yPix);
lg.dispose();
});

Clazz.newMeth(C$, 'this_mouseEntered$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor((I$[11]||$incl$(11)).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$, 'this_mouseExited$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor((I$[11]||$incl$(11)).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$, 'amplitude$I', function (xPix) {
var location = 0;
var f = this.pixFromX$D(this.getMaxX());
var g = this.pixFromX$D(this.getMinX());
location=Math.round(this.numPts * ((xPix - g) / (f - g)));
return (location|0);
});

Clazz.newMeth(C$, 'drawMyCoords$I$I', function (xPix, yPix) {
var x = this.getSize().width;
var msg = null;
if ((xPix > (x - (this.borderRight - 5))) && (xPix < (x - 5)) && (yPix > this.pixFromY$D(this.getMaxY())) && (yPix < this.pixFromY$D(this.getMinY()))  ) {
msg="E:" + this.$format.form$D(this.yFromPix$I(yPix));
this.energyDragMode=true;
return;
} else if (xPix < (x - (this.borderRight))) {
var index = p$.amplitude$I.apply(this, [xPix]);
if (index >= 0 && index < this.numPts ) msg="x:" + this.$format.form$D(this.xFromPix$I(xPix)) + ", E:" + this.$format.form$D(this.yFromPix$I(yPix)) + " Psi:" + this.$format.form$D(this.psigraphed[index]) ;
 else msg="x:" + this.$format.form$D(this.xFromPix$I(xPix)) + ", E:" + this.$format.form$D(this.yFromPix$I(yPix)) ;
}var dg = this.getGraphics();
var dr = this.getBounds();
dg.setColor$java_awt_Color((I$[5]||$incl$(5)).yellow);
var fm = dg.getFontMetrics$java_awt_Font(dg.getFont());
this.$boxWidth=Math.max(20 + fm.stringWidth$S(msg), this.$boxWidth);
dg.fillRect$I$I$I$I(0, dr.height - 20, this.$boxWidth, 20);
dg.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
dg.drawString$S$I$I(msg, 10, dr.height - 5);
dg.dispose();
});

Clazz.newMeth(C$, 'drawMyEnergy$java_awt_Graphics$D', function (g, en) {
var msg = "E:" + this.$format.form$D(en);
var dr = this.getBounds();
g.setColor$java_awt_Color((I$[5]||$incl$(5)).yellow);
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
this.$boxWidth=Math.max(20 + fm.stringWidth$S(msg), this.$boxWidth);
g.fillRect$I$I$I$I(0, dr.height - 20, this.$boxWidth, 20);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
g.drawString$S$I$I(msg, 10, dr.height - 5);
});

Clazz.newMeth(C$, 'getActiveWavefunctionID', function () {
if (this.activeWavefunction != null ) return this.activeWavefunction.getID();
this.activeWavefunction=Clazz.new_((I$[12]||$incl$(12)), [this, null]);
this.activeWavefunction.updateValues$D(this.energy);
return this.activeWavefunction.getID();
});

Clazz.newMeth(C$, 'getActiveStateID', function () {
if (this.activeState != null ) return this.activeState.getID();
this.activeState=Clazz.new_((I$[13]||$incl$(13)).c$$D$I, [this, null, this.energy, this.active]);
return this.activeState.getID();
});

Clazz.newMeth(C$, 'getActiveQuantumNumber', function () {
return this.active;
});

Clazz.newMeth(C$, 'getActiveEnergy', function () {
return this.energy;
});

Clazz.newMeth(C$, 'getWavefunctionID$I', function (n) {
var wf = null;
for (var e = this.dataSources.elements(); e.hasMoreElements(); ) {
wf=e.nextElement();
if (wf.qnumber == n) return wf.getID();
}
wf=Clazz.new_((I$[14]||$incl$(14)).c$$I, [this, null, n]);
this.dataSources.addElement$TE(wf);
return wf.getID();
});
;
(function(){var C$=Clazz.newClass(P$.EnergyGraph, "Wavefunction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.ds = null;
this.qnumber = 0;
this.eigenenergy = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "p", "psi", "energy"]);
this.ds = Clazz.array(Double.TYPE, [1, 4]);
this.qnumber = 0;
this.eigenenergy = 0;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (n) {
C$.$init$.apply(this);
this.qnumber=n;
this.eigenenergy=this.this$0.findElevel$I$Z(this.qnumber, false);
this.ds=Clazz.array(Double.TYPE, [this.this$0.numPts, 4]);
var dataheight = Math.abs(this.this$0.psi[0]);
var norm = 0;
var dx = Math.abs(this.this$0.$x[1] - this.this$0.$x[0]);
for (var i = 1; i < this.this$0.numPts; i++) {
dataheight=Math.max(dataheight, Math.abs(this.this$0.psi[i]));
norm += this.this$0.psi[i] * this.this$0.psi[i] * dx ;
}
norm=Math.sqrt(norm);
if (dataheight == 0 ) dataheight=1;
if (norm == 0 ) norm=1;
for (var i = 0; i < this.this$0.numPts; i++) {
this.ds[i][0]=this.this$0.$x[i];
this.ds[i][1]=this.this$0.$y[i];
if (this.this$0.scalearea) {
this.ds[i][2]=this.this$0.psi[i] / norm;
} else {
this.ds[i][2]=this.this$0.psi[i] / dataheight;
}this.ds[i][3]=this.eigenenergy;
}
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0.owner;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.EnergyGraph, "ActiveWavefunction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.ds = null;
this.eigenenergy = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "p", "psi", "energy"]);
this.ds = Clazz.array(Double.TYPE, [1, 4]);
this.eigenenergy = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.ds=Clazz.array(Double.TYPE, [this.this$0.numPts, 4]);
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'updateValues$D', function (en) {
this.eigenenergy=en;
if (this.this$0.$x == null  || this.this$0.$y == null   || this.this$0.psigraphed == null  ) return;
var numPts = this.this$0.$x.length;
if (this.ds == null  || this.ds.length != this.this$0.$x.length ) {
this.ds=Clazz.array(Double.TYPE, [numPts, 4]);
}var dataheight = Math.abs(this.this$0.psigraphed[0] - en);
var norm = 0;
var dx = Math.abs(this.this$0.$x[1] - this.this$0.$x[0]);
for (var i = 1; i < numPts; i++) {
var psi = this.this$0.psigraphed[i] - en;
dataheight=Math.max(dataheight, Math.abs(psi));
norm += psi * psi * dx ;
}
norm=Math.sqrt(norm);
if (dataheight == 0 ) dataheight=1;
if (norm == 0 ) norm=1;
for (var i = 0; i < numPts; i++) {
this.ds[i][0]=this.this$0.$x[i];
this.ds[i][1]=this.this$0.$y[i];
if (this.this$0.scalearea) {
this.ds[i][2]=(this.this$0.psigraphed[i] - en) / norm;
} else {
this.ds[i][2]=(this.this$0.psigraphed[i] - en) / dataheight;
}this.ds[i][3]=en;
}
this.this$0.owner.updateDataConnections();
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0.owner;
});
})()
;
(function(){var C$=Clazz.newClass(P$.EnergyGraph, "ActiveState", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.ds = null;
this.eigenenergy = 0;
this.qn = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["n", "energy"]);
this.ds = Clazz.array(Double.TYPE, [1, 2]);
this.eigenenergy = 0;
this.qn = 0;
}, 1);

Clazz.newMeth(C$, 'c$$D$I', function (en, n) {
C$.$init$.apply(this);
this.eigenenergy=en;
this.qn=n;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'updateValues$D$I', function (en, n) {
this.eigenenergy=en;
this.qn=n;
this.this$0.owner.updateDataConnections();
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0]=this.qn;
this.ds[0][1]=this.eigenenergy;
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0.owner;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:35
