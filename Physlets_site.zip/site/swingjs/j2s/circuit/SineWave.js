(function(){var P$=Clazz.newPackage("circuit"),I$=[['circuit.Common','java.awt.Color','circuit.Part']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SineWave", null, 'circuit.Part');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I', function (o, c, i1, j1, i2, j2) {
C$.superclazz.c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I.apply(this, [o, c, i1, j1, i2, j2]);
C$.$init$.apply(this);
this.label = (I$[1]||$incl$(1)).LEGEND_VAC;
this.voltRMS = 10;
this.phase = 0;
this.showV = true;
this.showZ = false;
this.showF = true;
this.showPhase = true;
}, 1);

Clazz.newMeth(C$, 'drawLabel$java_awt_Graphics$I$I$I$I', function (g, x, y, xOff, yOff) {
if (this.label == null ) return;
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color((I$[2]||$incl$(2)).black);
g.drawString$S$I$I(this.label, x - 10, y + 5);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'drawSymbol$java_awt_Graphics$I$I$I$I$I', function (g, x1, y1, x2, y2, s) {
g.setColor$java_awt_Color(this.color);
var x = x2 - x1;
var y = -(y2 - y1);
var h = Math.sqrt(x * x + y * y);
if (h < 2 ) return;
var w = (h / 2.0 - 6);
var base_x1 = ((x1 + (x * w) / h)|0);
var base_y1 = ((y1 - (y * w) / h)|0);
var base_x2 = ((x2 - (x * w) / h)|0);
var base_y2 = ((y2 + (y * w) / h)|0);
g.drawLine$I$I$I$I(x1, y1, base_x1, base_y1);
g.drawLine$I$I$I$I(x2, y2, base_x2, base_y2);
g.fillOval$I$I$I$I(((x1 + x2)/2|0) - 15, ((y1 + y2)/2|0) - 15, 30, 30);
g.setColor$java_awt_Color((I$[2]||$incl$(2)).white);
g.fillOval$I$I$I$I(((x1 + x2)/2|0) - 13, ((y1 + y2)/2|0) - 13, 26, 26);
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color((I$[2]||$incl$(2)).black);
g.drawString$S$I$I("+", (base_x1 + 20), (base_y1));
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'getMSHint', function () {
var msg = "";
if (this.showV) msg += (I$[1]||$incl$(1)).LEGEND_VEQU + this.format.form$D(this.voltRMS);
if (this.showF) msg += " " + (I$[1]||$incl$(1)).LEGEND_FREQ + this.format.form$D(this.freq) + "Hz  " ;
if (this.showPhase) msg += "phi=" + this.format.form$D(this.phase) + " " ;
if (msg.trim().length$() == 0) msg = (I$[1]||$incl$(1)).LEGEND_NOVALUE;
return msg;
});

Clazz.newMeth(C$, 'getHint', function () {
if (this.customHint != null ) return this.customHint;
if (P$.Part.isMicrosoft()) {
return this.getMSHint();
}var msg = "";
if (this.showV) msg += (I$[1]||$incl$(1)).LEGEND_VEQU + this.format.form$D(this.voltRMS);
if (this.showF) msg += " " + (I$[1]||$incl$(1)).LEGEND_FREQ + this.format.form$D(this.freq) + "Hz  " ;
if (this.showPhase) msg += (I$[3]||$incl$(3)).phi + "=" + this.format.form$D(this.phase) + (I$[3]||$incl$(3)).degree + "  " ;
if (msg.trim().length$() == 0) msg = (I$[1]||$incl$(1)).LEGEND_NOVALUE;
return msg;
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:36:46
