(function(){var P$=Clazz.newPackage("circuitsimulator"),p$1={},I$=[[0,'java.awt.Color','java.awt.Font','edu.davidson.display.Format','java.awt.Cursor','edu.davidson.tools.SApplet','edu.davidson.tools.SUtil','edu.davidson.graphics.Util','circuitsimulator.Circuit','Thread']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "CircuitElement", null, 'java.awt.Canvas', 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.value=0;
this.frequency=0;
this.$function=null;
this.direction=0;
this.inputIndex=0;
this.cirim=null;
this.$font=null;
this.format=null;
this.circuit=null;
this.circuitCanvas=null;
this.$x=0;
this.$y=0;
this.label=null;
this.unity=null;
this.imagename=null;
this.otherElem=null;
this.canvasElement=false;
this.vequation=null;
this.numberOfNodes=0;
this.row=0;
this.col=0;
this.to=null;
this.polarity=null;
this.polarized=false;
this.leftlinear=false;
this.rightlinear=false;
this.valueVisible=false;
this.imageVisible=false;
this.variableImage=false;
this.reverseEquation=false;
this.overloaded=false;
this.maxCurrentValue=0;
this.parsedbgColor=null;
this.varStrings=null;
this.vars=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$function="";
this.label="";
this.unity="";
this.imagename="";
this.otherElem=null;
this.canvasElement=true;
this.numberOfNodes=2;
this.polarized=false;
this.leftlinear=true;
this.rightlinear=true;
this.valueVisible=true;
this.imageVisible=true;
this.variableImage=false;
this.reverseEquation=false;
this.overloaded=false;
this.maxCurrentValue=10.0;
this.parsedbgColor=Clazz.new_(Clazz.load('java.awt.Color').c$$I$I$I,[255, 255, 185]);
this.varStrings=Clazz.array(String, -1, ["t", "v", "i"]);
this.vars=Clazz.array(Double.TYPE, [1, 3]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.value=0.0;
this.direction=0;
this.inputIndex=0;
this.row=this.col=0;
this.to="h";
this.cirim=null;
this.vequation=null;
this.$font=Clazz.new_(Clazz.load('java.awt.Font').c$$S$I$I,["TimesRoman", 0, 10]);
this.format=Clazz.new_(Clazz.load('edu.davidson.display.Format').c$$S,["%.3g"]);
this.imagename += this.getMyName$();
this.canvasElement=false;
this.setValueVisible$Z(false);
this.setBounds$I$I$I$I(0, 2, 52, 22);
this.setCursor$java_awt_Cursor(Clazz.load('java.awt.Cursor').getPredefinedCursor$I(12));
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit', function (circ) {
Clazz.super_(C$, this,1);
this.circuit=circ;
this.circuitCanvas=circ.circanvas;
this.value=0.0;
this.direction=0;
this.inputIndex=0;
this.row=this.col=0;
this.to="";
this.cirim=null;
this.vequation=null;
this.$font=Clazz.new_($I$(2).c$$S$I$I,["TimesRoman", 0, 10]);
this.format=Clazz.new_($I$(3).c$$S,["%.3g"]);
this.imagename += this.getMyName$();
this.canvasElement=false;
this.setValueVisible$Z(false);
this.setBounds$I$I$I$I(0, 2, 52, 22);
this.setCursor$java_awt_Cursor($I$(4).getPredefinedCursor$I(12));
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$S', function (circ, r, c, t) {
Clazz.super_(C$, this,1);
this.circuit=circ;
this.circuitCanvas=circ.circanvas;
this.value=1.0;
this.direction=0;
this.inputIndex=0;
this.row=r;
this.col=c;
this.to="" + t;
this.vequation=null;
this.imagename += this.getMyName$();
this.$font=Clazz.new_($I$(2).c$$S$I$I,["TimesRoman", 0, 10]);
this.format=Clazz.new_($I$(3).c$$S,["%.3g"]);
this.cirim=null;
try {
Clazz.load('edu.davidson.tools.SApplet').addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$I$S', function (circ, pol, r, c, t) {
C$.c$$circuitsimulator_Circuit$I$I$S.apply(this, [circ, r, c, t]);
this.polarized=true;
if (pol == 1) {
this.polarity="p";
this.direction=this.to.equals$O("h") ? 2 : 1;
} else {
this.polarity="m";
this.direction=this.to.equals$O("h") ? 0 : 3;
}}, 1);

Clazz.newMeth(C$, 'setCircuit$circuitsimulator_Circuit', function (circ) {
this.circuit=circ;
this.repaint$();
});

Clazz.newMeth(C$, 'set$S', function (list) {
list=list.toLowerCase$().trim$();
list=Clazz.load('edu.davidson.tools.SUtil').removeWhitespace$S(list);
if ($I$(6).parameterExist$S$S(list, "row=")) this.row=($I$(6).getParam$S$S(list, "row=")|0);
if ($I$(6).parameterExist$S$S(list, "col=")) this.col=($I$(6).getParam$S$S(list, "col=")|0);
if ($I$(6).parameterExist$S$S(list, "to=")) this.to="" + $I$(6).getParamStr$S$S(list, "to=");
if ($I$(6).parameterExist$S$S(list, "d=")) {
var pol=($I$(6).getParam$S$S(list, "d=")|0);
if (pol == 1) {
this.polarity="p";
this.direction=this.to.equals$O("h") ? 2 : 1;
} else {
this.polarity="m";
this.direction=this.to.equals$O("h") ? 0 : 3;
}}if ($I$(6).parameterExist$S$S(list, "func=")) this.$function="" + $I$(6).getParamStr$S$S(list, "func=");
if ($I$(6).parameterExist$S$S(list, "freq=")) this.frequency=$I$(6).getParam$S$S(list, "freq=");
return true;
});

Clazz.newMeth(C$, 'valueStr$', function () {
return this.format.form$D(this.value);
});

Clazz.newMeth(C$, 'setValueVisible$Z', function (b) {
this.valueVisible=b;
});

Clazz.newMeth(C$, 'setImageVisible$Z', function (b) {
this.imageVisible=b;
});

Clazz.newMeth(C$, 'setImage$S', function (gifname) {
if (gifname.equals$O("")) this.setImageVisible$Z(false);
 else this.imagename += gifname;
return true;
});

Clazz.newMeth(C$, 'changePolarity$', function () {
if (this.polarized) {
if (this.polarity.equals$O("m")) {
this.polarity="p";
this.direction=this.to.equals$O("h") ? 2 : 1;
} else {
this.polarity="m";
this.direction=this.to.equals$O("h") ? 0 : 3;
}}});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
this.format=Clazz.new_($I$(3).c$$S,[str]);
});

Clazz.newMeth(C$, 'setFont$java_awt_Font', function (nfont) {
this.$font=Clazz.new_($I$(2).c$$S$I$I,[nfont.getFamily$(), nfont.getStyle$(), nfont.getSize$()]);
});

Clazz.newMeth(C$, 'setvalue$S', function (s) {
this.value=(Double.valueOf$S(s)).doubleValue$();
});

Clazz.newMeth(C$, 'setFrequency$D', function (freq) {
this.frequency=freq;
});

Clazz.newMeth(C$, 'setlabel$S', function (l) {
this.label="" + l;
});

Clazz.newMeth(C$, 'setdirection$I', function (d) {
this.direction=d;
});

Clazz.newMeth(C$, 'setMaxCurrentValue$S', function (s) {
this.maxCurrentValue=(Double.valueOf$S(s)).doubleValue$();
});

Clazz.newMeth(C$, 'move$I$I$S', function (r, c, t) {
if (!t.equals$O(this.to)) this.cirim=null;
this.row=r;
this.col=c;
this.to="" + t;
});

Clazz.newMeth(C$, 'impedance$', function () {
return (this.reverseEquation) ? 1.0 : 0.0;
});

Clazz.newMeth(C$, 'impedanceCoupled$', function () {
return 0.0;
});

Clazz.newMeth(C$, 'indexVHere$', function () {
return (this.reverseEquation) ? 0.0 : -1.0;
});

Clazz.newMeth(C$, 'indexVNext$', function () {
return (this.reverseEquation) ? 0.0 : 1.0;
});

Clazz.newMeth(C$, 'integralVHere$', function () {
return 0.0;
});

Clazz.newMeth(C$, 'integralVNext$', function () {
return 0.0;
});

Clazz.newMeth(C$, 'input$D', function (sign) {
return 0.0;
});

Clazz.newMeth(C$, 'differential$', function () {
return 0.0;
});

Clazz.newMeth(C$, 'differentialCoupled$', function () {
return 0.0;
});

Clazz.newMeth(C$, 'rightFunction$D', function (sign) {
return 0.0;
});

Clazz.newMeth(C$, 'coupledTo$circuitsimulator_CircuitElement', function (other) {
this.otherElem=other;
});

Clazz.newMeth(C$, 'indexIcoupled$', function () {
return this.otherElem.vequation.indexI1;
});

Clazz.newMeth(C$, 'getvalue$', function () {
return Double.toString$D(this.value);
});

Clazz.newMeth(C$, 'getlabel$', function () {
return this.label;
});

Clazz.newMeth(C$, 'getunity$', function () {
return this.unity;
});

Clazz.newMeth(C$, 'getI$', function () {
var i=0;
try {
i=this.circuit.cirgrid.y[this.circuit.cirgrid.numberOfV + this.vequation.indexI1];
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
return i;
});

Clazz.newMeth(C$, 'getV$', function () {
var v=0;
try {
v=this.circuit.cirgrid.y[this.vequation.indexV2] - this.circuit.cirgrid.y[this.vequation.indexV1];
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
return v;
});

Clazz.newMeth(C$, 'gett$', function () {
return this.circuit.realt;
});

Clazz.newMeth(C$, 'getMyName$', function () {
var name=this.getClass$().getName$().toLowerCase$();
return name.substring$I(name.indexOf$S(".") + 1);
});

Clazz.newMeth(C$, 'getAddObjectString$', function () {
var s="addObject(\"" + this.circuit.cirProp.getProperty$S(this.getMyName$()) + "\",\"row=" + this.row + ",col=" + this.col + ",to=" + this.to + ",label=" + this.label ;
if (this.polarized) s += (this.polarity.equals$O("p")) ? ",d=1" : ",d=-1";
s += this.getStringAdditions$() + "\");\n";
return s;
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return "";
});

Clazz.newMeth(C$, 'get$', function () {
if (this.getStringAdditions$().length$() == 0) return "";
return this.getStringAdditions$().substring$I(1);
});

Clazz.newMeth(C$, 'loadImage$java_awt_Graphics', function (g) {
if (this.cirim == null  || this.overloaded ) {
this.overloaded=false;
if (this.imagename == null  || this.imagename.trim$().equals$O("") ) {
this.cirim=null;
} else {
this.cirim=Clazz.load('edu.davidson.graphics.Util').getImage$S$java_applet_Applet(this.circuit.imagedir + this.imagename + this.to + ".gif" , this.circuit);
}}if (this.cirim != null ) {
if (this.to.equals$O("h")) {
g.drawLine$I$I$I$I(this.$x + 3, this.$y, this.$x + (this.circuit.interGrid/2|0) - 24, this.$y);
g.drawLine$I$I$I$I(this.$x + (this.circuit.interGrid/2|0) + 24, this.$y, this.$x + this.circuit.interGrid - 4, this.$y);
} else {
g.drawLine$I$I$I$I(this.$x, this.$y + 3, this.$x, this.$y + (this.circuit.interGrid/2|0) - 24);
g.drawLine$I$I$I$I(this.$x, this.$y + (this.circuit.interGrid/2|0) + 24, this.$x, this.$y + this.circuit.interGrid - 4);
}var ox=this.to.equals$O("h") ? ((this.circuit.interGrid/2|0)) - 24 : -6;
var oy=this.to.equals$O("h") ? -6 : ((this.circuit.interGrid/2|0)) - 24;
while (!(g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.cirim, this.$x + ox, this.$y + oy, this.circuitCanvas)))if (!Clazz.load('circuitsimulator.Circuit').isJS) try {
Clazz.load('Thread').sleep$J(100);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}

} else {
g.setColor$java_awt_Color($I$(1).red);
g.setFont$java_awt_Font(Clazz.new_($I$(2).c$$S$I$I,["TimesRoman", 1, 22]));
if (this.to.equals$O("h")) {
g.drawLine$I$I$I$I(this.$x + 3, this.$y, this.$x + (this.circuit.interGrid/2|0) - 6, this.$y);
g.drawLine$I$I$I$I(this.$x + (this.circuit.interGrid/2|0) + 6, this.$y, this.$x + this.circuit.interGrid - 4, this.$y);
g.setColor$java_awt_Color($I$(1).black);
g.drawString$S$I$I("?", this.$x - 6 + (this.circuit.interGrid/2|0), this.$y + 6);
} else {
g.drawLine$I$I$I$I(this.$x, this.$y + 3, this.$x, this.$y + (this.circuit.interGrid/2|0) - 10);
g.drawLine$I$I$I$I(this.$x, this.$y + (this.circuit.interGrid/2|0) + 10, this.$x, this.$y + this.circuit.interGrid - 4);
g.setColor$java_awt_Color($I$(1).black);
g.drawString$S$I$I("?", this.$x - 4, this.$y + 8 + (this.circuit.interGrid/2|0) );
}g.setColor$java_awt_Color($I$(1).red);
g.setFont$java_awt_Font(this.$font);
}});

Clazz.newMeth(C$, 'overload$java_awt_Graphics', function (g) {
var ox=this.to.equals$O("h") ? ((this.circuit.interGrid/2|0)) - 24 : -24;
var oy=this.to.equals$O("h") ? -24 : ((this.circuit.interGrid/2|0)) - 24;
this.cirim=$I$(7).getImage$S$java_applet_Applet(this.circuit.imagedir + "fire.gif", this.circuit);
if (this.cirim != null ) while (!(g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.cirim, this.$x + ox, this.$y + oy, this.circuitCanvas))){
if (!$I$(8).isJS) try {
$I$(9).sleep$J(100);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}
}
this.overloaded=true;
});

Clazz.newMeth(C$, 'unknownImage$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color($I$(1).red);
g.setFont$java_awt_Font(Clazz.new_($I$(2).c$$S$I$I,["TimesRoman", 1, 12]));
if (this.to.equals$O("h")) {
g.drawLine$I$I$I$I(this.$x + 3, this.$y, this.$x + (this.circuit.interGrid/2|0) - 13, this.$y);
g.drawLine$I$I$I$I(this.$x + (this.circuit.interGrid/2|0) + 13, this.$y, this.$x + this.circuit.interGrid - 4, this.$y);
g.drawRect$I$I$I$I(this.$x + (this.circuit.interGrid/2|0) - 13, this.$y - 6, 25, 13);
g.setColor$java_awt_Color($I$(1).black);
g.drawString$S$I$I("Z", this.$x - 4 + (this.circuit.interGrid/2|0), this.$y + 6);
} else {
g.drawLine$I$I$I$I(this.$x, this.$y + 3, this.$x, this.$y + (this.circuit.interGrid/2|0) - 13);
g.drawLine$I$I$I$I(this.$x, this.$y + (this.circuit.interGrid/2|0) + 13, this.$x, this.$y + this.circuit.interGrid - 4);
g.drawRect$I$I$I$I(this.$x - 6, this.$y + (this.circuit.interGrid/2|0) - 13, 13, 25);
g.setColor$java_awt_Color($I$(1).black);
g.drawString$S$I$I("Z", this.$x - 2, this.$y + 5 + (this.circuit.interGrid/2|0) );
}g.setColor$java_awt_Color($I$(1).red);
g.setFont$java_awt_Font(this.$font);
});

Clazz.newMeth(C$, 'showArrows$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color($I$(1).white);
if (this.getI$() != 0 ) {
if (this.to.equals$O("h")) {
g.fillRect$I$I$I$I(this.$x + 22, this.$y + 6, 11, 5);
g.setColor$java_awt_Color($I$(1).blue);
g.drawLine$I$I$I$I(this.$x + 22, this.$y + 8, this.$x + 32, this.$y + 8);
if ((this.vequation.direction == 2 && this.getI$() > 0  ) || (this.vequation.direction == 0 && this.getI$() < 0  ) ) {
g.drawLine$I$I$I$I(this.$x + 29, this.$y + 6, this.$x + 32, this.$y + 8);
g.drawLine$I$I$I$I(this.$x + 29, this.$y + 10, this.$x + 32, this.$y + 8);
} else {
g.drawLine$I$I$I$I(this.$x + 22, this.$y + 8, this.$x + 25, this.$y + 6);
g.drawLine$I$I$I$I(this.$x + 22, this.$y + 8, this.$x + 25, this.$y + 10);
}} else {
g.fillRect$I$I$I$I(this.$x - 10, this.$y + 22, 5, 11);
g.setColor$java_awt_Color($I$(1).blue);
g.drawLine$I$I$I$I(this.$x - 8, this.$y + 22, this.$x - 8, this.$y + 32);
if ((this.vequation.direction == 1 && this.getI$() > 0  ) || (this.vequation.direction == 3 && this.getI$() < 0  ) ) {
g.drawLine$I$I$I$I(this.$x - 6, this.$y + 29, this.$x - 8, this.$y + 32);
g.drawLine$I$I$I$I(this.$x - 10, this.$y + 29, this.$x - 8, this.$y + 32);
} else {
g.drawLine$I$I$I$I(this.$x - 8, this.$y + 22, this.$x - 6, this.$y + 25);
g.drawLine$I$I$I$I(this.$x - 8, this.$y + 22, this.$x - 10, this.$y + 25);
}}}}, p$1);

Clazz.newMeth(C$, 'showValue$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color($I$(1).blue);
if (this.to.equals$O("h")) g.drawString$S$I$I(this.valueStr$(), this.$x + (this.circuit.interGrid/2|0) - 17, this.$y - 6);
 else g.drawString$S$I$I(this.valueStr$(), this.$x + 7, this.$y + (this.circuit.interGrid/2|0) - 1);
});

Clazz.newMeth(C$, 'showSigns$java_awt_Graphics', function (g) {
var p=this.polarity.equals$O("p") ? this.circuit.interGrid - 11 : 6;
g.setColor$java_awt_Color($I$(1).red);
if (this.to.equals$O("h")) {
g.fillRect$I$I$I$I(this.$x + p, this.$y - 4, 6, 2);
g.fillRect$I$I$I$I(this.$x + p + 2 , this.$y - 6, 2, 6);
g.setColor$java_awt_Color($I$(1).black);
g.fillRect$I$I$I$I(this.$x + this.circuit.interGrid - 5 - p, this.$y - 4, 6, 2);
} else {
g.fillRect$I$I$I$I(this.$x + 2, this.$y + p, 6, 2);
g.fillRect$I$I$I$I(this.$x + 4, this.$y + p - 2, 2, 6);
g.setColor$java_awt_Color($I$(1).black);
g.fillRect$I$I$I$I(this.$x + 2, this.$y + this.circuit.interGrid - 5 - p + 2, 6, 2);
}});

Clazz.newMeth(C$, 'repaintImage$java_awt_Graphics', function (g) {
if (this.circuit.parsed && this.circuit.showCurrent ) p$1.showArrows$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color($I$(1).red);
if (this.circuit != null  && this.canvasElement ) {
this.$x=((this.circuit.interGrid * (this.col + 0.5))|0);
this.$y=((this.circuit.interGrid * (this.row + 0.5))|0);
var cig=(this.circuit.interGrid/2|0);
g.setFont$java_awt_Font(this.$font);
if (this.imageVisible) this.loadImage$java_awt_Graphics(g);
 else this.unknownImage$java_awt_Graphics(g);
if (this.valueVisible) this.showValue$java_awt_Graphics(g);
g.setColor$java_awt_Color($I$(1).black);
if (this.to.equals$O("h")) g.drawString$S$I$I(this.label, this.$x + cig - 4, this.$y - 14);
 else g.drawString$S$I$I(this.label, this.$x + 7, this.$y + cig + 7 );
if (this.circuit.parsed && this.circuit.showCurrent ) p$1.showArrows$java_awt_Graphics.apply(this, [g]);
g.setColor$java_awt_Color($I$(1).red);
if (this.circuit.parsed && this.maxCurrentValue <= Math.abs(this.getI$())  ) {
this.overload$java_awt_Graphics(g);
this.circuit.pause$();
}if (this.polarized) this.showSigns$java_awt_Graphics(g);
} else {
this.$x=0;
this.$y=10;
this.loadImage$java_awt_Graphics(g);
}});

Clazz.newMeth(C$, 'getCoupledID$', function () {
return this.otherElem.getID$();
});

Clazz.newMeth(C$, 'getVariables$', function () {
this.vars[0][0]=this.circuit.clock.getTime$();
this.vars[0][1]=this.getV$();
this.vars[0][2]=this.getI$();
return this.vars;
});

Clazz.newMeth(C$, 'getVarStrings$', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID$', function () {
return this.hashCode$();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (o) {
this.circuit=o;
});

Clazz.newMeth(C$, 'getOwner$', function () {
return this.circuit;
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:15 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
