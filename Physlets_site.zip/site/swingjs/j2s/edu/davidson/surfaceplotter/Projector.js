(function(){var P$=Clazz.newPackage("edu.davidson.surfaceplotter"),I$=[['java.awt.Point']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Projector");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.scale_x = 0;
this.scale_y = 0;
this.scale_z = 0;
this.distance = 0;
this._2D_scale = 0;
this.rotation = 0;
this.elevation = 0;
this.sin_rotation = 0;
this.cos_rotation = 0;
this.sin_elevation = 0;
this.cos_elevation = 0;
this._2D_trans_x = 0;
this._2D_trans_y = 0;
this.x1 = 0;
this.x2 = 0;
this.y1 = 0;
this.y2 = 0;
this.center_x = 0;
this.center_y = 0;
this.trans_x = 0;
this.trans_y = 0;
this.factor = 0;
this.sx_cos = 0;
this.sy_cos = 0;
this.sz_cos = 0;
this.sx_sin = 0;
this.sy_sin = 0;
this.sz_sin = 0;
this.DEGTORAD = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.DEGTORAD = 0.017453292;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.setScaling$F(1);
this.setRotationAngle$F(0);
this.setElevationAngle$F(0);
this.setDistance$F(10);
this.set2DScaling$F(1);
this.set2DTranslation$I$I(0, 0);
}, 1);

Clazz.newMeth(C$, 'setProjectionArea$java_awt_Rectangle', function (r) {
this.x1 = r.x;
this.x2 = this.x1 + r.width;
this.y1 = r.y;
this.y2 = this.y1 + r.height;
this.center_x = ((this.x1 + this.x2)/2|0);
this.center_y = ((this.y1 + this.y2)/2|0);
this.trans_x = this.center_x + this._2D_trans_x;
this.trans_y = this.center_y + this._2D_trans_y;
});

Clazz.newMeth(C$, 'setRotationAngle$F', function (angle) {
this.rotation = angle;
this.sin_rotation = Math.sin(angle * 0.017453292);
this.cos_rotation = Math.cos(angle * 0.017453292);
this.sx_cos = -this.scale_x * this.cos_rotation;
this.sx_sin = -this.scale_x * this.sin_rotation;
this.sy_cos = -this.scale_y * this.cos_rotation;
this.sy_sin = this.scale_y * this.sin_rotation;
});

Clazz.newMeth(C$, 'getRotationAngle', function () {
return this.rotation;
});

Clazz.newMeth(C$, 'getSinRotationAngle', function () {
return this.sin_rotation;
});

Clazz.newMeth(C$, 'getCosRotationAngle', function () {
return this.cos_rotation;
});

Clazz.newMeth(C$, 'setElevationAngle$F', function (angle) {
this.elevation = angle;
this.sin_elevation = Math.sin(angle * 0.017453292);
this.cos_elevation = Math.cos(angle * 0.017453292);
this.sz_cos = this.scale_z * this.cos_elevation;
this.sz_sin = this.scale_z * this.sin_elevation;
});

Clazz.newMeth(C$, 'getElevationAngle', function () {
return this.elevation;
});

Clazz.newMeth(C$, 'getSinElevationAngle', function () {
return this.sin_elevation;
});

Clazz.newMeth(C$, 'getCosElevationAngle', function () {
return this.cos_elevation;
});

Clazz.newMeth(C$, 'setDistance$F', function (new_distance) {
this.distance = new_distance;
this.factor = this.distance * this._2D_scale;
});

Clazz.newMeth(C$, 'getDistance', function () {
return this.distance;
});

Clazz.newMeth(C$, 'setXScaling$F', function (scaling) {
this.scale_x = scaling;
this.sx_cos = -this.scale_x * this.cos_rotation;
this.sx_sin = -this.scale_x * this.sin_rotation;
});

Clazz.newMeth(C$, 'getXScaling', function () {
return this.scale_x;
});

Clazz.newMeth(C$, 'setYScaling$F', function (scaling) {
this.scale_y = scaling;
this.sy_cos = -this.scale_y * this.cos_rotation;
this.sy_sin = this.scale_y * this.sin_rotation;
});

Clazz.newMeth(C$, 'getYScaling', function () {
return this.scale_y;
});

Clazz.newMeth(C$, 'setZScaling$F', function (scaling) {
this.scale_z = scaling;
this.sz_cos = this.scale_z * this.cos_elevation;
this.sz_sin = this.scale_z * this.sin_elevation;
});

Clazz.newMeth(C$, 'getZScaling', function () {
return this.scale_z;
});

Clazz.newMeth(C$, 'setScaling$F$F$F', function (x, y, z) {
this.scale_x = x;
this.scale_y = y;
this.scale_z = z;
this.sx_cos = -this.scale_x * this.cos_rotation;
this.sx_sin = -this.scale_x * this.sin_rotation;
this.sy_cos = -this.scale_y * this.cos_rotation;
this.sy_sin = this.scale_y * this.sin_rotation;
this.sz_cos = this.scale_z * this.cos_elevation;
this.sz_sin = this.scale_z * this.sin_elevation;
});

Clazz.newMeth(C$, 'setScaling$F', function (scaling) {
this.scale_x = this.scale_y = this.scale_z = scaling;
this.sx_cos = -this.scale_x * this.cos_rotation;
this.sx_sin = -this.scale_x * this.sin_rotation;
this.sy_cos = -this.scale_y * this.cos_rotation;
this.sy_sin = this.scale_y * this.sin_rotation;
this.sz_cos = this.scale_z * this.cos_elevation;
this.sz_sin = this.scale_z * this.sin_elevation;
});

Clazz.newMeth(C$, 'set2DScaling$F', function (scaling) {
this._2D_scale = scaling;
this.factor = this.distance * this._2D_scale;
});

Clazz.newMeth(C$, 'get2DScaling', function () {
return this._2D_scale;
});

Clazz.newMeth(C$, 'set2DTranslation$I$I', function (x, y) {
this._2D_trans_x = x;
this._2D_trans_y = y;
this.trans_x = this.center_x + this._2D_trans_x;
this.trans_y = this.center_y + this._2D_trans_y;
});

Clazz.newMeth(C$, 'set2D_xTranslation$I', function (x) {
this._2D_trans_x = x;
this.trans_x = this.center_x + this._2D_trans_x;
});

Clazz.newMeth(C$, 'get2D_xTranslation', function () {
return this._2D_trans_x;
});

Clazz.newMeth(C$, 'set2D_yTranslation$I', function (y) {
this._2D_trans_y = y;
this.trans_y = this.center_y + this._2D_trans_y;
});

Clazz.newMeth(C$, 'get2D_yTranslation', function () {
return this._2D_trans_y;
});

Clazz.newMeth(C$, 'project$F$F$F', function (x, y, z) {
var temp;
temp = x;
x = x * this.sx_cos + y * this.sy_sin;
y = temp * this.sx_sin + y * this.sy_cos;
temp = this.factor / (y * this.cos_elevation - z * this.sz_sin + this.distance);
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[(Math.round(x * temp) + this.trans_x), (Math.round((y * this.sin_elevation + z * this.sz_cos) * -temp) + this.trans_y)]);
});
})();
//Created 2018-03-16 05:19:02
