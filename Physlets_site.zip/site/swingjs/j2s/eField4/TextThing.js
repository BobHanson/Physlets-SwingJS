(function(){var P$=Clazz.newPackage("eField4"),I$=[[0,'java.awt.Color','java.awt.Font','edu.davidson.numerics.Parser','edu.davidson.tools.SUtil']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "TextThing", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.tempVars=null;
this.calcStr=null;
this.calcFunc=null;
this.text=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.tempVars=Clazz.array(Double.TYPE, [10]);
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$S$S$D$D', function (o, txt, cs, x, y) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [o, x, y, 0, 0]);
C$.$init$.apply(this);
this.color=Clazz.load('java.awt.Color').black;
this.font=Clazz.new_(Clazz.load('java.awt.Font').c$$S$I$I,["Helvetica", 1, 14]);
this.text=txt;
this.calcStr=cs;
if (this.calcStr == null ) return;
this.calcFunc=Clazz.new_(Clazz.load('edu.davidson.numerics.Parser').c$$I,[10]);
this.calcFunc.defineVariable$I$S(1, "t");
this.calcFunc.defineVariable$I$S(2, "x");
this.calcFunc.defineVariable$I$S(3, "y");
this.calcFunc.defineVariable$I$S(4, "vx");
this.calcFunc.defineVariable$I$S(5, "vy");
this.calcFunc.defineVariable$I$S(6, "ax");
this.calcFunc.defineVariable$I$S(7, "ay");
this.calcFunc.defineVariable$I$S(8, "m");
this.calcFunc.defineVariable$I$S(9, "f");
this.calcFunc.defineVariable$I$S(10, "p");
this.calcFunc.define$S(this.calcStr);
this.calcFunc.parse$();
if (this.calcFunc.getErrorCode$() != 0) {
System.out.println$S("Failed to parse calc-text: " + this.calcStr);
System.out.println$S("Parse error: " + this.calcFunc.getErrorString$() + " at function 1, position " + this.calcFunc.getErrorPosition$() );
return;
}}, 1);

Clazz.newMeth(C$, 'getText$', function () {
var val=0;
if (this.calcStr == null ) return this.text;
this.tempVars[0]=this.vars[0];
this.tempVars[1]=this.vars[1];
this.tempVars[2]=this.vars[2];
this.tempVars[3]=this.vars[3];
this.tempVars[4]=this.vars[4];
this.tempVars[5]=this.vars[5];
this.tempVars[6]=this.vars[6];
this.tempVars[7]=this.mass;
this.tempVars[8]=this.flux;
this.tempVars[9]=this.pe;
try {
val=this.calcFunc.evaluate$DA(this.tempVars);
val=Clazz.load('edu.davidson.tools.SUtil').chop$D$D(val, 1.0E-12);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return this.text + " " + this.format.form$D(val) ;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.hideThing) return;
var f=g.getFont$();
g.setFont$java_awt_Font(this.font);
g.setColor$java_awt_Color(this.color);
var ptX=Math.round(this.p.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY=Math.round(this.p.pixFromY$D(this.vars[2])) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.drawString$S$I$I(this.getText$(), ptX, ptY);
g.setColor$java_awt_Color($I$(1).black);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:19 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
