(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['java.awt.event.ActionEvent','java.awt.Color','java.lang.Thread','Thread','java.awt.event.MouseAdapter']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ThreadButton", null, 'java.awt.Button', 'Runnable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.evt = null;
this.backgroundColor = null;
this.downColor = null;
this.thread = null;
this.longTick = 0;
this.shortTick = 0;
this.tick = 0;
this.running = false;
this.count = 0;
this.runLock = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.evt = Clazz.new_((I$[1]||$incl$(1)).c$$O$I$S,[this, 1001, "THREAD"]);
this.backgroundColor = (I$[2]||$incl$(2)).lightGray;
this.downColor = (I$[2]||$incl$(2)).green;
this.thread = null;
this.longTick = 500;
this.shortTick = 100;
this.tick = this.longTick;
this.running = false;
this.count = 0;
this.runLock =  Clazz.new_();
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.thread = Clazz.new_((I$[3]||$incl$(3)).c$$Runnable,[this]);
this.thread.start();
}, 1);

Clazz.newMeth(C$, 'destroy', function () {
{
this.thread = null;
this.running = true;
this.runLock.notifyAll();
}});

Clazz.newMeth(C$, 'startThread', function () {
if (this.thread == null ) {
this.thread = Clazz.new_((I$[3]||$incl$(3)).c$$Runnable,[this]);
this.thread.start();
} else {
this.running = true;
this.runLock.notifyAll();
}});

Clazz.newMeth(C$, 'stopThread', function () {
if (!this.running) return;
this.running = false;
{
;}this.tick = this.longTick;
this.count = 0;
});

Clazz.newMeth(C$, 'run', function () {
this.count = 0;
while (this.thread != null  && this.count < 100000 ){
{
while (this.running == false )try {
this.runLock.wait();
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
} else {
throw ie;
}
}

this.count++;
if (this.thread != null ) this.dispatchEvent$java_awt_AWTEvent(this.evt);
if (this.count > 0) this.tick = this.shortTick;
}if (this.thread != null ) try {
(I$[4]||$incl$(4)).sleep$J(this.tick);
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
} else {
throw ie;
}
}
}
});

Clazz.newMeth(C$, 'jbInit', function () {
this.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "ThreadButton$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.b$['edu.davidson.graphics.ThreadButton'].this_mousePressed$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.b$['edu.davidson.graphics.ThreadButton'].this_mouseReleased$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[5]||$incl$(5)), [this, null],P$.ThreadButton$1)));
});

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
if (this.running) return;
this.running = true;
this.setBackground$java_awt_Color(this.downColor);
p$.startThread.apply(this, []);
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.setBackground$java_awt_Color(this.backgroundColor);
p$.stopThread.apply(this, []);
this.running = false;
});
})();
//Created 2018-02-06 13:05:39
