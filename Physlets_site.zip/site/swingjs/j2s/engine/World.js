(function(){var P$=Clazz.newPackage("engine"),I$=[['java.awt.Point','engine.Point3D','engine.Segment','engine.Particle']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "World", null, 'java.awt.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.offDimension = null;
this.d = null;
this.offImage = null;
this.offGraphics = null;
this.nOfPoints = 0;
this.numLinks = 0;
this.nOfParticles = 0;
this.nOfSegments = 0;
this.posMouse = null;
this.points = null;
this.segments = null;
this.particles = null;
this.traceOn = false;
this.elementSelected = 0;
this.elementType = 0;
this.mouseMode = 0;
this.selectedParticle = 0;
this.updateImmediate = false;
this.xorMode = false;
this.doubleBuffering = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.nOfPoints = 0;
this.numLinks = 0;
this.nOfParticles = 0;
this.nOfSegments = 0;
this.posMouse = Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[0, 0]);
this.points = Clazz.array((I$[2]||$incl$(2)), [1000]);
this.segments = Clazz.array((I$[3]||$incl$(3)), [1000]);
this.particles = Clazz.array((I$[4]||$incl$(4)), [1000]);
this.traceOn = false;
this.elementSelected = 0;
this.elementType = 0;
this.mouseMode = 2;
this.selectedParticle = -1;
this.updateImmediate = true;
this.xorMode = false;
this.doubleBuffering = true;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
for (var j = 0; j < this.points.length; j++) this.points[j] = Clazz.new_((I$[2]||$incl$(2)));

for (var j = 0; j < this.particles.length; j++) this.particles[j] = Clazz.new_((I$[4]||$incl$(4)));

for (var j = 0; j < this.segments.length; j++) this.segments[j] = Clazz.new_((I$[3]||$incl$(3)));

}, 1);

Clazz.newMeth(C$, 'addPoint$I$I$I', function (x1, y1, z1) {
this.nOfPoints++;
this.points[this.nOfPoints - 1].x = x1;
this.points[this.nOfPoints - 1].y = y1;
this.points[this.nOfPoints - 1].z = z1;
});

Clazz.newMeth(C$, 'setPoint$I$I$I$I', function (i, x1, y1, z1) {
this.points[i].x = x1;
this.points[i].y = y1;
this.points[i].y = z1;
});

Clazz.newMeth(C$, 'mouseMove$java_awt_Event$I$I', function (event, x, y) {
this.posMouse.x = x;
this.posMouse.y = y;
return false;
});

Clazz.newMeth(C$, 'mouseDrag$java_awt_Event$I$I', function (event, x, y) {
this.posMouse.x = x;
this.posMouse.y = y;
return false;
});
})();
//Created 2018-02-25 19:20:09
