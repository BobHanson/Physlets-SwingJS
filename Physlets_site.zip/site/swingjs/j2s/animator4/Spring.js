(function(){var P$=Clazz.newPackage("animator4"),I$=[[0,'edu.davidson.numerics.Parser']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Spring", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.hStr=null;
this.vStr=null;
this.hFunc=null;
this.vFunc=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$S$S$S$S', function (o, s, h, v, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.s=s;
this.hStr=h;
this.vStr=v;
this.hFunc=Clazz.new_($I$(1).c$$I,[1]);
this.hFunc.defineVariable$I$S(1, "t");
this.hFunc.define$S(this.hStr);
this.hFunc.parse$();
if (this.hFunc.getErrorCode$() != 0) {
System.out.println$S("Failed to parse horzizontal component of vector: " + this.hStr);
System.out.println$S("Parse error: " + this.hFunc.getErrorString$() + " at function 1, position " + this.hFunc.getErrorPosition$() );
return;
}this.vFunc=Clazz.new_($I$(1).c$$I,[1]);
this.vFunc.defineVariable$I$S(1, "t");
this.vFunc.define$S(this.vStr);
this.vFunc.parse$();
if (this.vFunc.getErrorCode$() != 0) {
System.out.println$S("Failed to parse vertical component of vector: " + this.vStr);
System.out.println$S("Parse error: " + this.vFunc.getErrorString$() + " at function 1, position " + this.vFunc.getErrorPosition$() );
return;
}}, 1);

Clazz.newMeth(C$, 'getHorz$D', function (t) {
var h=0;
try {
h=this.hFunc.evaluate$D(t);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return h;
});

Clazz.newMeth(C$, 'getVert$D', function (t) {
var v=0;
try {
v=this.vFunc.evaluate$D(t);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return v;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX=Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY=Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
var x=this.canvas.pixPerUnit * this.getHorz$D(this.vars[0]);
var y=this.canvas.pixPerUnit * this.getVert$D(this.vars[0]);
g.setColor$java_awt_Color(this.color);
var h=Math.sqrt(x * x + y * y);
if (h > 1 ) {
var u=(x / 16.0 / this.s );
var v=-(y / 16.0 / this.s );
var u0=8 * x / h;
var v0=-8 * y / h;
var x1=ptX;
var y1=ptY;
var x2=x1 + u;
var y2=y1 + v;
var x3=x1 + 2 * u;
var y3=y1 + 2 * v;
for (var count=0; count < 4 * this.s; count++) {
x2=x2 - v0;
y2=y2 + u0;
g.drawLine$I$I$I$I(((x1)|0), ((y1)|0), ((x2)|0), ((y2)|0));
g.drawLine$I$I$I$I(((x2)|0), ((y2)|0), ((x3)|0), ((y3)|0));
x1=x3;
y1=y3;
x2=x1 + u;
y2=y1 + v;
x3=x1 + 2 * u;
y3=y1 + 2 * v;
x2=x2 + v0;
y2=y2 - u0;
g.drawLine$I$I$I$I(((x1)|0), ((y1)|0), ((x2)|0), ((y2)|0));
g.drawLine$I$I$I$I(((x2)|0), ((y2)|0), ((x3)|0), ((y3)|0));
x1=x3;
y1=y3;
x2=x1 + u;
y2=y1 + v;
x3=x1 + 2 * u;
y3=y1 + 2 * v;
}
}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:45 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
