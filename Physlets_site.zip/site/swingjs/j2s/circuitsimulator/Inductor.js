(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'edu.davidson.tools.SUtil']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Inductor", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$S', function (circuit, v, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$S.apply(this, [circuit, r, c, t]);
C$.$init$.apply(this);
this.value=v;
this.unity="H";
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'impedance$', function () {
return this.value / this.circuit.dt;
});

Clazz.newMeth(C$, 'differential$', function () {
return this.value / this.circuit.dt;
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",l=" + Double.toString$D(this.value);
});

Clazz.newMeth(C$, 'set$S', function (list) {
var ret=C$.superclazz.prototype.set$S.apply(this, [list]);
if (Clazz.load('edu.davidson.tools.SUtil').parameterExist$S$S(list, "l=")) this.value=$I$(1).getParam$S$S(list, "l=");
return ret;
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:15 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
