(function(){var P$=Clazz.newPackage("animator4"),I$=[];
var C$=Clazz.newClass(P$, "AnimatorProperties", null, 'java.util.Properties');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.defaultProperties$();
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorProperties', function (defaults) {
C$.superclazz.c$$java_util_Properties.apply(this, [defaults]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getBoolean$S$Z', function (key, def) {
var val=this.getProperty$S(key);
if (val != null ) {
if ("true".equalsIgnoreCase$S(val.trim$())) return true;
 else if ("false".equalsIgnoreCase$S(val.trim$())) return false;
}return def;
});

Clazz.newMeth(C$, 'getColor$S$java_awt_Color', function (key, def) {
var val=this.getProperty$S(key);
if (val != null ) {
var tkn=Clazz.new_(Clazz.load('java.util.StringTokenizer').c$$S,[val]);
try {
var r=Integer.parseInt$S(tkn.nextToken$());
var g=Integer.parseInt$S(tkn.nextToken$());
var b=Integer.parseInt$S(tkn.nextToken$());
return Clazz.new_(Clazz.load('java.awt.Color').c$$I$I$I,[r, g, b]);
} catch (x) {
if (Clazz.exceptionOf(x,"NumberFormatException")){
return def;
} else {
throw x;
}
}
}return def;
});

Clazz.newMeth(C$, 'getDouble$S$D', function (key, def) {
var val=this.getProperty$S(key);
var i=def;
if (val != null ) {
try {
i=Double.valueOf$S(val.trim$()).doubleValue$();
} catch (x) {
if (Clazz.exceptionOf(x,"NumberFormatException")){
} else {
throw x;
}
}
}return i;
});

Clazz.newMeth(C$, 'getInt$S$I', function (key, def) {
var val=this.getProperty$S(key);
var i=def;
if (val != null ) {
try {
i=Integer.parseInt$S(val.trim$());
} catch (x) {
if (Clazz.exceptionOf(x,"NumberFormatException")){
} else {
throw x;
}
}
}return i;
});

Clazz.newMeth(C$, 'getString$S$S', function (key, def) {
var val=this.getProperty$S(key);
if (val != null ) {
var len=val.length$();
var st=0;
while ((st < len) && (val.charAt$I(st) != "\"") ){
st++;
}
st++;
while ((st < len) && (val.charAt$I(len - 1) != "\"") ){
len--;
}
len--;
if (st < len) return val.substring$I$I(st, len);
}return def;
});

Clazz.newMeth(C$, 'getkey$S', function (value) {
var key="";
for (var e=this.propertyNames$(); e.hasMoreElements$(); ) {
key=e.nextElement$();
if (this.getProperty$S(key).equals$O(value)) return key;
}
return value;
});

Clazz.newMeth(C$, 'defaultProperties$', function () {
this.put$TK$TV("time", "Time");
this.put$TK$TV("collision", "Collision");
this.put$TK$TV("play_btn", "Play");
this.put$TK$TV("pause_btn", "Pause");
this.put$TK$TV("reset_btn", "Reset");
this.put$TK$TV("step_forward_btn", ">>");
this.put$TK$TV("step_back_btn", "<<");
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:12 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
