(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['edu.davidson.graphics.HintPanel','java.awt.BorderLayout','java.awt.Insets','edu.davidson.graphics.DrawnRectangle']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Border", null, 'a2s.Panel');
C$._defaultThickness = 0;
C$._defaultGap = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$._defaultThickness = 2;
C$._defaultGap = 0;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.thickness = 0;
this.gap = 0;
this.$border = null;
this.borderMe = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$java_awt_Component$I$I.apply(this, [Clazz.new_((I$[1]||$incl$(1))), C$._defaultThickness, C$._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component', function (borderMe) {
C$.c$$java_awt_Component$I$I.apply(this, [borderMe, C$._defaultThickness, C$._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I', function (borderMe, thickness) {
C$.c$$java_awt_Component$I$I.apply(this, [borderMe, thickness, C$._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I$I', function (borderMe, thickness, gap) {
Clazz.super_(C$, this,1);
this.borderMe = borderMe;
this.thickness = thickness;
this.gap = gap;
this.setLayout$java_awt_LayoutManager(Clazz.new_((I$[2]||$incl$(2))));
this.add$java_awt_Component$O(borderMe, "Center");
}, 1);

Clazz.newMeth(C$, 'getComponent', function () {
return this.borderMe;
});

Clazz.newMeth(C$, 'getInnerBounds', function () {
return this.myBorder().getInnerBounds();
});

Clazz.newMeth(C$, 'setLineColor$java_awt_Color', function (c) {
this.myBorder().setLineColor$java_awt_Color(c);
this.repaint();
});

Clazz.newMeth(C$, 'getLineColor', function () {
return this.myBorder().getLineColor();
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.myBorder().paint();
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'getInsets', function () {
return Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I$I,[this.thickness + this.gap, this.thickness + this.gap, this.thickness + this.gap, this.thickness + this.gap]);
});

Clazz.newMeth(C$, 'setSize$I$I', function (w, h) {
var location = this.getLocation();
this.setBounds$I$I$I$I(location.x, location.y, w, h);
});

Clazz.newMeth(C$, 'setBounds$I$I$I$I', function (x, y, w, h) {
C$.superclazz.prototype.setBounds$I$I$I$I.apply(this, [x, y, w, h]);
this.myBorder().setSize$I$I(w, h);
});

Clazz.newMeth(C$, 'paramString', function () {
return C$.superclazz.prototype.paramString.apply(this, []) + ",border=" + this.myBorder().toString() + ",thickness=" + this.thickness + ",gap=" + this.gap ;
});

Clazz.newMeth(C$, 'myBorder', function () {
if (this.$border == null ) this.$border = Clazz.new_((I$[4]||$incl$(4)).c$$java_awt_Component$I,[this, this.thickness]);
return this.$border;
});

Clazz.newMeth(C$, 'setHint$S', function (s) {
if (Clazz.instanceOf(this.borderMe, "edu.davidson.graphics.HintPanel")) (this.borderMe).setBubbleHelp$S(s);
});

Clazz.newMeth(C$, 'setThickness$I', function (t) {
this.thickness = t;
this.myBorder().setThickness$I(t);
this.repaint();
});

Clazz.newMeth(C$, 'getThickness', function () {
return this.thickness;
});

Clazz.newMeth(C$, 'setGap$I', function (g) {
this.gap = g;
this.repaint();
});

Clazz.newMeth(C$, 'getGap', function () {
return this.gap;
});

Clazz.newMeth(C$, 'setFillColor$java_awt_Color', function (c) {
this.myBorder().setFillColor$java_awt_Color(c);
this.repaint();
});

Clazz.newMeth(C$, 'getFillColor', function () {
return this.myBorder().getFillColor();
});
})();
//Created 2018-02-06 13:24:18
