(function(){var P$=Clazz.newPackage("emwave4"),I$=[[0,'java.util.Vector','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ThreeDPanel", null, 'java.awt.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.theta=0;
this.alpha=0;
this.phi=0;
this.trans=null;
this.figs=null;
this.osi=null;
this.iwidth=0;
this.iheight=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.trans=Clazz.array(Double.TYPE, [2, 3]);
this.figs=Clazz.new_($I$(1));
this.osi=null;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'setIsometric$', function () {
this.trans[0][0]=-1 / Math.sqrt(2);
this.trans[0][1]=-this.trans[0][0];
this.trans[0][2]=0;
this.trans[1][0]=-1 / Math.sqrt(6);
this.trans[1][1]=this.trans[1][0];
this.trans[1][2]=-2 * this.trans[1][0];
this.repaint$();
});

Clazz.newMeth(C$, 'transformMatrix$', function () {
this.trans[0][0]=(Math.cos(this.alpha) * Math.cos(this.theta));
this.trans[0][1]=-(-Math.cos(this.alpha) * Math.sin(this.theta));
this.trans[0][2]=(-Math.sin(this.alpha));
this.trans[1][0]=(-Math.cos(this.theta) * Math.sin(this.alpha) * Math.sin(this.phi)  + Math.cos(this.phi) * Math.sin(this.theta));
this.trans[1][1]=-(Math.cos(this.phi) * Math.cos(this.theta) + Math.sin(this.alpha) * Math.sin(this.phi) * Math.sin(this.theta) );
this.trans[1][2]=(-Math.cos(this.alpha) * Math.sin(this.phi));
});

Clazz.newMeth(C$, 'addFigure$emwave4_Figure', function (f) {
this.figs.addElement$TE(f);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$', function () {
var g=this.getGraphics$();
if (g == null ) return;
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var r=this.getBounds$();
if (this.osi == null  || r.width != this.iwidth  || r.height != this.iheight ) {
this.iheight=r.height;
this.iwidth=r.width;
this.osi=this.createImage$I$I(this.iwidth, this.iheight);
}var osg=this.osi.getGraphics$();
osg.setColor$java_awt_Color($I$(2).white);
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
var f;
for (var i=0; i < this.figs.size$(); i++) {
f=this.figs.elementAt$I(i);
f.drawFigure$java_awt_Graphics$DAA(osg, this.trans);
}
osg.dispose$();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
});

Clazz.newMeth(C$, 'translate$D', function (dz) {
var f;
for (var i=0; i < this.figs.size$(); i++) {
f=this.figs.elementAt$I(i);
f.translate$D(dz);
}
this.repaint$();
});

Clazz.newMeth(C$, 'setAngles$D$D$D', function (t, a, p) {
this.theta=t;
this.alpha=a;
this.phi=p;
this.transformMatrix$();
this.repaint$();
});

Clazz.newMeth(C$, 'registrationCheck$O', function (p) {
var figure=p;
var present;
present=this.figs.contains$O(figure);
return present;
});

Clazz.newMeth(C$, 'setTheta$D', function (t) {
this.theta=t;
this.transformMatrix$();
this.repaint$();
});

Clazz.newMeth(C$, 'setAlpha$D', function (a) {
this.alpha=a;
this.transformMatrix$();
this.repaint$();
});

Clazz.newMeth(C$, 'setPhi$D', function (p) {
this.phi=p;
this.transformMatrix$();
this.repaint$();
});

Clazz.newMeth(C$, 'clear$', function () {
this.figs.removeAllElements$();
});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:52 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
