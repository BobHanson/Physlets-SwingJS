(function(){var P$=Clazz.newPackage("circuit"),I$=[['edu.davidson.display.Format','java.awt.Font','java.awt.Color','edu.davidson.tools.SApplet','circuit.Common']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Part", null, null, 'edu.davidson.tools.SDataSource');
C$.delta = '\0';
C$.omega = '\0';
C$.micro = '\0';
C$.phi = '\0';
C$.degree = '\0';

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.delta = "\u0394";
C$.omega = "\u03a9";
C$.micro = "\u03bc";
C$.phi = "\u03c6";
C$.degree = "\u00b0";
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.owner = null;
this.format = null;
this.format0 = null;
this.format1 = null;
this.format2 = null;
this.format3 = null;
this.f = null;
this.color = null;
this.i1 = 0;
this.j1 = 0;
this.i2 = 0;
this.j2 = 0;
this.id = 0;
this.label = null;
this.customHint = null;
this.showV = false;
this.showCurrent = false;
this.showPhase = false;
this.showF = false;
this.showR = false;
this.showC = false;
this.showL = false;
this.showZ = false;
this.milliAmp = false;
this.switchOn = false;
this.varStrings = null;
this.ds = null;
this.voltRMS = 0;
this.currentRMS = 0;
this.voltInstantaneous = 0;
this.currentInstantaneous = 0;
this.freq = 0;
this.phase = 0;
this.radian = 0;
this.res = 0;
this.cap = 0;
this.ind = 0;
this.time = 0;
this.circuit = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.owner = null;
this.format = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+6.2f"]);
this.format0 = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+6.0f"]);
this.format1 = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+6.1f"]);
this.format2 = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+6.2f"]);
this.format3 = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+6.3f"]);
this.f = Clazz.new_((I$[2]||$incl$(2)).c$$S$I$I,["Helvetica", 1, 12]);
this.color = Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I,[0, 127, 0]);
this.id = 0;
this.label = "Z";
this.customHint = null;
this.showV = false;
this.showCurrent = false;
this.showPhase = false;
this.showF = false;
this.showR = false;
this.showC = false;
this.showL = false;
this.showZ = true;
this.milliAmp = false;
this.switchOn = false;
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "r", "l", "c", "z", "v", "i", "re", "im", "f", "vrms"]);
this.ds = Clazz.array(Double.TYPE, [1, 11]);
this.voltRMS = 0;
this.currentRMS = 0;
this.voltInstantaneous = 0;
this.currentInstantaneous = 0;
this.freq = 1;
this.phase = 0;
this.radian = 0;
this.res = 0;
this.cap = 0;
this.ind = 0;
this.time = 0;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I', function (o, c, i1, j1, i2, j2) {
C$.$init$.apply(this);
this.owner = o;
this.circuit = c;
this.i1 = i1;
this.j1 = j1;
this.i2 = i2;
this.j2 = j2;
try {
(I$[4]||$incl$(4)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.time;
this.ds[0][1] = this.res;
this.ds[0][2] = this.ind;
this.ds[0][3] = this.cap;
if (this.currentRMS == 0 ) this.ds[0][4] = 0;
 else this.ds[0][4] = Math.abs(this.voltRMS / this.currentRMS);
this.ds[0][5] = this.voltInstantaneous;
this.ds[0][6] = this.currentInstantaneous;
this.ds[0][7] = this.ds[0][4] * Math.cos(this.phase);
this.ds[0][8] = this.ds[0][4] * Math.sin(this.phase);
this.ds[0][9] = this.freq;
this.ds[0][10] = this.voltRMS;
return this.ds;
});

Clazz.newMeth(C$, 'getMSHint', function () {
var xl = 2 * 3.141592653589793 * this.freq * this.ind ;
var xc = -2 * 3.141592653589793 * this.cap ;
if (xc != 0 ) xc = 0;
var z = xl + xc;
var msg = "";
if (this.showZ) msg += "Z=" + this.format1.form$D(this.res) + " + i" + this.format1.form$D(z) + " " + " " + (I$[5]||$incl$(5)).OHM + " " ;
if (this.showR) msg += "R=" + this.format1.form$D(this.res) + " " + " " + (I$[5]||$incl$(5)).OHM + "   " ;
if (this.showC) msg += "C=" + this.format3.form$D(this.cap) + " " + " uF    " ;
if (this.showL) msg += "L=" + this.format1.form$D(this.ind) + " mH    " ;
if (this.showV) msg += (I$[5]||$incl$(5)).LEGEND_DELTAV + this.format1.form$D(this.voltRMS) + " " + (I$[5]||$incl$(5)).LEGEND_V + "    " ;
if (this.showPhase) msg += (I$[5]||$incl$(5)).PHASE + "=" + ((this.phase)|0) + " " + (I$[5]||$incl$(5)).DEG + "  " ;
if (this.showCurrent) msg += "I=" + this.format3.form$D(this.currentRMS) + " " + (I$[5]||$incl$(5)).LEGEND_I + "    " ;
if (msg.trim().length$() == 0) msg = (I$[5]||$incl$(5)).LEGEND_NOVALUE;
if (Clazz.instanceOf(this, "circuit.Wire")) msg = null;
return msg;
});

Clazz.newMeth(C$, 'getHint', function () {
if (this.customHint != null ) return this.customHint;
if (C$.isMicrosoft()) {
return this.getMSHint();
}var xl = 2 * 3.141592653589793 * this.freq * this.ind ;
var xc = -2 * 3.141592653589793 * this.cap ;
if (xc != 0 ) xc = 0;
var z = xl + xc;
var msg = "";
if (this.showZ) msg += "Z=" + this.format1.form$D(this.res) + " + i" + this.format1.form$D(z) + " " + C$.omega + "  " ;
if (this.showR) msg += "R=" + this.format1.form$D(this.res) + " " + C$.omega + "  " ;
if (this.showC) msg += "C=" + this.format3.form$D(this.cap) + " " + C$.micro + "F  " ;
if (this.showL) msg += "L=" + this.format1.form$D(this.ind) + " mH  " ;
if (this.showV) msg += C$.delta + (I$[5]||$incl$(5)).LEGEND_VEQU + this.format1.form$D(this.voltRMS) + " " + (I$[5]||$incl$(5)).LEGEND_V + "  " ;
if (this.showPhase) msg += C$.phi + "=" + ((this.phase)|0) + C$.degree + "  " ;
if (this.showCurrent && !this.milliAmp ) msg += "I=" + this.format3.form$D(this.currentRMS) + " " + (I$[5]||$incl$(5)).LEGEND_A + "  " ;
if (this.showCurrent && this.milliAmp ) msg += "I=" + this.format3.form$D(this.currentRMS) + " m" + (I$[5]||$incl$(5)).LEGEND_A + "  " ;
if (msg.trim().length$() == 0) msg = (I$[5]||$incl$(5)).LEGEND_NOVALUE;
if (Clazz.instanceOf(this, "circuit.Wire")) msg = null;
return msg;
});

Clazz.newMeth(C$, 'isInside$I$I$I$I$I', function (x, y, pixPerCell, xOffset, yOffset) {
var x1 = xOffset + pixPerCell * this.j1;
var y1 = yOffset + pixPerCell * this.i1;
var x2 = xOffset + pixPerCell * this.j2;
var y2 = yOffset + pixPerCell * this.i2;
if (Math.abs(x - ((x1 + x2)/2|0)) < (pixPerCell/4|0) && Math.abs(y - ((y1 + y2)/2|0)) < (pixPerCell/4|0) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics$I$I$I', function (g, pixPerCell, xOffset, yOffset) {
var x1 = xOffset + pixPerCell * this.j1;
var y1 = yOffset + pixPerCell * this.i1;
var x2 = xOffset + pixPerCell * this.j2;
var y2 = yOffset + pixPerCell * this.i2;
this.drawSymbol$java_awt_Graphics$I$I$I$I$I(g, x1, y1, x2, y2, pixPerCell);
if (this.i1 == this.i2) this.drawLabel$java_awt_Graphics$I$I$I$I(g, ((x1 + x2)/2|0), ((y1 + y2)/2|0), (-pixPerCell/5|0), -5);
 else if (this.j1 == this.j2) this.drawLabel$java_awt_Graphics$I$I$I$I(g, ((x1 + x2)/2|0), ((y1 + y2)/2|0), -8, -5);
 else this.drawLabel$java_awt_Graphics$I$I$I$I(g, ((x1 + x2)/2|0), ((y1 + y2)/2|0), -8, -5);
});

Clazz.newMeth(C$, 'drawLabel$java_awt_Graphics$I$I', function (g, x, y) {
this.drawLabel$java_awt_Graphics$I$I$I$I(g, x, y, 0, 0);
});

Clazz.newMeth(C$, 'drawLabel$java_awt_Graphics$I$I$I$I', function (g, x, y, xOff, yOff) {
if (this.label == null ) return;
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
g.drawString$S$I$I(this.label, x + xOff, y - yOff);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'drawSymbol$java_awt_Graphics$I$I$I$I$I', function (g, x1, y1, x2, y2, s) {
g.setColor$java_awt_Color(this.color);
var x = x2 - x1;
var y = -(y2 - y1);
var h = Math.sqrt(x * x + y * y);
if (h < 2 ) return;
var w = (h / 2.0 - s / 4.0);
var base_x1 = ((x1 + (x * w) / h)|0);
var base_y1 = ((y1 - (y * w) / h)|0);
var base_x2 = ((x2 - (x * w) / h)|0);
var base_y2 = ((y2 + (y * w) / h)|0);
g.drawLine$I$I$I$I(x1, y1, base_x1, base_y1);
g.drawLine$I$I$I$I(x2, y2, base_x2, base_y2);
w = s / 8.0;
var u = (w * x / h);
var v = -(w * y / h);
g.drawLine$I$I$I$I(((base_x1 - v)|0), ((base_y1 + u)|0), ((base_x1 + v)|0), ((base_y1 - u)|0));
g.drawLine$I$I$I$I(((base_x2 - v)|0), ((base_y2 + u)|0), ((base_x2 + v)|0), ((base_y2 - u)|0));
g.drawLine$I$I$I$I(((base_x2 - v)|0), ((base_y2 + u)|0), ((base_x1 - v)|0), ((base_y1 + u)|0));
g.drawLine$I$I$I$I(((base_x2 + v)|0), ((base_y2 - u)|0), ((base_x1 + v)|0), ((base_y1 - u)|0));
});

Clazz.newMeth(C$, 'setCurrentRMS$D', function (c) {
this.currentRMS = c;
});

Clazz.newMeth(C$, 'getCurrentRMS', function () {
return this.currentRMS;
});

Clazz.newMeth(C$, 'setCurrentInstantaneous$D', function (c) {
this.currentInstantaneous = c;
});

Clazz.newMeth(C$, 'getCurrentInstantaneous', function () {
return this.currentInstantaneous;
});

Clazz.newMeth(C$, 'setVoltRMS$D', function (v) {
this.voltRMS = v;
});

Clazz.newMeth(C$, 'getVoltRMS', function () {
return this.voltRMS;
});

Clazz.newMeth(C$, 'setVoltInstantaneous$D', function (v) {
this.voltInstantaneous = v;
});

Clazz.newMeth(C$, 'getVoltInstantaneous', function () {
return this.voltInstantaneous;
});

Clazz.newMeth(C$, 'setLabel$S', function (l) {
this.label = l;
this.circuit.forceRepaint();
});

Clazz.newMeth(C$, 'getLabel', function () {
return this.label;
});

Clazz.newMeth(C$, 'setCustomHint$S', function (h) {
if (h.trim().equals$O("")) this.customHint = null;
 else this.customHint = h;
});

Clazz.newMeth(C$, 'getCustomHint', function () {
return this.customHint;
});

Clazz.newMeth(C$, 'setC$D', function (c) {
this.cap = c;
});

Clazz.newMeth(C$, 'getC', function () {
return this.cap;
});

Clazz.newMeth(C$, 'setF$D', function (f) {
this.freq = f;
});

Clazz.newMeth(C$, 'getF', function () {
return this.freq;
});

Clazz.newMeth(C$, 'setL$D', function (l) {
this.ind = l;
});

Clazz.newMeth(C$, 'getL', function () {
return this.ind;
});

Clazz.newMeth(C$, 'setPhaseDegree$D', function (d) {
this.phase = d;
this.radian = d * 3.141592653589793 / 180.0;
});

Clazz.newMeth(C$, 'getPhaseDegree', function () {
return this.phase;
});

Clazz.newMeth(C$, 'setPhaseRadian$D', function (r) {
this.radian = r;
this.phase = r * 180.0 / 3.141592653589793;
});

Clazz.newMeth(C$, 'getPhaseRadian', function () {
return this.radian;
});

Clazz.newMeth(C$, 'setR$D', function (r) {
this.res = r;
});

Clazz.newMeth(C$, 'getR', function () {
return this.res;
});

Clazz.newMeth(C$, 'setTime$D', function (t) {
this.time = t;
});

Clazz.newMeth(C$, 'getTime', function () {
return this.time;
});

Clazz.newMeth(C$, 'setMilliAmp$Z', function (sma) {
this.milliAmp = sma;
});

Clazz.newMeth(C$, 'setSwitchOn$Z', function (on) {
this.switchOn = on;
});

Clazz.newMeth(C$, 'isMicrosoft', function () {
var vendor = System.getProperty("java.vendor").toLowerCase();
return (vendor.startsWith$S("microsoft"));
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:20:44
