(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newInterface(P$, "SDifferentiable");
})();
//Created 2018-03-17 21:37:12
