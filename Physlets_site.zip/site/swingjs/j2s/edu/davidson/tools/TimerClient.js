(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newInterface(P$, "TimerClient");
})();
//Created 2018-03-16 05:19:17
