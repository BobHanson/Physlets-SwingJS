(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "ResistorI", null, 'circuitsimulator.Resistor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$S', function (circuit, v, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$D$I$I$S.apply(this, [circuit, v, r, c, t]);
C$.$init$.apply(this);
this.leftlinear=false;
}, 1);

Clazz.newMeth(C$, 'impedance$', function () {
return Math.abs(this.value * this.getI$());
});

Clazz.newMeth(C$, 'valueStr$', function () {
return this.format.form$D(this.value) + "*I";
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",r=" + Double.toString$D(this.value);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:49 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
