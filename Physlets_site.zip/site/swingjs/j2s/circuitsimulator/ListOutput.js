(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "ListOutput", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.Dialog');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.cb=null;
this.fComponentsAdjusted=false;
this.addobjectList=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.cb=null;
this.fComponentsAdjusted=false;
this.addobjectList=Clazz.new_(Clazz.load('java.awt.TextArea'));
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame', function (parent) {
C$.superclazz.c$$java_awt_Frame.apply(this, [parent]);
C$.$init$.apply(this);
this.setLayout$java_awt_LayoutManager(null);
this.setSize$I$I(473, 282);
this.setVisible$Z(false);
this.add$java_awt_Component(this.addobjectList);
this.addobjectList.setBounds$I$I$I$I(5, 7, 460, 266);
var aSymWindow=Clazz.new_(Clazz.load(['circuitsimulator.ListOutput','.SymWindow']), [this, null]);
this.addWindowListener$java_awt_event_WindowListener(aSymWindow);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$java_awt_Frame.apply(this, [null]);
}, 1);

Clazz.newMeth(C$, 'c$$S$S$java_awt_Frame$circuitsimulator_CircuitBuilder', function (sTitle, s, parent, cirbuilder) {
C$.c$$java_awt_Frame.apply(this, [parent]);
this.cb=cirbuilder;
this.setTitle$S(sTitle);
this.addobjectList.setText$S(s);
this.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'addNotify$', function () {
var d=this.getSize$();
C$.superclazz.prototype.addNotify$.apply(this, []);
if (this.fComponentsAdjusted) return;
var ins=this.getInsets$();
this.setSize$I$I(ins.left + ins.right + d.width , ins.top + ins.bottom + d.height );
var components=this.getComponents$();
for (var i=0; i < components.length; i++) {
var p=components[i].getLocation$();
p.translate$I$I(ins.left, ins.top);
components[i].setLocation$java_awt_Point(p);
}
this.fComponentsAdjusted=true;
});

Clazz.newMeth(C$, 'setVisible$Z', function (b) {
if (b) {
var bounds=this.getParent$().getBounds$();
var abounds=this.getBounds$();
this.setLocation$I$I(bounds.x + ((bounds.width - abounds.width)/2|0), bounds.y + ((bounds.height - abounds.height)/2|0));
}C$.superclazz.prototype.setVisible$Z.apply(this, [b]);
});

Clazz.newMeth(C$, 'ListOutput_WindowClosing$java_awt_event_WindowEvent', function (event) {
try {
this.setVisible$Z(false);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});
;
(function(){var C$=Clazz.newClass(P$.ListOutput, "SymWindow", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.WindowAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0 ) this.this$0.ListOutput_WindowClosing$java_awt_event_WindowEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:16 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
