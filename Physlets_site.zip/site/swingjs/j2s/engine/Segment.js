(function(){var P$=Clazz.newPackage("engine"),I$=[['java.awt.Color','engine.Point3D']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Segment");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.p1 = null;
this.p2 = null;
this.col = null;
this.mode = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.col = (I$[1]||$incl$(1)).black;
this.mode = 0;
this.p1 = Clazz.new_((I$[2]||$incl$(2)));
this.p2 = Clazz.new_((I$[2]||$incl$(2)));
this.p1.x = 0.0;
this.p1.y = 0.0;
this.p1.z = 0.0;
this.p2.x = 0.0;
this.p2.y = 0.0;
this.p2.z = 0.0;
}, 1);

Clazz.newMeth(C$, 'showSegment$java_awt_Graphics', function (g) {
var r = 5;
g.setColor$java_awt_Color(this.col);
switch (this.mode) {
case 0:
g.drawLine$I$I$I$I(((this.p1.pa)|0), ((this.p1.pb)|0), ((this.p2.pa)|0), ((this.p2.pb)|0));
break;
case 1:
this.drawArrow$java_awt_Graphics$D$D$D$D(g, this.p1.pa, this.p1.pb, this.p2.pa, this.p2.pb);
break;
case 2:
g.drawLine$I$I$I$I(((this.p1.pa)|0), ((this.p1.pb)|0), ((this.p2.pa)|0), ((this.p2.pb)|0));
g.fillRect$I$I$I$I(((this.p2.pa - r)|0), ((this.p2.pb - r)|0), (2 * r), (2 * r));
break;
}
});

Clazz.newMeth(C$, 'drawArrow$java_awt_Graphics$D$D$D$D', function (g, px1, pz1, px2, pz2) {
var dxa;
var dxA;
var dza;
var dzA;
var S;
var AS;
var aS;
var x1;
var z1;
var x2;
var z2;
var xa;
var za;
var xb;
var zb;
var dx;
var dz;
var A = 10;
var a = 5;
x1 = ((px1)|0);
z1 = ((pz1)|0);
x2 = ((px2)|0);
z2 = ((pz2)|0);
dx = x2 - x1;
dz = z2 - z1;
if ((Math.abs(dx) > 1) || (Math.abs(dz) > 1) ) {
xa = xb = x2;
za = zb = z2;
if (dx == 0) {
xa = x2 + a;
xb = x2 - a;
if (dz < 0) {
za = zb = z2 + A;
}if (dz > 0) {
za = zb = z2 - A;
}} else if (dz == 0) {
za = z2 + a;
zb = z2 - a;
if (dx > 0) {
xa = xb = x2 - A;
}if (dx < 0) {
xa = xb = x2 + A;
}} else {
S = Math.sqrt(dx * dx + dz * dz);
AS = A / S;
aS = a / S;
dxA = dx * AS;
dzA = dz * AS;
dxa = dz * aS;
dza = dx * aS;
xa = x2 - ((dxA - dxa)|0);
za = z2 - ((dzA + dza)|0);
xb = x2 - ((dxA + dxa)|0);
zb = z2 - ((dzA - dza)|0);
}g.drawLine$I$I$I$I(x1, z1, x2, z2);
g.drawLine$I$I$I$I(x2, z2, xa, za);
g.drawLine$I$I$I$I(x2, z2, xb, zb);
}});
})();
//Created 2018-02-06 13:05:20
