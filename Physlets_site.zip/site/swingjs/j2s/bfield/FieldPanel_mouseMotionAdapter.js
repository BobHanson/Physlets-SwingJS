(function(){var P$=Clazz.newPackage("bfield"),I$=[];
var C$=Clazz.newClass(P$, "FieldPanel_mouseMotionAdapter", null, 'java.awt.event.MouseMotionAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$bfield_FieldPanel', function (adaptee) {
Clazz.super_(C$, this,1);
this.adaptee = adaptee;
}, 1);

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
this.adaptee.this_mouseDragged$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
this.adaptee.this_mouseMoved$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-16 05:18:53
