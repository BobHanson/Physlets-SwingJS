(function(){var P$=Clazz.newPackage("dataGraph"),I$=[['edu.davidson.graphics.EtchedBorder','a2s.Panel','edu.davidson.display.SNumber','a2s.Label','java.awt.BorderLayout','java.awt.FlowLayout']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DataListener", null, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SDataListener');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.numFields = 0;
this.etchedBorder1 = null;
this.panel1 = null;
this.panel2 = null;
this.fField = null;
this.gField = null;
this.label1 = null;
this.label2 = null;
this.borderLayout1 = null;
this.borderLayout2 = null;
this.borderLayout3 = null;
this.flowLayout1 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.etchedBorder1 = Clazz.new_((I$[1]||$incl$(1)));
this.panel1 = Clazz.new_((I$[2]||$incl$(2)));
this.panel2 = Clazz.new_((I$[2]||$incl$(2)));
this.fField = Clazz.new_((I$[3]||$incl$(3)));
this.gField = Clazz.new_((I$[3]||$incl$(3)));
this.label1 = Clazz.new_((I$[4]||$incl$(4)));
this.label2 = Clazz.new_((I$[4]||$incl$(4)));
this.borderLayout1 = Clazz.new_((I$[5]||$incl$(5)));
this.borderLayout2 = Clazz.new_((I$[5]||$incl$(5)));
this.borderLayout3 = Clazz.new_((I$[5]||$incl$(5)));
this.flowLayout1 = Clazz.new_((I$[6]||$incl$(6)));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.numFields = Integer.parseInt(this.getParameter$S$S("NumFields", "2"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
edu.davidson.tools.SApplet.addDataListener$O(this);
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, 'jbInit', function () {
this.panel1.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.panel2.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.fField.setText$S("0");
this.gField.setText$S("0");
this.label1.setAlignment$I(1);
this.label1.setText$S("Func. 2 =");
this.label2.setAlignment$I(1);
this.label2.setText$S("Func. 1 =");
this.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.add$java_awt_Component$O(this.etchedBorder1, null);
this.etchedBorder1.add$java_awt_Component$O(this.panel1, "West");
this.panel1.add$java_awt_Component$O(this.label2, "West");
this.panel1.add$java_awt_Component$O(this.fField, "Center");
this.etchedBorder1.add$java_awt_Component$O(this.panel2, "East");
this.panel2.add$java_awt_Component$O(this.label1, "West");
this.panel2.add$java_awt_Component$O(this.gField, "Center");
});

Clazz.newMeth(C$, 'start', function () {
});

Clazz.newMeth(C$, 'stop', function () {
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Applet Information";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["NumFields", "int", "Number of output fields.  Must be 1 or 2."])]);
return pinfo;
});

Clazz.newMeth(C$, ['addDatum$I$D$D','addDatum'], function (id, x, y) {
this.fField.setValue$D(x);
this.gField.setValue$D(y);
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, x, y) {
this.addDatum$I$D$D(id, x, y);
});

Clazz.newMeth(C$, ['addData$I$DA$DA','addData'], function (id, x, y) {
var n = x.length;
this.fField.setValue$D(x[n - 1]);
this.gField.setValue$D(y[n - 1]);
});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
this.addData$I$DA$DA(id, x, y);
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.fField.setValue$D(0);
this.gField.setValue$D(0);
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
this.fField.setValue$D(0);
this.gField.setValue$D(0);
});
})();
//Created 2018-02-24 16:21:05
