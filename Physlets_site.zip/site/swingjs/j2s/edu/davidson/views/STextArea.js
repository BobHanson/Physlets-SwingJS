(function(){var P$=Clazz.newPackage("edu.davidson.views"),I$=[['edu.davidson.display.Format','java.util.Vector','java.awt.Font','java.util.StringTokenizer',['edu.davidson.views.STextArea','.Series']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "STextArea", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'a2s.TextArea');
C$.VARIABLE_NOT_FOUND = 0;
C$.VARIABLE_NOT_A_NUMBER = 0;
C$.END_OF_MESSAGES = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.VARIABLE_NOT_FOUND = 1;
C$.VARIABLE_NOT_A_NUMBER = 2;
C$.END_OF_MESSAGES = "=========SERIES DATA=========";
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.errorCode = 0;
this.errorMsg = null;
this.dataSeries = null;
this.$font = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.errorCode = 0;
this.errorMsg = "";
this.dataSeries = Clazz.new_((I$[2]||$incl$(2)));
this.$font = Clazz.new_((I$[3]||$incl$(3)).c$$S$I$I,["Monospaced", 0, 12]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.setFont$java_awt_Font(this.$font);
}, 1);

Clazz.newMeth(C$, 'getValue$S', function (variable) {
var ptokens = Clazz.new_((I$[4]||$incl$(4)).c$$S$S,[this.getText(), "\u000a"]);
var n = ptokens.countTokens();
var value = 0;
this.errorCode = 0;
this.errorMsg = "";
for (var i = 0; i < n; i++) {
var aLine = ptokens.nextToken().trim();
if (aLine != null  && !aLine.equals$O("")  && aLine.startsWith$S(variable + "=") ) {
aLine = aLine.substring(variable.length$() + 1);
try {
value = Double.$valueOf(aLine).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Variable " + variable + " is not a number. var=" + aLine );
this.errorCode = C$.VARIABLE_NOT_A_NUMBER;
this.errorMsg = "Variable " + variable + " is not a number. var=" + aLine + "\n" ;
return 0;
} else {
throw e;
}
}
return value;
}}
System.out.println$S("Variable " + variable + " not found." );
this.errorCode = C$.VARIABLE_NOT_FOUND;
this.errorMsg = "Variable " + variable + " not found.\n" ;
return 0;
});

Clazz.newMeth(C$, 'setNumericFormat$I$S', function (sid, str) {
var s = this.getSeries$I(sid);
s.format = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+8.2g"]);
});

Clazz.newMeth(C$, 'setSeriesCharWidth$I$I', function (sid, charwidth) {
var s = this.getSeries$I(sid);
s.charwidth = charwidth;
this.setValue$S$D(null, 0);
});

Clazz.newMeth(C$, 'setSeriesLabel$I$S', function (sid, str) {
var s = this.getSeries$I(sid);
s.label = str;
if (str.length$() + 2 > s.charwidth) s.charwidth = str.length$() + 2;
this.setValue$S$D(null, 0);
});

Clazz.newMeth(C$, 'setValue$S$D', function (variable, val) {
var newText = "";
var text = this.getText();
var ptokens = Clazz.new_((I$[4]||$incl$(4)).c$$S$S,[text, "\u000a"]);
var n = ptokens.countTokens();
var variableFound = false;
for (var i = 0; i < n; i++) {
var aLine = ptokens.nextToken().trim();
if (aLine.equals$O(C$.END_OF_MESSAGES)) break;
if (aLine != null  && aLine.startsWith$S(variable + "=") ) {
aLine = variable + "=" + new Double(val).toString() ;
variableFound = true;
}newText = newText + aLine + "\n" ;
}
if (!variableFound && variable != null  ) newText = newText + variable + "=" + new Double(val).toString() + "\n" ;
if (this.dataSeries.size() > 0) newText = newText + C$.END_OF_MESSAGES + "\n" ;
newText = this.appendDataSeries$S(newText);
this.setText$S(newText);
});

Clazz.newMeth(C$, 'getErrorCode', function () {
return this.errorCode;
});

Clazz.newMeth(C$, 'getErrorMsg', function () {
return this.errorMsg;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.setText$S("");
this.errorCode = 0;
this.errorMsg = "";
this.dataSeries.removeAllElements();
});

Clazz.newMeth(C$, 'addDatum$I$D', function (sid, x) {
var s = this.getSeries$I(sid);
s.addDatum$D(x);
this.setValue$S$D(null, 0);
});

Clazz.newMeth(C$, 'addData$I$DA', function (sid, x) {
var s = this.getSeries$I(sid);
s.addData$DA(x);
this.setValue$S$D(null, 0);
});

Clazz.newMeth(C$, 'clearSeries$I', function (sid) {
var s = this.getSeries$I(sid);
s.clearSeries();
this.setValue$S$D(null, 0);
});

Clazz.newMeth(C$, 'deleteAllSeries', function () {
this.dataSeries.removeAllElements();
this.setValue$S$D(null, 0);
});

Clazz.newMeth(C$, 'clearAllSeries', function () {
var s = null;
for (var e = this.dataSeries.elements(); e.hasMoreElements(); ) {
s = e.nextElement();
s.clearSeries();
}
this.setValue$S$D(null, 0);
});

Clazz.newMeth(C$, 'deleteSeries$I', function (sid) {
var s = null;
for (var e = this.dataSeries.elements(); e.hasMoreElements(); ) {
s = e.nextElement();
if (s.seriesID == sid) {
this.dataSeries.remove$O(s);
return;
}}
this.setValue$S$D(null, 0);
});

Clazz.newMeth(C$, 'getSeries$I', function (sid) {
var s = null;
for (var e = this.dataSeries.elements(); e.hasMoreElements(); ) {
s = e.nextElement();
if (s.seriesID == sid) return s;
}
s = Clazz.new_((I$[5]||$incl$(5)).c$$I, [this, null, sid]);
this.dataSeries.addElement$TE(s);
return s;
});

Clazz.newMeth(C$, 'appendDataSeries$S', function (newText) {
newText += "\n";
var numseries = this.dataSeries.size();
var series;
var str;
for (var i = 0; i < numseries; i++) {
series = this.dataSeries.elementAt$I(i);
var spaces = series.charwidth - series.label.length$();
if (spaces < 1) {
str = series.label.substring(0, series.charwidth - 1);
if (spaces == 1) str = str + ' ';
} else if (spaces == 1) {
str = series.label + ' ';
} else {
var buffer = Clazz.array(Character.TYPE, [spaces]);
for (var j = 0; j < spaces; j++) buffer[j] = " ";

str = series.label +  String.instantialize(buffer);
}newText += str;
}
newText += "\n";
var row = 0;
var moreData = true;
while (moreData){
moreData = false;
for (var i = 0; i < numseries; i++) {
series = this.dataSeries.elementAt$I(i);
str = series.getStringValue$I(row);
newText += str;
if (row < series.nextRow) moreData = true;
}
newText += "\n";
row++;
}
return newText;
});
;
(function(){var C$=Clazz.newClass(P$.STextArea, "Series", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.data = null;
this.nextRow = 0;
this.MAX_VALS = 0;
this.seriesID = 0;
this.label = null;
this.charwidth = 0;
this.format = null;
this.replaceData = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.data = Clazz.array(Double.TYPE, [64]);
this.nextRow = 0;
this.MAX_VALS = 8192;
this.seriesID = 0;
this.label = "Series " + this.seriesID;
this.charwidth = 12;
this.format = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+8.2g"]);
this.replaceData = true;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (id) {
C$.$init$.apply(this);
this.seriesID = id;
this.label = "Series " + this.seriesID;
}, 1);

Clazz.newMeth(C$, 'doubleSize$I', function (minSize) {
if (this.data.length >= this.MAX_VALS) {
System.out.println$S("Series in STextArea has exceeded maximum size.");
return false;
}var newdata = Clazz.array(Double.TYPE, [2 * minSize]);
System.arraycopy(this.data, 0, newdata, 0, this.data.length);
this.data = newdata;
return true;
});

Clazz.newMeth(C$, 'addDatum$D', function (val) {
if (this.nextRow >= this.data.length) {
if (!p$.doubleSize$I.apply(this, [this.nextRow])) return;
}this.data[this.nextRow] = val;
this.nextRow++;
});

Clazz.newMeth(C$, 'addData$DA', function (vals) {
if (this.replaceData) this.nextRow = 0;
if (this.nextRow + vals.length > this.data.length) {
if (!p$.doubleSize$I.apply(this, [this.nextRow + vals.length])) return;
}System.arraycopy(vals, 0, this.data, this.nextRow, vals.length);
this.nextRow = this.nextRow+(vals.length);
});

Clazz.newMeth(C$, 'clearSeries', function () {
this.nextRow = 0;
this.data = Clazz.array(Double.TYPE, [64]);
});

Clazz.newMeth(C$, 'getStringValue$I', function (r) {
var str;
var buffer = Clazz.array(Character.TYPE, [this.charwidth]);
for (var j = 0; j < this.charwidth; j++) buffer[j] = " ";

str =  String.instantialize(buffer);
if (r < this.nextRow) {
str = this.format.form$D(this.data[r]);
var spaces = this.charwidth - str.length$();
if (spaces < 0) {
for (var j = 0; j < this.charwidth - 1; j++) buffer[j] = "*";

str =  String.instantialize(buffer) + ' ';
} else if (spaces > 1) {
buffer = Clazz.array(Character.TYPE, [spaces]);
for (var j = 0; j < spaces; j++) buffer[j] = " ";

str = str +  String.instantialize(buffer);
}}return str;
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-03-16 05:19:17
