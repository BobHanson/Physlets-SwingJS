(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "Constraints");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.curVindex=0;
this.prevVindex=0;
this.curIindex=0;
this.prevIindex=0;
this.curVvalue=0;
this.prevVvalue=0;
this.curIvalue=0;
this.prevIvalue=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.curVindex=0;
this.prevVindex=0;
this.curIindex=0;
this.prevIindex=0;
this.curVvalue=0.0;
this.prevVvalue=0.0;
this.curIvalue=0.0;
this.prevIvalue=0.0;
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I', function (i, j, k) {
C$.$init$.apply(this);
this.curVindex=i;
this.prevVindex=j;
this.curIindex=k;
this.curVvalue=1.0;
this.prevVvalue=-1.0;
this.curIvalue=1.0E-20;
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$D$D$D$D', function (i, j, k, l, iv, jv, kv, lv) {
C$.$init$.apply(this);
this.curVindex=i;
this.prevVindex=j;
this.curIindex=k;
this.prevIindex=l;
this.curVvalue=iv;
this.prevVvalue=jv;
this.curIvalue=kv;
this.prevIvalue=lv;
}, 1);

Clazz.newMeth(C$, 'leftValue$I$circuitsimulator_Matrix$I', function (nOV, matrix, r) {
matrix.set_elem$I$I$D(nOV + 1 + r , this.curVindex, this.curVvalue);
matrix.set_elem$I$I$D(nOV + 1 + r , this.prevVindex, this.prevVvalue);
matrix.set_elem$I$I$D(nOV + 1 + r , nOV + this.curIindex, this.curIvalue);
matrix.set_elem$I$I$D(nOV + 1 + r , nOV + this.prevIindex, this.prevIvalue);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:48 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
