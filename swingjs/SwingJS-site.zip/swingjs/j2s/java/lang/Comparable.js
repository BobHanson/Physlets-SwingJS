(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(P$, "Comparable");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-03-16 11:00:34 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
