(function(){var P$=Clazz.newPackage("engine"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Point3D");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.z = 0;
this.pa = 0;
this.pb = 0;
this.depth = 0;
this.mode = 0;
this.col = null;
this.paintMode = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I', function (dx, dy, dz) {
C$.$init$.apply(this);
this.x = dx;
this.y = dy;
this.z = dz;
this.mode = 1;
this.col = (I$[1]||$incl$(1)).black;
this.paintMode = 1;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.x = 0.0;
this.y = 0.0;
this.z = 0.0;
this.mode = 1;
this.col = (I$[1]||$incl$(1)).black;
;this.paintMode = 1;
}, 1);

Clazz.newMeth(C$, 'showPoint$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color(this.col);
g.drawOval$I$I$I$I(((this.pa)|0), ((this.pb)|0), 1, 1);
});
})();
//Created 2018-02-08 01:51:26
