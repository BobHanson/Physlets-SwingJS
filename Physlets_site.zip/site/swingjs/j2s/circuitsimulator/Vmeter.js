(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "Vmeter", null, 'circuitsimulator.Resistor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$I$S', function (circuit, v, d, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$D$I$I$I$S.apply(this, [circuit, v, d, r, c, t]);
C$.$init$.apply(this);
if (this.value == 0.0 ) this.value = 1000000.0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'valueStr', function () {
return "";
});
})();
//Created 2018-02-06 06:55:34
