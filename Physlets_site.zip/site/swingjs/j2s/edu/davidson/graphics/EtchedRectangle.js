(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['edu.davidson.graphics.Etching','edu.davidson.graphics.DrawnRectangle']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EtchedRectangle", null, 'edu.davidson.graphics.DrawnRectangle');
C$._defaultEtching = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$._defaultEtching = (I$[1]||$incl$(1)).IN;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.etching = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component', function (drawInto) {
C$.c$$java_awt_Component$edu_davidson_graphics_Etching$I$I$I$I$I.apply(this, [drawInto, C$._defaultEtching, (I$[2]||$incl$(2))._defaultThickness, 0, 0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I', function (drawInto, thickness) {
C$.c$$java_awt_Component$edu_davidson_graphics_Etching$I$I$I$I$I.apply(this, [drawInto, C$._defaultEtching, thickness, 0, 0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I$I$I$I', function (drawInto, x, y, w, h) {
C$.c$$java_awt_Component$edu_davidson_graphics_Etching$I$I$I$I$I.apply(this, [drawInto, C$._defaultEtching, (I$[2]||$incl$(2))._defaultThickness, x, y, w, h]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I$I$I$I$I', function (drawInto, thickness, x, y, w, h) {
C$.c$$java_awt_Component$edu_davidson_graphics_Etching$I$I$I$I$I.apply(this, [drawInto, C$._defaultEtching, thickness, x, y, w, h]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$edu_davidson_graphics_Etching$I$I$I$I$I', function (drawInto, etching, thickness, x, y, w, h) {
C$.superclazz.c$$java_awt_Component$I$I$I$I$I.apply(this, [drawInto, thickness, x, y, w, h]);
C$.$init$.apply(this);
this.etching = etching;
}, 1);

Clazz.newMeth(C$, 'etchedIn', function () {
this.etching = (I$[1]||$incl$(1)).IN;
});

Clazz.newMeth(C$, 'etchedOut', function () {
this.etching = (I$[1]||$incl$(1)).OUT;
});

Clazz.newMeth(C$, 'isEtchedIn', function () {
return this.etching === (I$[1]||$incl$(1)).IN ;
});

Clazz.newMeth(C$, 'paint', function () {
if (this.etching === (I$[1]||$incl$(1)).IN ) this.paintEtchedIn();
 else this.paintEtchedOut();
});

Clazz.newMeth(C$, 'paintEtchedIn', function () {
var g = this.drawInto.getGraphics();
if (g != null ) p$.paintEtched$java_awt_Graphics$java_awt_Color$java_awt_Color.apply(this, [g, this.getLineColor(), this.brighter()]);
this.etchedIn();
});

Clazz.newMeth(C$, 'paintEtchedOut', function () {
var g = this.drawInto.getGraphics();
if (g != null ) p$.paintEtched$java_awt_Graphics$java_awt_Color$java_awt_Color.apply(this, [g, this.brighter(), this.getLineColor()]);
this.etchedOut();
});

Clazz.newMeth(C$, 'paramString', function () {
return C$.superclazz.prototype.paramString.apply(this, []) + "," + this.etching ;
});

Clazz.newMeth(C$, 'paintEtched$java_awt_Graphics$java_awt_Color$java_awt_Color', function (g, topLeft, bottomRight) {
var thickness = this.getThickness();
var w = this.width - thickness;
var h = this.height - thickness;
g.setColor$java_awt_Color(topLeft);
for (var i = 0; i < (thickness/2|0); ++i) g.drawRect$I$I$I$I(this.x + i, this.y + i, w, h);

g.setColor$java_awt_Color(bottomRight);
for (var i = 0; i < (thickness/2|0); ++i) g.drawRect$I$I$I$I(this.x + ((thickness/2|0)) + i , this.y + ((thickness/2|0)) + i , w, h);

g.dispose();
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:37:11
