(function(){var P$=Clazz.newPackage("animator4"),p$1={},I$=[[0,'edu.davidson.numerics.SRK45','java.util.Vector','edu.davidson.display.Format','java.awt.Font',['animator4.AnimatorCanvas','.DynamicsSolver'],'edu.davidson.tools.SApplet','java.awt.Color','animator4.FunctionThing','animator4.ShapeThing','animator4.Interaction','animator4.Arrow','animator4.ArrowStatic','animator4.Protractor','animator4.Piston','animator4.Spring','animator4.Circle','animator4.Doppler','animator4.Charge','animator4.Shell','animator4.ExShell','animator4.Box','animator4.DrawnRectangle','animator4.TextThing','animator4.CalcThing','animator4.CaptionThing','animator4.CursorThing','animator4.MouseDataSource','animator4.CollisionDataSource','java.awt.MediaTracker','animator4.ImageThing','java.awt.Toolkit','edu.davidson.tools.SUtil','edu.davidson.graphics.Util','animator4.Animator_mouseMotionAdapter','animator4.Animator_mouseAdapter','animator4.TrailThing','java.awt.Cursor']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "AnimatorCanvas", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.Canvas', ['edu.davidson.tools.SStepable', 'edu.davidson.tools.SDataSource']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.isJS=false;
this.mouseMotionAdapter=null;
this.mouseAdapter=null;
this.enableMouse=false;
this.boxWidth=0;
this.mouseFormat=null;
this.sketchImage=null;
this.sketchMode=false;
this.trailThing=null;
this.sketchCursor=null;
this.referenceObject=null;
this.collisionDataSource=null;
this.dragThing=null;
this.defaultColor=null;
this.things=null;
this.boldFont=null;
this.owner=null;
this.pixPerUnit=0;
this.backgroundImage=null;
this.osi=null;
this.iwidth=0;
this.iheight=0;
this.xOffset=0;
this.yOffset=0;
this.gridUnit=0;
this.time=0;
this.timeDisplay=false;
this.coordDisplay=false;
this.autoRefresh=false;
this.message=null;
this.mouseDrag=false;
this.mouseX=0;
this.mouseY=0;
this.varStrings=null;
this.ds=null;
this.dynamics=null;
this.stickyCount=0;
this.bouncyCount=0;
this.dampOnMousePressed=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.isJS=true ||false;
this.enableMouse=false;
this.boxWidth=0;
this.mouseFormat=Clazz.new_($I$(3).c$$S,["%-+6.3g"]);
this.sketchImage=null;
this.sketchMode=false;
this.trailThing=null;
this.sketchCursor=null;
this.referenceObject=null;
this.collisionDataSource=null;
this.dragThing=null;
this.defaultColor=null;
this.things=Clazz.new_($I$(2));
this.boldFont=Clazz.new_($I$(4).c$$S$I$I,["Helvetica", 1, 14]);
this.owner=null;
this.pixPerUnit=10;
this.backgroundImage=null;
this.iwidth=0;
this.iheight=0;
this.xOffset=0;
this.yOffset=0;
this.gridUnit=1;
this.time=0;
this.timeDisplay=true;
this.coordDisplay=true;
this.autoRefresh=true;
this.message=null;
this.mouseDrag=false;
this.mouseX=0;
this.mouseY=0;
this.varStrings=Clazz.array(String, -1, ["t", "xcm", "ycm", "px", "py", "m", "ke"]);
this.ds=Clazz.array(Double.TYPE, [1, 7]);
this.dynamics=Clazz.new_($I$(5), [this, null]);
this.stickyCount=0;
this.bouncyCount=0;
this.dampOnMousePressed=true;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_Animator', function (o) {
C$.c$.apply(this, []);
this.owner=o;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.setEnableMouse$Z(true);
try {
$I$(6).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'jbInit', function () {
this.setBackground$java_awt_Color($I$(7).white);
}, p$1);

Clazz.newMeth(C$, 'getVarStrings$', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID$', function () {
return this.hashCode$();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (o) {
;});

Clazz.newMeth(C$, 'getOwner$', function () {
return this.owner;
});

Clazz.newMeth(C$, 'getVariables$', function () {
var xcm=0;
var ycm=0;
var px=0;
var py=0;
var m=0;
var ke=0;
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
m += t.mass;
xcm += t.mass * t.vars[1];
ycm += t.mass * t.vars[2];
px += t.mass * t.vars[3];
py += t.mass * t.vars[4];
ke += t.mass * (t.vars[3] * t.vars[3] + t.vars[4] * t.vars[4]);
}
this.ds[0][0]=this.time;
if (m > 0 ) {
this.ds[0][1]=xcm / m;
} else {
this.ds[0][1]=0;
}if (m > 0 ) {
this.ds[0][2]=ycm / m;
} else {
this.ds[0][2]=0;
}this.ds[0][3]=px;
this.ds[0][4]=py;
this.ds[0][5]=m;
this.ds[0][6]=ke / 2;
return this.ds;
});

Clazz.newMeth(C$, 'getThing$I', function (id) {
var t=null;
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
t=e.nextElement$();
if (t.hashCode$() == id) {
return t;
}}
return null;
});

Clazz.newMeth(C$, 'clearTrails$', function () {
var t=null;
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
t=e.nextElement$();
t.clearTrail$();
}
});

Clazz.newMeth(C$, 'setReferenceObject$animator4_Thing', function (t) {
var keepRunning=this.owner.clock.isRunning$();
this.owner.clock.stopClock$();
this.referenceObject=t;
this.clearTrails$();
this.paintOSI$();
if (keepRunning) {
this.owner.clock.startClock$();
} else {
this.repaint$();
}});

Clazz.newMeth(C$, 'getReferenceObject$', function () {
return this.referenceObject;
});

Clazz.newMeth(C$, 'addParametricCurve$I$D$D$S$S', function (n, start, stop, xStr, yStr) {
var t=Clazz.new_($I$(8).c$$animator4_AnimatorCanvas$I$D$D$S$S,[this, n, start, stop, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addPolyShape$I$IA$IA$S$S', function (n, h, v, xStr, yStr) {
var t=Clazz.new_($I$(9).c$$animator4_AnimatorCanvas$I$IA$IA$S$S,[this, n, h, v, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addInteraction$I$I$S$S', function (id1, id2, f, mode) {
var t1=this.getThing$I(id1);
var t2=this.getThing$I(id2);
if ((t1 == null ) || (t2 == null ) ) {
return false;
}mode=mode.trim$();
mode=mode.toLowerCase$();
var m;
if (mode.equals$O("x")) {
m=$I$(10).XMODE;
} else if (mode.equals$O("y")) {
m=$I$(10).YMODE;
} else {
m=$I$(10).RMODE;
}if ((t1 != null ) && t1.dynamic ) {
t1.addInteraction$animator4_Thing$S$I(t2, f, m);
};if ((t2 != null ) && t2.dynamic ) {
t2.addInteraction$animator4_Thing$S$I(t1, f, m);
};return true;
});

Clazz.newMeth(C$, 'deleteObject$I', function (id) {
var t=null;
t=this.getThing$I(id);
if (t == null ) return false;
if (this.owner != null ) this.owner.stop$();
this.things.removeElement$O(t);
if (this.owner != null ) {
this.owner.removeDataSource$I(t.hashCode$());
this.owner.removeDataListener$I(t.hashCode$());
this.owner.cleanupDataConnections$();
}if (this.autoRefresh) {
this.repaint$();
}return true;
});

Clazz.newMeth(C$, 'addArrow$I$S$S$S$S', function (size, hStr, vStr, xStr, yStr) {
var t=Clazz.new_($I$(11).c$$animator4_AnimatorCanvas$I$S$S$S$S,[this, size, hStr, vStr, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addArrowStatic$I$D$D$S$S', function (size, hStr, vStr, xStr, yStr) {
var t=Clazz.new_($I$(12).c$$animator4_AnimatorCanvas$I$D$D$S$S,[this, size, hStr, vStr, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addProtractor$I$D$D$S$S', function (size, theta, theta0, xStr, yStr) {
var t=Clazz.new_($I$(13).c$$animator4_AnimatorCanvas$I$D$D$S$S,[this, size, theta, theta0, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addPiston$I$S$S$S$S', function (s, x, y, xStr, yStr) {
var t=Clazz.new_($I$(14).c$$animator4_AnimatorCanvas$I$S$S$S$S,[this, s, x, y, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addSpring$I$S$S$S$S', function (s, x, y, xStr, yStr) {
var t=Clazz.new_($I$(15).c$$animator4_AnimatorCanvas$I$S$S$S$S,[this, s, x, y, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addCircle$I$S$S', function (diameter, xStr, yStr) {
var t=Clazz.new_($I$(16).c$$animator4_AnimatorCanvas$I$S$S,[this, diameter, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addDoppler$I$S$S$I$D$D', function (diameter, xStr, yStr, numCrests, period, c) {
var t=Clazz.new_($I$(17).c$$animator4_AnimatorCanvas$I$S$S$I$D$D,[this, diameter, xStr, yStr, numCrests, period, c]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addCharge$I$S$S$D', function (diameter, xStr, yStr, q) {
var t=Clazz.new_($I$(18).c$$animator4_AnimatorCanvas$I$S$S$D,[this, diameter, xStr, yStr, q]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addShell$I$S$S', function (diameter, xStr, yStr) {
var t=Clazz.new_($I$(19).c$$animator4_AnimatorCanvas$I$S$S,[this, diameter, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addExShell$I$S$S$S', function (tickness, rStr, xStr, yStr) {
var t=Clazz.new_($I$(20).c$$animator4_AnimatorCanvas$I$S$S$S,[this, tickness, rStr, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addBox$I$I$S$S', function (w, h, xStr, yStr) {
var t=Clazz.new_($I$(21).c$$animator4_AnimatorCanvas$I$I$S$S,[this, w, h, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addRectangle$I$I$S$S', function (w, h, xStr, yStr) {
var t=Clazz.new_($I$(22).c$$animator4_AnimatorCanvas$I$I$S$S,[this, w, h, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addText$S$S$S$S', function (text, calcStr, xStr, yStr) {
var t=Clazz.new_($I$(23).c$$animator4_AnimatorCanvas$S$S$S$S,[this, text, calcStr, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addCalcThing$S$S$S', function (text, xStr, yStr) {
var t=Clazz.new_($I$(24).c$$animator4_AnimatorCanvas$S$S$S,[this, text, xStr, yStr]);
if (this.defaultColor != null ) {
t.color=this.defaultColor;
}this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addCaption$S$S$S$S', function (text, calcStr, xStr, yStr) {
var t=Clazz.new_($I$(25).c$$animator4_AnimatorCanvas$S$S$S$S,[this, text, calcStr, xStr, yStr]);
this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addCursor$I$S$S', function (diameter, xStr, yStr) {
var t=Clazz.new_($I$(26).c$$animator4_AnimatorCanvas$I$S$S,[this, diameter, xStr, yStr]);
this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'addMouseThing$', function () {
var mds=Clazz.new_($I$(27).c$$animator4_AnimatorCanvas,[this]);
this.things.addElement$TE(mds);
return mds;
});

Clazz.newMeth(C$, 'getCollisionThing$', function () {
if (this.collisionDataSource != null ) return this.collisionDataSource;
this.collisionDataSource=Clazz.new_($I$(28).c$$animator4_AnimatorCanvas,[this]);
this.things.addElement$TE(this.collisionDataSource);
return this.collisionDataSource;
});

Clazz.newMeth(C$, 'addImage$java_awt_Image$S$S', function (im, xStr, yStr) {
if (im == null ) {
return 0;
}var tracker=Clazz.new_($I$(29).c$$java_awt_Component,[this]);
try {
tracker.addImage$java_awt_Image$I(im, 0);
tracker.waitForID$I$J(0, 1000);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
var t=Clazz.new_($I$(30).c$$animator4_AnimatorCanvas$java_awt_Image$S$S,[this, im, xStr, yStr]);
this.things.addElement$TE(t);
if (this.autoRefresh) {
this.repaint$();
}return t.hashCode$();
});

Clazz.newMeth(C$, 'updateMouseMovedListeners$I$I', function (xpix, ypix) {
var v;
{
v=this.things.clone$();
}for (var e=v.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
if (Clazz.instanceOf(t, "animator4.MouseDataSource")) {
(t).moveXY$I$I(xpix, ypix);
}}
});

Clazz.newMeth(C$, 'updateMouseDragListeners$D$D', function (x, y) {
var v;
{
v=this.things.clone$();
}for (var e=v.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
if (Clazz.instanceOf(t, "animator4.MouseDataSource")) {
(t).dragXY$D$D(x, y);
}}
});

Clazz.newMeth(C$, 'updateMouseClickListeners$I$I', function (xpix, ypix) {
var v;
{
v=this.things.clone$();
}for (var e=v.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
if (Clazz.instanceOf(t, "animator4.MouseDataSource")) {
(t).clickXY$I$I(xpix, ypix);
}}
});

Clazz.newMeth(C$, 'updateMouseReleaseListeners$I$I', function (xpix, ypix) {
var v;
{
v=this.things.clone$();
}for (var e=v.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
if (Clazz.instanceOf(t, "animator4.MouseDataSource")) {
(t).releaseXY$I$I(xpix, ypix);
}}
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$', function () {
var g=this.getGraphics$();
if (g == null ) {
return;
}if (this.osi == null ) {
return;
}{
this.paintOSI$();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
if (this.mouseDrag && this.sketchMode && (this.sketchImage != null )  ) {
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.sketchImage, this.mouseX, this.mouseY - this.sketchImage.getHeight$java_awt_image_ImageObserver(this), this);
}g.dispose$();
var tk=$I$(31).getDefaultToolkit$();
tk.sync$();
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.autoRefresh) return;
if ((this.getSize$().width == 0) || (this.getSize$().height == 0) ) {
return;
}if ((this.osi == null ) || (this.iwidth != this.getSize$().width) || (this.iheight != this.getSize$().height)  ) {
this.iwidth=this.getSize$().width;
this.iheight=this.getSize$().height;
this.osi=this.createImage$I$I(this.iwidth, this.iheight);
}if (this.owner.isClockRunning$()) {
return;
}if (this.osi == null ) {
return;
}{
this.paintOSI$();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
}});

Clazz.newMeth(C$, 'paintOSI$', function () {
var xo=(this.iwidth/2|0) - this.xOffset;
var yo=(this.iheight/2|0) + this.yOffset;
if (this.osi == null ) {
return;
}var osg=this.osi.getGraphics$();
if (osg == null ) {
return;
}var xref=0;
var yref=0;
if (this.referenceObject != null ) {
xref=this.pixFromX$D(this.referenceObject.getX$()) - this.pixFromX$D(0);
yref=this.pixFromY$D(this.referenceObject.getY$()) - this.pixFromY$D(0);
}this.xOffset+=xref;
this.yOffset-=yref;
osg.setColor$java_awt_Color(this.getBackground$());
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
if (this.backgroundImage != null ) {
osg.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.backgroundImage, 0, 0, this);
}osg.clipRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
this.paintThingsBeforeGrid$java_awt_Graphics(osg);
this.paintGrid$java_awt_Graphics$I$I(osg, xo, yo);
this.paintThingsAfterGrid$java_awt_Graphics(osg);
this.xOffset-=xref;
this.yOffset+=yref;
this.paintTime$java_awt_Graphics(osg);
this.paintMessage$java_awt_Graphics(osg);
if (this.mouseDrag) {
this.paintCoords$java_awt_Graphics$I$I(osg, this.mouseX, this.mouseY);
}osg.dispose$();
});

Clazz.newMeth(C$, 'setTime$', function () {
this.time=this.owner.clock.getTime$();
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
t.setTime$D$D(this.time, this.owner.dt / 10000.0);
}
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
t.setVarsFromMaster$();
}
this.dynamics.resetDynamicsVariables$();
if (this.owner != null ) {
this.owner.updateDataConnections$();
}if (this.autoRefresh) {
this.paint$();
}});

Clazz.newMeth(C$, ['step$D$D','step$'], function (dt, time) {
if (dt == 0 ) return;
if (this.testForCollision$()) {
if ((this.owner.label_collision != null ) && !this.owner.label_collision.equals$O("") ) {
this.setMessage$S(this.owner.label_collision);
}this.owner.stopClock$();
return;
}this.bounceThings$();
this.dynamics.step$D$D(dt, time);
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
if (!t.dynamic && t.noDrag && (t.myMaster == null )  ) {
t.setVars$D$D(this.time + dt, dt);
}if (!t.dynamic) {
t.vars[0]=this.time + dt;
}if ((t.myMaster == null ) && !(Clazz.instanceOf(t, "animator4.TrailThing")) ) {
t.incTrail$();
}}
if (this.dragThing != null ) {
this.dragThing.vars[0]=this.time + dt;
this.dragThing.vars[3]=0;
this.dragThing.vars[4]=0;
}for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
if (t.myMaster != null ) {
t.setVarsFromMaster$();
t.incTrail$();
}}
this.time=time + dt;
if (this.owner != null ) {
this.owner.updateDataConnections$();
}this.paint$();
});

Clazz.newMeth(C$, 'setMessage$S', function (msg) {
if (((this.message == null ) && (msg == null ) ) || (this.message != null ) && this.message.equals$O(msg)  ) {
return;
}this.message=msg;
this.paintMessage$();
if (this.autoRefresh) {
this.repaint$();
}});

Clazz.newMeth(C$, 'setCaption$S', function (s) {
var id=this.addCaption$S$S$S$S(s, null, "0", "0");
if (this.autoRefresh) {
this.repaint$();
}return id;
});

Clazz.newMeth(C$, 'paintThingsBeforeGrid$java_awt_Graphics', function (g) {
var v;
{
v=this.things.clone$();
}for (var e=v.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
if (t.paintBeforeGrid) {
t.paint$java_awt_Graphics(g);
}}
});

Clazz.newMeth(C$, 'paintThingsAfterGrid$java_awt_Graphics', function (g) {
var v;
{
v=this.things.clone$();
}for (var e=v.elements$(); e.hasMoreElements$(); ) {
var t=e.nextElement$();
if (!t.paintBeforeGrid) {
t.paint$java_awt_Graphics(g);
}}
});

Clazz.newMeth(C$, 'paintTime$java_awt_Graphics', function (osg) {
osg.setColor$java_awt_Color($I$(7).black);
var f=osg.getFont$();
osg.setFont$java_awt_Font(this.boldFont);
var tStr=Clazz.new_($I$(3).c$$S,["%7.4g"]).form$D($I$(32).chop$D$D(this.time, 1.0E-12));
if (this.timeDisplay) {
if (this.iwidth > 150) {
osg.drawString$S$I$I(this.owner.label_time + ": " + tStr , 10, 15);
} else {
osg.drawString$S$I$I(this.owner.label_time + ": " + tStr , 10, this.iheight - 40);
}}osg.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$, 'paintGrid$java_awt_Graphics$I$I', function (osg, xo, yo) {
osg.setColor$java_awt_Color($I$(7).lightGray);
var gridSpace=(Math.round(this.pixPerUnit * this.gridUnit)|0);
if (gridSpace > 0) {
for (var i=xo % gridSpace; i < this.iwidth; i=i + gridSpace) {
osg.drawLine$I$I$I$I(i, 0, i, this.iheight);
}
}if (gridSpace > 0) {
for (var i=yo % gridSpace; i < this.iheight; i=i + gridSpace) {
osg.drawLine$I$I$I$I(0, i, this.iwidth, i);
}
}});

Clazz.newMeth(C$, 'paintMessage$', function () {
var g=this.getGraphics$();
if (g != null ) {
this.paintMessage$java_awt_Graphics(g);
g.dispose$();
}});

Clazz.newMeth(C$, 'paintMessage$java_awt_Graphics', function (osg) {
var tempMsg=this.message;
if (tempMsg == null  || osg == null  ) {
return;
}var fm=osg.getFontMetrics$java_awt_Font(osg.getFont$());
osg.setColor$java_awt_Color($I$(7).yellow);
var w=15 + fm.stringWidth$S(tempMsg);
var h=fm.getHeight$();
var off=-5;
osg.fillRect$I$I$I$I(this.iwidth - w - 5 , this.iheight - h + off, w, h);
osg.setColor$java_awt_Color($I$(7).black);
osg.drawString$S$I$I(tempMsg, this.iwidth - w + 2, this.iheight - 3 + off);
osg.drawRect$I$I$I$I(this.iwidth - w - 5 , this.iheight - h + off, w, h);
});

Clazz.newMeth(C$, 'paintCoords$I$I', function (xPix, yPix) {
var g=this.getGraphics$();
if (g != null ) {
this.paintCoords$java_awt_Graphics$I$I(g, xPix, yPix);
g.dispose$();
}});

Clazz.newMeth(C$, 'paintCoords$java_awt_Graphics$I$I', function (g, xPix, yPix) {
if (!this.coordDisplay) {
return;
}var msg="" + this.mouseFormat.form$D(this.xFromPix$I(xPix)) + " , " + this.mouseFormat.form$D(this.yFromPix$I(yPix)) ;
var r=this.getBounds$();
g.setColor$java_awt_Color($I$(7).yellow);
var fm=g.getFontMetrics$java_awt_Font(g.getFont$());
this.boxWidth=Math.max(20 + fm.stringWidth$S(msg), this.boxWidth);
g.fillRect$I$I$I$I(0, r.height - 20, this.boxWidth, 20);
g.setColor$java_awt_Color($I$(7).black);
g.drawString$S$I$I(msg, 10, r.height - 5);
g.drawRect$I$I$I$I(0, r.height - 19, this.boxWidth - 1, 20);
});

Clazz.newMeth(C$, 'xFromPix$I', function (x) {
var xo=(this.iwidth/2|0) - this.xOffset;
return (x - xo) / (1.0 * this.pixPerUnit);
});

Clazz.newMeth(C$, 'yFromPix$I', function (y) {
var yo=(this.iheight/2|0) + this.yOffset;
return -(y - yo) / (1.0 * this.pixPerUnit);
});

Clazz.newMeth(C$, 'pixFromX$D', function (x) {
var xpix=(((this.iwidth/2|0) + x * this.pixPerUnit - this.xOffset)|0);
return xpix;
});

Clazz.newMeth(C$, 'pixFromY$D', function (y) {
var ypix=(((this.iheight/2|0) - y * this.pixPerUnit + this.yOffset)|0);
return ypix;
});

Clazz.newMeth(C$, 'setDefault$', function () {
this.defaultColor=null;
this.referenceObject=null;
this.dragThing=null;
this.collisionDataSource=null;
if (!this.isJS) this.setBackground$java_awt_Color($I$(7).white);
this.xOffset=0;
this.yOffset=0;
this.dynamics=Clazz.new_($I$(5), [this, null]);
var v;
var t;
{
v=this.things.clone$();
this.things.removeAllElements$();
}for (var e=v.elements$(); e.hasMoreElements$(); ) {
t=e.nextElement$();
this.owner.removeDataListener$I(t.hashCode$());
this.owner.removeDataSource$I(t.hashCode$());
}
if (this.autoRefresh) {
this.repaint$();
}});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
try {
this.mouseFormat=Clazz.new_($I$(3).c$$S,[str]);
} catch (e) {
if (Clazz.exceptionOf(e,"IllegalArgumentException")){
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'setSketchMode$Z', function (sm) {
this.sketchImage=$I$(33).getImage$S$java_applet_Applet("pencil.gif", this.owner);
this.sketchMode=sm;
if (!sm) {
this.trailThing=null;
return 0;
}this.sketchCursor=null;
return 0;
});

Clazz.newMeth(C$, 'swapZOrder$I$I', function (id1, id2) {
var t1=this.getThing$I(id1);
var t2=this.getThing$I(id2);
if ((t1 == null ) || (t2 == null ) ) {
return false;
}var index1=this.things.indexOf$O(t1);
var index2=this.things.indexOf$O(t2);
this.things.removeElementAt$I(index1);
this.things.insertElementAt$TE$I(t2, index1);
this.things.removeElementAt$I(index2);
this.things.insertElementAt$TE$I(t1, index2);
if (this.autoRefresh) {
this.repaint$();
}return true;
});

Clazz.newMeth(C$, 'highlightMySlaves$animator4_Thing$java_awt_Graphics', function (master, g) {
var slave=null;
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
slave=e.nextElement$();
if (slave.myMaster === master ) {
slave.paintHighlight$java_awt_Graphics(g);
}}
});

Clazz.newMeth(C$, 'paintMyConnectors$animator4_Thing$java_awt_Graphics', function (t, g) {
var connector=null;
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
connector=e.nextElement$();
if ((Clazz.instanceOf(connector, "animator4.Connector")) && ((t === (connector).thing1 ) || (t === (connector).thing2 ) ) ) {
connector.paint$java_awt_Graphics(g);
}}
});

Clazz.newMeth(C$, 'isEnableMouse$', function () {
return this.enableMouse;
});

Clazz.newMeth(C$, 'isInsideDragableThing$I$I', function (x, y) {
var t=null;
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
t=e.nextElement$();
if ((!t.noDrag || t.resizable ) && t.isInsideThing$I$I(x, y) ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'isInsideStickyThing$I$I$animator4_Thing', function (x, y, exclude) {
var t=null;
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
t=e.nextElement$();
if ((!t.dynamic) && (t !== exclude ) && t.sticky && (t.isInsideThing$I$I(x, y) || exclude.isInsideThing$I$I(this.pixFromX$D(t.vars[1]), this.pixFromY$D(t.vars[2])) )  ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'bounceMe$I$I$animator4_Thing', function (x, y, me) {
var t=null;
for (var e=this.things.elements$(); e.hasMoreElements$(); ) {
t=e.nextElement$();
if ((t !== me ) && t.bouncy && t.isInsideThing$I$I(x, y)  ) {
var dx=Math.abs(me.vars[1] - t.vars[1]) - (t.w/this.pixPerUnit / 2.0 |0);
var dy=Math.abs(me.vars[2] - t.vars[2]) - (t.h/this.pixPerUnit / 2.0 |0);
if (Math.abs(dx) < Math.abs(dy) ) {
if ((me.vars[3] < t.vars[3] ) && (me.vars[1] > t.vars[1] ) ) {
me.vars[3]=-me.vars[3];
this.dynamics.resetDynamicsVariable$animator4_Thing(me);
} else if ((me.vars[3] > t.vars[3] ) && (me.vars[1] < t.vars[1] ) ) {
me.vars[3]=-me.vars[3];
this.dynamics.resetDynamicsVariable$animator4_Thing(me);
}} else {
if ((me.vars[4] < t.vars[4] ) && (me.vars[2] > t.vars[2] ) ) {
me.vars[4]=-me.vars[4];
this.dynamics.resetDynamicsVariable$animator4_Thing(me);
} else if ((me.vars[4] > t.vars[4] ) && (me.vars[2] < t.vars[2] ) ) {
me.vars[4]=-me.vars[4];
this.dynamics.resetDynamicsVariable$animator4_Thing(me);
}}}}
});

Clazz.newMeth(C$, 'testForCollision$', function () {
if (this.stickyCount == 0) {
return false;
}var t;
var n=this.things.size$();
this.stickyCount=0;
for (var i=0; i < n; i++) {
t=this.things.elementAt$I(i);
if (t.sticky && t.dynamic ) {
this.stickyCount++;
if (this.isInsideStickyThing$I$I$animator4_Thing(this.pixFromX$D(t.vars[1]), this.pixFromY$D(t.vars[2]), t)) {
if (this.collisionDataSource != null ) {
this.collisionDataSource.setXY$D$D(t.vars[1], t.vars[2]);
this.collisionDataSource.setBlock$Z(false);
this.owner.updateDataConnection$I(this.collisionDataSource.hashCode$());
this.collisionDataSource.setBlock$Z(true);
}return true;
}}}
return false;
});

Clazz.newMeth(C$, 'bounceThings$', function () {
if (this.bouncyCount == 0) {
return;
}var t;
var n=this.things.size$();
this.bouncyCount=0;
for (var i=0; i < n; i++) {
t=this.things.elementAt$I(i);
if (t.dynamic) {
this.bouncyCount++;
this.bounceMe$I$I$animator4_Thing(this.pixFromX$D(t.vars[1]), this.pixFromY$D(t.vars[2]), t);
}}
});

Clazz.newMeth(C$, 'setEnableMouse$Z', function (em) {
if (this.enableMouse == em ) {
return;
}this.enableMouse=em;
if (this.enableMouse) {
this.addMouseMotionListener$java_awt_event_MouseMotionListener(this.mouseMotionAdapter=Clazz.new_($I$(34).c$$animator4_AnimatorCanvas,[this]));
this.addMouseListener$java_awt_event_MouseListener(this.mouseAdapter=Clazz.new_($I$(35).c$$animator4_AnimatorCanvas,[this]));
} else {
this.removeMouseMotionListener$java_awt_event_MouseMotionListener(this.mouseMotionAdapter);
this.removeMouseListener$java_awt_event_MouseListener(this.mouseAdapter);
}});

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
if ((e.getModifiers$() & 4) != 0) {
} else {
this.mouseDrag=true;
this.mouseX=e.getX$();
this.mouseY=e.getY$();
this.updateMouseClickListeners$I$I(this.mouseX, this.mouseY);
var g=this.getGraphics$();
var n=this.things.size$();
for (var i=0; i < n; i++) {
var t=this.things.elementAt$I(i);
if ((!t.noDrag || t.resizable ) && t.isInsideThing$I$I(this.mouseX, this.mouseY) ) {
this.dragThing=t;
}}
if (this.dragThing != null ) {
this.mouseX=this.pixFromX$D(this.dragThing.getX$());
this.mouseY=this.pixFromY$D(this.dragThing.getY$());
var x=this.xFromPix$I(this.mouseX);
var y=this.yFromPix$I(this.mouseY);
if (this.dragThing.dynamic) {
this.dynamics.resetDynamicsDragThingVariables$D$D(x, y);
} else {
if (!(Clazz.instanceOf(this.dragThing, "animator4.ArrowStatic"))) {
this.dragThing.setXY$D$D(x, y);
}if (this.dampOnMousePressed) {
this.dragThing.setVX$D(0);
this.dragThing.setVY$D(0);
}}this.dragThing.updateMySlaves$();
this.owner.updateDataConnection$I(this.dragThing.hashCode$());
g.setXORMode$java_awt_Color(this.getBackground$());
this.dragThing.paintHighlight$java_awt_Graphics(g);
this.highlightMySlaves$animator4_Thing$java_awt_Graphics(this.dragThing, g);
g.setPaintMode$();
}g.dispose$();
this.paintCoords$I$I(this.mouseX, this.mouseY);
}if (this.sketchMode) {
if (this.trailThing == null ) {
this.trailThing=Clazz.new_($I$(36).c$$animator4_AnimatorCanvas$I,[this, 1]);
this.trailThing.trailSize=2000;
this.things.addElement$TE(this.trailThing);
}var maxPix=this.iwidth;
var minPix=0;
if (this.mouseX < minPix) {
this.mouseX=minPix;
} else if (this.mouseX > maxPix - 2) {
this.mouseX=maxPix - 2;
}var x=this.xFromPix$I(this.mouseX);
minPix=0;
maxPix=this.iheight;
if (this.mouseY < minPix) {
this.mouseY=minPix;
} else if (this.mouseY > maxPix - 2) {
this.mouseY=maxPix - 2;
}var y=this.yFromPix$I(this.mouseY);
this.trailThing.incTrail$D$D(x, y);
this.owner.clearData$I(this.trailThing.hashCode$());
this.setCursor$java_awt_Cursor($I$(37).getPredefinedCursor$I(1));
this.this_mouseDragged$java_awt_event_MouseEvent(e);
}});

Clazz.newMeth(C$, 'this_mouseDragged$java_awt_event_MouseEvent', function (e) {
this.mouseX=e.getX$();
this.mouseY=e.getY$();
var x;
var y;
var maxPix=this.iwidth;
var minPix=0;
if (this.mouseX < minPix) {
this.mouseX=minPix;
} else if (this.mouseX > maxPix - 2) {
this.mouseX=maxPix - 2;
}x=this.xFromPix$I(this.mouseX);
minPix=0;
maxPix=this.iheight;
if (this.mouseY < minPix) {
this.mouseY=minPix;
} else if (this.mouseY > maxPix - 2) {
this.mouseY=maxPix - 2;
}y=this.yFromPix$I(this.mouseY);
this.updateMouseDragListeners$D$D(x, y);
if (this.dragThing != null ) {
if (this.dragThing.dynamic) {
this.dynamics.resetDynamicsDragThingVariables$D$D(x, y);
} else {
this.dragThing.setXY$D$D(x, y);
if (this.dampOnMousePressed) {
this.dragThing.setVX$D(0);
this.dragThing.setVY$D(0);
}}this.dragThing.updateMySlaves$();
if (!this.owner.isClockRunning$()) {
this.owner.updateDataConnection$I(this.dragThing.hashCode$());
this.paint$();
}} else if (this.sketchMode && (this.trailThing != null ) ) {
this.trailThing.incTrail$D$D(x, y);
var g=this.getGraphics$();
this.paint$java_awt_Graphics(g);
if (this.sketchImage != null ) {
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.sketchImage, this.mouseX, this.mouseY - this.sketchImage.getHeight$java_awt_image_ImageObserver(this), this);
}this.trailThing.paint$java_awt_Graphics(g);
g.dispose$();
this.owner.updateDataConnection$I(this.trailThing.hashCode$());
}this.paintCoords$I$I(this.mouseX, this.mouseY);
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.mouseDrag=false;
var r=this.getBounds$();
if (this.sketchMode && (this.trailThing != null ) ) {
this.owner.updateDataConnection$I(this.trailThing.hashCode$());
this.trailThing=null;
}if ((this.dragThing == null ) && !this.sketchMode ) {
this.repaint$I$I$I$I(0, r.height - 20, this.boxWidth, 20);
} else {
this.paint$();
}this.dragThing=null;
this.setCursor$java_awt_Cursor($I$(37).getPredefinedCursor$I(1));
this.boxWidth=0;
if (e == null ) {
return;
}this.mouseX=e.getX$();
this.mouseY=e.getY$();
this.updateMouseReleaseListeners$I$I(this.mouseX, this.mouseY);
});

Clazz.newMeth(C$, 'this_mouseEntered$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor($I$(37).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$, 'this_mouseExited$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor($I$(37).getPredefinedCursor$I(0));
});

Clazz.newMeth(C$, 'this_mouseMoved$java_awt_event_MouseEvent', function (e) {
this.mouseX=e.getX$();
this.mouseY=e.getY$();
this.updateMouseMovedListeners$I$I(this.mouseX, this.mouseY);
if (this.isInsideDragableThing$I$I(this.mouseX, this.mouseY)) {
this.setCursor$java_awt_Cursor($I$(37).getPredefinedCursor$I(12));
} else {
this.setCursor$java_awt_Cursor($I$(37).getPredefinedCursor$I(1));
}});
;
(function(){var C$=Clazz.newClass(P$.AnimatorCanvas, "DynamicsSolver", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.numerics.SDifferentiable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.n=0;
this.odeSolver=null;
this.dxdt=null;
this.vars=null;
this.dThings=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.n=1;
this.odeSolver=Clazz.new_($I$(1));
this.dxdt=Clazz.array(Double.TYPE, [1]);
this.vars=Clazz.array(Double.TYPE, [1]);
this.dThings=Clazz.new_($I$(2));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.odeSolver.setDifferentials$edu_davidson_numerics_SDifferentiable(this);
}, 1);

Clazz.newMeth(C$, 'rate$DA', function (x) {
var t;
if (4 * this.dThings.size$() != this.n - 1) {
return Clazz.array(Double.TYPE, [this.n]);
}this.updateThings$();
this.dxdt[0]=1;
for (var i=1; i < this.n; i=i + 4) {
t=this.dThings.elementAt$I(((i - 1)/4|0));
if (t.constrainX) {
this.dxdt[i]=0;
} else {
this.dxdt[i]=x[i + 2];
}if (t.constrainY) {
this.dxdt[i + 1]=0;
} else {
this.dxdt[i + 1]=x[i + 3];
}if (t.constrainR) {
t.constrainedRForce$I$DA(i, this.dxdt);
} else {
this.dxdt[i + 2]=t.getFx$() / t.mass;
this.dxdt[i + 3]=t.getFy$() / t.mass;
}}
return this.dxdt;
});

Clazz.newMeth(C$, 'getNumEqu$', function () {
return this.n;
});

Clazz.newMeth(C$, 'addRateEquation$animator4_Thing', function (t) {
var shouldRun=false;
if (this.this$0.owner.isClockRunning$()) {
shouldRun=true;
this.this$0.owner.pause$();
}this.dThings.addElement$TE(t);
this.dxdt=Clazz.array(Double.TYPE, [this.n + 4]);
this.vars=Clazz.array(Double.TYPE, [this.n + 4]);
this.vars[0]=this.this$0.time;
this.n+=4;
for (var i=1; i < this.n; i=i + 4) {
t=this.dThings.elementAt$I(((i - 1)/4|0));
this.vars[i]=t.vars[1];
this.vars[i + 1]=t.vars[2];
this.vars[i + 2]=t.vars[3];
this.vars[i + 3]=t.vars[4];
}
t.vars[5]=t.getTotalFx$() / t.mass;
t.vars[6]=t.getTotalFy$() / t.mass;
this.odeSolver.setDifferentials$edu_davidson_numerics_SDifferentiable(this);
if (shouldRun) {
this.this$0.owner.forward$();
}});

Clazz.newMeth(C$, 'resetDynamicsDragThingVariables$D$D', function (x, y) {
var shouldRun=false;
if (this.this$0.owner.isClockRunning$()) {
shouldRun=true;
this.this$0.owner.pause$();
}this.vars[0]=this.this$0.time;
for (var i=1; i < this.n; i=i + 4) {
var t=this.dThings.elementAt$I(((i - 1)/4|0));
if (t === this.this$0.dragThing ) {
t.vars[1]=x;
t.vars[2]=y;
if (this.this$0.dampOnMousePressed) {
t.vars[3]=0;
t.vars[4]=0;
}t.enforceConstraintOnXY$();
this.vars[i]=t.vars[1];
this.vars[i + 1]=t.vars[2];
this.vars[i + 2]=t.vars[3];
;this.vars[i + 3]=t.vars[4];
;t.vars[5]=0;
t.vars[6]=0;
}}
if (shouldRun) {
this.this$0.owner.forward$();
}});

Clazz.newMeth(C$, 'resetDynamicsVariable$animator4_Thing', function (t) {
var i=this.dThings.indexOf$O(t);
i=1 + i * 4;
this.vars[i]=t.vars[1];
this.vars[i + 1]=t.vars[2];
this.vars[i + 2]=t.vars[3];
this.vars[i + 3]=t.vars[4];
});

Clazz.newMeth(C$, 'resetDynamicsVariables$', function () {
var shouldRun=false;
if (this.this$0.owner.isClockRunning$()) {
shouldRun=true;
this.this$0.owner.pause$();
}this.vars[0]=this.this$0.time;
for (var i=1; i < this.n; i=i + 4) {
var t=this.dThings.elementAt$I(((i - 1)/4|0));
this.vars[i]=t.vars[1];
this.vars[i + 1]=t.vars[2];
this.vars[i + 2]=t.vars[3];
this.vars[i + 3]=t.vars[4];
t.vars[5]=t.getTotalFx$() / t.mass;
t.vars[6]=t.getTotalFy$() / t.mass;
}
if (shouldRun) {
this.this$0.owner.forward$();
}});

Clazz.newMeth(C$, 'updateThings$', function () {
var t;
for (var i=1; i < this.n; i=i + 4) {
t=this.dThings.elementAt$I(((i - 1)/4|0));
t.vars[0]=this.vars[0];
t.vars[1]=this.vars[i];
t.vars[2]=this.vars[i + 1];
t.vars[3]=this.vars[i + 2];
t.vars[4]=this.vars[i + 3];
}
});

Clazz.newMeth(C$, 'setTolerance$D', function (t) {
this.odeSolver.setTol$D(t);
});

Clazz.newMeth(C$, 'step$D$D', function (dt, time) {
if (dt == 0 ) {
return;
}var t;
if (this.n < 2) {
return;
}this.vars[0]=time;
this.odeSolver.step$D$DA(dt, this.vars);
for (var i=1; i < this.n; i=i + 4) {
t=this.dThings.elementAt$I(((i - 1)/4|0));
t.vars[0]=time + dt;
t.vars[1]=this.vars[i];
t.vars[2]=this.vars[i + 1];
t.vars[3]=this.vars[i + 2];
t.vars[4]=this.vars[i + 3];
if (t.enforceConstraintOnXY$()) {
this.vars[i + 2]=t.vars[3];
this.vars[i + 3]=t.vars[4];
}t.vars[5]=t.getTotalFx$() / t.mass;
t.vars[6]=t.getTotalFy$() / t.mass;
if (t === this.this$0.dragThing ) {
this.vars[i]=this.this$0.xFromPix$I.apply(this.this$0, [this.this$0.mouseX]);
this.vars[i + 1]=this.this$0.yFromPix$I.apply(this.this$0, [this.this$0.mouseY]);
this.vars[i + 2]=0;
this.vars[i + 3]=0;
}}
if (this.this$0.dragThing != null  && this.this$0.dragThing.dynamic ) {
this.this$0.dragThing.vars[1]=this.this$0.xFromPix$I.apply(this.this$0, [this.this$0.mouseX]);
this.this$0.dragThing.vars[2]=this.this$0.yFromPix$I.apply(this.this$0, [this.this$0.mouseY]);
if (this.this$0.dampOnMousePressed) {
this.this$0.dragThing.vars[3]=0;
this.this$0.dragThing.vars[4]=0;
}this.this$0.dragThing.enforceConstraintOnXY$();
this.this$0.dragThing.vars[5]=this.this$0.dragThing.getTotalFx$() / this.this$0.dragThing.mass;
this.this$0.dragThing.vars[6]=this.this$0.dragThing.getTotalFy$() / this.this$0.dragThing.mass;
}});
})()
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:44 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
