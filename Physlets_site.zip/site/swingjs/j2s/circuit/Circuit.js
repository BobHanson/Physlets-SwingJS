(function(){var P$=Clazz.newPackage("circuit"),I$=[['java.util.Vector','circuit.Circuit_mouseMotionAdapter','java.awt.Color','circuit.Battery','circuit.Resistor','circuit.Capacitor','circuit.SineWave','circuit.OnOffSwitch','circuit.Inductor','circuit.Transformer','circuit.Part','circuit.Wire','circuit.Voltmeter','circuit.Ammeter','java.awt.Dimension','java.awt.Cursor']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Circuit", null, 'edu.davidson.graphics.HintPanel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.osi = null;
this.osiInvalid = false;
this.iwidth = 0;
this.iheight = 0;
this.xOffset = 0;
this.yOffset = 0;
this.pixPerCell = 0;
this.preferredPixPerCell = 0;
this.iGrid = 0;
this.jGrid = 0;
this.parts = null;
this.maxNumber = 0;
this.owner = null;
this.showV = null;
this.showCurrent = null;
this.showPhase = null;
this.showF = null;
this.showR = null;
this.showC = null;
this.showL = null;
this.showZ = null;
this.dataSources = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.osi = null;
this.osiInvalid = true;
this.iwidth = 0;
this.iheight = 0;
this.pixPerCell = 60;
this.preferredPixPerCell = 60;
this.iGrid = 3;
this.jGrid = 3;
this.parts = Clazz.new_((I$[1]||$incl$(1)));
this.maxNumber = 50;
this.showV = null;
this.showCurrent = null;
this.showPhase = null;
this.showF = null;
this.showR = null;
this.showC = null;
this.showL = null;
this.showZ = null;
this.dataSources = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet', function (o) {
Clazz.super_(C$, this,1);
this.owner = o;
this.addMouseMotionListener$java_awt_event_MouseMotionListener(Clazz.new_((I$[2]||$incl$(2)).c$$circuit_Circuit,[this]));
this.setBackground$java_awt_Color(Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I,[225, 225, 225]));
}, 1);

Clazz.newMeth(C$, 'addBattery$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var battery = Clazz.new_((I$[4]||$incl$(4)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(battery);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(battery);
return battery;
});

Clazz.newMeth(C$, 'addResistor$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var resistor = Clazz.new_((I$[5]||$incl$(5)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(resistor);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(resistor);
return resistor;
});

Clazz.newMeth(C$, 'addCapacitor$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var capacitor = Clazz.new_((I$[6]||$incl$(6)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(capacitor);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(capacitor);
return capacitor;
});

Clazz.newMeth(C$, 'addSineWave$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var sineWave = Clazz.new_((I$[7]||$incl$(7)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(sineWave);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(sineWave);
return sineWave;
});

Clazz.newMeth(C$, 'addOnOffSwitch$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var onOffSwitch = Clazz.new_((I$[8]||$incl$(8)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(onOffSwitch);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(onOffSwitch);
return onOffSwitch;
});

Clazz.newMeth(C$, 'addInductor$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var inductor = Clazz.new_((I$[9]||$incl$(9)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(inductor);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(inductor);
return inductor;
});

Clazz.newMeth(C$, 'addTransformer$I$I$I$I$Z', function (i1, j1, i2, j2, vert) {
if (this.parts.size() >= this.maxNumber) return null;
var transformer = Clazz.new_((I$[10]||$incl$(10)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I$Z,[this.owner, this, i1, j1, i2, j2, vert]);
this.parts.addElement$TE(transformer);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(transformer);
return transformer;
});

Clazz.newMeth(C$, 'addPart$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var part = Clazz.new_((I$[11]||$incl$(11)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(part);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(part);
return part;
});

Clazz.newMeth(C$, 'addWire$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var wire = Clazz.new_((I$[12]||$incl$(12)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(wire);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(wire);
return wire;
});

Clazz.newMeth(C$, 'addVoltmeter$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var voltmeter = Clazz.new_((I$[13]||$incl$(13)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(voltmeter);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(voltmeter);
return voltmeter;
});

Clazz.newMeth(C$, 'addAmmeter$I$I$I$I', function (i1, j1, i2, j2) {
if (this.parts.size() >= this.maxNumber) return null;
var ammeter = Clazz.new_((I$[14]||$incl$(14)).c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I,[this.owner, this, i1, j1, i2, j2]);
this.parts.addElement$TE(ammeter);
this.osiInvalid = true;
this.repaint();
this.setShowInfo$circuit_Part(ammeter);
return ammeter;
});

Clazz.newMeth(C$, 'getPartFromID$I', function (id) {
for (var i = 0; i < this.parts.size(); i++) {
var p = this.parts.elementAt$I(i);
if (p.getID() == id) return p;
}
return null;
});

Clazz.newMeth(C$, 'getMinimumSize', function () {
return Clazz.new_((I$[15]||$incl$(15)).c$$I$I,[20 * (this.jGrid), 20 * (this.iGrid)]);
});

Clazz.newMeth(C$, 'getPreferredSize', function () {
return Clazz.new_((I$[15]||$incl$(15)).c$$I$I,[this.preferredPixPerCell * (this.jGrid), this.preferredPixPerCell * (this.iGrid)]);
});

Clazz.newMeth(C$, 'getOsi', function () {
return this.osi;
});

Clazz.newMeth(C$, 'forceRepaint', function () {
this.osiInvalid = true;
this.repaint();
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.owner.destroyed) return;
if (this.getSize().width == 0 || this.getSize().height == 0 ) return;
if (this.osi == null  || this.osiInvalid  || this.iwidth != this.getSize().width  || this.iheight != this.getSize().height ) {
this.paintOSI();
}g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
this.paintHint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintGrid$java_awt_Graphics', function (g) {
if (this.owner.destroyed) return;
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
for (var i = 0; i < this.iGrid; i++) for (var j = 0; j < this.jGrid; j++) g.drawLine$I$I$I$I(this.xOffset + this.pixPerCell * j, this.yOffset + this.pixPerCell * i, this.xOffset + this.pixPerCell * j, this.yOffset + this.pixPerCell * i);


});

Clazz.newMeth(C$, 'paintParts$java_awt_Graphics', function (g) {
if (this.owner.destroyed) return;
for (var i = 0; i < this.parts.size(); i++) {
var p = this.parts.elementAt$I(i);
p.paint$java_awt_Graphics$I$I$I(g, this.pixPerCell, this.xOffset, this.yOffset);
}
});

Clazz.newMeth(C$, 'paintOSI', function () {
if (this.owner.destroyed) return;
if (this.osi == null  || this.iwidth != this.getSize().width  || this.iheight != this.getSize().height ) {
this.iwidth = this.getSize().width;
this.iheight = this.getSize().height;
this.osi = this.createImage$I$I(this.iwidth, this.iheight);
}this.pixPerCell = this.preferredPixPerCell;
if (this.iwidth < (this.jGrid) * this.pixPerCell) this.pixPerCell = (this.iwidth/(this.jGrid)|0);
if (this.iheight < (this.iGrid) * this.pixPerCell) this.pixPerCell = (this.iheight/(this.iGrid)|0);
this.xOffset = ((this.iwidth - (this.jGrid - 1) * this.pixPerCell)/2|0);
this.yOffset = ((this.iheight - (this.iGrid - 1) * this.pixPerCell)/2|0);
var osg = this.osi.getGraphics();
osg.setColor$java_awt_Color(this.getBackground());
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
this.paintParts$java_awt_Graphics(osg);
osg.dispose();
this.osiInvalid = false;
return;
});

Clazz.newMeth(C$, 'setBatteryEMF$I$D$Z', function (id, emf, showV) {
var bat = this.getPartFromID$I(id);
if (Clazz.instanceOf(bat, "circuit.Battery")) {
bat.setVoltRMS$D(emf);
bat.showV = showV;
return true;
} else return false;
});

Clazz.newMeth(C$, 'setCapacitance$I$D$Z$Z$Z', function (id, c, showC, showV, showPhase) {
var cap = this.getPartFromID$I(id);
if (Clazz.instanceOf(cap, "circuit.Capacitor")) {
cap.setC$D(c);
cap.showC = showC;
cap.showV = showV;
cap.showPhase = showPhase;
return true;
} else return false;
});

Clazz.newMeth(C$, 'setSwitchOn$I$Z', function (id, on) {
var sw = this.getPartFromID$I(id);
if (Clazz.instanceOf(sw, "circuit.OnOffSwitch")) {
sw.setSwitchOn$Z(on);
return true;
} else return false;
});

Clazz.newMeth(C$, 'setCurrent$I$D', function (id, c) {
var part = this.getPartFromID$I(id);
part.setCurrentRMS$D(c);
return true;
});

Clazz.newMeth(C$, 'setShowCurrent$I$Z', function (id, sc) {
var part = this.getPartFromID$I(id);
part.showCurrent = sc;
return true;
});

Clazz.newMeth(C$, 'setPhaseDegree$I$D', function (id, p) {
var part = this.getPartFromID$I(id);
part.setPhaseDegree$D(p);
return true;
});

Clazz.newMeth(C$, 'setShowPhase$I$Z', function (id, sp) {
var part = this.getPartFromID$I(id);
part.showPhase = sp;
return true;
});

Clazz.newMeth(C$, 'setVolt$I$D', function (id, v) {
var part = this.getPartFromID$I(id);
part.setVoltRMS$D(v);
return true;
});

Clazz.newMeth(C$, 'setShowV$I$Z', function (id, sv) {
var part = this.getPartFromID$I(id);
part.showV = sv;
return true;
});

Clazz.newMeth(C$, 'setInductance$I$D$Z$Z$Z', function (id, l, showL, showV, showPhase) {
var ind = this.getPartFromID$I(id);
if (Clazz.instanceOf(ind, "circuit.Inductor")) {
ind.setL$D(l);
ind.showL = showL;
ind.showV = showV;
ind.showPhase = showPhase;
return true;
} else return false;
});

Clazz.newMeth(C$, 'setResistance$I$D$Z$Z$Z', function (id, r, showR, showV, showPhase) {
var res = this.getPartFromID$I(id);
if (Clazz.instanceOf(res, "circuit.Resistor")) {
res.setR$D(r);
res.showR = showR;
res.showV = showV;
res.showPhase = showPhase;
return true;
} else return false;
});

Clazz.newMeth(C$, 'setAmmeter$I$D$Z', function (id, a, sc) {
var meter = this.getPartFromID$I(id);
if (Clazz.instanceOf(meter, "circuit.Ammeter")) {
meter.setCurrentRMS$D(a);
meter.showCurrent = sc;
return true;
} else return false;
});

Clazz.newMeth(C$, 'setLabel$I$S', function (id, str) {
var part = this.getPartFromID$I(id);
part.setLabel$S(str);
return true;
});

Clazz.newMeth(C$, 'setHint$I$S', function (id, str) {
var part = this.getPartFromID$I(id);
part.setCustomHint$S(str);
return true;
});

Clazz.newMeth(C$, 'setMilliAmp$I$Z', function (id, sma) {
var part = this.getPartFromID$I(id);
part.milliAmp = sma;
return true;
});

Clazz.newMeth(C$, 'setVoltage$I$D', function (id, v) {
var part = this.getPartFromID$I(id);
part.setVoltRMS$D(v);
return true;
});

Clazz.newMeth(C$, 'setVoltmeter$I$D$Z', function (id, v, sv) {
var meter = this.getPartFromID$I(id);
if (Clazz.instanceOf(meter, "circuit.Voltmeter")) {
meter.setVoltRMS$D(v);
meter.showV = sv;
return true;
} else return false;
});

Clazz.newMeth(C$, 'isInside$I$I', function (xpix, ypix) {
for (var i = 0; i < this.parts.size(); i++) {
var p = this.parts.elementAt$I(i);
if (p.isInside$I$I$I$I$I(xpix, ypix, this.pixPerCell, this.xOffset, this.yOffset)) return p;
}
return null;
});

Clazz.newMeth(C$, 'setShowInfo$circuit_Part', function (p) {
if (this.showV != null ) p.showV = this.showV.booleanValue();
if (this.showCurrent != null ) p.showCurrent = this.showCurrent.booleanValue();
if (this.showPhase != null ) p.showPhase = this.showPhase.booleanValue();
if (this.showF != null ) p.showF = this.showF.booleanValue();
if (this.showR != null ) p.showR = this.showR.booleanValue();
if (this.showC != null ) p.showC = this.showC.booleanValue();
if (this.showL != null ) p.showL = this.showL.booleanValue();
if (this.showZ != null ) p.showZ = this.showZ.booleanValue();
});

Clazz.newMeth(C$, 'setDefault$I', function (ppc) {
this.setDefault();
this.preferredPixPerCell = ppc;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.updateBubbleHelp$S(null);
this.destroyHint();
this.showV = null;
this.showCurrent = null;
this.showPhase = null;
this.showF = null;
this.showR = null;
this.showC = null;
this.showL = null;
this.showZ = null;
this.parts.removeAllElements();
});

Clazz.newMeth(C$, 'setShowV$Z', function (val) {
this.showV =  Boolean.from(val);
});

Clazz.newMeth(C$, 'setShowCurrent$Z', function (val) {
this.showCurrent =  Boolean.from(val);
});

Clazz.newMeth(C$, 'setShowPhase$Z', function (val) {
this.showPhase =  Boolean.from(val);
});

Clazz.newMeth(C$, 'setShowF$Z', function (val) {
this.showPhase =  Boolean.from(val);
});

Clazz.newMeth(C$, 'setShowR$Z', function (val) {
this.showR =  Boolean.from(val);
});

Clazz.newMeth(C$, 'setShowC$Z', function (val) {
this.showC =  Boolean.from(val);
});

Clazz.newMeth(C$, 'setShowL$Z', function (val) {
this.showL =  Boolean.from(val);
});

Clazz.newMeth(C$, 'setShowZ$Z', function (val) {
this.showZ =  Boolean.from(val);
});

Clazz.newMeth(C$, 'setPreferredPixPerCell$I', function (ppc) {
this.pixPerCell = ppc;
this.preferredPixPerCell = ppc;
this.invalidate();
if (this.getParent() != null ) this.getParent().validate();
 else this.validate();
});

Clazz.newMeth(C$, 'setGridSize$I$I', function (gsi, gsj) {
this.iGrid = gsi;
this.jGrid = gsj;
this.invalidate();
if (this.getParent() != null ) this.getParent().validate();
 else this.validate();
});

Clazz.newMeth(C$, 'this_mouseMoved$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor((I$[16]||$incl$(16)).getPredefinedCursor$I(1));
var xPix = e.getX();
var yPix = e.getY();
var p = this.isInside$I$I(xPix, yPix);
if (p != null ) {
this.updateBubbleHelp$S(p.getHint());
} else {
this.updateBubbleHelp$S(null);
}});

Clazz.newMeth(C$, 'this_mouseDragged$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:06:38
