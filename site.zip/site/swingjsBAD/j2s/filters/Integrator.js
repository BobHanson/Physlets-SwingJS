(function(){var P$=Clazz.newPackage("filters"),I$=[['edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Integrator", null, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataListener', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.xiStr = null;
this.xIntegrand = null;
this.yiStr = null;
this.yIntegrand = null;
this.varStrings = null;
this.variables = null;
this.n = 0;
this.sumX = 0;
this.sumY = 0;
this.lastX = 0;
this.lastY = 0;
this.lastXIntegrand = 0;
this.lastYIntegrand = 0;
this.dx = 0;
this.dy = 0;
this.ds = 0;
this.$isStandalone = false;
this.mode = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.xIntegrand = null;
this.yIntegrand = null;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "n", "integral", "ds"]);
this.variables = Clazz.array(Double.TYPE, [1, 5]);
this.n = 0;
this.sumX = 0;
this.sumY = 0;
this.lastX = 0;
this.lastY = 0;
this.dx = 0;
this.dy = 0;
this.ds = 0;
this.$isStandalone = false;
this.mode = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
var diffStr = "dx";
try {
this.varStrings[0]=this.getParameter$S$S("Independent", "x");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
diffStr=this.getParameter$S$S("Differential", "dx");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xiStr=this.getParameter$S$S("Integrand", this.varStrings[1]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.yiStr= String.instantialize(this.xiStr);
diffStr=diffStr.toLowerCase();
if (diffStr.equals$O("dx")) this.mode=0;
 else if (diffStr.equals$O("dy")) this.mode=1;
 else if (diffStr.equals$O("ds")) this.mode=2;
 else {
this.mode=0;
System.out.println$S("Differential parameter invalid. Use dx, dy or ds.");
}edu.davidson.tools.SApplet.addDataListener$O(this);
edu.davidson.tools.SApplet.addDataSource$O(this);
});

Clazz.newMeth(C$, 'parseXIntegrand$edu_davidson_tools_SDataSource', function (s) {
this.xiStr=this.xiStr.trim();
this.xiStr=this.xiStr.toLowerCase();
var num = s.getVarStrings().length;
this.xIntegrand=Clazz.new_((I$[1]||$incl$(1)).c$$I,[num]);
for (var i = 0; i < num; i++) {
this.xIntegrand.defineVariable$I$S(1 + i, s.getVarStrings()[i]);
}
this.xIntegrand.define$S(this.xiStr);
this.xIntegrand.parse();
if (this.xIntegrand.getErrorCode() != 0) {
System.out.println$S("Failed to parse the x integrand in filters.Integrator: " + this.xiStr);
System.out.println$S("Parse error: " + this.xIntegrand.getErrorString() + " at function 1, position " + this.xIntegrand.getErrorPosition() );
this.xIntegrand=null;
return false;
}return true;
});

Clazz.newMeth(C$, 'parseYIntegrand$edu_davidson_tools_SDataSource', function (s) {
this.yiStr=this.yiStr.trim();
this.yiStr=this.yiStr.toLowerCase();
var num = s.getVarStrings().length;
this.yIntegrand=Clazz.new_((I$[1]||$incl$(1)).c$$I,[num]);
for (var i = 0; i < num; i++) {
this.yIntegrand.defineVariable$I$S(1 + i, s.getVarStrings()[i]);
}
this.yIntegrand.define$S(this.yiStr);
this.yIntegrand.parse();
if (this.yIntegrand.getErrorCode() != 0) {
System.out.println$S("Failed to parse the y integrand in filters.Integrator: " + this.yiStr);
System.out.println$S("Parse error: " + this.yIntegrand.getErrorString() + " at function 1, position " + this.yIntegrand.getErrorPosition() );
this.yIntegrand=null;
return false;
}return true;
});

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Integrator Physlets";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Integrand", "String", "Integrand"]), Clazz.array(java.lang.String, -1, ["Differential", "String", "Differential"])]);
return pinfo;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.variables[0][0]=this.lastX;
this.variables[0][1]=this.lastY;
this.variables[0][2]=this.n;
this.variables[0][3]=this.sumX + this.sumY;
this.variables[0][4]=this.ds;
return this.variables;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, 'reset', function () {
this.sumX=0;
this.sumY=0;
this.n=0;
this.updateDataConnections();
});

Clazz.newMeth(C$, ['setLineIntegralMode$S$S','setLineIntegralMode'], function (xComponent, yComponent) {
this.mode=3;
this.xIntegrand=null;
this.yIntegrand=null;
this.xiStr=xComponent;
this.yiStr=yComponent;
this.sumX=0;
this.sumY=0;
this.n=0;
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, x, y) {
if (this.xIntegrand == null  && this.xiStr != null  ) p$.parseXIntegrand$edu_davidson_tools_SDataSource.apply(this, [s]);
if (this.yIntegrand == null  && this.yiStr != null  ) p$.parseYIntegrand$edu_davidson_tools_SDataSource.apply(this, [s]);
this.dx=(x - this.lastX);
this.dy=(y - this.lastY);
this.ds=Math.sqrt(this.dx * this.dx + this.dy * this.dy);
var tmp = 0;
if (this.n > 0) switch (this.mode) {
case 0:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += (tmp + this.lastXIntegrand) * this.dx / 2;
this.lastXIntegrand=tmp;
break;
case 1:
if (this.yIntegrand != null ) tmp=this.yIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumY += (tmp + this.lastYIntegrand) * this.dy / 2;
this.lastYIntegrand=tmp;
break;
case 2:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += (tmp + this.lastXIntegrand) * this.ds / 2;
this.lastXIntegrand=tmp;
break;
case 3:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += (tmp + this.lastXIntegrand) * this.dx / 2;
this.lastXIntegrand=tmp;
if (this.yIntegrand != null ) tmp=this.yIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumY += (tmp + this.lastYIntegrand) * this.dy / 2;
this.lastYIntegrand=tmp;
break;
default:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += (tmp + this.lastXIntegrand) * this.dx / 2;
this.lastXIntegrand=tmp;
}
this.lastX=x;
this.lastY=y;
this.n++;
this.updateDataConnections();
});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
if (this.xIntegrand == null  && this.xiStr != null  ) p$.parseXIntegrand$edu_davidson_tools_SDataSource.apply(this, [s]);
if (this.yIntegrand == null  && this.yiStr != null  ) p$.parseYIntegrand$edu_davidson_tools_SDataSource.apply(this, [s]);
this.sumX=0;
this.sumY=0;
this.n=x.length;
if (this.n < 2) return;
var tmp = 0;
this.dx=(x[1] - x[0]) / 2;
this.dy=(y[1] - y[0]) / 2;
for (var i = 0; i < this.n; i++) {
this.ds=Math.sqrt(this.dx * this.dx + this.dy * this.dy);
switch (this.mode) {
case 0:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += tmp * this.dx;
break;
case 1:
if (this.yIntegrand != null ) tmp=this.yIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumY += tmp * this.dy;
break;
case 2:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += tmp * this.ds;
break;
case 3:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += tmp * this.dx;
if (this.yIntegrand != null ) tmp=this.yIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumY += tmp * this.dy;
break;
default:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += tmp * this.dx;
}
if (i < this.n - 3) {
this.dx=(x[i + 2] - x[i + 1]);
this.dy=(y[i + 2] - y[i + 1]);
} else if (i < this.n - 2) {
this.dx=(x[i + 2] - x[i + 1]) / 2;
this.dy=(y[i + 2] - y[i + 1]) / 2;
} else {
}}
this.updateDataConnections();
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.reset();
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
this.reset();
});
})();
//Created 2018-07-23 12:59:29 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
