(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[];
var C$=Clazz.newInterface(P$, "SScalable");
})();
//Created 2018-07-23 12:59:46 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
