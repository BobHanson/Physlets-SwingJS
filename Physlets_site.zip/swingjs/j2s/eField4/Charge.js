(function(){var P$=Clazz.newPackage("eField4"),I$=[['java.awt.Polygon','java.awt.Font','java.awt.Color','edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Charge", null, 'eField4.Thing', 'Cloneable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$D$D', function (p, x, y, vx, vy) {
C$.c$$eField4_OdeCanvas$D$D$D$D$D.apply(this, [p, x, y, vx, vy, 1.0]);
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$D$D$D', function (p, x, y, vx, vy, m) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D$D.apply(this, [p, x, y, vx, vy, m]);
C$.$init$.apply(this);
this.sticky = true;
this.noDrag = false;
this.p = p;
this.vars[0] = 0;
this.vars[1] = x;
this.vars[2] = y;
this.vars[3] = vx;
this.vars[4] = vy;
this.initVars[0] = 0;
this.initVars[1] = x;
this.initVars[2] = y;
this.initVars[3] = vx;
this.initVars[4] = vy;
this.mag = m;
this.showFVector = true;
this.ds = Clazz.array(Double.TYPE, [1, 12]);
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "vx", "vy", "ax", "ay", "fx", "fy", "p", "m", "q"]);
}, 1);

Clazz.newMeth(C$, 'setAcceleration', function () {
this.vars[5] = this.mag * (-this.p.dudx$D$D(this.vars[1], this.vars[2]) + this.p.getPoleFx$D$D$eField4_Charge(this.vars[1], this.vars[2], this) + this.p.bz * this.vars[4] );
this.vars[6] = this.mag * (-this.p.dudy$D$D(this.vars[1], this.vars[2]) + this.p.getPoleFy$D$D$eField4_Charge(this.vars[1], this.vars[2], this) - this.p.bz * this.vars[3]);
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.vars[0];
this.ds[0][1] = this.vars[1];
this.ds[0][2] = this.vars[2];
this.ds[0][3] = this.vars[3];
this.ds[0][4] = this.vars[4];
this.ds[0][7] = this.mag * (-this.p.dudx$D$D(this.vars[1], this.vars[2]) + this.p.getPoleFx$D$D$eField4_Charge(this.vars[1], this.vars[2], this) + this.p.bz * this.vars[4] );
this.ds[0][8] = this.mag * (-this.p.dudy$D$D(this.vars[1], this.vars[2]) + this.p.getPoleFy$D$D$eField4_Charge(this.vars[1], this.vars[2], this) - this.p.bz * this.vars[3]);
if (this.hasTrajectory()) {
this.ds[0][5] = this.vars[5];
this.ds[0][6] = this.vars[6];
} else {
this.ds[0][5] = this.ds[0][7] / this.mass;
this.ds[0][6] = this.ds[0][8] / this.mass;
}if (this.p.parser != null ) this.ds[0][9] = this.p.parser.evaluate$D$D(this.vars[1], this.vars[2]) + this.p.getPoleU$D$D(this.vars[1], this.vars[2]);
 else this.ds[0][9] = this.p.getPoleU$D$D(this.vars[1], this.vars[2]);
this.ds[0][10] = this.mass;
this.ds[0][11] = this.mag;
return this.ds;
});

Clazz.newMeth(C$, 'calcPE', function () {
this.pe = this.p.getPE$eField4_Charge(this);
return this.pe;
});

Clazz.newMeth(C$, 'calculateState', function () {
this.calcPE();
});

Clazz.newMeth(C$, 'clone', function () {
var c = null;
try {
c = Clazz.clone(this);
c.trail = Clazz.new_((I$[1]||$incl$(1)));
c.font = Clazz.new_((I$[2]||$incl$(2)).c$$S$I$I,["Monospaced", 0, 14]);
c.vars = this.vars.clone();
c.initVars = this.initVars.clone();
c.color = (I$[3]||$incl$(3)).black;
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.CloneNotSupportedException")){
return null;
} else {
throw e;
}
}
return c;
});

Clazz.newMeth(C$, 'incTrail', function () {
if (this.trail == null  || this.trailSize < 1 ) return;
var x = this.p.pixFromX$D(this.vars[1]);
var y = this.p.pixFromY$D(this.vars[2]);
if (this.trail.npoints < this.trailSize) {
this.trail.addPoint$I$I(x, y);
} else {
System.arraycopy(this.trail.xpoints, 1, this.trail.xpoints, 0, this.trailSize - 1);
System.arraycopy(this.trail.ypoints, 1, this.trail.ypoints, 0, this.trailSize - 1);
this.trail.xpoints[this.trailSize - 1] = x;
this.trail.ypoints[this.trailSize - 1] = y;
}});

Clazz.newMeth(C$, 'getTrail', function () {
return this.trail;
});

Clazz.newMeth(C$, 'resetTime', function () {
this.vars[0] = this.initVars[0];
this.vars[1] = this.initVars[1];
this.vars[2] = this.initVars[2];
this.vars[3] = this.initVars[3];
this.vars[4] = this.initVars[4];
this.vars[5] = this.initVars[5];
this.vars[6] = this.initVars[6];
this.clearTrail();
});

Clazz.newMeth(C$, 'getMaxU', function () {
var x0 = this.p.xFromPix$I(0);
var x1 = this.p.xFromPix$I(this.s);
var r2 = (x0 - x1) * (x0 - x1);
if (r2 != 0 ) return this.mag / Math.sqrt(r2);
 else return 0;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (this.hideThing) return;
if (!this.p.showPoles && Clazz.instanceOf(this, "eField4.Pole") ) return;
var ptX = this.p.pixFromX$D(this.vars[1]);
var ptY = this.p.pixFromY$D(this.vars[2]);
if (this.ghost && this.footPrints > 0  && this.trailSize > 1  && this.trail.npoints > 1 ) {
osg.setColor$java_awt_Color((I$[4]||$incl$(4)).veryPaleColor$java_awt_Color(this.color));
for (var i = 0; i < this.trail.npoints; i = i+(this.footPrints)) osg.fillOval$I$I$I$I((this.trail.xpoints[i] - this.s), (this.trail.ypoints[i] - this.s), 2 * this.s, 2 * this.s);

}osg.setColor$java_awt_Color(this.color);
if (this.p.pointChargeMode) osg.fillOval$I$I$I$I((ptX - this.s), (ptY - this.s), 2 * this.s, 2 * this.s);
 else {
osg.setColor$java_awt_Color((I$[4]||$incl$(4)).paleColor$java_awt_Color(this.color));
osg.fillOval$I$I$I$I((ptX - this.s), (ptY - this.s), 2 * this.s, 2 * this.s);
osg.setColor$java_awt_Color(this.color);
if (this.label == null ) {
osg.drawLine$I$I$I$I(ptX, ptY - this.s, ptX, ptY + this.s);
osg.drawLine$I$I$I$I(ptX - this.s, ptY, ptX + this.s, ptY);
}osg.drawOval$I$I$I$I((ptX - this.s), (ptY - this.s), 2 * this.s, 2 * this.s);
}osg.setColor$java_awt_Color(this.lightGreen);
if (this.showVComponents) {
var ptVX = this.p.pixFromX$D(this.vars[1] + this.vars[3]);
var ptVY = this.p.pixFromY$D(this.vars[2] + this.vars[4]);
(I$[4]||$incl$(4)).drawArrow$java_awt_Graphics$I$I$I$I(osg, ptX, ptY, ptVX, ptY);
(I$[4]||$incl$(4)).drawArrow$java_awt_Graphics$I$I$I$I(osg, ptVX, ptY, ptVX, ptVY);
}osg.setColor$java_awt_Color(this.darkGreen);
if (this.showVVector) {
var ptVX = this.p.pixFromX$D(this.vars[1] + this.vars[3]);
var ptVY = this.p.pixFromY$D(this.vars[2] + this.vars[4]);
(I$[4]||$incl$(4)).drawArrow$java_awt_Graphics$I$I$I$I(osg, ptX, ptY, ptVX, ptVY);
}osg.setColor$java_awt_Color(this.color);
this.paintTrail$java_awt_Graphics(osg);
this.paintConstraint$java_awt_Graphics(osg);
if (this.label != null ) {
var oldFont = osg.getFont();
osg.setFont$java_awt_Font(this.font);
osg.setColor$java_awt_Color((I$[3]||$incl$(3)).white);
osg.drawString$S$I$I(this.label, ptX - 4, ptY + 5);
osg.setFont$java_awt_Font(oldFont);
osg.setColor$java_awt_Color(this.color);
}});

Clazz.newMeth(C$, 'getMag', function () {
return this.mag;
});

Clazz.newMeth(C$, 'setMag$D', function (m) {
this.mag = m;
});

Clazz.newMeth(C$, 'isInsidePole$I$I$eField4_OdeCanvas', function (xPix, yPix, p) {
var ptX = p.pixFromX$D(this.vars[1]);
var ptY = p.pixFromY$D(this.vars[2]);
if ((Math.abs(xPix - ptX) < this.s + 1) && (Math.abs(yPix - ptY) < this.s + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.p.pixFromX$D(this.vars[1]);
var ptY = this.p.pixFromY$D(this.vars[2]);
if ((Math.abs(xPix - ptX) < this.s + 1) && (Math.abs(yPix - ptY) < this.s + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'isInsidePole$D$D$eField4_OdeCanvas', function (x, y, p) {
return p$.isInsidePole$I$I$eField4_OdeCanvas.apply(this, [p.pixFromX$D(x), p.pixFromY$D(y), p]);
});

Clazz.newMeth(C$, 'doesOverlap$eField4_Charge', function (c) {
var r2;
if ((c.getMag() < 0  && this.mag < 0  ) || (c.getMag() > 0  && this.mag > 0  ) ) r2 = (this.p.xFromPix$I(0) - this.p.xFromPix$I(this.s * 2 + 3)) * (this.p.xFromPix$I(0) - this.p.xFromPix$I(this.s * 2 + 3));
 else r2 = (this.p.xFromPix$I(0) - this.p.xFromPix$I(this.s + 2)) * (this.p.xFromPix$I(0) - this.p.xFromPix$I(this.s + 2));
var d2 = (this.getX() - c.getX()) * (this.getX() - c.getX()) + (this.getY() - c.getY()) * (this.getY() - c.getY());
if (d2 > r2 ) return false;
 else return true;
});

Clazz.newMeth(C$, 'getRadius', function () {
var r = (this.p.xFromPix$I(0) - this.p.xFromPix$I(this.s + 1)) * (this.p.xFromPix$I(0) - this.p.xFromPix$I(this.s + 1));
r = Math.sqrt(r);
return r;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:29
