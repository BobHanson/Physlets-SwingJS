(function(){var P$=Clazz.newPackage("eField4"),I$=[[0,'edu.davidson.numerics.SRK45']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "TestCharge", null, 'eField4.Charge', 'edu.davidson.numerics.SDifferentiable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.odeSolver=null;
this.dydx=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.odeSolver=Clazz.new_($I$(1));
this.dydx=Clazz.array(Double.TYPE, [5]);
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$D$D', function (p, x, y, vx, vy) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D$D.apply(this, [p, x, y, vx, vy, 1.0]);
C$.$init$.apply(this);
this.odeSolver.setDifferentials$edu_davidson_numerics_SDifferentiable(this);
this.sticky=false;
this.dynamic=true;
this.noDrag=false;
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$D$D$D', function (p, x, y, vx, vy, m) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D$D.apply(this, [p, x, y, vx, vy, m]);
C$.$init$.apply(this);
this.odeSolver.setDifferentials$edu_davidson_numerics_SDifferentiable(this);
this.sticky=false;
this.dynamic=true;
this.noDrag=false;
}, 1);

Clazz.newMeth(C$, 'getNumEqu$', function () {
return 5;
});

Clazz.newMeth(C$, 'constrainedRate$DA', function (x) {
this.dydx[0]=1;
var speed=Math.sqrt(x[3] * x[3] + x[4] * x[4]);
var m=this.getConstraintSlope$D$D(x[1], Math.abs(x[1]) * 0.01 + 1.0E-6);
var v=-1 / Math.sqrt(1 + m * m);
var u=-m * v;
var m2=this.getConstraintSecondDeriv$D$D(x[1], Math.abs(x[1]) * 0.01 + 1.0E-6);
var kappa=Math.abs(m2) / Math.pow(1 + m * m, 1.5);
this.dydx[1]=x[3];
this.dydx[2]=x[4];
var ax=this.mag * (-this.p.dudx$D$D(x[1], x[2]) + this.p.getPoleFx$D$D$eField4_Charge(x[1], x[2], null) + this.p.bz * x[4] );
var ay=this.mag * (-this.p.dudy$D$D(x[1], x[2]) + this.p.getPoleFy$D$D$eField4_Charge(x[1], x[2], null) - this.p.bz * x[3]);
var acc=(-ax * v + ay * u);
var acc2=-speed * speed * kappa ;
this.dydx[3]=(acc2 * u - acc * v - this.damping * x[3]) / this.mass;
this.dydx[4]=(acc2 * v + acc * u - this.damping * x[4]) / this.mass;
this.vars[5]=this.dydx[3];
this.vars[6]=this.dydx[4];
return this.dydx;
});

Clazz.newMeth(C$, 'constrainedRRate$DA', function (x) {
this.dydx[0]=1;
this.enforceConstraintOnR$();
var speed=Math.sqrt(x[3] * x[3] + x[4] * x[4]);
var u=(this.vars[1] - this.constantRx) / this.constantR;
var v=(this.vars[2] - this.constantRy) / this.constantR;
this.dydx[1]=x[3];
this.dydx[2]=x[4];
var ax=this.mag * (-this.p.dudx$D$D(x[1], x[2]) + this.p.getPoleFx$D$D$eField4_Charge(x[1], x[2], null) + this.p.bz * x[4] );
var ay=this.mag * (-this.p.dudy$D$D(x[1], x[2]) + this.p.getPoleFy$D$D$eField4_Charge(x[1], x[2], null) - this.p.bz * x[3]);
var acc=(-ax * v + ay * u);
var acc2=-speed * speed / this.constantR;
this.dydx[3]=(acc2 * u - acc * v - this.damping * x[3]) / this.mass;
this.dydx[4]=(acc2 * v + acc * u - this.damping * x[4]) / this.mass;
this.vars[5]=this.dydx[3];
this.vars[6]=this.dydx[4];
if (this.p.dragShape === this ) {
this.dydx[3]=0;
this.dydx[4]=0;
}return this.dydx;
});

Clazz.newMeth(C$, 'constrainedXRate$DA', function (x) {
x[1]=this.constantX;
this.dydx[0]=1;
this.dydx[1]=0;
this.dydx[2]=x[4];
this.dydx[3]=0;
this.dydx[4]=(this.mag * (-this.p.dudy$D$D(x[1], x[2]) + this.p.getPoleFy$D$D$eField4_Charge(x[1], x[2], null) - this.p.bz * x[3]) - this.damping * x[4]) / this.mass;
this.vars[5]=0;
this.vars[6]=this.dydx[4];
return this.dydx;
});

Clazz.newMeth(C$, 'constrainedYRate$DA', function (x) {
x[2]=this.constantY;
this.dydx[0]=1;
this.dydx[1]=x[3];
this.dydx[2]=0;
this.dydx[3]=(this.mag * (-this.p.dudx$D$D(x[1], x[2]) + this.p.getPoleFx$D$D$eField4_Charge(x[1], x[2], null) + this.p.bz * x[4] ) - this.damping * x[3]) / this.mass;
this.dydx[4]=0;
this.vars[5]=this.dydx[3];
this.vars[6]=0;
return this.dydx;
});

Clazz.newMeth(C$, 'rate$DA', function (x) {
if (this.p.dragShape === this ) {
x[3]=0;
x[4]=0;
}if (this.constraint != null ) return this.constrainedRate$DA(x);
 else if (this.constrainX) return this.constrainedXRate$DA(x);
 else if (this.constrainY) return this.constrainedYRate$DA(x);
 else if (this.constrainR) return this.constrainedRRate$DA(x);
this.dydx[0]=1;
this.dydx[1]=x[3];
this.dydx[2]=x[4];
this.dydx[3]=(this.mag * (-this.p.dudx$D$D(x[1], x[2]) + this.p.getPoleFx$D$D$eField4_Charge(x[1], x[2], null) + this.p.bz * x[4] ) - this.damping * x[3]) / this.mass;
this.dydx[4]=(this.mag * (-this.p.dudy$D$D(x[1], x[2]) + this.p.getPoleFy$D$D$eField4_Charge(x[1], x[2], null) - this.p.bz * x[3]) - this.damping * x[4]) / this.mass;
this.vars[5]=this.dydx[3];
this.vars[6]=this.dydx[4];
if (this.p.dragShape === this ) {
this.dydx[3]=0;
this.dydx[4]=0;
}return this.dydx;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:52 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
