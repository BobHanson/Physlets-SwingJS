(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Constraint", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.left = 0;
this.right = 0;
this.top = 0;
this.bottom = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$D$D', function (owner, sc, l, r, b, t) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, 0, 0]);
C$.$init$.apply(this);
this.applet = owner;
this.left = l;
this.right = r;
this.top = t;
this.bottom = b;
this.visible = true;
this.color = (I$[1]||$incl$(1)).black;
}, 1);

Clazz.newMeth(C$, 'setProperties$I$D$D', function (sid, a, b) {
var w2 = (this.right - this.left) / 2.0;
var h2 = (this.top - this.bottom) / 2.0;
if (sid == 0 || sid == 1 ) {
this.left = a - w2;
this.right = a + w2;
this.top = b + h2;
this.bottom = b - h2;
} else if (sid == 6) {
this.left = a - w2;
this.right = a + w2;
} else if (sid == 7) {
this.top = b + h2;
this.bottom = b - h2;
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.left);
var ptY = this.canvas.pixFromY$D(this.top);
this.w = this.canvas.pixFromX$D(this.right) - ptX;
this.h = this.canvas.pixFromY$D(this.bottom) - ptY;
osg.setColor$java_awt_Color(this.color);
if (this.w > 0 && this.h > 0 ) osg.drawRect$I$I$I$I(ptX, ptY, this.w, this.h);
 else if (this.w > 0 && this.h == 0 ) osg.drawLine$I$I$I$I(ptX, ptY, ptX + this.w, ptY);
 else if (this.w == 0 && this.h > 0 ) osg.drawLine$I$I$I$I(ptX, ptY, ptX, ptY + this.h);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
this.paint$java_awt_Graphics(osg);
});

Clazz.newMeth(C$, 'enforceConstraint$edu_davidson_display_Thing', function (t) {
var x = t.x;
var y = t.y;
if (this.right > this.left ) {
x = Math.max(this.left, x);
x = Math.min(this.right, x);
if (this.top == this.bottom ) y = this.top;
}if (this.top > this.bottom ) {
y = Math.max(this.bottom, y);
y = Math.min(this.top, y);
if (this.left == this.right ) x = this.left;
}t.x = x;
t.y = y;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
return false;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-08 01:51:41
