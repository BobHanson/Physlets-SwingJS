(function(){var P$=Clazz.newPackage("engine"),I$=[['edu.davidson.tools.SApplet',['engine.Engine','.DataSource'],'java.awt.Point','engine.XcWorld','java.awt.Color','java.awt.Font']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Engine", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SStepable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.mode = 0;
this.gamma = 0;
this.gas = null;
this.pressure = 0;
this.temperature = 0;
this.volume = 0;
this.label_burning = null;
this.label_expelling = null;
this.label_sucking = null;
this.label_compressing = null;
this.radius = 0;
this.CylPtBottom = 0;
this.CylPtTop = 0;
this.Xcyl = 0;
this.Ycircle = 0;
this.Xcircle = 0;
this.Ypiston = 0;
this.MiddlePositonPiston = 0;
this.Xpiston = 0;
this.PistonHeight = 0;
this.ValveHeight = 0;
this.Xvalve = 0;
this.ValveLength = 0;
this.ValveJoint1 = 0;
this.ValveJoint2 = 0;
this.CirPart = 0;
this.Circle = 0;
this.PistonJoint = 0;
this.Piston = 0;
this.ValveBottom1 = 0;
this.ValveBottom2 = 0;
this.AirColor = 0;
this.pole = 0;
this.StartingAngle = 0;
this.currentangle = 0;
this.pi = 0;
this.conversionRadians = 0;
this.RadianAngle = 0;
this.posMouse = null;
this.btnMouse = 0;
this.currElement = 0;
this.currElementType = 0;
this.aWorld_2XcWorld = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.mode = 0;
this.gamma = 1.4;
this.gas = Clazz.new_((I$[2]||$incl$(2)).c$$edu_davidson_tools_SApplet, [this, null, this]);
this.pressure = 1;
this.temperature = 1;
this.volume = 1;
this.label_burning = "Burning Gas Mixture";
this.label_expelling = "Expelling smoke";
this.label_sucking = "Sucking in Gas Mixture";
this.label_compressing = "Compressing Gas";
this.Xpiston = 0.0;
this.ValveJoint1 = 11;
this.ValveJoint2 = 12;
this.CirPart = 4;
this.Circle = 5;
this.PistonJoint = 3;
this.Piston = 2;
this.ValveBottom1 = 6;
this.ValveBottom2 = 7;
this.AirColor = 1;
this.pole = 4;
this.StartingAngle = 89;
this.pi = 3.141592653589793;
this.posMouse = Clazz.new_((I$[3]||$incl$(3)).c$$I$I,[0, 0]);
this.btnMouse = 0;
this.currElement = -1;
this.currElementType = 0;
}, 1);

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
this.addNotify();
this.openFrames();
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
this.clock.setDt$D(0.05);
this.clock.setFPS$D(20);
});

Clazz.newMeth(C$, 'setResources', function () {
this.label_burning = this.localProperties.getProperty$S$S("label.burning", this.label_burning);
this.label_expelling = this.localProperties.getProperty$S$S("label.expelling", this.label_expelling);
this.label_sucking = this.localProperties.getProperty$S$S("label.sucking", this.label_sucking);
this.label_compressing = this.localProperties.getProperty$S$S("label.compressing", this.label_compressing);
});

Clazz.newMeth(C$, 'openFrames', function () {
this.aWorld_2XcWorld = Clazz.new_((I$[4]||$incl$(4)));
this.add$java_awt_Component(this.aWorld_2XcWorld);
this.aWorld_2XcWorld.reshape$I$I$I$I(0, 0, 400, 450);
this.aWorld_2XcWorld.setForeground$java_awt_Color((I$[5]||$incl$(5)).black);
this.aWorld_2XcWorld.setBackground$java_awt_Color((I$[5]||$incl$(5)).black);
this.aWorld_2XcWorld.setFont$java_awt_Font(Clazz.new_((I$[6]||$incl$(6)).c$$S$I$I,["Helvetica", 0, 12]));
this.aWorld_2XcWorld.nOfPoints = 0;
this.aWorld_2XcWorld.nOfParticles = 0;
this.aWorld_2XcWorld.nOfSegments = 0;
this.aWorld_2XcWorld.doubleBuffering = false;
this.XdevProgram();
});

Clazz.newMeth(C$, 'XdevProgram', function () {
var i;
var w;
var h;
var nOfPar = 16;
var nOfSeg = 14;
var Space = 40.0;
var CylWidth = 100;
var CylHeight;
var CompressionSpace = 20.0;
var HoseThickness;
var HoseLength;
var HoseStart;
var PistonWidth;
var Diameter = 120;
this.radius = Diameter / 2.0;
this.conversionRadians = this.pi / 180;
h = this.aWorld_2XcWorld.getSize().height;
w = this.aWorld_2XcWorld.getSize().width;
PistonWidth = CylWidth - 5;
this.PistonHeight = ((CylWidth / 2.0 - 20)|0);
CylHeight = Diameter + this.PistonHeight + CompressionSpace ;
this.CylPtBottom = this.radius + Space;
this.CylPtTop = this.CylPtBottom + CylHeight;
this.Xcyl = CylWidth / 2.0;
HoseThickness = CylWidth / 4.0;
HoseLength = this.Xcyl;
this.ValveLength = (HoseThickness|0);
this.ValveHeight = HoseThickness * 2.0;
this.Xvalve = this.Xcyl - (this.ValveLength/2|0) - 1;
HoseStart = this.Xcyl - this.ValveLength * 0.75;
this.aWorld_2XcWorld.nOfParticles = nOfPar;
this.aWorld_2XcWorld.nOfSegments = nOfSeg;
this.aWorld_2XcWorld.setBackground$java_awt_Color((I$[5]||$incl$(5)).black);
this.aWorld_2XcWorld.updateImmediate = true;
this.aWorld_2XcWorld.doubleBuffering = true;
this.aWorld_2XcWorld.xorMode = true;
this.aWorld_2XcWorld.xmin = -w / 2.0;
this.aWorld_2XcWorld.xmax = w / 2.0;
this.aWorld_2XcWorld.ymin = -this.radius - 50.0;
this.aWorld_2XcWorld.ymax = h - this.radius - 50.0 ;
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(1, -this.Xcyl, this.CylPtBottom, -this.Xcyl, this.CylPtTop);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(2, -this.Xcyl + this.ValveLength, this.CylPtTop, this.Xcyl - this.ValveLength, this.CylPtTop);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(3, this.Xcyl, this.CylPtBottom, this.Xcyl, this.CylPtTop);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(5, -this.Xcyl + this.ValveLength, this.CylPtTop, -HoseStart, this.CylPtTop + HoseThickness);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(6, -HoseStart, this.CylPtTop + HoseThickness, -this.Xcyl - HoseLength, this.CylPtTop + HoseThickness);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(7, -this.Xcyl, this.CylPtTop, -this.Xcyl - HoseLength, this.CylPtTop);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(8, this.Xcyl - this.ValveLength, this.CylPtTop, HoseStart, this.CylPtTop + HoseThickness);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(9, HoseStart, this.CylPtTop + HoseThickness, this.Xcyl + HoseLength, this.CylPtTop + HoseThickness);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(10, this.Xcyl, this.CylPtTop, this.Xcyl + HoseLength, this.CylPtTop);
this.currentangle = this.StartingAngle;
this.conversionRadians = this.pi / 180.0;
this.RadianAngle = this.currentangle * this.conversionRadians;
this.Ycircle = this.radius * Math.sin(this.RadianAngle);
this.Xcircle = this.radius * Math.cos(this.RadianAngle);
this.MiddlePositonPiston = this.CylPtBottom + this.radius + this.PistonHeight / 2.0 ;
this.Ypiston = this.MiddlePositonPiston + this.Ycircle;
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.pole, this.Xpiston, this.Ypiston, this.Xcircle, this.Ycircle);
i = 1;
while (i <= 10){
this.aWorld_2XcWorld.XcWorldChangeSegmentColor$I$S(i, "cyan");
i = i + 1;
}
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(this.ValveBottom1, 2);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.ValveBottom1, -this.Xvalve, this.CylPtTop);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(this.ValveBottom1, this.ValveLength, 2);
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.ValveBottom1, "red");
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.ValveJoint1, -this.Xvalve, this.CylPtTop, -this.Xvalve, this.CylPtTop + this.ValveHeight);
this.aWorld_2XcWorld.XcWorldChangeSegmentColor$I$S(this.ValveJoint1, "red");
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(this.ValveBottom2, 2);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.ValveBottom2, this.Xvalve, this.CylPtTop);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(this.ValveBottom2, this.ValveLength, 2);
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.ValveBottom2, "red");
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.ValveJoint2, this.Xvalve, this.CylPtTop, this.Xvalve, this.CylPtTop + this.ValveHeight);
this.aWorld_2XcWorld.XcWorldChangeSegmentColor$I$S(this.ValveJoint2, "red");
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(this.Piston, 2);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.Piston, this.Xpiston, this.Ypiston);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(this.Piston, PistonWidth, this.PistonHeight);
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.Piston, "red");
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.PistonJoint, this.Xpiston, this.Ypiston);
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.PistonJoint, "black");
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(this.Circle, 1);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.Circle, 0.0, 0.0);
this.aWorld_2XcWorld.XcWorldChangeParticleSize$I$I(this.Circle, Diameter);
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.Circle, "red");
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.CirPart, this.Xcircle, this.Ycircle);
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.CirPart, "red");
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(16, 0.0, 0.0);
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(16, "red");
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(this.AirColor, 12);
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(8, 14);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(8, -5.0, this.CylPtTop - 6);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(8, 10, 2);
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(9, 14);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(9, -5.0, this.CylPtTop - 3);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(9, 10, 2);
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(10, 11);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(10, -10.0, this.CylPtTop);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(10, 20, 2);
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(11, 11);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(11, -10.0, this.CylPtTop + 3);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(11, 20, 2);
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(12, 11);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(12, -10.0, this.CylPtTop + 6);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(12, 20, 2);
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(13, 12);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(13, -5.0, this.CylPtTop + 6);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(13, 10, 8);
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(14, 12);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(14, -8.0, this.CylPtTop + 14);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(14, 16, 10);
this.aWorld_2XcWorld.XcWorldChangeParticleMode$I$I(15, 12);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(15, -8.0, this.CylPtTop + 24);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(15, 20, 5);
i = 8;
while (i <= 15){
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(i, "white");
i = i + 1;
}
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(13, 12.0, this.CylPtTop + 26.5, 20.0, this.CylPtTop + 26.5);
this.aWorld_2XcWorld.XcWorldChangeSegmentColor$I$S(13, "gray");
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(14, 20.0, this.CylPtTop + 26.5, 20.0, this.CylPtTop + 100);
this.aWorld_2XcWorld.XcWorldChangeSegmentColor$I$S(14, "gray");
this.aWorld_2XcWorld.XcWorldUpdate();
});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
var i = 8;
var sparkangle = 90;
var sparkduration = 10;
var OutLetOpen = 270;
var OutLetOpen_Duration = 180;
var InLetOpen = 450;
var InLetOpen_Duration = 180;
var cycle2 = 720;
var stepAngle = 1;
var YBottomValve = this.CylPtTop;
var YTopValve;
var ValveOpenSize = 10;
YTopValve = this.CylPtTop + this.ValveHeight;
this.currentangle = (this.currentangle % cycle2);
this.currentangle = this.currentangle + stepAngle;
this.RadianAngle = this.currentangle * this.conversionRadians;
this.Ycircle = this.radius * Math.sin(this.RadianAngle);
this.Xcircle = this.radius * Math.cos(this.RadianAngle);
this.Ypiston = this.MiddlePositonPiston + this.Ycircle;
this.button_5_helpCallback();
this.button_3_helpCallback();
if (this.currentangle == sparkangle) {
this.mode = 0;
this.play$java_net_URL$S(this.getCodeBase(), "beep.au");
while (i <= 15){
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(i, "yellow");
i = i + 1;
}
i = 8;
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.AirColor, "pink\'");
this.aWorld_2XcWorld.msgXpos = 40;
this.aWorld_2XcWorld.msgYpos = 300;
this.aWorld_2XcWorld.msgColor = (I$[5]||$incl$(5)).pink;
this.aWorld_2XcWorld.msgString = this.label_burning;
}if (this.currentangle == (sparkangle + sparkduration)) {
this.mode = 0;
while (i <= 15){
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(i, "white");
i = i + 1;
}
i = 7;
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.AirColor, "pink");
this.aWorld_2XcWorld.msgXpos = 40;
this.aWorld_2XcWorld.msgYpos = 300;
this.aWorld_2XcWorld.msgColor = (I$[5]||$incl$(5)).orange;
this.aWorld_2XcWorld.msgString = this.label_burning;
}if (this.currentangle == OutLetOpen) {
this.mode = 1;
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.AirColor, "gray");
this.aWorld_2XcWorld.msgXpos = 240;
this.aWorld_2XcWorld.msgYpos = 60;
this.aWorld_2XcWorld.msgColor = (I$[5]||$incl$(5)).lightGray;
this.aWorld_2XcWorld.msgString = this.label_expelling;
}if ((this.currentangle >= OutLetOpen) && (this.currentangle < (OutLetOpen + OutLetOpen_Duration)) ) {
this.mode = 1;
YTopValve = YTopValve - ValveOpenSize * Math.cos(this.RadianAngle);
YBottomValve = YBottomValve - ValveOpenSize * Math.cos(this.RadianAngle);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.ValveBottom2, this.Xvalve, YBottomValve);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.ValveJoint2, this.Xvalve, YBottomValve, this.Xvalve, YTopValve);
}if (this.currentangle == (OutLetOpen + OutLetOpen_Duration)) {
this.mode = 1;
YTopValve = this.CylPtTop + this.ValveHeight;
YBottomValve = this.CylPtTop;
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.ValveBottom2, this.Xvalve, YBottomValve);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.ValveJoint2, this.Xvalve, YBottomValve, this.Xvalve, YTopValve);
}if (this.currentangle == InLetOpen) {
this.mode = 2;
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.AirColor, "yellow");
this.aWorld_2XcWorld.msgXpos = 50;
this.aWorld_2XcWorld.msgYpos = 60;
this.aWorld_2XcWorld.msgColor = (I$[5]||$incl$(5)).yellow;
this.aWorld_2XcWorld.msgString = this.label_sucking;
this.pressure = 1.0;
}if ((this.currentangle >= InLetOpen) && (this.currentangle < InLetOpen + InLetOpen_Duration) ) {
this.mode = 2;
YTopValve = YTopValve + ValveOpenSize * Math.cos(this.RadianAngle);
YBottomValve = YBottomValve + ValveOpenSize * Math.cos(this.RadianAngle);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.ValveBottom1, -this.Xvalve, YBottomValve);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.ValveJoint1, -this.Xvalve, YBottomValve, -this.Xvalve, YTopValve);
}if (this.currentangle == (InLetOpen + InLetOpen_Duration)) {
this.mode = 3;
YTopValve = this.CylPtTop + this.ValveHeight;
YBottomValve = this.CylPtTop;
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.ValveBottom1, -this.Xvalve, YBottomValve);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.ValveJoint1, -this.Xvalve, YBottomValve, -this.Xvalve, YTopValve);
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.AirColor, "orange");
this.aWorld_2XcWorld.msgXpos = 40;
this.aWorld_2XcWorld.msgYpos = 300;
this.aWorld_2XcWorld.msgColor = (I$[5]||$incl$(5)).orange;
this.aWorld_2XcWorld.msgString = this.label_compressing;
}this.aWorld_2XcWorld.XcWorldUpdate();
this.volume = (this.CylPtTop - this.Ypiston) / (this.CylPtTop - this.MiddlePositonPiston + this.radius);
switch (this.mode) {
case 0:
{
this.pressure = 3.0 / Math.pow(this.volume, this.gamma);
this.temperature = this.pressure * this.volume;
break;
}case 1:
{
this.pressure = 1.1;
break;
}case 2:
{
this.pressure = 1;
this.temperature = 1;
break;
}case 3:
{
this.pressure = 1.0 / Math.pow(this.volume, this.gamma);
this.temperature = this.pressure * this.volume;
break;
}}
this.updateDataConnections();
});

Clazz.newMeth(C$, 'button_3_helpCallback', function () {
var ColorHeight;
var ColorWidth;
var YairColor;
var XairColor = -this.Xcyl + 1.5;
YairColor = this.Ypiston + (this.PistonHeight/2|0);
ColorWidth = ((2 * this.Xcyl - 2)|0);
ColorHeight = ((this.CylPtTop - this.Ypiston - (this.PistonHeight/2|0)  - 2)|0);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.AirColor, XairColor, YairColor);
this.aWorld_2XcWorld.XcWorldChangeParticleSizes$I$I$I(this.AirColor, ColorWidth, ColorHeight);
});

Clazz.newMeth(C$, 'button_5_activateCallback', function () {
var i = 8;
this.currentangle = this.StartingAngle;
this.RadianAngle = this.currentangle * this.conversionRadians;
this.Ycircle = this.radius * Math.sin(this.RadianAngle);
this.Xcircle = this.radius * Math.cos(this.RadianAngle);
this.Ypiston = this.MiddlePositonPiston + this.Ycircle;
this.button_5_helpCallback();
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.ValveBottom1, -this.Xvalve, this.CylPtTop);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.ValveJoint1, -this.Xvalve, this.CylPtTop, -this.Xvalve, this.CylPtTop + this.ValveHeight);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.ValveBottom2, this.Xvalve, this.CylPtTop);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.ValveJoint2, this.Xvalve, this.CylPtTop, this.Xvalve, this.CylPtTop + this.ValveHeight);
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(this.AirColor, "black");
if (this.currentangle <= 90) {
while (i <= 15){
this.aWorld_2XcWorld.XcWorldChangeParticleColor$I$S(i, "white");
i = i + 1;
}
}});

Clazz.newMeth(C$, 'button_5_helpCallback', function () {
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.Piston, this.Xpiston, this.Ypiston);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.PistonJoint, this.Xpiston, this.Ypiston);
this.aWorld_2XcWorld.XcWorldMoveParticle$I$D$D(this.CirPart, this.Xcircle, this.Ycircle);
this.aWorld_2XcWorld.XcWorldMoveSegment$I$D$D$D$D(this.pole, this.Xpiston, this.Ypiston, this.Xcircle, this.Ycircle);
});

Clazz.newMeth(C$, 'getGasID', function () {
return this.gas.getID();
});

Clazz.newMeth(C$, 'reset', function () {
this.pause();
C$.superclazz.prototype.reset.apply(this, []);
this.button_5_activateCallback();
this.step$D$D(this.clock.getDt(), 0);
});

Clazz.newMeth(C$, 'stoppingClock', function () {
this.aWorld_2XcWorld.msgXpos = 40;
this.aWorld_2XcWorld.msgYpos = 300;
this.aWorld_2XcWorld.msgColor = (I$[5]||$incl$(5)).orange;
this.aWorld_2XcWorld.msgString = this.oneShotMsg;
this.aWorld_2XcWorld.XcWorldUpdate();
});
;
(function(){var C$=Clazz.newClass(P$.Engine, "DataSource", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.applet = null;
this.varStrings = null;
this.ds = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["time", "p", "v", "t", "theta"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet', function (a) {
C$.$init$.apply(this);
this.applet = a;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.this$0.clock.getTime();
this.ds[0][1] = this.this$0.pressure;
this.ds[0][2] = this.this$0.volume;
this.ds[0][3] = this.this$0.temperature;
this.ds[0][4] = this.this$0.currentangle;
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (a) {
this.applet = a;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.applet;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:09
