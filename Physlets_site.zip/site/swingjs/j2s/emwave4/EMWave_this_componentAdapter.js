(function(){var P$=Clazz.newPackage("emwave4"),I$=[];
var C$=Clazz.newClass(P$, "EMWave_this_componentAdapter", null, 'java.awt.event.ComponentAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$emwave4_EMWave', function (adaptee) {
Clazz.super_(C$, this,1);
this.adaptee = adaptee;
}, 1);

Clazz.newMeth(C$, 'componentResized$java_awt_event_ComponentEvent', function (e) {
this.adaptee.this_componentResized$java_awt_event_ComponentEvent(e);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:20:49
