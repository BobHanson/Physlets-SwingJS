(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['edu.davidson.graph.RotateTextFilter','java.awt.image.FilteredImageSource']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "RTextLine", null, 'edu.davidson.graph.TextLine');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.angle = 0;
this.cos = 0;
this.sin = 0;
this.component = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.angle = 0;
this.cos = 1.0;
this.sin = 0.0;
this.component = null;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (s) {
C$.superclazz.c$$S.apply(this, [s]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component', function (c) {
Clazz.super_(C$, this,1);
this.setDrawingComponent$java_awt_Component(c);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_Font', function (s, f) {
C$.superclazz.c$$S$java_awt_Font.apply(this, [s, f]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_Font$java_awt_Color$I', function (s, f, c, j) {
C$.superclazz.c$$S$java_awt_Font$java_awt_Color$I.apply(this, [s, f, c, j]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_Color', function (s, c) {
C$.superclazz.c$$S$java_awt_Color.apply(this, [s, c]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Font$java_awt_Color$I$I', function (f, c, j, a) {
C$.superclazz.c$$java_awt_Font$java_awt_Color$I.apply(this, [f, c, j]);
C$.$init$.apply(this);
this.setRotation$I(a);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Font$java_awt_Color$I', function (f, c, j) {
C$.superclazz.c$$java_awt_Font$java_awt_Color$I.apply(this, [f, c, j]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'copyState$edu_davidson_graph_RTextLine', function (t) {
if (t == null ) return;
this.font = t.getFont();
this.color = t.getColor();
this.justification = t.getJustification();
this.setRotation$I$java_awt_Component(t.getRotation(), t.getComponent());
if (this.font == null ) return;
this.fontname = this.font.getName();
this.fontstyle = this.font.getStyle();
this.fontsize = this.font.getSize();
this.parse = true;
});

Clazz.newMeth(C$, 'setRotation$I', function (angle) {
this.angle = (((angle % 360)/90|0)) * 90;
this.cos = Math.cos(angle * 3.141592653589793 / 180.0);
this.sin = Math.sin(angle * 3.141592653589793 / 180.0);
});

Clazz.newMeth(C$, 'setDrawingComponent$java_awt_Component', function (c) {
this.component = c;
});

Clazz.newMeth(C$, 'setRotation$I$java_awt_Component', function (angle, c) {
this.setRotation$I(angle);
this.setDrawingComponent$java_awt_Component(c);
});

Clazz.newMeth(C$, 'getRotation', function () {
return this.angle;
});

Clazz.newMeth(C$, 'getComponent', function () {
return this.component;
});

Clazz.newMeth(C$, 'getRWidth$java_awt_Graphics', function (g) {
this.parseText$java_awt_Graphics(g);
return ((Math.abs(this.cos * this.width + this.sin * this.height) + 0.5)|0);
});

Clazz.newMeth(C$, 'getRHeight$java_awt_Graphics', function (g) {
this.parseText$java_awt_Graphics(g);
return ((Math.abs(-this.sin * this.width + this.cos * this.height) + 0.5)|0);
});

Clazz.newMeth(C$, 'getLeftEdge$java_awt_Graphics', function (g) {
return this.getLeftEdge$java_awt_Graphics$I(g, this.justification);
});

Clazz.newMeth(C$, 'getRightEdge$java_awt_Graphics', function (g) {
return this.getRightEdge$java_awt_Graphics$I(g, this.justification);
});

Clazz.newMeth(C$, 'getTopEdge$java_awt_Graphics', function (g) {
return this.getTopEdge$java_awt_Graphics$I(g, this.justification);
});

Clazz.newMeth(C$, 'getBottomEdge$java_awt_Graphics', function (g) {
return this.getBottomEdge$java_awt_Graphics$I(g, this.justification);
});

Clazz.newMeth(C$, 'getLeftEdge$java_awt_Graphics$I', function (g, j) {
this.parseText$java_awt_Graphics(g);
switch (this.angle) {
case 90:
case -270:
return -this.ascent;
case 180:
case -180:
if (j == 0) return (-this.width/2|0);
 else if (j == 2) return 0;
 else return -this.width;
case 270:
case -90:
return -this.descent - this.leading;
default:
if (j == 0) return (-this.width/2|0);
 else if (j == 2) return -this.width;
 else return 0;
}
});

Clazz.newMeth(C$, 'getRightEdge$java_awt_Graphics$I', function (g, j) {
this.parseText$java_awt_Graphics(g);
switch (this.angle) {
case 90:
case -270:
return this.descent + this.leading;
case 180:
case -180:
if (j == 0) return (this.width/2|0);
 else if (j == 2) return this.width;
 else return 0;
case 270:
case -90:
return this.ascent;
default:
if (j == 0) return (this.width/2|0);
 else if (j == 2) return 0;
 else return this.width;
}
});

Clazz.newMeth(C$, 'getTopEdge$java_awt_Graphics$I', function (g, j) {
this.parseText$java_awt_Graphics(g);
switch (this.angle) {
case 90:
case -270:
if (j == 0) return (this.width/2|0);
 else if (j == 2) return 0;
 else return this.width;
case 180:
case -180:
return this.descent + this.leading;
case 270:
case -90:
if (j == 0) return (this.width/2|0);
 else if (j == 2) return this.width;
 else return 0;
default:
return this.ascent;
}
});

Clazz.newMeth(C$, 'getBottomEdge$java_awt_Graphics$I', function (g, j) {
this.parseText$java_awt_Graphics(g);
switch (this.angle) {
case 90:
case -270:
if (j == 0) return (-this.width/2|0);
 else if (j == 2) return -this.width;
 else return 0;
case 180:
case -180:
return -this.ascent;
case 270:
case -90:
if (j == 0) return (-this.width/2|0);
 else if (j == 2) return 0;
 else return -this.width;
default:
return -this.descent - this.leading;
}
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics$I$I', function (g, x, y) {
if (g == null ) return;
if (this.component == null ) this.angle = 0;
if (this.angle == 0) C$.superclazz.prototype.draw$java_awt_Graphics$I$I.apply(this, [g, x, y]);
 else this.draw$java_awt_Component$java_awt_Graphics$I$I(this.component, g, x, y);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics$I$I$I', function (g, x, y, j) {
this.justification = j;
if (g == null ) return;
if (this.component == null ) this.angle = 0;
if (this.angle == 0) C$.superclazz.prototype.draw$java_awt_Graphics$I$I.apply(this, [g, x, y]);
 else this.draw$java_awt_Component$java_awt_Graphics$I$I(this.component, g, x, y);
});

Clazz.newMeth(C$, 'draw$java_awt_Component$java_awt_Graphics$I$I', function (comp, g, x, y) {
var ts;
var xoffset = 0;
var yoffset = 0;
var offsI = null;
var offsG = null;
var rotatedImage = null;
var maxHeight = 0;
if (this.text == null  || comp == null  ) return;
this.parseText$java_awt_Graphics(g);
maxHeight = this.maxAscent + this.maxDescent;
switch (this.angle) {
case 90:
case -270:
xoffset = -this.maxAscent;
if (this.justification == 0) yoffset = (-this.width/2|0);
 else if (this.justification == 2) yoffset = 0;
 else yoffset = -this.width;
break;
case 180:
case -180:
yoffset = -this.maxDescent;
if (this.justification == 0) xoffset = (-this.width/2|0);
 else if (this.justification == 2) xoffset = 0;
 else xoffset = -this.width;
break;
case 270:
case -90:
xoffset = -this.maxDescent;
if (this.justification == 0) yoffset = (-this.width/2|0);
 else if (this.justification == 2) yoffset = -this.width;
 else yoffset = 0;
break;
default:
xoffset = 0;
yoffset = 0;
break;
}
offsI = comp.createImage$I$I(this.width, maxHeight);
if (offsI == null ) return;
offsG = offsI.getGraphics();
if (this.background != null ) {
offsG.setColor$java_awt_Color(this.background);
} else {
offsG.setColor$java_awt_Color(comp.getBackground());
}offsG.fillRect$I$I$I$I(0, 0, this.width, maxHeight);
offsG.setFont$java_awt_Font(g.getFont());
offsG.setColor$java_awt_Color(g.getColor());
if (this.font != null ) offsG.setFont$java_awt_Font(this.font);
if (this.color != null ) offsG.setColor$java_awt_Color(this.color);
for (var i = 0; i < this.list.size(); i++) {
ts = ((this.list.elementAt$I(i)));
if (ts.f != null ) offsG.setFont$java_awt_Font(ts.f);
if (ts.s != null ) offsG.drawString$S$I$I(ts.toString(), ts.x, ts.y + this.maxAscent);
}
offsG.dispose();
var f = Clazz.new_((I$[1]||$incl$(1)).c$$I,[this.angle]);
var producer = Clazz.new_((I$[2]||$incl$(2)).c$$java_awt_image_ImageProducer$java_awt_image_ImageFilter,[offsI.getSource(), f]);
rotatedImage = comp.createImage$java_awt_image_ImageProducer(producer);
if (rotatedImage == null ) return;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(rotatedImage, x + xoffset, y + yoffset, null);
});
})();
//Created 2018-02-25 19:20:26
