(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newInterface(P$, "TimerClient");
})();
//Created 2018-02-22 01:07:18
