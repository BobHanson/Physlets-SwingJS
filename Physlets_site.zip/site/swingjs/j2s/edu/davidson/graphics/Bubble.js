(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['edu.davidson.graphics.Util','edu.davidson.graphics.BubblePanel','java.awt.Color','java.awt.Dimension']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Bubble", null, 'java.awt.Window');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.panel = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$S', function (comp, text) {
C$.superclazz.c$$java_awt_Frame.apply(this, [(I$[1]||$incl$(1)).getFrame$java_awt_Component(comp)]);
C$.$init$.apply(this);
this.panel = Clazz.new_((I$[2]||$incl$(2)).c$$S,[text]);
this.add$java_awt_Component$O(this.panel, "Center");
}, 1);

Clazz.newMeth(C$, 'setVisible$Z', function (b) {
this.pack();
C$.superclazz.prototype.setVisible$Z.apply(this, [b]);
});

Clazz.newMeth(C$, 'setText$S', function (txt) {
this.panel.setText$S(txt);
if (txt == null ) this.setVisible$Z(false);
 else {
this.pack();
this.panel.repaint();
}});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:37:11
