(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['java.util.Vector','edu.davidson.graph.TextState','java.util.Stack','java.awt.Font','java.lang.StringBuffer','edu.davidson.graph.SpecialFunction']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TextLine");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.script_fraction = 0;
this.sup_offset = 0;
this.sub_offset = 0;
this.font = null;
this.color = null;
this.background = null;
this.text = null;
this.fontname = null;
this.fontsize = 0;
this.fontstyle = 0;
this.justification = 0;
this.width = 0;
this.ascent = 0;
this.maxAscent = 0;
this.descent = 0;
this.maxDescent = 0;
this.height = 0;
this.leading = 0;
this.parse = false;
this.lg = null;
this.list = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.script_fraction = 0.8;
this.sup_offset = 0.6;
this.sub_offset = 0.7;
this.font = null;
this.color = null;
this.background = null;
this.text = null;
this.fontname = "TimesRoman";
this.fontsize = 0;
this.fontstyle = 0;
this.justification = 1;
this.width = 0;
this.ascent = 0;
this.maxAscent = 0;
this.descent = 0;
this.maxDescent = 0;
this.height = 0;
this.leading = 0;
this.parse = true;
this.lg = null;
this.list = Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[8, 4]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (s) {
C$.$init$.apply(this);
this.text = s;
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_Font', function (s, f) {
C$.c$$S.apply(this, [s]);
this.font = f;
if (this.font == null ) return;
this.fontname = f.getName();
this.fontstyle = f.getStyle();
this.fontsize = f.getSize();
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_Font$java_awt_Color$I', function (s, f, c, j) {
C$.c$$S$java_awt_Font.apply(this, [s, f]);
this.color = c;
this.justification = j;
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_Color', function (s, c) {
C$.c$$S.apply(this, [s]);
this.color = c;
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Font$java_awt_Color$I', function (f, c, j) {
C$.$init$.apply(this);
this.font = f;
this.color = c;
this.justification = j;
if (this.font == null ) return;
this.fontname = f.getName();
this.fontstyle = f.getStyle();
this.fontsize = f.getSize();
}, 1);

Clazz.newMeth(C$, 'copyState', function () {
return Clazz.new_(C$.c$$java_awt_Font$java_awt_Color$I,[this.font, this.color, this.justification]);
});

Clazz.newMeth(C$, 'copyState$edu_davidson_graph_TextLine', function (t) {
if (t == null ) return;
this.font = t.getFont();
this.color = t.getColor();
this.justification = t.getJustification();
if (this.font == null ) return;
this.fontname = this.font.getName();
this.fontstyle = this.font.getStyle();
this.fontsize = this.font.getSize();
this.parse = true;
});

Clazz.newMeth(C$, 'setFont$java_awt_Font', function (f) {
this.font = f;
this.fontname = f.getName();
this.fontstyle = f.getStyle();
this.fontsize = f.getSize();
this.parse = true;
});

Clazz.newMeth(C$, 'setText$S', function (s) {
this.text = s;
this.parse = true;
});

Clazz.newMeth(C$, 'setColor$java_awt_Color', function (c) {
this.color = c;
});

Clazz.newMeth(C$, 'setBackground$java_awt_Color', function (c) {
this.background = c;
});

Clazz.newMeth(C$, 'setJustification$I', function (i) {
switch (i) {
case 0:
this.justification = 0;
break;
case 1:
default:
this.justification = 1;
break;
case 2:
this.justification = 2;
break;
}
});

Clazz.newMeth(C$, 'getFont', function () {
return this.font;
});

Clazz.newMeth(C$, 'getText', function () {
return this.text;
});

Clazz.newMeth(C$, 'getColor', function () {
return this.color;
});

Clazz.newMeth(C$, 'getBackground', function () {
return this.background;
});

Clazz.newMeth(C$, 'getJustification', function () {
return this.justification;
});

Clazz.newMeth(C$, 'getFM$java_awt_Graphics', function (g) {
if (g == null ) return null;
if (this.font == null ) return g.getFontMetrics();
 else return g.getFontMetrics$java_awt_Font(this.font);
});

Clazz.newMeth(C$, 'charWidth$java_awt_Graphics$C', function (g, ch) {
var fm;
if (g == null ) return 0;
if (this.font == null ) fm = g.getFontMetrics();
 else fm = g.getFontMetrics$java_awt_Font(this.font);
return fm.charWidth$C(ch);
});

Clazz.newMeth(C$, 'getWidth$java_awt_Graphics', function (g) {
this.parseText$java_awt_Graphics(g);
return this.width;
});

Clazz.newMeth(C$, 'getHeight$java_awt_Graphics', function (g) {
this.parseText$java_awt_Graphics(g);
return this.height;
});

Clazz.newMeth(C$, 'getAscent$java_awt_Graphics', function (g) {
if (g == null ) return 0;
this.parseText$java_awt_Graphics(g);
return this.ascent;
});

Clazz.newMeth(C$, 'getMaxAscent$java_awt_Graphics', function (g) {
if (g == null ) return 0;
this.parseText$java_awt_Graphics(g);
return this.maxAscent;
});

Clazz.newMeth(C$, 'getDescent$java_awt_Graphics', function (g) {
if (g == null ) return 0;
this.parseText$java_awt_Graphics(g);
return this.descent;
});

Clazz.newMeth(C$, 'getMaxDescent$java_awt_Graphics', function (g) {
if (g == null ) return 0;
this.parseText$java_awt_Graphics(g);
return this.maxDescent;
});

Clazz.newMeth(C$, 'getLeading$java_awt_Graphics', function (g) {
if (g == null ) return 0;
this.parseText$java_awt_Graphics(g);
return this.leading;
});

Clazz.newMeth(C$, 'parseText$java_awt_Graphics', function (g) {
var fm;
var current = Clazz.new_((I$[2]||$incl$(2)));
var ch;
var state = Clazz.new_((I$[3]||$incl$(3)));
var w = 0;
if (this.lg !== g ) this.parse = true;
this.lg = g;
if (!this.parse) return;
this.parse = false;
this.width = 0;
this.leading = 0;
this.ascent = 0;
this.descent = 0;
this.height = 0;
this.maxAscent = 0;
this.maxDescent = 0;
if (this.text == null  || g == null  ) return;
this.list.removeAllElements();
if (this.font == null ) current.f = g.getFont();
 else current.f = this.font;
state.push$TE(current);
this.list.addElement$TE(current);
fm = g.getFontMetrics$java_awt_Font(current.f);
for (var i = 0; i < this.text.length$(); i++) {
ch = this.text.charAt(i);
switch (ch.$c()) {
case 36:
i++;
if (i < this.text.length$()) current.s.append$C(this.text.charAt(i));
break;
case 123:
w = current.getWidth$java_awt_Graphics(g);
if (!current.isEmpty()) {
current = current.copyState();
this.list.addElement$TE(current);
}state.push$TE(current);
current.x = current.x+(w);
break;
case 125:
w = current.x + current.getWidth$java_awt_Graphics(g);
state.pop();
current = (state.peek()).copyState();
this.list.addElement$TE(current);
current.x = w;
break;
case 94:
w = current.getWidth$java_awt_Graphics(g);
if (!current.isEmpty()) {
current = current.copyState();
this.list.addElement$TE(current);
}current.f = this.getScriptFont$java_awt_Font(current.f);
current.x = current.x+(w);
current.y = current.y-((((current.getAscent$java_awt_Graphics(g)) * this.sup_offset + 0.5)|0));
break;
case 95:
w = current.getWidth$java_awt_Graphics(g);
if (!current.isEmpty()) {
current = current.copyState();
this.list.addElement$TE(current);
}current.f = this.getScriptFont$java_awt_Font(current.f);
current.x = current.x+(w);
current.y = current.y+((((current.getDescent$java_awt_Graphics(g)) * this.sub_offset + 0.5)|0));
break;
default:
current.s.append$C(ch);
break;
}
}
var vec;
{
vec = this.list.clone();
}for (var i = 0; i < vec.size(); i++) {
current = ((vec.elementAt$I(i)));
if (!current.isEmpty()) {
this.width = this.width+(current.getWidth$java_awt_Graphics(g));
this.ascent = Math.max(this.ascent, Math.abs(current.y) + current.getAscent$java_awt_Graphics(g));
this.descent = Math.max(this.descent, Math.abs(current.y) + current.getDescent$java_awt_Graphics(g));
this.leading = Math.max(this.leading, current.getLeading$java_awt_Graphics(g));
this.maxDescent = Math.max(this.maxDescent, Math.abs(current.y) + current.getMaxDescent$java_awt_Graphics(g));
this.maxAscent = Math.max(this.maxAscent, Math.abs(current.y) + current.getMaxAscent$java_awt_Graphics(g));
}}
this.height = this.ascent + this.descent + this.leading ;
return;
});

Clazz.newMeth(C$, 'isNull', function () {
return (this.text == null );
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics$I$I$I', function (g, x, y, j) {
this.justification = j;
if (g == null ) return;
this.draw$java_awt_Graphics$I$I(g, x, y);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics$I$I', function (g, x, y) {
var ts;
var xoffset = x;
var yoffset = y;
if (g == null  || this.text == null  ) return;
var lg = g.create();
if (lg == null ) return;
this.parseText$java_awt_Graphics(g);
if (this.justification == 0) {
xoffset = x - (this.width/2|0);
} else if (this.justification == 2) {
xoffset = x - this.width;
}if (this.background != null ) {
lg.setColor$java_awt_Color(this.background);
lg.fillRect$I$I$I$I(xoffset, yoffset - this.ascent, this.width, this.height);
lg.setColor$java_awt_Color(g.getColor());
}if (this.font != null ) lg.setFont$java_awt_Font(this.font);
if (this.color != null ) lg.setColor$java_awt_Color(this.color);
var vec;
{
vec = this.list.clone();
}for (var i = 0; i < vec.size(); i++) {
ts = ((vec.elementAt$I(i)));
if (ts.f != null ) lg.setFont$java_awt_Font(ts.f);
if (ts.s != null ) lg.drawString$S$I$I(ts.toString(), ts.x + xoffset, ts.y + yoffset);
}
lg.dispose();
lg = null;
});

Clazz.newMeth(C$, 'getFontName', function () {
return this.fontname;
});

Clazz.newMeth(C$, 'getFontStyle', function () {
return this.fontstyle;
});

Clazz.newMeth(C$, 'getFontSize', function () {
return this.fontsize;
});

Clazz.newMeth(C$, 'setFontName$S', function (s) {
this.fontname = s;
p$.rebuildFont.apply(this, []);
});

Clazz.newMeth(C$, 'setFontStyle$I', function (i) {
this.fontstyle = i;
p$.rebuildFont.apply(this, []);
});

Clazz.newMeth(C$, 'setFontSize$I', function (i) {
this.fontsize = i;
p$.rebuildFont.apply(this, []);
});

Clazz.newMeth(C$, 'rebuildFont', function () {
this.parse = true;
if (this.fontsize <= 0 || this.fontname == null  ) {
this.font = null;
} else {
this.font = Clazz.new_((I$[4]||$incl$(4)).c$$S$I$I,[this.fontname, this.fontstyle, this.fontsize]);
}});

Clazz.newMeth(C$, 'getScriptFont$java_awt_Font', function (f) {
var size;
if (f == null ) return f;
size = f.getSize();
if (size <= 6) return f;
size = (((f.getSize()) * this.script_fraction + 0.5)|0);
if (size <= 6) return f;
return Clazz.new_((I$[4]||$incl$(4)).c$$S$I$I,[f.getName(), f.getStyle(), size]);
});

Clazz.newMeth(C$, 'parseDouble$D', function (d) {
return this.parseDouble$D$I$I$I(d, 7, 6, 2);
});

Clazz.newMeth(C$, 'parseDouble$D$I', function (d, p) {
return this.parseDouble$D$I$I$I(d, p + 1, p, 2);
});

Clazz.newMeth(C$, 'parseDouble$D$I$I$I', function (d, n, p, f) {
var x = d;
var left = n - p;
var right = 0;
var power;
var exponent;
var i;
var s = Clazz.new_((I$[5]||$incl$(5)).c$$I,[n + 4]);
if (left < 0) {
System.out.println$S("TextLine.parseDouble: Precision > significant figures!");
return false;
}if (d < 0.0 ) {
x = -d;
s.append$S("-");
}if (d == 0.0 ) exponent = 0;
 else exponent = ((Math.floor((I$[6]||$incl$(6)).log10$D(x)))|0);
power = exponent - (left - 1);
if (power < 0) {
for (i = power; i < 0; i++) {
x *= 10.0;
}
} else {
for (i = 0; i < power; i++) {
x /= 10.0;
}
}left = (x|0);
s.append$I(left);
if (p > 0) {
s.append$C(".");
right = x - left;
for (i = 0; i < p; i++) {
right *= 10;
var digit = (Math.round(right)|0);
s.append$I(digit);
right -= digit;
}
}if (power != 0) {
if (f == 1) {
s.append$C("E");
if (power < 0) s.append$C("-");
 else s.append$C("+");
power = Math.abs(power);
if (power > 9) {
s.append$I(power);
} else {
s.append$C("0");
s.append$I(power);
}} else {
s.append$S("x10{^");
s.append$I(power);
s.append$S("}");
}}this.setText$S(s.toString());
return true;
});
})();
//Created 2018-02-22 01:07:15
