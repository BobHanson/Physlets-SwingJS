(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[[0,'java.awt.Color','java.awt.event.KeyAdapter']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "SInteger", null, 'java.awt.TextField', 'java.awt.event.TextListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.lastValue=null;
this.lastCaretPosition=0;
this.noColor=false;
this.val=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.noColor=false;
this.val=0;
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (defval, size) {
C$.superclazz.c$$S$I.apply(this, ["" + defval, size]);
C$.$init$.apply(this);
this.addTextListener$java_awt_event_TextListener(this);
this.addKeyListener$java_awt_event_KeyListener(((P$.SInteger$1||
(function(){var C$=Clazz.newClass(P$, "SInteger$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'keyTyped$java_awt_event_KeyEvent', function (evt) {
var ch=evt.getKeyChar$();
if (!("0" <= ch && ch <= "9"  || ch == "-"  || Character.isISOControl$C(ch) )) evt.consume$();
 else {
this.b$['edu.davidson.display.SInteger'].lastCaretPosition=this.b$['java.awt.TextComponent'].getCaretPosition$.apply(this.b$['java.awt.TextComponent'], []);
if (this.b$['java.awt.TextComponent'].isEditable$.apply(this.b$['java.awt.TextComponent'], []) && !this.b$['edu.davidson.display.SInteger'].noColor ) this.b$['java.awt.TextComponent'].setBackground$java_awt_Color.apply(this.b$['java.awt.TextComponent'], [$I$(1).yellow]);
}});
})()
), Clazz.new_($I$(2), [this, null],P$.SInteger$1)));
this.lastValue="" + defval;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$I$I.apply(this, [0, 3]);
}, 1);

Clazz.newMeth(C$, ['textValueChanged$java_awt_event_TextEvent','textValueChanged$'], function (evt) {
this.checkValue$();
});

Clazz.newMeth(C$, 'checkValue$', function () {
try {
Integer.parseInt$S(this.getText$().trim$() + "0");
this.lastValue=this.getText$();
} catch (e) {
if (Clazz.exceptionOf(e,"NumberFormatException")){
this.setText$S(this.lastValue);
this.setCaretPosition$I(this.lastCaretPosition);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getValue$', function () {
this.checkValue$();
return this.getVal$();
});

Clazz.newMeth(C$, 'getVal$', function () {
try {
this.val=Integer.parseInt$S(this.getText$().trim$());
if (this.isEditable$() && !this.noColor ) this.setBackground$java_awt_Color($I$(1).white);
return this.val;
} catch (e) {
if (Clazz.exceptionOf(e,"NumberFormatException")){
if (!this.noColor) this.setBackground$java_awt_Color($I$(1).red);
return 0;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'setValue$I', function (v) {
this.val=v;
this.setText$S("" + v);
if (!this.noColor) this.setBackground$java_awt_Color($I$(1).white);
});

Clazz.newMeth(C$, 'isNoColor$', function () {
return this.noColor;
});

Clazz.newMeth(C$, 'setNoColor$Z', function (nc) {
this.noColor=nc;
});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:03 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
