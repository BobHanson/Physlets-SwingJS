(function(){var P$=Clazz.newPackage("qTimeAWT"),I$=[['java.awt.Color','edu.davidson.numerics.Parser','edu.davidson.tools.SApplet','java.awt.Polygon','edu.davidson.numerics.Util']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "QTimeState", null, null, 'edu.davidson.tools.SDataSource');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.ds = null;
this.parser = null;
this.norm = 0;
this.energy = 0;
this.x = null;
this.v = null;
this.re = null;
this.im = null;
this.dre = null;
this.dim = null;
this.rei = null;
this.imi = null;
this.colors = null;
this.numPts = 0;
this.minV = 0;
this.maxV = 0;
this.time = 0;
this.x0 = 0;
this.x1 = 0;
this.startPix = 0;
this.endPix = 0;
this.dx = 0;
this.dt = 0;
this.gamma = 0;
this.courant = 0;
this.owner = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "v", "re", "im", "dre", "dim"]);
this.ds = Clazz.array(Double.TYPE, [1, 6]);
this.norm = 1;
this.energy = 0;
this.colors = Clazz.array((I$[1]||$incl$(1)), [101]);
this.minV = 0;
this.maxV = 0;
this.time = 0;
this.dx = 1;
this.dt = 1;
this.gamma = 1;
this.courant = 0.35;
}, 1);

Clazz.newMeth(C$, 'c$$D$D$I$edu_davidson_tools_SApplet', function (x0_, x1_, numPts_, o) {
C$.$init$.apply(this);
this.owner=o;
this.parser=Clazz.new_((I$[2]||$incl$(2)).c$$I,[1]);
this.parser.defineVariable$I$S(1, "x");
p$.initColors.apply(this, []);
this.numPts=numPts_;
this.x=Clazz.array(Double.TYPE, [this.numPts]);
this.v=Clazz.array(Double.TYPE, [this.numPts]);
this.re=Clazz.array(Double.TYPE, [this.numPts]);
this.im=Clazz.array(Double.TYPE, [this.numPts]);
this.dre=Clazz.array(Double.TYPE, [this.numPts]);
this.dim=Clazz.array(Double.TYPE, [this.numPts]);
this.rei=Clazz.array(Double.TYPE, [this.numPts]);
this.imi=Clazz.array(Double.TYPE, [this.numPts]);
this.ds=Clazz.array(Double.TYPE, [this.numPts, 6]);
this.x0=x0_;
this.x1=x1_;
this.dx=(this.x1 - this.x0) / (this.numPts - 1);
this.dt=this.dx * this.dx * this.courant ;
this.gamma=this.dt / 2 / this.dx / this.dx ;
for (var i = 0; i < this.numPts; i++) {
this.rei[i]=0;
this.imi[i]=0;
this.re[i]=0;
this.im[i]=0;
this.x[i]=this.x0 + this.dx * i;
this.v[i]=0;
}
this.minV=0;
this.maxV=0;
(I$[3]||$incl$(3)).addDataSource$O(this);
}, 1);

Clazz.newMeth(C$, 'step$D', function (stepTime) {
if (stepTime < 0 ) this.stepMinus$D(stepTime);
 else this.stepPlus$D(stepTime);
});

Clazz.newMeth(C$, 'stepPlus$D', function (stepTime) {
var maxCount = 20000;
var localTime = 0;
var localStep = this.dt;
var count = 0;
this.gamma=localStep / 2 / this.dx / this.dx ;
if (Math.abs(stepTime / this.dt) > maxCount ) {
System.out.println$S("QTime time-step is too large.");
}while ((localTime < stepTime ) && (count < maxCount) ){
if (stepTime - localTime - localStep  < 0 ) {
localStep=stepTime - localTime;
this.gamma=localStep / 2 / this.dx / this.dx ;
count=maxCount;
}p$.stepRe$D.apply(this, [localStep]);
p$.stepIm$D.apply(this, [localStep]);
p$.setBoundary.apply(this, []);
localTime=localTime + localStep;
count++;
}
this.time=this.time + localTime;
});

Clazz.newMeth(C$, 'stepMinus$D', function (stepTime) {
var maxCount = 20000;
var localTime = 0;
var localStep = -this.dt;
var count = 0;
this.gamma=localStep / 2 / this.dx / this.dx ;
if (Math.abs(stepTime / this.dt) > maxCount ) {
System.out.println$S("QTime time-step is too large.");
}while ((localTime > stepTime ) && (count < maxCount) ){
if (stepTime - localTime - localStep  > 0 ) {
localStep=stepTime - localTime;
this.gamma=localStep / 2 / this.dx / this.dx ;
count=maxCount;
}p$.stepRe$D.apply(this, [localStep]);
p$.stepIm$D.apply(this, [localStep]);
p$.setBoundary.apply(this, []);
localTime=localTime + localStep;
count++;
}
this.time=this.time + localTime;
});

Clazz.newMeth(C$, 'stepRe$D', function (dt) {
for (var i = 1; i < this.numPts - 1; i++) {
this.re[i]=this.re[i] - this.gamma * (this.im[i + 1] + this.im[i - 1] - 2 * this.im[i]) + dt * this.v[i] * this.im[i] ;
}
});

Clazz.newMeth(C$, 'stepIm$D', function (dt) {
for (var i = 1; i < this.numPts - 1; i++) {
this.im[i]=this.im[i] + this.gamma * (this.re[i + 1] + this.re[i - 1] - 2 * this.re[i]) - dt * this.v[i] * this.re[i] ;
}
});

Clazz.newMeth(C$, 'setBoundary', function () {
this.re[0]=0;
this.im[0]=0;
this.re[this.numPts - 1]=0;
this.im[this.numPts - 1]=0;
});

Clazz.newMeth(C$, 'reset', function () {
this.time=0;
p$.calcNorm.apply(this, []);
p$.calcEnergy.apply(this, []);
for (var i = 0; i < this.numPts; i++) {
this.re[i]=this.rei[i];
this.im[i]=this.imi[i];
}
});

Clazz.newMeth(C$, 'setSpace$D$D', function (x0_, x1_) {
this.x0=x0_;
this.x1=x1_;
this.dx=(this.x1 - this.x0) / (this.numPts - 1);
this.dt=this.dx * this.dx * this.courant ;
this.gamma=this.dt / 2 / this.dx / this.dx ;
for (var i = 0; i < this.numPts; i++) {
this.rei[i]=0;
this.imi[i]=0;
this.re[i]=0;
this.im[i]=0;
this.x[i]=this.x0 + this.dx * i;
this.v[i]=0;
}
});

Clazz.newMeth(C$, 'setPotential$S', function (potStr) {
var y = 0;
var error = false;
var i;
this.parser.define$S(potStr);
this.parser.parse();
for (i=0; i < this.numPts; i++) {
try {
y=this.parser.evaluate$D(this.x[i]);
if (y == y ) this.v[i]=y;
 else {
System.out.println$S("Divide by zero!");
y=this.parser.evaluate$D(this.x[i] + 1.0E-32);
if (y == y ) this.v[i]=y;
 else this.v[i]=0;
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
error=true;
} else {
throw e;
}
}
this.v[i]=this.v[i];
if (i == 0) {
this.minV=this.v[0];
this.maxV=this.v[0];
} else {
if (this.v[i] < this.minV ) this.minV=this.v[i];
if (this.v[i] > this.maxV ) this.maxV=this.v[i];
}}
this.dt=this.dx * this.dx;
for (i=0; i < this.numPts; i++) {
if ((this.v[i] > 0 ) && (this.dt > 1 / (this.v[i] / 2 + 1 / this.dx / this.dx ) ) ) this.dt=1 / (this.v[i] / 2 + 1 / this.dx / this.dx );
}
for (i=0; i < this.numPts; i++) {
if ((this.v[i] < 0 ) && (this.dt > -2 / this.v[i] ) ) this.dt=-2 / this.v[i];
}
this.dt=this.dt * this.courant;
this.gamma=this.dt / 2 / this.dx / this.dx ;
this.reset();
return error;
});

Clazz.newMeth(C$, 'getMinV', function () {
return this.minV;
});

Clazz.newMeth(C$, 'getMaxV', function () {
return this.maxV;
});

Clazz.newMeth(C$, 'setReal$S', function (reStr) {
var y = 0;
var error = false;
this.parser.define$S(reStr);
this.parser.parse();
for (var i = 0; i < this.numPts; i++) {
try {
y=this.parser.evaluate$D(this.x[i]);
if (y == y ) this.rei[i]=y;
 else {
System.out.println$S("Divide by zero!");
y=this.parser.evaluate$D(this.x[i] + 1.0E-32);
if (y == y ) this.rei[i]=y;
 else this.rei[i]=0;
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
error=true;
} else {
throw e;
}
}
}
this.reset();
return error;
});

Clazz.newMeth(C$, 'setImaginary$S', function (imStr) {
var y = 0;
var error = false;
this.parser.define$S(imStr);
this.parser.parse();
for (var i = 0; i < this.numPts; i++) {
try {
y=this.parser.evaluate$D(this.x[i]);
if (y == y ) this.imi[i]=y;
 else {
System.out.println$S("Divide by zero!");
y=this.parser.evaluate$D(this.x[i] + 1.0E-32);
if (y == y ) this.imi[i]=y;
 else this.imi[i]=0;
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
error=true;
} else {
throw e;
}
}
}
this.reset();
return error;
});

Clazz.newMeth(C$, 'setXScale$I$I', function (sp, ep) {
this.startPix=sp;
this.endPix=ep;
});

Clazz.newMeth(C$, 'setPolyReal$I$I$java_awt_Polygon', function (iheight, basePix, polyline) {
if (this.numPts == 0) return;
if (polyline.npoints == 0) return;
var offset;
for (var i = this.startPix; i <= this.endPix; i++) {
offset=(((this.numPts - 1) * (i - this.startPix)/(this.endPix - this.startPix)|0));
polyline.ypoints[i]=((basePix + this.re[offset] * iheight / 2)|0);
}
});

Clazz.newMeth(C$, 'setPolyImaginary$I$I$java_awt_Polygon', function (iheight, basePix, polyline) {
if (this.numPts == 0) return;
var offset;
for (var i = this.startPix; i <= this.endPix; i++) {
offset=(((this.numPts - 1) * (i - this.startPix)/(this.endPix - this.startPix)|0));
polyline.ypoints[i]=((basePix + this.im[offset] * iheight / 2)|0);
}
});

Clazz.newMeth(C$, 'setPolyProb$I$I$java_awt_Polygon', function (iheight, basePix, polyline) {
if (this.numPts == 0) return;
if (polyline.npoints == 0) return;
var offset;
var amp;
for (var i = this.startPix; i <= this.endPix; i++) {
offset=(((this.numPts - 1) * (i - this.startPix)/(this.endPix - this.startPix)|0));
amp=-Math.sqrt(this.re[offset] * this.re[offset] + this.im[offset] * this.im[offset]);
polyline.ypoints[i]=((basePix + amp * iheight / 2)|0);
}
});

Clazz.newMeth(C$, 'setPolyProbNeg$I$I$java_awt_Polygon', function (iheight, basePix, polyline) {
if (this.numPts == 0) return;
if (polyline.npoints == 0) return;
var offset;
var amp;
for (var i = this.startPix; i <= this.endPix; i++) {
offset=(((this.numPts - 1) * (i - this.startPix)/(this.endPix - this.startPix)|0));
amp=Math.sqrt(this.re[offset] * this.re[offset] + this.im[offset] * this.im[offset]);
polyline.ypoints[i]=((basePix + amp * iheight / 2)|0);
}
});

Clazz.newMeth(C$, 'fillPolyProb$I$I$java_awt_Polygon$java_awt_Graphics', function (iheight, basePix, polyline, g) {
if (this.numPts == 0) return;
if (polyline.npoints == 0) return;
var xpts = Clazz.array(Integer.TYPE, [5]);
var ypts = Clazz.array(Integer.TYPE, [5]);
var shape = Clazz.new_((I$[4]||$incl$(4)).c$$IA$IA$I,[xpts, ypts, 5]);
var x0;
var x1;
var y0;
var y1;
var y0Neg;
var y1Neg;
var offset = 0;
var amp = Math.sqrt(this.re[0] * this.re[0] + this.im[0] * this.im[0]) / 2;
if (this.startPix < 0 || this.startPix > polyline.xpoints.length - 1 ) return;
if (this.endPix < 0 || this.endPix > polyline.xpoints.length - 1 ) return;
x0=polyline.xpoints[this.startPix];
y0=((basePix + amp * iheight / 2)|0);
y0Neg=((basePix - amp * iheight / 2)|0);
for (var i = this.startPix + 1; i < this.endPix; i++) {
offset=(((this.numPts - 1) * (i - this.startPix)/(this.endPix - this.startPix)|0));
amp=Math.sqrt(this.re[offset] * this.re[offset] + this.im[offset] * this.im[offset]) / 2;
x1=polyline.xpoints[i];
y1=((basePix + amp * iheight / 2)|0);
y1Neg=((basePix - amp * iheight / 2)|0);
shape.xpoints[0]=x0;
shape.ypoints[0]=y0;
shape.xpoints[1]=x1;
shape.ypoints[1]=y1;
shape.xpoints[2]=x1;
shape.ypoints[2]=y1Neg;
shape.xpoints[3]=x0;
shape.ypoints[3]=y0Neg;
shape.xpoints[4]=x0;
shape.ypoints[4]=y0;
g.setColor$java_awt_Color(p$.colorFromPhase$D.apply(this, [Math.atan2(this.im[offset], this.re[offset])]));
g.fillPolygon$java_awt_Polygon(shape);
x0=x1;
y0=y1;
y0Neg=y1Neg;
}
});

Clazz.newMeth(C$, 'calcNorm', function () {
var sum = 0;
for (var i = 0; i < this.numPts; i++) {
sum += this.re[i] * this.re[i] + this.im[i] * this.im[i];
}
if (sum > 0 ) this.norm=Math.sqrt(sum * this.dx);
 else this.norm=1;
});

Clazz.newMeth(C$, 'calcEnergy', function () {
var HR = 0;
var HI = 0;
var sumRHR = 0;
var sumIHI = 0;
var sumIHR = 0;
var sumRHI = 0;
for (var i = 1; i < this.numPts - 1; i++) {
HR=-(this.re[i + 1] + this.re[i - 1] - 2 * this.re[i]) / 2 / this.dx / this.dx  + this.v[i] * this.re[i];
HI=-(this.im[i + 1] + this.im[i - 1] - 2 * this.im[i]) / 2 / this.dx / this.dx  + this.v[i] * this.im[i];
sumRHR += this.re[i] * HR;
sumIHI += this.im[i] * HI;
sumIHR += this.im[i] * HR;
sumRHI += this.re[i] * HI;
}
this.energy=(sumRHR + sumIHI) * this.dx / this.norm / this.norm;
});

Clazz.newMeth(C$, 'getEnergy', function () {
return this.energy;
});

Clazz.newMeth(C$, 'getPsiAtX$D', function (x1) {
var i = 0;
if (x1 < this.x[0]  || x1 > this.x[this.numPts - 1]  ) return 0;
while (x1 > this.x[i] )i++;

return Math.sqrt(this.re[i] * this.re[i] + this.im[i] * this.im[i]) / this.norm;
});

Clazz.newMeth(C$, 'getAngleAtX$D', function (x1) {
var i = 0;
if (x1 < this.x[0]  || x1 > this.x[this.numPts - 1]  ) return 0;
while (x1 > this.x[i] )i++;

if (this.im[i] == 0  && this.re[i] == 0  ) return 0;
return ((180 * Math.atan2(this.im[i], this.re[i]) / 3.141592653589793)|0);
});

Clazz.newMeth(C$, 'colorFromPhase$D', function (phi) {
var offset = ((50 + 50 * phi / 3.141592653589793)|0);
return this.colors[offset];
});

Clazz.newMeth(C$, 'initColors', function () {
var r;
var g;
var b;
var pi = 3.141592653589793;
for (var i = 0; i < 101; i++) {
b=((255 * Math.sin(pi * i / 100) * Math.sin(pi * i / 100) )|0);
g=((255 * Math.sin(pi * i / 100 + pi / 3) * Math.sin(pi * i / 100 + pi / 3) )|0);
r=((255 * Math.sin(pi * i / 100 + 2 * pi / 3) * Math.sin(pi * i / 100 + 2 * pi / 3) )|0);
this.colors[i]=Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[r, g, b]);
}
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'getVariables', function () {
(I$[5]||$incl$(5)).numericDerivative$D$DA$DA(this.dx, this.re, this.dre);
(I$[5]||$incl$(5)).numericDerivative$D$DA$DA(this.dx, this.im, this.dim);
for (var i = 0; i < this.numPts; i++) {
this.ds[i][0]=this.x[i];
this.ds[i][1]=this.v[i];
this.ds[i][2]=this.re[i] / this.norm;
this.ds[i][3]=this.im[i] / this.norm;
this.ds[i][4]=this.dre[i] / this.norm;
this.ds[i][5]=this.dim[i] / this.norm;
}
return this.ds;
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:38
