(function(){var P$=Clazz.newPackage("emwave4"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Figure");
C$.xOrigin = 0;
C$.yOrigin = 0;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.numLines = 0;
this.pts = null;
this.c = null;
this.figType = null;
this.pixPerUnit = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.numLines = 0;
this.pts = null;
this.c = (I$[1]||$incl$(1)).blue;
this.figType = "line";
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'translate$D', function (z) {
});

Clazz.newMeth(C$, 'getPtsValue$I$I', function (i, j) {
return this.pts[i][j];
});

Clazz.newMeth(C$, 'getPts', function () {
return this.pts;
});

Clazz.newMeth(C$, 'getNumPts', function () {
return 2 * this.numLines;
});

Clazz.newMeth(C$, 'getNumLines', function () {
return this.numLines;
});

Clazz.newMeth(C$, 'setColor$java_awt_Color', function (clr) {
});

Clazz.newMeth(C$, 'reSetColor$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color(this.c);
});

Clazz.newMeth(C$, 'setOrigin$java_awt_Graphics', function (g) {
g.translate$I$I(C$.xOrigin, C$.yOrigin);
});

Clazz.newMeth(C$, 'setOrigin$I$I', function (x, y) {
C$.xOrigin = x;
C$.yOrigin = y;
}, 1);

Clazz.newMeth(C$, 'setOrigin$java_awt_Graphics$I$I', function (g, x, y) {
g.translate$I$I(C$.xOrigin = x, C$.yOrigin = y);
});

Clazz.newMeth(C$, 'resetOrigin$java_awt_Graphics', function (g) {
g.translate$I$I(-C$.xOrigin, -C$.yOrigin);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics$DAA', function (g, trans) {
});

Clazz.newMeth(C$, 'drawFigure$java_awt_Graphics$DAA', function (g, trans) {
this.reSetColor$java_awt_Graphics(g);
this.setOrigin$java_awt_Graphics(g);
for (var i = 0; i < this.getNumPts(); i++) g.drawLine$I$I$I$I((Math.round(trans[0][0] * this.getPtsValue$I$I(i, 0) + trans[0][1] * this.getPtsValue$I$I(i, 1) + trans[0][2] * this.getPtsValue$I$I(i, 2))|0), (Math.round(trans[1][0] * this.getPtsValue$I$I(i, 0) + trans[1][1] * this.getPtsValue$I$I(i, 1) + trans[1][2] * this.getPtsValue$I$I(i, 2))|0), (Math.round(trans[0][0] * this.getPtsValue$I$I(++i, 0) + trans[0][1] * this.getPtsValue$I$I(i, 1) + trans[0][2] * this.getPtsValue$I$I(i, 2))|0), (Math.round(trans[1][0] * this.getPtsValue$I$I(i, 0) + trans[1][1] * this.getPtsValue$I$I(i, 1) + trans[1][2] * this.getPtsValue$I$I(i, 2))|0));

this.resetOrigin$java_awt_Graphics(g);
});
})();
//Created 2018-02-19 20:23:03
