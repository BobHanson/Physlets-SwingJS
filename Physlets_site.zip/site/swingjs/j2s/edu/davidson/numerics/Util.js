(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newClass(P$, "Util");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'numericDerivative$D$DA$DA', function (dx, input, output) {
var len=input.length;
if (len != output.length) {
System.out.println$S("Vector lengths do not match.");
return;
}if (len < 2) {
System.out.println$S("Vector length must be > 1.");
return;
}if (len < 3) {
output[0]=(input[1] - input[0]) / dx;
output[1]=output[0];
return;
}output[0]=(-0.5 * input[2] + 2.0 * input[1] - 1.5 * input[0]) / dx;
output[len - 1]=(1.5 * input[len - 1] - 2.0 * input[len - 2] + 0.5 * input[len - 3]) / dx;
for (var i=1; i < len - 1; i++) {
output[i]=(input[i + 1] - input[i - 1]) / (2.0 * dx);
}
}, 1);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:04 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
