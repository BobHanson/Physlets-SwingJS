(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['edu.davidson.graphics.BorderStyle','edu.davidson.graphics.DrawnRectangle']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ThreeDRectangle", null, 'edu.davidson.graphics.DrawnRectangle');
C$._defaultState = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$._defaultState = (I$[1]||$incl$(1)).RAISED;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.state = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component', function (drawInto) {
C$.c$$java_awt_Component$edu_davidson_graphics_BorderStyle$I$I$I$I$I.apply(this, [drawInto, C$._defaultState, (I$[2]||$incl$(2))._defaultThickness, 0, 0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I', function (drawInto, thickness) {
C$.c$$java_awt_Component$edu_davidson_graphics_BorderStyle$I$I$I$I$I.apply(this, [drawInto, C$._defaultState, thickness, 0, 0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I$I$I$I', function (drawInto, x, y, w, h) {
C$.c$$java_awt_Component$edu_davidson_graphics_BorderStyle$I$I$I$I$I.apply(this, [drawInto, C$._defaultState, (I$[2]||$incl$(2))._defaultThickness, x, y, w, h]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I$I$I$I$I', function (drawInto, thickness, x, y, w, h) {
C$.c$$java_awt_Component$edu_davidson_graphics_BorderStyle$I$I$I$I$I.apply(this, [drawInto, C$._defaultState, thickness, x, y, w, h]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$edu_davidson_graphics_BorderStyle$I$I$I$I$I', function (drawInto, state, thickness, x, y, w, h) {
C$.superclazz.c$$java_awt_Component$I$I$I$I$I.apply(this, [drawInto, thickness, x, y, w, h]);
C$.$init$.apply(this);
this.state = state;
}, 1);

Clazz.newMeth(C$, 'paint', function () {
if (this.state === (I$[1]||$incl$(1)).RAISED ) this.paintRaised();
 else this.paintInset();
});

Clazz.newMeth(C$, 'raise', function () {
this.state = (I$[1]||$incl$(1)).RAISED;
});

Clazz.newMeth(C$, 'inset', function () {
this.state = (I$[1]||$incl$(1)).INSET;
});

Clazz.newMeth(C$, 'isRaised', function () {
return this.state === (I$[1]||$incl$(1)).RAISED ;
});

Clazz.newMeth(C$, 'paramString', function () {
return C$.superclazz.prototype.paramString.apply(this, []) + "," + this.state ;
});

Clazz.newMeth(C$, 'paintRaised', function () {
var g = this.drawInto.getGraphics();
if (g != null ) {
this.raise();
p$.drawTopLeftLines$java_awt_Graphics$java_awt_Color.apply(this, [g, this.brighter()]);
p$.drawBottomRightLines$java_awt_Graphics$java_awt_Color.apply(this, [g, this.getLineColor()]);
g.dispose();
}});

Clazz.newMeth(C$, 'paintInset', function () {
var g = this.drawInto.getGraphics();
if (g != null ) {
this.inset();
p$.drawTopLeftLines$java_awt_Graphics$java_awt_Color.apply(this, [g, this.getLineColor()]);
p$.drawBottomRightLines$java_awt_Graphics$java_awt_Color.apply(this, [g, this.brighter()]);
g.dispose();
}});

Clazz.newMeth(C$, 'drawTopLeftLines$java_awt_Graphics$java_awt_Color', function (g, color) {
var thick = this.getThickness();
g.setColor$java_awt_Color(color);
for (var i = 0; i < thick; ++i) {
g.drawLine$I$I$I$I(this.x + i, this.y + i, this.x + this.width - (i + 1), this.y + i);
g.drawLine$I$I$I$I(this.x + i, this.y + i + 1 , this.x + i, this.y + this.height - (i + 1));
}
});

Clazz.newMeth(C$, 'drawBottomRightLines$java_awt_Graphics$java_awt_Color', function (g, color) {
var thick = this.getThickness();
g.setColor$java_awt_Color(color);
for (var i = 1; i <= thick; ++i) {
g.drawLine$I$I$I$I(this.x + i - 1, this.y + this.height - i, this.x + this.width - i, this.y + this.height - i);
g.drawLine$I$I$I$I(this.x + this.width - i, this.y + i - 1, this.x + this.width - i, this.y + this.height - i);
}
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:24
