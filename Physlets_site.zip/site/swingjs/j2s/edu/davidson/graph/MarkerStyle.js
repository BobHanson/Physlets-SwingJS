(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[[0,'java.util.Vector','edu.davidson.graph.MarkerStyle','edu.davidson.graph.MarkerVertex','edu.davidson.graph.Markers']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "MarkerStyle");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.size=0;
this.type=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.size=4;
this.type=$I$(4).TYPE_CIRCLE;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:04 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
