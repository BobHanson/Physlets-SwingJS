(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CircleThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I', function (owner, sc, x, y, radius) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, x, y]);
C$.$init$.apply(this);
this.s = 1;
this.w = radius;
this.h = radius;
this.applet = owner;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.x) - this.w + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.w - this.yDisplayOff ;
osg.setColor$java_awt_Color(this.color);
osg.fillOval$I$I$I$I(ptX, ptY, 2 * this.w + 1, 2 * this.h + 1);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.x) - this.w + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.w - this.yDisplayOff ;
if (this.color === (I$[1]||$incl$(1)).red ) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).blue);
 else osg.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
osg.fillOval$I$I$I$I(ptX, ptY, 2 * this.w + 1, 2 * this.h + 1);
osg.fillOval$I$I$I$I(ptX - 1, ptY - 1, 2 * this.w + 3, 2 * this.h + 3);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < this.w + 1) && (Math.abs(yPix - ptY) < this.w + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:07:12
