(function(){var P$=Clazz.newPackage("qTime"),I$=[['a2s.Button','a2s.TextField','Boolean','java.awt.BorderLayout','a2s.Panel','qTime.QTimeGraph','qTime.TabbedPanel','java.awt.GridLayout','java.awt.Color','edu.davidson.graphics.Box','qTime.QTimeHelp','java.awt.FlowLayout','a2s.Label']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "QTime", null, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SStepable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.button_start = null;
this.button_stop = null;
this.button_reset = null;
this.button_submit = null;
this.label_qtime = null;
this.label_qm = null;
this.label_help = null;
this.label_wavefunction = null;
this.label_time = null;
this.label_energy = null;
this.label_real = null;
this.label_imaginary = null;
this.label_potential = null;
this.label_new = null;
this.label_magnitude = null;
this.label_phase = null;
this.t = 0;
this.runBtn = null;
this.resetBtn = null;
this.parseBtn = null;
this.potInput = null;
this.reInput = null;
this.imInput = null;
this.graph = null;
this.m_fStandAlone = false;
this.m_potential = null;
this.m_real = null;
this.m_imaginary = null;
this.m_numPts = 0;
this.m_minX = 0;
this.m_maxX = 0;
this.m_showControls = false;
this.m_FPS = 0;
this.PARAM_FPS = null;
this.PARAM_dt = null;
this.PARAM_potential = null;
this.PARAM_real = null;
this.PARAM_imaginary = null;
this.PARAM_numPts = null;
this.PARAM_minX = null;
this.PARAM_maxX = null;
this.PARAM_showControls = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.button_start = "Run";
this.button_stop = "Stop";
this.button_reset = "Reset";
this.button_submit = "Submit Functions";
this.label_qtime = "QTime";
this.label_qm = "QM";
this.label_help = "Help";
this.label_wavefunction = "Wavefunction";
this.label_time = "Time:";
this.label_energy = "Energy";
this.label_real = "Real";
this.label_imaginary = "Imaginary";
this.label_potential = "Potential";
this.label_new = "New System";
this.label_magnitude = "|Psi|";
this.label_phase = "alpha:";
this.t = 0;
this.runBtn = Clazz.new_((I$[1]||$incl$(1)).c$$S,["Run"]);
this.resetBtn = Clazz.new_((I$[1]||$incl$(1)).c$$S,["Reset"]);
this.parseBtn = Clazz.new_((I$[1]||$incl$(1)).c$$S,["Submit Functions"]);
this.potInput = Clazz.new_((I$[2]||$incl$(2)).c$$I,[30]);
this.reInput = Clazz.new_((I$[2]||$incl$(2)).c$$I,[30]);
this.imInput = Clazz.new_((I$[2]||$incl$(2)).c$$I,[30]);
this.m_fStandAlone = false;
this.m_potential = "20*(step(1+x)-step(x-1))";
this.m_real = "cos(2*pi*x)*exp(-(x+4)*(x+4))";
this.m_imaginary = "sin(2*pi*x)*exp(-(x+4)*(x+4))";
this.m_numPts = 256;
this.m_minX = -10;
this.m_maxX = 10;
this.m_showControls = true;
this.m_FPS = 10;
this.PARAM_FPS = "FPS";
this.PARAM_dt = "dt";
this.PARAM_potential = "potential";
this.PARAM_real = "real";
this.PARAM_imaginary = "imaginary";
this.PARAM_numPts = "numPts";
this.PARAM_minX = "minX";
this.PARAM_maxX = "maxX";
this.PARAM_showControls = "showControls";
}, 1);

Clazz.newMeth(C$, 'GetParameter$S$SA', function (strName, args) {
if (args == null ) {
return this.getParameter$S(strName);
}var i;
var strArg = strName + "=";
var strValue = null;
for (i=0; i < args.length; i++) {
if (strArg.equalsIgnoreCase$S(args[i].substring(0, strArg.length$()))) {
strValue=args[i].substring(strArg.length$());
if (strValue.startsWith$S("\"")) {
strValue=strValue.substring(1);
if (strValue.endsWith$S("\"")) {
strValue=strValue.substring(0, strValue.length$() - 1);
}}}}
return strValue;
});

Clazz.newMeth(C$, 'GetParameters$SA', function (args) {
var param;
param=this.GetParameter$S$SA("potential", args);
if (param != null ) {
this.m_potential=param;
}param=this.GetParameter$S$SA("real", args);
if (param != null ) {
this.m_real=param;
}param=this.GetParameter$S$SA("imaginary", args);
if (param != null ) {
this.m_imaginary=param;
}param=this.GetParameter$S$SA("FPS", args);
if (param != null ) {
this.m_FPS=Integer.parseInt(param);
}param=this.GetParameter$S$SA("numPts", args);
if (param != null ) {
this.m_numPts=Integer.parseInt(param);
}param=this.GetParameter$S$SA("minX", args);
if (param != null ) {
this.m_minX=Double.$valueOf(param).doubleValue();
}param=this.GetParameter$S$SA("maxX", args);
if (param != null ) {
this.m_maxX=Double.$valueOf(param).doubleValue();
}param=this.GetParameter$S$SA("showControls", args);
if (param != null ) {
this.m_showControls=(I$[3]||$incl$(3)).$valueOf(param).booleanValue();
}param=this.GetParameter$S$SA("dt", args);
if (param != null ) {
var dt = Double.$valueOf(param).doubleValue();
this.clock.setDt$D(dt);
}});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Name: QTime Ver 1.2\u000d\u000aAuthor: Wolfgang Christian\u000d\u000aEMail: wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var info = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["potential", "String", "Potential"]), Clazz.array(java.lang.String, -1, ["real", "String", "Real part of wavefunction"]), Clazz.array(java.lang.String, -1, ["imaginary", "String", "Imaginary part of wavefunction"]), Clazz.array(java.lang.String, -1, ["FPS", "int", "Frames per second."]), Clazz.array(java.lang.String, -1, ["dt", "double", "Time step per frame."]), Clazz.array(java.lang.String, -1, ["numPts", "int", "Number of points to plot"]), Clazz.array(java.lang.String, -1, ["minX", "double", "Minimum x value"]), Clazz.array(java.lang.String, -1, ["maxX", "double", "Maximum x value"]), Clazz.array(java.lang.String, -1, ["showControls", "boolean", "Show controls on screen"])]);
return info;
});

Clazz.newMeth(C$, 'setResources', function () {
this.button_start=this.localProperties.getProperty$S$S("button.start", this.button_start);
this.button_stop=this.localProperties.getProperty$S$S("button.stop", this.button_stop);
this.button_reset=this.localProperties.getProperty$S$S("button.reset", this.button_reset);
this.button_submit=this.localProperties.getProperty$S$S("button.submit", this.button_submit);
this.label_wavefunction=this.localProperties.getProperty$S$S("label.wavefunction", this.label_wavefunction);
this.label_qtime=this.localProperties.getProperty$S$S("label.qtime", this.label_qtime);
this.label_qm=this.localProperties.getProperty$S$S("label.qm", this.label_qm);
this.label_help=this.localProperties.getProperty$S$S("label.help", this.label_help);
this.label_time=this.localProperties.getProperty$S$S("label.time", this.label_time);
this.label_energy=this.localProperties.getProperty$S$S("label.energy", this.label_energy);
this.label_real=this.localProperties.getProperty$S$S("label.real", this.label_real);
this.label_imaginary=this.localProperties.getProperty$S$S("label.imaginary", this.label_imaginary);
this.label_potential=this.localProperties.getProperty$S$S("label.potential", this.label_potential);
this.label_new=this.localProperties.getProperty$S$S("label.new", this.label_new);
this.label_magnitude=this.localProperties.getProperty$S$S("label.magnitude", this.label_magnitude);
this.label_phase=this.localProperties.getProperty$S$S("label.phase", this.label_phase);
});

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
this.runBtn.setLabel$S(this.button_start + " ");
this.resetBtn.setLabel$S(this.button_reset);
this.parseBtn.setLabel$S(this.button_submit);
if (!this.m_fStandAlone) {
this.GetParameters$SA(null);
}{
this.resize$I$I(400, 400);
}this.setLayout$java_awt_LayoutManager(Clazz.new_((I$[4]||$incl$(4))));
var p = Clazz.new_((I$[5]||$incl$(5)));
p.setLayout$java_awt_LayoutManager(Clazz.new_((I$[4]||$incl$(4))));
this.graph=Clazz.new_((I$[6]||$incl$(6)).c$$qTime_QTime$I,[this, this.m_numPts]);
if (!this.graph.setPotential$S(this.m_potential)) {
System.out.println$S("Failed to parse potential!");
}if (!this.graph.setReal$S(this.m_real)) {
System.out.println$S("Failed to real psi!");
}if (!this.graph.setImaginary$S(this.m_imaginary)) {
System.out.println$S("Failed to parse imaginary psi!");
}this.graph.setXMinMax$D$D(this.m_minX, this.m_maxX);
p.add$S$java_awt_Component("Center", this.graph);
this.potInput.setText$S(this.m_potential);
this.reInput.setText$S(this.m_real);
this.imInput.setText$S(this.m_imaginary);
if (this.m_showControls) {
var t = Clazz.new_((I$[7]||$incl$(7)));
this.add$S$java_awt_Component("Center", t);
var p11 = Clazz.new_((I$[5]||$incl$(5)));
p11.setLayout$java_awt_LayoutManager(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[1, 2]));
p11.add$java_awt_Component(this.runBtn);
p11.add$java_awt_Component(this.resetBtn);
p.add$S$java_awt_Component("South", p11);
t.addItem$S$java_awt_Component(this.label_wavefunction, p);
var p2 = Clazz.new_((I$[5]||$incl$(5)));
p2.setBackground$java_awt_Color((I$[9]||$incl$(9)).lightGray);
p2.setLayout$java_awt_LayoutManager(Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I$I,[4, 1, 10, 30]));
p2.add$java_awt_Component(Clazz.new_((I$[10]||$incl$(10)).c$$java_awt_Component$S,[this.reInput, this.label_real]));
p2.add$java_awt_Component(Clazz.new_((I$[10]||$incl$(10)).c$$java_awt_Component$S,[this.imInput, this.label_imaginary]));
p2.add$java_awt_Component(Clazz.new_((I$[10]||$incl$(10)).c$$java_awt_Component$S,[this.potInput, this.label_potential]));
p2.add$java_awt_Component(Clazz.new_((I$[10]||$incl$(10)).c$$java_awt_Component$S,[this.parseBtn, this.label_new]));
t.addItem$S$java_awt_Component(this.label_qm, p2);
var hc = Clazz.new_((I$[11]||$incl$(11)).c$$qTime_QTime,[this]);
t.addItem$S$java_awt_Component(this.label_help, hc);
} else {
this.add$S$java_awt_Component("Center", p);
}this.reset();
this.clock.setFPS$D(this.m_FPS);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
});

Clazz.newMeth(C$, 'destroy', function () {
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.firstTime) {
return 0;
} else {
return C$.superclazz.prototype.getAppletCount.apply(this, []);
}});

Clazz.newMeth(C$, 'start', function () {
C$.superclazz.prototype.start.apply(this, []);
if (this.firstTime) {
this.firstTime=false;
}});

Clazz.newMeth(C$, 'forward', function () {
this.runBtn.setLabel$S(this.button_stop);
this.clock.startClock();
});

Clazz.newMeth(C$, 'pause', function () {
this.runBtn.setLabel$S(this.button_start + " ");
if (this.clock.isRunning()) {
this.clock.stopClock();
}});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
this.t=this.t + dt;
this.graph.stepState$D(dt);
this.updateDataConnections();
});

Clazz.newMeth(C$, ['setDt$D','setDt'], function (dt) {
this.clock.setDt$D(dt);
});

Clazz.newMeth(C$, 'stepForward', function () {
if (this.clock.isRunning()) {
this.pause();
return;
}var isNegative = false;
if (this.clock.getDt() < 0 ) {
isNegative=true;
}this.clock.setDt$D(Math.abs(this.clock.getDt()));
this.clock.doStep();
if (isNegative) {
this.clock.setDt$D(-Math.abs(this.clock.getDt()));
}});

Clazz.newMeth(C$, 'stepTimeBack', function () {
if (this.clock.isRunning()) {
this.pause();
return;
}var isNegative = false;
if (this.clock.getDt() < 0 ) {
isNegative=true;
}this.clock.setDt$D(-Math.abs(this.clock.getDt()));
this.clock.doStep();
if (!isNegative) {
this.clock.setDt$D(Math.abs(this.clock.getDt()));
}});

Clazz.newMeth(C$, ['action$java_awt_Event$O','action'], function (ev, a) {
if (ev.target.equals$O(this.runBtn)) {
if (this.clock.isRunning()) {
this.runBtn.setLabel$S(this.button_start + " ");
this.clock.stopClock();
} else {
this.runBtn.setLabel$S(this.button_stop);
this.clock.startClock();
}return true;
}if (ev.target.equals$O(this.resetBtn)) {
this.reset();
return true;
}if (ev.target.equals$O(this.parseBtn)) {
var str;
str=this.potInput.getText();
this.setPotential$S(str);
str=this.reInput.getText();
this.setReal$S(str);
str=this.imInput.getText();
this.setImaginary$S(str);
this.reset();
return true;
}return false;
});

Clazz.newMeth(C$, 'reset', function () {
this.runBtn.setLabel$S(this.button_start + " ");
this.clock.stopClock();
this.clock.setTime$D(0);
this.graph.reset();
this.t=0;
this.graph.repaint();
this.updateDataConnections();
});

Clazz.newMeth(C$, 'setDefault', function () {
this.reset();
});

Clazz.newMeth(C$, ['setPotential$S','setPotential'], function (f) {
this.m_potential=f;
this.potInput.setText$S(this.m_potential);
if (!this.graph.setPotential$S(this.m_potential)) {
this.potInput.setBackground$java_awt_Color((I$[9]||$incl$(9)).red);
System.out.println$S("Failed to parse potential!");
} else {
this.potInput.setBackground$java_awt_Color((I$[9]||$incl$(9)).white);
}this.potInput.setText$S(this.m_potential);
});

Clazz.newMeth(C$, ['setReal$S','setReal'], function (f) {
this.m_real=f;
this.reInput.setText$S(this.m_real);
if (!this.graph.setReal$S(this.m_real)) {
this.reInput.setBackground$java_awt_Color((I$[9]||$incl$(9)).red);
System.out.println$S("Failed to parse real!");
} else {
this.reInput.setBackground$java_awt_Color((I$[9]||$incl$(9)).white);
}this.reInput.setText$S(this.m_real);
});

Clazz.newMeth(C$, ['setImaginary$S','setImaginary'], function (f) {
this.m_imaginary=f;
this.imInput.setText$S(this.m_imaginary);
if (!this.graph.setImaginary$S(this.m_imaginary)) {
this.imInput.setBackground$java_awt_Color((I$[9]||$incl$(9)).red);
System.out.println$S("Failed to parse imaginary!");
} else {
this.imInput.setBackground$java_awt_Color((I$[9]||$incl$(9)).white);
}this.imInput.setText$S(this.m_imaginary);
});

Clazz.newMeth(C$, ['setEnergyOffset$Z','setEnergyOffset'], function (set) {
this.graph.offsetFunction=set;
this.graph.repaint();
});

Clazz.newMeth(C$, ['setShowAxes$Z','setShowAxes'], function (show) {
if (this.graph.isShowAxis() == show ) {
return;
}if (show) {
this.graph.setGutters$I$I$I$I(20, 20, 20, 20);
this.graph.drawgrid=true;
} else {
this.graph.setGutters$I$I$I$I(0, 0, 0, 0);
this.graph.drawgrid=false;
}this.graph.setShowAxis$Z(show);
this.graph.repaint();
});

Clazz.newMeth(C$, 'getWavefunctionID', function () {
return this.graph.getState().getID();
});

Clazz.newMeth(C$, ['setShowPotential$Z','setShowPotential'], function (show) {
if (this.graph.showPotential == show ) {
return;
}this.graph.showPotential=show;
this.graph.parsePotential();
this.graph.repaint();
});

Clazz.newMeth(C$, ['setRGBColor$I$I$I','setRGBColor'], function (r, g, b) {
this.graph.setRGBColor$I$I$I(r, g, b);
});

Clazz.newMeth(C$, ['setYMinMax$D$D','setYMinMax'], function (min, max) {
this.graph.setYMinMax$D$D(min, max);
this.reset();
});

Clazz.newMeth(C$, 'setYAutoscaleOn', function () {
this.graph.setYManualRange$Z(false);
});

Clazz.newMeth(C$, 'setYAutoscaleOff', function () {
this.graph.setYManualRange$Z(true);
});

Clazz.newMeth(C$, ['setXMinMax$D$D','setXMinMax'], function (min, max) {
this.m_minX=min;
this.m_maxX=max;
this.graph.setXMinMax$D$D(min, max);
});

Clazz.newMeth(C$, ['setCaption$S','setCaption'], function (s) {
this.graph.setCaption$S(s);
});

Clazz.newMeth(C$, ['setXTitle$S','setXTitle'], function (s) {
this.graph.setXTitle$S(s);
});

Clazz.newMeth(C$, ['setYTitle$S','setYTitle'], function (s) {
this.graph.setYTitle$S(s);
});
})();
//Created 2018-07-23 12:59:43 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
