(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['edu.davidson.tools.SUtil','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TransformerCoil", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.position = 0;
this.ratio = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$S$I', function (circuit, v, r, c, t, p) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$S.apply(this, [circuit, r, c, t]);
C$.$init$.apply(this);
this.numberOfNodes = 4;
this.value = v;
this.position = p;
this.ratio = 1;
this.unity = "H";
this.setValueVisible$Z(false);
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$S$I$D', function (circuit, v, r, c, t, p, rat) {
C$.c$$circuitsimulator_Circuit$D$I$I$S$I.apply(this, [circuit, v, r, c, t, p]);
this.ratio = this.position == 1 ? Math.sqrt(this.otherElem.value / this.value) : Math.sqrt(this.value / this.otherElem.value);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.position = 1;
this.ratio = 1;
this.setBounds$I$I$I$I(0, 1, 52, 40);
}, 1);

Clazz.newMeth(C$, 'impedance', function () {
return this.value / this.circuit.dt;
});

Clazz.newMeth(C$, 'differential', function () {
return this.value / this.circuit.dt;
});

Clazz.newMeth(C$, 'impedanceCoupled', function () {
return Math.sqrt(this.value * this.otherElem.value) / this.circuit.dt;
});

Clazz.newMeth(C$, 'differentialCoupled', function () {
return Math.sqrt(this.value * this.otherElem.value) / this.circuit.dt;
});

Clazz.newMeth(C$, 'getStringAdditions', function () {
return ",position=" + this.position + ",l=" + new Double(this.value).toString() + ",ratio=" + new Double(this.ratio).toString() ;
});

Clazz.newMeth(C$, 'set$S', function (list) {
var ret = C$.superclazz.prototype.set$S.apply(this, [list]);
if ((I$[1]||$incl$(1)).parameterExist$S$S(list, "l=")) this.value = (I$[1]||$incl$(1)).getParam$S$S(list, "l=");
this.ratio = this.position == 1 ? Math.sqrt(this.otherElem.value / this.value) : Math.sqrt(this.value / this.otherElem.value);
if ((I$[1]||$incl$(1)).parameterExist$S$S(list, "ratio=")) {
this.ratio = (I$[1]||$incl$(1)).getParam$S$S(list, "ratio=");
this.otherElem.value = this.value * (this.position == 1 ? this.ratio * this.ratio : 1 / (this.ratio * this.ratio));
(this.otherElem).ratio = this.ratio;
}return ret;
});

Clazz.newMeth(C$, 'coupledTo$circuitsimulator_CircuitElement', function (other) {
C$.superclazz.prototype.coupledTo$circuitsimulator_CircuitElement.apply(this, [other]);
this.ratio = this.position == 1 ? Math.sqrt(this.otherElem.value / this.value) : Math.sqrt(this.value / this.otherElem.value);
});

Clazz.newMeth(C$, 'loadImage$java_awt_Graphics', function (g) {
});

Clazz.newMeth(C$, 'showValue$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color((I$[2]||$incl$(2)).blue);
if (this.to.equals$O("h")) g.drawString$S$I$I(this.valueStr(), this.$x + (this.circuit.interGrid/2|0) - 17, this.$y + 3);
 else g.drawString$S$I$I(this.valueStr(), this.$x - 7, this.$y + (this.circuit.interGrid/2|0) - 1);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
g.setColor$java_awt_Color((I$[2]||$incl$(2)).red);
var q = (this.position == 1) ? 0 : 90;
var r = (this.position == 1) ? -1 : 1;
var p = (this.position == 1) ? (this.circuit.interGrid/2|0) - 4 : 4 - (this.circuit.interGrid/2|0);
var xcig = this.$x + (this.circuit.interGrid/2|0);
var ycig = this.$y + (this.circuit.interGrid/2|0);
var xs = (this.position == 1) ? this.$x + (this.circuit.interGrid/2|0) - 20 : this.$x - (this.circuit.interGrid/2|0) + 10;
var ys = (this.position == 1) ? this.$y + (this.circuit.interGrid/2|0) - 20 : this.$y - (this.circuit.interGrid/2|0) + 10;
if (this.canvasElement) {
if (this.to.equals$O("h")) {
g.drawLine$I$I$I$I(this.$x, this.$y - 3 * r, this.$x, ys + 5);
g.drawLine$I$I$I$I(this.$x, ys + 5, xcig - 23, ys + 5);
g.drawArc$I$I$I$I$I$I(xcig - 23, ys, 10, 10, 180, -225 * r);
g.drawArc$I$I$I$I$I$I(xcig - 16, ys, 10, 10, 135 + q, -270 * r);
g.drawArc$I$I$I$I$I$I(xcig - 9, ys, 10, 10, 135 + q, -270 * r);
g.drawArc$I$I$I$I$I$I(xcig - 2, ys, 10, 10, 135 + q, -270 * r);
g.drawArc$I$I$I$I$I$I(xcig + 5, ys, 10, 10, 135 + q, -270 * r);
g.drawArc$I$I$I$I$I$I(xcig + 12, ys, 10, 10, 135 + q, -225 * r);
g.drawLine$I$I$I$I(xcig + 23, ys + 5, this.$x + this.circuit.interGrid, ys + 5);
g.drawLine$I$I$I$I(this.$x + this.circuit.interGrid, this.$y - 3 * r, this.$x + this.circuit.interGrid, ys + 5);
g.drawLine$I$I$I$I(xcig - 20, this.$y + p, xcig + 20, this.$y + p);
} else {
g.drawLine$I$I$I$I(this.$x - 3 * r, this.$y, xs + 5, this.$y);
g.drawLine$I$I$I$I(xs + 5, this.$y, xs + 5, ycig - 23);
g.drawArc$I$I$I$I$I$I(xs, ycig - 23, 10, 10, 90, 225 * r);
g.drawArc$I$I$I$I$I$I(xs, ycig - 16, 10, 10, 135 - q, 270 * r);
g.drawArc$I$I$I$I$I$I(xs, ycig - 9, 10, 10, 135 - q, 270 * r);
g.drawArc$I$I$I$I$I$I(xs, ycig - 2, 10, 10, 135 - q, 270 * r);
g.drawArc$I$I$I$I$I$I(xs, ycig + 5, 10, 10, 135 - q, 270 * r);
g.drawArc$I$I$I$I$I$I(xs, ycig + 12, 10, 10, 135 - q, 225 * r);
g.drawLine$I$I$I$I(xs + 5, ycig + 23, xs + 5, this.$y + this.circuit.interGrid);
g.drawLine$I$I$I$I(this.$x - 3 * r, this.$y + this.circuit.interGrid, xs + 5, this.$y + this.circuit.interGrid);
g.drawLine$I$I$I$I(this.$x + p, ycig - 20, this.$x + p, ycig + 20);
}return;
} else {
g.drawLine$I$I$I$I(2, 5, 4, 5);
g.drawArc$I$I$I$I$I$I(4, 0, 10, 10, 180, 225);
g.drawArc$I$I$I$I$I$I(11, 0, 10, 10, 135, 270);
g.drawArc$I$I$I$I$I$I(18, 0, 10, 10, 135, 270);
g.drawArc$I$I$I$I$I$I(25, 0, 10, 10, 135, 270);
g.drawArc$I$I$I$I$I$I(32, 0, 10, 10, 135, 270);
g.drawArc$I$I$I$I$I$I(39, 0, 10, 10, 135, 225);
g.drawLine$I$I$I$I(50, 5, 52, 5);
g.drawLine$I$I$I$I(4, 15, 48, 15);
g.drawLine$I$I$I$I(4, 20, 48, 20);
g.drawLine$I$I$I$I(2, 30, 4, 30);
g.drawArc$I$I$I$I$I$I(4, 25, 10, 10, 180, -225);
g.drawArc$I$I$I$I$I$I(11, 25, 10, 10, 225, -270);
g.drawArc$I$I$I$I$I$I(18, 25, 10, 10, 225, -270);
g.drawArc$I$I$I$I$I$I(25, 25, 10, 10, 225, -270);
g.drawArc$I$I$I$I$I$I(32, 25, 10, 10, 225, -270);
g.drawArc$I$I$I$I$I$I(39, 25, 10, 10, 225, -225);
g.drawLine$I$I$I$I(50, 30, 52, 30);
}});
})();
//Created 2018-02-06 06:55:34
