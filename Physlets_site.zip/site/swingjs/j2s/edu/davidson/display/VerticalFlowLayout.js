(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['java.awt.Dimension']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VerticalFlowLayout", null, 'java.awt.FlowLayout', 'java.io.Serializable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$hgap = 0;
this.$vgap = 0;
this.hfill = false;
this.vfill = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$I$I$I$Z$Z.apply(this, [0, 5, 5, true, false]);
}, 1);

Clazz.newMeth(C$, 'c$$Z$Z', function (hfill, vfill) {
C$.c$$I$I$I$Z$Z.apply(this, [0, 5, 5, hfill, vfill]);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (align) {
C$.c$$I$I$I$Z$Z.apply(this, [align, 5, 5, true, false]);
}, 1);

Clazz.newMeth(C$, 'c$$I$Z$Z', function (align, hfill, vfill) {
C$.c$$I$I$I$Z$Z.apply(this, [align, 5, 5, hfill, vfill]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$Z$Z', function (align, hgap, vgap, hfill, vfill) {
Clazz.super_(C$, this,1);
this.setAlignment$I(align);
this.$hgap = hgap;
this.$vgap = vgap;
this.hfill = hfill;
this.vfill = vfill;
}, 1);

Clazz.newMeth(C$, 'getHgap', function () {
return this.$hgap;
});

Clazz.newMeth(C$, 'setHgap$I', function (hgap) {
C$.superclazz.prototype.setHgap$I.apply(this, [hgap]);
this.$hgap = hgap;
});

Clazz.newMeth(C$, 'getVgap', function () {
return this.$vgap;
});

Clazz.newMeth(C$, 'setVgap$I', function (vgap) {
C$.superclazz.prototype.setVgap$I.apply(this, [vgap]);
this.$vgap = vgap;
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
var tarsiz = Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[0, 0]);
for (var i = 0; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
tarsiz.width = Math.max(tarsiz.width, d.width);
if (i > 0) {
tarsiz.height = tarsiz.height+(this.$vgap);
}tarsiz.height = tarsiz.height+(d.height);
}}
var insets = target.getInsets();
tarsiz.width = tarsiz.width+(insets.left + insets.right + this.$hgap * 2 );
tarsiz.height = tarsiz.height+(insets.top + insets.bottom + this.$vgap * 2 );
return tarsiz;
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
var tarsiz = Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[0, 0]);
for (var i = 0; i < target.getComponentCount(); i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getMinimumSize();
tarsiz.width = Math.max(tarsiz.width, d.width);
if (i > 0) {
tarsiz.height = tarsiz.height+(this.$vgap);
}tarsiz.height = tarsiz.height+(d.height);
}}
var insets = target.getInsets();
tarsiz.width = tarsiz.width+(insets.left + insets.right + this.$hgap * 2 );
tarsiz.height = tarsiz.height+(insets.top + insets.bottom + this.$vgap * 2 );
return tarsiz;
});

Clazz.newMeth(C$, 'setVerticalFill$Z', function (vfill) {
this.vfill = vfill;
});

Clazz.newMeth(C$, 'getVerticalFill', function () {
return this.vfill;
});

Clazz.newMeth(C$, 'setHorizontalFill$Z', function (hfill) {
this.hfill = hfill;
});

Clazz.newMeth(C$, 'getHorizontalFill', function () {
return this.hfill;
});

Clazz.newMeth(C$, 'placethem$java_awt_Container$I$I$I$I$I$I', function (target, x, y, width, height, first, last) {
var align = this.getAlignment();
if (align == 1) y = y+((height/2|0));
if (align == 2) y = y+(height);
for (var i = first; i < last; i++) {
var m = target.getComponent$I(i);
var md = m.getSize();
if (m.isVisible()) {
var px = x + ((width - md.width)/2|0);
m.setLocation$I$I(px, y);
y = y+(this.$vgap + md.height);
}}
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var insets = target.getInsets();
var maxheight = target.getSize().height - (insets.top + insets.bottom + this.$vgap * 2 );
var maxwidth = target.getSize().width - (insets.left + insets.right + this.$hgap * 2 );
var numcomp = target.getComponentCount();
var x = insets.left + this.$hgap;
var y = 0;
var colw = 0;
var start = 0;
for (var i = 0; i < numcomp; i++) {
var m = target.getComponent$I(i);
if (m.isVisible()) {
var d = m.getPreferredSize();
if ((this.vfill) && (i == (numcomp - 1)) ) {
d.height = Math.max((maxheight - y), m.getPreferredSize().height);
}if (this.hfill) {
m.setSize$I$I(maxwidth, d.height);
d.width = maxwidth;
} else {
m.setSize$I$I(d.width, d.height);
}if (y + d.height > maxheight) {
p$.placethem$java_awt_Container$I$I$I$I$I$I.apply(this, [target, x, insets.top + this.$vgap, colw, maxheight - y, start, i]);
y = d.height;
x = x+(this.$hgap + colw);
colw = d.width;
start = i;
} else {
if (y > 0) y = y+(this.$vgap);
y = y+(d.height);
colw = Math.max(colw, d.width);
}}}
p$.placethem$java_awt_Container$I$I$I$I$I$I.apply(this, [target, x, insets.top + this.$vgap, colw, maxheight - y, start, numcomp]);
});
})();
//Created 2018-03-17 21:37:10
