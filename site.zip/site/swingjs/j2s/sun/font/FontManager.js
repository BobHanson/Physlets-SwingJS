(function(){var P$=Clazz.newPackage("sun.font"),I$=[];
var C$=Clazz.newInterface(P$, "FontManager");
})();
//Created 2018-05-24 08:47:30
