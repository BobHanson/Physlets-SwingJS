(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'edu.davidson.tools.SwingJSUtils','java.util.Vector','symantec.itools.awt.BorderPanel','circuitsimulator.BuilderPanel','java.awt.Color',['circuitsimulator.CircuitBuilder','.SymMouse'],'circuitsimulator.PopupOnElement','javax.swing.Timer','circuitsimulator.Circuit','Thread','java.awt.Cursor','java.awt.Point','edu.davidson.tools.SUtil','java.net.URL','java.io.BufferedReader','java.io.InputStreamReader']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "CircuitBuilder", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'circuitsimulator.Circuit');
C$.dim=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.dim=$I$(1).setDim$I$I(514, 445);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.borderPanel=null;
this.builderPanel=null;
this.popupOnElement=null;
this.currentElement=null;
this.scopeList=null;
this.meterList=null;
this.graphList=null;
this.componentList=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.currentElement=null;
this.scopeList=Clazz.new_($I$(2));
this.meterList=Clazz.new_($I$(2));
this.graphList=Clazz.new_($I$(2));
this.componentList="";
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
C$.superclazz.prototype.init$.apply(this, []);
if (C$.dim != null ) this.setSize$java_awt_Dimension(C$.dim);
this.borderPanel=Clazz.new_($I$(3));
this.builderPanel=Clazz.new_($I$(4).c$$circuitsimulator_Circuit,[this]);
this.setLayout$java_awt_LayoutManager(null);
this.setBackground$java_awt_Color(Clazz.new_($I$(5).c$$I$I$I,[0, 143, 213]));
try {
this.borderPanel.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setIPadBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setIPadSides$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setIPadTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.borderPanel.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.borderPanel);
this.borderPanel.setBounds$I$I$I$I(0, 0, 514, 444);
try {
this.builderPanel.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setBevelStyle$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.builderPanel.setLayout$java_awt_LayoutManager(null);
this.builderPanel.setBackground$java_awt_Color(Clazz.new_($I$(5).c$$I$I$I,[0, 143, 213]));
this.builderPanel.setBounds$I$I$I$I(313, 17, 195, 401);
this.borderPanel.add$java_awt_Component(this.builderPanel);
var aSymMouse=Clazz.new_($I$(6), [this, null]);
this.circanvas.addMouseListener$java_awt_event_MouseListener(aSymMouse);
});

Clazz.newMeth(C$, ['start$','start'], function () {
C$.superclazz.prototype.start$.apply(this, []);
this.gridZone=this.getSize$();
this.gridZone.width=this.builderPanel.getBounds$().x;
this.popupOnElement=Clazz.new_($I$(7).c$$circuitsimulator_CircuitBuilder,[this]);
this.loadList$S("/lists/default.txt");
this.parse$();
this.calculateCircuit$();
});

Clazz.newMeth(C$, ['runTimer$','runTimer'], function () {
this.timer=Clazz.new_($I$(8).c$$I$java_awt_event_ActionListener,[this.sleepTime, ((P$.CircuitBuilder$1||
(function(){var C$=Clazz.newClass(P$, "CircuitBuilder$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (e) {
for (var enu=this.b$['circuitsimulator.CircuitBuilder'].meterList.elements$(); enu.hasMoreElements$(); ) {
var meter=enu.nextElement$();
meter.recalc$();
}
this.b$['circuitsimulator.CircuitBuilder'].circanvas.repaint$();
if (this.b$['circuitsimulator.CircuitBuilder'].runner != null ) this.b$['circuitsimulator.CircuitBuilder'].runTimer$.apply(this.b$['circuitsimulator.CircuitBuilder'], []);
});
})()
), Clazz.new_(P$.CircuitBuilder$1.$init$, [this, null]))]);
this.timer.setRepeats$Z(false);
this.timer.start$();
});

Clazz.newMeth(C$, ['run$','run'], function () {
if ($I$(9).isJS) {
System.err.println$S("Error.  Thread should not start when using JavaScript.");
return;
}while (this.runner === $I$(10).currentThread$() ){
if (this.parsed) {
this.circanvas.repaint$();
}for (var enu=this.meterList.elements$(); enu.hasMoreElements$(); ) {
var meter=enu.nextElement$();
meter.recalc$();
}
try {
$I$(10).sleep$J(100);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'circanvas_MousePressed$java_awt_event_MouseEvent', function (event) {
this.currentElement=this.getComponent$S(this.coordString$java_awt_Point$Z(event.getPoint$(), false));
if (!!((event.isMetaDown$() == true ) | (event.isControlDown$() == true ))) {
this.popupOnElement.selectItems$();
this.add$java_awt_PopupMenu(this.popupOnElement);
this.popupOnElement.show$java_awt_Component$I$I(event.getComponent$(), event.getX$(), event.getY$());
} else {
this.circanvas.setCursor$java_awt_Cursor($I$(11).getPredefinedCursor$I(12));
}if ((this.debugLevel & $I$(9).DEBUG_IO) > 0) {
System.out.println$S(this.currentElement.getMyName$());
}});

Clazz.newMeth(C$, 'circanvas_mouseReleased$java_awt_event_MouseEvent', function (event) {
if (!!((event.isMetaDown$() == false ) & (event.isControlDown$() == false ))) {
this.moveComponent$circuitsimulator_CircuitElement$S(this.currentElement, this.coordString$java_awt_Point$Z(event.getPoint$(), false));
this.circanvas.setCursor$java_awt_Cursor($I$(11).getDefaultCursor$());
this.parse$();
this.repaintMeters$();
}});

Clazz.newMeth(C$, ['step$D$D','step','step$'], function (dt, time) {
C$.superclazz.prototype.step$D$D.apply(this, [dt, time]);
if ((this.parsed) && !this.graphList.isEmpty$() ) {
for (var e=this.graphList.elements$(); e.hasMoreElements$(); ) {
var graph=e.nextElement$();
graph.addData$();
}
}});

Clazz.newMeth(C$, ['reset$','reset'], function () {
C$.superclazz.prototype.reset$.apply(this, []);
if ((this.parsed) && !this.graphList.isEmpty$() ) {
for (var e=this.graphList.elements$(); e.hasMoreElements$(); ) {
var graph=e.nextElement$();
graph.clearGraph$();
}
}});

Clazz.newMeth(C$, ['coordString$java_awt_Point$Z','coordString'], function (absCoords, absolute) {
var circanvasP=Clazz.new_($I$(12).c$$I$I,[0, 0]);
if (absolute) {
circanvasP.setLocation$java_awt_Point(this.circanvas.getLocation$());
}var posString="row=";
var diffx;
var diffy;
var x;
var y;
var row=-1;
var col=-1;
x=absCoords.x - circanvasP.x;
y=absCoords.y - circanvasP.y;
do {
col++;
diffx=(this.interGrid/2|0) + this.interGrid * col - x;
} while (diffx < 0);
do {
row++;
diffy=(this.interGrid/2|0) + this.interGrid * row - y;
} while (diffy < 0);
if (!!((diffx >= diffy) & (diffx + diffy >= this.interGrid))) {
posString += Integer.toString$I(row - 1) + ",col=" + Integer.toString$I(col - 1) + ",to=v" ;
} else if (!!((diffx >= diffy) & (diffx + diffy < this.interGrid))) {
posString += Integer.toString$I(row) + ",col=" + Integer.toString$I(col - 1) + ",to=h" ;
} else if (!!((diffx < diffy) & (diffy + diffx >= this.interGrid))) {
posString += Integer.toString$I(row - 1) + ",col=" + Integer.toString$I(col - 1) + ",to=h" ;
} else if (!!((diffx < diffy) & (diffy + diffx < this.interGrid))) {
posString += Integer.toString$I(row - 1) + ",col=" + Integer.toString$I(col) + ",to=v" ;
}if ((this.debugLevel & $I$(9).DEBUG_IO) > 0) {
System.out.println$S(posString);
}return posString;
});

Clazz.newMeth(C$, ['repaintMeters$','repaintMeters'], function () {
if (this.parsed) {
this.calculateCircuit$();
for (var e=this.scopeList.elements$(); e.hasMoreElements$(); ) {
var oscdiag=e.nextElement$();
oscdiag.scopeCanvas.repaint$();
}
for (var e=this.meterList.elements$(); e.hasMoreElements$(); ) {
var meter=e.nextElement$();
meter.recalc$();
}
}});

Clazz.newMeth(C$, ['parseCommand$S','parseCommand'], function (s) {
s="" + $I$(13).removeWhitespace$S(s);
if ($I$(13).parameterExist$S$S(s, "setGrid")) {
var parameters= String.instantialize(s.substring$I$I(9, s.length$() - 3));
var rows=($I$(13).getParam$S$S(parameters, "rows=")|0);
var cols=($I$(13).getParam$S$S(parameters, "cols=")|0);
this.setGrid$I$I(rows, cols);
} else if ($I$(13).parameterExist$S$S(s, "setNumberOfDT")) {
var par=Integer.parseInt$S(s.substring$I$I(s.indexOf$S("(") + 1, s.indexOf$S(")")));
this.setNumberOfDT$I(par);
} else if ($I$(13).parameterExist$S$S(s, "setDT")) {
var par=(Double.valueOf$S(s.substring$I$I(s.indexOf$S("(") + 1, s.indexOf$S(")")))).doubleValue$();
this.setDT$D(par);
} else if ($I$(13).parameterExist$S$S(s, "setNOC")) {
var par=Integer.parseInt$S(s.substring$I$I(s.indexOf$S("(") + 1, s.indexOf$S(")")));
this.setNOC$I(par);
} else if ($I$(13).parameterExist$S$S(s, "setFPS")) {
var par=(Double.valueOf$S(s.substring$I$I(s.indexOf$S("(") + 1, s.indexOf$S(")")))).doubleValue$();
this.setFPS$D(par);
} else if ($I$(13).parameterExist$S$S(s, "addObject")) {
var name= String.instantialize(s.substring$I$I(s.indexOf$S("(\"") + 2, s.indexOf$S("\",")));
var list= String.instantialize(s.substring$I$I(s.indexOf$S(",\"") + 2, s.indexOf$S("\")")));
this.addObject$S$S(name, list);
}});

Clazz.newMeth(C$, 'loadList$S', function (inputfile) {
var trydoc=false;
try {
if ($I$(9).DEBUG) {
System.out.println$S("loading from codebase:" + this.getCodeBase$().getPath$() + inputfile );
}var url=Clazz.new_($I$(14).c$$S,[this.getCodeBase$() + inputfile]);
var $in=url.openStream$();
var br=Clazz.new_($I$(15).c$$java_io_Reader,[Clazz.new_($I$(16).c$$java_io_InputStream,[$in])]);
var line;
while ((line=br.readLine$()) != null ){
this.parseCommand$S(line);
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
trydoc=true;
if ($I$(9).DEBUG) {
System.out.println$S("load failed from docbase: " + e.getMessage$());
}} else {
throw e;
}
}
if (trydoc) {
try {
var url=Clazz.new_($I$(14).c$$S,[this.getDocumentPath$() + inputfile]);
var $in=url.openStream$();
var br=Clazz.new_($I$(15).c$$java_io_Reader,[Clazz.new_($I$(16).c$$java_io_InputStream,[$in])]);
var line;
while ((line=br.readLine$()) != null ){
this.parseCommand$S(line);
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("load failed: " + e.getMessage$());
this.setGrid$S("rows=8,cols=5");
} else {
throw e;
}
}
}});
;
(function(){var C$=Clazz.newClass(P$.CircuitBuilder, "SymMouse", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.MouseAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0.circanvas ) {
this.this$0.circanvas_mouseReleased$java_awt_event_MouseEvent.apply(this.this$0, [event]);
}});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0.circanvas ) {
this.this$0.circanvas_MousePressed$java_awt_event_MouseEvent.apply(this.this$0, [event]);
}});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:48 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
