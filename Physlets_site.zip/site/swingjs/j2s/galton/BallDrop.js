(function(){var P$=Clazz.newPackage("galton"),I$=[['edu.davidson.graphics.Util','Boolean','galton.Ball','java.util.Vector','java.lang.Thread','Thread','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "BallDrop", null, 'edu.davidson.tools.SApplet', ['Runnable', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.ds = null;
this.time = 0;
this.totalBalls = 0;
this.itsThread = null;
this.itsBalls = null;
this.mean = 0;
this.stdev = 0;
this.showFunc = false;
this.countBalls = 0;
this.maxBalls = 0;
this.preLab = false;
this.trueMean = 0;
this.$firstTime = false;
this.offDimension = null;
this.backDimension = null;
this.offImage = null;
this.backImage = null;
this.numrows = 0;
this.numcolumns = 0;
this.numballs = 0;
this.delay = 0;
this.topspace = 0;
this.sidespace = 0;
this.pin = null;
this.ball = null;
this.pinr = 0;
this.ballw = 0;
this.ballh = 0;
this.pinw = 0;
this.pinh = 0;
this.numracks = 0;
this.rackheight = 0;
this.rackdel = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "mean", "std", "n"]);
this.ds = Clazz.array(Double.TYPE, [1, 4]);
this.time = 0;
this.totalBalls = 0;
this.itsThread = null;
this.itsBalls = null;
this.mean = 0;
this.stdev = 0;
this.showFunc = true;
this.maxBalls = 400;
this.preLab = false;
this.trueMean = 0.0;
this.$firstTime = true;
this.numrows = 8;
this.numcolumns = 20;
this.numballs = 10;
this.delay = 10;
this.topspace = 30;
this.sidespace = 20;
}, 1);

Clazz.newMeth(C$, 'init', function () {
var param = null;
param = this.getParameter$S("BallImage");
if (param == null ) param = "galtonimages/smallball.gif";
this.ball = (I$[1]||$incl$(1)).getImage$S$a2s_Applet(param, this);
param = this.getParameter$S("PinImage");
if (param == null ) param = "galtonimages/smallpin.gif";
this.pin = (I$[1]||$incl$(1)).getImage$S$a2s_Applet(param, this);
param = this.getParameter$S("NumRows");
if (param != null ) this.numrows = Integer.$valueOf(param).intValue();
param = this.getParameter$S("NumColumns");
if (param != null ) this.numcolumns = Integer.$valueOf(param).intValue();
param = this.getParameter$S("NumBalls");
if (param != null ) this.numballs = Integer.$valueOf(param).intValue();
param = this.getParameter$S("Delay");
if (param != null ) this.delay = Integer.$valueOf(param).intValue();
param = this.getParameter$S("TopSpace");
if (param != null ) this.topspace = Integer.$valueOf(param).intValue();
param = this.getParameter$S("SideSpace");
if (param != null ) this.sidespace = Integer.$valueOf(param).intValue();
param = this.getParameter$S("MaxBalls");
if (param != null ) this.maxBalls = Integer.$valueOf(param).intValue();
param = this.getParameter$S("PreLab");
if (param != null ) this.preLab = (I$[2]||$incl$(2)).$valueOf(param).booleanValue();
param = this.getParameter$S("ShowFunc");
if (param != null ) this.showFunc = (I$[2]||$incl$(2)).$valueOf(param).booleanValue();
if (this.pin == null ) System.out.println$S("Pin image not found.");
if (this.ball == null ) System.out.println$S("Ball image not found.");
this.pinw = this.pin.getWidth$java_awt_image_ImageObserver(this);
this.pinh = this.pin.getHeight$java_awt_image_ImageObserver(this);
this.pinr = this.pinw / 2.0;
this.ballw = this.ball.getWidth$java_awt_image_ImageObserver(this);
this.ballh = this.ball.getHeight$java_awt_image_ImageObserver(this);
edu.davidson.tools.SApplet.addDataSource$O(this);
});

Clazz.newMeth(C$, 'reset', function () {
p$.resetBoard.apply(this, []);
});

Clazz.newMeth(C$, 'setDefault', function () {
C$.superclazz.prototype.setDefault.apply(this, []);
p$.resetBoard.apply(this, []);
});

Clazz.newMeth(C$, 'resetBoard', function () {
this.stop();
this.trueMean = 0.0;
var i;
var aBall;
var d = this.getSize();
for (i = 0; i < this.numracks; ++i) {
this.rackheight[i] = 0;
this.rackdel[i] = 0;
}
this.itsBalls.removeAllElements();
this.countBalls = this.maxBalls;
for (i = 0; i < this.numballs; ++i) {
aBall = Clazz.new_((I$[3]||$incl$(3)).c$$D$D,[(d.width/2|0), 0]);
this.countBalls--;
aBall.Accelerate$D$D((Math.random() - 0.5) * 0.5, 0);
aBall.SetImage$java_awt_Image(this.ball);
this.itsBalls.addElement$TE(aBall);
}
this.mean = 0;
this.stdev = 0;
this.time = 0;
this.totalBalls = 0;
this.clearAllData();
this.repaint();
this.start();
});

Clazz.newMeth(C$, 'forward', function () {
this.start();
});

Clazz.newMeth(C$, 'pause', function () {
this.stop();
});

Clazz.newMeth(C$, 'pausingClock', function () {
this.pause();
});

Clazz.newMeth(C$, 'start', function () {
if (this.$firstTime) {
this.$firstTime = false;
var d = this.getSize();
var aBall;
this.numracks = (this.getSize().width/this.ballw|0);
System.out.println$S("ball=" + this.ballw);
System.out.println$S("numracks=" + this.numracks);
this.rackheight = Clazz.array(Integer.TYPE, [this.numracks]);
this.rackdel = Clazz.array(Integer.TYPE, [this.numracks]);
for (var i = 0; i < this.numracks; ++i) {
this.rackheight[i] = 0;
this.rackdel[i] = 0;
}
this.itsBalls = Clazz.new_((I$[4]||$incl$(4)));
this.countBalls = this.maxBalls;
for (var i = 0; i < this.numballs; ++i) {
aBall = Clazz.new_((I$[3]||$incl$(3)).c$$D$D,[(d.width/2|0), 0]);
this.countBalls--;
aBall.Accelerate$D$D((Math.random() - 0.5) * 0.5, 0);
aBall.SetImage$java_awt_Image(this.ball);
this.itsBalls.addElement$TE(aBall);
}
}if (this.itsThread == null ) {
this.setRunningID$O(this);
this.itsThread = Clazz.new_((I$[5]||$incl$(5)).c$$Runnable,[this]);
this.itsThread.start();
}});

Clazz.newMeth(C$, 'stop', function () {
var myThread = this.itsThread;
this.itsThread = null;
if (myThread == null ) return;
try {
myThread.join();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
this.offImage = null;
this.backImage = null;
});

Clazz.newMeth(C$, ['mouseDown$java_awt_Event$I$I','mouseDown'], function (e, x, y) {
if (this.itsThread == null ) {
this.start();
} else {
var myThread = this.itsThread;
this.itsThread = null;
if (myThread != null ) try {
myThread.join();
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.InterruptedException")){
} else {
throw ex;
}
}
}return false;
});

Clazz.newMeth(C$, 'destroy', function () {
var myThread = this.itsThread;
this.itsThread = null;
if (myThread != null ) try {
myThread.join();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'run', function () {
var startTime = System.currentTimeMillis();
while ((I$[6]||$incl$(6)).currentThread() === this.itsThread  && this.getRunningID() === this  ){
this.UpdateBalls();
this.repaint();
this.time += this.delay / 1000.0;
try {
startTime = startTime+(this.delay);
(I$[6]||$incl$(6)).sleep$J(Math.max(10, startTime - System.currentTimeMillis()));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
break;
} else {
throw e;
}
}
startTime = System.currentTimeMillis();
}
this.itsThread = null;
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
var offGraphics;
var aBall;
var d = this.getSize();
if ((this.backImage == null ) || (d.width != this.backDimension.width) || (d.height != this.backDimension.height)  ) {
var backGraphics;
this.backDimension = d;
this.backImage = this.createImage$I$I(d.width, d.height);
backGraphics = this.backImage.getGraphics();
backGraphics.setColor$java_awt_Color(this.getBackground());
backGraphics.fillRect$I$I$I$I(0, 0, d.width, d.height);
backGraphics.setColor$java_awt_Color((I$[7]||$incl$(7)).black);
this.paintBackground$java_awt_Graphics(backGraphics);
} else {
this.updateRack$java_awt_Graphics(this.backImage.getGraphics());
}if ((this.offImage == null ) || (d.width != this.offDimension.width) || (d.height != this.offDimension.height)  ) {
this.offDimension = d;
this.offImage = this.createImage$I$I(d.width, d.height);
}offGraphics = this.offImage.getGraphics();
offGraphics.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.backImage, 0, 0, this);
for (var e = this.itsBalls.elements(); e.hasMoreElements(); ) {
aBall = e.nextElement();
aBall.Draw$java_awt_Graphics(offGraphics);
}
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.offImage, 0, 0, this);
});

Clazz.newMeth(C$, ['update$java_awt_Graphics','update'], function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintBackground$java_awt_Graphics', function (g) {
var d = this.getSize();
var i;
var j;
var pinx;
var piny;
var scale;
var x;
var y;
var oy;
for (i = 0; i < this.numrows; ++i) {
piny = (i * (d.height - 2 * this.topspace)/(this.numrows * 2)|0) + this.topspace;
scale = (d.width - 2 * this.sidespace) / this.numcolumns;
for (j = 0; j < this.numcolumns; ++j) {
pinx = (((j + (i % 2) / 2.0) * scale)|0) + this.sidespace;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.pin, pinx - (this.pinw/2|0), piny - (this.pinh/2|0), this);
}
}
scale = d.width / this.numracks;
g.setColor$java_awt_Color((I$[7]||$incl$(7)).black);
oy = 0;
if (this.showFunc) for (i = 0; i <= this.numracks; ++i) {
x = (this.numracks/2|0);
y = d.height * (1.0 - 0.5 * Math.exp(-(i - x) * (i - x) / 162));
if (i > 0) g.drawLine$I$I$I$I((((i - 1) * scale)|0), (oy|0), ((i * scale)|0), (y|0));
oy = y;
}
for (i = 0; i < this.numracks; ++i) {
for (j = 0; j < this.rackheight[i]; ++j) {
pinx = i * this.ballw;
piny = d.height - (j + 1) * this.ballh;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.ball, pinx, piny, this);
}
}
});

Clazz.newMeth(C$, 'updateRack$java_awt_Graphics', function (g) {
var i;
var pinx;
var piny;
var offset;
var d = this.getSize();
var sumr;
var sumrr;
var num;
sumr = 0;
sumrr = 0;
num = 0;
offset = (this.numracks - 1.0) / 2.0;
for (i = 0; i < this.numracks; ++i) {
while (this.rackdel[i] > 0){
++this.rackheight[i];
pinx = i * this.ballw;
piny = d.height - this.rackheight[i] * this.ballh;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.ball, pinx, piny, this);
--this.rackdel[i];
}
num = num+(this.rackheight[i]);
sumr += this.rackheight[i] * (i - offset);
sumrr += this.rackheight[i] * (i - offset) * (i - offset) ;
}
if (num > 0) {
this.totalBalls = num;
this.mean = sumr / num;
if (this.preLab) this.trueMean = 6.5;
this.stdev = Math.sqrt(sumrr / num - this.mean * this.mean);
this.updateDataConnections();
}});

Clazz.newMeth(C$, ['setShowFunc$Z','setShowFunc'], function (value) {
if (this.showFunc != value ) {
this.backImage = null;
this.showFunc = value;
this.repaint();
}});

Clazz.newMeth(C$, 'getMean', function () {
if (this.preLab) return this.mean + this.trueMean;
 else return this.mean;
});

Clazz.newMeth(C$, 'getStDev', function () {
return this.stdev;
});

Clazz.newMeth(C$, 'UpdateBalls', function () {
var i;
var j;
var k;
var pinx;
var piny;
var rack;
var bottomy;
var fr;
var lr;
var fc;
var lc;
var scale;
var aBall;
var d = this.getSize();
bottomy = d.height;
for (var e = this.itsBalls.elements(); e.hasMoreElements(); ) {
aBall = e.nextElement();
aBall.Move();
if (aBall.y > bottomy - aBall.r ) {
if (aBall.vlen > 0.25 ) {
aBall.vx = 0;
aBall.vy = -aBall.vy * 0.25;
aBall.y = bottomy - aBall.r;
} else {
rack = ((aBall.x / this.ballw)|0);
if (rack >= 0 && rack < this.numracks ) {
++this.rackdel[rack];
}aBall.x = (d.width/2|0);
aBall.y = aBall.r;
aBall.vx = (Math.random() - 0.5) / 3;
aBall.vy = 0;
this.countBalls--;
if (this.countBalls < 0) this.itsBalls.removeElement$O(aBall);
}} else {
k = (((aBall.y - this.topspace) * 2 * this.numrows  / (d.height - 2 * this.topspace))|0);
fr = k <= 0 ? 0 : k - 1;
lr = k >= this.numrows - 1 ? this.numrows - 1 : k + 1;
for (i = fr; i <= lr; ++i) {
piny = (i * (d.height - 2 * this.topspace)/(2 * this.numrows)|0) + this.topspace;
scale = (d.width - 2 * this.sidespace) / this.numcolumns;
k = (((aBall.x - this.sidespace) / scale - (i % 2) / 2.0)|0);
fc = k <= 0 ? 0 : k - 1;
lc = k >= this.numcolumns - 1 ? this.numcolumns - 1 : k + 1;
for (j = fc; j <= lc; ++j) {
pinx = (((j + (i % 2) / 2.0) * scale + this.sidespace)|0);
aBall.Boink$I$I$D(pinx, piny, this.pinr);
}
}
}aBall.Accelerate$D$D(0, 0.075);
}
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.time;
if (this.preLab) this.ds[0][1] = this.mean + this.trueMean;
 else this.ds[0][1] = this.mean;
this.ds[0][2] = this.stdev;
this.ds[0][3] = this.totalBalls;
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:18
