(function(){var P$=Clazz.newPackage("sun.awt.datatransfer"),I$=[];
var C$=Clazz.newInterface(P$, "ToolkitThreadBlockedHandler");
})();
//Created 2018-05-24 08:47:24
