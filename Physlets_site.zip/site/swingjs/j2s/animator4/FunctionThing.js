(function(){var P$=Clazz.newPackage("animator4"),I$=[['edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FunctionThing", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$xStr = null;
this.$yStr = null;
this.$xFunc = null;
this.$yFunc = null;
this.num = 0;
this.start = 0;
this.stop = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.num = 10;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$D$D$S$S', function (o, n, start_, stop_, xStr_, yStr_) {
C$.superclazz.c$$animator4_AnimatorCanvas.apply(this, [o]);
C$.$init$.apply(this);
this.start = start_;
this.stop = stop_;
this.num = n;
this.$xStr = xStr_;
this.$yStr = yStr_;
this.$xFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[2]);
this.$xFunc.defineVariable$I$S(1, "s");
this.$xFunc.defineVariable$I$S(2, "t");
this.$xFunc.define$S(this.$xStr);
this.$xFunc.parse();
if (this.$xFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse x(s,t): " + this.$xStr);
System.out.println$S("Parse error: " + this.$xFunc.getErrorString() + " at function x, position " + this.$xFunc.getErrorPosition() );
}this.$yFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[2]);
this.$yFunc.defineVariable$I$S(1, "s");
this.$yFunc.defineVariable$I$S(2, "t");
this.$yFunc.define$S(this.$yStr);
this.$yFunc.parse();
if (this.$yFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse y(s,t): " + this.$yStr);
System.out.println$S("Parse error: " + this.$yFunc.getErrorString() + " at function y, position " + this.$yFunc.getErrorPosition() );
}}, 1);

Clazz.newMeth(C$, 'getX$D$D', function (s, t) {
var x = 0;
try {
x = this.$xFunc.evaluate$D$D(s, t);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return x;
});

Clazz.newMeth(C$, 'getY$D$D', function (s, t) {
var y = 0;
try {
y = this.$yFunc.evaluate$D$D(s, t);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return y;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
g.setColor$java_awt_Color(this.color);
var s = this.start;
var ptX0 = Math.round(this.canvas.pixFromX$D(this.getX$D$D(this.start, this.canvas.time))) + this.xDisplayOff;
var ptY0 = Math.round(this.canvas.pixFromY$D(this.getY$D$D(this.start, this.canvas.time))) - this.yDisplayOff;
var ds = (this.stop - this.start) / (this.num - 1);
for (var j = 0; j < this.num; j++) {
var ptX1 = Math.round(this.canvas.pixFromX$D(this.getX$D$D(s, this.canvas.time))) + this.xDisplayOff;
var ptY1 = Math.round(this.canvas.pixFromY$D(this.getY$D$D(s, this.canvas.time))) - this.yDisplayOff;
g.drawLine$I$I$I$I(ptX0, ptY0, ptX1, ptY1);
ptX0 = ptX1;
ptY0 = ptY1;
s = s + ds;
}
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:20:58
