(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[[0,'edu.davidson.graphics.HintPanel','edu.davidson.graphics.Border','edu.davidson.graphics.ThreeDRectangle']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ThreeDBorder", null, 'edu.davidson.graphics.Border');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$java_awt_Component.apply(this, [Clazz.new_(Clazz.load('edu.davidson.graphics.HintPanel'))]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component', function (borderMe) {
C$.c$$java_awt_Component$I$I.apply(this, [borderMe, Clazz.load('edu.davidson.graphics.Border')._defaultThickness, $I$(2)._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I', function (borderMe, borderThickness) {
C$.c$$java_awt_Component$I$I.apply(this, [borderMe, borderThickness, $I$(2)._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I$I', function (borderMe, borderThickness, gap) {
C$.superclazz.c$$java_awt_Component$I$I.apply(this, [borderMe, borderThickness, gap]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'inset$', function () {
(this.myBorder$()).inset$();
});

Clazz.newMeth(C$, 'raise$', function () {
(this.myBorder$()).raise$();
});

Clazz.newMeth(C$, 'paintRaised$', function () {
(this.myBorder$()).paintRaised$();
});

Clazz.newMeth(C$, 'paintInset$', function () {
(this.myBorder$()).paintInset$();
});

Clazz.newMeth(C$, 'isRaised$', function () {
return (this.myBorder$()).isRaised$();
});

Clazz.newMeth(C$, 'myBorder$', function () {
if (this.border == null ) this.border=Clazz.new_(Clazz.load('edu.davidson.graphics.ThreeDRectangle').c$$java_awt_Component$I,[this, this.thickness]);
return this.border;
});

Clazz.newMeth(C$, 'setRaised$Z', function (r) {
if (r) this.paintRaised$();
 else this.paintInset$();
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:31 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
