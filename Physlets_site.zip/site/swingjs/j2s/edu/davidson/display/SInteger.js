(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['java.awt.Color','java.awt.event.KeyAdapter']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SInteger", null, 'a2s.TextField', 'java.awt.event.TextListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.lastValue = null;
this.lastCaretPosition = 0;
this.noColor = false;
this.val = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.noColor = false;
this.val = 0;
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (defval, size) {
C$.superclazz.c$$S$I.apply(this, ["" + defval, size]);
C$.$init$.apply(this);
this.addTextListener$java_awt_event_TextListener(this);
this.addKeyListener$java_awt_event_KeyListener(((
(function(){var C$=Clazz.newClass(P$, "SInteger$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.KeyAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'keyTyped$java_awt_event_KeyEvent', function (evt) {
var ch = evt.getKeyChar();
if (!("0" <= ch && ch <= "9"  || ch == "-"  || Character.isISOControl(ch) )) evt.consume();
 else {
this.b$['edu.davidson.display.SInteger'].lastCaretPosition = this.b$['edu.davidson.display.SInteger'].getCaretPosition();
if (this.b$['edu.davidson.display.SInteger'].isEditable() && !this.b$['edu.davidson.display.SInteger'].noColor ) this.b$['edu.davidson.display.SInteger'].setBackground$java_awt_Color((I$[1]||$incl$(1)).yellow);
}});
})()
), Clazz.new_((I$[2]||$incl$(2)), [this, null],P$.SInteger$1)));
this.lastValue = "" + defval;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$I$I.apply(this, [0, 3]);
}, 1);

Clazz.newMeth(C$, 'textValueChanged$java_awt_event_TextEvent', function (evt) {
this.checkValue();
});

Clazz.newMeth(C$, 'checkValue', function () {
try {
Integer.parseInt(this.getText().trim() + "0");
this.lastValue = this.getText();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
this.setText$S(this.lastValue);
this.setCaretPosition$I(this.lastCaretPosition);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getValue', function () {
this.checkValue();
return this.getVal();
});

Clazz.newMeth(C$, 'getVal', function () {
try {
this.val = Integer.parseInt(this.getText().trim());
if (this.isEditable() && !this.noColor ) this.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
return this.val;
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
if (!this.noColor) this.setBackground$java_awt_Color((I$[1]||$incl$(1)).red);
return 0;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'setValue$I', function (v) {
this.val = v;
this.setText$S("" + v);
if (!this.noColor) this.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
});

Clazz.newMeth(C$, 'isNoColor', function () {
return this.noColor;
});

Clazz.newMeth(C$, 'setNoColor$Z', function (nc) {
this.noColor = nc;
});
})();
//Created 2018-03-16 05:19:11
