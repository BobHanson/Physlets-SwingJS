(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "Wire", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$S', function (circuit, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$S.apply(this, [circuit, r, c, t]);
C$.$init$.apply(this);
this.setValueVisible$Z(false);
this.maxCurrentValue=100;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'loadImage$java_awt_Graphics', function (g) {
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var cig=(this.circuit != null ) ? this.circuit.interGrid : 27;
g.setColor$java_awt_Color(Clazz.load('java.awt.Color').red);
if (this.to.equals$O("h")) g.drawLine$I$I$I$I(this.$x + 3, this.$y, this.$x + cig - 4, this.$y);
 else g.drawLine$I$I$I$I(this.$x, this.$y + 3, this.$x, this.$y + cig - 4);
});

Clazz.newMeth(C$, 'overload$java_awt_Graphics$I$I', function (g, ix, iy) {
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:16 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
