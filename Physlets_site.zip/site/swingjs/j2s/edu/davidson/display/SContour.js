(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['edu.davidson.display.Format','edu.davidson.graph.TextLine','java.awt.Font','java.awt.Color','java.awt.Rectangle','edu.davidson.graph.IsoCurve','java.util.Vector','edu.davidson.graph.DataSet','edu.davidson.display.SContour_this_mouseMotionAdapter','edu.davidson.display.SContour_this_mouseAdapter','java.awt.Cursor']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SContour", null, 'edu.davidson.display.SGraph');
C$.MINCELLS = 0;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.MINCELLS = 25;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.nx = 0;
this.ny = 0;
this.curves = null;
this.autoLevels = false;
this.logLevels = false;
this.gridLimits = false;
this.levels = null;
this.labels = null;
this.labelfont = null;
this.labelcolor = null;
this.labelStyle = 0;
this.labelPrecision = 0;
this.labelSignificant = 0;
this.labelLevels = 0;
this.drawlabels = false;
this.autoLabels = false;
this.contourColor = null;
this.labelledColor = null;
this.grid = null;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.zmin = 0;
this.zmax = 0;
this.noContours = false;
this.isDrag = false;
this.$format = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.noContours = false;
this.isDrag = false;
this.$format = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+8.5g"]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.grid = null;
this.xmin = -1.0;
this.xmax = 1.0;
this.ymin = -1.0;
this.ymax = 1.0;
this.zmin = 0.0;
this.zmax = 0.0;
this.nx = 0;
this.ny = 0;
this.levels = Clazz.array(Double.TYPE, [12]);
this.labels = Clazz.array((I$[2]||$incl$(2)), [12]);
this.autoLevels = true;
this.logLevels = false;
this.gridLimits = true;
this.autoLabels = true;
this.labelfont = Clazz.new_((I$[3]||$incl$(3)).c$$S$I$I,["Helvetica", 0, 12]);
this.labelcolor = (I$[4]||$incl$(4)).blue;
this.labelLevels = 1;
this.labelStyle = 2;
this.labelPrecision = 2;
this.labelSignificant = 3;
this.drawlabels = true;
this.contourColor = null;
this.labelledColor = null;
this.curves = null;
this.setDataBackground$java_awt_Color(Clazz.new_((I$[4]||$incl$(4)).c$$F$F$F,[0.933, 0.914, 0.749]));
this.setContourColor$java_awt_Color(Clazz.new_((I$[4]||$incl$(4)).c$$F$F$F,[0.18, 0.545, 0.341]));
this.setLabelledContourColor$java_awt_Color(Clazz.new_((I$[4]||$incl$(4)).c$$F$F$F,[0.5, 0.0, 0.0]));
this.setLabelPrecision$I(2);
this.setLabelSignificance$I(2);
this.square = false;
this.setFont$java_awt_Font(Clazz.new_((I$[3]||$incl$(3)).c$$S$I$I,["TimesRoman", 0, 15]));
this.deleteAllSeries();
this.detachAxes();
this.detachDataSets();
this.xaxis = this.createAxis$I(5);
this.xaxis.setTitleText$S("X_axis");
this.xaxis.setTitleColor$java_awt_Color((I$[4]||$incl$(4)).magenta);
this.xaxis.setTitleFont$java_awt_Font(Clazz.new_((I$[3]||$incl$(3)).c$$S$I$I,["TimesRoman", 2, 15]));
this.xaxis.setLabelFont$java_awt_Font(Clazz.new_((I$[3]||$incl$(3)).c$$S$I$I,["Helvetica", 0, 10]));
this.yaxis = this.createAxis$I(2);
this.yaxis.setTitleText$S("Y_axis");
this.yaxis.setTitleColor$java_awt_Color((I$[4]||$incl$(4)).magenta);
this.yaxis.setTitleFont$java_awt_Font(Clazz.new_((I$[3]||$incl$(3)).c$$S$I$I,["TimesRoman", 2, 15]));
this.yaxis.setLabelFont$java_awt_Font(Clazz.new_((I$[3]||$incl$(3)).c$$S$I$I,["Helvetica", 0, 10]));
this.borderLeft = 0;
this.borderTop = 0;
this.borderRight = 0;
this.borderBottom = 0;
this.setShowAxis$Z(true);
this.createSampleData();
this.xaxis.setManualRange$Z(true);
this.yaxis.setManualRange$Z(true);
try {
this.jbInit();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'setRange$D$D$D$D', function (xmin, xmax, ymin, ymax) {
if (xmin >= xmax  || ymin >= ymax  ) return;
this.xmin = xmin;
this.xmax = xmax;
this.ymin = ymin;
this.ymax = ymax;
p$.detachCurves.apply(this, []);
this.curves = null;
if (this.gridLimits) {
if (this.xaxis != null ) {
this.xaxis.setManualRange$Z$D$D(true, xmin, xmax);
}if (this.yaxis != null ) {
this.yaxis.setManualRange$Z$D$D(true, ymin, ymax);
}}});

Clazz.newMeth(C$, 'setNoContours$Z', function (nc) {
if (nc == this.noContours ) return;
this.noContours = nc;
if (nc) p$.detachCurves.apply(this, []);
 else p$.attachCurves.apply(this, []);
});

Clazz.newMeth(C$, 'getRange', function () {
var d = Clazz.array(Double.TYPE, [4]);
d[0] = this.xmin;
d[1] = this.xmax;
d[2] = this.ymin;
d[3] = this.ymax;
return d;
});

Clazz.newMeth(C$, 'getDim', function () {
var i = Clazz.array(Integer.TYPE, [2]);
i[0] = this.nx;
i[1] = this.ny;
return i;
});

Clazz.newMeth(C$, 'getGrid', function () {
return this.grid;
});

Clazz.newMeth(C$, 'setLevels$D$D$I', function (start, delta, nl) {
var i;
nl = Math.min(nl, 1000);
if (nl <= 0) {
this.autoLevels = true;
this.setNLevels$I(12);
return;
}if (delta <= 0 ) {
this.autoLevels = true;
this.setNLevels$I(nl);
return;
}p$.detachCurves.apply(this, []);
this.curves = null;
this.autoLevels = false;
this.levels = Clazz.array(Double.TYPE, [nl]);
for (i = 0; i < nl; i++) {
this.levels[i] = start;
start += delta;
}
this.labels = Clazz.array((I$[2]||$incl$(2)), [nl]);
for (i = 0; i < nl; i++) {
this.labels[i] = Clazz.new_((I$[2]||$incl$(2)).c$$S,[String.valueOf(this.levels[i])]);
}
});

Clazz.newMeth(C$, 'setLevels$DA', function (levels) {
var i;
if (levels == null  || levels.length <= 0 ) {
this.autoLevels = true;
this.setNLevels$I(12);
return;
}var nl = levels.length;
p$.detachCurves.apply(this, []);
this.curves = null;
this.autoLevels = false;
this.levels = Clazz.array(Double.TYPE, [nl]);
System.arraycopy(levels, 0, this.levels, 0, nl);
this.labels = Clazz.array((I$[2]||$incl$(2)), [nl]);
for (i = 0; i < this.labels.length; i++) {
this.labels[i] = Clazz.new_((I$[2]||$incl$(2)).c$$S,[String.valueOf(levels[i])]);
}
});

Clazz.newMeth(C$, 'setLabels$edu_davidson_graph_TextLineA$I', function (labels, nl) {
if (labels == null  || nl <= 0 ) return;
this.autoLabels = false;
this.labels = Clazz.array((I$[2]||$incl$(2)), [nl]);
System.arraycopy(labels, 0, this.labels, 0, nl);
});

Clazz.newMeth(C$, 'setLabelFont$java_awt_Font', function (f) {
this.labelfont = f;
});

Clazz.newMeth(C$, 'setLabelColor$java_awt_Color', function (c) {
this.labelcolor = c;
});

Clazz.newMeth(C$, 'setGrid$DA$I$I', function (grid, nx, ny) {
this.grid = grid;
this.nx = nx;
this.ny = ny;
C$.MINCELLS = ((nx + ny)/4|0);
p$.zrange.apply(this, []);
p$.calcLevels.apply(this, []);
});

Clazz.newMeth(C$, 'setGrid$DAA', function (newGrid) {
if (newGrid == null  || newGrid.length < 2  || newGrid[0].length < 2 ) return;
this.setGrid$DAA$D$D$D$D(newGrid, this.xmin, this.xmax, this.ymin, this.ymax);
});

Clazz.newMeth(C$, 'setGrid$DAA$D$D$D$D', function (newGrid, _xmin, _xmax, _ymin, _ymax) {
if (newGrid == null  || newGrid.length < 2  || newGrid[0].length < 2 ) return;
var count = 0;
var ii = newGrid.length;
var jj = newGrid[0].length;
var array = Clazz.array(Double.TYPE, [ii * jj]);
for (var j = 0; j < jj; j++) for (var i = 0; i < ii; i++) {
array[count] = newGrid[i][j];
count++;
}

this.setRange$D$D$D$D(_xmin, _xmax, _ymin, _ymax);
this.setGrid$DA$I$I(array, ii, jj);
p$.calcLabels.apply(this, []);
p$.detachCurves.apply(this, []);
this.curves = null;
});

Clazz.newMeth(C$, 'deleteContours', function () {
if (this.curves == null ) return;
p$.detachCurves.apply(this, []);
this.curves = null;
});

Clazz.newMeth(C$, 'detachContours', function () {
if (this.curves == null ) return;
p$.detachCurves.apply(this, []);
});

Clazz.newMeth(C$, 'attachContours', function () {
if (this.curves == null ) return;
p$.attachCurves.apply(this, []);
});

Clazz.newMeth(C$, 'setContourColor$java_awt_Color', function (c) {
this.contourColor = c;
});

Clazz.newMeth(C$, 'setLabelledContourColor$java_awt_Color', function (c) {
this.labelledColor = c;
});

Clazz.newMeth(C$, 'getLevels', function () {
return this.levels;
});

Clazz.newMeth(C$, 'setLimitsToGrid$Z', function (b) {
this.gridLimits = b;
});

Clazz.newMeth(C$, 'setLabelLevels$I', function (i) {
if (i <= 0) this.labelLevels = 0;
 else this.labelLevels = i;
});

Clazz.newMeth(C$, 'setLogLevels$Z', function (b) {
this.logLevels = b;
if (this.zmin <= 0.0  || this.zmax <= 0.0  ) this.logLevels = false;
});

Clazz.newMeth(C$, 'setNLevels$I', function (l) {
if (l <= 0) return;
this.levels = Clazz.array(Double.TYPE, [l]);
p$.calcLevels.apply(this, []);
p$.detachCurves.apply(this, []);
this.curves = null;
});

Clazz.newMeth(C$, 'setAutoLevels$Z', function (b) {
this.autoLevels = b;
});

Clazz.newMeth(C$, 'setDrawLabels$Z', function (b) {
if (this.drawlabels == b ) return;
this.drawlabels = b;
});

Clazz.newMeth(C$, 'getDrawLabels', function () {
return this.drawlabels;
});

Clazz.newMeth(C$, 'setLabelStyle$I', function (s) {
this.labelStyle = s;
p$.calcLabels.apply(this, []);
});

Clazz.newMeth(C$, 'getLabelStyle', function () {
return this.labelStyle;
});

Clazz.newMeth(C$, 'setLabelPrecision$I', function (p) {
this.labelPrecision = p;
p$.calcLabels.apply(this, []);
});

Clazz.newMeth(C$, 'getLabelPrecision', function () {
return this.labelPrecision;
});

Clazz.newMeth(C$, 'setLabelSignificance$I', function (s) {
this.labelSignificant = s;
p$.calcLabels.apply(this, []);
});

Clazz.newMeth(C$, 'getLabelSignificance', function () {
return this.labelSignificant;
});

Clazz.newMeth(C$, 'calcLevels', function () {
var i;
var l;
if (!this.autoLevels) return;
if (this.levels == null ) this.levels = Clazz.array(Double.TYPE, [12]);
this.labels = Clazz.array((I$[2]||$incl$(2)), [this.levels.length]);
if (this.logLevels) {
var inc = Math.log(this.zmax - this.zmin) / (this.levels.length + 1);
try {
for (i = 0; i < this.levels.length; i++) this.levels[i] = this.zmin + Math.pow(2.718281828459045, (i + 1) * inc);

} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Error calculateing Log levels!");
System.out.println$S("... calculating linear levels instead");
this.logLevels = false;
p$.calcLevels.apply(this, []);
} else {
throw e;
}
}
} else {
var inc = (this.zmax - this.zmin) / (this.levels.length + 1);
for (i = 0; i < this.levels.length; i++) this.levels[i] = this.zmin + (i + 1) * inc;

}});

Clazz.newMeth(C$, 'calcLabels', function () {
var i;
if (!this.autoLabels) return;
if (this.levels == null  || this.levels.length <= 0 ) return;
this.labels = Clazz.array((I$[2]||$incl$(2)), [this.levels.length]);
for (i = 0; i < this.labels.length; i++) {
this.labels[i] = Clazz.new_((I$[2]||$incl$(2)));
this.labels[i].parseDouble$D$I$I$I(this.levels[i], this.labelSignificant, this.labelPrecision, this.labelStyle);
}
});

Clazz.newMeth(C$, 'zrange', function () {
var i;
this.zmin = this.grid[0];
this.zmax = this.grid[1];
for (i = 0; i < this.grid.length; i++) {
this.zmin = Math.min(this.zmin, this.grid[i]);
this.zmax = Math.max(this.zmax, this.grid[i]);
}
if (this.zmin == this.zmax ) {
}if (this.zmin <= 0  || this.zmax <= 0  ) this.logLevels = false;
});

Clazz.newMeth(C$, 'paintFirst$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
{
if (this.curves == null  && !this.noContours ) {
this.calculateCurves();
p$.calcLabels.apply(this, []);
}}p$.setContourColors.apply(this, []);
if (this.gridLimits) {
if (this.xaxis != null ) {
if (this.xaxis.minimum != this.xmin ) this.xaxis.minimum = this.xmin;
if (this.xaxis.maximum != this.xmax ) this.xaxis.maximum = this.xmax;
}if (this.yaxis != null ) {
if (this.yaxis.minimum != this.ymin ) this.yaxis.minimum = this.ymin;
if (this.yaxis.maximum != this.ymax ) this.yaxis.maximum = this.ymax;
}} else if (this.dataset.isEmpty()) {
if (this.xaxis != null ) {
this.xaxis.minimum = this.xmin;
this.xaxis.maximum = this.xmax;
}if (this.yaxis != null ) {
this.yaxis.minimum = this.ymin;
this.yaxis.maximum = this.ymax;
}}});

Clazz.newMeth(C$, 'setContourColors', function () {
var i;
var j;
var v;
if (this.curves == null  || (this.contourColor == null  && this.labelledColor == null  ) ) return;
for (i = 0; i < this.curves.length; i++) {
p$.setContourColors$java_util_Vector$java_awt_Color.apply(this, [this.curves[i], null]);
}
if (this.contourColor != null ) {
for (i = 0; i < this.curves.length; i++) {
p$.setContourColors$java_util_Vector$java_awt_Color.apply(this, [this.curves[i], this.contourColor]);
}
}if (this.labelledColor != null ) {
for (i = 0; i < this.curves.length; i++) {
if (i % this.labelLevels == 0) {
p$.setContourColors$java_util_Vector$java_awt_Color.apply(this, [this.curves[i], this.labelledColor]);
}}
}});

Clazz.newMeth(C$, 'setContourColors$java_util_Vector$java_awt_Color', function (v, c) {
var i;
var d;
if (v == null ) return;
for (i = 0; i < v.size(); i++) {
d = (v.elementAt$I(i));
if (d != null ) d.linecolor = c;
}
});

Clazz.newMeth(C$, 'attachCurves', function () {
var i;
if (this.curves == null ) return;
for (i = 0; i < this.curves.length; i++) p$.attachCurves$java_util_Vector.apply(this, [this.curves[i]]);

});

Clazz.newMeth(C$, 'attachCurves$java_util_Vector', function (v) {
var j;
if (v == null ) return;
for (j = 0; j < v.size(); j++) {
this.attachDataSet$edu_davidson_graph_DataSet((v.elementAt$I(j)));
if (this.xaxis != null ) this.xaxis.attachDataSet$edu_davidson_graph_DataSet((v.elementAt$I(j)));
if (this.yaxis != null ) this.yaxis.attachDataSet$edu_davidson_graph_DataSet((v.elementAt$I(j)));
}
});

Clazz.newMeth(C$, 'detachCurves', function () {
var i;
if (this.curves == null ) return;
for (i = 0; i < this.curves.length; i++) p$.detachCurves$java_util_Vector.apply(this, [this.curves[i]]);

});

Clazz.newMeth(C$, 'detachCurves$java_util_Vector', function (v) {
var j;
if (v == null ) return;
for (j = 0; j < v.size(); j++) {
this.detachDataSet$edu_davidson_graph_DataSet((v.elementAt$I(j)));
if (this.xaxis != null ) this.xaxis.detachDataSet$edu_davidson_graph_DataSet((v.elementAt$I(j)));
if (this.yaxis != null ) this.yaxis.detachDataSet$edu_davidson_graph_DataSet((v.elementAt$I(j)));
}
});

Clazz.newMeth(C$, 'paintLast$java_awt_Graphics$java_awt_Rectangle', function (g, rect) {
var i;
var j;
var points;
var index;
var v;
var ds;
var point = Clazz.array(Double.TYPE, [2]);
var x;
var y;
var current = g.getColor();
var r = Clazz.new_((I$[5]||$incl$(5)));
if (this.xaxis == null  || this.yaxis == null   || this.labels == null   || this.labelLevels == 0  || !this.drawlabels  || this.curves == null  ) {
C$.superclazz.prototype.paintLast$java_awt_Graphics$java_awt_Rectangle.apply(this, [g, rect]);
return;
}for (i = 0; i < this.levels.length; i++) {
if (this.labels[i] != null  && !this.labels[i].isNull()  && i % this.labelLevels == 0 ) {
this.labels[i].setFont$java_awt_Font(this.labelfont);
this.labels[i].setColor$java_awt_Color(this.labelcolor);
v = this.curves[i];
for (j = 0; j < v.size(); j++) {
ds = (v.elementAt$I(j));
points = ds.dataPoints();
index = ((Math.random() * C$.MINCELLS)|0);
while (points > C$.MINCELLS){
point = ds.getPoint$I(index);
x = this.xaxis.getInteger$D(point[0]);
y = this.yaxis.getInteger$D(point[1]);
r.width = this.labels[i].getWidth$java_awt_Graphics(g);
r.height = this.labels[i].getAscent$java_awt_Graphics(g);
r.x = x - (r.width/2|0);
r.y = y - (r.height/2|0);
g.setColor$java_awt_Color(this.DataBackground);
g.fillRect$I$I$I$I(r.x, r.y, r.width, r.height);
g.setColor$java_awt_Color(current);
this.labels[i].draw$java_awt_Graphics$I$I$I(g, r.x, r.y + r.height, 1);
points = points-(C$.MINCELLS);
index = index+(C$.MINCELLS);
}
}
}}
C$.superclazz.prototype.paintLast$java_awt_Graphics$java_awt_Rectangle.apply(this, [g, rect]);
});

Clazz.newMeth(C$, 'calculateCurves', function () {
var i;
var j;
var data;
var xscale = (this.xmax - this.xmin) / (this.nx - 1);
var yscale = (this.ymax - this.ymin) / (this.ny - 1);
var isocurve;
isocurve = Clazz.new_((I$[6]||$incl$(6)).c$$DA$I$I,[this.grid, this.nx, this.ny]);
{
if (this.curves != null ) {
p$.detachCurves.apply(this, []);
this.curves = null;
}if (this.zmin == this.zmax ) return;
var numCurves = this.levels.length;
var newCurves = Clazz.array((I$[7]||$incl$(7)), [numCurves]);
for (i = 0; i < numCurves; i++) {
isocurve.setValue$D(this.levels[i]);
newCurves[i] = Clazz.new_((I$[7]||$incl$(7)));
data = isocurve.getCurve();
while (isocurve != null  && data != null  ){
for (j = 0; j < data.length; ) {
data[j] = this.xmin + data[j] * xscale;
j++;
data[j] = this.ymin + data[j] * yscale;
j++;
}
try {
newCurves[i].addElement$TE(Clazz.new_((I$[8]||$incl$(8)).c$$DA$I,[data, (data.length/2|0)]));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Error loading contour into DataSet!");
System.out.println$S("...Contour Level " + new Double(this.levels[i]).toString());
return;
} else {
throw e;
}
}
data = isocurve.getCurve();
}
p$.calcLabels.apply(this, []);
if (newCurves != null  && newCurves[i] != null  ) p$.attachCurves$java_util_Vector.apply(this, [newCurves[i]]);
}
this.curves = newCurves;
}});

Clazz.newMeth(C$, 'calculateCurve$D', function (aLevel) {
var j;
var data;
var xscale = (this.xmax - this.xmin) / (this.nx - 1);
var yscale = (this.ymax - this.ymin) / (this.ny - 1);
var isocurve;
isocurve = Clazz.new_((I$[6]||$incl$(6)).c$$DA$I$I,[this.grid, this.nx, this.ny]);
if (this.zmin == this.zmax ) return;
isocurve.setValue$D(aLevel);
var aCurve = Clazz.new_((I$[7]||$incl$(7)));
while (isocurve != null  && (data = isocurve.getCurve()) != null  ){
for (j = 0; j < data.length; ) {
data[j] = this.xmin + data[j] * xscale;
j++;
data[j] = this.ymin + data[j] * yscale;
j++;
}
try {
aCurve.addElement$TE(Clazz.new_((I$[8]||$incl$(8)).c$$DA$I,[data, (data.length/2|0)]));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Error loading contour into DataSet!");
System.out.println$S("...Contour Level " + new Double(aLevel).toString());
return;
} else {
throw e;
}
}
}
if (aCurve != null ) p$.attachCurves$java_util_Vector.apply(this, [aCurve]);
});

Clazz.newMeth(C$, 'deleteAllSeries', function () {
this.deleteContours();
C$.superclazz.prototype.deleteAllSeries.apply(this, []);
p$.calcLevels.apply(this, []);
this.repaint();
});

Clazz.newMeth(C$, 'createSampleData', function () {
var i;
var j;
var count;
var nx = 50;
var ny = 50;
var xmin = -1.0;
var xmax = 1.0;
var ymax = 1.0;
var ymin = -1.0;
var array = Clazz.array(Double.TYPE, [nx * ny]);
var x;
var y;
var rad;
var h1;
var h2;
var h3;
h1 = 0.25;
h2 = 0.5625;
h3 = 0.0625;
count = 0;
for (j = 0; j < ny; j++) {
y = 2.0 * j / (ny - 1) - 1.0;
for (i = 0; i < nx; i++) {
x = 2.0 * i / (nx - 1) - 1.0;
rad = (x - 0.5) * (x - 0.5) + (y + 0.5) * (y + 0.5);
array[count] = Math.exp(-rad / h1);
rad = (x + 0.3) * (x + 0.3) + (y - 0.75) * (y - 0.75);
array[count] += Math.exp(-rad / h2);
rad = (x + 0.7) * (x + 0.7) + (y + 0.6) * (y + 0.6);
array[count] = x * x + x * y;
count++;
}
}
this.setRange$D$D$D$D(xmin, xmax, ymin, ymax);
this.setGrid$DA$I$I(array, nx, ny);
this.setLabelLevels$I(3);
this.setNLevels$I(20);
});

Clazz.newMeth(C$, 'paintCoordinates$D$D', function (x, y) {
var g = this.getGraphics();
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
var msg = "x=" + this.$format.form$D(x) + " y=" + this.$format.form$D(y) ;
g.setColor$java_awt_Color((I$[4]||$incl$(4)).yellow);
var w = 20 + fm.stringWidth$S(msg);
g.fillRect$I$I$I$I(0, this.getBounds().height - 15, w, 15);
g.setColor$java_awt_Color((I$[4]||$incl$(4)).black);
g.drawString$S$I$I(msg, 8, this.getBounds().height - 2);
g.dispose();
});

Clazz.newMeth(C$, 'jbInit', function () {
this.addMouseMotionListener$java_awt_event_MouseMotionListener(Clazz.new_((I$[9]||$incl$(9)).c$$edu_davidson_display_SContour,[this]));
this.addMouseListener$java_awt_event_MouseListener(Clazz.new_((I$[10]||$incl$(10)).c$$edu_davidson_display_SContour,[this]));
});

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
this.isDrag = true;
var x = this.xFromPix$I(e.getX());
var y = this.yFromPix$I(e.getY());
this.paintCoordinates$D$D(x, y);
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.isDrag = false;
this.repaint();
});

Clazz.newMeth(C$, 'this_mouseMoved$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor((I$[11]||$incl$(11)).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$, 'this_mouseDragged$java_awt_event_MouseEvent', function (e) {
var x = this.xFromPix$I(e.getX());
var y = this.yFromPix$I(e.getY());
if (this.isDrag) {
this.paintCoordinates$D$D(x, y);
}});
})();
//Created 2018-02-22 01:07:13
