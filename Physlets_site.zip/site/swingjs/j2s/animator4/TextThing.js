(function(){var P$=Clazz.newPackage("animator4"),I$=[[0,'java.awt.Font','edu.davidson.numerics.Parser','edu.davidson.tools.SUtil','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "TextThing", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.calcStr=null;
this.textVars=null;
this.calcFunc=null;
this.chopValue=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.textVars=Clazz.array(Double.TYPE, [10]);
this.chopValue=1.0E-12;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$S$S$S$S', function (o, txt, cs, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.font=Clazz.new_($I$(1).c$$S$I$I,["Helvetica", 1, 14]);
this.label=txt;
this.calcStr=cs;
if (this.calcStr == null ) return;
this.calcFunc=Clazz.new_($I$(2).c$$I,[10]);
this.calcFunc.defineVariable$I$S(1, "t");
this.calcFunc.defineVariable$I$S(2, "x");
this.calcFunc.defineVariable$I$S(3, "y");
this.calcFunc.defineVariable$I$S(4, "vx");
this.calcFunc.defineVariable$I$S(5, "vy");
this.calcFunc.defineVariable$I$S(6, "ax");
this.calcFunc.defineVariable$I$S(7, "ay");
this.calcFunc.defineVariable$I$S(8, "m");
this.calcFunc.defineVariable$I$S(9, "fx");
this.calcFunc.defineVariable$I$S(10, "fy");
this.calcFunc.define$S(this.calcStr);
this.calcFunc.parse$();
if (this.calcFunc.getErrorCode$() != 0) {
System.out.println$S("Failed to parse calc-text: " + this.calcStr);
System.out.println$S("Parse error: " + this.calcFunc.getErrorString$() + " at function 1, position " + this.calcFunc.getErrorPosition$() );
return;
}}, 1);

Clazz.newMeth(C$, 'getText$', function () {
var val=0;
if (this.calcStr == null ) return this.label;
for (var i=0; i < 8; i++) {
this.textVars[i]=this.vars[i];
}
if (this.myMaster != null  && !this.dynamic ) {
this.textVars[8]=this.myMaster.getTotalFx$();
this.textVars[9]=this.myMaster.getTotalFy$();
} else {
this.textVars[8]=this.getTotalFx$();
this.textVars[9]=this.getTotalFy$();
}try {
val=this.calcFunc.evaluate$DA(this.textVars);
val=$I$(3).chop$D$D(val, this.chopValue);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return this.label + " " + this.format.form$D(val) ;
});

Clazz.newMeth(C$, 'setChop$D', function (value) {
this.chopValue=value;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var f=g.getFont$();
g.setFont$java_awt_Font(this.font);
var ptX=Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY=Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.drawString$S$I$I(this.getText$(), ptX, ptY);
g.setColor$java_awt_Color($I$(4).black);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:45 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
