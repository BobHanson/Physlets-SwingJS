(function(){var P$=Clazz.newPackage("org.xml.sax.ext"),I$=[];
var C$=Clazz.newClass(P$, "Locator2Impl", null, 'org.xml.sax.helpers.LocatorImpl', 'org.xml.sax.ext.Locator2');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.encoding = null;
this.version = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'c$$org_xml_sax_Locator', function (locator) {
C$.superclazz.c$$org_xml_sax_Locator.apply(this, [locator]);
C$.$init$.apply(this);
if (Clazz.instanceOf(locator, "org.xml.sax.ext.Locator2")) {
var l2 = locator;
this.version=l2.getXMLVersion();
this.encoding=l2.getEncoding();
}}, 1);

Clazz.newMeth(C$, 'getXMLVersion', function () {
return this.version;
});

Clazz.newMeth(C$, 'getEncoding', function () {
return this.encoding;
});

Clazz.newMeth(C$, 'setXMLVersion$S', function (version) {
this.version=version;
});

Clazz.newMeth(C$, 'setEncoding$S', function (encoding) {
this.encoding=encoding;
});
})();
//Created 2018-07-22 16:20:21 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
