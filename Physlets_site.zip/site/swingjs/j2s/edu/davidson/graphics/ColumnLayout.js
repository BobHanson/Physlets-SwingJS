(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['edu.davidson.graphics.Orientation','java.awt.Dimension']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ColumnLayout", null, null, 'java.awt.LayoutManager');
C$._defaultGap = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$._defaultGap = 5;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.gap = 0;
this.horizontalOrientation = null;
this.verticalOrientation = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation$I.apply(this, [(I$[1]||$incl$(1)).CENTER, (I$[1]||$incl$(1)).CENTER, C$._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (gap) {
C$.c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation$I.apply(this, [(I$[1]||$incl$(1)).CENTER, (I$[1]||$incl$(1)).CENTER, gap]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation', function (horizontalOrient, verticalOrient) {
C$.c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation$I.apply(this, [horizontalOrient, verticalOrient, C$._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation$I', function (horizontalOrient, verticalOrient, gap) {
C$.$init$.apply(this);
if (gap < 0 || (horizontalOrient !== (I$[1]||$incl$(1)).LEFT  && horizontalOrient !== (I$[1]||$incl$(1)).CENTER   && horizontalOrient !== (I$[1]||$incl$(1)).RIGHT  )  || (verticalOrient !== (I$[1]||$incl$(1)).TOP  && verticalOrient !== (I$[1]||$incl$(1)).CENTER   && verticalOrient !== (I$[1]||$incl$(1)).BOTTOM  ) ) {
throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["bad gap or orientation"]);
}this.gap = gap;
this.verticalOrientation = verticalOrient;
this.horizontalOrientation = horizontalOrient;
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, comp) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (comp) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
var insets = target.getInsets();
var dim = Clazz.new_((I$[2]||$incl$(2)).c$$I$I,[0, 0]);
var ncomponents = target.getComponentCount();
var comp;
var d;
for (var i = 0; i < ncomponents; i++) {
comp = target.getComponent$I(i);
if (comp.isVisible()) {
d = comp.getPreferredSize();
if (i > 0) dim.height = dim.height+(this.gap);
dim.height = dim.height+(d.height);
dim.width = Math.max(d.width, dim.width);
}}
dim.width = dim.width+(insets.left + insets.right);
dim.height = dim.height+(insets.top + insets.bottom);
return dim;
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
var insets = target.getInsets();
var dim = Clazz.new_((I$[2]||$incl$(2)).c$$I$I,[0, 0]);
var ncomponents = target.getComponentCount();
var comp;
var d;
for (var i = 0; i < ncomponents; i++) {
comp = target.getComponent$I(i);
if (comp.isVisible()) {
d = comp.getMinimumSize();
dim.width = Math.max(d.width, dim.width);
dim.height = dim.height+(d.height);
if (i > 0) dim.height = dim.height+(this.gap);
}}
dim.width = dim.width+(insets.left + insets.right);
dim.height = dim.height+(insets.top + insets.bottom);
return dim;
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var insets = target.getInsets();
var top = insets.top;
var left = 0;
var ncomponents = target.getComponentCount();
var preferredSize = target.getPreferredSize();
var targetSize = target.getSize();
var comp;
var ps;
if (this.verticalOrientation === (I$[1]||$incl$(1)).CENTER ) top = top+(((targetSize.height/2|0)) - ((preferredSize.height/2|0)));
 else if (this.verticalOrientation === (I$[1]||$incl$(1)).BOTTOM ) top = targetSize.height - preferredSize.height + insets.top;
for (var i = 0; i < ncomponents; i++) {
comp = target.getComponent$I(i);
left = insets.left;
if (comp.isVisible()) {
ps = comp.getPreferredSize();
if (this.horizontalOrientation === (I$[1]||$incl$(1)).CENTER ) left = ((targetSize.width/2|0)) - ((ps.width/2|0));
 else if (this.horizontalOrientation === (I$[1]||$incl$(1)).RIGHT ) {
left = targetSize.width - ps.width - insets.right ;
}comp.setBounds$I$I$I$I(left, top, ps.width, ps.height);
top = top+(ps.height + this.gap);
}}
});
})();
//Created 2018-02-22 01:07:15
