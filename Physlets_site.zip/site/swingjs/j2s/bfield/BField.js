(function(){var P$=Clazz.newPackage("bfield"),I$=[['edu.davidson.graphics.EtchedBorder','a2s.Button','a2s.TextField','a2s.Panel','java.awt.GridLayout','a2s.Checkbox','java.awt.BorderLayout','bfield.FieldPanel','Boolean','java.awt.Dimension','bfield.BField$1','bfield.BField$2','bfield.BField$3','bfield.BField$4','bfield.BField$5','bfield.BField$6','bfield.BField$7','edu.davidson.tools.SUtil','bfield.CompassThing','bfield.FieldBox','bfield.FieldRectangle','bfield.FieldCircle','bfield.FieldCursor','bfield.FieldShell','bfield.FieldArrow','bfield.CalcThing','edu.davidson.display.CaptionThing','edu.davidson.graphics.Util','bfield.FieldImage','edu.davidson.display.ConstraintEllipse','edu.davidson.display.Constraint','java.awt.Color','java.awt.Font']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "BField", null, 'edu.davidson.tools.SApplet');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.button_reset = null;
this.button_currentin = null;
this.button_currentout = null;
this.label_newfield = null;
this.label_coil = null;
this.label_vectors = null;
this.label_doubleclick = null;
this.label_force_undefined = null;
this.label_field_undefined = null;
this.wireColor = null;
this.wireLabel = null;
this.hideWire = false;
this.showControls = false;
this.showFieldVectors = false;
this.coilMode = false;
this.rangeStr = null;
this.gridSize = 0;
this.etchedBorder1 = null;
this.etchedBorder2 = null;
this.updateBtn = null;
this.bxField = null;
this.byField = null;
this.panel1 = null;
this.gridLayout1 = null;
this.etchedBorder3 = null;
this.lineCkBox = null;
this.fieldVecCkBox = null;
this.panel2 = null;
this.inBtn = null;
this.outBtn = null;
this.borderLayout1 = null;
this.panel3 = null;
this.fieldPanel = null;
this.borderLayout2 = null;
this.borderLayout3 = null;
this.borderLayout4 = null;
this.clearBtn = null;
this.bxStr = null;
this.byStr = null;
this.coilCkBox = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.button_reset = "Clear";
this.button_currentin = "Current In";
this.button_currentout = "Current Out";
this.label_newfield = "New Field: Bx By";
this.label_coil = "Coil";
this.label_vectors = "Vectors";
this.label_doubleclick = "Double Click";
this.label_force_undefined = "F=Undefined";
this.label_field_undefined = "B=Undefined inside wire.";
this.wireColor = null;
this.wireLabel = null;
this.hideWire = false;
this.showControls = true;
this.showFieldVectors = true;
this.coilMode = false;
this.rangeStr = "-1.0,1.0,-1.0,1.0";
this.etchedBorder1 = Clazz.new_((I$[1]||$incl$(1)));
this.etchedBorder2 = Clazz.new_((I$[1]||$incl$(1)));
this.updateBtn = Clazz.new_((I$[2]||$incl$(2)));
this.bxField = Clazz.new_((I$[3]||$incl$(3)));
this.byField = Clazz.new_((I$[3]||$incl$(3)));
this.panel1 = Clazz.new_((I$[4]||$incl$(4)));
this.gridLayout1 = Clazz.new_((I$[5]||$incl$(5)));
this.etchedBorder3 = Clazz.new_((I$[1]||$incl$(1)));
this.lineCkBox = Clazz.new_((I$[6]||$incl$(6)));
this.fieldVecCkBox = Clazz.new_((I$[6]||$incl$(6)));
this.panel2 = Clazz.new_((I$[4]||$incl$(4)));
this.inBtn = Clazz.new_((I$[2]||$incl$(2)));
this.outBtn = Clazz.new_((I$[2]||$incl$(2)));
this.borderLayout1 = Clazz.new_((I$[7]||$incl$(7)));
this.panel3 = Clazz.new_((I$[4]||$incl$(4)));
this.fieldPanel = Clazz.new_((I$[8]||$incl$(8)).c$$bfield_BField,[this]);
this.borderLayout2 = Clazz.new_((I$[7]||$incl$(7)));
this.borderLayout3 = Clazz.new_((I$[7]||$incl$(7)));
this.borderLayout4 = Clazz.new_((I$[7]||$incl$(7)));
this.clearBtn = Clazz.new_((I$[2]||$incl$(2)));
this.bxStr = "0";
this.byStr = "0";
this.coilCkBox = Clazz.new_((I$[6]||$incl$(6)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'setResources', function () {
this.button_reset = this.localProperties.getProperty$S$S("button.reset", this.button_reset);
this.button_currentin = this.localProperties.getProperty$S$S("button.currentin", this.button_currentin);
this.button_currentout = this.localProperties.getProperty$S$S("button.currentout", this.button_currentout);
this.label_newfield = this.localProperties.getProperty$S$S("label.newfield", this.label_newfield);
this.label_coil = this.localProperties.getProperty$S$S("label.coil", this.label_coil);
this.label_vectors = this.localProperties.getProperty$S$S("label.vectors", this.label_vectors);
this.label_doubleclick = this.localProperties.getProperty$S$S("label.doubleclick", this.label_doubleclick);
this.label_force_undefined = this.localProperties.getProperty$S$S("label.force_undefined", this.label_force_undefined);
this.label_field_undefined = this.localProperties.getProperty$S$S("label.field_undefined", this.label_field_undefined);
});

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
try {
this.bxStr = this.getParameter$S$S("BxFunction", "0");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.byStr = this.getParameter$S$S("ByFunction", "0");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls = (I$[9]||$incl$(9)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showFieldVectors = (I$[9]||$incl$(9)).$valueOf(this.getParameter$S$S("ShowFieldVectors", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.gridSize = Integer.parseInt(this.getParameter$S$S("GridSize", "32"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.rangeStr = this.getParameter$S$S("Range", "-1,1,-1,1");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.bxField.setText$S(this.bxStr);
this.byField.setText$S(this.byStr);
this.etchedBorder1.setVisible$Z(this.showControls);
this.fieldPanel.setGridSize$I(this.gridSize);
this.fieldPanel.setShowFieldVectors$Z(this.showFieldVectors);
this.fieldVecCkBox.setState$Z(this.showFieldVectors);
this.fieldPanel.setRange$S(this.rangeStr);
if (this.showControls) {
this.fieldPanel.setShowBOnDrag$Z(true);
}});

Clazz.newMeth(C$, 'jbInit', function () {
this.etchedBorder2.setLayout$java_awt_LayoutManager(this.borderLayout4);
{
this.setSize$java_awt_Dimension(Clazz.new_((I$[10]||$incl$(10)).c$$I$I,[505, 457]));
}this.updateBtn.setActionCommand$S("newB");
this.updateBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "BField$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['bfield.BField'].updateBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[11]||$incl$(11)).$init$, [this, null])));
this.updateBtn.setLabel$S(this.label_newfield);
this.bxField.setText$S("textField1");
this.byField.setText$S("textField2");
this.gridLayout1.setColumns$I(2);
this.lineCkBox.setLabel$S(this.label_doubleclick);
this.lineCkBox.addItemListener$java_awt_event_ItemListener(((
(function(){var C$=Clazz.newClass(P$, "BField$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['itemStateChanged$java_awt_event_ItemEvent','itemStateChanged'], function (e) {
this.b$['bfield.BField'].lineCkBox_itemStateChanged$java_awt_event_ItemEvent(e);
});
})()
), Clazz.new_((I$[12]||$incl$(12)).$init$, [this, null])));
this.fieldVecCkBox.setState$Z(true);
this.fieldVecCkBox.addItemListener$java_awt_event_ItemListener(((
(function(){var C$=Clazz.newClass(P$, "BField$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['itemStateChanged$java_awt_event_ItemEvent','itemStateChanged'], function (e) {
this.b$['bfield.BField'].fieldVecCkBox_itemStateChanged$java_awt_event_ItemEvent(e);
});
})()
), Clazz.new_((I$[13]||$incl$(13)).$init$, [this, null])));
this.fieldVecCkBox.setLabel$S(this.label_vectors);
this.inBtn.setLabel$S(this.button_currentin);
this.inBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "BField$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['bfield.BField'].inBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[14]||$incl$(14)).$init$, [this, null])));
this.outBtn.setLabel$S(this.button_currentout);
this.outBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "BField$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['bfield.BField'].outBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[15]||$incl$(15)).$init$, [this, null])));
this.clearBtn.setLabel$S(this.button_reset);
this.coilCkBox.setLabel$S(this.label_coil);
this.coilCkBox.addItemListener$java_awt_event_ItemListener(((
(function(){var C$=Clazz.newClass(P$, "BField$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['itemStateChanged$java_awt_event_ItemEvent','itemStateChanged'], function (e) {
this.b$['bfield.BField'].coilCkBox_itemStateChanged$java_awt_event_ItemEvent(e);
});
})()
), Clazz.new_((I$[16]||$incl$(16)).$init$, [this, null])));
this.clearBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "BField$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['bfield.BField'].clearBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[17]||$incl$(17)).$init$, [this, null])));
this.etchedBorder3.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.panel1.setLayout$java_awt_LayoutManager(this.gridLayout1);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.add$java_awt_Component$O(this.etchedBorder1, "North");
this.etchedBorder1.add$java_awt_Component$O(this.etchedBorder2, "North");
this.etchedBorder2.add$java_awt_Component$O(this.updateBtn, "West");
this.etchedBorder2.add$java_awt_Component$O(this.panel1, "Center");
this.panel1.add$java_awt_Component$O(this.bxField, null);
this.panel1.add$java_awt_Component$O(this.byField, null);
this.etchedBorder1.add$java_awt_Component$O(this.etchedBorder3, "South");
this.etchedBorder3.add$java_awt_Component$O(this.panel2, "East");
this.panel2.add$java_awt_Component$O(this.clearBtn, null);
this.panel2.add$java_awt_Component$O(this.inBtn, null);
this.panel2.add$java_awt_Component$O(this.outBtn, null);
this.etchedBorder3.add$java_awt_Component$O(this.panel3, "Center");
this.panel3.add$java_awt_Component$O(this.coilCkBox, null);
this.panel3.add$java_awt_Component$O(this.fieldVecCkBox, null);
this.panel3.add$java_awt_Component$O(this.lineCkBox, null);
this.add$java_awt_Component$O(this.fieldPanel, "Center");
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "BField by W. Christian. Email:wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["BxFunction", "String", "B field x component"]), Clazz.array(java.lang.String, -1, ["ByFunction", "String", "B field y component"]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show interactive controls on screen"]), Clazz.array(java.lang.String, -1, ["GridSize", "int", "Grid size for calculations"])]);
return pinfo;
});

Clazz.newMeth(C$, ['addWire$D$D$D','addWire'], function (x, y, current) {
var w = this.fieldPanel.addWire$D$D$D(x, y, current);
w.setVisible$Z(!this.hideWire);
if (this.wireLabel != null ) {
w.setLabel$S(this.wireLabel);
}if (this.wireColor != null ) {
w.setColor$java_awt_Color(this.wireColor);
}return w.getID();
});

Clazz.newMeth(C$, ['addCoil$D$D$D','addCoil'], function (x, y, current) {
var w = this.fieldPanel.addCoil$D$D$D(x, y, current);
w.setVisible$Z(!this.hideWire);
if (this.wireLabel != null ) {
w.setLabel$S(this.wireLabel);
}if (this.wireColor != null ) {
w.setColor$java_awt_Color(this.wireColor);
}return w.getID();
});

Clazz.newMeth(C$, ['addObject$S$S','addObject'], function (name, parList) {
if (this.destroyed) {
return 0;
}var t = null;
var x = 0;
var y = 0;
var width = 20;
var height = 20;
var r = 10;
var s = 10;
name = name.toLowerCase().trim();
name = (I$[18]||$incl$(18)).removeWhitespace$S(name);
var parList2 = parList.trim();
;parList = (I$[18]||$incl$(18)).removeWhitespace$S(parList);
if (name.equals$O("field")) {
return this.fieldPanel.addField().hashCode();
} else if (name.equals$O("wire")) {
var current = 1;
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "i=")) {
current = (I$[18]||$incl$(18)).getParam$S$S(parList, "i=");
}var id = this.addWire$D$D$D(x, y, current);
t = this.fieldPanel.getThing$I(id);
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "s=")) {
s = ((I$[18]||$incl$(18)).getParam$S$S(parList, "s=")|0);
t.setSize$I(s);
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "dx=") && (I$[18]||$incl$(18)).parameterExist$S$S(parList, "num=") ) {
var dx = (I$[18]||$incl$(18)).getParam$S$S(parList, "dx=");
var num = ((I$[18]||$incl$(18)).getParam$S$S(parList, "num=")|0);
s = t.getSize();
for (var i = 0; i < num - 1; i++) {
x += dx;
id = this.addWire$D$D$D(x, y, current);
t = this.fieldPanel.getThing$I(id);
t.setSize$I(s);
}
}return id;
} else if (name.equals$O("coil")) {
var current = 1;
var rad = 0.5;
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "i=")) {
current = (I$[18]||$incl$(18)).getParam$S$S(parList, "i=");
}var id = this.addCoil$D$D$D(x, y, current);
t = this.fieldPanel.getThing$I(id);
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "r=")) {
rad = (I$[18]||$incl$(18)).getParam$S$S(parList, "r=");
this.setRadius$I$D(id, rad);
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "s=")) {
s = ((I$[18]||$incl$(18)).getParam$S$S(parList, "s=")|0);
t.setSize$I(s);
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "dx=") && (I$[18]||$incl$(18)).parameterExist$S$S(parList, "num=") ) {
var dx = (I$[18]||$incl$(18)).getParam$S$S(parList, "dx=");
var num = ((I$[18]||$incl$(18)).getParam$S$S(parList, "num=")|0);
rad = (t).getRadius();
s = t.getSize();
for (var i = 0; i < num - 1; i++) {
x += dx;
id = this.addCoil$D$D$D(x, y, current);
t = this.fieldPanel.getThing$I(id);
t.setSize$I(s);
this.setRadius$I$D(id, rad);
}
}return id;
} else if (name.equals$O("compass")) {
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "r=")) {
r = ((I$[18]||$incl$(18)).getParam$S$S(parList, "r=")|0);
}t = Clazz.new_((I$[19]||$incl$(19)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I,[this, this.fieldPanel, x, y, r]);
} else if (name.equals$O("box")) {
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "w=")) {
width = ((I$[18]||$incl$(18)).getParam$S$S(parList, "w=")|0);
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "h=")) {
height = ((I$[18]||$incl$(18)).getParam$S$S(parList, "h=")|0);
}t = Clazz.new_((I$[20]||$incl$(20)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I$I,[this, this.fieldPanel, x, y, width, height]);
} else if (name.equals$O("rectangle")) {
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "w=")) {
width = ((I$[18]||$incl$(18)).getParam$S$S(parList, "w=")|0);
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "h=")) {
height = ((I$[18]||$incl$(18)).getParam$S$S(parList, "h=")|0);
}t = Clazz.new_((I$[21]||$incl$(21)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I$I,[this, this.fieldPanel, x, y, width, height]);
} else if (name.equals$O("circle")) {
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "r=")) {
r = ((I$[18]||$incl$(18)).getParam$S$S(parList, "r=")|0);
}t = Clazz.new_((I$[22]||$incl$(22)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I,[this, this.fieldPanel, x, y, r]);
} else if (name.equals$O("cursor")) {
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "r=")) {
r = ((I$[18]||$incl$(18)).getParam$S$S(parList, "r=")|0);
}t = Clazz.new_((I$[23]||$incl$(23)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I,[this, this.fieldPanel, x, y, 2 * r + 1]);
} else if (name.equals$O("shell")) {
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "r=")) {
r = ((I$[18]||$incl$(18)).getParam$S$S(parList, "r=")|0);
}t = Clazz.new_((I$[24]||$incl$(24)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I,[this, this.fieldPanel, x, y, r]);
} else if (name.equals$O("arrow")) {
var horz = "1";
var vert = "1";
s = 4;
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "s=")) {
s = ((I$[18]||$incl$(18)).getParam$S$S(parList, "s=")|0);
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "h=")) {
horz = (I$[18]||$incl$(18)).getParamStr$S$S(parList, "h=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "v=")) {
vert = (I$[18]||$incl$(18)).getParamStr$S$S(parList, "v=");
}t = Clazz.new_((I$[25]||$incl$(25)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$I$S$S$D$D,[this, this.fieldPanel, s, horz, vert, x, y]);
} else if (name.equals$O("text")) {
var txt = "";
var calc = null;
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "txt=")) {
txt = (I$[18]||$incl$(18)).getParamStr$S$S(parList2, "txt=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "text=")) {
txt = (I$[18]||$incl$(18)).getParamStr$S$S(parList2, "text=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "calc=")) {
calc = (I$[18]||$incl$(18)).getParamStr$S$S(parList, "calc=");
}t = Clazz.new_((I$[26]||$incl$(26)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$S$S$D$D,[this, this.fieldPanel, txt, calc, x, y]);
} else if (name.equals$O("caption")) {
var txt = "";
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "txt=")) {
txt = (I$[18]||$incl$(18)).getParamStr$S$S(parList2, "txt=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "text=")) {
txt = (I$[18]||$incl$(18)).getParamStr$S$S(parList2, "text=");
}t = Clazz.new_((I$[27]||$incl$(27)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$S$D$D,[this, this.fieldPanel, txt, x, y]);
} else if (name.equals$O("image")) {
var file = " ";
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "x=")) {
x = (I$[18]||$incl$(18)).getParam$S$S(parList, "x=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "y=")) {
y = (I$[18]||$incl$(18)).getParam$S$S(parList, "y=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "gif=")) {
file = (I$[18]||$incl$(18)).getParamStr$S$S(parList, "gif=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "file=")) {
file = (I$[18]||$incl$(18)).getParamStr$S$S(parList, "file=");
}if (file == null ) {
return 0;
}var im = (I$[28]||$incl$(28)).getImage$S$a2s_Applet(file, this);
if (im != null ) {
t = Clazz.new_((I$[29]||$incl$(29)).c$$edu_davidson_tools_SApplet$bfield_FieldPanel$java_awt_Image$D$D,[this, this.fieldPanel, im, x, y]);
} else {
t = null;
}} else if (name.equals$O("constraint")) {
var xmin = 0;
var xmax = 0;
var ymin = 0;
var ymax = 0;
if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "xmin=")) {
xmin = (I$[18]||$incl$(18)).getParam$S$S(parList, "xmin=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "ymin=")) {
ymin = (I$[18]||$incl$(18)).getParam$S$S(parList, "ymin=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "xmax=")) {
xmax = (I$[18]||$incl$(18)).getParam$S$S(parList, "xmax=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "ymax=")) {
ymax = (I$[18]||$incl$(18)).getParam$S$S(parList, "ymax=");
}if ((I$[18]||$incl$(18)).parameterExist$S$S(parList, "path=")) {
var path = (I$[18]||$incl$(18)).getParamStr$S$S(parList2, "path=");
if (path.equals$O("ellipse")) {
t = Clazz.new_((I$[30]||$incl$(30)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$D$D,[this, this.fieldPanel, xmin, xmax, ymin, ymax]);
}} else {
t = Clazz.new_((I$[31]||$incl$(31)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$D$D,[this, this.fieldPanel, xmin, xmax, ymin, ymax]);
}}if (t == null ) {
System.out.println$S("Object not created. name:" + name + "parameter list:" + parList );
return 0;
}this.fieldPanel.addThing$edu_davidson_display_Thing(t);
this.fieldPanel.invalidateOSI();
if (this.autoRefresh) {
this.fieldPanel.repaint();
}return t.hashCode();
});

Clazz.newMeth(C$, ['setAnimationSlave$I$I','setAnimationSlave'], function (masterID, slaveID) {
var master = this.fieldPanel.getThing$I(masterID);
var slave = this.fieldPanel.getThing$I(slaveID);
if ((master == null ) || (slave == null ) ) {
return false;
}master.addSlave$edu_davidson_display_Thing(slave);
this.fieldPanel.invalidateOSI();
if (this.autoRefresh) {
this.fieldPanel.repaint();
}return true;
});

Clazz.newMeth(C$, ['getBx$D$D','getBx'], function (x, y) {
return this.fieldPanel.getBx$D$D$bfield_Wire(x, y, null);
});

Clazz.newMeth(C$, ['getBy$D$D','getBy'], function (x, y) {
return this.fieldPanel.getBy$D$D$bfield_Wire(x, y, null);
});

Clazz.newMeth(C$, 'getGraphID', function () {
return this.fieldPanel.graph.hashCode();
});

Clazz.newMeth(C$, ['setSeriesRGB$I$I$I$I','setSeriesRGB'], function (id, r, g, b) {
this.fieldPanel.graph.setSeriesColor$I$java_awt_Color(id, Clazz.new_((I$[32]||$incl$(32)).c$$I$I$I,[r, g, b]));
});

Clazz.newMeth(C$, ['setSeriesStyle$I$Z$I','setSeriesStyle'], function (id, conPts, m) {
this.fieldPanel.graph.setSeriesStyle$I$Z$I(id, conPts, m);
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (s) {
this.fieldPanel.graph.deleteSeries$I(s);
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (s) {
this.fieldPanel.graph.clearSeriesData$I(s);
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (ar) {
if (this.autoRefresh == ar ) {
return;
}this.autoRefresh = ar;
this.fieldPanel.setAutoRefresh$Z(ar);
if (!this.autoRefresh) {
return;
}this.fieldPanel.invalidateOSI();
this.fieldPanel.setFields();
this.fieldPanel.paintOSI();
var g = this.fieldPanel.getGraphics();
this.fieldPanel.paint$java_awt_Graphics(g);
g.dispose();
});

Clazz.newMeth(C$, ['setBFunctions$S$S$D$D$D$D','setBFunctions'], function (bx, by, xmin, xmax, ymin, ymax) {
this.bxField.setText$S(bx);
this.byField.setText$S(by);
this.fieldPanel.setBFunctions$S$S$D$D$D$D(bx, by, xmin, xmax, ymin, ymax);
});

Clazz.newMeth(C$, 'setDefault', function () {
this.setShowFieldVectors$Z(false);
this.wireLabel = null;
this.wireColor = null;
this.fieldPanel.setDefault();
});

Clazz.newMeth(C$, 'reset', function () {
this.fieldPanel.reset();
});

Clazz.newMeth(C$, ['setShowFieldLineOnClick$Z','setShowFieldLineOnClick'], function (sfl) {
this.fieldPanel.setShowFieldLineOnClick$Z(sfl);
this.lineCkBox.setState$Z(sfl);
});

Clazz.newMeth(C$, ['setShowFieldLineOnDoubleClick$Z','setShowFieldLineOnDoubleClick'], function (sfl) {
this.fieldPanel.setShowFieldLineOnDoubleClick$Z(sfl);
});

Clazz.newMeth(C$, ['setShowFieldVectors$Z','setShowFieldVectors'], function (sfv) {
this.fieldVecCkBox.setState$Z(sfv);
this.fieldPanel.setShowFieldVectors$Z(sfv);
});

Clazz.newMeth(C$, ['setRGB$I$I$I$I','setRGB'], function (id, r, g, b) {
return this.fieldPanel.setColor$I$java_awt_Color(id, Clazz.new_((I$[32]||$incl$(32)).c$$I$I$I,[r, g, b]));
});

Clazz.newMeth(C$, ['setLabel$I$S','setLabel'], function (id, str) {
return this.fieldPanel.setLabel$I$S(id, str);
});

Clazz.newMeth(C$, ['setDisplayOffset$I$I$I','setDisplayOffset'], function (id, xOff, yOff) {
var t = this.fieldPanel.getThing$I(id);
if (t == null ) {
return false;
}t.setDisplayOff$I$I(xOff, yOff);
this.fieldPanel.invalidateOSI();
if (this.autoRefresh) {
this.fieldPanel.setFields();
this.fieldPanel.repaint();
}return true;
});

Clazz.newMeth(C$, ['setDragable$I$Z','setDragable'], function (id, drag) {
return this.fieldPanel.setDragable$I$Z(id, drag);
});

Clazz.newMeth(C$, ['setFormat$I$S','setFormat'], function (id, fstr) {
var t = this.fieldPanel.getThing$I(id);
if ((t == null ) && ((id == 0) || (id == this.fieldPanel.hashCode()) ) ) {
return this.fieldPanel.setFormat$S(fstr);
}var result = t.setFormat$S(fstr);
if (this.autoRefresh) {
this.fieldPanel.repaint();
}return result;
});

Clazz.newMeth(C$, ['setFont$I$S$I$I','setFont'], function (id, family, style, size) {
var font = Clazz.new_((I$[33]||$incl$(33)).c$$S$I$I,[family, style, size]);
var t = this.fieldPanel.getThing$I(id);
if ((t == null ) || (font == null ) ) {
return false;
}t.setFont$java_awt_Font(font);
if (this.autoRefresh) {
this.fieldPanel.repaint();
}return true;
});

Clazz.newMeth(C$, ['setObjectFont$I$S$I$I','setObjectFont'], function (id, family, style, size) {
return this.setFont$I$S$I$I(id, family, style, size);
});

Clazz.newMeth(C$, ['setOptionDrag$I$Z','setOptionDrag'], function (id, isDrag) {
return this.fieldPanel.setOptionDrag$I$Z(id, isDrag);
});

Clazz.newMeth(C$, ['setResizable$I$Z','setResizable'], function (id, isResizable) {
return this.fieldPanel.setOptionDrag$I$Z(id, isResizable);
});

Clazz.newMeth(C$, ['setCurrent$I$D','setCurrent'], function (id, c) {
return this.fieldPanel.setCurrent$I$D(id, c);
});

Clazz.newMeth(C$, ['setConstraint$I$I','setConstraint'], function (id, constraintID) {
var t = this.fieldPanel.getThing$I(id);
var c = this.fieldPanel.getThing$I(constraintID);
if (t == null ) {
return false;
}if (c == null ) {
return false;
}if (!(Clazz.instanceOf(c, "edu.davidson.display.Constraint"))) {
return false;
}t.setConstraint$edu_davidson_display_Constraint(c);
return true;
});

Clazz.newMeth(C$, ['setRadius$I$D','setRadius'], function (id, r) {
return this.fieldPanel.setRadius$I$D(id, r);
});

Clazz.newMeth(C$, ['setShowFVector$I$Z','setShowFVector'], function (id, showForce) {
return this.fieldPanel.setShowForce$I$Z(id, showForce);
});

Clazz.newMeth(C$, ['setShowForce$I$Z','setShowForce'], function (id, showForce) {
return this.fieldPanel.setShowForce$I$Z(id, showForce);
});

Clazz.newMeth(C$, ['setShowFComponents$I$Z','setShowFComponents'], function (id, showComponents) {
return this.fieldPanel.setShowFComponents$I$Z(id, showComponents);
});

Clazz.newMeth(C$, ['setShowInfo$I$Z','setShowInfo'], function (id, showInfo) {
return this.fieldPanel.setShowInfo$I$Z(id, showInfo);
});

Clazz.newMeth(C$, ['setVisibility$I$Z','setVisibility'], function (id, v) {
return this.fieldPanel.setVisibility$I$Z(id, v);
});

Clazz.newMeth(C$, ['setXY$I$D$D','setXY'], function (id, x, y) {
var t = this.fieldPanel.getThing$I(id);
if (t == null ) {
return false;
}if (Clazz.instanceOf(t, "bfield.Wire")) {
this.fieldPanel.setWireXY$bfield_Wire$D$D(t, x, y);
return true;
}t.setXY$D$D(x, y);
this.fieldPanel.invalidateOSI();
if (this.autoRefresh) {
this.fieldPanel.repaint();
}return true;
});

Clazz.newMeth(C$, ['setXPos$I$D','setXPos'], function (id, x) {
var t = this.fieldPanel.getThing$I(id);
if (t == null ) {
return false;
}if (Clazz.instanceOf(t, "bfield.Wire")) {
var y = t.getY();
this.fieldPanel.setWireXY$bfield_Wire$D$D(t, x, y);
return true;
}t.setX$D(x);
this.fieldPanel.invalidateOSI();
if (this.autoRefresh) {
this.fieldPanel.repaint();
}return true;
});

Clazz.newMeth(C$, 'setX$I$D', function (id, x) {
return this.setXPos$I$D(id, x);
});

Clazz.newMeth(C$, ['getXPos$I','getXPos'], function (id) {
var t = this.fieldPanel.getThing$I(id);
if (t == null ) {
return 0;
}return t.getX();
});

Clazz.newMeth(C$, ['setYPos$I$D','setYPos'], function (id, y) {
var t = this.fieldPanel.getThing$I(id);
if (t == null ) {
return false;
}if (Clazz.instanceOf(t, "bfield.Wire")) {
var x = t.getX();
this.fieldPanel.setWireXY$bfield_Wire$D$D(t, x, y);
return true;
}t.setY$D(y);
this.fieldPanel.invalidateOSI();
if (this.autoRefresh) {
this.fieldPanel.repaint();
}return true;
});

Clazz.newMeth(C$, ['setY$I$D','setY'], function (id, y) {
return this.setYPos$I$D(id, y);
});

Clazz.newMeth(C$, ['getYPos$I','getYPos'], function (id) {
var t = this.fieldPanel.getThing$I(id);
if (t == null ) {
return 0;
}return t.getY();
});

Clazz.newMeth(C$, ['setShowCoordOnDrag$Z','setShowCoordOnDrag'], function (sc) {
this.fieldPanel.setShowCoordOnDrag$Z(sc);
});

Clazz.newMeth(C$, ['setSketchMode$Z','setSketchMode'], function (sketch) {
return this.fieldPanel.setSketchMode$Z(sketch);
});

Clazz.newMeth(C$, ['setShowBOnDrag$Z','setShowBOnDrag'], function (sb) {
this.fieldPanel.setShowBOnDrag$Z(sb);
});

Clazz.newMeth(C$, ['setShowControls$Z','setShowControls'], function (sc) {
this.etchedBorder2.setVisible$Z(sc);
this.invalidate();
this.validate();
});

Clazz.newMeth(C$, ['setHideWire$Z','setHideWire'], function (hw) {
this.hideWire = hw;
});

Clazz.newMeth(C$, ['setDefaultRGB$I$I$I','setDefaultRGB'], function (r, g, b) {
this.wireColor = Clazz.new_((I$[32]||$incl$(32)).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, ['setDefaultLabel$S','setDefaultLabel'], function (str) {
if ((str == null ) || str.trim().equals$O("") ) {
this.wireLabel = null;
} else {
this.wireLabel = str;
}});

Clazz.newMeth(C$, ['swapZOrder$I$I','swapZOrder'], function (id1, id2) {
var err = this.fieldPanel.swapZOrder$I$I(id1, id2);
this.fieldPanel.invalidateOSI();
if (this.autoRefresh) {
this.fieldPanel.repaint();
}return err;
});

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.firstTime) {
return 0;
} else {
return C$.superclazz.prototype.getAppletCount.apply(this, []);
}});

Clazz.newMeth(C$, 'start', function () {
if (this.firstTime) {
this.firstTime = false;
this.fieldPanel.osi = null;
this.fieldPanel.paintOSI();
this.fieldPanel.setBFunctions$S$S(this.bxStr, this.byStr);
}C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'destroy', function () {
this.destroyed = true;
this.autoRefresh = false;
this.fieldPanel.setAutoRefresh$Z(false);
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'fieldVecCkBox_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (e.getStateChange() == 1) {
this.fieldPanel.setShowFieldVectors$Z(true);
} else {
this.fieldPanel.setShowFieldVectors$Z(false);
}});

Clazz.newMeth(C$, 'lineCkBox_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (e.getStateChange() == 1) {
this.fieldPanel.setShowFieldLineOnDoubleClick$Z(true);
} else {
this.fieldPanel.setShowFieldLineOnDoubleClick$Z(false);
}});

Clazz.newMeth(C$, 'coilCkBox_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (e.getStateChange() == 1) {
this.coilMode = true;
} else {
this.coilMode = false;
}});

Clazz.newMeth(C$, 'clearBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.fieldPanel.clearAll();
});

Clazz.newMeth(C$, 'inBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.coilMode) {
this.fieldPanel.addCoil$D(1);
} else {
this.fieldPanel.addWire$D(-1);
}});

Clazz.newMeth(C$, 'outBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.coilMode) {
this.fieldPanel.addCoil$D(-1);
} else {
this.fieldPanel.addWire$D(1);
}});

Clazz.newMeth(C$, 'updateBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.bxStr = this.bxField.getText();
this.byStr = this.byField.getText();
this.fieldPanel.setBFunctions$S$S(this.bxStr, this.byStr);
});
})();
//Created 2018-03-17 21:36:54
