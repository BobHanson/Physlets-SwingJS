(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'edu.davidson.tools.SUtil']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "CurrentSource", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$I$S', function (circ, a, pol, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circ, pol, r, c, t]);
C$.$init$.apply(this);
this.value=a;
this.reverseEquation=true;
this.unity="A";
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit', function (circuit) {
C$.superclazz.c$$circuitsimulator_Circuit.apply(this, [circuit]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'rightFunction$D', function (sign) {
return this.value * sign;
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",a=" + Double.toString$D(this.value);
});

Clazz.newMeth(C$, 'set$S', function (s) {
var ret=C$.superclazz.prototype.set$S.apply(this, [s]);
if ($I$(1).parameterExist$S$S(s, "a=")) this.value=$I$(1).getParam$S$S(s, "a=");
return ret;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:48 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
