(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['edu.davidson.tools.SApplet',['edu.davidson.display.SGraph','.RegressionDataSource'],'java.awt.Color','edu.davidson.numerics.Parser','edu.davidson.display.VectorField','edu.davidson.display.Format','java.util.Vector','edu.davidson.graph.TextLine','java.awt.Font','java.lang.Thread','edu.davidson.graphics.Util','edu.davidson.display.TrailThing','java.util.StringTokenizer','java.awt.Toolkit','java.awt.Rectangle','edu.davidson.tools.SUtil','edu.davidson.display.MarkerThing','edu.davidson.display.ConnectorLine',['edu.davidson.display.SGraph','.MathFunction'],['edu.davidson.display.SGraph','.VectorFieldThing'],['edu.davidson.display.SGraph','.ComplexFunction'],'java.net.URL','java.io.StreamTokenizer','edu.davidson.display.SGraph_mouseMotionAdapter','edu.davidson.display.SGraph_mouseAdapter','edu.davidson.display.SGraphFrame','java.awt.Cursor',['edu.davidson.display.SGraph','.Series'],'edu.davidson.graph.Markers']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SGraph", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.graph.Graph2D', ['edu.davidson.tools.SStepable', 'Cloneable', 'edu.davidson.tools.SDataListener', 'Runnable', 'edu.davidson.display.SScalable']);
C$.colors = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.colors = Clazz.array((I$[3]||$incl$(3)), [91]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.isJS = false;
this.label_time = null;
this.interrupted = false;
this.newData = false;
this.delayLock = null;
this.delayThread = null;
this.xaxis = null;
this.yaxis = null;
this.borders = null;
this.format = null;
this.autoRefresh = false;
this.mouseMotionAdapter = null;
this.mouseAdapter = null;
this.boxWidth = 0;
this.sampleData = false;
this.dataSetSeries = null;
this.functions = null;
this.cfunctions = null;
this.dPoint = null;
this.labelX = null;
this.labelY = null;
this.labelXColor = null;
this.labelYColor = null;
this.labelXTitleColor = null;
this.labelYTitleColor = null;
this.defaultMarkerScale = 0;
this.enableMouse = false;
this.enableClone = false;
this.enableCoordDisplay = false;
this.parentSApplet = null;
this.titleStr = null;
this.title = null;
this.titleColor = null;
this.dataBackground = null;
this.$mouseDrag = false;
this.mouseX = 0;
this.mouseY = 0;
this.dragThing = null;
this.trailThing = null;
this.sketchMode = false;
this.boldFont = null;
this.hasGraphThing = false;
this.timeDisplay = false;
this.sketchImage = null;
this.things = null;
this.offScreenImage = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.isJS = true ||false;
this.label_time = "Time: ";
this.interrupted = false;
this.newData = false;
this.delayLock =  Clazz.new_();
this.delayThread = null;
this.borders = Clazz.array(Integer.TYPE, -1, [0, 10, 10, 0]);
this.format = Clazz.new_((I$[6]||$incl$(6)).c$$S,["%-+6.2g"]);
this.autoRefresh = true;
this.boxWidth = 0;
this.sampleData = false;
this.dataSetSeries = Clazz.new_((I$[7]||$incl$(7)));
this.functions = Clazz.new_((I$[7]||$incl$(7)));
this.cfunctions = Clazz.new_((I$[7]||$incl$(7)));
this.dPoint = Clazz.array(Double.TYPE, [2]);
this.labelX = "X Axis";
this.labelY = "Y Axis";
this.labelXColor = (I$[3]||$incl$(3)).black;
this.labelYColor = (I$[3]||$incl$(3)).black;
this.labelXTitleColor = (I$[3]||$incl$(3)).black;
this.labelYTitleColor = (I$[3]||$incl$(3)).black;
this.defaultMarkerScale = 1.0;
this.enableMouse = false;
this.enableClone = true;
this.enableCoordDisplay = true;
this.titleStr = null;
this.title = Clazz.new_((I$[8]||$incl$(8)));
this.titleColor = (I$[3]||$incl$(3)).black;
this.dataBackground = (I$[3]||$incl$(3)).white;
this.$mouseDrag = false;
this.trailThing = null;
this.sketchMode = false;
this.boldFont = Clazz.new_((I$[9]||$incl$(9)).c$$S$I$I,["Helvetica", 1, 14]);
this.hasGraphThing = false;
this.timeDisplay = false;
this.sketchImage = null;
this.things = Clazz.new_((I$[7]||$incl$(7)));
this.offScreenImage = null;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
C$.initColors();
this.title.setFontStyle$I(1);
this.title.setFontSize$I(16);
this.setDataBackground$java_awt_Color((I$[3]||$incl$(3)).white);
this.setGraphBackground$java_awt_Color((I$[3]||$incl$(3)).white);
p$.buildMarkers$I.apply(this, [4]);
this.drawzero=false;
this.drawgrid=false;
this.borderLeft=this.borders[0];
this.borderTop=this.borders[1];
this.borderRight=this.borders[2];
this.borderBottom=this.borders[3];
this.xaxis=this.createAxis$I(5);
this.xaxis.setTitleColor$java_awt_Color(this.labelXTitleColor);
this.xaxis.setLabelColor$java_awt_Color(this.labelXColor);
this.xaxis.setTitleBackground$java_awt_Color((I$[3]||$incl$(3)).white);
this.xaxis.setTitleText$S(this.labelX);
this.xaxis.setTitleFont$java_awt_Font(Clazz.new_((I$[9]||$incl$(9)).c$$S$I$I,["TimesRoman", 0, 12]));
this.xaxis.setLabelFont$java_awt_Font(Clazz.new_((I$[9]||$incl$(9)).c$$S$I$I,["Helvetica", 0, 10]));
this.yaxis=this.createAxis$I(2);
this.yaxis.setTitleColor$java_awt_Color(this.labelYTitleColor);
this.yaxis.setLabelColor$java_awt_Color(this.labelYColor);
this.yaxis.setTitleBackground$java_awt_Color((I$[3]||$incl$(3)).white);
this.yaxis.setTitleText$S(this.labelY);
this.yaxis.setTitleFont$java_awt_Font(Clazz.new_((I$[9]||$incl$(9)).c$$S$I$I,["TimesRoman", 0, 12]));
this.yaxis.setLabelFont$java_awt_Font(Clazz.new_((I$[9]||$incl$(9)).c$$S$I$I,["Helvetica", 0, 10]));
if (this.sampleData) p$.makeSampleData$I.apply(this, [100]);
try {
(I$[1]||$incl$(1)).addDataListener$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.delayThread=Clazz.new_((I$[10]||$incl$(10)).c$$Runnable,[this]);
if (!this.isJS) this.delayThread.start();
this.setFont$java_awt_Font(this.getFont());
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet', function (applet) {
C$.c$.apply(this, []);
this.parentSApplet=applet;
}, 1);

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t=e.nextElement();
if (Clazz.instanceOf(t, "edu.davidson.tools.SStepable")) (t).step(dt, time);
}
if (this.autoRefresh && this.parentSApplet != null  ) {
if (this.parentSApplet.destroyed) return;
this.parentSApplet.updateDataConnections();
this.repaintDelayed();
}});

Clazz.newMeth(C$, 'isInsideDragableThing$I$I', function (x, y) {
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t=e.nextElement();
if (!t.noDrag && t.isInsideThing$I$I(x, y) ) {
return true;
}}
return false;
});

Clazz.newMeth(C$, 'setFont$java_awt_Font', function (aFont) {
if (aFont == null ) return;
C$.superclazz.prototype.setFont$java_awt_Font.apply(this, [aFont]);
var derivedFont = Clazz.new_((I$[9]||$incl$(9)).c$$S$I$I,[aFont.getFamily(), 1, aFont.getSize() + 2]);
if (this.title == null ) return;
this.title.setFont$java_awt_Font(derivedFont);
this.xaxis.setTitleFont$java_awt_Font(aFont);
this.yaxis.setTitleFont$java_awt_Font(aFont);
derivedFont=Clazz.new_((I$[9]||$incl$(9)).c$$S$I$I,[aFont.getFamily(), 0, aFont.getSize() - 4]);
this.xaxis.setLabelFont$java_awt_Font(derivedFont);
this.yaxis.setLabelFont$java_awt_Font(derivedFont);
});

Clazz.newMeth(C$, 'setForeground$java_awt_Color', function (c) {
if (c == null ) return;
C$.superclazz.prototype.setForeground$java_awt_Color.apply(this, [c]);
if (this.xaxis == null ) return;
this.xaxis.setTitleColor$java_awt_Color(c);
this.xaxis.setLabelColor$java_awt_Color(c);
this.yaxis.setTitleColor$java_awt_Color(c);
this.yaxis.setLabelColor$java_awt_Color(c);
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setDataBackground$java_awt_Color', function (c) {
this.dataBackground=c;
C$.superclazz.prototype.setDataBackground$java_awt_Color.apply(this, [c]);
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setGraphBackground$java_awt_Color', function (c) {
if (c == null ) return;
if (this.xaxis != null ) this.xaxis.setTitleBackground$java_awt_Color(c);
if (this.yaxis != null ) this.yaxis.setTitleBackground$java_awt_Color(c);
this.setBackground$java_awt_Color(c);
});

Clazz.newMeth(C$, 'getDataBackground', function () {
return this.dataBackground;
});

Clazz.newMeth(C$, 'setSampleData$Z', function (sd) {
if (sd == this.sampleData ) return;
this.sampleData=sd;
if (sd) p$.makeSampleData$I.apply(this, [100]);
 else this.deleteAllSeries();
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'isSampleData', function () {
return this.sampleData;
});

Clazz.newMeth(C$, 'setDrawGrid$Z', function (dg) {
if (dg == this.drawgrid ) return;
this.drawgrid=dg;
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'isDrawGrid', function () {
return this.drawgrid;
});

Clazz.newMeth(C$, 'setAutoRefresh$Z', function (auto) {
if (auto == this.autoRefresh ) return;
this.autoRefresh=auto;
if (this.autoRefresh) {
this.repaintDelayed();
}});

Clazz.newMeth(C$, 'isAutoRefresh', function () {
return this.autoRefresh;
});

Clazz.newMeth(C$, 'setAutoscaleX$Z', function (as) {
if (!as == this.xaxis.isManualRange() ) return;
this.xaxis.setManualRange$Z(!as);
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'isAutoscaleX', function () {
return !this.xaxis.isManualRange();
});

Clazz.newMeth(C$, 'setAutoscaleY$Z', function (as) {
if (!as == this.yaxis.isManualRange() ) return;
this.yaxis.setManualRange$Z(!as);
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'isAutoscaleY', function () {
return !this.yaxis.isManualRange();
});

Clazz.newMeth(C$, 'setDrawZero$Z', function (dz) {
if (dz == this.drawzero ) return;
this.drawzero=dz;
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'isDrawZero', function () {
return this.drawzero;
});

Clazz.newMeth(C$, 'setSeriesLegend$I$java_awt_Color$I$I$S', function (sid, c, xpix, ypix, legend) {
var data;
var series = p$.getSeriesFromSID$I.apply(this, [sid]);
if (series == null ) {
this.dPoint[0]=0;
this.dPoint[1]=0;
data=p$.attachArray$I$DA.apply(this, [sid, this.dPoint]).getDataSet();
data.deleteData();
} else {
data=series.data;
}data.legend$I$I$S(xpix, ypix, legend);
if (c != null ) data.legendColor$java_awt_Color(c);
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'setSeriesLegend$I$I$I$S', function (sid, xpix, ypix, legend) {
var c = (I$[3]||$incl$(3)).black;
var series = this.createSeries$I(sid);
c=series.data.markercolor;
this.setSeriesLegend$I$java_awt_Color$I$I$S(sid, c, xpix, ypix, legend);
});

Clazz.newMeth(C$, 'setSeriesLegendColor$I$java_awt_Color', function (sid, c) {
var series = this.createSeries$I(sid);
series.data.legendColor$java_awt_Color(c);
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'colorOf$S', function (c) {
if (c.equals$O("black")) return (I$[3]||$incl$(3)).black;
 else if (c.equals$O("blue")) return (I$[3]||$incl$(3)).blue;
 else if (c.equals$O("cyan")) return (I$[3]||$incl$(3)).cyan;
 else if (c.equals$O("darkGray")) return (I$[3]||$incl$(3)).darkGray;
 else if (c.equals$O("gray")) return (I$[3]||$incl$(3)).gray;
 else if (c.equals$O("green")) return (I$[3]||$incl$(3)).green;
 else if (c.equals$O("lightGray")) return (I$[3]||$incl$(3)).lightGray;
 else if (c.equals$O("magenta")) return (I$[3]||$incl$(3)).magenta;
 else if (c.equals$O("orange")) return (I$[3]||$incl$(3)).orange;
 else if (c.equals$O("pink")) return (I$[3]||$incl$(3)).pink;
 else if (c.equals$O("red")) return (I$[3]||$incl$(3)).red;
 else if (c.equals$O("white")) return (I$[3]||$incl$(3)).white;
 else if (c.equals$O("yellow")) return (I$[3]||$incl$(3)).yellow;
 else return (I$[3]||$incl$(3)).white;
}, 1);

Clazz.newMeth(C$, 'setSeriesStyle$I$S$Z$I', function (sid, colorName, conPts, m) {
this.setSeriesStyle$I$java_awt_Color$Z$I(sid, C$.colorOf$S(colorName), conPts, m);
});

Clazz.newMeth(C$, 'setSeriesStyle$I$S$Z$I$D', function (sid, colorName, conPts, m, size) {
this.setSeriesStyle$I$java_awt_Color$Z$I$D(sid, C$.colorOf$S(colorName), conPts, m, size);
});

Clazz.newMeth(C$, 'setSeriesStyle$I$java_awt_Color$Z$I$D', function (sid, c, conPts, m, size) {
var data;
var series = p$.getSeriesFromSID$I.apply(this, [sid]);
if (series == null ) {
this.dPoint[0]=0;
this.dPoint[1]=0;
data=p$.attachArray$I$DA.apply(this, [sid, this.dPoint]).getDataSet();
data.deleteData();
} else {
data=series.data;
}if (conPts) data.linestyle=1;
 else data.linestyle=0;
data.marker=m;
data.markerscale=size;
data.markercolor=c;
data.linecolor=c;
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'setSeriesStyle$I$java_awt_Color$Z$I', function (sid, c, conPts, m) {
var data;
var series = p$.getSeriesFromSID$I.apply(this, [sid]);
if (series == null ) {
this.dPoint[0]=0;
this.dPoint[1]=0;
data=p$.attachArray$I$DA.apply(this, [sid, this.dPoint]).getDataSet();
data.deleteData();
} else {
data=series.data;
}if (conPts) data.linestyle=1;
 else data.linestyle=0;
data.marker=m;
data.markercolor=c;
data.linecolor=c;
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'setSeriesStyle$I$Z$I', function (sid, conPts, m) {
var c = (I$[3]||$incl$(3)).black;
var series = this.createSeries$I(sid);
c=series.data.markercolor;
this.setSeriesStyle$I$java_awt_Color$Z$I(sid, c, conPts, m);
});

Clazz.newMeth(C$, 'setSeriesColor$I$java_awt_Color', function (sid, c) {
var series = this.createSeries$I(sid);
series.data.markercolor=c;
series.data.linecolor=c;
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'setSeriesSorted$I$Z', function (sid, sorted) {
var series = this.createSeries$I(sid);
series.data.setSorted$Z(sorted);
});

Clazz.newMeth(C$, 'setSeriesStripChart$I$I$Z', function (sid, chartpoints, stripchart) {
var series = this.createSeries$I(sid);
series.data.setStripChart$I$Z(chartpoints, stripchart);
});

Clazz.newMeth(C$, 'setSketchMode$Z', function (sm) {
var applet = (I$[11]||$incl$(11)).getApplet$java_awt_Component(this);
this.sketchImage=(I$[11]||$incl$(11)).getImage$S$a2s_Applet("pencil.gif", applet);
this.sketchMode=sm;
if (!sm) {
this.trailThing=null;
return 0;
}this.trailThing=Clazz.new_((I$[12]||$incl$(12)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I,[this.parentSApplet, this, 1]);
this.trailThing.trailSize=2000;
return this.trailThing.hashCode();
});

Clazz.newMeth(C$, 'setShowAxes$Z', function (sa) {
this.setShowAxis$Z(sa);
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'isShowAxes', function () {
return this.isShowAxis();
});

Clazz.newMeth(C$, 'setSquare$Z', function (isSquare) {
this.square=isSquare;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'isSquare', function () {
return this.square;
});

Clazz.newMeth(C$, 'getBorders', function () {
var b = "" + this.borders[0] + ',' + this.borders[1] + ',' + this.borders[2] + ',' + this.borders[3] ;
return b;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'getThing$I', function (id) {
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t=e.nextElement();
if (t.hashCode() == id) {
return t;
}}
return null;
});

Clazz.newMeth(C$, 'setBorders$S', function (s) {
var error = false;
var tokens = Clazz.new_((I$[13]||$incl$(13)).c$$S$S,[s.trim(), ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
if (tokens.countTokens() < 4) error=true;
 else for (var i = 0; i < 4; i++) {
try {
this.borders[i]=Integer.parseInt(tokens.nextToken().trim());
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
error=true;
} else {
throw e;
}
}
}
if (!error) {
this.borderLeft=this.borders[0];
this.borderTop=this.borders[1];
this.borderRight=this.borders[2];
this.borderBottom=this.borders[3];
if (this.autoRefresh) this.repaint();
} else {
this.borders[0]=this.borderLeft;
this.borders[1]=this.borderTop;
this.borders[2]=this.borderRight;
this.borders[3]=this.borderBottom;
}});

Clazz.newMeth(C$, 'setGutters$I$I$I$I', function (g1, g2, g3, g4) {
this.borderLeft=g1;
this.borderTop=g2;
this.borderRight=g3;
this.borderBottom=g4;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setLabelX$S', function (s) {
this.xaxis.setTitleColor$java_awt_Color(this.labelXTitleColor);
this.xaxis.setTitleText$S(s);
this.labelX=s;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setLabelX$S$java_awt_Color', function (s, c) {
this.labelXTitleColor=c;
this.xaxis.setTitleColor$java_awt_Color(c);
this.xaxis.setTitleText$S(s);
this.labelX=s;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'getLabelX', function () {
return this.labelX;
});

Clazz.newMeth(C$, 'getLabelXTitleColor', function () {
return this.labelXTitleColor;
});

Clazz.newMeth(C$, 'setLabelXTitleColor$java_awt_Color', function (c) {
this.labelXTitleColor=c;
this.xaxis.setTitleColor$java_awt_Color(c);
this.xaxis.setTitleText$S(this.labelX);
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'getLabelXColor', function () {
return this.labelXColor;
});

Clazz.newMeth(C$, 'setLabelXColor$java_awt_Color', function (c) {
this.labelXColor=c;
this.xaxis.setLabelColor$java_awt_Color(c);
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setLabelY$S', function (s) {
this.yaxis.setTitleColor$java_awt_Color(this.labelYTitleColor);
this.yaxis.setTitleText$S(s);
this.labelY=s;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setLabelY$S$java_awt_Color', function (s, c) {
this.labelYTitleColor=c;
this.yaxis.setTitleColor$java_awt_Color(c);
this.yaxis.setTitleText$S(s);
this.labelY=s;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'getLabelY', function () {
return this.labelY;
});

Clazz.newMeth(C$, 'getLabelYTitleColor', function () {
return this.labelYTitleColor;
});

Clazz.newMeth(C$, 'setLabelYTitleColor$java_awt_Color', function (c) {
this.labelYTitleColor=c;
this.yaxis.setTitleColor$java_awt_Color(c);
this.yaxis.setTitleText$S(this.labelY);
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'getLabelYColor', function () {
return this.labelYColor;
});

Clazz.newMeth(C$, 'setLabelYColor$java_awt_Color', function (c) {
this.labelYColor=c;
this.yaxis.setLabelColor$java_awt_Color(c);
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setLastPointMarker$I$Z', function (sid, lpm) {
var series = this.createSeries$I(sid);
series.enableLPCursor=lpm;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setAutoReplaceData$I$Z', function (sid, auto) {
var series = this.createSeries$I(sid);
series.autoReplace=auto;
});

Clazz.newMeth(C$, 'setAddRepeatedDatum$I$Z', function (sid, add) {
var series = this.createSeries$I(sid);
series.addRepeatedDatum=add;
});

Clazz.newMeth(C$, 'setMarkerSize$D', function (scale) {
this.defaultMarkerScale=scale;
});

Clazz.newMeth(C$, 'getMarkerSize', function () {
return this.defaultMarkerScale;
});

Clazz.newMeth(C$, 'setDefaultMarkerSize$D', function (size) {
this.defaultMarkerScale=size;
});

Clazz.newMeth(C$, 'getDefaultMarkerSize', function () {
return this.defaultMarkerScale;
});

Clazz.newMeth(C$, 'setAllMarkerSizes$D', function (scale) {
this.defaultMarkerScale=scale;
for (var i = 0; i < this.dataSetSeries.size(); i++) {
var s = this.dataSetSeries.elementAt$I(i);
s.data.markerscale=scale;
}
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setMarkerSize$I$D', function (sid, scale) {
var series = this.createSeries$I(sid);
series.data.markerscale=scale;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setMinMaxX$D$D', function (min, max) {
if (this.xaxis.isManualRange()) {
this.xaxis.setManualRange$Z$D$D(true, min, max);
} else {
this.xaxis.resetRange();
}if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setMinXRange$Z$D$D', function (enable, min, max) {
this.xaxis.setMinRange$Z$D$D(enable, min, max);
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setMinYRange$Z$D$D', function (enable, min, max) {
this.yaxis.setMinRange$Z$D$D(enable, min, max);
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setMinX$D', function (min) {
if (this.xaxis.isManualRange()) {
if (min > this.xaxis.maximum ) this.xaxis.setManualRange$Z$D$D(true, min, min + 1);
 else this.xaxis.setManualRange$Z$D$D(true, min, this.xaxis.maximum);
} else {
this.xaxis.resetRange();
}if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'getMinX', function () {
return this.xaxis.minimum;
});

Clazz.newMeth(C$, 'setMaxX$D', function (max) {
if (this.xaxis.isManualRange()) {
if (max < this.xaxis.minimum ) this.xaxis.setManualRange$Z$D$D(true, max - 1, max);
 else this.xaxis.setManualRange$Z$D$D(true, this.xaxis.minimum, max);
} else {
this.xaxis.resetRange();
}if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'getMaxX', function () {
return this.xaxis.maximum;
});

Clazz.newMeth(C$, 'setMinMaxY$D$D', function (min, max) {
if (this.yaxis.isManualRange()) {
this.yaxis.setManualRange$Z$D$D(true, min, max);
} else {
this.yaxis.resetRange();
}if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setMinY$D', function (min) {
if (this.yaxis.isManualRange()) {
if (min > this.yaxis.maximum ) this.yaxis.setManualRange$Z$D$D(true, min, min + 1);
 else this.yaxis.setManualRange$Z$D$D(true, min, this.yaxis.maximum);
} else {
this.yaxis.resetRange();
}if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'getMinY', function () {
return this.yaxis.minimum;
});

Clazz.newMeth(C$, 'setMaxY$D', function (max) {
if (this.yaxis.isManualRange()) {
if (max < this.yaxis.minimum ) this.yaxis.setManualRange$Z$D$D(true, max - 1, max);
 else this.yaxis.setManualRange$Z$D$D(true, this.yaxis.minimum, max);
} else {
this.yaxis.resetRange();
}if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'getMaxY', function () {
return this.yaxis.maximum;
});

Clazz.newMeth(C$, 'getDataSetFromSID$I', function (sid) {
var series;
var n = this.dataSetSeries.size();
for (var i = 0; i < n; i++) {
series=this.dataSetSeries.elementAt$I(i);
if (sid == series.sid) {
return series.data;
}}
return null;
});

Clazz.newMeth(C$, 'getFunction$I', function (id) {
var f = null;
var v;
{
v=this.functions.clone();
}for (var e = v.elements(); e.hasMoreElements(); ) {
f=e.nextElement();
if (f.hashCode() == id) {
return f;
}}
return null;
});

Clazz.newMeth(C$, 'getCFunction$I', function (id) {
var f = null;
var v;
{
v=this.cfunctions.clone();
}for (var e = v.elements(); e.hasMoreElements(); ) {
f=e.nextElement();
if (f.hashCode() == id) {
return f;
}}
return null;
});

Clazz.newMeth(C$, 'getFunctionId$I', function (pos) {
var v;
{
v=this.functions.clone();
}if ((pos < 1) || (pos > v.size()) ) return 0;
var f = v.elementAt$I(pos - 1);
return f.hashCode();
});

Clazz.newMeth(C$, 'getCFunctionId$I', function (pos) {
var v;
{
v=this.cfunctions.clone();
}if ((pos < 1) || (pos > v.size()) ) return 0;
var f = v.elementAt$I(pos - 1);
return f.hashCode();
});

Clazz.newMeth(C$, 'getSeriesFromSID$I', function (sid) {
var series;
for (var e = this.dataSetSeries.elements(); e.hasMoreElements(); ) {
series=e.nextElement();
if (sid == series.sid) {
return series;
}}
return null;
});

Clazz.newMeth(C$, 'getTitle', function () {
return this.titleStr;
});

Clazz.newMeth(C$, 'setTitle$S', function (str) {
this.titleStr=str;
this.title.setText$S(str);
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setTimeDisplay$Z', function (show) {
this.timeDisplay=show;
if (this.timeDisplay) this.parentSApplet.clock.addClockListener$edu_davidson_tools_SStepable(this);
 else this.parentSApplet.clock.removeClockListener$edu_davidson_tools_SStepable(this);
});

Clazz.newMeth(C$, 'getTitleColor', function () {
return this.titleColor;
});

Clazz.newMeth(C$, 'setTitleColor$java_awt_Color', function (c) {
this.titleColor=c;
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'getIDFromDataSet$edu_davidson_graph_DataSet', function (dset) {
var series;
var n = this.dataSetSeries.size();
for (var i = 0; i < n; i++) {
series=this.dataSetSeries.elementAt$I(i);
if (dset === series.data ) {
return series.hashCode();
}}
return 0;
});

Clazz.newMeth(C$, 'getIDFromSID$I', function (val) {
var series;
var n = this.dataSetSeries.size();
for (var i = 0; i < n; i++) {
series=this.dataSetSeries.elementAt$I(i);
if (val == series.sid) {
return series.hashCode();
}}
return 0;
});

Clazz.newMeth(C$, 'getRegressionID$I$I$I', function (sid, start, end) {
var series = this.createSeries$I(sid);
return series.getRegressionID$I$I(start, end);
});

Clazz.newMeth(C$, 'setObjectColor$I$java_awt_Color', function (id, c) {
var f = null;
var v;
if (id == 0 || id == this.hashCode() ) {
this.setDataBackground$java_awt_Color(c);
this.setGraphBackground$java_awt_Color(c);
return;
}{
v=this.functions.clone();
}for (var e = v.elements(); e.hasMoreElements(); ) {
f=e.nextElement();
if (f.hashCode() == id) {
f.color=c;
if (this.autoRefresh) this.repaint();
;}}
var s = null;
for (var e = this.dataSetSeries.elements(); e.hasMoreElements(); ) {
s=e.nextElement();
if (s.hashCode() == id) {
s.data.markercolor=c;
s.data.linecolor=c;
if (this.autoRefresh) this.repaint();
return;
}}
{
v=this.things.clone();
}for (var e = v.elements(); e.hasMoreElements(); ) {
var t = e.nextElement();
if (t.hashCode() == id) {
t.setColor$java_awt_Color(c);
if (this.autoRefresh) this.repaint();
return;
}}
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
this.parentSApplet=owner;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.parentSApplet;
});

Clazz.newMeth(C$, 'getPixWidth', function () {
return this.getSize().width;
});

Clazz.newMeth(C$, 'getPixHeight', function () {
return this.getSize().height;
});

Clazz.newMeth(C$, 'deleteAllFunctions', function () {
var v;
{
v=this.functions.clone();
this.functions.removeAllElements();
}for (var e = v.elements(); e.hasMoreElements(); ) {
var f = e.nextElement();
this.parentSApplet.removeDataSource$I(f.hashCode());
if (f.explicitTime) this.parentSApplet.clock.removeClockListener$edu_davidson_tools_SStepable(f);
}
{
v=this.cfunctions.clone();
this.cfunctions.removeAllElements();
}for (var e = v.elements(); e.hasMoreElements(); ) {
var f = e.nextElement();
this.parentSApplet.removeDataSource$I(f.hashCode());
if (f.explicitTime) this.parentSApplet.clock.removeClockListener$edu_davidson_tools_SStepable(f);
}
this.repaintDelayed();
});

Clazz.newMeth(C$, 'deleteObject$I', function (id) {
if (p$.deleteThing$I.apply(this, [id])) return;
if (this.deleteFunction$I(id)) return;
this.deleteSeries$I(id);
});

Clazz.newMeth(C$, 'deleteThing$I', function (id) {
var t = null;
t=this.getThing$I(id);
if (t == null ) return false;
if (this.parentSApplet != null ) this.parentSApplet.stopClock();
this.things.removeElement$O(t);
if (this.parentSApplet != null ) {
this.parentSApplet.removeDataSource$I(t.hashCode());
this.parentSApplet.removeDataListener$I(t.hashCode());
if (Clazz.instanceOf(t, "edu.davidson.tools.SStepable")) this.parentSApplet.clock.removeClockListener$edu_davidson_tools_SStepable(t);
this.parentSApplet.cleanupDataConnections();
}if (this.autoRefresh) this.repaintDelayed();
return true;
});

Clazz.newMeth(C$, 'deleteFunction$I', function (id) {
var functionFound = false;
{
for (var e = this.functions.elements(); e.hasMoreElements(); ) {
var f = e.nextElement();
if (f.hashCode() == id) {
functionFound=true;
this.parentSApplet.removeDataSource$I(f.hashCode());
this.functions.removeElement$O(f);
if (f.explicitTime) this.parentSApplet.clock.removeClockListener$edu_davidson_tools_SStepable(f);
break;
}}
}{
for (var e = this.cfunctions.elements(); e.hasMoreElements(); ) {
var f = e.nextElement();
if (f.hashCode() == id) {
functionFound=true;
this.parentSApplet.removeDataSource$I(f.hashCode());
this.cfunctions.removeElement$O(f);
if (f.explicitTime) this.parentSApplet.clock.removeClockListener$edu_davidson_tools_SStepable(f);
break;
}}
}if (this.autoRefresh) this.repaintDelayed();
return functionFound;
});

Clazz.newMeth(C$, 'deleteAllSeries', function () {
this.clearAllThings();
for (var e = this.dataSetSeries.elements(); e.hasMoreElements(); ) {
var s = e.nextElement();
if (s == null ) continue;
if (s.regression != null ) (I$[1]||$incl$(1)).dataSources.remove$O(Integer.toString(s.regression.hashCode()));
(I$[1]||$incl$(1)).dataSources.remove$O(Integer.toString(s.hashCode()));
}
this.dataSetSeries.removeAllElements();
this.detachDataSets();
if (this.parentSApplet != null ) this.parentSApplet.cleanupDataConnections();
if (!this.xaxis.isManualRange()) this.setMinMaxX$D$D(0, 1);
if (!this.yaxis.isManualRange()) this.setMinMaxY$D$D(0, 1);
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'deleteAllNonSeriesData', function () {
for (var e = this.dataset.elements(); e.hasMoreElements(); ) {
var dset = e.nextElement();
var id = this.getIDFromDataSet$edu_davidson_graph_DataSet(dset);
if (id == 0) this.detachDataSet$edu_davidson_graph_DataSet(dset);
}
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'deleteSeries$I', function (id) {
this.deleteSeries$I$Z(id, true);
});

Clazz.newMeth(C$, 'deleteSeries$I$Z', function (id, willRepaint) {
var series;
var n = this.dataSetSeries.size();
for (var i = 0; i < n; i++) {
series=this.dataSetSeries.elementAt$I(i);
if (id == series.sid) {
if (series.regression != null ) (I$[1]||$incl$(1)).dataSources.remove$O(Integer.toString(series.regression.hashCode()));
(I$[1]||$incl$(1)).dataSources.remove$O(Integer.toString(series.hashCode()));
this.dataSetSeries.removeElement$O(series);
this.detachDataSet$edu_davidson_graph_DataSet(series.data);
break;
}}
if (this.dataSetSeries.size() == 0) {
this.detachDataSets();
}if (this.parentSApplet != null ) this.parentSApplet.cleanupDataConnections();
if (willRepaint && this.autoRefresh ) this.repaint();
});

Clazz.newMeth(C$, 'setFunctionRange$I$D$D$I', function (id, xmin, xmax, n) {
var f = null;
for (var e = this.functions.elements(); e.hasMoreElements(); ) {
f=e.nextElement();
if (f.hashCode() == id) {
f.setFunctionRange$D$D$I(xmin, xmax, n);
}}
var cf = null;
for (var e = this.cfunctions.elements(); e.hasMoreElements(); ) {
cf=e.nextElement();
if (cf.hashCode() == id) {
cf.setFunctionRange$D$D(xmin, xmax);
}}
if (this.parentSApplet != null ) {
if (this.parentSApplet.destroyed) return;
this.parentSApplet.updateDataConnection$I(f.hashCode());
}this.repaintDelayed();
});

Clazz.newMeth(C$, 'setFunctionClip$I$D$D', function (id, min, max) {
var f = null;
for (var e = this.functions.elements(); e.hasMoreElements(); ) {
f=e.nextElement();
if (f.hashCode() == id) {
f.setFunctionClip$D$D(min, max);
}}
if (this.parentSApplet != null ) {
if (this.parentSApplet.destroyed) return;
this.parentSApplet.updateDataConnection$I(f.hashCode());
}this.repaintDelayed();
});

Clazz.newMeth(C$, 'setYScaleFromFunction$I', function (id) {
for (var e = this.functions.elements(); e.hasMoreElements(); ) {
var f = e.nextElement();
if (f.hashCode() == id) {
this.setMinMaxY$D$D(f.ymin, f.ymax);
}}
for (var e = this.cfunctions.elements(); e.hasMoreElements(); ) {
var f = e.nextElement();
if (f.hashCode() == id) {
this.setMinMaxY$D$D(f.ymin, f.ymax);
}}
this.repaintDelayed();
});

Clazz.newMeth(C$, 'setFunctionString$I$S', function (id, str) {
var fun = this.getFunction$I(id);
if (fun == null ) return false;
if (!fun.setString$S(str)) return false;
fun.setScale();
if (this.parentSApplet != null ) {
if (this.parentSApplet.destroyed) return false;
this.parentSApplet.updateDataConnection$I(fun.hashCode());
}this.repaintDelayed();
return true;
});

Clazz.newMeth(C$, 'setCFunctionStrings$I$S$S', function (id, strRe, strIm) {
var fun = this.getCFunction$I(id);
if (fun == null ) return false;
if (!fun.setStringRe$S(strRe)) return false;
if (!fun.setStringIm$S(strIm)) return false;
fun.setScale();
if (this.parentSApplet != null ) {
if (this.parentSApplet.destroyed) return false;
this.parentSApplet.updateDataConnection$I(fun.hashCode());
}this.repaintDelayed();
return true;
});

Clazz.newMeth(C$, 'getFunctionString$I', function (id) {
var fun = this.getFunction$I(id);
if (fun == null ) return "";
return fun.getFunctionStr();
});

Clazz.newMeth(C$, 'getReFunctionString$I', function (id) {
var fun = this.getCFunction$I(id);
if (fun == null ) return "";
return fun.getFunctionStrRe();
});

Clazz.newMeth(C$, 'getImFunctionString$I', function (id) {
var fun = this.getCFunction$I(id);
if (fun == null ) return "";
return fun.getFunctionStrIm();
});

Clazz.newMeth(C$, 'setFunctionVariable$I$S', function (id, str) {
var fun = this.getFunction$I(id);
if (fun == null ) return false;
fun.setVariable$S(str);
return true;
});

Clazz.newMeth(C$, 'setFunction$I$S$S', function (id, $var, str) {
var fun = this.getFunction$I(id);
if (fun == null ) return false;
if (!fun.setString$S(str)) return false;
fun.setVariable$S($var);
fun.setScale();
if (this.parentSApplet != null ) {
if (this.parentSApplet.destroyed) return false;
this.parentSApplet.updateDataConnection$I(fun.hashCode());
}this.repaintDelayed();
return true;
});

Clazz.newMeth(C$, 'clone', function () {
var g = Clazz.new_(C$.c$$edu_davidson_tools_SApplet,[this.parentSApplet]);
g.autoRefresh=this.autoRefresh;
g.setSampleData$Z(false);
g.setTitle$S(this.titleStr);
g.setTitleColor$java_awt_Color(this.titleColor);
g.setAutoscaleX$Z(this.isAutoscaleX());
g.setAutoscaleY$Z(this.isAutoscaleY());
g.setLabelX$S$java_awt_Color(this.labelX, this.labelXTitleColor);
g.setLabelY$S$java_awt_Color(this.labelY, this.labelYTitleColor);
g.setLabelXColor$java_awt_Color(this.labelXColor);
g.setLabelYColor$java_awt_Color(this.labelYColor);
g.setMinMaxX$D$D(this.getMinX(), this.getMaxX());
g.setMinMaxY$D$D(this.getMinY(), this.getMaxY());
g.defaultMarkerScale=this.defaultMarkerScale;
g.drawgrid=this.isDrawGrid();
g.drawzero=this.isDrawZero();
g.setEnableMouse$Z(this.enableMouse);
g.setEnableClone$Z(false);
g.setEnableCoordDisplay$Z(this.enableCoordDisplay);
g.deleteAllSeries();
for (var i = 0; i < this.dataSetSeries.size(); i++) {
var s = this.dataSetSeries.elementAt$I(i);
g.addDataSeries$edu_davidson_display_SGraph_Series(s);
g.setLastPointMarker$I$Z(s.sid, s.enableLPCursor);
}
g.deleteAllFunctions();
var f;
for (var e = this.functions.elements(); e.hasMoreElements(); ) {
f=e.nextElement();
var id = g.addFunction$S$S(f.variable, f.getFunctionStr());
g.setFunctionRange$I$D$D$I(id, f.xmin, f.xmax, f.numPts);
g.setFunctionClip$I$D$D(id, f.minClip, f.maxClip);
g.setObjectColor$I$java_awt_Color(id, f.color);
}
var cf;
for (var e = this.cfunctions.elements(); e.hasMoreElements(); ) {
cf=e.nextElement();
var id = g.addCFunction$S$S$S$Z(cf.variable, cf.getFunctionStrRe(), cf.getFunctionStrRe(), cf.centered);
g.setFunctionRange$I$D$D$I(id, cf.xmin, cf.xmax, 400);
g.setObjectColor$I$java_awt_Color(id, cf.color);
}
var tempx = g.xaxis.manualRange;
g.xaxis.manualRange=true;
var tempy = g.yaxis.manualRange;
g.yaxis.manualRange=true;
g.setMinMaxX$D$D(this.xaxis.minimum, this.xaxis.maximum);
g.setMinMaxY$D$D(this.yaxis.minimum, this.yaxis.maximum);
g.xaxis.manualRange=tempx;
g.yaxis.manualRange=tempy;
return g;
});

Clazz.newMeth(C$, 'createSeries$I', function (sid) {
var series = p$.getSeriesFromSID$I.apply(this, [sid]);
if (series == null ) series=p$.makeEmptySeries$I.apply(this, [sid]);
return series;
});

Clazz.newMeth(C$, 'clearAllData', function () {
var series;
var n = this.dataSetSeries.size();
for (var i = 0; i < n; i++) {
series=this.dataSetSeries.elementAt$I(i);
series.data.deleteData();
}
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'clearSeries$I', function (s) {
this.clearSeriesData$I(s);
});

Clazz.newMeth(C$, 'clearAllSeries', function () {
var series;
var n = this.dataSetSeries.size();
for (var i = 0; i < n; i++) {
series=this.dataSetSeries.elementAt$I(i);
series.data.deleteData();
series.setOwner$edu_davidson_tools_SApplet(this.parentSApplet);
}
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'clearSeriesData$I', function (sid) {
var series;
var n = this.dataSetSeries.size();
for (var i = 0; i < n; i++) {
series=this.dataSetSeries.elementAt$I(i);
if (sid == series.sid && !series.autoReplace ) {
series.data.deleteData();
series.setOwner$edu_davidson_tools_SApplet(this.parentSApplet);
if (this.autoRefresh) this.repaintDelayed();
break;
}}
});

Clazz.newMeth(C$, 'adjustScale', function () {
if (this.yaxis.isManualRange()) return;
var ymin = this.yaxis.minimum;
var ymax = this.yaxis.maximum;
var f;
var v;
{
v=this.functions.clone();
}for (var e = v.elements(); e.hasMoreElements(); ) {
f=e.nextElement();
ymin=Math.min(f.ymin, ymin);
ymax=Math.max(f.ymax, ymax);
}
var cf;
{
v=this.cfunctions.clone();
}for (var e = v.elements(); e.hasMoreElements(); ) {
cf=e.nextElement();
ymin=Math.min(cf.ymin, ymin);
ymax=Math.max(cf.ymax, ymax);
}
if (ymin == ymax ) {
ymin -= 0.5;
ymax += 0.5;
}this.yaxis.minimum=ymin;
this.yaxis.maximum=ymax;
this.yaxis.calculateGridLabels();
});

Clazz.newMeth(C$, 'paintFunctions$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var f;
{
for (var e = this.functions.elements(); e.hasMoreElements(); ) {
f=e.nextElement();
f.paint$java_awt_Graphics$java_awt_Rectangle(g, r);
}
}var cf;
{
for (var e = this.cfunctions.elements(); e.hasMoreElements(); ) {
cf=e.nextElement();
cf.paint$java_awt_Graphics$java_awt_Rectangle(g, r);
}
}});

Clazz.newMeth(C$, 'repaint', function () {
if (this.delayLock == null ) {
this.newData=true;
return;
}this.repaintDelayed();
});

Clazz.newMeth(C$, 'startPaintThread', function () {
if (this.delayThread != null ) return;
this.interrupted=false;
this.delayThread=Clazz.new_((I$[10]||$incl$(10)).c$$Runnable,[this]);
this.newData=true;
this.delayThread.start();
});

Clazz.newMeth(C$, 'destroy', function () {
this.interrupted=true;
if (this.delayThread == null ) return;
this.repaintDelayed();
var temp = this.delayThread;
if (temp != null ) try {
temp.interrupt();
temp.join$J(100);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
this.delayThread=null;
});

Clazz.newMeth(C$, 'repaintDelayed', function () {
this.paintOffScreen();
});

Clazz.newMeth(C$, 'run', function () {
while (!this.interrupted){
{
if (!this.newData) try {
if (!this.isJS) this.delayLock.wait();
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
return;
} else {
throw ie;
}
}
this.newData=false;
if (!this.interrupted) this.paintOffScreen();
}{
return
}
}
});

Clazz.newMeth(C$, 'paintOffScreen$java_awt_Graphics', function (g) {
if (this.parentSApplet != null  && this.parentSApplet.destroyed ) return;
var w = this.getSize().width;
var h = this.getSize().height;
if (w < 10 || h < 10 ) {
g.fillRect$I$I$I$I(0, 0, w, h);
return;
}if (this.offScreenImage == null  || this.offScreenImage.getWidth$java_awt_image_ImageObserver(this) != w  || this.offScreenImage.getHeight$java_awt_image_ImageObserver(this) != h ) this.offScreenImage=this.createImage$I$I(w, h);
if (this.offScreenImage == null ) return;
{
var osg = this.offScreenImage.getGraphics();
if (this.parentSApplet != null  && this.parentSApplet.destroyed ) return;
this.update$java_awt_Graphics(osg);
g.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(this.offScreenImage, 0, 0, w, h, this);
if (this.$mouseDrag) this.drawCoords$I$I(this.mouseX, this.mouseY);
osg.dispose();
var tk = (I$[14]||$incl$(14)).getDefaultToolkit();
tk.sync();
}});

Clazz.newMeth(C$, 'paintOffScreen', function () {
var g = this.getGraphics();
if (g == null ) return;
if (g == null ) {
this.repaint();
return;
}this.paintOffScreen$java_awt_Graphics(g);
g.dispose();
});

Clazz.newMeth(C$, 'paintBeforeData$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
if (!this.hasGraphThing) return;
var s;
var v;
{
v=this.things.clone();
}for (var e = v.elements(); e.hasMoreElements(); ) {
var t = e.nextElement();
if (Clazz.instanceOf(t, "edu.davidson.display.GraphThing")) return;
t.paint$java_awt_Graphics(g);
}
});

Clazz.newMeth(C$, 'paintLast$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var s;
var v;
var paintOn = false;
{
v=this.things.clone();
}for (var e = v.elements(); e.hasMoreElements(); ) {
var t = e.nextElement();
if (Clazz.instanceOf(t, "edu.davidson.display.GraphThing")) paintOn=true;
if (!this.hasGraphThing || paintOn ) t.paint$java_awt_Graphics(g);
}
for (var e = this.dataSetSeries.elements(); e.hasMoreElements(); ) {
s=e.nextElement();
s.paintLastPoint$java_awt_Graphics$java_awt_Rectangle(g, r);
}
if (this.titleStr != null ) {
g.setColor$java_awt_Color(this.titleColor);
this.title.draw$java_awt_Graphics$I$I$I(g, r.x + (r.width/2|0), r.y + Math.max(10 + (r.height/20|0), 16), 0);
}if (this.timeDisplay) this.paintTime$java_awt_Graphics$java_awt_Rectangle(g, r);
});

Clazz.newMeth(C$, 'paintTime$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
if (!this.timeDisplay || this.parentSApplet == null  ) return;
var rc = Clazz.new_((I$[15]||$incl$(15)).c$$I$I$I$I,[0, 0, this.getBounds().width, this.getBounds().height]);
g.setClip$java_awt_Shape(rc);
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
var f = g.getFont();
g.setFont$java_awt_Font(this.boldFont);
var tStr = Clazz.new_((I$[6]||$incl$(6)).c$$S,["%7.4g"]).form$D((I$[16]||$incl$(16)).chop$D$D(this.parentSApplet.clock.getTime(), 1.0E-12));
g.drawString$S$I$I(this.label_time + tStr, 10, this.getBounds().height - 5);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$, 'pixFromX$D', function (x) {
var pix;
try {
pix=this.xaxis.getInteger$D(x);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
return 0;
} else {
throw e;
}
}
return pix;
});

Clazz.newMeth(C$, 'pixFromY$D', function (y) {
var pix;
try {
pix=this.yaxis.getInteger$D(y);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
return 0;
} else {
throw e;
}
}
return pix;
});

Clazz.newMeth(C$, 'xFromPix$I', function (x) {
var val;
try {
val=this.xaxis.getDouble$I(x);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
return 0;
} else {
throw e;
}
}
return val;
});

Clazz.newMeth(C$, 'yFromPix$I', function (y) {
var val;
try {
val=this.yaxis.getDouble$I(y);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
return 0;
} else {
throw e;
}
}
return val;
});

Clazz.newMeth(C$, 'addDataSet$DA$I', function (points, np) {
var data = this.loadDataSet$DA$I(points, np);
this.xaxis.attachDataSet$edu_davidson_graph_DataSet(data);
this.yaxis.attachDataSet$edu_davidson_graph_DataSet(data);
return data;
});

Clazz.newMeth(C$, 'addDataSeries$edu_davidson_display_SGraph_Series', function (s) {
var data = null;
this.addData$I$DA$DA$I(s.sid, s.getX(), s.getY(), s.getNumpts());
data=p$.getDataSetFromSID$I.apply(this, [s.sid]);
if (data == null ) {
System.out.println$S("Error: DataSet not created in SGraph.addDataSetSeries.");
return null;
}data.markercolor=s.getDataSet().markercolor;
data.linestyle=s.getDataSet().linestyle;
data.linecolor=s.getDataSet().linecolor;
data.markercolor=s.getDataSet().markercolor;
data.markerscale=s.getDataSet().markerscale;
data.marker=s.getDataSet().marker;
data.legend$I$I$S(s.getDataSet().getLegend_ix(), s.getDataSet().getLegend_iy(), s.getDataSet().getLegend());
data.legendColor$java_awt_Color(s.getDataSet().linecolor);
return data;
});

Clazz.newMeth(C$, 'addDatum$I$D$D', function (sid, x, y) {
var series = p$.getSeriesFromSID$I.apply(this, [sid]);
this.dPoint[0]=x;
this.dPoint[1]=y;
if (series == null ) {
series=p$.attachArray$I$DA.apply(this, [sid, this.dPoint]);
} else {
try {
if (series.addRepeatedDatum) series.data.append$DA$I(this.dPoint, 1);
 else {
var datum = series.getLastPoint();
if (datum == null  || datum[0] != x   || datum[1] != y  ) {
series.data.append$DA$I(this.dPoint, 1);
}}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Error appending Data!");
} else {
throw e;
}
}
}if (!this.autoRefresh) return;
this.repaintDelayed();
});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (ds, id, x, y) {
this.addDatum$I$D$D(id, x, y);
});

Clazz.newMeth(C$, 'clearAllThings', function () {
var v;
{
v=this.things.clone();
this.things.removeAllElements();
}this.hasGraphThing=false;
var t;
for (var e = v.elements(); e.hasMoreElements(); ) {
t=e.nextElement();
if (t == null ) continue;
this.parentSApplet.removeDataListener$I(t.hashCode());
this.parentSApplet.removeDataSource$I(t.hashCode());
if (Clazz.instanceOf(t, "edu.davidson.tools.SStepable")) this.parentSApplet.clock.removeClockListener$edu_davidson_tools_SStepable(t);
}
});

Clazz.newMeth(C$, 'addCursor$edu_davidson_tools_SApplet$I$D$D', function (owner, diameter, x, y) {
var t = Clazz.new_((I$[17]||$incl$(17)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D,[owner, this, diameter, x, y]);
this.things.addElement$TE(t);
if (this.autoRefresh) this.repaint();
return t.hashCode();
});

Clazz.newMeth(C$, 'addConnectorLine$edu_davidson_tools_SApplet$I$I', function (owner, id1, id2) {
var t1 = this.getThing$I(id1);
var t2 = this.getThing$I(id2);
var t = Clazz.new_((I$[18]||$incl$(18)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$edu_davidson_display_Thing$edu_davidson_display_Thing,[owner, this, t1, t2]);
this.things.addElement$TE(t);
if (this.autoRefresh) this.repaint();
return t.hashCode();
});

Clazz.newMeth(C$, 'swapZOrder$I$I', function (id1, id2) {
var t1 = this.getThing$I(id1);
var t2 = this.getThing$I(id2);
if ((t1 == null ) || (t2 == null ) ) {
return false;
}var index1 = this.things.indexOf$O(t1);
var index2 = this.things.indexOf$O(t2);
this.things.removeElementAt$I(index1);
this.things.insertElementAt$TE$I(t2, index1);
this.things.removeElementAt$I(index2);
this.things.insertElementAt$TE$I(t1, index2);
return true;
});

Clazz.newMeth(C$, 'addThing$edu_davidson_display_Thing', function (t) {
if (Clazz.instanceOf(t, "edu.davidson.display.GraphThing")) this.hasGraphThing=true;
this.things.addElement$TE(t);
if (this.autoRefresh) this.repaint();
return t.hashCode();
});

Clazz.newMeth(C$, 'addData$I$DA$DA', function (sid, x, y) {
this.addData$I$DA$DA$I(sid, x, y, x.length);
return;
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (ds, sid, x, y) {
var i;
var j;
var np;
if (x == null  || y == null   || (x.length != y.length)  || x.length == 0 ) {
if (p$.getSeriesFromSID$I.apply(this, [sid]) == null ) p$.makeEmptySeries$I.apply(this, [sid]);
return;
}np=x.length;
var series = p$.getSeriesFromSID$I.apply(this, [sid]);
var points = Clazz.array(Double.TYPE, [2 * np]);
for (i=j=0; i < np; i++, j+=2) {
points[j]=x[i];
points[j + 1]=y[i];
}
if (series == null ) {
series=p$.attachArray$I$DA.apply(this, [sid, points]);
} else {
try {
series.data.replace$DA$I(points, np);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Error appending Data!");
} else {
throw e;
}
}
}if (this.autoRefresh) this.repaintDelayed();
return;
});

Clazz.newMeth(C$, 'addData$I$DA$DA$I', function (sid, x, y, num) {
var i;
var j;
var np;
if (x == null  || y == null   || (x.length != y.length)  || num == 0 ) {
if (p$.getSeriesFromSID$I.apply(this, [sid]) == null ) p$.makeEmptySeries$I.apply(this, [sid]);
return;
}np=x.length;
if (np > num) np=num;
var series = p$.getSeriesFromSID$I.apply(this, [sid]);
var points = Clazz.array(Double.TYPE, [2 * np]);
for (i=j=0; i < np; i++, j+=2) {
points[j]=x[i];
points[j + 1]=y[i];
}
if (series == null ) {
series=p$.attachArray$I$DA.apply(this, [sid, points]);
} else {
try {
if (series.autoReplace) {
series.data.replace$DA$I(points, np);
this.repaintDelayed();
return;
} else series.data.append$DA$I(points, np);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Error appending Data!");
} else {
throw e;
}
}
}if (this.autoRefresh) this.repaintDelayed();
return;
});

Clazz.newMeth(C$, 'addFunction$S$S', function (indVar, str) {
var func = Clazz.new_((I$[19]||$incl$(19)).c$$S$S, [this, null, indVar, str]);
{
this.functions.addElement$TE(func);
if (this.datarect != null  && this.datarect.width > 20 ) {
var r = this.datarect;
func.xmin=this.xFromPix$I(r.x);
func.xmax=this.xFromPix$I(r.x + r.width - 1);
func.numPts=r.width;
func.setScale();
} else {
func.xmin=-1;
func.xmax=1;
func.numPts=200;
func.setScale();
}}if (this.autoRefresh) this.repaintDelayed();
return func.hashCode();
});

Clazz.newMeth(C$, 'addVectorField$S$S$I', function (strFx, strFy, gridSize) {
var field = Clazz.new_((I$[20]||$incl$(20)).c$$S$S$I, [this, null, strFx, strFy, gridSize]);
this.things.addElement$TE(field);
this.repaintDelayed();
return field.hashCode();
});

Clazz.newMeth(C$, 'addCFunction$S$S$S$Z', function (indVar, strRe, strIm, centered) {
var func = Clazz.new_((I$[21]||$incl$(21)).c$$S$S$S, [this, null, indVar, strRe, strIm]);
func.centered=centered;
{
this.cfunctions.addElement$TE(func);
if (this.datarect != null  && this.datarect.width > 20 ) {
var r = this.datarect;
func.xmin=this.xFromPix$I(r.x);
func.xmax=this.xFromPix$I(r.x + r.width - 1);
func.setScale();
} else {
func.xmin=-1;
func.xmax=1;
func.setScale();
}}if (this.autoRefresh) this.repaintDelayed();
return func.hashCode();
});

Clazz.newMeth(C$, 'addFunction$S', function (str) {
return this.addFunction$S$S("x", str);
});

Clazz.newMeth(C$, 'loadFile$I$S', function (series, file) {
var error = false;
var applet = this.parentSApplet;
if (applet == null ) applet=(I$[11]||$incl$(11)).getApplet$java_awt_Component(this);
if (applet == null ) {
System.out.println$S("File load failed. Applet not found.");
return;
}var temp = this.autoRefresh;
this.autoRefresh=false;
this.clearSeries$I(series);
try {
var is = Clazz.new_((I$[22]||$incl$(22)).c$$java_net_URL$S,[applet.getCodeBase(), file]).openStream();
this.readFile$I$java_io_InputStream(series, is);
is.close();
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
error=true;
} else {
throw ex;
}
}
if (error) try {
var is = Clazz.new_((I$[22]||$incl$(22)).c$$java_net_URL$S,[applet.getDocumentBase(), file]).openStream();
this.readFile$I$java_io_InputStream(series, is);
is.close();
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
System.out.println$S("file load failed: " + ex.getMessage());
return;
} else {
throw ex;
}
}
this.autoRefresh=temp;
if (this.autoRefresh) this.repaintDelayed();
});

Clazz.newMeth(C$, 'readFile$I$java_io_InputStream', function (series, is) {
var x;
var y;
var st = Clazz.new_((I$[23]||$incl$(23)).c$$java_io_InputStream,[is]);
st.eolIsSignificant$Z(true);
st.commentChar$I("#".$c());
scan : while (st.ttype != -1){
switch (st.nextToken()) {
default:
break scan;
case 10:
break;
case -3:
if ("series".equals$O(st.sval)) {
st.nextToken();
series=(st.nval|0);
this.clearSeries$I(series);
break;
}case -2:
x=st.nval;
st.nextToken();
y=st.nval;
this.addDatum$I$D$D(series, x, y);
break;
}
while (st.ttype != 10 && st.ttype != -1 )st.nextToken();

}
});

Clazz.newMeth(C$, 'plotRegression$I$I$I', function (sid, start, end) {
var str;
var m = 2;
var b = 0.5;
var s = p$.getSeriesFromSID$I.apply(this, [sid]);
var regVars = s.getSlopeIntercept$I$I(start, end);
m=regVars[0];
b=regVars[1];
if (b >= 0 ) str="" + new Double(m).toString() + "*x+" + new Double(b).toString() ;
 else str="" + new Double(m).toString() + "*x-" + new Double(Math.abs(b)).toString() ;
return this.addFunction$S$S("x", str);
});

Clazz.newMeth(C$, 'drawCoords$java_awt_Graphics$I$I', function (g, xPix, yPix) {
if (!this.enableCoordDisplay) return;
var msg = "" + this.format.form$D(this.xFromPix$I(xPix)) + " , " + this.format.form$D(this.yFromPix$I(yPix)) ;
var r = this.getBounds();
g.setColor$java_awt_Color((I$[3]||$incl$(3)).yellow);
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
this.boxWidth=Math.max(20 + fm.stringWidth$S(msg), this.boxWidth);
g.fillRect$I$I$I$I(0, r.height - 20, this.boxWidth, 20);
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
g.drawString$S$I$I(msg, 10, r.height - 5);
});

Clazz.newMeth(C$, 'drawCoords$I$I', function (xPix, yPix) {
var g = this.getGraphics();
this.drawCoords$java_awt_Graphics$I$I(g, xPix, yPix);
g.dispose();
});

Clazz.newMeth(C$, 'isEnableCoordDisplay', function () {
return this.enableCoordDisplay;
});

Clazz.newMeth(C$, 'setEnableCoordDisplay$Z', function (ecd) {
this.enableCoordDisplay=ecd;
});

Clazz.newMeth(C$, 'isEnableClone', function () {
return this.enableClone;
});

Clazz.newMeth(C$, 'setEnableClone$Z', function (ec) {
this.enableClone=ec;
});

Clazz.newMeth(C$, 'isEnableMouse', function () {
return this.enableMouse;
});

Clazz.newMeth(C$, 'setEnableMouse$Z', function (em) {
if (this.enableMouse == em ) return;
this.enableMouse=em;
if (this.enableMouse) {
this.addMouseMotionListener$java_awt_event_MouseMotionListener(this.mouseMotionAdapter=Clazz.new_((I$[24]||$incl$(24)).c$$edu_davidson_display_SGraph,[this]));
this.addMouseListener$java_awt_event_MouseListener(this.mouseAdapter=Clazz.new_((I$[25]||$incl$(25)).c$$edu_davidson_display_SGraph,[this]));
} else {
this.removeMouseMotionListener$java_awt_event_MouseMotionListener(this.mouseMotionAdapter);
this.removeMouseListener$java_awt_event_MouseListener(this.mouseAdapter);
}});

Clazz.newMeth(C$, 'setParentSApplet$edu_davidson_tools_SApplet', function (p) {
this.parentSApplet=p;
});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
this.format=Clazz.new_((I$[6]||$incl$(6)).c$$S,[str]);
});

Clazz.newMeth(C$, 'getFormat', function () {
return this.format.toString();
});

Clazz.newMeth(C$, 'colorFromRadians$D', function (phi) {
var offset = ((45 + 45 * phi / 3.141592653589793)|0);
return C$.colors[offset];
}, 1);

Clazz.newMeth(C$, 'colorFromDegrees$I', function (phi) {
if (phi >= 0) return C$.colors[(45 + (phi/4|0)) % 90];
 else return C$.colors[89 - (45 - (phi/4|0)) % 90];
}, 1);

Clazz.newMeth(C$, 'initColors', function () {
var r;
var g;
var b;
var pi = 3.141592653589793;
for (var i = 0; i < 91; i++) {
b=((255 * Math.sin(pi * i / 90) * Math.sin(pi * i / 90) )|0);
g=((255 * Math.sin(pi * i / 90 + pi / 3) * Math.sin(pi * i / 90 + pi / 3) )|0);
r=((255 * Math.sin(pi * i / 90 + 2 * pi / 3) * Math.sin(pi * i / 90 + 2 * pi / 3) )|0);
C$.colors[i]=Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I,[r, g, b]);
}
}, 1);

Clazz.newMeth(C$, 'sGraph_mousePressed$java_awt_event_MouseEvent', function (e) {
if (this.enableClone && (e.getModifiers() & 4) != 0 ) {
var graphFrame = Clazz.new_((I$[26]||$incl$(26)).c$$edu_davidson_display_SGraph,[this.clone()]);
graphFrame.setSize$I$I(this.getSize().width, this.getSize().height);
graphFrame.show();
} else {
this.mouseX=e.getX();
this.mouseY=e.getY();
this.$mouseDrag=true;
var g = this.getGraphics();
var n = this.things.size();
for (var i = 0; i < n; i++) {
var t = this.things.elementAt$I(i);
if (!t.noDrag && t.isInsideThing$I$I(this.mouseX, this.mouseY) ) {
this.dragThing=t;
}}
if (this.dragThing != null ) {
this.sGraph_mouseDragged$java_awt_event_MouseEvent(e);
} else if (this.sketchMode && this.trailThing != null  ) {
this.trailThing.clearTrail();
this.parentSApplet.clearData$I(this.trailThing.hashCode());
this.setCursor$java_awt_Cursor((I$[27]||$incl$(27)).getPredefinedCursor$I(1));
this.sGraph_mouseDragged$java_awt_event_MouseEvent(e);
}g.dispose();
this.drawCoords$I$I(this.mouseX, this.mouseY);
}});

Clazz.newMeth(C$, 'sGraph_mouseDragged$java_awt_event_MouseEvent', function (e) {
this.mouseX=e.getX();
this.mouseY=e.getY();
var x;
var y;
var maxPix = this.pixFromX$D(this.xaxis.maximum);
var minPix = this.pixFromX$D(this.xaxis.minimum);
if (this.mouseX < minPix) this.mouseX=minPix;
 else if (this.mouseX > maxPix - 2) this.mouseX=maxPix - 2;
x=this.xFromPix$I(this.mouseX);
minPix=this.pixFromY$D(this.yaxis.maximum);
maxPix=this.pixFromY$D(this.yaxis.minimum);
if (this.mouseY < minPix) this.mouseY=minPix;
 else if (this.mouseY > maxPix - 2) this.mouseY=maxPix - 2;
y=this.yFromPix$I(this.mouseY);
if (this.dragThing != null ) {
this.dragThing.dragMe$D$D(x, y);
if (this.parentSApplet != null ) {
if (this.parentSApplet.destroyed) return;
this.parentSApplet.updateDataConnection$I(this.dragThing.hashCode());
}if (this.parentSApplet != null  || !this.parentSApplet.clock.isRunning() ) this.paintOffScreen();
} else if (this.sketchMode && this.trailThing != null  ) {
x=Math.min(x, this.xaxis.maximum);
x=Math.max(x, this.xaxis.minimum);
y=Math.min(y, this.yaxis.maximum);
y=Math.max(y, this.yaxis.minimum);
this.trailThing.incTrail$D$D(x, y);
var g = this.getGraphics();
this.paintOffScreen$java_awt_Graphics(g);
this.trailThing.paint$java_awt_Graphics(g);
if (this.sketchImage != null ) g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.sketchImage, this.mouseX, this.mouseY - this.sketchImage.getHeight$java_awt_image_ImageObserver(this), this);
g.dispose();
if (this.parentSApplet.destroyed) return;
this.parentSApplet.updateDataConnection$I(this.trailThing.hashCode());
}this.drawCoords$I$I(this.mouseX, this.mouseY);
});

Clazz.newMeth(C$, 'sGraph_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.$mouseDrag=false;
var r = this.getBounds();
if (this.dragThing == null ) this.repaint$I$I$I$I(0, r.height - 20, this.boxWidth, 20);
 else {
this.repaintDelayed();
}this.dragThing=null;
this.boxWidth=0;
if (this.sketchMode && this.trailThing != null  ) {
this.attachDataSet$edu_davidson_graph_DataSet(this.trailThing.dataset);
this.xaxis.attachDataSet$edu_davidson_graph_DataSet(this.trailThing.dataset);
this.yaxis.attachDataSet$edu_davidson_graph_DataSet(this.trailThing.dataset);
this.repaintDelayed();
}this.sGraph_mouseMoved$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'sGraph_mouseEntered$java_awt_event_MouseEvent', function (e) {
if (this.sketchMode) this.setCursor$java_awt_Cursor((I$[27]||$incl$(27)).getPredefinedCursor$I(13));
 else this.setCursor$java_awt_Cursor((I$[27]||$incl$(27)).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$, 'sGraph_mouseExited$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor((I$[27]||$incl$(27)).getPredefinedCursor$I(0));
});

Clazz.newMeth(C$, 'sGraph_mouseMoved$java_awt_event_MouseEvent', function (e) {
var xpt = e.getX();
var ypt = e.getY();
if (this.isInsideDragableThing$I$I(xpt, ypt)) this.setCursor$java_awt_Cursor((I$[27]||$incl$(27)).getPredefinedCursor$I(12));
 else if (this.sketchMode) this.setCursor$java_awt_Cursor((I$[27]||$incl$(27)).getPredefinedCursor$I(13));
 else this.setCursor$java_awt_Cursor((I$[27]||$incl$(27)).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$, 'attachArray$I$DA', function (id, points) {
var data;
if (points.length < 2) return null;
var np = (points.length/2|0);
data=this.loadDataSet$DA$I(points, np);
data.linestyle=1;
data.marker=3;
data.markerscale=this.defaultMarkerScale;
data.markercolor=Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I,[0, 0, 255]);
data.linecolor=Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I,[0, 0, 255]);
data.legendColor$java_awt_Color((I$[3]||$incl$(3)).black);
this.xaxis.attachDataSet$edu_davidson_graph_DataSet(data);
this.yaxis.attachDataSet$edu_davidson_graph_DataSet(data);
var newSeries;
this.dataSetSeries.addElement$TE(newSeries=Clazz.new_((I$[28]||$incl$(28)).c$$I$edu_davidson_graph_DataSet, [this, null, id, data]));
return newSeries;
});

Clazz.newMeth(C$, 'makeEmptySeries$I', function (sid) {
var data;
this.dPoint[0]=0;
this.dPoint[1]=0;
var series = p$.attachArray$I$DA.apply(this, [sid, this.dPoint]);
data=series.getDataSet();
data.deleteData();
return series;
});

Clazz.newMeth(C$, 'makeSampleData$I', function (np) {
var data;
var points = Clazz.array(Double.TYPE, [2 * np]);
var i = 0;
var j = 0;
for (i=j=0; i < np; i++, j+=2) {
points[j]=j - np;
points[j + 1]=60000 * Math.pow((points[j] / (np - 2)), 2);
}
var s = p$.attachArray$I$DA.apply(this, [1, points]);
data=s.getDataSet();
data.legend$I$I$S(200, 100, "sample data");
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'buildMarkers$I', function (w) {
var markers;
this.setMarkers$edu_davidson_graph_Markers(markers=Clazz.new_((I$[29]||$incl$(29))));
var draw = Clazz.array(Boolean.TYPE, [5]);
var xMark = Clazz.array(Integer.TYPE, [5]);
var yMark = Clazz.array(Integer.TYPE, [5]);
draw[0]=false;
draw[1]=true;
draw[2]=false;
draw[3]=true;
xMark[0]=w;
xMark[1]=-w;
xMark[2]=-w;
xMark[3]=w;
yMark[0]=w;
yMark[1]=-w;
yMark[2]=w;
yMark[3]=-w;
markers.AddMarker$I$I$ZA$IA$IA(1, 4, draw, xMark, yMark);
draw[0]=false;
draw[1]=true;
draw[2]=true;
draw[3]=true;
draw[4]=true;
xMark[0]=w;
xMark[1]=-w;
xMark[2]=-w;
xMark[3]=w;
xMark[4]=w;
yMark[0]=w;
yMark[1]=w;
yMark[2]=-w;
yMark[3]=-w;
yMark[4]=w;
markers.AddMarker$I$I$ZA$IA$IA(2, 5, draw, xMark, yMark);
markers.AddMarker$I$I$I(3, w, (I$[29]||$incl$(29)).TYPE_CIRCLE);
markers.AddMarker$I$I$I(4, w, (I$[29]||$incl$(29)).TYPE_SQUARE);
});
;
(function(){var C$=Clazz.newClass(P$.SGraph, "RegressionDataSource", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.regStrings = null;
this.ds = null;
this.series = null;
this.owner = null;
this.start = 0;
this.end = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.regStrings = Clazz.array(java.lang.String, -1, ["m", "b", "dm", "db"]);
this.ds = Clazz.array(Double.TYPE, [1, 4]);
this.series = null;
this.owner = null;
this.start = 0;
this.end = 0;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_display_SGraph_Series$I$I', function (s, start, end) {
C$.$init$.apply(this);
this.owner=this.this$0.parentSApplet;
this.series=s;
this.start=start;
this.end=end;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0]=0;
this.ds[0][1]=0;
this.ds[0][2]=0;
this.ds[0][3]=0;
var first = 0;
var last = 0;
var sumx = 0;
var sumy = 0;
var sumxx = 0;
var sumxy = 0;
var xval;
var yval;
var vals = this.series.data.getData();
var n = this.series.data.dataPoints();
if (this.end <= this.start) last=n;
 else last=Math.min(n, this.end);
first=Math.max(1, this.start) - 1;
if ((last - first) < 2) {
return this.ds;
}for (var i = first; i < last; i++) {
xval=vals[2 * i];
yval=vals[2 * i + 1];
sumx += xval;
sumy += yval;
sumxx += xval * xval;
sumxy += xval * yval;
}
var delta = n * sumxx - sumx * sumx;
if (delta == 0 ) {
this.ds[0][0]=1.0E64;
this.ds[0][1]=1.0E64;
}var m = (n * sumxy - sumx * sumy) / delta;
var b = (sumxx * sumy - sumx * sumxy) / delta;
this.ds[0][0]=m;
this.ds[0][1]=b;
if ((last - first) < 3) {
return this.ds;
}var chisq = 0;
var dy;
for (var i = first; i < last; i++) {
dy=vals[2 * i + 1] - b - m * vals[2 * i] ;
chisq += dy * dy;
}
this.ds[0][2]=Math.sqrt(chisq * n / delta / (n - 2));
this.ds[0][3]=Math.sqrt(chisq * sumxx / delta / (n - 2));
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.regStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0.parentSApplet;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.SGraph, "Series", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.data = null;
this.sid = 0;
this.enableLPCursor = false;
this.addRepeatedDatum = false;
this.varStrings = null;
this.owner = null;
this.autoReplace = false;
this.regression = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.enableLPCursor = false;
this.addRepeatedDatum = true;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "u", "v"]);
this.owner = null;
this.autoReplace = false;
this.regression = null;
}, 1);

Clazz.newMeth(C$, 'c$$I$edu_davidson_graph_DataSet', function (i, ds) {
C$.$init$.apply(this);
this.sid=i;
this.data=ds;
this.owner=this.this$0.parentSApplet;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
this.owner=owner;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getDataSet', function () {
return this.data;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'getRegressionID$I$I', function (start, end) {
if (this.regression == null ) this.regression=Clazz.new_((I$[2]||$incl$(2)).c$$edu_davidson_display_SGraph_Series$I$I, [this, null, this, start, end]);
return this.regression.getID();
});

Clazz.newMeth(C$, 'paintLastPoint$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var lpRadius = 2;
var n = this.data.dataPoints();
if (n < 1 || !this.enableLPCursor ) return;
var datum = this.data.getLastPoint();
if (datum == null ) return;
var xpix = this.this$0.pixFromX$D(datum[0]);
var ypix = this.this$0.pixFromY$D(datum[1]);
if (this.data.marker > 0) {
lpRadius=Math.max(lpRadius, (Math.round(4 * this.data.markerscale)|0) - 1);
}var lpSize = lpRadius * 2 + 1;
g.setColor$java_awt_Color((I$[3]||$incl$(3)).red);
g.fillOval$I$I$I$I(xpix - lpRadius - 1 , ypix - lpRadius - 1 , lpSize, lpSize);
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
g.drawOval$I$I$I$I(xpix - lpRadius - 1 , ypix - lpRadius - 1 , lpSize, lpSize);
});

Clazz.newMeth(C$, 'getLastPoint', function () {
var n = this.data.dataPoints();
if (n < 1) return null;
var datum = this.data.getPoint$I(n - 1);
return datum;
});

Clazz.newMeth(C$, 'getX', function () {
var vals = this.data.getData();
var n = this.data.dataPoints();
var x = Clazz.array(Double.TYPE, [n]);
for (var i = 0; i < n; i++) x[i]=vals[2 * i];

return x;
});

Clazz.newMeth(C$, 'getY', function () {
var vals = this.data.getData();
var n = this.data.dataPoints();
var y = Clazz.array(Double.TYPE, [n]);
for (var i = 0; i < n; i++) y[i]=vals[2 * i + 1];

return y;
});

Clazz.newMeth(C$, 'getNumpts', function () {
return this.data.dataPoints();
});

Clazz.newMeth(C$, 'getSlopeIntercept$I$I', function (start, end) {
var first;
var last;
var datum;
var regVars = Clazz.array(Double.TYPE, [2]);
var x = 0;
var y = 0;
var xx = 0;
var xy = 0;
var n = this.data.dataPoints();
if (end <= start) last=n;
 else last=Math.min(n, end);
first=Math.max(1, start) - 1;
if (last - first < 2) return regVars;
for (var i = first; i < last; i++) {
datum=this.data.getPoint$I(i);
x += datum[0];
y += datum[1];
xx += datum[0] * datum[0];
xy += datum[0] * datum[1];
}
regVars[0]=(n * xy - x * y) / (n * xx - x * x);
regVars[1]=y / n - regVars[0] * x / n;
return regVars;
});

Clazz.newMeth(C$, 'getVariables', function () {
var n = this.data.dataPoints();
var datum;
var v = Clazz.array(Double.TYPE, [n, 4]);
if (n < 1) return v;
datum=this.data.getPoint$I(0);
v[0][0]=datum[0];
v[0][1]=datum[1];
for (var i = 1; i < n; i++) {
datum=this.data.getPoint$I(i);
v[i][0]=datum[0];
v[i][1]=datum[1];
v[i][2]=v[i][0] - v[i - 1][0];
v[i][3]=v[i][1] - v[i - 1][1];
}
return v;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.SGraph, "MathFunction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, ['Cloneable', 'edu.davidson.tools.SDataSource', 'edu.davidson.tools.SStepable']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.parser = null;
this.checkFunc = null;
this.explicitTime = false;
this.color = null;
this.numPts = 0;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.minClip = 0;
this.maxClip = 0;
this.time = 0;
this.fixedRange = false;
this.functionClip = false;
this.varStrings = null;
this.v = null;
this.owner = null;
this.string = null;
this.variable = null;
this.visible = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.parser = null;
this.checkFunc = Clazz.new_((I$[4]||$incl$(4)).c$$I,[1]);
this.explicitTime = false;
this.color = (I$[3]||$incl$(3)).black;
this.numPts = 100;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.maxClip = 0;
this.time = 0;
this.fixedRange = false;
this.functionClip = false;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "v", "a"]);
this.v = Clazz.array(Double.TYPE, [this.numPts, 4]);
this.owner = null;
this.string = null;
this.variable = null;
this.visible = true;
}, 1);

Clazz.newMeth(C$, 'c$$S$S', function (indVar, str) {
C$.$init$.apply(this);
this.xmin=this.this$0.xaxis.minimum;
this.xmax=this.this$0.xaxis.maximum;
if (this.xmin >= this.xmax ) {
this.xmax += 1;
this.xmin=this.xmax - 1;
}str=str.trim();
this.variable= String.instantialize(indVar.trim());
this.string= String.instantialize(str);
if (!indVar.equals$O("t")) this.checkFunctionForTime$S(this.string);
this.parser=Clazz.new_((I$[4]||$incl$(4)).c$$I,[2]);
this.parser.defineVariable$I$S(1, indVar);
if (!indVar.equals$O("t")) this.parser.defineVariable$I$S(2, "t");
 else this.parser.defineVariable$I$S(2, "time");
this.parser.define$S(str);
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
System.out.println$S("Failed to parse f(x,t)): " + str);
System.out.println$S("Parse error in MathFunction: " + this.parser.getErrorString() + " at math function, position " + this.parser.getErrorPosition() );
} else this.setScale();
this.owner=this.this$0.parentSApplet;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (this.owner != null ) {
if (this.explicitTime) this.owner.clock.addClockListener$edu_davidson_tools_SStepable(this);
this.time=this.owner.clock.getTime();
}}, 1);

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
this.time=time + dt;
this.owner.clearData$I(this.hashCode());
if (this.this$0.parentSApplet != null  && this.this$0.parentSApplet.destroyed ) return;
this.owner.updateDataConnection$I(this.hashCode());
if (this.this$0.autoRefresh) this.this$0.repaintDelayed();
});

Clazz.newMeth(C$, 'setString$S', function (str) {
str=str.trim();
this.string= String.instantialize(str);
this.parser.define$S(str);
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
System.out.println$S("Failed to parse f(x,t)): " + str);
System.out.println$S("Parse error in MathFunction: " + this.parser.getErrorString() + " at function 1, position " + this.parser.getErrorPosition() );
return false;
} else this.setScale();
if (this.owner != null ) {
if (this.this$0.parentSApplet != null  && this.this$0.parentSApplet.destroyed ) return false;
this.owner.clearData$I(this.hashCode());
this.owner.updateDataConnection$I(this.hashCode());
}return true;
});

Clazz.newMeth(C$, 'getString', function () {
return this.variable;
});

Clazz.newMeth(C$, 'setVariable$S', function (str) {
this.variable= String.instantialize(str.trim());
this.parser.defineVariable$I$S(1, str);
});

Clazz.newMeth(C$, 'getVariable', function () {
return this.variable;
});

Clazz.newMeth(C$, 'checkFunctionForTime$S', function (fieldStr) {
var str =  String.instantialize(fieldStr);
this.checkFunc.defineVariable$I$S(1, "x");
this.checkFunc.define$S(str.toLowerCase());
this.checkFunc.parse();
if (this.checkFunc.getErrorCode() != 0) {
this.explicitTime=true;
} else this.explicitTime=false;
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
this.owner=owner;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'getParser', function () {
return this.parser;
});

Clazz.newMeth(C$, 'getFunctionStr', function () {
return this.parser.getFunctionString();
});

Clazz.newMeth(C$, 'setFunctionRange$D$D$I', function (xmin, xmax, n) {
if (n < 1) {
this.fixedRange=false;
return;
}this.xmin=xmin;
this.xmax=xmax;
this.numPts=n;
if (this.numPts != this.v.length) this.v=Clazz.array(Double.TYPE, [this.numPts, 4]);
this.fixedRange=true;
});

Clazz.newMeth(C$, 'setFunctionClip$D$D', function (min, max) {
if (min >= max ) {
this.functionClip=false;
return;
}this.minClip=min;
this.maxClip=max;
this.functionClip=true;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
if (!this.visible) return;
if (this.fixedRange) this.paint2$java_awt_Graphics$java_awt_Rectangle(g, r);
 else this.paint1$java_awt_Graphics$java_awt_Rectangle(g, r);
});

Clazz.newMeth(C$, 'paint1$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
this.numPts=r.width;
if (this.numPts != this.v.length) this.v=Clazz.array(Double.TYPE, [this.numPts, 4]);
if (this.numPts < 1) return;
var rc = g.getClip();
g.setClip$java_awt_Shape(r);
var y1Pix = 0;
var y2Pix = 0;
var x1 = 0;
var x2 = 0;
var y1 = 0;
var y2 = 0;
this.xmin=this.this$0.xFromPix$I(r.x);
this.xmax=this.this$0.xFromPix$I(r.x + r.width - 1);
x1=this.xmin;
this.ymin=this.parser.evaluate$D$D(x1, this.time);
y1=this.ymin;
this.ymax=this.ymin;
y1Pix=this.this$0.pixFromY$D(this.ymin);
g.setColor$java_awt_Color(this.color);
for (var i = 1; i < r.width; i++) {
x2=this.this$0.xFromPix$I(r.x + i);
y2=this.parser.evaluate$D$D(x2, this.time);
if (!this.functionClip || (y2 > this.minClip  && y2 < this.maxClip  ) ) {
if (y2 < this.ymin ) this.ymin=y2;
if (y2 > this.ymax ) this.ymax=y2;
}y2Pix=this.this$0.pixFromY$D(y2);
if (!this.functionClip || (y1 > this.minClip  && y1 < this.maxClip   && y2 > this.minClip   && y2 < this.maxClip  ) ) {
g.drawLine$I$I$I$I(r.x + i - 1, y1Pix, r.x + i, y2Pix);
}y1Pix=y2Pix;
y1=y2;
}
g.setClip$java_awt_Shape(rc);
});

Clazz.newMeth(C$, 'paint2$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
if (this.numPts < 1) return;
var rc = g.getClip();
g.setClip$java_awt_Shape(r);
var x1Pix = 0;
var x2Pix = 0;
var y1Pix = 0;
var y2Pix = 0;
var x = 0;
var y = 0;
var dx = (this.xmax - this.xmin) / (this.numPts - 1);
x=this.xmin;
x1Pix=this.this$0.pixFromX$D(x);
this.ymin=this.parser.evaluate$D$D(x, this.time);
this.ymax=this.ymin;
y1Pix=this.this$0.pixFromY$D(this.ymin);
g.setColor$java_awt_Color(this.color);
for (var i = 1; i < this.numPts; i++) {
x=x + dx;
x2Pix=this.this$0.pixFromX$D(x);
y=this.parser.evaluate$D$D(x, this.time);
if (y < this.ymin ) this.ymin=y;
if (y > this.ymax ) this.ymax=y;
y2Pix=this.this$0.pixFromY$D(y);
g.drawLine$I$I$I$I(x1Pix, y1Pix, x2Pix, y2Pix);
x1Pix=x2Pix;
y1Pix=y2Pix;
}
g.setClip$java_awt_Shape(rc);
});

Clazz.newMeth(C$, 'getVariables', function () {
var v = this.v;
var numPts = v.length;
{
var x = this.this$0.xaxis.minimum;
var xMax = this.this$0.xaxis.maximum;
if (this.fixedRange) {
x=this.xmin;
xMax=this.xmax;
}var dx = (xMax - x) / (numPts - 1);
for (var i = 0; i < numPts; i++) {
v[i][0]=x;
v[i][1]=this.parser.evaluate$D$D(x, this.time);
x += dx;
}
if (numPts < 4) return v;
for (var i = 2; i < numPts - 2; i++) {
v[i][2]=(-v[i + 2][1] + 8 * v[i + 1][1] - 8 * v[i - 1][1] + v[i - 2][1]) / dx / 12 ;
v[i][3]=(-v[i + 2][1] + 16 * v[i + 1][1] - 30 * v[i][1] + 16 * v[i - 1][1] - v[i - 2][1]) / dx / dx / 12 ;
}
x=this.this$0.xaxis.minimum;
v[1][2]=(-v[3][1] + 8 * v[2][1] - 8 * v[0][1] + this.parser.evaluate$D$D(x - dx, this.time)) / dx / 12 ;
v[0][2]=(-v[2][1] + 8 * v[1][1] - 8 * this.parser.evaluate$D$D(x - dx, this.time) + this.parser.evaluate$D$D(x - 2 * dx, this.time)) / dx / 12 ;
v[numPts - 1][2]=(-this.parser.evaluate$D$D(xMax + 2 * dx, this.time) + 8 * this.parser.evaluate$D$D(xMax + dx, this.time) - 8 * v[numPts - 2][1] + v[numPts - 3][1]) / dx / 12 ;
v[numPts - 2][2]=(-this.parser.evaluate$D$D(xMax + dx, this.time) + 8 * v[numPts - 1][1] - 8 * v[numPts - 3][1] + v[numPts - 4][1]) / dx / 12 ;
v[1][3]=(-v[3][1] + 16 * v[2][1] - 30 * v[1][1] + 16 * v[0][1] - this.parser.evaluate$D$D(x - dx, this.time)) / dx / dx / 12 ;
v[0][3]=(-v[2][1] + 16 * v[1][1] - 30 * v[0][1] + 16 * this.parser.evaluate$D$D(x - dx, this.time) - this.parser.evaluate$D$D(x - 2 * dx, this.time)) / dx / dx / 12 ;
v[numPts - 1][3]=(-this.parser.evaluate$D$D(xMax + 2 * dx, this.time) + 16 * this.parser.evaluate$D$D(xMax + dx, this.time) - 30 * v[numPts - 1][1] + 16 * v[numPts - 2][1] - v[numPts - 3][1]) / dx / dx / 12 ;
v[numPts - 2][3]=(-this.parser.evaluate$D$D(xMax + dx, this.time) + 16 * v[numPts - 1][1] - 30 * v[numPts - 2][1] + 16 * v[numPts - 3][1] - v[numPts - 4][1]) / dx / dx / 12 ;
return v;
}});

Clazz.newMeth(C$, 'setScale', function () {
if (this.numPts < 2) return;
var x = 0;
var y = 0;
var dx = (this.xmax - this.xmin) / (this.numPts - 1);
x=this.xmin;
y=this.parser.evaluate$D$D(x, this.time);
if (!this.functionClip || (y > this.minClip  && y < this.maxClip  ) ) {
this.ymin=this.ymax=y;
} else {
this.ymin=this.ymax=this.minClip;
}for (var i = 1; i < this.numPts; i++) {
x=x + dx;
y=this.parser.evaluate$D$D(x, this.time);
if (!this.functionClip || (y > this.minClip  && y < this.maxClip  ) ) {
this.ymin=Math.min(this.ymin, y);
this.ymax=Math.max(this.ymax, y);
}}
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.SGraph, "ComplexFunction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, ['Cloneable', 'edu.davidson.tools.SDataSource', 'edu.davidson.tools.SStepable']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.parserIm = null;
this.parserRe = null;
this.checkFunc = null;
this.explicitTime = false;
this.color = null;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.time = 0;
this.fixedRange = false;
this.varStrings = null;
this.v = null;
this.owner = null;
this.stringRe = null;
this.stringIm = null;
this.variable = null;
this.centered = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.parserIm = null;
this.parserRe = null;
this.checkFunc = Clazz.new_((I$[4]||$incl$(4)).c$$I,[1]);
this.explicitTime = false;
this.color = (I$[3]||$incl$(3)).black;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.time = 0;
this.fixedRange = false;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "v", "a"]);
this.v = Clazz.array(Double.TYPE, [100, 4]);
this.owner = null;
this.stringRe = null;
this.stringIm = null;
this.variable = null;
this.centered = true;
}, 1);

Clazz.newMeth(C$, 'c$$S$S$S', function (indVar, strRe, strIm) {
C$.$init$.apply(this);
this.xmin=this.this$0.xaxis.minimum;
this.xmax=this.this$0.xaxis.maximum;
if (this.xmin >= this.xmax ) {
this.xmax += 1;
this.xmin=this.xmax - 1;
}strRe=strRe.trim();
this.stringRe= String.instantialize(strRe);
strIm=strIm.trim();
this.stringIm= String.instantialize(strIm);
this.variable= String.instantialize(indVar.trim());
if (!indVar.equals$O("t")) {
this.explicitTime=this.checkFunctionForTime$S(this.stringRe) || this.checkFunctionForTime$S(this.stringRe) ;
}this.parserRe=Clazz.new_((I$[4]||$incl$(4)).c$$I,[2]);
this.parserRe.defineVariable$I$S(1, indVar);
if (!indVar.equals$O("t")) this.parserRe.defineVariable$I$S(2, "t");
 else this.parserRe.defineVariable$I$S(2, "time");
this.parserRe.define$S(strRe);
this.parserRe.parse();
if (this.parserRe.getErrorCode() != 0) {
System.out.println$S("Failed to parse f(x,t)): " + strRe);
System.out.println$S("Parse error in ComplexFunction: " + this.parserRe.getErrorString() + " at position " + this.parserRe.getErrorPosition() );
}this.parserIm=Clazz.new_((I$[4]||$incl$(4)).c$$I,[2]);
this.parserIm.defineVariable$I$S(1, indVar);
if (!indVar.equals$O("t")) this.parserIm.defineVariable$I$S(2, "t");
 else this.parserIm.defineVariable$I$S(2, "time");
this.parserIm.define$S(strIm);
this.parserIm.parse();
if (this.parserIm.getErrorCode() != 0) {
System.out.println$S("Failed to parse f(x,t)): " + strIm);
System.out.println$S("Parse error in ComplexFunction: " + this.parserIm.getErrorString() + " at math position " + this.parserIm.getErrorPosition() );
}this.setScale();
this.owner=this.this$0.parentSApplet;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (this.owner != null ) {
if (this.explicitTime) this.owner.clock.addClockListener$edu_davidson_tools_SStepable(this);
this.time=this.owner.clock.getTime();
}}, 1);

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
this.time=time + dt;
if (this.this$0.parentSApplet != null  && this.this$0.parentSApplet.destroyed ) return;
this.owner.clearData$I(this.hashCode());
this.owner.updateDataConnection$I(this.hashCode());
if (this.this$0.autoRefresh) this.this$0.repaintDelayed();
});

Clazz.newMeth(C$, 'setStringIm$S', function (strIm) {
strIm=strIm.trim();
this.stringIm= String.instantialize(strIm);
this.parserIm.define$S(strIm);
this.parserIm.parse();
if (this.parserIm.getErrorCode() != 0) {
System.out.println$S("Failed to parse f(x,t)): " + strIm);
System.out.println$S("Parse error in ComplexFunction: " + this.parserIm.getErrorString() + " at position " + this.parserIm.getErrorPosition() );
return false;
} else this.setScale();
if (this.owner != null ) {
if (this.this$0.parentSApplet != null  && this.this$0.parentSApplet.destroyed ) return false;
this.owner.clearData$I(this.hashCode());
this.owner.updateDataConnection$I(this.hashCode());
}return true;
});

Clazz.newMeth(C$, 'setStringRe$S', function (strRe) {
strRe=strRe.trim();
this.stringRe= String.instantialize(strRe);
this.parserRe.define$S(strRe);
this.parserRe.parse();
if (this.parserRe.getErrorCode() != 0) {
System.out.println$S("Failed to parse Re(x,t)): " + strRe);
System.out.println$S("Parse error in ComplexFunction: " + this.parserRe.getErrorString() + " at position " + this.parserRe.getErrorPosition() );
return false;
} else this.setScale();
if (this.owner != null ) {
if (this.this$0.parentSApplet != null  && this.this$0.parentSApplet.destroyed ) return false;
this.owner.clearData$I(this.hashCode());
this.owner.updateDataConnection$I(this.hashCode());
}return true;
});

Clazz.newMeth(C$, 'getString', function () {
return this.variable;
});

Clazz.newMeth(C$, 'setVariable$S', function (str) {
this.variable= String.instantialize(str.trim());
this.parserRe.defineVariable$I$S(1, str);
this.parserIm.defineVariable$I$S(1, str);
});

Clazz.newMeth(C$, 'getVariable', function () {
return this.variable;
});

Clazz.newMeth(C$, 'checkFunctionForTime$S', function (fieldStr) {
var explicitTime = false;
var str =  String.instantialize(fieldStr);
this.checkFunc.defineVariable$I$S(1, "x");
this.checkFunc.define$S(str.toLowerCase());
this.checkFunc.parse();
if (this.checkFunc.getErrorCode() != 0) {
explicitTime=true;
} else explicitTime=false;
return explicitTime;
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
this.owner=owner;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'getParserRe', function () {
return this.parserRe;
});

Clazz.newMeth(C$, 'getParserIm', function () {
return this.parserIm;
});

Clazz.newMeth(C$, 'getFunctionStrRe', function () {
return this.parserRe.getFunctionString();
});

Clazz.newMeth(C$, 'getFunctionStrIm', function () {
return this.parserIm.getFunctionString();
});

Clazz.newMeth(C$, 'setFunctionRange$D$D', function (xmin, xmax) {
if (xmin >= xmax ) {
this.fixedRange=false;
return;
}this.xmin=xmin;
this.xmax=xmax;
this.fixedRange=true;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
this.paint1$java_awt_Graphics$java_awt_Rectangle(g, r);
});

Clazz.newMeth(C$, 'paint1$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
if (r.width < 3) return;
var rc = g.getClip();
g.setClip$java_awt_Shape(r);
var y1Pix = 0;
var y2Pix = 0;
var x = 0;
var y = 0;
var xstart;
var xstop;
var origin = this.this$0.pixFromY$D(0);
xstart=this.this$0.xFromPix$I(r.x);
xstop=this.this$0.xFromPix$I(r.x + r.width - 1);
var yRe;
var yIm;
yRe=this.parserRe.evaluate$D$D(this.xmin, this.time);
yIm=this.parserIm.evaluate$D$D(this.xmin, this.time);
this.ymin=Math.sqrt(yRe * yRe + yIm * yIm);
this.ymax=this.ymin;
for (var i = 1; i < r.width - 1; i++) {
x=this.this$0.xFromPix$I(r.x + i);
if (this.fixedRange && (x < this.xmin  || x > this.xmax  ) ) continue;
yRe=this.parserRe.evaluate$D$D(x, this.time);
yIm=this.parserIm.evaluate$D$D(x, this.time);
y=Math.sqrt(yRe * yRe + yIm * yIm);
g.setColor$java_awt_Color(P$.SGraph.colorFromRadians$D(Math.atan2(yIm, yRe)));
if (y < this.ymin ) this.ymin=y;
if (y > this.ymax ) this.ymax=y;
if (this.centered) {
y1Pix=this.this$0.pixFromY$D(-y / 2);
y2Pix=this.this$0.pixFromY$D(y / 2);
} else {
y1Pix=origin;
y2Pix=this.this$0.pixFromY$D(y);
}g.drawLine$I$I$I$I(r.x + i, y1Pix, r.x + i, y2Pix);
}
g.setClip$java_awt_Shape(rc);
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.v;
});

Clazz.newMeth(C$, 'setScale', function () {
var numPts = 500;
var x = 0;
var y = 0;
var dx = (this.xmax - this.xmin) / (numPts - 1);
x=this.xmin;
var yRe = this.parserRe.evaluate$D$D(x, this.time);
var yIm = this.parserIm.evaluate$D$D(x, this.time);
this.ymin=Math.sqrt(yRe * yRe + yIm * yIm);
this.ymax=this.ymin;
for (var i = 1; i < numPts; i++) {
x=x + dx;
yRe=this.parserRe.evaluate$D$D(x, this.time);
yIm=this.parserIm.evaluate$D$D(x, this.time);
y=Math.sqrt(yRe * yRe + yIm * yIm);
this.ymin=Math.min(this.ymin, y);
this.ymax=Math.max(this.ymax, y);
}
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.SGraph, "VectorFieldThing", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'edu.davidson.display.Thing', ['Cloneable', 'edu.davidson.tools.SStepable']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.parserFx = null;
this.parserFy = null;
this.checkFunc = null;
this.explicitTime = false;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.$time = 0;
this.stringFx = null;
this.stringFy = null;
this.gridSize = 0;
this.field = null;
this.fieldData = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.parserFx = null;
this.parserFy = null;
this.checkFunc = Clazz.new_((I$[4]||$incl$(4)).c$$I,[2]);
this.explicitTime = false;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.$time = 0;
this.stringFx = null;
this.stringFy = null;
this.gridSize = 0;
}, 1);

Clazz.newMeth(C$, 'c$$S$S$I', function (strFx, strFy, gs) {
C$.superclazz.c$$edu_davidson_display_SScalable.apply(this, [this.this$0]);
C$.$init$.apply(this);
this.field=Clazz.new_((I$[5]||$incl$(5)).c$$I$I,[gs, gs]);
this.fieldData=this.field.resize$I$I(gs, gs);
this.gridSize=gs;
this.xmin=this.this$0.xaxis.minimum;
this.xmax=this.this$0.xaxis.maximum;
this.ymin=this.this$0.yaxis.minimum;
this.ymax=this.this$0.yaxis.maximum;
strFx=strFx.trim();
this.stringFx= String.instantialize(strFx);
strFy=strFy.trim();
this.stringFy= String.instantialize(strFy);
this.explicitTime=this.checkFunctionForTime$S(this.stringFx) || this.checkFunctionForTime$S(this.stringFy) ;
this.parserFx=Clazz.new_((I$[4]||$incl$(4)).c$$I,[3]);
this.parserFx.defineVariable$I$S(1, "x");
this.parserFx.defineVariable$I$S(2, "y");
this.parserFx.defineVariable$I$S(3, "t");
this.parserFx.define$S(strFx);
this.parserFx.parse();
if (this.parserFx.getErrorCode() != 0) {
System.out.println$S("Failed to parse fx(x,y,t)): " + strFx);
System.out.println$S("Parse error in VectorField: " + this.parserFx.getErrorString() + " at position " + this.parserFx.getErrorPosition() );
}this.parserFy=Clazz.new_((I$[4]||$incl$(4)).c$$I,[3]);
this.parserFy.defineVariable$I$S(1, "x");
this.parserFy.defineVariable$I$S(2, "y");
this.parserFy.defineVariable$I$S(3, "t");
this.parserFy.define$S(strFy);
this.parserFy.parse();
if (this.parserFy.getErrorCode() != 0) {
System.out.println$S("Failed to parse fy(x,y,t)): " + strFy);
System.out.println$S("Parse error in VectorField: " + this.parserFy.getErrorString() + " at position " + this.parserFy.getErrorPosition() );
}if (this.this$0.parentSApplet != null ) {
this.$time=this.this$0.parentSApplet.clock.getTime();
if (this.explicitTime) this.this$0.parentSApplet.clock.addClockListener$edu_davidson_tools_SStepable(this);
}}, 1);

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
this.$time=time + dt;
if (this.explicitTime && this.this$0.autoRefresh ) this.this$0.repaintDelayed();
});

Clazz.newMeth(C$, 'checkFunctionForTime$S', function (fieldStr) {
var explicitTime = false;
var str =  String.instantialize(fieldStr);
this.checkFunc.defineVariable$I$S(1, "x");
this.checkFunc.defineVariable$I$S(2, "y");
this.checkFunc.define$S(str.toLowerCase());
this.checkFunc.parse();
if (this.checkFunc.getErrorCode() != 0) {
explicitTime=true;
} else explicitTime=false;
return explicitTime;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
for (var j = 0; j < this.gridSize; j++) {
this.x=(this.xmax - this.xmin) * j / (this.gridSize - 1) + this.xmin;
for (var i = 0; i < this.gridSize; i++) {
this.y=(this.ymax - this.ymin) * i / (this.gridSize - 1) + this.ymin;
var fx = this.parserFx.evaluate$D$D$D(this.x, this.y, this.$time);
var fy = this.parserFy.evaluate$D$D$D(this.x, this.y, this.$time);
var mag = Math.sqrt(fx * fx + fy * fy);
if (mag > 0 ) {
this.fieldData[i][j][0]=fx / mag;
this.fieldData[i][j][1]=fy / mag;
this.fieldData[i][j][2]=mag;
} else {
this.fieldData[i][j][0]=0;
this.fieldData[i][j][1]=0;
this.fieldData[i][j][2]=0;
}}
}
this.field.paint$java_awt_Graphics$java_awt_Rectangle(g, this.this$0.datarect);
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-07-23 12:59:46 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
