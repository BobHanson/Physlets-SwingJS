(function(){var P$=Clazz.newPackage("animator4"),I$=[[0,'edu.davidson.tools.SUtil','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ArrowStatic", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.insideTip=false;
this.fixedlength=false;
this.length=0;
this.filled=false;
this.horz=0;
this.vert=0;
this.thickness=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.insideTip=false;
this.fixedlength=false;
this.length=0;
this.filled=false;
this.horz=0;
this.vert=0;
this.thickness=1;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$D$D$S$S', function (o, s, horz, vert, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.varStrings=Clazz.array(String, -1, ["t", "x", "y", "vx", "vy", "ax", "ay", "m", "horz", "vert", "w", "h"]);
this.ds=Clazz.array(Double.TYPE, [1, 12]);
this.s=s;
this.horz=horz;
this.vert=vert;
this.length=Math.sqrt(horz * horz + vert * vert);
}, 1);

Clazz.newMeth(C$, 'getHorz$', function () {
return this.horz;
});

Clazz.newMeth(C$, 'getVert$', function () {
return this.vert;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
this.insideTip=false;
var ptX=this.canvas.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY=this.canvas.pixFromY$D(this.vars[2]) - this.yDisplayOff;
if (!this.noDrag && (Math.abs(xPix - ptX) < this.s + 1) && (Math.abs(yPix - ptY) < this.s + 1)  ) return true;
ptX=((ptX + this.canvas.pixPerUnit * this.horz)|0);
ptY=((ptY - this.canvas.pixPerUnit * this.vert)|0);
if (this.resizable && (Math.abs(xPix - ptX) < this.s + 5) && (Math.abs(yPix - ptY) < this.s + 5)  ) {
this.insideTip=true;
return true;
} else return false;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX=Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY=Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
var x=this.canvas.pixPerUnit * this.horz;
var y=this.canvas.pixPerUnit * this.vert;
osg.setColor$java_awt_Color(this.color);
var x2=((ptX + x)|0);
var y2=((ptY - y)|0);
var h=Math.sqrt(x * x + y * y);
if (h < 2 ) {
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
return;
}var w;
if (h > 3 * this.s ) w=this.s;
 else w=h / 3;
w=Math.max(w, 5);
if (this.s == 0) {
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
} else if (this.thickness > 1) {
$I$(1).drawThickArrow$java_awt_Graphics$I$I$I$I$I$I(osg, ptX, ptY, x2, y2, (w|0), this.thickness);
} else if (this.filled) {
$I$(1).drawSolidArrow$java_awt_Graphics$I$I$I$I$I(osg, ptX, ptY, x2, y2, (w|0));
} else {
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
if (h > 1 ) {
var u=(w * x / h);
var v=-(w * y / h);
var base_x=x2 - 3 * u;
var base_y=y2 - 3 * v;
osg.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x2, y2);
osg.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x2, y2);
}}if (!this.noDrag) {
if (this.color !== $I$(2).lightGray ) osg.setColor$java_awt_Color($I$(2).lightGray);
 else this.setColor$java_awt_Color($I$(2).red);
osg.fillOval$I$I$I$I(ptX - 2, ptY - 2, 5, 5);
osg.setColor$java_awt_Color(this.color);
osg.drawOval$I$I$I$I(ptX - 2, ptY - 2, 5, 5);
}if (this.resizable) {
if (this.color !== $I$(2).lightGray ) osg.setColor$java_awt_Color($I$(2).lightGray);
 else this.setColor$java_awt_Color($I$(2).red);
osg.fillOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
osg.setColor$java_awt_Color(this.color);
osg.drawOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
}if (this.label != null ) {
osg.setColor$java_awt_Color($I$(2).black);
var f=osg.getFont$();
osg.setFont$java_awt_Font(this.font);
var fm=osg.getFontMetrics$java_awt_Font(this.font);
var off1=4 + (((8 + fm.stringWidth$S(this.label)) * (-1.0 + x / h) / 2.0)|0);
var off2=((-4 * (y / h) + fm.getHeight$() * (1.0 - y / h) / 4.0)|0);
osg.drawString$S$I$I(this.label, x2 + off1, y2 + off2);
osg.setFont$java_awt_Font(f);
}});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX=Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY=Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
var x=this.canvas.pixPerUnit * this.horz;
var y=this.canvas.pixPerUnit * this.vert;
osg.setColor$java_awt_Color(this.highlightColor);
var x2=((ptX + x)|0);
var y2=((ptY - y)|0);
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
var h=Math.sqrt(x * x + y * y);
if (h < 2 ) {
return;
}var w;
if (h > 3 * this.s ) w=this.s;
 else w=h / 3;
w=Math.max(w, 5);
if (h > 1  && this.s > 0 ) {
var u=(w * x / h);
var v=-(w * y / h);
var base_x=x2 - 3 * u;
var base_y=y2 - 3 * v;
osg.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x2, y2);
osg.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x2, y2);
}if (this.label != null ) {
osg.setColor$java_awt_Color($I$(2).black);
var f=osg.getFont$();
osg.setFont$java_awt_Font(this.font);
var fm=osg.getFontMetrics$java_awt_Font(this.font);
var off1=4 + (((8 + fm.stringWidth$S(this.label)) * (-1.0 + x / h) / 2.0)|0);
var off2=((-4 * (y / h) + fm.getHeight$() * (1.0 - y / h) / 4.0)|0);
osg.drawString$S$I$I(this.label, x2 + off1, y2 + off2);
osg.setFont$java_awt_Font(f);
}});

Clazz.newMeth(C$, 'getVariables$', function () {
this.ds[0][0]=this.vars[0];
this.ds[0][1]=this.vars[1];
this.ds[0][2]=this.vars[2];
this.ds[0][3]=this.vars[3];
this.ds[0][4]=this.vars[4];
this.ds[0][5]=this.vars[5];
this.ds[0][6]=this.vars[6];
this.ds[0][7]=this.mass;
this.ds[0][8]=this.horz;
this.ds[0][9]=this.vert;
this.ds[0][10]=this.horz;
this.ds[0][11]=this.vert;
return this.ds;
});

Clazz.newMeth(C$, 'setFilled$Z', function (f) {
this.filled=f;
});

Clazz.newMeth(C$, 'setFixedLength$Z', function (f) {
this.fixedlength=f;
});

Clazz.newMeth(C$, 'getH$', function () {
return this.vert;
});

Clazz.newMeth(C$, 'setH$D', function (vert) {
this.vert=vert;
});

Clazz.newMeth(C$, 'getW$', function () {
return this.horz;
});

Clazz.newMeth(C$, 'setW$D', function (horz) {
this.horz=horz;
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
if (this.insideTip) {
this.horz=x - this.vars[1];
this.vert=y - this.vars[2];
if (this.fixedlength) {
var len=Math.sqrt(this.horz * this.horz + this.vert * this.vert);
if (len == 0 ) return;
this.horz=this.length * this.horz / len;
this.vert=this.length * this.vert / len;
}return;
}C$.superclazz.prototype.setXY$D$D.apply(this, [x, y]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:44 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
