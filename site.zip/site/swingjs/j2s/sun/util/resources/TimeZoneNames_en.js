(function(){var P$=Clazz.newPackage("sun.util.resources"),I$=[];
var C$=Clazz.newClass(P$, "TimeZoneNames_en", null, 'sun.util.resources.TimeZoneNamesBundle');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getContents', function () {
return Clazz.array(java.lang.Object, -2, []);
});

Clazz.newMeth(C$);
})();
//Created 2018-05-24 08:47:39
