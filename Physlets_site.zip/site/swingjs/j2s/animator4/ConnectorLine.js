(function(){var P$=Clazz.newPackage("animator4"),I$=[];
var C$=Clazz.newClass(P$, "ConnectorLine", null, 'animator4.Connector');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$animator4_Thing$animator4_Thing', function (o, t1, t2) {
C$.superclazz.c$$animator4_AnimatorCanvas$animator4_Thing$animator4_Thing.apply(this, [o, t1, t2]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
if (this.thing1 == null  || this.thing2 == null  ) return;
var ptX1 = this.canvas.pixFromX$D(this.thing1.vars[1]);
var ptY1 = this.canvas.pixFromY$D(this.thing1.vars[2]);
var ptX2 = this.canvas.pixFromX$D(this.thing2.vars[1]);
var ptY2 = this.canvas.pixFromY$D(this.thing2.vars[2]);
g.setColor$java_awt_Color(this.color);
g.drawLine$I$I$I$I(ptX1, ptY1, ptX2, ptY2);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:20:58
