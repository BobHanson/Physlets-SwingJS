(function(){var P$=Clazz.newPackage("edu.clarku.tools"),I$=[];
var C$=Clazz.newClass(P$, "WrongNumberOfVariables", null, 'IllegalArgumentException');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (s) {
C$.superclazz.c$$S.apply(this, [s]);
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-02-24 16:21:09
