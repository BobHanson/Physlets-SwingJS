(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ProtractorThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.insideTip1 = false;
this.insideTip2 = false;
this.angle1 = 0;
this.angle2 = 0;
this.spot = 0;
this.fixedBase = false;
this.fixedlength = false;
this.len = 0;
this.color2 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.insideTip1 = false;
this.insideTip2 = false;
this.spot = 4;
this.fixedBase = false;
this.fixedlength = false;
this.color2 = (I$[1]||$incl$(1)).green;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D$D$D', function (owner, sc, s, theta, theta0, x, y) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, x, y]);
C$.$init$.apply(this);
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "theta", "theta0"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
this.s = s;
this.len = s;
this.angle1 = theta0;
this.angle2 = theta + theta0;
this.color = (I$[1]||$incl$(1)).red;
this.resizable = true;
}, 1);

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
var xpixPerUnit = this.canvas.pixFromX$D(1) - this.canvas.pixFromX$D(0);
var ypixPerUnit = -this.canvas.pixFromY$D(1) + this.canvas.pixFromY$D(0);
if (this.insideTip1) {
var horz = x - this.x;
var vert = y - this.y;
if (horz == 0  && vert == 0  ) return;
this.angle1 = Math.atan2(vert, horz * xpixPerUnit / ypixPerUnit);
return;
}if (this.insideTip2) {
var horz = x - this.x;
var vert = y - this.y;
if (!this.fixedlength) {
if (horz == 0  && vert == 0  ) return;
this.len = ((Math.sqrt(horz * horz * xpixPerUnit * xpixPerUnit  + vert * vert * ypixPerUnit * ypixPerUnit ))|0);
this.len = Math.max(this.len, this.spot);
}if (horz == 0  && vert == 0  ) return;
this.angle2 = Math.atan2(vert, horz * xpixPerUnit / ypixPerUnit);
return;
}C$.superclazz.prototype.setXY$D$D.apply(this, [x, y]);
});

Clazz.newMeth(C$, 'setProperties$I$D$D', function (sid, alpha, beta) {
if (sid == 3) {
this.angle1 = alpha;
this.angle2 = alpha + beta;
} else if (sid == 4) {
this.insideTip1 = true;
this.insideTip2 = false;
this.setXY$D$D(alpha, beta);
this.insideTip1 = false;
} else if (sid == 5) {
this.insideTip1 = false;
this.insideTip2 = true;
this.setXY$D$D(alpha, beta);
this.insideTip2 = false;
} else if (sid == 6) {
this.setX$D(alpha);
} else if (sid == 7) {
this.setY$D(beta);
}});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
this.insideTip1 = false;
this.insideTip2 = false;
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
if (!this.noDrag && (Math.abs(xPix - ptX) < this.spot) && (Math.abs(yPix - ptY) < this.spot)  ) return true;
if (this.resizable && !this.fixedBase && (Math.abs(xPix - ptX - this.s * Math.cos(this.angle1) ) < this.spot ) && (Math.abs(yPix - ptY + this.s * Math.sin(this.angle1)) < this.spot )  ) {
this.insideTip1 = true;
return true;
}if (this.resizable && (Math.abs(xPix - ptX - this.len * Math.cos(this.angle2) ) < this.spot ) && (Math.abs(yPix - ptY + this.len * Math.sin(this.angle2)) < this.spot )  ) {
this.insideTip2 = true;
return true;
}return false;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX = Math.round(this.canvas.pixFromX$D(this.x)) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.y)) - this.yDisplayOff;
var background = (I$[1]||$incl$(1)).white;
if (Clazz.instanceOf(this.canvas, "a2s.Panel")) background = (this.canvas).getBackground();
if (background === (I$[1]||$incl$(1)).black ) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
 else osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
var x2 = ((ptX + this.s * Math.cos(this.angle1))|0);
var y2 = ((ptY - this.s * Math.sin(this.angle1))|0);
osg.drawLine$I$I$I$I(ptX, ptY, x2, y2);
x2 = ((ptX + this.len * Math.cos(this.angle2))|0);
y2 = ((ptY - this.len * Math.sin(this.angle2))|0);
osg.setColor$java_awt_Color(this.color);
osg.drawLine$I$I$I$I(ptX, ptY, x2, y2);
x2 = ((ptX + this.s * Math.cos(this.angle2))|0);
y2 = ((ptY - this.s * Math.sin(this.angle2))|0);
var begin = ((180 * this.angle1 / 3.141592653589793)|0);
var arc = this.angle2 - this.angle1;
if (arc > 3.141592653589793 ) arc = arc - 6.283185307179586;
 else if (arc < -3.141592653589793 ) arc = arc + 6.283185307179586;
var arcsize = Math.min(this.s, this.len);
osg.drawArc$I$I$I$I$I$I(ptX - (arcsize/2|0), ptY - (arcsize/2|0), arcsize, arcsize, begin, ((180 * arc / 3.141592653589793)|0));
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
if (!this.noDrag) {
if (this.color !== (I$[1]||$incl$(1)).lightGray ) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).lightGray);
 else this.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
osg.fillOval$I$I$I$I(ptX - 2, ptY - 2, 5, 5);
osg.setColor$java_awt_Color(this.color);
osg.drawOval$I$I$I$I(ptX - 2, ptY - 2, 5, 5);
}if (this.resizable) {
if (this.color !== (I$[1]||$incl$(1)).lightGray ) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).lightGray);
 else this.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
x2 = ((ptX + this.len * Math.cos(this.angle2))|0);
y2 = ((ptY - this.len * Math.sin(this.angle2))|0);
osg.fillOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
osg.setColor$java_awt_Color(this.color);
osg.drawOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
}if (this.resizable && !this.fixedBase ) {
if (this.color !== (I$[1]||$incl$(1)).lightGray ) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).lightGray);
 else this.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
x2 = ((ptX + this.s * Math.cos(this.angle1))|0);
y2 = ((ptY - this.s * Math.sin(this.angle1))|0);
osg.fillOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
osg.setColor$java_awt_Color(this.color);
osg.drawOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
}if (this.label != null ) {
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
var f = osg.getFont();
osg.setFont$java_awt_Font(this.font);
var fm = osg.getFontMetrics$java_awt_Font(this.font);
osg.drawString$S$I$I(this.label, ptX, ptY);
osg.setFont$java_awt_Font(f);
}});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.time;
this.ds[0][1] = this.x;
this.ds[0][2] = this.y;
var arc = this.angle2 - this.angle1;
if (arc > 3.141592653589793 ) arc = arc - 6.283185307179586;
 else if (arc < -3.141592653589793 ) arc = arc + 6.283185307179586;
this.ds[0][3] = arc;
this.ds[0][4] = this.angle1;
return this.ds;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:07:13
