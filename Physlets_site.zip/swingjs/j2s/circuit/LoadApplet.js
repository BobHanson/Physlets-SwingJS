(function(){var P$=Clazz.newPackage("circuit"),I$=[['java.awt.Color','edu.davidson.graphics.EtchedBorder','edu.davidson.display.SSlider','edu.davidson.display.SNumber','circuit.Circuit','edu.davidson.graphics.Box','circuit.Common',['circuit.LoadApplet','.LoadGraph'],'java.awt.BorderLayout','java.awt.Label','Boolean','java.awt.Dimension','circuit.LoadApplet_rNumber_actionAdapter','circuit.LoadApplet_rSlider_adjustmentAdapter','java.net.URL']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "LoadApplet", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.currentStr = null;
this.rmin = 0;
this.rmax = 0;
this.showControls = false;
this.showGraph = false;
this.showPower = false;
this.defaultCircuit = false;
this.preferredPixPerCell = 0;
this.etchedBorder1 = null;
this.etchedBorder2 = null;
this.rSlider = null;
this.rNumber = null;
this.circuit = null;
this.circuitBox = null;
this.graph = null;
this.borderLayout1 = null;
this.borderLayout2 = null;
this.borderLayout3 = null;
this.label1 = null;
this.xold = 0;
this.yold = 0;
this.bat = null;
this.load = null;
this.meter = null;
this.unknown = null;
this.loadRes = 0;
this.unknownRes = 0;
this.batVolt = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.showControls = true;
this.showGraph = true;
this.showPower = false;
this.defaultCircuit = true;
this.preferredPixPerCell = 60;
this.etchedBorder1 = Clazz.new_((I$[2]||$incl$(2)));
this.etchedBorder2 = Clazz.new_((I$[2]||$incl$(2)));
this.rSlider = Clazz.new_((I$[3]||$incl$(3)));
this.rNumber = Clazz.new_((I$[4]||$incl$(4)));
this.circuit = Clazz.new_((I$[5]||$incl$(5)).c$$edu_davidson_tools_SApplet,[this]);
this.circuitBox = Clazz.new_((I$[6]||$incl$(6)).c$$java_awt_Component$S,[this.circuit, (I$[7]||$incl$(7)).CIRCUIT]);
this.graph = Clazz.new_((I$[8]||$incl$(8)), [this, null]);
this.borderLayout1 = Clazz.new_((I$[9]||$incl$(9)));
this.borderLayout2 = Clazz.new_((I$[9]||$incl$(9)));
this.borderLayout3 = Clazz.new_((I$[9]||$incl$(9)));
this.label1 = Clazz.new_((I$[10]||$incl$(10)));
this.unknownRes = 20;
this.batVolt = 12;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
var dt = 0.1;
var fps = 10;
var resourceFile = "";
try {
resourceFile = this.getParameter$S$S("Resources", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (resourceFile != null  && !resourceFile.equals$O("") ) this.loadResources$S(resourceFile);
try {
fps = Double.$valueOf(this.getParameter$S$S("FPS", "10")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
dt = Double.$valueOf(this.getParameter$S$S("dt", "0.1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.defaultCircuit = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("DefaultCircuit", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.batVolt = Double.$valueOf(this.getParameter$S$S("Battery", "12")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.unknownRes = Double.$valueOf(this.getParameter$S$S("Unknown", "20")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showGraph = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowGraph", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (this.showGraph) this.preferredPixPerCell = 60;
 else this.preferredPixPerCell = 200;
try {
this.rmin = Double.$valueOf(this.getParameter$S$S("Rmin", "0")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.rmax = Double.$valueOf(this.getParameter$S$S("Rmax", "100")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showPower = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("PowerGraphType", "false")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.preferredPixPerCell = Integer.parseInt(this.getParameter$S$S("PixPerCell", "" + this.preferredPixPerCell));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.clock.setDt$D(dt);
this.clock.setFPS$D((fps|0));
this.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.etchedBorder2.setVisible$Z(this.showControls);
if (this.showPower) this.graph.setLabelY$S((I$[7]||$incl$(7)).LOAD_POWER);
 else this.graph.setLabelY$S((I$[7]||$incl$(7)).VOLTAGE);
this.graph.deleteAllSeries();
this.graph.setMinMaxX$D$D(this.rmin, this.rmax);
this.graph.setMinMaxY$D$D(-1, 1);
this.graph.setEnableMouse$Z(true);
this.graph.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.rSlider.setDMax$D(this.rmax);
this.rSlider.setDMin$D(this.rmin);
this.loadRes = (this.rmax + this.rmin) / 2;
this.rSlider.setDValue$D(this.loadRes);
this.rNumber.setValue$D(this.loadRes);
this.loadRes = this.rNumber.getValue();
this.rNumber.addPropertyChangeListener$java_beans_PropertyChangeListener(this.rSlider);
this.rSlider.addPropertyChangeListener$java_beans_PropertyChangeListener(this.rNumber);
if (this.rmax < 100 ) this.rNumber.setFormat$S("%6.1f");
 else this.rNumber.setFormat$S("%6.0f");
if (this.defaultCircuit) {
p$.createCircuit.apply(this, []);
p$.setCircuitValues.apply(this, []);
this.plotFunction();
this.graph.setVisible$Z(this.showGraph);
} else {
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
this.circuit.setGridSize$I$I(4, 2);
this.showGraph = false;
this.graph.setVisible$Z(false);
}});

Clazz.newMeth(C$, 'createCircuit', function () {
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
this.circuit.setGridSize$I$I(4, 2);
this.bat = this.circuit.addBattery$I$I$I$I(0, 1, 0, 0);
this.unknown = this.circuit.addResistor$I$I$I$I(0, 1, 1, 1);
this.unknown.setLabel$S("Rx");
this.unknown.showR = false;
this.unknown.showV = true;
this.circuit.addWire$I$I$I$I(1, 1, 2, 1);
this.circuit.addWire$I$I$I$I(0, 0, 2, 0);
this.load = this.circuit.addResistor$I$I$I$I(2, 1, 2, 0);
this.load.setLabel$S("Rl");
this.load.showR = true;
this.load.showV = true;
this.circuit.addWire$I$I$I$I(2, 0, 3, 0);
this.circuit.addWire$I$I$I$I(2, 1, 3, 1);
this.meter = this.circuit.addVoltmeter$I$I$I$I(3, 0, 3, 1);
});

Clazz.newMeth(C$, 'setCircuitValues', function () {
this.bat.setVoltRMS$D(this.batVolt);
this.unknown.setR$D(this.unknownRes);
this.load.setR$D(this.loadRes);
var vout = p$.outVolt$D.apply(this, [this.loadRes]);
var i = this.batVolt / (this.unknownRes + this.loadRes);
this.meter.setVoltRMS$D(vout);
this.load.setVoltRMS$D(vout);
this.load.setVoltInstantaneous$D(vout);
this.load.setCurrentInstantaneous$D(i);
this.unknown.setVoltRMS$D(this.batVolt - vout);
this.unknown.setVoltInstantaneous$D(this.batVolt - vout);
this.unknown.setCurrentInstantaneous$D(i);
this.updateDataConnections();
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.setSize$java_awt_Dimension(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[740, 390]));
this.rSlider.setDMax$D(200.0);
this.rNumber.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[13]||$incl$(13)).c$$circuit_LoadApplet,[this]));
this.rSlider.addAdjustmentListener$java_awt_event_AdjustmentListener(Clazz.new_((I$[14]||$incl$(14)).c$$circuit_LoadApplet,[this]));
this.circuitBox.setTitle$S((I$[7]||$incl$(7)).CIRCUIT);
this.graph.setLabelY$S((I$[7]||$incl$(7)).LOAD_POWER);
this.label1.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.label1.setAlignment$I(1);
this.label1.setText$S((I$[7]||$incl$(7)).LOAD_RESISTOR);
this.graph.setSampleData$Z(false);
this.graph.setAutoscaleX$Z(false);
this.graph.setAutoscaleY$Z(true);
this.graph.setLabelX$S((I$[7]||$incl$(7)).LOAD_RESISTOR);
this.etchedBorder2.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.add$java_awt_Component$O(this.etchedBorder1, "Center");
this.etchedBorder1.add$java_awt_Component$O(this.circuitBox, "West");
this.etchedBorder1.add$java_awt_Component$O(this.graph, "Center");
this.add$java_awt_Component$O(this.etchedBorder2, "South");
this.etchedBorder2.add$java_awt_Component$O(this.rSlider, "Center");
this.etchedBorder2.add$java_awt_Component$O(this.rNumber, "East");
this.etchedBorder2.add$java_awt_Component$O(this.label1, "West");
});

Clazz.newMeth(C$, 'loadResources$S', function (rc) {
if (rc == null ) return;
try {
(I$[7]||$incl$(7)).initResources$java_io_InputStream(Clazz.new_((I$[15]||$incl$(15)).c$$java_net_URL$S,[this.getCodeBase(), rc]).openStream());
(I$[7]||$incl$(7)).setResources();
return;
} catch (x) {
if (Clazz.exceptionOf(x, "java.lang.Exception")){
} else {
throw x;
}
}
try {
(I$[7]||$incl$(7)).initResources$java_io_InputStream(Clazz.new_((I$[15]||$incl$(15)).c$$java_net_URL$S,[this.getDocumentBase(), rc]).openStream());
(I$[7]||$incl$(7)).setResources();
} catch (x) {
if (Clazz.exceptionOf(x, "java.lang.Exception")){
System.out.println$S("Can't load resources! : " + x.getMessage());
return;
} else {
throw x;
}
}
});

Clazz.newMeth(C$, 'destroy', function () {
this.circuit.forceBubbleHelp$S(null);
this.graph.destroy();
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'start', function () {
this.graph.setOwner$edu_davidson_tools_SApplet(this);
this.graph.repaint();
C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'stop', function () {
this.oneShotMsg = null;
this.circuit.forceBubbleHelp$S(null);
C$.superclazz.prototype.stop.apply(this, []);
});

Clazz.newMeth(C$, 'forward', function () {
this.circuit.forceBubbleHelp$S(null);
C$.superclazz.prototype.forward.apply(this, []);
});

Clazz.newMeth(C$, 'stoppingClock', function () {
this.circuit.forceBubbleHelp$S(this.oneShotMsg);
});

Clazz.newMeth(C$, 'cyclingClock', function () {
this.clock.setTime$D(0);
this.load.setTime$D(0);
this.unknown.setTime$D(0);
this.clearAllData();
});

Clazz.newMeth(C$, 'getUnknownID', function () {
return this.unknown.getID();
});

Clazz.newMeth(C$, 'getLoadID', function () {
return this.load.getID();
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "LoadApplet by Wolfgang Christian, wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Unknown", "double", "Internal resitance of battery."]), Clazz.array(java.lang.String, -1, ["Battery", "double", "Battery emf."]), Clazz.array(java.lang.String, -1, ["Vmin", "double", "Voltage min"]), Clazz.array(java.lang.String, -1, ["Vmax", "double", "Voltage max"]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show controls."]), Clazz.array(java.lang.String, -1, ["PowerGraphType", "boolean", "Plot load power as a function of resistance."])]);
return pinfo;
});

Clazz.newMeth(C$, 'plotFunc$D', function (r) {
if (this.showPower) return this.batVolt * this.batVolt * r  / (r + this.unknownRes) / (r + this.unknownRes);
 else return this.batVolt * r / (r + this.unknownRes);
});

Clazz.newMeth(C$, 'outVolt$D', function (r) {
return this.batVolt * r / (r + this.unknownRes);
});

Clazz.newMeth(C$, 'plotFunction', function () {
var np = 200;
var dr = (this.rmax - this.rmin) / (np - 1);
var x = Clazz.array(Double.TYPE, [np]);
var y = Clazz.array(Double.TYPE, [np]);
for (var i = 0; i < np; i++) {
x[i] = this.rmin + i * dr;
y[i] = p$.plotFunc$D.apply(this, [x[i]]);
}
this.graph.setAutoReplaceData$I$Z(3, true);
this.graph.clearSeriesData$I(3);
this.graph.addData$I$DA$DA(3, x, y);
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(3, (I$[1]||$incl$(1)).red, true, 0);
this.xold = -100;
this.yold = -100;
});

Clazz.newMeth(C$, 'adjustLoad$D', function (r) {
this.loadRes = r;
if (this.loadRes < this.rmin ) {
this.loadRes = this.rmin;
this.rSlider.setDValue$D(this.loadRes);
}if (this.loadRes > this.rmax ) {
this.loadRes = this.rmax;
this.rSlider.setDValue$D(this.loadRes);
}var v = p$.plotFunc$D.apply(this, [r]);
var xpix = this.graph.pixFromX$D(r);
var ypix = this.graph.pixFromY$D(v);
var g = this.graph.getGraphics();
g.setColor$java_awt_Color((I$[1]||$incl$(1)).green);
g.setXORMode$java_awt_Color((I$[1]||$incl$(1)).red);
g.fillOval$I$I$I$I(this.xold - 5, this.yold - 5, 10, 10);
g.fillOval$I$I$I$I(xpix - 5, ypix - 5, 10, 10);
this.xold = xpix;
this.yold = ypix;
g.setPaintMode();
g.dispose();
p$.setCircuitValues.apply(this, []);
});

Clazz.newMeth(C$, 'rSlider_adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
this.adjustLoad$D(this.rSlider.getDValue());
});

Clazz.newMeth(C$, 'rNumber_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.rNumber.isValid()) this.adjustLoad$D(this.rNumber.getValue());
});

Clazz.newMeth(C$, ['setPixPerCell$I','setPixPerCell'], function (ppc) {
this.preferredPixPerCell = ppc;
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
});

Clazz.newMeth(C$, 'setDefault', function () {
this.oneShotMsg = null;
this.deleteDataConnections();
this.circuit.setDefault$I(this.preferredPixPerCell);
p$.createCircuit.apply(this, []);
p$.setCircuitValues.apply(this, []);
this.graph.setTitle$S(null);
if (this.graph.isVisible()) this.plotFunction();
});

Clazz.newMeth(C$, ['setTitle$S','setTitle'], function (str) {
this.graph.setTitle$S(str);
});

Clazz.newMeth(C$, ['setPowerGraphType$Z','setPowerGraphType'], function (sp) {
this.showPower = sp;
if (this.showPower) this.graph.setLabelY$S((I$[7]||$incl$(7)).LOAD_POWER);
 else this.graph.setLabelY$S((I$[7]||$incl$(7)).VOLTAGE);
this.plotFunction();
this.graph.repaint();
});

Clazz.newMeth(C$, ['setShowGraph$Z','setShowGraph'], function (sg) {
if (this.graph.isVisible() == sg ) {
this.plotFunction();
return;
}this.showGraph = sg;
this.graph.setVisible$Z(sg);
this.invalidate();
this.validate();
if (sg) this.plotFunction();
});

Clazz.newMeth(C$, ['setUnknown$D','setUnknown'], function (r) {
this.unknownRes = r;
p$.setCircuitValues.apply(this, []);
if (this.graph.isVisible()) this.plotFunction();
});

Clazz.newMeth(C$, ['setVoltage$D','setVoltage'], function (v) {
this.batVolt = v;
p$.setCircuitValues.apply(this, []);
if (this.graph.isVisible()) this.plotFunction();
});

Clazz.newMeth(C$, ['setLoad$D','setLoad'], function (r) {
this.rSlider.setDValue$D(r);
this.adjustLoad$D(r);
});

Clazz.newMeth(C$, ['setBatteryHint$S','setBatteryHint'], function (str) {
return this.circuit.setHint$I$S(this.bat.getID(), str);
});

Clazz.newMeth(C$, ['setVoltmeterHint$S','setVoltmeterHint'], function (str) {
return this.circuit.setHint$I$S(this.meter.getID(), str);
});

Clazz.newMeth(C$, ['setLoadHint$S','setLoadHint'], function (str) {
return this.circuit.setHint$I$S(this.load.getID(), str);
});

Clazz.newMeth(C$, ['setUnknownHint$S','setUnknownHint'], function (str) {
return this.circuit.setHint$I$S(this.unknown.getID(), str);
});
;
(function(){var C$=Clazz.newClass(P$.LoadApplet, "LoadGraph", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'edu.davidson.display.SGraph');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'paintLast$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
C$.superclazz.prototype.paintLast$java_awt_Graphics$java_awt_Rectangle.apply(this, [g, r]);
g.clipRect$I$I$I$I(r.x, r.y, r.width, r.height);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).green);
g.setXORMode$java_awt_Color((I$[1]||$incl$(1)).red);
var xx = this.this$0.rSlider.getDValue();
this.this$0.xold = this.this$0.graph.pixFromX$D(xx);
this.this$0.yold = this.this$0.graph.pixFromY$D(this.this$0.plotFunc$D.apply(this.this$0, [xx]));
g.fillOval$I$I$I$I(this.this$0.xold - 5, this.this$0.yold - 5, 10, 10);
g.setPaintMode();
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-02-20 07:13:05
