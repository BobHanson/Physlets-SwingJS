(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['edu.davidson.graphics.HintPanel','edu.davidson.graphics.Border','edu.davidson.graphics.EtchedRectangle']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EtchedBorder", null, 'edu.davidson.graphics.Border');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$java_awt_Component.apply(this, [Clazz.new_((I$[1]||$incl$(1)))]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component', function (borderMe) {
C$.c$$java_awt_Component$I$I.apply(this, [borderMe, (I$[2]||$incl$(2))._defaultThickness, (I$[2]||$incl$(2))._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I', function (borderMe, borderThickness) {
C$.c$$java_awt_Component$I$I.apply(this, [borderMe, borderThickness, (I$[2]||$incl$(2))._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I$I', function (borderMe, borderThickness, gap) {
C$.superclazz.c$$java_awt_Component$I$I.apply(this, [borderMe, borderThickness, gap]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'etchedIn', function () {
(this.myBorder()).etchedIn();
});

Clazz.newMeth(C$, 'etchedOut', function () {
(this.myBorder()).etchedOut();
});

Clazz.newMeth(C$, 'paintEtchedIn', function () {
(this.myBorder()).paintEtchedIn();
});

Clazz.newMeth(C$, 'paintEtchedOut', function () {
(this.myBorder()).paintEtchedOut();
});

Clazz.newMeth(C$, 'isEtchedIn', function () {
return (this.myBorder()).isEtchedIn();
});

Clazz.newMeth(C$, 'paramString', function () {
return C$.superclazz.prototype.paramString.apply(this, []) + this.myBorder();
});

Clazz.newMeth(C$, 'myBorder', function () {
if (this.$border == null ) this.$border = Clazz.new_((I$[3]||$incl$(3)).c$$java_awt_Component$I,[this, this.thickness]);
return this.$border;
});

Clazz.newMeth(C$, 'setEtchedIn$Z', function (ei) {
if (ei) this.paintEtchedIn();
 else this.paintEtchedOut();
});
})();
//Created 2018-02-06 13:24:18
