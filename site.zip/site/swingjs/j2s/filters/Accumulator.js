(function(){var P$=Clazz.newPackage("filters"),I$=[['edu.davidson.graphics.EtchedBorder','java.awt.BorderLayout','edu.davidson.display.SNumber','java.awt.Panel','java.awt.Label','java.awt.FlowLayout','java.awt.Button','edu.davidson.display.SInteger','java.awt.Toolkit','Boolean','filters.Accumulator$1','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Accumulator", null, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataListener', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.numPts = 0;
this.showControls = false;
this.autoReplace = false;
this.varStrings = null;
this.ds = null;
this.nextIndex = 0;
this.controlPanel = null;
this.borderLayout1 = null;
this.yField = null;
this.panel3 = null;
this.minLabel2 = null;
this.xField = null;
this.panel4 = null;
this.minLabel3 = null;
this.flowLayout1 = null;
this.resetBtn = null;
this.numLabel = null;
this.panel1 = null;
this.numField = null;
this.tk = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.numPts = 100;
this.showControls = true;
this.autoReplace = true;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y"]);
this.ds = null;
this.nextIndex = 0;
this.controlPanel = Clazz.new_((I$[1]||$incl$(1)));
this.borderLayout1 = Clazz.new_((I$[2]||$incl$(2)));
this.yField = Clazz.new_((I$[3]||$incl$(3)));
this.panel3 = Clazz.new_((I$[4]||$incl$(4)));
this.minLabel2 = Clazz.new_((I$[5]||$incl$(5)));
this.xField = Clazz.new_((I$[3]||$incl$(3)));
this.panel4 = Clazz.new_((I$[4]||$incl$(4)));
this.minLabel3 = Clazz.new_((I$[5]||$incl$(5)));
this.flowLayout1 = Clazz.new_((I$[6]||$incl$(6)));
this.resetBtn = Clazz.new_((I$[7]||$incl$(7)));
this.numLabel = Clazz.new_((I$[5]||$incl$(5)));
this.panel1 = Clazz.new_((I$[4]||$incl$(4)));
this.numField = Clazz.new_((I$[8]||$incl$(8)));
this.tk = (I$[9]||$incl$(9)).getDefaultToolkit();
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.numPts=Integer.parseInt(this.getParameter$S$S("NumPts", "100"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls=(I$[10]||$incl$(10)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.controlPanel.setVisible$Z(this.showControls);
this.setNumPts$I(this.numPts);
edu.davidson.tools.SApplet.addDataListener$O(this);
edu.davidson.tools.SApplet.addDataSource$O(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.minLabel2.setText$S("Last Y");
this.minLabel2.setAlignment$I(2);
this.minLabel3.setText$S("Last X");
this.minLabel3.setAlignment$I(2);
this.controlPanel.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.resetBtn.setLabel$S("Reset");
this.resetBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Accumulator$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['filters.Accumulator'].resetBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[11]||$incl$(11)).$init$, [this, null])));
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("Max #");
this.xField.setEditable$Z(false);
this.xField.setText$S("??");
this.yField.setEditable$Z(false);
this.yField.setText$S("??");
this.controlPanel.setBackground$java_awt_Color((I$[12]||$incl$(12)).lightGray);
this.controlPanel.setFillColor$java_awt_Color((I$[12]||$incl$(12)).lightGray);
this.add$java_awt_Component$O(this.controlPanel, "Center");
this.controlPanel.add$java_awt_Component$O(this.resetBtn, null);
this.controlPanel.add$java_awt_Component$O(this.panel1, null);
this.panel1.add$java_awt_Component$O(this.numLabel, null);
this.panel1.add$java_awt_Component$O(this.numField, null);
this.controlPanel.add$java_awt_Component$O(this.panel4, null);
this.panel4.add$java_awt_Component$O(this.minLabel3, null);
this.panel4.add$java_awt_Component$O(this.xField, null);
this.controlPanel.add$java_awt_Component$O(this.panel3, null);
this.panel3.add$java_awt_Component$O(this.minLabel2, null);
this.panel3.add$java_awt_Component$O(this.yField, null);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Accumulator Physlet written by W. Christian.  Accumulate datum to produce a data set.";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["NumPts", "int", "The number of points to put into data set."]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the user interface."])]);
return pinfo;
});

Clazz.newMeth(C$, ['setNumPts$I','setNumPts'], function (n) {
if (n < 1) {
System.out.println$S("Number of points must be >0.");
}this.numPts=Math.max(1, n);
this.ds=Clazz.array(Double.TYPE, [this.numPts, 2]);
for (var i = 0; i < this.numPts; i++) {
this.ds[i][0]=0;
this.ds[i][1]=0;
}
this.nextIndex=0;
if (this.showControls && this.getBounds().width > 50 ) {
this.xField.setText$S("??");
this.xField.setText$S("??");
this.numField.setValue$I(0);
}this.updateDataConnections();
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, x, y) {
if (this.autoReplace) {
this.ds[this.nextIndex][0]=x;
this.ds[this.nextIndex][1]=y;
this.nextIndex++;
if (this.showControls && this.getBounds().width > 50 ) {
this.xField.setValue$D(x);
this.yField.setValue$D(y);
this.numField.setValue$I(this.nextIndex);
}if (this.nextIndex == this.numPts) {
this.nextIndex=0;
this.updateDataConnections();
return;
}} else {
if (this.nextIndex == 0) {
this.nextIndex=this.numPts;
for (var i = 0; i < this.numPts; i++) {
this.ds[i][0]=x;
this.ds[i][1]=y;
}
} else for (var i = 1; i < this.numPts; i++) {
this.ds[i - 1][0]=this.ds[i][0];
this.ds[i - 1][1]=this.ds[i][1];
}
this.ds[this.numPts - 1][0]=x;
this.ds[this.numPts - 1][1]=y;
if (this.showControls && this.getBounds().width > 50 ) {
this.xField.setValue$D(x);
this.yField.setValue$D(y);
this.numField.setValue$I(this.nextIndex);
this.tk.sync();
}this.updateDataConnections();
}});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
if (this.showControls && this.getBounds().width > 50 ) {
this.xField.setValue$D(x[0]);
this.yField.setValue$D(y[0]);
this.numField.setValue$I(this.nextIndex);
}var n = x.length;
for (var i = 0; i < n; i++) {
if (this.autoReplace) {
this.ds[this.nextIndex][0]=x[i];
this.ds[this.nextIndex][1]=y[i];
this.nextIndex++;
if (this.nextIndex == this.numPts) {
this.nextIndex=0;
this.updateDataConnections();
return;
}}}
});

Clazz.newMeth(C$, 'reset', function () {
for (var i = 0; i < this.numPts; i++) {
this.ds[i][0]=0;
this.ds[i][1]=0;
}
this.nextIndex=0;
if (this.showControls && this.getBounds().width > 50 ) {
this.xField.setText$S("??");
this.xField.setText$S("??");
this.numField.setValue$I(this.nextIndex);
}this.updateDataConnections();
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.reset();
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
if (this.autoReplace) this.reset();
});

Clazz.newMeth(C$, ['setAutoReplaceData$I$Z','setAutoReplaceData'], function (id, replace) {
this.autoReplace=replace;
if (this.autoReplace && this.nextIndex >= this.numPts ) this.reset();
});

Clazz.newMeth(C$, 'resetBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.reset();
this.tk.beep();
});
})();
//Created 2018-07-20 18:09:32
