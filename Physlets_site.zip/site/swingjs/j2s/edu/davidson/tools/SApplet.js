(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[['java.util.Hashtable','edu.davidson.tools.SClock','edu.davidson.tools.BusyFlag','java.util.Vector','edu.davidson.display.Format','edu.davidson.tools.Crypt','java.util.Properties','java.net.URL','edu.davidson.tools.SDataConnection','java.lang.StringBuffer','edu.davidson.tools.SUtil','java.util.StringTokenizer','java.awt.Font']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SApplet", null, 'a2s.Applet');
C$.dataSources = null;
C$.dataListeners = null;
C$.runningID = null;
C$.appletCount = 0;
C$.staticDebugLevel = 0;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.dataSources = Clazz.new_((I$[1]||$incl$(1)).c$$I,[50]);
C$.dataListeners = Clazz.new_((I$[1]||$incl$(1)).c$$I,[20]);
C$.runningID = null;
C$.appletCount = 0;
C$.staticDebugLevel = 0;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.localClock = null;
this.clock = null;
this.lock = null;
this.dataConnections = null;
this.oneShotMsg = null;
this.autoRefresh = false;
this.firstTime = false;
this.debugLevel = 0;
this.formatString = null;
this.formatD = null;
this.formatI = null;
this.independentClock = false;
this.started = false;
this.destroyed = false;
this.crypt = null;
this.isStandalone = false;
this.localProperties = null;
this.loadThread = null;
this.onloadStr = null;
this.appletNames = null;
this.scriptHasRun = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.localClock = Clazz.new_((I$[2]||$incl$(2)).c$$edu_davidson_tools_SApplet,[this]);
this.clock = this.localClock;
this.lock = Clazz.new_((I$[3]||$incl$(3)));
this.dataConnections = Clazz.new_((I$[4]||$incl$(4)));
this.oneShotMsg = null;
this.autoRefresh = true;
this.firstTime = true;
this.debugLevel = 0;
this.formatString = "%-+6.2g";
this.formatD = Clazz.new_((I$[5]||$incl$(5)).c$$S,[this.formatString]);
this.formatI = Clazz.new_((I$[5]||$incl$(5)).c$$S,["%-+6d"]);
this.independentClock = false;
this.started = false;
this.destroyed = false;
this.crypt = Clazz.new_((I$[6]||$incl$(6)));
this.isStandalone = false;
this.localProperties = Clazz.new_((I$[7]||$incl$(7)));
this.onloadStr = "";
this.appletNames = "";
this.scriptHasRun = false;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'getParameter$S$S', function (key, def) {
return this.isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'runJavaScript', function () {
try {
this.onloadStr = this.getParameter$S$S("OnLoad", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.appletNames = this.getParameter$S$S("AppletNames", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (!this.onloadStr.equals$O("")) {
this.scriptHasRun = false;
if (this.debugLevel > 127) System.out.println$S("starting new OnLoadThread");
} else this.scriptHasRun = true;
});

Clazz.newMeth(C$, 'initResources$S', function (resourceFile) {
var loaded = false;
try {
this.debugLevel = Integer.parseInt(this.getParameter$S$S("Debug", "0"));
C$.staticDebugLevel = this.debugLevel;
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
var cryptokey = this.getParameter$S$S("Key", "");
if (!cryptokey.equals$O("")) this.crypt.setKey$S(cryptokey);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (resourceFile == null  || resourceFile.equals$O("") ) {
try {
resourceFile = this.getParameter$S$S("Resources", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}if (resourceFile != null  && !resourceFile.equals$O("") ) {
try {
loaded = true;
this.localProperties.load$java_io_InputStream(Clazz.new_((I$[8]||$incl$(8)).c$$java_net_URL$S,[this.getCodeBase(), resourceFile]).openStream());
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
loaded = false;
} else {
throw ex;
}
}
if (!loaded) {
try {
loaded = true;
this.localProperties.load$java_io_InputStream(Clazz.new_((I$[8]||$incl$(8)).c$$java_net_URL$S,[this.getDocumentBase(), resourceFile]).openStream());
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
loaded = false;
} else {
throw ex;
}
}
}if (!loaded) {
try {
loaded = true;
var resourcePath = resourceFile;
if (!resourceFile.startsWith$S("/")) resourcePath = "/" + resourceFile;
this.localProperties.load$java_io_InputStream(Clazz.getClass(C$).getResource$S(resourcePath).openStream());
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
loaded = false;
} else {
throw e;
}
}
}if (!loaded) {
System.out.println$S("Can't load resource: " + resourceFile);
} else {
this.setResources();
var cryptokey = this.localProperties.getProperty$S$S("key", "");
if (!cryptokey.equals$O("")) this.crypt.setKey$S(cryptokey);
}return loaded;
} else return false;
});

Clazz.newMeth(C$, 'setResources', function () {
});

Clazz.newMeth(C$, 'destroy', function () {
this.destroyed = false;
this.autoRefresh = false;
this.setAutoRefresh$Z(false);
if (this.loadThread != null ) this.loadThread.stop();
this.started = false;
C$.appletCount = 0;
this.deleteDataConnections();
this.localClock.panicStopClock();
var ds = null;
var dl = null;
var key;
var ht;
{
ht = C$.dataSources.clone();
}for (var e = ht.keys(); e.hasMoreElements(); ) {
key = e.nextElement();
ds = C$.dataSources.get$O(key);
if ((ds != null ) && (ds.getOwner() === this ) ) {
C$.dataSources.remove$O(key);
}}
{
ht = C$.dataListeners.clone();
}for (var e = ht.keys(); e.hasMoreElements(); ) {
key = e.nextElement();
dl = C$.dataListeners.get$O(key);
if ((dl != null ) && (dl.getOwner() === this ) ) {
C$.dataListeners.remove$O(key);
}}
this.localClock.removeAllClockListeners();
});

Clazz.newMeth(C$, 'getExistingConnection$I$I$I', function (sourceID, listenerID, seriesID) {
return null;
});

Clazz.newMeth(C$, 'sendDataToListener$I$I$D$D', function (listenerID, sid, x, y) {
var dl = C$.getDataListener$I(listenerID);
if (dl == null ) {
System.out.println$S("DataListener not found in sendData method.");
return;
}dl.addDatum$edu_davidson_tools_SDataSource$I$D$D(this.clock, sid, x, y);
});

Clazz.newMeth(C$, 'makeDataConnection$I$I$I$S$S', function (sourceID, listenerID, seriesID, xStr, yStr) {
if (xStr == null  || xStr.equals$O("") ) {
xStr = "0";
}if (yStr == null  || yStr.equals$O("") ) {
yStr = "0";
}if (this.debugLevel > 7) {
System.out.println$S("making connection. SourceID=" + sourceID + "ListenerID=" + listenerID );
}var dl = C$.getDataListener$I(listenerID);
var ds = C$.getDataSource$I(sourceID);
var dc = null;
if ((ds != null ) && (dl != null ) ) {
dc = p$.getExistingConnection$I$I$I.apply(this, [sourceID, listenerID, seriesID]);
if (dc == null ) {
if (this.debugLevel > 7) {
System.out.println$S("xStr=" + xStr + " yStr=" + yStr );
}dc = Clazz.new_((I$[9]||$incl$(9)).c$$edu_davidson_tools_SDataSource$edu_davidson_tools_SDataListener$I$S$S,[ds, dl, seriesID, xStr, yStr]);
this.dataConnections.addElement$TE(dc);
} else {
System.out.println$S("Warning: Data connection already exists.");
}} else {
System.out.println$S("DataConnection not made.  Listener:" + dl + "  Source:" + ds );
return 0;
}return dc.hashCode();
});

Clazz.newMeth(C$, 'clearAllData', function () {
for (var e = this.dataConnections.elements(); e.hasMoreElements(); ) {
var dc = e.nextElement();
dc.clearData();
}
});

Clazz.newMeth(C$, 'clearData$I', function (id) {
for (var e = this.dataConnections.elements(); e.hasMoreElements(); ) {
var dc = e.nextElement();
if (dc.getDataSource().hashCode() == id) {
dc.clearData();
}}
});

Clazz.newMeth(C$, 'updateDataConnection$I', function (id) {
if (this.destroyed) return;
for (var e = this.dataConnections.elements(); e.hasMoreElements(); ) {
var dc = e.nextElement();
if (dc.getDataSource().hashCode() == id) {
if (this.destroyed) return;
dc.registerDatum();
}}
});

Clazz.newMeth(C$, 'updateDataConnections', function () {
for (var e = this.dataConnections.elements(); e.hasMoreElements(); ) {
var dc = e.nextElement();
if (dc.getDataSource() !== this.clock ) {
if (this.destroyed) return;
dc.registerDatum();
}}
});

Clazz.newMeth(C$, 'deleteDataConnections', function () {
this.dataConnections.removeAllElements();
});

Clazz.newMeth(C$, 'deleteDataConnection$I', function (id) {
var dc = null;
for (var e = this.dataConnections.elements(); e.hasMoreElements(); ) {
dc = e.nextElement();
if (id == dc.hashCode()) {
this.dataConnections.removeElement$O(dc);
}}
});

Clazz.newMeth(C$, 'getDataConnection$I', function (id) {
var dc = null;
for (var e = this.dataConnections.elements(); e.hasMoreElements(); ) {
dc = e.nextElement();
if (id == dc.hashCode()) {
return dc;
}}
return null;
});

Clazz.newMeth(C$, 'getDataConnectionFromDS$edu_davidson_tools_SDataSource', function (ds) {
var dc = null;
for (var e = this.dataConnections.elements(); e.hasMoreElements(); ) {
dc = e.nextElement();
if (ds === dc.getDataSource() ) {
return dc;
}}
return null;
});

Clazz.newMeth(C$, 'getDataFromDS$I', function (id) {
var format = Clazz.new_((I$[5]||$incl$(5)).c$$S,["%10.5g"]);
var ds = C$.getDataSource$I(id);
var vStr = ds.getVarStrings();
var v = ds.getVariables();
if ((v == null ) || (vStr == null ) ) {
return "";
}var n = vStr.length;
var numPts = v.length;
var sb = Clazz.new_((I$[10]||$incl$(10)).c$$I,[(n + 1) * numPts * 10 ]);
for (var i = 0; i < n; i++) {
sb.append$S(vStr[i]);
for (var j = 0; j < numPts; j++) {
sb.append$S(",");
sb.append$S(format.form$D(v[j][i]));
}
sb.append$C("\u000a");
}
return sb.toString();
});

Clazz.newMeth(C$, 'getDataConnectionFromDL$edu_davidson_tools_SDataListener', function (dl) {
var dc = null;
for (var e = this.dataConnections.elements(); e.hasMoreElements(); ) {
dc = e.nextElement();
if (dl === dc.getDataListener() ) {
return dc;
}}
return null;
});

Clazz.newMeth(C$, 'isValidFunction$S$S', function (func, vars) {
return (I$[11]||$incl$(11)).isValidFunction$S$S(func, vars);
});

Clazz.newMeth(C$, 'getAppletCount', function () {
var n = 0;
if (C$.appletCount <= 0) return 0;
if (C$.appletCount == 1) return 1;
try {
var en = this.getAppletContext().getApplets();
while (en.hasMoreElements()){
n++;
en.nextElement();
}
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
System.err.println$S("Error while counting applets: " + ex.getMessage());
n = -1;
} else {
throw ex;
}
}
return n;
});

Clazz.newMeth(C$, 'getAppletName', function () {
if (C$.appletCount <= 0) return "";
return this.getParameter$S("name");
});

Clazz.newMeth(C$, 'checkAppletNames$S', function (names) {
if (this.debugLevel > 127) System.out.println$S("checkAppletNames:" + names);
if (!this.isActive() || C$.appletCount <= 0 ) return false;
names = names.trim();
if (C$.appletCount == 1 && this.getAppletName().equals$O(names) ) return true;
var appletNames = Clazz.new_((I$[4]||$incl$(4)));
try {
var en = this.getAppletContext().getApplets();
while (en.hasMoreElements()){
var applet = en.nextElement();
if (Clazz.instanceOf(applet, "edu.davidson.tools.SApplet")) {
appletNames.addElement$TE((applet).getAppletName());
if (this.debugLevel > 127) {
System.out.println$S("Applet named: " + (applet).getAppletName());
}}}
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
return false;
} else {
throw ex;
}
}
var ptokens = Clazz.new_((I$[12]||$incl$(12)).c$$S$S,[names, ",;"]);
for (var i = 0, n = ptokens.countTokens(); i < n; i++) {
if (!appletNames.contains$O(ptokens.nextToken().trim())) return false;
}
return true;
});

Clazz.newMeth(C$, 'cleanupDataConnections', function () {
var dc = null;
var ds = null;
var dl = null;
for (var e = this.dataConnections.elements(); e.hasMoreElements(); ) {
dc = e.nextElement();
dl = dc.getDataListener();
ds = dc.getDataSource();
if (!C$.dataListeners.contains$O(dl) || !C$.dataSources.contains$O(ds) ) {
this.dataConnections.removeElement$O(dc);
}}
});

Clazz.newMeth(C$, 'getRunningID', function () {
if (this.independentClock) {
return this;
}return C$.runningID;
});

Clazz.newMeth(C$, 'setRunningID$O', function (id) {
C$.runningID = id;
});

Clazz.newMeth(C$, 'setRunningID', function () {
C$.runningID = this;
});

Clazz.newMeth(C$, 'getDebugLevel', function () {
return this.debugLevel;
});

Clazz.newMeth(C$, 'setDebugLevel$I', function (level) {
this.debugLevel = level;
C$.staticDebugLevel = level;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setConnectionSmoothing$I$I', function (id, num) {
var dc = this.getDataConnection$I(id);
if (dc == null ) {
System.out.println$S("Error: DataConnection not found in setConnectionSmoothing.");
return false;
}dc.setSmooth$I(num);
return true;
});

Clazz.newMeth(C$, 'setConnectionWindowX$I$D$D', function (id, xmin, xmax) {
var dc = this.getDataConnection$I(id);
if (dc == null ) {
System.out.println$S("Error: DataConnection not found in setConnectionWindowX.");
return false;
}dc.setWindowX$D$D(xmin, xmax);
return true;
});

Clazz.newMeth(C$, 'setConnectionWindowY$I$D$D', function (id, ymin, ymax) {
var dc = this.getDataConnection$I(id);
if (dc == null ) {
System.out.println$S("Error: DataConnection not found in setConnectionWindowY.");
return false;
}dc.setWindowY$D$D(ymin, ymax);
return true;
});

Clazz.newMeth(C$, 'setConnectionStride$I$I', function (id, num) {
var dc = this.getDataConnection$I(id);
if (dc == null ) {
System.out.println$S("Error: DataConnection not found in setConnectionStride.");
return false;
}dc.setStride$I(num);
return true;
});

Clazz.newMeth(C$, 'setConnectionBlock$I$Z', function (id, block) {
var dc = this.getDataConnection$I(id);
if (dc == null ) {
System.out.println$S("Error: DataConnection not found in setConnectionBlock.");
return false;
}dc.block = block;
return true;
});

Clazz.newMeth(C$, 'setConnectionSource$I', function (id) {
var dc = this.getDataConnection$I(id);
if (dc == null ) {
System.out.println$S("Error: DataConnection not found in setConnectionSource.");
return false;
}dc.ds = C$.getDataSource$I(id);
return true;
});

Clazz.newMeth(C$, 'setConnectionListener$I', function (id) {
var dc = this.getDataConnection$I(id);
if (dc == null ) {
System.out.println$S("Error: DataConnection not found in setConnectionSource.");
return false;
}dc.dl = C$.getDataListener$I(id);
return true;
});

Clazz.newMeth(C$, 'setAutoRefresh$Z', function (ar) {
this.autoRefresh = ar;
});

Clazz.newMeth(C$, 'formatValue$D$D$S', function (val, chop, str) {
if (str == null ) str = "";
str.trim();
if (!str.equals$O("") && !this.formatString.equals$O(str) ) {
this.formatString = str;
this.formatD = Clazz.new_((I$[5]||$incl$(5)).c$$S,[this.formatString]);
}if (Math.abs(val) < chop ) {
return "0";
}if (Math.abs(val - (val|0)) <= chop ) {
return this.formatI.form$J((val|0));
}return this.formatD.form$D(val);
});

Clazz.newMeth(C$, 'setFont$java_awt_Font', function (f) {
if (this.started && this.debugLevel > 0  && !Clazz.getClass((I$[13]||$incl$(13))).isInstance$O(f) ) {
f = C$.superclazz.prototype.getFont.apply(this, []);
System.out.println$S("SCRIPT ERROR: Java 1.4 plug-in does not support method overloading.");
System.out.println$S("Method: setFont");
System.out.println$S("Alternate method: setObjectFont.");
System.out.println$S("");
}C$.superclazz.prototype.setFont$java_awt_Font.apply(this, [f]);
});

Clazz.newMeth(C$, 'getX', function () {
if (this.started && this.debugLevel > 0 ) {
System.out.println$S("SCRIPT ERROR: Java 1.4 plug-in does not support method overloading.");
System.out.println$S("Method: getX");
System.out.println$S("Alternate method: getXPos.");
System.out.println$S("");
}return C$.superclazz.prototype.getX.apply(this, []);
});

Clazz.newMeth(C$, 'getY', function () {
if (this.started && this.debugLevel > 0 ) {
System.out.println$S("SCRIPT ERROR: Java 1.4 plug-in does not support method overloading.");
System.out.println$S("Method: getY");
System.out.println$S("Alternate method: getYPos.");
System.out.println$S("");
}return C$.superclazz.prototype.getY.apply(this, []);
});

Clazz.newMeth(C$, 'forward', function () {
this.setRunningID();
this.clock.dt = Math.abs(this.clock.dt);
this.clock.startClock();
});

Clazz.newMeth(C$, 'reverse', function () {
this.setRunningID();
this.clock.dt = -Math.abs(this.clock.dt);
this.clock.startClock();
});

Clazz.newMeth(C$, 'pause', function () {
this.clock.stopClock();
});

Clazz.newMeth(C$, 'reset', function () {
this.pause();
this.clock.setTime$D(0);
});

Clazz.newMeth(C$, 'setDefault', function () {
this.pause();
this.clock.setTime$D(0);
this.deleteDataConnections();
});

Clazz.newMeth(C$, 'setDt$D', function (dt) {
this.clock.setDt$D(dt);
});

Clazz.newMeth(C$, 'setFPS$D', function (fps) {
this.clock.setFPS$D(fps);
});

Clazz.newMeth(C$, 'setTimeContinuous', function () {
this.clock.setContinuous();
});

Clazz.newMeth(C$, 'getClockID', function () {
return this.clock.hashCode();
});

Clazz.newMeth(C$, 'setIndependentClock$Z', function (independent) {
this.independentClock = independent;
});

Clazz.newMeth(C$, 'setExternalClock$I', function (id) {
var ds = C$.getDataSource$I(id);
if (ds == null ) {
return false;
}var newClock = null;
if (Clazz.instanceOf(ds, "edu.davidson.tools.SClock")) {
newClock = ds;
} else {
return false;
}this.clock.stopClock();
newClock.stopClock();
for (var e = this.clock.clockListeners.elements(); e.hasMoreElements(); ) {
var clockListener = e.nextElement();
newClock.addClockListener$edu_davidson_tools_SStepable(clockListener);
}
this.removeDataSource$I(this.clock.getID());
this.clock = newClock;
return true;
});

Clazz.newMeth(C$, 'stepClock', function () {
this.clock.doStep();
});

Clazz.newMeth(C$, 'stepTimeForward', function () {
this.clock.setDt$D(Math.abs(this.clock.getDt()));
this.clock.doStep();
});

Clazz.newMeth(C$, 'stepTimeBack', function () {
this.clock.setDt$D(-Math.abs(this.clock.getDt()));
this.clock.doStep();
});

Clazz.newMeth(C$, 'stepTime', function () {
this.clock.doStep();
});

Clazz.newMeth(C$, 'getClockTime', function () {
return this.clock.getTime();
});

Clazz.newMeth(C$, 'setClockTime$D', function (t) {
this.clock.setTime$D(t);
});

Clazz.newMeth(C$, 'setTimeOneShot$D$S', function (maxTime, msg) {
this.oneShotMsg = msg;
this.clock.setOneShot$D$D(0, maxTime);
this.clock.setTime$D(0);
});

Clazz.newMeth(C$, 'setClockOneShot$D$D', function (minTime, maxTime) {
this.clock.setOneShot$D$D(minTime, maxTime);
this.clock.setTime$D(minTime);
});

Clazz.newMeth(C$, 'setClockContinous', function () {
this.clock.oneShot = false;
this.clock.cycle = false;
});

Clazz.newMeth(C$, 'setKey$S', function (str) {
this.crypt.setKey$S(str);
});

Clazz.newMeth(C$, 'decrypt$S', function (str) {
return this.crypt.decrypt$S(str);
});

Clazz.newMeth(C$, 'setTimeCycle$D', function (maxTime) {
this.clearAllData();
this.clock.setCycle$D$D(0, maxTime);
this.clock.setTime$D(0);
});

Clazz.newMeth(C$, 'setClockCycle$D$D', function (minTime, maxTime) {
this.clearAllData();
this.clock.setCycle$D$D(minTime, maxTime);
this.clock.setTime$D(minTime);
});

Clazz.newMeth(C$, 'start', function () {
this.started = true;
C$.appletCount++;
if (!this.scriptHasRun) this.runJavaScript();
});

Clazz.newMeth(C$, 'stop', function () {
if (this.loadThread != null ) {
this.loadThread.halt = true;
}C$.superclazz.prototype.stop.apply(this, []);
this.started = false;
C$.appletCount = 0;
});

Clazz.newMeth(C$, 'startClock', function () {
this.setRunningID();
this.clock.startClock();
});

Clazz.newMeth(C$, 'isAutoRefresh', function () {
return this.autoRefresh;
});

Clazz.newMeth(C$, 'isClockRunning', function () {
return this.clock.isRunning();
});

Clazz.newMeth(C$, 'stoppingClock', function () {
});

Clazz.newMeth(C$, 'cyclingClock', function () {
});

Clazz.newMeth(C$, 'pausingClock', function () {
});

Clazz.newMeth(C$, 'stopClock', function () {
this.clock.stopClock();
});

Clazz.newMeth(C$, 'addDataSource$O', function (ds) {
if ((Clazz.instanceOf(ds, "edu.davidson.tools.SDataSource")) && !C$.dataSources.contains$O(ds) ) {
C$.dataSources.put$TK$TV(Integer.toString(ds.hashCode()), ds);
if (C$.staticDebugLevel > 8) {
System.out.println$S("data source added: " + ds.hashCode());
}} else {
System.out.println$S("Error: ds is not a DataSource in SApplet.addDataSource:" + ds.hashCode());
}}, 1);

Clazz.newMeth(C$, 'removeDataSource$I', function (id) {
var ds = C$.getDataSource$I(id);
var dc = null;
do {
dc = this.getDataConnectionFromDS$edu_davidson_tools_SDataSource(ds);
if (dc != null ) {
this.dataConnections.removeElement$O(dc);
}} while (dc != null );
C$.dataSources.remove$O(Integer.toString(id));
});

Clazz.newMeth(C$, 'getDataSource$S', function (key) {
return C$.dataSources.get$O(key);
}, 1);

Clazz.newMeth(C$, 'getDataSource$I', function (id) {
return C$.dataSources.get$O(Integer.toString(id));
}, 1);

Clazz.newMeth(C$, 'getSourceVariables$I', function (id) {
var str = "";
var ds = C$.dataSources.get$O(Integer.toString(id));
if (ds == null ) {
return "Data source not found.";
}var varStr = ds.getVarStrings();
if (varStr == null ) {
return "Variables not found.";
}var num = varStr.length;
for (var i = 0; i < num - 1; i++) {
str = str + varStr[i] + ", " ;
}
str = str + varStr[num - 1];
return str;
});

Clazz.newMeth(C$, 'getSourceData$I$S', function (id, vStr) {
var index = -1;
var ds = C$.dataSources.get$O(Integer.toString(id));
if (ds == null ) {
return "Data source not found.";
}var varStr = ds.getVarStrings();
if (varStr == null ) {
return "Variables not found.";
}var num = varStr.length;
for (var i = 0; i < num; i++) {
if (varStr[i].equals$O(vStr)) {
index = i;
break;
}}
if (index == -1) {
return "Data source variable not found.";
}var vals = ds.getVariables();
if (vals == null ) {
return "Values not found.";
}var len = vals.length;
var str = Clazz.new_((I$[10]||$incl$(10)).c$$I,[len * 10]);
for (var j = 0; j < len - 1; j++) {
str = str.append$D(vals[j][index]);
str.append$S(", ");
}
if (len <= 0) {
return "";
}str.append$D(vals[len - 1][index]);
return str.toString();
});

Clazz.newMeth(C$, 'removeDataListener$I', function (id) {
var dl = C$.getDataListener$I(id);
var dc = null;
do {
dc = this.getDataConnectionFromDL$edu_davidson_tools_SDataListener(dl);
if (dc != null ) {
this.dataConnections.removeElement$O(dc);
}} while (dc != null );
C$.dataListeners.remove$O(Integer.toString(id));
});

Clazz.newMeth(C$, 'addDataListener$O', function (dl) {
if (Clazz.instanceOf(dl, "edu.davidson.tools.SDataListener")) {
C$.dataListeners.put$TK$TV(Integer.toString(dl.hashCode()), dl);
if (C$.staticDebugLevel > 8) {
System.out.println$S("data listener added: " + dl.hashCode());
}} else {
System.out.println$S("Error: dl is not a DataListener in SApplet.addDataListener:" + dl.hashCode());
}}, 1);

Clazz.newMeth(C$, 'getDataListener$S', function (key) {
return C$.dataListeners.get$O(key);
}, 1);

Clazz.newMeth(C$, 'getDataListener$I', function (id) {
return C$.dataListeners.get$O(Integer.toString(id));
}, 1);
})();
//Created 2018-02-06 13:41:44
