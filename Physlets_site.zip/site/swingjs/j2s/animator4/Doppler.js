(function(){var P$=Clazz.newPackage("animator4"),I$=[['java.util.Vector',['animator4.Doppler','.Wave'],'java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Doppler", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'animator4.Circle');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.lastCrest = 0;
this.c = 0;
this.period = 0;
this.numCrests = 0;
this.counter = 0;
this.waves = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.lastCrest = 0;
this.c = 1.0;
this.period = 1.0;
this.numCrests = 10;
this.counter = 0;
this.waves = null;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$S$S$I$D$D', function (o, diameter, xStr, yStr, numCrests, period, c) {
C$.superclazz.c$$animator4_AnimatorCanvas$I$S$S.apply(this, [o, diameter, xStr, yStr]);
C$.$init$.apply(this);
this.numCrests = numCrests;
this.period = period;
this.c = c;
this.waves = Clazz.new_((I$[1]||$incl$(1)).c$$I,[numCrests]);
this.lastCrest = this.vars[0];
p$.initCrests.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'initCrests', function () {
for (var i = 0; i < this.numCrests; i++) this.waves.addElement$TE(Clazz.new_((I$[2]||$incl$(2)).c$$D$D$D, [this, null, this.lastCrest, this.vars[1], this.vars[2]]));

});

Clazz.newMeth(C$, 'addCrest$D', function (t0) {
if (t0 < this.lastCrest + this.period ) return;
while (t0 >= this.lastCrest + this.period ){
this.lastCrest += this.period;
if (this.waves.size() > this.numCrests) this.waves.removeElementAt$I(0);
this.waves.addElement$TE(Clazz.new_((I$[2]||$incl$(2)).c$$D$D$D, [this, null, this.lastCrest, this.vars[1], this.vars[2]]));
}
});

Clazz.newMeth(C$, 'clearTrail', function () {
C$.superclazz.prototype.clearTrail.apply(this, []);
this.lastCrest = this.vars[0];
if (this.waves == null ) return;
this.waves.removeAllElements();
p$.initCrests.apply(this, []);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
if (this.waves == null ) return;
this.addCrest$D(this.vars[0]);
var len = this.waves.size();
var wave;
var red = 255 - this.color.getRed();
var green = 255 - this.color.getGreen();
var blue = 255 - this.color.getBlue();
if (len > 0) for (var i = 0; i < len; i++) {
g.setColor$java_awt_Color(Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I,[255 - (red * (i)/(len + 1)|0), 255 - (green * (i)/(len + 1)|0), 255 - (blue * (i)/(len + 1)|0)]));
wave = (this.waves.elementAt$I(i));
wave.draw$D$java_awt_Graphics(this.vars[0], g);
}
});
;
(function(){var C$=Clazz.newClass(P$.Doppler, "Wave", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x0 = 0;
this.y0 = 0;
this.t0 = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D', function (t0_, x0_, y0_) {
C$.$init$.apply(this);
this.x0 = x0_;
this.y0 = y0_;
this.t0 = t0_;
}, 1);

Clazz.newMeth(C$, 'draw$D$java_awt_Graphics', function (t, g) {
if (!this.this$0.visible) return;
var rad = (t - this.t0) * this.this$0.c;
var pixRadius = (this.this$0.w/2|0) + ((rad * this.this$0.canvas.pixPerUnit)|0) + 1;
var ptX = this.this$0.canvas.pixFromX$D(this.x0) - pixRadius + this.this$0.xDisplayOff;
var ptY = this.this$0.canvas.pixFromY$D(this.y0) - pixRadius - this.this$0.yDisplayOff ;
g.drawOval$I$I$I$I(ptX, ptY, pixRadius * 2, pixRadius * 2);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:20:58
