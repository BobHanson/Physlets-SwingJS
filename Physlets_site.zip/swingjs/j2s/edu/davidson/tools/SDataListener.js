(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newInterface(P$, "SDataListener");
})();
//Created 2018-02-19 20:23:25
