(function(){var P$=Clazz.newPackage("javajs.api"),I$=[];
var C$=Clazz.newClass(P$, "Interface");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getInterface$S', function (name) {
try {
var x = Clazz.forName(name);
return (x == null  ? null : x.newInstance());
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Interface.getInterface Error creating instance for " + name + ": \n" + e );
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getInstanceWithParams$S$ClassA$OA', function (name, classes, params) {
try {
var cl = Clazz.forName(name);
return cl.getConstructor$ClassA(classes).newInstance$OA(params);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Interface.getInterfaceWithParams Error creating instance for " + name + ": \n" + e );
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 16:19:53 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
