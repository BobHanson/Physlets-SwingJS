(function(){var P$=Clazz.newPackage("doppler"),I$=[['java.awt.BorderLayout','a2s.Scrollbar','a2s.Label','a2s.TextField','java.awt.Dimension','java.awt.Insets','java.awt.Color','edu.davidson.display.Format','doppler.ChangeValueEvent']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "VarScrollBar", null, 'a2s.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.caption = null;
this.scrollBar = null;
this.value = 0;
this.min = 0;
this.max = 0;
this.valFld = null;
this.hasChanged = false;
this.captionLbl = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.hasChanged = false;
}, 1);

Clazz.newMeth(C$, 'c$$S$D$D$D', function (caption_, value_, min_, max_) {
Clazz.super_(C$, this,1);
this.caption = caption_;
this.setLayout$java_awt_LayoutManager(Clazz.new_((I$[1]||$incl$(1))));
this.value = value_;
this.min = min_;
this.max = max_;
if (this.value > this.max ) this.value = this.max;
if (this.value < this.min ) this.value = this.min;
this.scrollBar = Clazz.new_((I$[2]||$incl$(2)).c$$I$I$I$I$I,[0, ((100 * (this.value - this.min) / (this.max - this.min))|0), 4, 0, 100]);
this.add$S$java_awt_Component("West", this.captionLbl = Clazz.new_((I$[3]||$incl$(3)).c$$S$I,[caption_, 2]));
this.add$S$java_awt_Component("Center", this.scrollBar);
this.valFld = Clazz.new_((I$[4]||$incl$(4)));
this.valFld.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[5]||$incl$(5)).c$$I$I,[40, 20]));
this.valFld.setText$S("" + new Double(value_).toString());
this.add$S$java_awt_Component("East", this.valFld);
}, 1);

Clazz.newMeth(C$, 'insets', function () {
var inH = ((this.size().height - 30)/2|0);
if (inH < 0) inH = 0;
return Clazz.new_((I$[6]||$incl$(6)).c$$I$I$I$I,[inH, 2, inH, 2]);
});

Clazz.newMeth(C$, 'preferredSize', function () {
return Clazz.new_((I$[5]||$incl$(5)).c$$I$I,[100, 20]);
});

Clazz.newMeth(C$, 'minimumSize', function () {
return Clazz.new_((I$[5]||$incl$(5)).c$$I$I,[40, 15]);
});

Clazz.newMeth(C$, 'keyUp$java_awt_Event$I', function (evt, chr) {
if (evt.target.equals$O(this.valFld)) {
this.valFld.setBackground$java_awt_Color((I$[7]||$incl$(7)).yellow);
} else return false;
return true;
});

Clazz.newMeth(C$, 'setCaption$S', function (caption_) {
this.caption = caption_;
this.captionLbl.setText$S(this.caption);
});

Clazz.newMeth(C$, 'getValue', function () {
this.hasChanged = false;
this.valFld.setBackground$java_awt_Color((I$[7]||$incl$(7)).white);
this.valFld.setText$S("" + new Double(this.value).toString());
this.scrollBar.setValue$I(((100 * (this.value - this.min) / (this.max - this.min))|0));
return this.value;
});

Clazz.newMeth(C$, 'setValue$D', function (val) {
this.hasChanged = false;
this.valFld.setBackground$java_awt_Color((I$[7]||$incl$(7)).white);
this.value = val;
this.valFld.setText$S("" + new Double(this.value).toString());
this.scrollBar.setValue$I(((100 * (this.value - this.min) / (this.max - this.min))|0));
});

Clazz.newMeth(C$, 'setMinMax$D$D', function (newMin, newMax) {
this.hasChanged = false;
this.valFld.setBackground$java_awt_Color((I$[7]||$incl$(7)).white);
this.min = newMin;
this.max = newMax;
this.valFld.setText$S("" + new Double(this.value).toString());
this.scrollBar.setValue$I(((100 * (this.value - this.min) / (this.max - this.min))|0));
});

Clazz.newMeth(C$, 'action$java_awt_Event$O', function (evt, arg) {
if (evt.target.equals$O(this.valFld)) {
this.value = (I$[8]||$incl$(8)).atof$S(arg);
this.scrollBar.setValue$I(((100 * (this.value - this.min) / (this.max - this.min))|0));
this.valFld.setBackground$java_awt_Color((I$[7]||$incl$(7)).white);
var str = this.valFld.getText();
this.valFld.setText$S(str);
var newEvent = Clazz.new_((I$[9]||$incl$(9)).c$$O$java_awt_Event$I,[this, evt, 1]);
this.deliverEvent$java_awt_Event(newEvent);
} else return false;
return true;
});

Clazz.newMeth(C$, 'handleEvent$java_awt_Event', function (evt) {
if (evt.id == 605 || evt.id == 602  || evt.id == 601  || evt.id == 604  || evt.id == 603 ) {
this.value = this.min + (this.max - this.min) * this.scrollBar.getValue() / 100.0;
this.valFld.setBackground$java_awt_Color((I$[7]||$incl$(7)).white);
this.valFld.setText$S("" + new Double(this.value).toString());
var newEvent = Clazz.new_((I$[9]||$incl$(9)).c$$O$java_awt_Event$I,[this, evt, 1]);
this.deliverEvent$java_awt_Event(newEvent);
return true;
}return C$.superclazz.prototype.handleEvent$java_awt_Event.apply(this, [evt]);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:19:59
