(function(){var P$=Clazz.newPackage("eField4"),I$=[];
var C$=Clazz.newClass(P$, "LineAnchor", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.thing=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$eField4_Thing', function (p, x, y, t) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [p, x, y, 0, 0]);
C$.$init$.apply(this);
this.p=p;
this.thing=t;
this.vars[0]=0;
this.vars[1]=x;
this.vars[2]=y;
this.initVars[0]=0;
this.initVars[1]=x;
this.initVars[2]=y;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (this.hideThing) return;
var ptX1=this.p.pixFromX$D(this.vars[1]);
var ptY1=this.p.pixFromY$D(this.vars[2]);
var ptX2=this.p.pixFromX$D(this.thing.vars[1]);
var ptY2=this.p.pixFromY$D(this.thing.vars[2]);
osg.setColor$java_awt_Color(this.color);
osg.drawLine$I$I$I$I(ptX1, ptY1, ptX2, ptY2);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:19 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
