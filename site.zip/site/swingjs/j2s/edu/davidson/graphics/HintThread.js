(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['java.awt.event.MouseAdapter','edu.davidson.graphics.HintThread','java.awt.Color','Thread']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "HintThread", null, 'Thread');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.hp = null;
this.bubbleInterval = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.bubbleInterval = 200;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_graphics_HintPanel', function (hp) {
Clazz.super_(C$, this,1);
this.hp=hp;
hp.hintVisible=true;
this.start();
}, 1);

Clazz.newMeth(C$, 'run', function () {
var start = System.currentTimeMillis();
var done = false;
while (!done){
var delta = System.currentTimeMillis() - start;
try {
(I$[4]||$incl$(4)).sleep$J(50);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
if (delta > this.bubbleInterval) {
this.hp.repaint();
done=true;
}}
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:40
