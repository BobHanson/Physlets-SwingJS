(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),p$1={},I$=[[0,'java.awt.event.MouseAdapter','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "TreadButton", null, 'java.awt.Button');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'jbInit', function () {
this.addMouseListener$java_awt_event_MouseListener(((P$.TreadButton$1||
(function(){var C$=Clazz.newClass(P$, "TreadButton$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.b$['edu.davidson.graphics.TreadButton'].this_mousePressed$java_awt_event_MouseEvent.apply(this.b$['edu.davidson.graphics.TreadButton'], [e]);
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.b$['edu.davidson.graphics.TreadButton'].this_mouseReleased$java_awt_event_MouseEvent.apply(this.b$['edu.davidson.graphics.TreadButton'], [e]);
});
})()
), Clazz.new_(Clazz.load('java.awt.event.MouseAdapter'), [this, null],P$.TreadButton$1)));
}, p$1);

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
this.setBackground$java_awt_Color(Clazz.load('java.awt.Color').green);
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.setBackground$java_awt_Color($I$(2).gray);
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:31 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
