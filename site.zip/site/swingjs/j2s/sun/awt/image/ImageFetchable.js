(function(){var P$=Clazz.newPackage("sun.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "ImageFetchable");
})();
//Created 2018-05-24 08:47:27
