(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'symantec.itools.awt.ImagePanel','symantec.itools.awt.shape.Circle','symantec.itools.awt.InvisibleButton','symantec.itools.awt.shape.Square','symantec.itools.awt.shape.Rect','symantec.itools.awt.BorderPanel','circuitsimulator.ScopeCanvas','java.awt.Label','java.awt.Color','java.awt.Cursor','java.awt.Font','java.net.URL',['circuitsimulator.OscilloDialog','.SymWindow'],['circuitsimulator.OscilloDialog','.SymMouse'],['circuitsimulator.OscilloDialog','.SymMouseMotion']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "OscilloDialog", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.Dialog');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.voltageScaling=0;
this.timeScaling=0;
this.verOffset=0;
this.horOffset=0;
this.mode=null;
this.cb=null;
this.ce=null;
this.fComponentsAdjusted=false;
this.timeScale=null;
this.timeIndicator=null;
this.invisible10us=null;
this.invisible20us=null;
this.invisible50us=null;
this.invisible01ms=null;
this.invisible02ms=null;
this.invisible05ms=null;
this.invisible1ms=null;
this.invisible2ms=null;
this.invisible5ms=null;
this.invisible10ms=null;
this.invisible20ms=null;
this.invisible50ms=null;
this.voltageScale=null;
this.voltageIndicator=null;
this.invisible01V=null;
this.invisible02V=null;
this.invisible05V=null;
this.invisible1V=null;
this.invisible2V=null;
this.invisible5V=null;
this.invisible10V=null;
this.invisible5mV=null;
this.invisible10mV=null;
this.invisible20mV=null;
this.invisible20V=null;
this.invisible50mV=null;
this.horScrol=null;
this.invisibleLeft=null;
this.invisibleRight=null;
this.horIndicator=null;
this.vertScrol=null;
this.invisibleUp=null;
this.invisibleDown=null;
this.verIndicator=null;
this.voltageMode=null;
this.modeIndicator=null;
this.invisibleAC=null;
this.invisibleDC=null;
this.invisibleGround=null;
this.borderCanvas=null;
this.scopeCanvas=null;
this.borderVoltageScale=null;
this.labelVoltageScale=null;
this.borderTimeBase=null;
this.labelTimeBase=null;
this.coords=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.fComponentsAdjusted=false;
this.timeScale=Clazz.new_(Clazz.load('symantec.itools.awt.ImagePanel'));
this.timeIndicator=Clazz.new_(Clazz.load('symantec.itools.awt.shape.Circle'));
this.invisible10us=Clazz.new_(Clazz.load('symantec.itools.awt.InvisibleButton'));
this.invisible20us=Clazz.new_($I$(3));
this.invisible50us=Clazz.new_($I$(3));
this.invisible01ms=Clazz.new_($I$(3));
this.invisible02ms=Clazz.new_($I$(3));
this.invisible05ms=Clazz.new_($I$(3));
this.invisible1ms=Clazz.new_($I$(3));
this.invisible2ms=Clazz.new_($I$(3));
this.invisible5ms=Clazz.new_($I$(3));
this.invisible10ms=Clazz.new_($I$(3));
this.invisible20ms=Clazz.new_($I$(3));
this.invisible50ms=Clazz.new_($I$(3));
this.voltageScale=Clazz.new_($I$(1));
this.voltageIndicator=Clazz.new_($I$(2));
this.invisible01V=Clazz.new_($I$(3));
this.invisible02V=Clazz.new_($I$(3));
this.invisible05V=Clazz.new_($I$(3));
this.invisible1V=Clazz.new_($I$(3));
this.invisible2V=Clazz.new_($I$(3));
this.invisible5V=Clazz.new_($I$(3));
this.invisible10V=Clazz.new_($I$(3));
this.invisible5mV=Clazz.new_($I$(3));
this.invisible10mV=Clazz.new_($I$(3));
this.invisible20mV=Clazz.new_($I$(3));
this.invisible20V=Clazz.new_($I$(3));
this.invisible50mV=Clazz.new_($I$(3));
this.horScrol=Clazz.new_($I$(1));
this.invisibleLeft=Clazz.new_($I$(3));
this.invisibleRight=Clazz.new_($I$(3));
this.horIndicator=Clazz.new_(Clazz.load('symantec.itools.awt.shape.Square'));
this.vertScrol=Clazz.new_($I$(1));
this.invisibleUp=Clazz.new_($I$(3));
this.invisibleDown=Clazz.new_($I$(3));
this.verIndicator=Clazz.new_($I$(4));
this.voltageMode=Clazz.new_($I$(1));
this.modeIndicator=Clazz.new_(Clazz.load('symantec.itools.awt.shape.Rect'));
this.invisibleAC=Clazz.new_($I$(3));
this.invisibleDC=Clazz.new_($I$(3));
this.invisibleGround=Clazz.new_($I$(3));
this.borderCanvas=Clazz.new_(Clazz.load('symantec.itools.awt.BorderPanel'));
this.scopeCanvas=Clazz.new_(Clazz.load('circuitsimulator.ScopeCanvas'));
this.borderVoltageScale=Clazz.new_($I$(6));
this.labelVoltageScale=Clazz.new_(Clazz.load('java.awt.Label'));
this.borderTimeBase=Clazz.new_($I$(6));
this.labelTimeBase=Clazz.new_($I$(8));
this.coords=Clazz.new_($I$(8));
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame$circuitsimulator_CircuitBuilder', function (parent, cirbuilder) {
C$.superclazz.c$$java_awt_Frame$S$Z.apply(this, [parent, "", false]);
C$.$init$.apply(this);
this.cb=cirbuilder;
this.ce=this.cb.currentElement;
this.scopeCanvas.setCircuit$circuitsimulator_CircuitBuilder$circuitsimulator_OscilloDialog(this.cb, this);
this.setTitle$S(this.cb.cirProp.getProperty$S("scope_title") + " " + this.cb.cirProp.getProperty$S(this.ce.getMyName$()) + " " + this.ce.getlabel$() );
this.setLayout$java_awt_LayoutManager(null);
this.setBackground$java_awt_Color(Clazz.new_(Clazz.load('java.awt.Color').c$$I$I$I,[220, 200, 160]));
this.setSize$I$I(549, 312);
this.setVisible$Z(false);
try {
this.timeScale.setStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.timeScale.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.timeScale);
this.timeScale.setBounds$I$I$I$I(432, 180, 108, 116);
try {
this.timeIndicator.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.timeIndicator.setFillColor$java_awt_Color($I$(9).red);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.timeIndicator.setFillMode$Z(true);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.timeScale.add$java_awt_Component(this.timeIndicator);
this.timeIndicator.setForeground$java_awt_Color($I$(9).blue);
this.timeIndicator.setBounds$I$I$I$I(39, 33, 12, 12);
this.invisible10us.setCursor$java_awt_Cursor(Clazz.load('java.awt.Cursor').getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible10us);
this.invisible10us.setBounds$I$I$I$I(69, 84, 20, 15);
this.invisible20us.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible20us);
this.invisible20us.setBounds$I$I$I$I(81, 71, 21, 14);
this.invisible50us.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible50us);
this.invisible50us.setBounds$I$I$I$I(85, 54, 20, 15);
this.invisible01ms.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible01ms);
this.invisible01ms.setBounds$I$I$I$I(83, 34, 20, 14);
this.invisible02ms.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible02ms);
this.invisible02ms.setBounds$I$I$I$I(69, 15, 21, 15);
this.invisible05ms.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible05ms);
this.invisible05ms.setBounds$I$I$I$I(45, 9, 19, 19);
this.invisible1ms.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible1ms);
this.invisible1ms.setBounds$I$I$I$I(23, 16, 18, 17);
this.invisible2ms.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible2ms);
this.invisible2ms.setBounds$I$I$I$I(10, 32, 15, 17);
this.invisible5ms.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible5ms);
this.invisible5ms.setBounds$I$I$I$I(5, 50, 17, 15);
this.invisible10ms.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible10ms);
this.invisible10ms.setBounds$I$I$I$I(9, 69, 18, 17);
this.invisible20ms.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible20ms);
this.invisible20ms.setBounds$I$I$I$I(24, 84, 17, 17);
this.invisible50ms.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.timeScale.add$java_awt_Component(this.invisible50ms);
this.invisible50ms.setBounds$I$I$I$I(45, 91, 17, 15);
try {
this.voltageScale.setStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.voltageScale.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.voltageScale);
this.voltageScale.setBounds$I$I$I$I(432, 36, 109, 116);
try {
this.voltageIndicator.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.voltageIndicator.setFillColor$java_awt_Color($I$(9).red);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.voltageIndicator.setFillMode$Z(true);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.voltageScale.add$java_awt_Component(this.voltageIndicator);
this.voltageIndicator.setForeground$java_awt_Color($I$(9).blue);
this.voltageIndicator.setBounds$I$I$I$I(30, 41, 12, 12);
this.invisible01V.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible01V);
this.invisible01V.setBounds$I$I$I$I(65, 14, 19, 14);
this.invisible02V.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible02V);
this.invisible02V.setBounds$I$I$I$I(42, 7, 21, 16);
this.invisible05V.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible05V);
this.invisible05V.setBounds$I$I$I$I(21, 14, 20, 17);
this.invisible1V.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible1V);
this.invisible1V.setBounds$I$I$I$I(10, 30, 16, 14);
this.invisible2V.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible2V);
this.invisible2V.setBounds$I$I$I$I(5, 51, 17, 16);
this.invisible5V.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible5V);
this.invisible5V.setBounds$I$I$I$I(10, 71, 16, 13);
this.invisible10V.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible10V);
this.invisible10V.setBounds$I$I$I$I(26, 85, 16, 16);
this.invisible5mV.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible5mV);
this.invisible5mV.setBounds$I$I$I$I(68, 85, 18, 17);
this.invisible10mV.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible10mV);
this.invisible10mV.setBounds$I$I$I$I(84, 68, 17, 15);
this.invisible20mV.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible20mV);
this.invisible20mV.setBounds$I$I$I$I(86, 49, 18, 17);
this.invisible20V.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible20V);
this.invisible20V.setBounds$I$I$I$I(46, 89, 16, 19);
this.invisible50mV.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageScale.add$java_awt_Component(this.invisible50mV);
this.invisible50mV.setBounds$I$I$I$I(82, 29, 17, 17);
try {
this.horScrol.setStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.horScrol.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.horScrol);
this.horScrol.setBounds$I$I$I$I(396, 240, 26, 48);
this.invisibleLeft.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.horScrol.add$java_awt_Component(this.invisibleLeft);
this.invisibleLeft.setBounds$I$I$I$I(-3, 3, 16, 17);
this.invisibleRight.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.horScrol.add$java_awt_Component(this.invisibleRight);
this.invisibleRight.setBounds$I$I$I$I(14, 4, 14, 14);
try {
this.horIndicator.setFillColor$java_awt_Color($I$(9).red);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.horIndicator.setFillMode$Z(true);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.horScrol.add$java_awt_Component(this.horIndicator);
this.horIndicator.setBackground$java_awt_Color($I$(9).red);
this.horIndicator.setForeground$java_awt_Color($I$(9).lightGray);
this.horIndicator.setBounds$I$I$I$I(10, 16, 5, 5);
try {
this.vertScrol.setStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.vertScrol.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.vertScrol);
this.vertScrol.setBounds$I$I$I$I(384, 108, 36, 36);
this.invisibleUp.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.vertScrol.add$java_awt_Component(this.invisibleUp);
this.invisibleUp.setBounds$I$I$I$I(-3, 0, 15, 17);
this.invisibleDown.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.vertScrol.add$java_awt_Component(this.invisibleDown);
this.invisibleDown.setBounds$I$I$I$I(-3, 18, 18, 13);
try {
this.verIndicator.setFillColor$java_awt_Color($I$(9).red);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.verIndicator.setFillMode$Z(true);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.vertScrol.add$java_awt_Component(this.verIndicator);
this.verIndicator.setBackground$java_awt_Color($I$(9).red);
this.verIndicator.setForeground$java_awt_Color($I$(9).lightGray);
this.verIndicator.setBounds$I$I$I$I(10, 15, 5, 5);
try {
this.voltageMode.setStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.voltageMode.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.voltageMode);
this.voltageMode.setBounds$I$I$I$I(384, 24, 24, 36);
try {
this.modeIndicator.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.modeIndicator.setFillColor$java_awt_Color($I$(9).red);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.modeIndicator.setFillMode$Z(true);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.voltageMode.add$java_awt_Component(this.modeIndicator);
this.modeIndicator.setBounds$I$I$I$I(12, 14, 9, 7);
this.invisibleAC.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageMode.add$java_awt_Component(this.invisibleAC);
this.invisibleAC.setBounds$I$I$I$I(1, 2, 21, 12);
this.invisibleDC.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageMode.add$java_awt_Component(this.invisibleDC);
this.invisibleDC.setBounds$I$I$I$I(0, 12, 22, 12);
this.invisibleGround.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(12));
this.voltageMode.add$java_awt_Component(this.invisibleGround);
this.invisibleGround.setBounds$I$I$I$I(-1, 21, 24, 12);
try {
this.borderCanvas.setBevelStyle$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.borderCanvas.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.borderCanvas);
this.borderCanvas.setBounds$I$I$I$I(20, 9, 355, 285);
this.scopeCanvas.setCursor$java_awt_Cursor($I$(10).getPredefinedCursor$I(1));
this.borderCanvas.add$java_awt_Component(this.scopeCanvas);
this.scopeCanvas.setBackground$java_awt_Color(Clazz.new_($I$(9).c$$I$I$I,[77, 57, 7]));
this.scopeCanvas.setBounds$I$I$I$I(1, 1, 351, 281);
try {
this.borderVoltageScale.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderVoltageScale.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderVoltageScale.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderVoltageScale.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderVoltageScale.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderVoltageScale.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderVoltageScale.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderVoltageScale.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.borderVoltageScale.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.borderVoltageScale);
this.borderVoltageScale.setBounds$I$I$I$I(430, 12, 113, 144);
this.labelVoltageScale.setText$S("Voltage Scale");
this.borderVoltageScale.add$java_awt_Component(this.labelVoltageScale);
this.labelVoltageScale.setBounds$I$I$I$I(3, 2, 105, 25);
try {
this.borderTimeBase.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderTimeBase.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderTimeBase.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderTimeBase.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderTimeBase.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderTimeBase.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderTimeBase.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderTimeBase.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.borderTimeBase.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.borderTimeBase);
this.borderTimeBase.setBounds$I$I$I$I(430, 156, 113, 144);
this.labelTimeBase.setText$S("Time Base");
this.borderTimeBase.add$java_awt_Component(this.labelTimeBase);
this.labelTimeBase.setBounds$I$I$I$I(5, 7, 101, 21);
this.add$java_awt_Component(this.coords);
this.coords.setFont$java_awt_Font(Clazz.new_(Clazz.load('java.awt.Font').c$$S$I$I,["Dialog", 0, 10]));
this.coords.setBounds$I$I$I$I(21, 294, 217, 16);
this.labelVoltageScale.setText$S(this.cb.cirProp.getProperty$S("scope_vscale"));
this.labelTimeBase.setText$S(this.cb.cirProp.getProperty$S("scope_tbase"));
var cbString=this.cb.getCodeBase$().toString() + this.cb.imagedir + "/" ;
try {
try {
this.timeScale.setImageURL$java_net_URL(Clazz.new_(Clazz.load('java.net.URL').c$$S,[cbString + "btbt.gif"]));
} catch (error) {
if (Clazz.exceptionOf(error,"java.net.MalformedURLException")){
} else {
throw error;
}
}
try {
this.voltageScale.setImageURL$java_net_URL(Clazz.new_($I$(12).c$$S,[cbString + "btsv.gif"]));
} catch (error) {
if (Clazz.exceptionOf(error,"java.net.MalformedURLException")){
} else {
throw error;
}
}
try {
this.horScrol.setImageURL$java_net_URL(Clazz.new_($I$(12).c$$S,[cbString + "poth.gif"]));
} catch (error) {
if (Clazz.exceptionOf(error,"java.net.MalformedURLException")){
} else {
throw error;
}
}
try {
this.vertScrol.setImageURL$java_net_URL(Clazz.new_($I$(12).c$$S,[cbString + "potv.gif"]));
} catch (error) {
if (Clazz.exceptionOf(error,"java.net.MalformedURLException")){
} else {
throw error;
}
}
try {
this.voltageMode.setImageURL$java_net_URL(Clazz.new_($I$(12).c$$S,[cbString + "btmode.gif"]));
} catch (error) {
if (Clazz.exceptionOf(error,"java.net.MalformedURLException")){
} else {
throw error;
}
}
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
var aSymWindow=Clazz.new_(Clazz.load(['circuitsimulator.OscilloDialog','.SymWindow']), [this, null]);
this.addWindowListener$java_awt_event_WindowListener(aSymWindow);
var aSymMouse=Clazz.new_(Clazz.load(['circuitsimulator.OscilloDialog','.SymMouse']), [this, null]);
this.invisible5mV.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible10mV.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible20mV.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible50mV.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible01V.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible02V.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible05V.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible1V.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible2V.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible5V.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible10V.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible20V.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible10us.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible20us.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible50us.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible01ms.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible02ms.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible05ms.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible1ms.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible2ms.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible5ms.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible10ms.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible20ms.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisible50ms.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisibleLeft.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisibleRight.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisibleUp.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisibleDown.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisibleAC.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisibleDC.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.invisibleGround.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.scopeCanvas.addMouseListener$java_awt_event_MouseListener(aSymMouse);
var aSymMouseMotion=Clazz.new_(Clazz.load(['circuitsimulator.OscilloDialog','.SymMouseMotion']), [this, null]);
this.scopeCanvas.addMouseMotionListener$java_awt_event_MouseMotionListener(aSymMouseMotion);
this.voltageScaling=1.0;
this.timeScaling=0.001;
this.verOffset=this.horOffset=0;
this.scopeCanvas.repaint$();
this.mode="DC";
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_CircuitBuilder', function (cirbuilder) {
C$.c$$java_awt_Frame$circuitsimulator_CircuitBuilder.apply(this, [null, cirbuilder]);
}, 1);

Clazz.newMeth(C$, 'addNotify$', function () {
var d=this.getSize$();
C$.superclazz.prototype.addNotify$.apply(this, []);
if (this.fComponentsAdjusted) return;
var insets=this.getInsets$();
this.setSize$I$I(insets.left + insets.right + d.width , insets.top + insets.bottom + d.height );
var components=this.getComponents$();
for (var i=0; i < components.length; i++) {
var p=components[i].getLocation$();
p.translate$I$I(insets.left, insets.top);
components[i].setLocation$java_awt_Point(p);
}
this.fComponentsAdjusted=true;
});

Clazz.newMeth(C$, 'setVisible$Z', function (b) {
if (b) this.setLocation$I$I(100, 100);
C$.superclazz.prototype.setVisible$Z.apply(this, [b]);
});

Clazz.newMeth(C$, 'OscilloDialog_WindowClosing$java_awt_event_WindowEvent', function (event) {
this.setVisible$Z(false);
this.cb.scopeList.removeElement$O(this);
});

Clazz.newMeth(C$, 'invisible5mV_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(59, 70, 12, 12);
this.voltageScaling=0.005;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible10mV_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(66, 61, 12, 12);
this.voltageScaling=0.01;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible20mV_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(68, 51, 12, 12);
this.voltageScaling=0.02;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible50mV_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(66, 41, 12, 12);
this.voltageScaling=0.05;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible01V_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(59, 33, 12, 12);
this.voltageScaling=0.1;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible02V_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(48, 32, 12, 12);
this.voltageScaling=0.2;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible05V_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(37, 33, 12, 12);
this.voltageScaling=0.5;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible1V_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(30, 41, 12, 12);
this.voltageScaling=1.0;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible2V_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(27, 51, 12, 12);
this.voltageScaling=2.0;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible5V_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(30, 61, 12, 12);
this.voltageScaling=5.0;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible10V_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(37, 70, 12, 12);
this.voltageScaling=10.0;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible20V_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.voltageIndicator.setBounds$I$I$I$I(48, 73, 12, 12);
this.voltageScaling=20.0;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible10us_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(59, 70, 12, 12);
this.timeScaling=1.0E-5;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible20us_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(66, 61, 12, 12);
this.timeScaling=2.0E-5;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible50us_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(68, 51, 12, 12);
this.timeScaling=5.0E-5;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible01ms_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(66, 41, 12, 12);
this.timeScaling=1.0E-4;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible02ms_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(59, 33, 12, 12);
this.timeScaling=2.0E-4;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible05ms_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(48, 32, 12, 12);
this.timeScaling=5.0E-4;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible1ms_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(37, 33, 12, 12);
this.timeScaling=0.001;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible2ms_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(30, 41, 12, 12);
this.timeScaling=0.002;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible5ms_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(27, 51, 12, 12);
this.timeScaling=0.005;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible10ms_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(30, 61, 12, 12);
this.timeScaling=0.01;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible20ms_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(37, 70, 12, 12);
this.timeScaling=0.02;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisible50ms_mouseClicked$java_awt_event_MouseEvent', function (event) {
try {
this.timeIndicator.setBounds$I$I$I$I(48, 73, 12, 12);
this.timeScaling=0.05;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'invisibleLeft_mouseClicked$java_awt_event_MouseEvent', function (event) {
this.horOffset -= 7;
this.horIndicator.setBounds$I$I$I$I(10 + (Math.round(10 * Math.sin(this.horOffset * 3.141592653589793 / 180))|0), 26 - (Math.round(10 * Math.cos(this.horOffset * 3.141592653589793 / 180))|0), 5, 5);
});

Clazz.newMeth(C$, 'invisibleRight_mouseClicked$java_awt_event_MouseEvent', function (event) {
this.horOffset += 7;
this.horIndicator.setBounds$I$I$I$I(10 + (Math.round(10 * Math.sin(this.horOffset * 3.141592653589793 / 180))|0), 26 - (Math.round(10 * Math.cos(this.horOffset * 3.141592653589793 / 180))|0), 5, 5);
});

Clazz.newMeth(C$, 'invisibleUp_mouseClicked$java_awt_event_MouseEvent', function (event) {
this.verOffset += 7;
this.verIndicator.setBounds$I$I$I$I(20 - (Math.round(10 * Math.cos(this.verOffset * 3.141592653589793 / 180))|0), 15 - (Math.round(10 * Math.sin(this.verOffset * 3.141592653589793 / 180))|0), 5, 5);
});

Clazz.newMeth(C$, 'invisibleDown_mouseClicked$java_awt_event_MouseEvent', function (event) {
this.verOffset -= 7;
this.verIndicator.setBounds$I$I$I$I(20 - (Math.round(10 * Math.cos(this.verOffset * 3.141592653589793 / 180))|0), 15 - (Math.round(10 * Math.sin(this.verOffset * 3.141592653589793 / 180))|0), 5, 5);
});

Clazz.newMeth(C$, 'invisibleAC_mouseClicked$java_awt_event_MouseEvent', function (event) {
this.modeIndicator.setBounds$I$I$I$I(12, 4, 9, 7);
this.mode="AC";
});

Clazz.newMeth(C$, 'invisibleDC_mouseClicked$java_awt_event_MouseEvent', function (event) {
this.modeIndicator.setBounds$I$I$I$I(12, 14, 9, 7);
this.mode="DC";
});

Clazz.newMeth(C$, 'invisibleGround_mouseClicked$java_awt_event_MouseEvent', function (event) {
this.modeIndicator.setBounds$I$I$I$I(12, 24, 9, 7);
this.mode="Ground";
});

Clazz.newMeth(C$, 'scopeCanvas_MouseDragged$java_awt_event_MouseEvent', function (event) {
this.coords.setText$S(this.scopeCanvas.getCoords$java_awt_Point(event.getPoint$()));
});

Clazz.newMeth(C$, 'scopeCanvas_MouseClicked$java_awt_event_MouseEvent', function (event) {
this.coords.setText$S(this.scopeCanvas.getCoords$java_awt_Point(event.getPoint$()));
});
;
(function(){var C$=Clazz.newClass(P$.OscilloDialog, "SymWindow", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.WindowAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0 ) this.this$0.OscilloDialog_WindowClosing$java_awt_event_WindowEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.OscilloDialog, "SymMouse", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.MouseAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0.invisible5mV ) this.this$0.invisible5mV_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible10mV ) this.this$0.invisible10mV_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible20mV ) this.this$0.invisible20mV_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible50mV ) this.this$0.invisible50mV_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible01V ) this.this$0.invisible01V_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible02V ) this.this$0.invisible02V_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible05V ) this.this$0.invisible05V_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible1V ) this.this$0.invisible1V_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible2V ) this.this$0.invisible2V_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible5V ) this.this$0.invisible5V_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible10V ) this.this$0.invisible10V_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible20V ) this.this$0.invisible20V_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible10us ) this.this$0.invisible10us_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible20us ) this.this$0.invisible20us_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible50us ) this.this$0.invisible50us_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible01ms ) this.this$0.invisible01ms_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible02ms ) this.this$0.invisible02ms_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible05ms ) this.this$0.invisible05ms_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible1ms ) this.this$0.invisible1ms_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible2ms ) this.this$0.invisible2ms_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible5ms ) this.this$0.invisible5ms_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible10ms ) this.this$0.invisible10ms_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible20ms ) this.this$0.invisible20ms_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisible50ms ) this.this$0.invisible50ms_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisibleLeft ) this.this$0.invisibleLeft_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisibleRight ) this.this$0.invisibleRight_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisibleUp ) this.this$0.invisibleUp_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisibleDown ) this.this$0.invisibleDown_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisibleAC ) this.this$0.invisibleAC_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisibleDC ) this.this$0.invisibleDC_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.invisibleGround ) this.this$0.invisibleGround_mouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
if (object === this.this$0.scopeCanvas ) this.this$0.scopeCanvas_MouseClicked$java_awt_event_MouseEvent.apply(this.this$0, [event]);
this.this$0.scopeCanvas.repaint$();
this.this$0.timeScale.repaint$();
this.this$0.voltageScale.repaint$();
this.this$0.horScrol.repaint$();
this.this$0.vertScrol.repaint$();
this.this$0.voltageMode.repaint$();
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.OscilloDialog, "SymMouseMotion", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.MouseMotionAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0.scopeCanvas ) this.this$0.scopeCanvas_MouseDragged$java_awt_event_MouseEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:16 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
