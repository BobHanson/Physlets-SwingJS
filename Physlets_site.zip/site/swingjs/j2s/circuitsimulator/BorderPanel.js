(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "BorderPanel", null, 'javax.swing.JPanel');
C$.BEVEL_LOWERED = null;
C$.BEVEL_RAISED = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.BEVEL_LOWERED = null;
C$.BEVEL_RAISED = null;
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'setBevelStyle$S', function (bevelRaised) {
});

Clazz.newMeth(C$, 'setPaddingRight$I', function (i) {
});

Clazz.newMeth(C$, 'setPaddingLeft$I', function (i) {
});

Clazz.newMeth(C$, 'setIPadBottom$I', function (i) {
});

Clazz.newMeth(C$, 'setIPadSides$I', function (i) {
});

Clazz.newMeth(C$, 'setPaddingTop$I', function (i) {
});

Clazz.newMeth(C$, 'setIPadTop$I', function (i) {
});

Clazz.newMeth(C$, 'setPaddingBottom$I', function (i) {
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 06:55:32
