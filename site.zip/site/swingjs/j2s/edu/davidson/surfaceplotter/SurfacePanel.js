(function(){var P$=Clazz.newPackage("edu.davidson.surfaceplotter"),I$=[['java.awt.BorderLayout','edu.davidson.surfaceplotter.SurfaceCanvas','edu.davidson.tools.SApplet',['edu.davidson.surfaceplotter.SurfacePanel','.PoissonPanel_mouseMotionAdapter'],['edu.davidson.surfaceplotter.SurfacePanel','.SurfacePanel_mouseAdapter']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SurfacePanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'a2s.Panel', 'edu.davidson.tools.SDataListener');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.borderLayout1 = null;
this.surfaceCanvas = null;
this.sapplet = null;
this.autoRefresh = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.borderLayout1 = Clazz.new_((I$[1]||$incl$(1)));
this.surfaceCanvas = Clazz.new_((I$[2]||$incl$(2)));
this.sapplet = null;
this.autoRefresh = true;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$edu_davidson_tools_SApplet.apply(this, [null]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet', function (sa) {
Clazz.super_(C$, this,1);
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.sapplet=sa;
(I$[3]||$incl$(3)).addDataListener$O(this);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(Clazz.new_((I$[4]||$incl$(4)).c$$edu_davidson_surfaceplotter_SurfaceCanvas, [this, null, this.surfaceCanvas]));
this.addMouseListener$java_awt_event_MouseListener(Clazz.new_((I$[5]||$incl$(5)).c$$edu_davidson_surfaceplotter_SurfaceCanvas, [this, null, this.surfaceCanvas]));
}, 1);

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.add$java_awt_Component$O(this.surfaceCanvas, "Center");
});

Clazz.newMeth(C$, 'setFunction1$S', function (funcStr) {
this.stop();
if (funcStr == null  || funcStr.equals$O("") ) {
funcStr=null;
}this.surfaceCanvas.dataGenerator.setDataArray$DAA(null);
this.surfaceCanvas.controller.setFunction1$S(funcStr);
this.surfaceCanvas.dataGenerator.createData();
this.surfaceCanvas.startPlot();
return true;
});

Clazz.newMeth(C$, 'setFunction2$S', function (funcStr) {
this.stop();
if (funcStr == null  || funcStr.equals$O("") ) {
funcStr=null;
}this.surfaceCanvas.controller.setFunction2$S(funcStr);
this.surfaceCanvas.dataGenerator.createData();
this.surfaceCanvas.startPlot();
return true;
});

Clazz.newMeth(C$, 'setScaleFactor$I', function (sf) {
this.surfaceCanvas.projector.set2DScaling$F(sf);
});

Clazz.newMeth(C$, 'setDistance$I', function (dis) {
this.surfaceCanvas.projector.setDistance$F(dis);
});

Clazz.newMeth(C$, 'setRotationAngle$D', function (a) {
this.surfaceCanvas.projector.setRotationAngle$F(a);
});

Clazz.newMeth(C$, 'getRotationAngle', function () {
return this.surfaceCanvas.projector.getRotationAngle();
});

Clazz.newMeth(C$, 'setElevationAngle$D', function (a) {
this.surfaceCanvas.projector.setElevationAngle$F(a);
});

Clazz.newMeth(C$, 'getElevationAngle', function () {
return this.surfaceCanvas.projector.getElevationAngle();
});

Clazz.newMeth(C$, 'startRotate', function () {
this.surfaceCanvas.startRotation();
});

Clazz.newMeth(C$, 'stopRotate', function () {
this.surfaceCanvas.stopRotation();
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
this.sapplet=owner;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.sapplet;
});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (s, id, x, y) {
System.out.println$S("addDatum Series not supported.");
System.out.println$S("x=" + new Double(x).toString() + "    y=" + new Double(y).toString() );
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (s, id, x, y) {
var varStrings;
var dataArray = null;
varStrings=s.getVarStrings();
if (varStrings == null  || varStrings[0] == null   || varStrings[0].equals$O("surfacedata") ) {
dataArray=s.getVariables();
if (dataArray[0].length != dataArray.length) {
System.out.println$S("Surface data array is not square");
return;
}this.setGridPts$I(dataArray.length - 1);
this.surfaceCanvas.dataGenerator.setDataArray$DAA(dataArray);
this.surfaceCanvas.dataGenerator.createData();
}this.surfaceCanvas.startPlot();
});

Clazz.newMeth(C$, 'addData$I$DAA', function (id, dataArray) {
if (dataArray == null ) {
System.out.println$S("null data");
return;
}if (dataArray[0].length != dataArray.length) {
System.out.println$S("Surface data array is not square");
return;
}this.setGridPts$I(dataArray.length - 1);
this.surfaceCanvas.dataGenerator.setDataArray$DAA(dataArray);
this.surfaceCanvas.dataGenerator.createData();
this.surfaceCanvas.startPlot();
});

Clazz.newMeth(C$, 'deleteSeries$I', function (id) {
this.stop();
this.surfaceCanvas.dataGenerator.setDataArray$DAA(null);
});

Clazz.newMeth(C$, 'clearSeries$I', function (id) {
this.stop();
this.surfaceCanvas.dataGenerator.setDataArray$DAA(null);
});

Clazz.newMeth(C$, 'destroyThread', function () {
try {
this.surfaceCanvas.destroyThread();
this.surfaceCanvas.dataGenerator.destroyThread();
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'getMinX', function () {
return this.surfaceCanvas.controller.getXMin();
});

Clazz.newMeth(C$, 'getMaxX', function () {
return this.surfaceCanvas.controller.getXMax();
});

Clazz.newMeth(C$, 'getMinY', function () {
return this.surfaceCanvas.controller.getYMin();
});

Clazz.newMeth(C$, 'getMaxY', function () {
return this.surfaceCanvas.controller.getYMax();
});

Clazz.newMeth(C$, 'getMinZ', function () {
return this.surfaceCanvas.controller.getZMin();
});

Clazz.newMeth(C$, 'getMaxZ', function () {
return this.surfaceCanvas.controller.getZMax();
});

Clazz.newMeth(C$, 'setMinX$D', function (val) {
this.surfaceCanvas.controller.xmin=val;
});

Clazz.newMeth(C$, 'setMaxX$D', function (val) {
this.surfaceCanvas.controller.xmax=val;
});

Clazz.newMeth(C$, 'setMinY$D', function (val) {
this.surfaceCanvas.controller.ymin=val;
});

Clazz.newMeth(C$, 'setMaxY$D', function (val) {
this.surfaceCanvas.controller.ymax=val;
});

Clazz.newMeth(C$, 'setMinZ$D', function (val) {
this.surfaceCanvas.controller.zmin=val;
});

Clazz.newMeth(C$, 'setTime$D', function (t) {
this.surfaceCanvas.setTime$D(t);
});

Clazz.newMeth(C$, 'resetTime', function () {
this.surfaceCanvas.resetTime();
});

Clazz.newMeth(C$, 'setMaxZ$D', function (val) {
this.surfaceCanvas.controller.zmax=val;
});

Clazz.newMeth(C$, 'getMode', function () {
return this.surfaceCanvas.controller.plotMode;
});

Clazz.newMeth(C$, 'setMode$I', function (val) {
this.surfaceCanvas.controller.plotMode=val;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.stop();
this.surfaceCanvas.controller.setDefault();
this.setAutoRefresh$Z(this.autoRefresh);
});

Clazz.newMeth(C$, 'setContour', function () {
if (this.surfaceCanvas.contour && !this.surfaceCanvas.density ) return;
this.surfaceCanvas.setContour$Z(true);
this.surfaceCanvas.destroyImage();
this.surfaceCanvas.repaint();
});

Clazz.newMeth(C$, 'isContour', function () {
return this.surfaceCanvas.contour;
});

Clazz.newMeth(C$, 'setDensity', function () {
if (!this.surfaceCanvas.contour && this.surfaceCanvas.density ) return;
this.surfaceCanvas.setDensity$Z(true);
this.surfaceCanvas.destroyImage();
this.surfaceCanvas.repaint();
});

Clazz.newMeth(C$, 'isDensity', function () {
return this.surfaceCanvas.density;
});

Clazz.newMeth(C$, 'setGutter$I', function (gutter) {
this.surfaceCanvas.gutter=gutter;
});

Clazz.newMeth(C$, 'setThreeD', function () {
if (!this.surfaceCanvas.contour && !this.surfaceCanvas.density && !this.surfaceCanvas.noDrawing  ) return;
this.surfaceCanvas.setContour$Z(false);
this.surfaceCanvas.setDensity$Z(false);
this.surfaceCanvas.destroyImage();
this.surfaceCanvas.repaint();
});

Clazz.newMeth(C$, 'setNoDrawing', function () {
this.surfaceCanvas.setNoDrawing$Z(true);
this.surfaceCanvas.destroyImage();
this.surfaceCanvas.repaint();
});

Clazz.newMeth(C$, 'isThreeD', function () {
return !(this.surfaceCanvas.contour || this.surfaceCanvas.density );
});

Clazz.newMeth(C$, 'setShowBox$Z', function (val) {
this.surfaceCanvas.controller.boxed=val;
});

Clazz.newMeth(C$, 'setShowMesh$Z', function (val) {
this.surfaceCanvas.controller.showMesh=val;
});

Clazz.newMeth(C$, 'setAutoRefresh$Z', function (val) {
this.autoRefresh=val;
if (this.autoRefresh) {
this.surfaceCanvas.destroyImage();
this.surfaceCanvas.repaint();
} else this.stop();
});

Clazz.newMeth(C$, 'setScaledBox$Z', function (val) {
this.surfaceCanvas.controller.autoScale=val;
});

Clazz.newMeth(C$, 'setAutoscaleZ$Z', function (val) {
this.surfaceCanvas.controller.autoScaleHeigth=val;
});

Clazz.newMeth(C$, 'setShowFaceGrids$Z', function (val) {
this.surfaceCanvas.controller.showFaceGrids=val;
});

Clazz.newMeth(C$, 'setShowXYticks$Z', function (val) {
this.surfaceCanvas.controller.displayXYTicks=val;
});

Clazz.newMeth(C$, 'setShowZticks$Z', function (val) {
this.surfaceCanvas.controller.displayZTicks=val;
});

Clazz.newMeth(C$, 'setGridPts$I', function (pts) {
if (pts == this.surfaceCanvas.controller.calc_divisions) return;
{
this.surfaceCanvas.dataGenerator.interrupt();
this.surfaceCanvas.interrupt();
this.surfaceCanvas.dataGenerator.setDataArray$DAA(null);
this.surfaceCanvas.controller.calc_divisions=pts;
this.surfaceCanvas.controller.disp_divisions=pts;
}if (this.autoRefresh) this.surfaceCanvas.repaint();
});

Clazz.newMeth(C$, 'setNumLevels$I', function (num) {
if (this.surfaceCanvas.controller.numContourLines == num) return;
{
this.surfaceCanvas.dataGenerator.interrupt();
this.surfaceCanvas.interrupt();
this.surfaceCanvas.controller.numContourLines=num;
}if (this.autoRefresh) this.surfaceCanvas.repaint();
});

Clazz.newMeth(C$, 'setGraphFont$java_awt_Font', function (font) {
this.surfaceCanvas.defaultFont=font;
});

Clazz.newMeth(C$, 'stop', function () {
this.surfaceCanvas.dataGenerator.interrupt();
this.surfaceCanvas.interrupt();
});
;
(function(){var C$=Clazz.newClass(P$.SurfacePanel, "SurfacePanel_mouseAdapter", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.MouseAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_surfaceplotter_SurfaceCanvas', function (adaptee) {
Clazz.super_(C$, this,1);
this.adaptee=adaptee;
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.adaptee.myMouseDown$java_awt_event_MouseEvent$I$I(e, e.getX(), e.getY());
});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
this.adaptee.myMouseDrag$java_awt_event_MouseEvent$I$I(e, e.getX(), e.getY());
});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
this.adaptee.myMouseEnter$java_awt_event_MouseEvent$I$I(e, e.getX(), e.getY());
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.adaptee.myMouseUp$java_awt_event_MouseEvent$I$I(e, e.getX(), e.getY());
this.adaptee.startPlot();
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.SurfacePanel, "PoissonPanel_mouseMotionAdapter", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.MouseMotionAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_surfaceplotter_SurfaceCanvas', function (adaptee) {
Clazz.super_(C$, this,1);
this.adaptee=adaptee;
}, 1);

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
this.adaptee.myMouseDrag$java_awt_event_MouseEvent$I$I(e, e.getX(), e.getY());
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-07-20 18:09:39
