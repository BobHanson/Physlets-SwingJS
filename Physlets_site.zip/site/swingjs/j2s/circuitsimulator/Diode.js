(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'edu.davidson.tools.SUtil']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Diode", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.nv=0;
this.ov=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.ov=0;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$I$S', function (circuit, isat, d, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circuit, d, r, c, t]);
C$.$init$.apply(this);
this.value=isat;
this.unity="A";
this.leftlinear=false;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit', function (circuit) {
C$.superclazz.c$$circuitsimulator_Circuit.apply(this, [circuit]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'impedance$', function () {
this.nv=this.ov;
this.ov=this.getV$();
this.nv=this.nv == 0  ? 1.0 / (this.value * 38.9) : this.nv / (this.value * (Math.exp(38.9 * this.nv) - 1.0));
return Math.abs(this.nv);
});

Clazz.newMeth(C$, 'rightFunction$D', function (sign) {
return 0;
});

Clazz.newMeth(C$, 'valueStr$', function () {
return this.$function;
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",isat=" + Double.toString$D(this.value);
});

Clazz.newMeth(C$, 'set$S', function (list) {
var ret=C$.superclazz.prototype.set$S.apply(this, [list]);
if ($I$(1).parameterExist$S$S(list, "isat=")) this.value=$I$(1).getParam$S$S(list, "isat=");
return ret;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:48 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
