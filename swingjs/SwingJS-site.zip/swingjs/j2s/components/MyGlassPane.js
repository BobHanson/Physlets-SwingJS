(function(){var P$=Clazz.newPackage("components"),p$1={},I$=[[0,'javax.swing.JFrame','javax.swing.JCheckBox','java.awt.FlowLayout','javax.swing.JButton','javax.swing.JMenuBar','javax.swing.JMenu','javax.swing.JMenuItem','test.components.GlassPaneDemo','test.components.MyGlassPane','javax.swing.SwingUtilities','java.awt.Color','test.components.CBListener','java.awt.Toolkit','java.awt.event.MouseEvent']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MyGlassPane", null, 'javax.swing.JLabel', 'java.awt.event.ItemListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['point','java.awt.Point']]]

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent', function (e) {
this.setVisible$Z(e.getStateChange$() == 1);
});

Clazz.newMeth(C$, 'paintComponent$java_awt_Graphics', function (g) {
if (this.point != null ) {
g.setColor$java_awt_Color($I$(11).red);
g.fillOval$I$I$I$I(this.point.x - 10, this.point.y - 10, 20, 20);
}});

Clazz.newMeth(C$, 'setPoint$java_awt_Point', function (p) {
this.point=p;
});

Clazz.newMeth(C$, 'c$$javax_swing_AbstractButton$javax_swing_JMenuBar$java_awt_Container', function (aButton, menuBar, contentPane) {
Clazz.super_(C$, this);
var listener=Clazz.new_($I$(12,1).c$$java_awt_Component$javax_swing_JMenuBar$test_components_MyGlassPane$java_awt_Container,[aButton, menuBar, this, contentPane]);
this.addMouseListener$java_awt_event_MouseListener(listener);
this.addMouseMotionListener$java_awt_event_MouseMotionListener(listener);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-16 19:32:09 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
