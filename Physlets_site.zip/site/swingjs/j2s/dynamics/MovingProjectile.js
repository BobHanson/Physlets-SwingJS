(function(){var P$=Clazz.newPackage("dynamics");
var C$=Clazz.newClass(P$, "MovingProjectile", null, 'dynamics.rk4');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.r3=0;
this.GM=0;
this.c0=0;
this.count=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'setup$D$D$D$D', function (n, n2, n3, n4) {
this.y[0]=n;
this.y[1]=n2;
this.y[2]=n3;
this.y[3]=n4;
this.c0=10.0 * Math.abs(n3);
});

Clazz.newMeth(C$, 'setupDrag$D$D', function (n, n2) {
this.y[1]=n;
this.y[3]=n2;
});

Clazz.newMeth(C$, 'setGM$D', function (n) {
this.GM=-n;
});

Clazz.newMeth(C$, 'getX$', function () {
return this.y[0];
});

Clazz.newMeth(C$, 'getY$', function () {
return this.y[2];
});

Clazz.newMeth(C$, 'vx$', function () {
return this.y[1];
});

Clazz.newMeth(C$, 'vy$', function () {
return this.y[3];
});

Clazz.newMeth(C$, 'V$', function () {
return Math.sqrt(this.y[1] * this.y[1] + this.y[3] * this.y[3]);
});

Clazz.newMeth(C$, 'R$', function () {
return Math.sqrt(this.y[0] * this.y[0] + this.y[2] * this.y[2]);
});

Clazz.newMeth(C$, 'derivs$D$DA$DA', function (n, array, array2) {
this.r3=array[0] * array[0] + array[2] * array[2];
this.r3 *= Math.sqrt(this.r3);
array2[0]=array[1];
array2[1]=this.GM * array[0] / this.r3;
array2[2]=array[3];
array2[3]=this.GM * array[2] / this.r3;
});

Clazz.newMeth(C$, 'advanced$D', function (h) {
this.count=((this.c0 / this.R$())|0);
h /= this.count;
for (var i=0; i < this.count; ++i) {
this.nextmove$D(h);
}
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.GM=-980000.0;
this.count=20;
this.init$I$Z(4, true);
}, 1);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:12 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
