(function(){var P$=Clazz.newPackage("faraday"),I$=[['edu.davidson.graphics.EtchedBorder','a2s.Button','a2s.Panel','a2s.Label','a2s.TextField','java.awt.BorderLayout','edu.davidson.display.SGraph','faraday.Schematic','java.awt.FlowLayout','a2s.Checkbox','Boolean','java.awt.Color','java.awt.Dimension','faraday.Faraday_runBtn_actionAdapter','faraday.Faraday_resetBtn_actionAdapter','faraday.Faraday$1','faraday.Faraday$2','faraday.Faraday$3','faraday.Faraday_forwardBtn_actionAdapter','edu.davidson.tools.SUtil','faraday.UWire','edu.davidson.display.Constraint','faraday.FluxBox','faraday.FluxRectangle','faraday.FluxCircle','edu.davidson.display.MarkerThing','faraday.FluxShell','edu.davidson.display.ArrowThing','faraday.CalcThing','edu.davidson.graphics.Util','edu.davidson.display.ImageThing','edu.davidson.display.CaptionThing','java.awt.Font','java.awt.event.ActionEvent']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Faraday", null, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SStepable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.button_reset = null;
this.button_start = null;
this.button_stop = null;
this.button_forward = null;
this.label_udrag = null;
this.label_yaxis = null;
this.label_xaxis = null;
this.label_bxt = null;
this.label_xt = null;
this.label_time = null;
this.label_current = null;
this.pixPerUnit = 0;
this.fps = 0;
this.showControls = false;
this.fieldStr = null;
this.posStr = null;
this.stopMessage = null;
this.showGraph = false;
this.etchedBorder1 = null;
this.etchedBorder2 = null;
this.etchedBorder3 = null;
this.runBtn = null;
this.resetBtn = null;
this.etchedBorder4 = null;
this.panel1 = null;
this.panel2 = null;
this.label1 = null;
this.label2 = null;
this.posField = null;
this.fieldField = null;
this.borderLayout1 = null;
this.borderLayout3 = null;
this.etchedBorder7 = null;
this.graph = null;
this.schematic = null;
this.borderLayout4 = null;
this.borderLayout5 = null;
this.borderLayout6 = null;
this.flowLayout1 = null;
this.borderLayout2 = null;
this.borderLayout7 = null;
this.dragMode = false;
this.maxTime = 0;
this.uwireExists = false;
this.schematicWidth = 0;
this.showSchematic = false;
this.showGrid = false;
this.showColor = false;
this.showCurrentArrow = false;
this.forwardBtn = null;
this.dragBox = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.button_reset = "Clear";
this.button_start = "Run";
this.button_stop = "Stop";
this.button_forward = ">>";
this.label_udrag = "U Drag";
this.label_yaxis = "Voltage (mV)";
this.label_xaxis = "Time(s)";
this.label_bxt = "B(x,t)";
this.label_xt = "x(t)";
this.label_time = "Time:";
this.label_current = "Current";
this.stopMessage = null;
this.etchedBorder1 = Clazz.new_((I$[1]||$incl$(1)));
this.etchedBorder2 = Clazz.new_((I$[1]||$incl$(1)));
this.etchedBorder3 = Clazz.new_((I$[1]||$incl$(1)));
this.runBtn = Clazz.new_((I$[2]||$incl$(2)));
this.resetBtn = Clazz.new_((I$[2]||$incl$(2)));
this.etchedBorder4 = Clazz.new_((I$[1]||$incl$(1)));
this.panel1 = Clazz.new_((I$[3]||$incl$(3)));
this.panel2 = Clazz.new_((I$[3]||$incl$(3)));
this.label1 = Clazz.new_((I$[4]||$incl$(4)));
this.label2 = Clazz.new_((I$[4]||$incl$(4)));
this.posField = Clazz.new_((I$[5]||$incl$(5)));
this.fieldField = Clazz.new_((I$[5]||$incl$(5)));
this.borderLayout1 = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout3 = Clazz.new_((I$[6]||$incl$(6)));
this.etchedBorder7 = Clazz.new_((I$[1]||$incl$(1)));
this.graph = Clazz.new_((I$[7]||$incl$(7)));
this.schematic = Clazz.new_((I$[8]||$incl$(8)).c$$faraday_Faraday,[this]);
this.borderLayout4 = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout5 = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout6 = Clazz.new_((I$[6]||$incl$(6)));
this.flowLayout1 = Clazz.new_((I$[9]||$incl$(9)));
this.borderLayout2 = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout7 = Clazz.new_((I$[6]||$incl$(6)));
this.dragMode = true;
this.maxTime = 10;
this.uwireExists = false;
this.schematicWidth = 200;
this.showSchematic = true;
this.showGrid = true;
this.showColor = true;
this.showCurrentArrow = true;
this.forwardBtn = Clazz.new_((I$[2]||$incl$(2)));
this.dragBox = Clazz.new_((I$[10]||$incl$(10)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'setResources', function () {
this.button_reset = this.localProperties.getProperty$S$S("button.reset", this.button_reset);
this.button_start = this.localProperties.getProperty$S$S("button.start", this.button_start);
this.button_stop = this.localProperties.getProperty$S$S("button.stop", this.button_stop);
this.button_forward = this.localProperties.getProperty$S$S("button.forward", this.button_forward);
this.label_udrag = this.localProperties.getProperty$S$S("label.udrag", this.label_udrag);
this.label_yaxis = this.localProperties.getProperty$S$S("label.yaxis", this.label_yaxis);
this.label_xaxis = this.localProperties.getProperty$S$S("label.xaxis", this.label_xaxis);
this.label_bxt = this.localProperties.getProperty$S$S("label.bxt", this.label_bxt);
this.label_xt = this.localProperties.getProperty$S$S("label.xt", this.label_xt);
this.label_time = this.localProperties.getProperty$S$S("label.time", this.label_time);
this.label_current = this.localProperties.getProperty$S$S("label.current", this.label_current);
});

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
var dt = 0.1;
var showMeter = true;
;try {
this.maxTime = Double.$valueOf(this.getParameter$S$S("MaxTime", "10")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.pixPerUnit = Integer.parseInt(this.getParameter$S$S("PixPerUnit", "10"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.schematicWidth = Integer.parseInt(this.getParameter$S$S("SchematicWidth", "200"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.fps = Integer.parseInt(this.getParameter$S$S("FPS", "10"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
dt = Double.$valueOf(this.getParameter$S$S("dt", "0.1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.fieldStr = this.getParameter$S$S("FieldFunction", "10*sin(pi*x/5)");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.posStr = this.getParameter$S$S("PositionFunction", "1.0+3.0*t");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showSchematic = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowSchematic", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showGraph = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowGraph", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showGrid = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowGrid", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showColor = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowColor", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showCurrentArrow = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowCurrentArrow", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
showMeter = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowMeter", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.dragMode = (I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("DragMode", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.schematic.showSchematic = this.showSchematic;
this.clock.setDt$D(dt);
this.clock.setFPS$D(this.fps);
this.clock.setCycle$D$D(0, this.maxTime);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
if (!this.showControls) this.etchedBorder1.setVisible$Z(false);
this.autoRefresh = false;
this.posField.setText$S(this.posStr);
this.posField.setEnabled$Z(!this.dragMode);
this.dragBox.setState$Z(this.dragMode);
this.fieldField.setText$S(this.fieldStr);
this.graph.setEnableMouse$Z(true);
this.setBackground$java_awt_Color((I$[12]||$incl$(12)).lightGray);
this.graph.setBackground$java_awt_Color((I$[12]||$incl$(12)).white);
this.graph.setVisible$Z(this.showGraph);
this.setRunningID$O(this);
this.graph.deleteAllSeries();
this.graph.setAutoscaleX$Z(false);
this.graph.setAutoscaleY$Z(false);
this.graph.setBorders$S("0,10,10,5");
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(1, (I$[12]||$incl$(12)).red, true, 0);
this.graph.setMinMaxX$D$D(0, this.maxTime);
this.graph.setAutoscaleY$Z(true);
this.schematic.parsePosFunction$S(this.posStr);
this.schematic.parseFieldFunction$S(this.fieldStr);
this.schematic.pixPerUnit = this.pixPerUnit;
this.schematic.setDragMode$Z(this.dragMode);
this.schematic.fillApplet = !this.showGraph;
this.schematic.setPreferredWidth$I(this.schematicWidth);
this.schematic.showGrid = this.showGrid;
this.schematic.showColor = this.showColor;
this.schematic.setShowCurrentArrow$Z(this.showCurrentArrow);
this.schematic.setShowMeter$Z(showMeter);
this.autoRefresh = true;
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setSize$java_awt_Dimension(Clazz.new_((I$[13]||$incl$(13)).c$$I$I,[669, 401]));
this.runBtn.setLabel$S(this.button_start);
this.runBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[14]||$incl$(14)).c$$faraday_Faraday,[this]));
this.resetBtn.setLabel$S(this.button_reset);
this.resetBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[15]||$incl$(15)).c$$faraday_Faraday,[this]));
this.label1.setAlignment$I(2);
this.label1.setText$S(this.label_bxt);
this.label2.setAlignment$I(2);
this.label2.setText$S("   " + this.label_xt);
this.graph.setSampleData$Z(false);
this.graph.setLabelY$S(this.label_yaxis);
this.forwardBtn.setLabel$S(this.button_forward);
this.dragBox.setLabel$S(this.label_udrag);
this.dragBox.setBackground$java_awt_Color((I$[12]||$incl$(12)).lightGray);
this.dragBox.addItemListener$java_awt_event_ItemListener(((
(function(){var C$=Clazz.newClass(P$, "Faraday$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['itemStateChanged$java_awt_event_ItemEvent','itemStateChanged'], function (e) {
this.b$['faraday.Faraday'].dragBox_itemStateChanged$java_awt_event_ItemEvent(e);
});
})()
), Clazz.new_((I$[16]||$incl$(16)).$init$, [this, null])));
this.fieldField.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Faraday$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['faraday.Faraday'].fieldField_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[17]||$incl$(17)).$init$, [this, null])));
this.posField.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Faraday$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['faraday.Faraday'].posField_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[18]||$incl$(18)).$init$, [this, null])));
this.forwardBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[19]||$incl$(19)).c$$faraday_Faraday,[this]));
this.graph.setLabelX$S(this.label_xaxis);
this.etchedBorder4.setLayout$java_awt_LayoutManager(this.borderLayout4);
this.panel2.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.panel1.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.etchedBorder3.setLayout$java_awt_LayoutManager(this.borderLayout6);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.etchedBorder2.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.etchedBorder7.setLayout$java_awt_LayoutManager(this.borderLayout7);
this.setLayout$java_awt_LayoutManager(this.borderLayout5);
this.add$java_awt_Component$O(this.etchedBorder4, "Center");
this.etchedBorder4.add$java_awt_Component$O(this.graph, "Center");
this.etchedBorder7.add$java_awt_Component$O(this.schematic, "Center");
this.etchedBorder4.add$java_awt_Component$O(this.etchedBorder7, "West");
this.add$java_awt_Component$O(this.etchedBorder1, "South");
this.etchedBorder1.add$java_awt_Component$O(this.etchedBorder2, "West");
this.etchedBorder2.add$java_awt_Component$O(this.dragBox, null);
this.etchedBorder2.add$java_awt_Component$O(this.runBtn, null);
this.etchedBorder2.add$java_awt_Component$O(this.resetBtn, null);
this.etchedBorder2.add$java_awt_Component$O(this.forwardBtn, null);
this.etchedBorder1.add$java_awt_Component$O(this.etchedBorder3, "Center");
this.etchedBorder3.add$java_awt_Component$O(this.panel1, "North");
this.panel1.add$java_awt_Component$O(this.label2, "West");
this.panel1.add$java_awt_Component$O(this.posField, "Center");
this.etchedBorder3.add$java_awt_Component$O(this.panel2, "Center");
this.panel2.add$java_awt_Component$O(this.label1, "West");
this.panel2.add$java_awt_Component$O(this.fieldField, "Center");
});

Clazz.newMeth(C$, 'forward', function () {
this.schematic.setMessage$S(null);
if (this.clock.getDt() < 0 ) this.clock.setDt$D(-this.clock.getDt());
this.runBtn.setLabel$S(this.button_stop);
this.clock.startClock();
});

Clazz.newMeth(C$, 'reverse', function () {
this.schematic.setMessage$S(null);
if (this.clock.getDt() > 0 ) this.clock.setDt$D(-this.clock.getDt());
this.runBtn.setLabel$S(this.button_stop);
this.clock.startClock();
});

Clazz.newMeth(C$, 'stepTimeForward', function () {
if (this.clock.isRunning()) {
this.clock.stopClock();
}var dt = this.clock.getDt();
if (dt < 0 ) {
this.clock.setDt$D(-dt);
}this.clock.doStep();
});

Clazz.newMeth(C$, 'stepForward', function () {
this.stepTimeForward();
});

Clazz.newMeth(C$, 'stepTimeBack', function () {
if (this.clock.isRunning()) {
this.clock.stopClock();
}var dt = this.clock.getDt();
if (dt > 0 ) {
this.clock.setDt$D(-dt);
}this.clock.doStep();
});

Clazz.newMeth(C$, 'stepBack', function () {
this.stepTimeBack();
});

Clazz.newMeth(C$, 'destroy', function () {
this.clock.stopClock();
this.graph.destroy();
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.firstTime) return 0;
 else return C$.superclazz.prototype.getAppletCount.apply(this, []);
});

Clazz.newMeth(C$, 'start', function () {
if (this.firstTime) {
this.firstTime = false;
this.graph.setOwner$edu_davidson_tools_SApplet(this);
this.schematic.paint();
this.schematic.invalidateOSI();
var id = 0;
if (this.showSchematic) {
id = this.addObject$S$S("uwire", "x=0");
this.setDragable$I$Z(id, this.dragMode);
this.forward();
}}C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
var v = this.schematic.step$D$D(dt, time);
if (time > 0 ) this.graph.addDatum$I$D$D(1, time + dt, v);
});

Clazz.newMeth(C$, 'cyclingClock', function () {
this.schematic.resetTime();
this.graph.clearSeriesData$I(1);
this.clearAllData();
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Applet Information";
});

Clazz.newMeth(C$, 'getGraphID', function () {
return this.graph.getID();
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["MaxTime", "double", "Length of time the animation should run in seconds."]), Clazz.array(java.lang.String, -1, ["PixPerUnit", "int", "Pixesl per unit"]), Clazz.array(java.lang.String, -1, ["FPS", "int", "Frames per second in anmination"]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show controls"]), Clazz.array(java.lang.String, -1, ["FieldFunction", "String", "Magnetic Field: B(x,t)"]), Clazz.array(java.lang.String, -1, ["PositionFunction", "String", "The postion of the wire: x(t)"]), Clazz.array(java.lang.String, -1, ["ShowSchematic", "boolean", "Show the schematic at start up."]), Clazz.array(java.lang.String, -1, ["ShowGraph", "boolean", "Show the voltage graph: V(t)."]), Clazz.array(java.lang.String, -1, ["DragMode", "boolean", "Let the user drag the wire."])]);
return pinfo;
});

Clazz.newMeth(C$, 'runBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.fieldField_actionPerformed$java_awt_event_ActionEvent(e);
this.posField_actionPerformed$java_awt_event_ActionEvent(e);
if (this.clock.isRunning()) {
this.clock.stopClock();
this.runBtn.setLabel$S(this.button_start);
} else {
this.clock.startClock();
this.runBtn.setLabel$S(this.button_stop);
}});

Clazz.newMeth(C$, 'setDefault', function () {
this.deleteDataConnections();
this.clock.stopClock();
this.schematic.setDefault();
this.uwireExists = false;
this.runBtn.setLabel$S(this.button_start);
this.clock.setTime$D(0);
this.setPosFunction$S(null);
this.showSchematic = true;
this.schematic.showSchematic = true;
this.graph.clearSeriesData$I(1);
if (this.autoRefresh) this.schematic.repaint();
});

Clazz.newMeth(C$, 'reset', function () {
this.clock.stopClock();
this.runBtn.setLabel$S(this.button_start);
this.clock.setTime$D(0);
this.schematic.resetTime();
this.graph.clearSeriesData$I(1);
this.clearAllData();
if (this.autoRefresh) this.schematic.repaint();
});

Clazz.newMeth(C$, 'resetBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.reset();
});

Clazz.newMeth(C$, ['addObject$S$S','addObject'], function (name, parList) {
var t = null;
var x = 0;
var y = 0;
var width = 20;
var height = 20;
var r = 10;
name = name.toLowerCase().trim();
name = (I$[20]||$incl$(20)).removeWhitespace$S(name);
var parList2 = parList.trim();
;parList = (I$[20]||$incl$(20)).removeWhitespace$S(parList);
if (name.equals$O("uwire")) {
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if (!this.uwireExists) t = Clazz.new_((I$[21]||$incl$(21)).c$$edu_davidson_tools_SApplet$faraday_Schematic$D,[this, this.schematic, x]);
 else this.uwireExists = true;
} else if (name.equals$O("constraint")) {
var xmin = 0;
var xmax = 0;
var ymin = 0;
var ymax = 0;
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "xmin=")) xmin = (I$[20]||$incl$(20)).getParam$S$S(parList, "xmin=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "ymin=")) ymin = (I$[20]||$incl$(20)).getParam$S$S(parList, "ymin=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "xmax=")) xmax = (I$[20]||$incl$(20)).getParam$S$S(parList, "xmax=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "ymax=")) ymax = (I$[20]||$incl$(20)).getParam$S$S(parList, "ymax=");
t = Clazz.new_((I$[22]||$incl$(22)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$D$D,[this, this.schematic, xmin, xmax, ymin, ymax]);
} else if (name.equals$O("box")) {
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "y=")) y = (I$[20]||$incl$(20)).getParam$S$S(parList, "y=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "w=")) width = ((I$[20]||$incl$(20)).getParam$S$S(parList, "w=")|0);
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "h=")) height = ((I$[20]||$incl$(20)).getParam$S$S(parList, "h=")|0);
t = Clazz.new_((I$[23]||$incl$(23)).c$$edu_davidson_tools_SApplet$faraday_Schematic$D$D$I$I,[this, this.schematic, x, y, width, height]);
} else if (name.equals$O("rectangle")) {
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "y=")) y = (I$[20]||$incl$(20)).getParam$S$S(parList, "y=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "w=")) width = ((I$[20]||$incl$(20)).getParam$S$S(parList, "w=")|0);
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "h=")) height = ((I$[20]||$incl$(20)).getParam$S$S(parList, "h=")|0);
t = Clazz.new_((I$[24]||$incl$(24)).c$$edu_davidson_tools_SApplet$faraday_Schematic$D$D$I$I,[this, this.schematic, x, y, width, height]);
} else if (name.equals$O("circle")) {
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "y=")) y = (I$[20]||$incl$(20)).getParam$S$S(parList, "y=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "r=")) r = ((I$[20]||$incl$(20)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[25]||$incl$(25)).c$$edu_davidson_tools_SApplet$faraday_Schematic$D$D$I,[this, this.schematic, x, y, r]);
} else if (name.equals$O("cursor")) {
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "y=")) y = (I$[20]||$incl$(20)).getParam$S$S(parList, "y=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "r=")) r = ((I$[20]||$incl$(20)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[26]||$incl$(26)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D,[this, this.schematic, 2 * r + 1, x, y]);
} else if (name.equals$O("shell")) {
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "y=")) y = (I$[20]||$incl$(20)).getParam$S$S(parList, "y=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "r=")) r = ((I$[20]||$incl$(20)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[27]||$incl$(27)).c$$edu_davidson_tools_SApplet$faraday_Schematic$D$D$I,[this, this.schematic, x, y, r]);
} else if (name.equals$O("arrow")) {
var h = 1;
var v = 1;
var s = 4;
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "s=")) s = ((I$[20]||$incl$(20)).getParam$S$S(parList, "s=")|0);
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "y=")) y = (I$[20]||$incl$(20)).getParam$S$S(parList, "y=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "h=")) h = (I$[20]||$incl$(20)).getParam$S$S(parList, "h=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "v=")) v = (I$[20]||$incl$(20)).getParam$S$S(parList, "v=");
t = Clazz.new_((I$[28]||$incl$(28)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D$D$D,[this, this.schematic, s, h, v, x, y]);
} else if (name.equals$O("text")) {
var txt = "";
var calc = null;
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "y=")) y = (I$[20]||$incl$(20)).getParam$S$S(parList, "y=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "txt=")) txt = (I$[20]||$incl$(20)).getParamStr$S$S(parList2, "txt=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "text=")) txt = (I$[20]||$incl$(20)).getParamStr$S$S(parList2, "text=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "calc=")) calc = (I$[20]||$incl$(20)).getParamStr$S$S(parList, "calc=");
t = Clazz.new_((I$[29]||$incl$(29)).c$$edu_davidson_tools_SApplet$faraday_Schematic$S$S$D$D,[this, this.schematic, txt, calc, x, y]);
} else if (name.equals$O("image")) {
var file = " ";
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "y=")) y = (I$[20]||$incl$(20)).getParam$S$S(parList, "y=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "gif=")) file = (I$[20]||$incl$(20)).getParamStr$S$S(parList, "gif=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "file=")) file = (I$[20]||$incl$(20)).getParamStr$S$S(parList, "file=");
if (file == null ) return 0;
var im = (I$[30]||$incl$(30)).getImage$S$a2s_Applet(file, this);
if (im != null ) t = Clazz.new_((I$[31]||$incl$(31)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$java_awt_Image$D$D,[this, this.schematic, im, x, y]);
 else t = null;
} else if (name.equals$O("caption")) {
var txt = "";
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "x=")) x = (I$[20]||$incl$(20)).getParam$S$S(parList, "x=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "y=")) y = (I$[20]||$incl$(20)).getParam$S$S(parList, "y=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "txt=")) txt = (I$[20]||$incl$(20)).getParamStr$S$S(parList2, "txt=");
if ((I$[20]||$incl$(20)).parameterExist$S$S(parList, "text=")) txt = (I$[20]||$incl$(20)).getParamStr$S$S(parList2, "text=");
t = Clazz.new_((I$[32]||$incl$(32)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$S$D$D,[this, this.schematic, txt, x, y]);
}if (t == null ) {
System.out.println$S("Object not created. name:" + name + "parameter list:" + parList );
return 0;
}this.schematic.addThing$edu_davidson_display_Thing(t);
if (this.autoRefresh) this.schematic.repaint();
return t.hashCode();
});

Clazz.newMeth(C$, ['setConstraint$I$I','setConstraint'], function (id, constraintID) {
var t = this.schematic.getThing$I(id);
var c = this.schematic.getThing$I(constraintID);
if (t == null ) return false;
if (c == null ) return false;
if (!(Clazz.instanceOf(c, "edu.davidson.display.Constraint"))) return false;
t.setConstraint$edu_davidson_display_Constraint(c);
return true;
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (auto) {
if (this.autoRefresh == auto ) return;
this.autoRefresh = auto;
this.graph.setAutoRefresh$Z(auto);
if (!this.autoRefresh) return;
this.schematic.invalidateOSI();
this.schematic.paint();
this.graph.repaint();
});

Clazz.newMeth(C$, ['setShowColor$Z','setShowColor'], function (show) {
this.showColor = show;
this.schematic.showColor = this.showColor;
if (this.autoRefresh) this.schematic.repaint();
});

Clazz.newMeth(C$, ['setShowGrid$Z','setShowGrid'], function (show) {
this.showGrid = show;
this.schematic.showGrid = this.showGrid;
if (this.autoRefresh) this.schematic.repaint();
});

Clazz.newMeth(C$, ['setShowBOnDrag$Z','setShowBOnDrag'], function (show) {
this.schematic.showBOnDrag = show;
});

Clazz.newMeth(C$, ['setShowCurrentArrow$I$Z','setShowCurrentArrow'], function (id, show) {
this.showCurrentArrow = show;
this.schematic.setShowCurrentArrow$I$Z(id, show);
if (this.autoRefresh) this.schematic.repaint();
});

Clazz.newMeth(C$, ['setShowCoordinates$I$Z','setShowCoordinates'], function (id, show) {
if (id == 0 || id == this.schematic.hashCode() ) {
this.schematic.coordDisplay = show;
return true;
}return false;
});

Clazz.newMeth(C$, ['setShowMeter$I$Z','setShowMeter'], function (id, show) {
this.schematic.setShowMeter$I$Z(id, show);
if (this.autoRefresh) this.schematic.repaint();
});

Clazz.newMeth(C$, ['setDragMode$Z','setDragMode'], function (dm) {
this.dragMode = dm;
this.dragBox.setState$Z(this.dragMode);
this.posField.setEnabled$Z(!dm);
this.schematic.setDragMode$Z(dm);
});

Clazz.newMeth(C$, ['setMeterMinMax$D$D','setMeterMinMax'], function (min, max) {
this.schematic.setMeterMinMax$D$D(min, max);
this.graph.setMinMaxY$D$D(min, max);
if (this.autoRefresh) {
this.graph.repaint();
this.schematic.repaint();
}});

Clazz.newMeth(C$, ['setPixPerUnit$I','setPixPerUnit'], function (ppu) {
this.pixPerUnit = ppu;
this.schematic.pixPerUnit = this.pixPerUnit;
});

Clazz.newMeth(C$, ['setShowGraph$Z','setShowGraph'], function (sg) {
if (this.graph.isVisible() == sg ) return;
this.showGraph = sg;
this.schematic.fillApplet = !this.showGraph;
this.graph.setVisible$Z(sg);
this.invalidate();
this.validate();
});

Clazz.newMeth(C$, ['setPosFunction$S','setPosFunction'], function (str) {
var shouldRun = this.clock.isRunning();
this.clock.stopClock();
if (str == null ) str = "";
this.posStr = str;
this.posField.setText$S(this.posStr);
var err = this.schematic.parsePosFunction$S(this.posStr);
if (shouldRun) this.clock.startClock();
 else if (this.autoRefresh) this.schematic.repaint();
return err;
});

Clazz.newMeth(C$, ['setTrajectory$I$S','setTrajectory'], function (id, xStr) {
var t = this.schematic.getThing$I(id);
if (t == null ) return false;
this.schematic.setDefaultCircuit$edu_davidson_display_Thing(t);
return this.setPosFunction$S(xStr);
});

Clazz.newMeth(C$, ['setFieldFunction$S','setFieldFunction'], function (str) {
var shouldRun = this.clock.isRunning();
this.clock.stopClock();
this.fieldStr = str;
this.fieldField.setText$S(this.fieldStr);
this.schematic.parseFieldFunction$S(this.fieldStr);
if (shouldRun) this.clock.startClock();
 else if (this.autoRefresh) this.schematic.repaint();
});

Clazz.newMeth(C$, ['setBScale$D$D','setBScale'], function (min, max) {
this.schematic.setBScale$D$D(min, max);
if (this.autoRefresh) this.schematic.repaint();
});

Clazz.newMeth(C$, ['setMaxTime$D','setMaxTime'], function (tm) {
this.maxTime = tm;
this.clock.setCycle$D$D(0, this.maxTime);
this.graph.setMinMaxX$D$D(0, this.maxTime);
});

Clazz.newMeth(C$, ['setTimeCycle$D','setTimeCycle'], function (max) {
this.setTimeInterval$D$D(0, max);
});

Clazz.newMeth(C$, ['setTimeInterval$D$D','setTimeInterval'], function (min, max) {
this.clock.setCycle$D$D(min, max);
this.schematic.setTime$D(min);
});

Clazz.newMeth(C$, 'setTimeContinuous', function () {
this.clock.setContinuous();
});

Clazz.newMeth(C$, ['setTimeOneShot$D$S','setTimeOneShot'], function (max, msg) {
this.clock.setOneShot$D$D(0, max);
this.stopMessage = msg;
});

Clazz.newMeth(C$, 'stoppingClock', function () {
this.schematic.setMessage$S(this.stopMessage);
});

Clazz.newMeth(C$, ['setFont$I$S$I$I','setFont'], function (id, family, style, size) {
var font = Clazz.new_((I$[33]||$incl$(33)).c$$S$I$I,[family, style, size]);
var t = this.schematic.getThing$I(id);
if (t == null  || font == null  ) return false;
t.setFont$java_awt_Font(font);
if (this.autoRefresh) this.schematic.repaint();
return true;
});

Clazz.newMeth(C$, ['setObjectFont$I$S$I$I','setObjectFont'], function (id, family, style, size) {
return this.setFont$I$S$I$I(id, family, style, size);
});

Clazz.newMeth(C$, ['setFormat$I$S','setFormat'], function (id, fstr) {
var t = this.schematic.getThing$I(id);
if (t == null  && (id == 0 || id == this.schematic.hashCode() ) ) {
return this.schematic.setFormat$S(fstr);
}var result = t.setFormat$S(fstr);
if (this.autoRefresh) this.schematic.repaint();
return result;
});

Clazz.newMeth(C$, ['setDisplayOffset$I$I$I','setDisplayOffset'], function (id, xOff, yOff) {
var t = this.schematic.getThing$I(id);
if (t == null ) return false;
t.setDisplayOff$I$I(xOff, yOff);
if (this.autoRefresh) this.schematic.repaint();
return true;
});

Clazz.newMeth(C$, ['setDragable$I$Z','setDragable'], function (id, canDrag) {
var t = this.schematic.getThing$I(id);
if (t == null ) return false;
t.setDragable$Z(canDrag);
this.schematic.dragMode = canDrag;
return true;
});

Clazz.newMeth(C$, ['setVisibility$I$Z','setVisibility'], function (id, show) {
if (id == this.getClockID()) {
this.schematic.showTime = show;
if (this.autoRefresh) this.schematic.repaint();
return true;
}var t = this.schematic.getThing$I(id);
if (t == null ) return false;
t.setVisible$Z(show);
return true;
});

Clazz.newMeth(C$, ['setAnimationSlave$I$I','setAnimationSlave'], function (masterID, slaveID) {
var master = this.schematic.getThing$I(masterID);
var slave = this.schematic.getThing$I(slaveID);
if (master == null  || slave == null  ) return false;
master.addSlave$edu_davidson_display_Thing(slave);
this.schematic.invalidateOSI();
if (this.autoRefresh) this.schematic.repaint();
return true;
});

Clazz.newMeth(C$, ['setRGB$I$I$I$I','setRGB'], function (id, r, g, b) {
if (id == this.schematic.hashCode()) {
this.schematic.setBackground$java_awt_Color(Clazz.new_((I$[12]||$incl$(12)).c$$I$I$I,[r, g, b]));
return true;
}var t = this.schematic.getThing$I(id);
if (t == null ) return false;
t.setColor$java_awt_Color(Clazz.new_((I$[12]||$incl$(12)).c$$I$I$I,[r, g, b]));
if (this.autoRefresh) this.schematic.repaint();
return true;
});

Clazz.newMeth(C$, 'forwardBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.clock.doStep();
});

Clazz.newMeth(C$, 'posField_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.schematic.parsePosFunction$S(this.posField.getText())) this.posField.setBackground$java_awt_Color((I$[12]||$incl$(12)).white);
 else this.posField.setBackground$java_awt_Color((I$[12]||$incl$(12)).red);
});

Clazz.newMeth(C$, 'fieldField_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.schematic.parseFieldFunction$S(this.fieldField.getText())) {
this.fieldField.setBackground$java_awt_Color((I$[12]||$incl$(12)).white);
this.schematic.repaint();
} else this.fieldField.setBackground$java_awt_Color((I$[12]||$incl$(12)).red);
});

Clazz.newMeth(C$, 'dragBox_itemStateChanged$java_awt_event_ItemEvent', function (e) {
this.schematic.setDragMode$Z(this.dragBox.getState());
this.reset();
this.fieldField_actionPerformed$java_awt_event_ActionEvent(Clazz.new_((I$[34]||$incl$(34)).c$$O$I$S,[this, 0, null]));
this.posField_actionPerformed$java_awt_event_ActionEvent(Clazz.new_((I$[34]||$incl$(34)).c$$O$I$S,[this, 0, null]));
this.posField.setEnabled$Z(!this.dragBox.getState());
});
})();
//Created 2018-02-25 19:20:20
