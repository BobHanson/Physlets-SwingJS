(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "Ameter", null, 'circuitsimulator.Resistor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$I$S', function (circuit, v, d, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$D$I$I$I$S.apply(this, [circuit, v, d, r, c, t]);
C$.$init$.apply(this);
if (this.value == 0.0 ) this.value=0.1;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit', function (circuit) {
C$.superclazz.c$$circuitsimulator_Circuit.apply(this, [circuit]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'valueStr$', function () {
return "";
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:47 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
