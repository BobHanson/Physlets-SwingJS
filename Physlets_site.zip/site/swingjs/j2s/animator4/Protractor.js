(function(){var P$=Clazz.newPackage("animator4"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Protractor", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.insideTip1 = false;
this.insideTip2 = false;
this.angle1 = 0;
this.angle2 = 0;
this.spot = 0;
this.fixedBase = false;
this.fixedlength = false;
this.len = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.insideTip1 = false;
this.insideTip2 = false;
this.spot = 4;
this.fixedBase = false;
this.fixedlength = false;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$D$D$S$S', function (o, s, theta, theta0, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "theta", "theta0"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
this.s = s;
this.len = s;
this.angle1 = theta0;
this.angle2 = theta + theta0;
this.color = (I$[1]||$incl$(1)).red;
this.resizable = true;
}, 1);

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
if (this.insideTip1) {
var horz = x - this.vars[1];
var vert = y - this.vars[2];
if (horz == 0  && vert == 0  ) return;
this.angle1 = Math.atan2(vert, horz);
return;
}if (this.insideTip2) {
var horz = x - this.vars[1];
var vert = y - this.vars[2];
if (!this.fixedlength) {
if (horz == 0  && vert == 0  ) return;
this.len = ((this.canvas.pixPerUnit * Math.sqrt(horz * horz + vert * vert))|0);
this.len = Math.max(this.len, this.spot);
}if (horz == 0  && vert == 0  ) return;
this.angle2 = Math.atan2(vert, horz);
return;
}C$.superclazz.prototype.setXY$D$D.apply(this, [x, y]);
});

Clazz.newMeth(C$, 'setProperties$I$D$D', function (sid, alpha, beta) {
if (sid == 3) {
this.angle1 = alpha;
this.angle2 = alpha + beta;
} else if (sid == 4) {
this.insideTip1 = true;
this.insideTip2 = false;
this.setXY$D$D(alpha, beta);
this.insideTip1 = false;
} else if (sid == 5) {
this.insideTip1 = false;
this.insideTip2 = true;
this.setXY$D$D(alpha, beta);
this.insideTip2 = false;
}});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
this.insideTip1 = false;
this.insideTip2 = false;
var ptX = this.canvas.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.vars[2]) - this.yDisplayOff;
if (!this.noDrag && (Math.abs(xPix - ptX) < this.spot) && (Math.abs(yPix - ptY) < this.spot)  ) return true;
if (this.resizable && !this.fixedBase && (Math.abs(xPix - ptX - this.s * Math.cos(this.angle1) ) < this.spot ) && (Math.abs(yPix - ptY + this.s * Math.sin(this.angle1)) < this.spot )  ) {
this.insideTip1 = true;
return true;
}if (this.resizable && (Math.abs(xPix - ptX - this.len * Math.cos(this.angle2) ) < this.spot ) && (Math.abs(yPix - ptY + this.len * Math.sin(this.angle2)) < this.spot )  ) {
this.insideTip2 = true;
return true;
}return false;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX = Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
var x2 = ((ptX + this.s * Math.cos(this.angle1))|0);
var y2 = ((ptY - this.s * Math.sin(this.angle1))|0);
osg.drawLine$I$I$I$I(ptX, ptY, x2, y2);
x2 = ((ptX + this.len * Math.cos(this.angle2))|0);
y2 = ((ptY - this.len * Math.sin(this.angle2))|0);
osg.setColor$java_awt_Color(this.color);
osg.drawLine$I$I$I$I(ptX, ptY, x2, y2);
x2 = ((ptX + this.s * Math.cos(this.angle2))|0);
y2 = ((ptY - this.s * Math.sin(this.angle2))|0);
var begin = ((180 * this.angle1 / 3.141592653589793)|0);
var arc = this.angle2 - this.angle1;
if (arc > 3.141592653589793 ) arc = arc - 6.283185307179586;
 else if (arc < -3.141592653589793 ) arc = arc + 6.283185307179586;
var arcsize = Math.min(this.s, this.len);
osg.drawArc$I$I$I$I$I$I(ptX - (arcsize/2|0), ptY - (arcsize/2|0), arcsize, arcsize, begin, ((180 * arc / 3.141592653589793)|0));
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
if (!this.noDrag) {
if (this.color !== (I$[1]||$incl$(1)).lightGray ) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).lightGray);
 else this.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
osg.fillOval$I$I$I$I(ptX - 2, ptY - 2, 5, 5);
osg.setColor$java_awt_Color(this.color);
osg.drawOval$I$I$I$I(ptX - 2, ptY - 2, 5, 5);
}if (this.resizable) {
if (this.color !== (I$[1]||$incl$(1)).lightGray ) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).lightGray);
 else this.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
x2 = ((ptX + this.len * Math.cos(this.angle2))|0);
y2 = ((ptY - this.len * Math.sin(this.angle2))|0);
osg.fillOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
osg.setColor$java_awt_Color(this.color);
osg.drawOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
}if (this.resizable && !this.fixedBase ) {
if (this.color !== (I$[1]||$incl$(1)).lightGray ) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).lightGray);
 else this.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
x2 = ((ptX + this.s * Math.cos(this.angle1))|0);
y2 = ((ptY - this.s * Math.sin(this.angle1))|0);
osg.fillOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
osg.setColor$java_awt_Color(this.color);
osg.drawOval$I$I$I$I(x2 - 2, y2 - 2, 5, 5);
}if (this.label != null ) {
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
var f = osg.getFont();
osg.setFont$java_awt_Font(this.font);
osg.drawString$S$I$I(this.label, ptX, ptY);
osg.setFont$java_awt_Font(f);
}});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.vars[0];
this.ds[0][1] = this.vars[1];
this.ds[0][2] = this.vars[2];
var arc = this.angle2 - this.angle1;
if (arc > 3.141592653589793 ) arc = arc - 6.283185307179586;
 else if (arc < -3.141592653589793 ) arc = arc + 6.283185307179586;
this.ds[0][3] = arc;
this.ds[0][4] = this.angle1;
return this.ds;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:14
