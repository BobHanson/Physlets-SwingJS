(function(){var P$=Clazz.newPackage("sun.swing"),I$=[];
var C$=Clazz.newInterface(P$, "MenuItemCheckIconFactory");
})();
//Created 2018-05-24 08:47:36
