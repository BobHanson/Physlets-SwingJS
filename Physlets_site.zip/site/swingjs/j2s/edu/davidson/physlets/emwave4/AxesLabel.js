(function(){var P$=Clazz.newPackage("edu.davidson.physlets.emwave4"),I$=[[0,'java.awt.Font']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "AxesLabel", null, 'edu.davidson.physlets.emwave4.Axis3D');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$D$java_awt_Color', function (x, y, z, s, clr) {
C$.superclazz.c$$I$I$I$D$java_awt_Color.apply(this, [x, y, z, s, clr]);
C$.$init$.apply(this);
this.figType="text";
}, 1);

Clazz.newMeth(C$, 'drawFigure$java_awt_Graphics$DAA', function (g, trans) {
this.reSetColor$java_awt_Graphics(g);
this.setOrigin$java_awt_Graphics(g);
g.setFont$java_awt_Font(Clazz.new_($I$(1).c$$S$I$I,["SansSerif", 1, 14]));
g.drawString$S$I$I("x", (Math.round(trans[0][0] * this.getPtsValue$I$I(1, 0) + trans[0][1] * this.getPtsValue$I$I(1, 1) + trans[0][2] * this.getPtsValue$I$I(1, 2))|0), (Math.round(trans[1][0] * this.getPtsValue$I$I(1, 0) + trans[1][1] * this.getPtsValue$I$I(1, 1) + trans[1][2] * this.getPtsValue$I$I(1, 2))|0));
g.drawString$S$I$I("y", (Math.round(trans[0][0] * this.getPtsValue$I$I(3, 0) + trans[0][1] * this.getPtsValue$I$I(3, 1) + trans[0][2] * this.getPtsValue$I$I(3, 2))|0), (Math.round(trans[1][0] * this.getPtsValue$I$I(3, 0) + trans[1][1] * this.getPtsValue$I$I(3, 1) + trans[1][2] * this.getPtsValue$I$I(3, 2))|0));
g.drawString$S$I$I("z", (Math.round(trans[0][0] * this.getPtsValue$I$I(5, 0) + trans[0][1] * this.getPtsValue$I$I(5, 1) + trans[0][2] * this.getPtsValue$I$I(5, 2))|0), (Math.round(trans[1][0] * this.getPtsValue$I$I(5, 0) + trans[1][1] * this.getPtsValue$I$I(5, 1) + trans[1][2] * this.getPtsValue$I$I(5, 2))|0));
this.resetOrigin$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:04 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
