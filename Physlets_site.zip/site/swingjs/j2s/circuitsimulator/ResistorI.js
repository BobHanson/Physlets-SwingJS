(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "ResistorI", null, 'circuitsimulator.Resistor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$S', function (circuit, v, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$D$I$I$S.apply(this, [circuit, v, r, c, t]);
C$.$init$.apply(this);
this.cirim=circuit.getImage$java_net_URL$S(circuit.base$(), "resistor" + this.to + ".gif" );
this.cirim=Clazz.load('edu.davidson.graphics.Util').getImage$S$java_applet_Applet(circuit.imagedir + this.getMyName$() + this.to + ".gif" , circuit);
this.leftlinear=false;
}, 1);

Clazz.newMeth(C$, 'impedance$', function () {
return Math.abs(this.value * this.getI$());
});

Clazz.newMeth(C$, 'valueStr$', function () {
return this.format.form$D(this.value) + "*I";
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",r=" + Double.toString$D(this.value);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:16 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
