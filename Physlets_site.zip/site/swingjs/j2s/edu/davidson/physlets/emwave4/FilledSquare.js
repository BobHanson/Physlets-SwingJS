(function(){var P$=Clazz.newPackage("edu.davidson.physlets.emwave4"),I$=[['java.awt.Polygon']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FilledSquare", null, 'edu.davidson.physlets.emwave4.Figure');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D$java_awt_Color', function (z1, s, clr) {
Clazz.super_(C$, this,1);
this.numLines = 4;
this.pts = Clazz.array(Double.TYPE, [4, 3]);
this.c = clr;
this.pts[0][0] = -s / 2;
this.pts[0][1] = -s / 2;
this.pts[0][2] = z1;
this.pts[1][0] = -s / 2;
this.pts[1][1] = s / 2;
this.pts[1][2] = z1;
this.pts[2][0] = s / 2;
this.pts[2][1] = s / 2;
this.pts[2][2] = z1;
this.pts[3][0] = s / 2;
this.pts[3][1] = -s / 2;
this.pts[3][2] = z1;
}, 1);

Clazz.newMeth(C$, 'drawFigure$java_awt_Graphics$DAA', function (g, trans) {
this.reSetColor$java_awt_Graphics(g);
this.setOrigin$java_awt_Graphics(g);
var p = Clazz.new_((I$[1]||$incl$(1)));
p.addPoint$I$I((Math.round(trans[0][0] * this.getPtsValue$I$I(0, 0) + trans[0][1] * this.getPtsValue$I$I(0, 1) + trans[0][2] * this.getPtsValue$I$I(0, 2))|0), (Math.round(trans[1][0] * this.getPtsValue$I$I(0, 0) + trans[1][1] * this.getPtsValue$I$I(0, 1) + trans[1][2] * this.getPtsValue$I$I(0, 2))|0));
p.addPoint$I$I((Math.round(trans[0][0] * this.getPtsValue$I$I(1, 0) + trans[0][1] * this.getPtsValue$I$I(1, 1) + trans[0][2] * this.getPtsValue$I$I(1, 2))|0), (Math.round(trans[1][0] * this.getPtsValue$I$I(1, 0) + trans[1][1] * this.getPtsValue$I$I(1, 1) + trans[1][2] * this.getPtsValue$I$I(1, 2))|0));
p.addPoint$I$I((Math.round(trans[0][0] * this.getPtsValue$I$I(2, 0) + trans[0][1] * this.getPtsValue$I$I(2, 1) + trans[0][2] * this.getPtsValue$I$I(2, 2))|0), (Math.round(trans[1][0] * this.getPtsValue$I$I(2, 0) + trans[1][1] * this.getPtsValue$I$I(2, 1) + trans[1][2] * this.getPtsValue$I$I(2, 2))|0));
p.addPoint$I$I((Math.round(trans[0][0] * this.getPtsValue$I$I(3, 0) + trans[0][1] * this.getPtsValue$I$I(3, 1) + trans[0][2] * this.getPtsValue$I$I(3, 2))|0), (Math.round(trans[1][0] * this.getPtsValue$I$I(3, 0) + trans[1][1] * this.getPtsValue$I$I(3, 1) + trans[1][2] * this.getPtsValue$I$I(3, 2))|0));
g.fillPolygon$java_awt_Polygon(p);
this.resetOrigin$java_awt_Graphics(g);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:37:12
