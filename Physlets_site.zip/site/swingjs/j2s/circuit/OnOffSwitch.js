(function(){var P$=Clazz.newPackage("circuit"),I$=[['java.awt.Color','circuit.Common']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "OnOffSwitch", null, 'circuit.Part');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I', function (o, c, i1, j1, i2, j2) {
C$.superclazz.c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I.apply(this, [o, c, i1, j1, i2, j2]);
C$.$init$.apply(this);
this.label = "";
this.voltRMS = 0;
this.switchOn = false;
this.showC = false;
this.showV = false;
this.showR = false;
this.showZ = false;
this.showL = false;
}, 1);

Clazz.newMeth(C$, 'drawLabel$java_awt_Graphics$I$I$I$I', function (g, x, y, xOff, yOff) {
if (this.label == null ) return;
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
if (this.i1 == this.i2) g.drawString$S$I$I(this.label, x - 4, y + 15);
 else g.drawString$S$I$I(this.label, x - 10, y);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'drawSymbol$java_awt_Graphics$I$I$I$I$I', function (g, x1, y1, x2, y2, s) {
g.setColor$java_awt_Color(this.color);
var x = x2 - x1;
var y = -(y2 - y1);
var h = Math.sqrt(x * x + y * y);
if (h < 2 ) return;
var w = (h / 2.0 - 6);
var base_x1 = ((x1 + (x * w) / h)|0);
var base_y1 = ((y1 - (y * w) / h)|0);
var base_x2 = ((x2 - (x * w) / h)|0);
var base_y2 = ((y2 + (y * w) / h)|0);
g.drawLine$I$I$I$I(x1, y1, base_x1, base_y1);
g.drawLine$I$I$I$I(x2, y2, base_x2, base_y2);
w = s / 8.0;
var u = (w * x / h);
var v = -(w * y / h);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
if (this.switchOn) {
g.drawLine$I$I$I$I((base_x1), (base_y1), (base_x2), (base_y2));
if (this.j1 == this.j2) {
g.drawLine$I$I$I$I((base_x1 - 1), (base_y1), (base_x2 - 1), (base_y2));
g.drawLine$I$I$I$I((base_x1 + 1), (base_y1), (base_x2 + 1), (base_y2));
} else {
g.drawLine$I$I$I$I((base_x1), (base_y1 - 1), (base_x2), (base_y2 - 1));
g.drawLine$I$I$I$I((base_x1), (base_y1 + 1), (base_x2), (base_y2 + 1));
}g.drawLine$I$I$I$I((base_x1), (base_y1), ((base_x2 + v)|0), ((base_y2 - u)|0));
} else {
g.drawLine$I$I$I$I((base_x1), (base_y1), ((base_x2 + v)|0), ((base_y2 - u)|0));
if (this.j1 == this.j2) {
g.drawLine$I$I$I$I((base_x1 - 1), (base_y1), ((base_x2 + v - 1)|0), ((base_y2 - u)|0));
g.drawLine$I$I$I$I((base_x1 + 1), (base_y1), ((base_x2 + v + 1 )|0), ((base_y2 - u)|0));
} else {
g.drawLine$I$I$I$I((base_x1), (base_y1 - 1), ((base_x2 + v)|0), ((base_y2 - u - 1 )|0));
g.drawLine$I$I$I$I((base_x1), (base_y1 + 1), ((base_x2 + v)|0), ((base_y2 - u + 1)|0));
}}});

Clazz.newMeth(C$, 'getHint', function () {
if (this.customHint != null ) return this.customHint;
if (this.switchOn) return (I$[2]||$incl$(2)).SWITCH_ON;
 else return (I$[2]||$incl$(2)).SWITCH_OFF;
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:36:45
