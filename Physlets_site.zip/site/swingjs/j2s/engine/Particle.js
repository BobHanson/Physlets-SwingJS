(function(){var P$=Clazz.newPackage("engine"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Particle", null, 'engine.Point3D');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.rx = 0;
this.ry = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.x = 0.0;
this.y = 0.0;
this.z = 0.0;
this.mode = 0;
this.col = (I$[1]||$incl$(1)).black;
this.rx = 5.0;
this.ry = 5.0;
this.paintMode = 0;
}, 1);

Clazz.newMeth(C$, 'showParticle$java_awt_Graphics$D', function (g, height) {
var sizex;
var sizey;
sizex = ((this.rx * height)|0);
sizey = ((this.ry * height)|0);
g.setColor$java_awt_Color(this.col);
switch (this.mode) {
case 0:
g.fillOval$I$I$I$I(((this.pa - sizex)|0), ((this.pb - sizey)|0), (2 * sizex), (2 * sizey));
break;
case 1:
g.drawOval$I$I$I$I(((this.pa - sizex)|0), ((this.pb - sizey)|0), (2 * sizex), (2 * sizey));
break;
case 2:
g.fillRect$I$I$I$I(((this.pa - sizex)|0), ((this.pb - sizey)|0), (2 * sizex), (2 * sizey));
break;
case 3:
g.drawRect$I$I$I$I(((this.pa - sizex)|0), ((this.pb - sizey)|0), (2 * sizex), (2 * sizey));
break;
case 10:
g.fillOval$I$I$I$I(((this.pa)|0), ((this.pb - 2 * height)|0), (2 * sizex), (2 * sizey));
break;
case 11:
g.drawOval$I$I$I$I(((this.pa)|0), ((this.pb - 2 * sizey)|0), (2 * sizex), (2 * sizey));
break;
case 12:
g.fillRect$I$I$I$I(((this.pa)|0), ((this.pb - 2 * sizey)|0), (2 * sizex), (2 * sizey));
break;
case 13:
g.drawRect$I$I$I$I(((this.pa)|0), ((this.pb - 2 * sizey)|0), (2 * sizex), (2 * sizey));
break;
}
});
})();
//Created 2018-03-16 05:18:52
