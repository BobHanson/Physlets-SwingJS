(function(){var P$=Clazz.newPackage("dynamics"),I$=[[0,'java.awt.Panel','java.awt.Label','java.awt.Choice','java.awt.Button','dynamics.SFront','edu.davidson.graphics.Util','javax.swing.Timer','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Airplane", null, 'java.applet.Applet', 'Runnable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.yOffset=0;
this.time=0;
this.ts=0;
this.area=null;
this.bgImage=null;
this.fgImage=null;
this.gb=null;
this.g=null;
this.bgColor=null;
this.va=0;
this.vs=0;
this.cta=0;
this.count=0;
this.n=0;
this.d=0;
this.id=0;
this.S=null;
this.ear=null;
this.plane=null;
this.cb=null;
this.label=null;
this.Start=null;
this.Reset=null;
this.rts=null;
this.STR=null;
this.earw=0;
this.earh=0;
this.planew=0;
this.planeh=0;
this.xx=0;
this.yy=0;
this.idx=0;
this.running=false;
this.startTime=0;
this.lastTime=0;
this.delay=0;
this.delta=0;
this.cst=0;
this.rightClick=false;
this.dragging=false;
this.fm=null;
this.chy=0;
this.xa=0;
this.ya=0;
this.xm=0;
this.ym=0;
this.y1=0;
this.size=0;
this.size2=0;
this.timer=null;
this.imagedir=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.imagedir="./";
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
this.setSize$I$I(700, 600);
this.setBackground$java_awt_Color(this.bgColor);
for (var i=0; i < this.STR.length; ++i) {
if ((this.rts=this.getParameter$S(this.STR[i])) != null ) {
this.STR[i]= String.instantialize(this.rts);
}}
var panel=Clazz.new_(Clazz.load('java.awt.Panel'));
panel.add$java_awt_Component(Clazz.new_(Clazz.load('java.awt.Label').c$$S,[this.STR[0]]));
panel.add$java_awt_Component(this.cb=Clazz.new_(Clazz.load('java.awt.Choice')));
for (var j=0; j < this.label.length; ++j) {
this.cb.addItem$S(this.label[j]);
}
panel.add$java_awt_Component(Clazz.new_(Clazz.load('java.awt.Button').c$$S,[this.Reset=this.STR[1]]));
panel.add$java_awt_Component(Clazz.new_($I$(4).c$$S,[this.Start=this.STR[2]]));
this.cb.select$I(4);
this.add$S$java_awt_Component("North", panel);
this.area=this.size$();
var area=this.area;
area.height-=this.yOffset;
this.count=(this.area.width/5|0);
this.S=Clazz.array(Clazz.load('dynamics.SFront'), [this.count]);
for (var k=0; k < this.count; ++k) {
this.S[k]=Clazz.new_($I$(5));
}
var s=this.getParameter$S("imagedir");
if (s == null ) {
this.imagedir="./";
} else {
this.imagedir += s + "/";
}this.loadImage$();
this.reset$Z(true);
});

Clazz.newMeth(C$, 'loadImage$', function () {
this.plane=Clazz.load('edu.davidson.graphics.Util').getImage$S$java_applet_Applet(this.imagedir + "airplane.jpg", this);
this.ear=$I$(6).getImage$S$java_applet_Applet(this.imagedir + "ear.jpg", this);
if (this.plane != null ) {
this.planew=this.plane.getWidth$java_awt_image_ImageObserver(this);
this.planeh=(this.plane.getHeight$java_awt_image_ImageObserver(this)/2|0) + 5;
}if (this.ear != null ) {
this.earw=(this.ear.getWidth$java_awt_image_ImageObserver(this)/2|0);
this.earh=(this.ear.getHeight$java_awt_image_ImageObserver(this)/2|0);
}});

Clazz.newMeth(C$, ['action$java_awt_Event$O','action'], function (event, o) {
if (Clazz.instanceOf(event.target, "java.awt.Button")) {
var s=o;
if (s.equals$O(this.Reset)) {
this.reset$Z(true);
} else if (s.equals$O(this.Start)) {
this.reset$Z(true);
this.running=true;
this.start$();
this.timer.start$();
this.running=true;
}}return true;
});

Clazz.newMeth(C$, ['reset$Z','reset'], function (b) {
this.xa=0.0;
this.ya=this.y1;
this.id=0;
this.n=0;
this.idx=0;
this.va=this.vs * (this.cb.getSelectedIndex$() + 1) / 2.0;
this.cta=Math.asin(this.vs / this.va);
this.clear$();
});

Clazz.newMeth(C$, 'd2String$D', function (n) {
var s=String.valueOf$F((((n * 100.0)|0) / 100.0));
if (s.indexOf$S(".") == -1) {
s += ".0";
}return s;
});

Clazz.newMeth(C$, ['start$','start'], function () {
this.delta=200;
if (this.timer == null ) this.timer=Clazz.new_(Clazz.load('javax.swing.Timer').c$$I$java_awt_event_ActionListener,[((this.delta|0)/2|0), ((P$.Airplane$1||
(function(){var C$=Clazz.newClass(P$, "Airplane$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (ae) {
this.b$['dynamics.Airplane'].run$.apply(this.b$['dynamics.Airplane'], []);
});
})()
), Clazz.new_(P$.Airplane$1.$init$, [this, null]))]);
this.timer.setRepeats$Z(true);
});

Clazz.newMeth(C$, ['stop$','stop'], function () {
this.timer.stop$();
this.running=false;
});

Clazz.newMeth(C$, ['run$','run'], function () {
if (this.running) {
this.advanced$D(this.delta / 1000.0);
}});

Clazz.newMeth(C$, 'advanced$D', function (n) {
this.xa += this.va * n;
if (this.xa < this.area.width  && this.xa / this.d > this.id  ) {
this.id=((this.xa / this.d)|0) + 1;
this.cst=this.vs / Math.sqrt((this.xm - this.xa) * (this.xm - this.xa) + (this.ym - this.ya) * (this.ym - this.ya));
this.S[this.n].setup$D$D$D$D(this.xa, this.ya, this.cst * (this.xm - this.xa), this.cst * (this.ym - this.ya));
this.gb.fillOval$I$I$I$I((this.xa|0) - this.size, (this.ya|0) - this.size, this.size2, this.size2);
++this.n;
if (this.n == this.count) {
this.stop$();
}}for (var i=0; i < this.n; ++i) {
this.S[i].moving$D(n);
}
this.repaint$();
});

Clazz.newMeth(C$, ['mouseDown$java_awt_Event$I$I','mouseDown'], function (event, n, n2) {
if ((n2-=this.yOffset) < 0) {
return false;
}if (event.modifiers == 4) {
this.rightClick=true;
this.running=!this.running;
} else if (n > this.xm - this.earw && n2 > this.ym - this.earh  && n < this.xm + this.earw  && n2 < this.ym + this.earh ) {
this.dragging=true;
}return true;
});

Clazz.newMeth(C$, ['mouseDrag$java_awt_Event$I$I','mouseDrag'], function (event, xm, ym) {
if ((ym-=this.yOffset) < 0) {
return false;
}if (this.dragging) {
this.xm=xm;
this.ym=ym;
this.reset$Z(true);
}return true;
});

Clazz.newMeth(C$, ['mouseUp$java_awt_Event$I$I','mouseUp'], function (event, n, n2) {
if ((n2-=this.yOffset) < 0) {
return false;
}if (this.rightClick) {
this.rightClick=false;
}this.dragging=false;
return true;
});

Clazz.newMeth(C$, 'clear$', function () {
if (this.g == null ) {
this.bgImage=this.createImage$I$I(this.area.width, this.area.height);
this.gb=this.bgImage.getGraphics$();
this.fgImage=this.createImage$I$I(this.area.width, this.area.height);
this.g=this.fgImage.getGraphics$();
this.fm=this.gb.getFontMetrics$();
this.chy=this.fm.getHeight$();
this.xm=(this.area.width/2|0);
this.ym=this.area.height - this.y1;
}this.gb.setColor$java_awt_Color(this.bgColor);
this.gb.fillRect$I$I$I$I(0, 0, this.area.width, this.area.height);
this.gb.setColor$java_awt_Color(Clazz.load('java.awt.Color').black);
this.gb.drawRect$I$I$I$I(0, 0, this.area.width - 1, this.area.height - 1);
if (this.ear != null ) this.gb.drawImage$java_awt_Image$I$I$java_awt_Color$java_awt_image_ImageObserver(this.ear, this.xm - this.earw, this.ym - this.earh, $I$(8).white, this);
this.gb.setColor$java_awt_Color($I$(8).white);
this.repaint$();
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
this.updateScreen$java_awt_Graphics(g);
});

Clazz.newMeth(C$, ['updateScreen$java_awt_Graphics','updateScreen'], function (graphics) {
this.g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.bgImage, 0, 0, this);
for (var i=0; i < this.n; ++i) {
if (i % 2 == 0) {
this.g.setColor$java_awt_Color($I$(8).green);
} else {
this.g.setColor$java_awt_Color($I$(8).yellow);
}this.g.fillOval$I$I$I$I(this.xx=(this.S[i].x|0) - this.size, this.yy=(this.S[i].y|0) - this.size, this.size2, this.size2);
if ((this.S[i].y|0) >= this.ym) {
this.g.setColor$java_awt_Color($I$(8).blue);
if (this.S[i].on) {
this.gb.setColor$java_awt_Color($I$(8).black);
this.gb.drawString$S$I$I(String.valueOf$I(++this.idx), (this.S[i].x0|0), (this.S[i].y0|0) + this.chy * (this.idx % 2));
this.S[i].on=false;
if (this.idx == this.n) {
this.stop$();
} else if (this.idx == 1 && this.va > this.vs  ) {
this.running=!this.running;
}}}this.g.drawLine$I$I$I$I((this.S[i].x|0), (this.S[i].y|0), (this.S[i].x0|0), (this.S[i].y0|0));
}
if (this.plane != null ) this.g.drawImage$java_awt_Image$I$I$java_awt_Color$java_awt_image_ImageObserver(this.plane, this.xx=(this.xa|0) - this.planew, this.yy=(this.ya|0) - this.planeh, $I$(8).lightGray, this);
this.g.setColor$java_awt_Color($I$(8).black);
if (this.va > this.vs ) {
this.g.drawLine$I$I$I$I(this.xx=(this.xa|0), this.yy=(this.ya|0), ((this.xa - (this.area.height - this.ya) / Math.tan(this.cta))|0), this.area.height);
this.g.drawLine$I$I$I$I(this.xx, this.yy, ((this.xa - this.ya / Math.tan(this.cta))|0), 0);
}graphics.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.fgImage, 0, this.yOffset, this);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.yOffset=40;
this.time=0.0;
this.ts=0.0;
this.bgColor=$I$(8).lightGray;
this.va=250.0;
this.vs=100.0;
this.d=15;
this.label=Clazz.array(String, -1, ["0.5", "1.0", "1.5", "2.0", "2.5", "3.0", "3.5", "4.0"]);
this.STR=Clazz.array(String, -1, ["speedRatioLabel", "Reset", "Start"]);
this.running=false;
this.startTime=0;
this.delay=50;
this.rightClick=false;
this.dragging=false;
this.y1=30;
this.size=2;
this.size2=2 * this.size;
}, 1);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:12 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
