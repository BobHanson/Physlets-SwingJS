(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newInterface(P$, "SDifferentiable");
})();
//Created 2018-02-25 19:20:27
