(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[];
var C$=Clazz.newClass(P$, "BorderStyle");
C$.NONE = null;
C$.RAISED = null;
C$.INSET = null;
C$.ETCHED = null;
C$.SOLID = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.NONE = Clazz.new_(C$);
C$.RAISED = Clazz.new_(C$);
C$.INSET = Clazz.new_(C$);
C$.ETCHED = Clazz.new_(C$);
C$.SOLID = Clazz.new_(C$);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'toString', function () {
var s =  String.instantialize();
if (this === C$.NONE ) s = this.getClass().getName() + "=NONE";
 else if (this === C$.RAISED ) s = this.getClass().getName() + "=RAISED";
 else if (this === C$.INSET ) s = this.getClass().getName() + "=INSET";
 else if (this === C$.ETCHED ) s = this.getClass().getName() + "=ETCHED";
 else if (this === C$.SOLID ) s = this.getClass().getName() + "=SOLID";
return s;
});

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-02-24 16:21:12
