(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['java.awt.Font','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CaptionThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.text = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$S$D$D', function (owner, sc, txt, x, y) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, x, y]);
C$.$init$.apply(this);
this.yDisplayOff=-25;
this.font=Clazz.new_((I$[1]||$incl$(1)).c$$S$I$I,["Helvetica", 1, 14]);
this.text=txt;
this.applet=owner;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var f = g.getFont();
g.setFont$java_awt_Font(this.font);
g.setColor$java_awt_Color(this.color);
var fm = g.getFontMetrics$java_awt_Font(this.font);
g.drawString$S$I$I(this.text, ((this.canvas.getPixWidth() - fm.stringWidth$S(this.text))/2|0) + this.xDisplayOff, -this.yDisplayOff);
g.setColor$java_awt_Color((I$[2]||$incl$(2)).black);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-23 12:59:45 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
