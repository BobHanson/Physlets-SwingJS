function hideshow(id){
	if (!document.getElementById) return;
	if (document.getElementById(id).style.display=="none"){
		document.getElementById(id).style.display="";
		if(document.getElementById('img'+id)) document.getElementById('img'+id).src="/services/images/workflow/menuclose.gif";
	} else {
		document.getElementById(id).style.display="none";
		if(document.getElementById('img'+id)) document.getElementById('img'+id).src="/services/images/workflow/menuopen.gif";
	}
}
function hide(id){
	if (!document.getElementById) return;
	if (document.getElementById(id).style.display==""){
		document.getElementById(id).style.display="none";
		if(document.getElementById('img'+id)) document.getElementById('img'+id).src="/services/images/workflow/menuopen.gif";
	}
}
function show(id){
	if (!document.getElementById) return;
	if (document.getElementById(id).style.display=="none"){
		document.getElementById(id).style.display="";
		if(document.getElementById('img'+id)) document.getElementById('img'+id).src="/services/images/workflow/menuclose.gif";
	}
}

