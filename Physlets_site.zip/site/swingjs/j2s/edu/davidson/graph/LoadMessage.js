(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['java.util.Vector','java.awt.Color','java.awt.Rectangle','edu.davidson.graph.DataSet','edu.davidson.graph.Axis','edu.davidson.graph.LoadMessage','java.awt.Font','java.awt.Dimension']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "LoadMessage", null, 'Thread');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.g2d = null;
this.message = null;
this.newmessage = null;
this.visible = 0;
this.invisible = 0;
this.foreground = null;
this.lg = null;
this.f = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.message = "Loading Data ... Please Wait!";
this.newmessage = null;
this.visible = 500;
this.invisible = 200;
this.foreground = (I$[2]||$incl$(2)).red;
this.lg = null;
this.f = null;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_graph_Graph2D', function (g2d) {
Clazz.super_(C$, this,1);
this.g2d = g2d;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_graph_Graph2D$S', function (g2d, s) {
C$.c$$edu_davidson_graph_Graph2D.apply(this, [g2d]);
this.message = s;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_graph_Graph2D$S$J$J', function (g, s, visible, invisible) {
C$.c$$edu_davidson_graph_Graph2D$S.apply(this, [g, s]);
this.visible = visible;
this.invisible = invisible;
}, 1);

Clazz.newMeth(C$, 'begin', function () {
this.g2d.clearAll = false;
this.g2d.$paintAll = false;
C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'end', function () {
C$.superclazz.prototype.stop.apply(this, []);
this.g2d.clearAll = true;
this.g2d.$paintAll = true;
if (this.lg != null ) this.lg.dispose();
this.g2d.repaint();
});

Clazz.newMeth(C$, 'run', function () {
var draw = true;
var fm;
var r;
var sw = 0;
var sa = 0;
var x = 0;
var y = 0;
this.setPriority$I(1);
while (true){
if (this.newmessage != null  && draw ) {
this.message = this.newmessage;
this.newmessage = null;
}if (this.lg == null ) {
this.lg = this.g2d.getGraphics();
if (this.lg != null ) this.lg = this.lg.create();
}if (this.lg != null ) {
if (this.f != null ) this.lg.setFont$java_awt_Font(this.f);
fm = this.lg.getFontMetrics$java_awt_Font(this.lg.getFont());
sw = fm.stringWidth$S(this.message);
sa = fm.getAscent();
} else {
draw = false;
}if (draw) {
this.lg.setColor$java_awt_Color(this.foreground);
r = this.g2d.getBounds();
x = r.x + ((r.width - sw)/2|0);
y = r.y + ((r.height + sa)/2|0);
this.lg.drawString$S$I$I(this.message, x, y);
this.g2d.repaint();
try {
Thread.sleep$J(this.visible);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
} else {
if (this.lg != null ) {
this.lg.setColor$java_awt_Color(this.g2d.getBackground());
this.lg.drawString$S$I$I(this.message, x, y);
this.g2d.repaint();
}try {
Thread.sleep$J(this.invisible);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
}draw = !draw;
if (this.lg != null ) this.lg.dispose();
}
});

Clazz.newMeth(C$, 'setFont$java_awt_Font', function (f) {
this.f = f;
});

Clazz.newMeth(C$, 'setForeground$java_awt_Color', function (c) {
if (c == null ) return;
this.foreground = c;
});

Clazz.newMeth(C$, 'setMessage$S', function (s) {
if (s == null ) return;
this.newmessage = s;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:07:15
