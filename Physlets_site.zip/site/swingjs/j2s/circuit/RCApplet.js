(function(){var P$=Clazz.newPackage("circuit"),I$=[['java.awt.Color','edu.davidson.graphics.EtchedBorder','edu.davidson.display.SSlider','edu.davidson.display.SNumber','circuit.Circuit','edu.davidson.graphics.Box','circuit.Common',['circuit.RCApplet','.RCGraph'],'java.awt.BorderLayout','java.awt.Panel','java.awt.Label','java.awt.Checkbox','Boolean','java.awt.Dimension','circuit.RCApplet_fNumber_actionAdapter','circuit.RCApplet_fSlider_adjustmentAdapter','circuit.RCApplet_checkbox1_itemAdapter','java.net.URL']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "RCApplet", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SStepable');
C$.sqrt2 = 0;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.sqrt2 = Math.sqrt(2);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.resVal = 0;
this.capVal = 0;
this.xc = 0;
this.fmin = 0;
this.fmax = 0;
this.tmax = 0;
this.freqVal = 0;
this.showControls = false;
this.showCheckBox = false;
this.showGraph = false;
this.defaultCircuit = false;
this.showImpedance = false;
this.$autoRefresh = false;
this.preferredPixPerCell = 0;
this.currentStr = null;
this.etchedBorder1 = null;
this.etchedBorder2 = null;
this.fSlider = null;
this.fNumber = null;
this.circuit = null;
this.circuitBox = null;
this.graph = null;
this.borderLayout1 = null;
this.borderLayout2 = null;
this.borderLayout3 = null;
this.xold = 0;
this.yold = 0;
this.bat = null;
this.cap = null;
this.meter = null;
this.res = null;
this.volt = 0;
this.panel1 = null;
this.label1 = null;
this.checkbox1 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.xc = 0;
this.tmax = 0.1;
this.showControls = true;
this.showCheckBox = true;
this.showGraph = true;
this.defaultCircuit = true;
this.showImpedance = false;
this.$autoRefresh = true;
this.preferredPixPerCell = 60;
this.etchedBorder1 = Clazz.new_((I$[2]||$incl$(2)));
this.etchedBorder2 = Clazz.new_((I$[2]||$incl$(2)));
this.fSlider = Clazz.new_((I$[3]||$incl$(3)));
this.fNumber = Clazz.new_((I$[4]||$incl$(4)));
this.circuit = Clazz.new_((I$[5]||$incl$(5)).c$$edu_davidson_tools_SApplet,[this]);
this.circuitBox = Clazz.new_((I$[6]||$incl$(6)).c$$java_awt_Component$S,[this.circuit, (I$[7]||$incl$(7)).CIRCUIT]);
this.graph = Clazz.new_((I$[8]||$incl$(8)), [this, null]);
this.borderLayout1 = Clazz.new_((I$[9]||$incl$(9)));
this.borderLayout2 = Clazz.new_((I$[9]||$incl$(9)));
this.borderLayout3 = Clazz.new_((I$[9]||$incl$(9)));
this.volt = 10;
this.panel1 = Clazz.new_((I$[10]||$incl$(10)));
this.label1 = Clazz.new_((I$[11]||$incl$(11)));
this.checkbox1 = Clazz.new_((I$[12]||$incl$(12)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
var dt = 0.1;
var fps = 10;
var resourceFile = "";
try {
resourceFile = this.getParameter$S$S("Resources", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (resourceFile != null  && !resourceFile.equals$O("") ) this.loadResources$S(resourceFile);
try {
fps = Double.$valueOf(this.getParameter$S$S("FPS", "10")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
dt = Double.$valueOf(this.getParameter$S$S("dt", "0.1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.defaultCircuit = (I$[13]||$incl$(13)).$valueOf(this.getParameter$S$S("DefaultCircuit", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.resVal = Double.$valueOf(this.getParameter$S$S("Resistor", "50")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.capVal = Double.$valueOf(this.getParameter$S$S("Capacitor", "10")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.fmin = Double.$valueOf(this.getParameter$S$S("Fmin", "10")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.fmax = Double.$valueOf(this.getParameter$S$S("FMax", "1000")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls = (I$[13]||$incl$(13)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showCheckBox = (I$[13]||$incl$(13)).$valueOf(this.getParameter$S$S("ShowCheckBox", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showImpedance = (I$[13]||$incl$(13)).$valueOf(this.getParameter$S$S("ImpedanceGraphType", "false")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showGraph = (I$[13]||$incl$(13)).$valueOf(this.getParameter$S$S("ShowGraph", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (this.showGraph) this.preferredPixPerCell = 60;
 else this.preferredPixPerCell = 200;
try {
this.preferredPixPerCell = Integer.parseInt(this.getParameter$S$S("PixPerCell", "" + this.preferredPixPerCell));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.clock.setDt$D(dt);
this.clock.setFPS$D((fps|0));
this.checkbox1.setState$Z(!this.showImpedance);
this.checkbox1.setVisible$Z(this.showCheckBox);
this.etchedBorder2.setVisible$Z(this.showControls);
this.volt *= C$.sqrt2;
this.capVal *= 1.0E-6;
this.graph.deleteAllSeries();
this.graph.setBorders$S("0,10,10,5");
this.graph.setMinMaxX$D$D(this.fmin, this.fmax);
this.graph.setMinMaxY$D$D(-1, 1);
this.graph.setEnableMouse$Z(true);
this.graph.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.fSlider.setDMax$D(this.fmax);
this.fSlider.setDMin$D(this.fmin);
this.freqVal = (this.fmax + this.fmin) / 2;
this.fNumber.setValue$D(this.freqVal);
this.fSlider.setDValue$D(this.freqVal);
this.fNumber.addPropertyChangeListener$java_beans_PropertyChangeListener(this.fSlider);
this.fSlider.addPropertyChangeListener$java_beans_PropertyChangeListener(this.fNumber);
if (this.fmax < 100 ) this.fNumber.setFormat$S("%6.1f");
 else this.fNumber.setFormat$S("%6.0f");
this.tmax = 10.0 / this.fmax;
if (this.showImpedance) {
this.graph.setLabelY$S((I$[7]||$incl$(7)).CURRENT_RMS_A);
this.graph.setLabelX$S((I$[7]||$incl$(7)).FREQUENCY_HZ);
this.graph.setMinMaxX$D$D(this.fmin, this.fmax);
this.graph.setMinMaxY$D$D(0, this.volt / this.resVal);
} else {
this.graph.setLabelY$S((I$[7]||$incl$(7)).VOLTAGE_V);
this.graph.setLabelX$S((I$[7]||$incl$(7)).TIME_SEC);
this.graph.setMinMaxX$D$D(0, this.tmax);
this.graph.setMinMaxY$D$D(-1.1 * this.volt, 1.2 * this.volt);
}if (this.defaultCircuit) {
p$.createCircuit.apply(this, []);
p$.setCircuitValues.apply(this, []);
this.plotFunction();
this.graph.setVisible$Z(this.showGraph);
} else {
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
this.circuit.setGridSize$I$I(3, 2);
this.showGraph = false;
this.graph.setVisible$Z(false);
}this.clock.addClockListener$edu_davidson_tools_SStepable(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.setSize$java_awt_Dimension(Clazz.new_((I$[14]||$incl$(14)).c$$I$I,[740, 390]));
this.fSlider.setDMax$D(200.0);
this.fNumber.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[15]||$incl$(15)).c$$circuit_RCApplet,[this]));
this.fSlider.addAdjustmentListener$java_awt_event_AdjustmentListener(Clazz.new_((I$[16]||$incl$(16)).c$$circuit_RCApplet,[this]));
this.circuitBox.setTitle$S((I$[7]||$incl$(7)).CIRCUIT);
this.panel1.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.graph.setLabelY$S((I$[7]||$incl$(7)).CURRENT_RMS_A);
this.label1.setAlignment$I(2);
this.label1.setText$S((I$[7]||$incl$(7)).FREQUENCY);
this.checkbox1.setLabel$S((I$[7]||$incl$(7)).VOLTAGE);
this.checkbox1.addItemListener$java_awt_event_ItemListener(Clazz.new_((I$[17]||$incl$(17)).c$$circuit_RCApplet,[this]));
this.graph.setLabelX$S((I$[7]||$incl$(7)).FREQUENCY_HZ);
this.graph.setSampleData$Z(false);
this.graph.setAutoscaleX$Z(false);
this.graph.setAutoscaleY$Z(false);
this.graph.setLabelX$S((I$[7]||$incl$(7)).FREQUENCY);
this.etchedBorder2.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.add$java_awt_Component$O(this.etchedBorder1, "Center");
this.etchedBorder1.add$java_awt_Component$O(this.circuitBox, "West");
this.etchedBorder1.add$java_awt_Component$O(this.graph, "Center");
this.add$java_awt_Component$O(this.etchedBorder2, "South");
this.etchedBorder2.add$java_awt_Component$O(this.fSlider, "Center");
this.etchedBorder2.add$java_awt_Component$O(this.fNumber, "East");
this.etchedBorder2.add$java_awt_Component$O(this.panel1, "West");
this.panel1.add$java_awt_Component$O(this.checkbox1, null);
this.panel1.add$java_awt_Component$O(this.label1, null);
});

Clazz.newMeth(C$, 'loadResources$S', function (rc) {
if (rc == null ) return;
try {
(I$[7]||$incl$(7)).initResources$java_io_InputStream(Clazz.new_((I$[18]||$incl$(18)).c$$java_net_URL$S,[this.getCodeBase(), rc]).openStream());
(I$[7]||$incl$(7)).setResources();
return;
} catch (x) {
if (Clazz.exceptionOf(x, "java.lang.Exception")){
} else {
throw x;
}
}
try {
(I$[7]||$incl$(7)).initResources$java_io_InputStream(Clazz.new_((I$[18]||$incl$(18)).c$$java_net_URL$S,[this.getDocumentBase(), rc]).openStream());
(I$[7]||$incl$(7)).setResources();
} catch (x) {
if (Clazz.exceptionOf(x, "java.lang.Exception")){
System.out.println$S("Can't load resources! : " + x.getMessage());
return;
} else {
throw x;
}
}
});

Clazz.newMeth(C$, 'destroy', function () {
this.circuit.forceBubbleHelp$S(null);
this.graph.destroy();
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'start', function () {
this.graph.setOwner$edu_davidson_tools_SApplet(this);
this.graph.repaint();
C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'stop', function () {
this.oneShotMsg = null;
this.circuit.forceBubbleHelp$S(null);
C$.superclazz.prototype.stop.apply(this, []);
});

Clazz.newMeth(C$, 'forward', function () {
this.circuit.forceBubbleHelp$S(null);
C$.superclazz.prototype.forward.apply(this, []);
});

Clazz.newMeth(C$, 'stoppingClock', function () {
this.circuit.forceBubbleHelp$S(this.oneShotMsg);
});

Clazz.newMeth(C$, 'cyclingClock', function () {
this.clock.setTime$D(0);
this.res.setTime$D(0);
this.cap.setTime$D(0);
this.clearAllData();
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "RCApplet by Wolfgang Christian, wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Resistor", "double", "Resistance in Ohm."]), Clazz.array(java.lang.String, -1, ["Capacitor", "double", "Capacitor value in micro-H."]), Clazz.array(java.lang.String, -1, ["Fmin", "double", "Minimum frequency"]), Clazz.array(java.lang.String, -1, ["FMax", "double", "Maximum frequency."]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the slider."]), Clazz.array(java.lang.String, -1, ["ShowCheckBox", "boolean", "Show the check box."]), Clazz.array(java.lang.String, -1, ["ImpedanceGraphType", "boolean", "Plot current, I(f), rather than time series, V(t)."])]);
return pinfo;
});

Clazz.newMeth(C$, 'getResistorID', function () {
return this.res.getID();
});

Clazz.newMeth(C$, 'getCapacitorID', function () {
return this.cap.getID();
});

Clazz.newMeth(C$, 'getSourceID', function () {
return this.bat.getID();
});

Clazz.newMeth(C$, 'createCircuit', function () {
this.xc = Math.abs(6.283185307179586 * this.freqVal * this.capVal );
if (this.xc != 0 ) this.xc = 1 / this.xc;
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
this.circuit.setGridSize$I$I(4, 2);
this.bat = this.circuit.addSineWave$I$I$I$I(0, 0, 0, 1);
this.bat.setVoltRMS$D(this.volt / C$.sqrt2);
this.bat.showPhase = false;
this.res = this.circuit.addResistor$I$I$I$I(0, 1, 1, 1);
this.res.setLabel$S((I$[7]||$incl$(7)).LEGEND_R);
this.res.setR$D(this.resVal);
this.res.showR = true;
this.res.showV = true;
this.res.showPhase = true;
this.circuit.addWire$I$I$I$I(1, 1, 2, 1);
this.circuit.addWire$I$I$I$I(0, 0, 2, 0);
this.cap = this.circuit.addCapacitor$I$I$I$I(2, 1, 2, 0);
this.cap.setLabel$S((I$[7]||$incl$(7)).LEGEND_C);
this.cap.setC$D(this.capVal * 1000000.0);
this.cap.showC = true;
this.cap.showV = true;
this.cap.showPhase = true;
this.circuit.addWire$I$I$I$I(2, 0, 3, 0);
this.circuit.addWire$I$I$I$I(2, 1, 3, 1);
this.meter = this.circuit.addVoltmeter$I$I$I$I(3, 0, 3, 1);
});

Clazz.newMeth(C$, 'setCircuitValues', function () {
var irms = this.volt / this.zMag$D(this.freqVal) / C$.sqrt2 ;
this.bat.setF$D(this.freqVal);
this.bat.setCurrentRMS$D(irms);
this.res.setVoltRMS$D(this.vrMag$D(this.freqVal) / C$.sqrt2);
this.res.setCurrentRMS$D(irms);
this.res.setPhaseRadian$D(this.vrPhase$D(this.freqVal));
this.meter.setVoltRMS$D(this.vrMag$D(this.freqVal) / C$.sqrt2);
this.cap.setVoltRMS$D(this.vcMag$D(this.freqVal) / C$.sqrt2);
this.cap.setCurrentRMS$D(irms);
this.cap.setPhaseRadian$D(this.vcPhase$D(this.freqVal));
var t = this.clock.getTime();
var vc = this.vcMag$D(this.freqVal);
var vr = this.vrMag$D(this.freqVal);
var wt = 6.283185307179586 * this.freqVal * t ;
var i = vr * Math.sin(wt + this.res.getPhaseRadian()) / this.resVal;
this.bat.setTime$D(t);
this.bat.setVoltInstantaneous$D(this.volt * Math.sin(wt));
this.bat.setCurrentInstantaneous$D(i);
this.res.setTime$D(t);
this.res.setVoltInstantaneous$D(vr * Math.sin(wt + this.res.getPhaseRadian()));
this.res.setCurrentInstantaneous$D(i);
this.cap.setTime$D(t);
this.cap.setVoltInstantaneous$D(vc * Math.sin(wt + this.cap.getPhaseRadian()));
this.cap.setCurrentInstantaneous$D(i);
});

Clazz.newMeth(C$, 'zMag$D', function (f) {
return Math.sqrt(this.resVal * this.resVal + this.xc * this.xc);
});

Clazz.newMeth(C$, 'vcMag$D', function (f) {
return this.volt * this.xc / Math.sqrt(this.resVal * this.resVal + this.xc * this.xc);
});

Clazz.newMeth(C$, 'vrMag$D', function (f) {
return this.volt * this.resVal / Math.sqrt(this.resVal * this.resVal + this.xc * this.xc);
});

Clazz.newMeth(C$, 'vrPhase$D', function (f) {
return Math.atan2(this.xc, this.resVal);
});

Clazz.newMeth(C$, 'vcPhase$D', function (f) {
return Math.atan2(-this.resVal, this.xc);
});

Clazz.newMeth(C$, 'plotFunction', function () {
if (this.showImpedance) {
this.plotZ();
} else {
this.plotV();
}});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, t) {
var wt = 6.283185307179586 * this.freqVal * t ;
var vc = this.vcMag$D(this.freqVal);
var vr = this.vrMag$D(this.freqVal);
var i = vr * Math.sin(wt + this.res.getPhaseRadian()) / this.resVal;
this.bat.setTime$D(t);
this.bat.setVoltInstantaneous$D(this.volt * Math.sin(wt));
this.bat.setCurrentInstantaneous$D(i);
this.res.setTime$D(t);
this.res.setVoltInstantaneous$D(vr * Math.sin(wt + this.res.getPhaseRadian()));
this.res.setCurrentInstantaneous$D(i);
this.cap.setTime$D(t);
this.cap.setVoltInstantaneous$D(vc * Math.sin(wt + this.cap.getPhaseRadian()));
this.cap.setCurrentInstantaneous$D(i);
this.updateDataConnections();
});

Clazz.newMeth(C$, 'plotV', function () {
var np = Math.max(150, (this.graph.getBounds().width/3|0));
if (this.graph.getBounds().width == 0) np = 200;
this.graph.setAutoRefresh$Z(false);
var dt = this.tmax / (np - 1);
var x = Clazz.array(Double.TYPE, [np]);
var y1 = Clazz.array(Double.TYPE, [np]);
var y2 = Clazz.array(Double.TYPE, [np]);
var y3 = Clazz.array(Double.TYPE, [np]);
var vc = this.vcMag$D(this.freqVal);
var vr = this.vrMag$D(this.freqVal);
var pc = this.vcPhase$D(this.freqVal);
var pr = this.vrPhase$D(this.freqVal);
var w = 6.283185307179586 * this.freqVal;
for (var i = 0; i < np; i++) {
x[i] = i * dt;
y1[i] = this.volt * Math.sin(w * x[i]);
y2[i] = vc * Math.sin(w * x[i] + pc);
y3[i] = vr * Math.sin(w * x[i] + pr);
}
this.graph.setAutoReplaceData$I$Z(1, true);
this.graph.setAutoReplaceData$I$Z(2, true);
this.graph.setAutoReplaceData$I$Z(3, true);
this.graph.clearSeriesData$I(1);
this.graph.clearSeriesData$I(2);
this.graph.clearSeriesData$I(3);
this.graph.addData$I$DA$DA(1, x, y1);
this.graph.addData$I$DA$DA(2, x, y2);
this.graph.addData$I$DA$DA(3, x, y3);
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(1, (I$[1]||$incl$(1)).black, true, 0);
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(2, (I$[1]||$incl$(1)).red, true, 0);
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(3, (I$[1]||$incl$(1)).blue, true, 0);
this.graph.setSeriesLegend$I$java_awt_Color$I$I$S(1, (I$[1]||$incl$(1)).black, 75, 20, "Vac");
this.graph.setSeriesLegend$I$java_awt_Color$I$I$S(2, (I$[1]||$incl$(1)).red, 125, 20, "Vc");
this.graph.setSeriesLegend$I$java_awt_Color$I$I$S(3, (I$[1]||$incl$(1)).blue, 175, 20, "Vr");
this.graph.setAutoRefresh$Z(this.$autoRefresh);
});

Clazz.newMeth(C$, 'plotZ', function () {
var np = 200;
var df = (this.fmax - this.fmin) / (np - 1);
var x = Clazz.array(Double.TYPE, [np]);
var y = Clazz.array(Double.TYPE, [np]);
var temp;
var con = 6.283185307179586 * this.capVal;
for (var i = 0; i < np; i++) {
x[i] = this.fmin + i * df;
temp = 1 / (con * x[i]);
y[i] = this.volt / Math.sqrt(this.resVal * this.resVal + temp * temp);
}
this.graph.clearSeriesData$I(1);
this.graph.clearSeriesData$I(2);
this.graph.clearSeriesData$I(3);
this.graph.addData$I$DA$DA(1, x, y);
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(1, (I$[1]||$incl$(1)).red, true, 0);
this.graph.setSeriesLegend$I$java_awt_Color$I$I$S(1, (I$[1]||$incl$(1)).red, 75, 20, "Current");
this.xold = -100;
this.yold = -100;
if (this.circuit.getOsi() == null ) return;
var g = this.graph.getGraphics();
g.setColor$java_awt_Color((I$[1]||$incl$(1)).green);
g.setXORMode$java_awt_Color((I$[1]||$incl$(1)).red);
var xx = this.fSlider.getDValue();
this.xold = this.graph.pixFromX$D(xx);
this.yold = this.graph.pixFromY$D(this.volt / this.zMag$D(xx));
g.fillOval$I$I$I$I(this.xold - 5, this.yold - 5, 10, 10);
g.setPaintMode();
g.dispose();
});

Clazz.newMeth(C$, 'adjustFreq$D', function (f) {
this.freqVal = f;
if (this.freqVal < this.fmin ) {
this.freqVal = this.fmin;
this.fSlider.setDValue$D(this.freqVal);
}if (this.freqVal > this.fmax ) {
this.freqVal = this.fmax;
this.fSlider.setDValue$D(this.freqVal);
}this.xc = Math.abs(6.283185307179586 * this.freqVal * this.capVal );
if (this.xc != 0 ) this.xc = 1 / this.xc;
this.clock.setTime$D(0);
this.clearAllData();
p$.setCircuitValues.apply(this, []);
if (!this.showImpedance) {
this.plotV();
return;
}var i = this.volt / this.zMag$D(this.freqVal);
var xpix = this.graph.pixFromX$D(this.freqVal);
var ypix = this.graph.pixFromY$D(i);
var g = this.graph.getGraphics();
g.setColor$java_awt_Color((I$[1]||$incl$(1)).green);
g.setXORMode$java_awt_Color((I$[1]||$incl$(1)).red);
g.fillOval$I$I$I$I(this.xold - 5, this.yold - 5, 10, 10);
g.fillOval$I$I$I$I(xpix - 5, ypix - 5, 10, 10);
this.xold = xpix;
this.yold = ypix;
g.setPaintMode();
g.dispose();
});

Clazz.newMeth(C$, 'fSlider_adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
this.adjustFreq$D(this.fSlider.getDValue());
});

Clazz.newMeth(C$, 'fNumber_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.fNumber.isValid()) this.adjustFreq$D(this.fNumber.getValue());
});

Clazz.newMeth(C$, ['setPixPerCell$I','setPixPerCell'], function (ppc) {
if (this.preferredPixPerCell == ppc) return;
this.preferredPixPerCell = ppc;
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
});

Clazz.newMeth(C$, ['setTitle$S','setTitle'], function (str) {
this.graph.setTitle$S(str);
});

Clazz.newMeth(C$, 'setDefault', function () {
this.oneShotMsg = null;
this.deleteDataConnections();
this.clock.stopClock();
this.clock.setTime$D(0);
this.circuit.setDefault$I(this.preferredPixPerCell);
p$.createCircuit.apply(this, []);
p$.setCircuitValues.apply(this, []);
this.graph.setTitle$S(null);
});

Clazz.newMeth(C$, ['setCapacitance$D$Z$Z$Z','setCapacitance'], function (c, showC, showV, showPhase) {
this.capVal = c;
this.cap.setC$D(this.capVal * 1000000.0);
this.cap.showC = showC;
this.cap.showV = showV;
this.cap.showPhase = showPhase;
this.adjustFreq$D(this.freqVal);
});

Clazz.newMeth(C$, ['setResistance$D$Z$Z$Z','setResistance'], function (r, showR, showV, showPhase) {
this.resVal = r;
this.res.setR$D(this.resVal);
this.res.showR = showR;
this.res.showV = showV;
this.res.showPhase = showPhase;
this.adjustFreq$D(this.freqVal);
});

Clazz.newMeth(C$, ['setSourceVoltage$D$Z$Z','setSourceVoltage'], function (v, showV, showPhase) {
this.volt = v;
this.bat.setVoltRMS$D(this.volt / C$.sqrt2);
this.bat.showV = showV;
this.bat.showPhase = showPhase;
this.adjustFreq$D(this.freqVal);
});

Clazz.newMeth(C$, ['setCapacitorHint$S','setCapacitorHint'], function (str) {
return this.circuit.setHint$I$S(this.cap.getID(), str);
});

Clazz.newMeth(C$, ['setResistorHint$S','setResistorHint'], function (str) {
return this.circuit.setHint$I$S(this.res.getID(), str);
});

Clazz.newMeth(C$, ['setACHint$S','setACHint'], function (str) {
return this.circuit.setHint$I$S(this.bat.getID(), str);
});

Clazz.newMeth(C$, ['setVoltmeterHint$S','setVoltmeterHint'], function (str) {
return this.circuit.setHint$I$S(this.meter.getID(), str);
});

Clazz.newMeth(C$, ['setFrequency$D','setFrequency'], function (f) {
this.fSlider.setDValue$D(f);
this.adjustFreq$D(f);
});

Clazz.newMeth(C$, ['setShowControls$Z','setShowControls'], function (sc) {
this.etchedBorder2.setVisible$Z(sc);
});

Clazz.newMeth(C$, ['setShowCheckBox$Z','setShowCheckBox'], function (scb) {
this.checkbox1.setVisible$Z(scb);
});

Clazz.newMeth(C$, ['setShowGraph$Z','setShowGraph'], function (sg) {
if (this.graph.isVisible() == sg ) return;
this.showGraph = sg;
this.graph.setVisible$Z(sg);
this.invalidate();
this.validate();
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (ar) {
if (this.$autoRefresh == ar ) return;
this.$autoRefresh = ar;
this.graph.setAutoRefresh$Z(this.$autoRefresh);
if (this.$autoRefresh) this.setShowImpedance$Z(this.showImpedance);
});

Clazz.newMeth(C$, ['setImpedanceGraphType$Z','setImpedanceGraphType'], function (igt) {
if (this.showImpedance == igt ) return;
this.showImpedance = igt;
if (this.$autoRefresh) this.setShowImpedance$Z(this.showImpedance);
});

Clazz.newMeth(C$, 'setShowImpedance$Z', function (si) {
this.graph.setAutoRefresh$Z(false);
this.showImpedance = si;
this.graph.deleteSeries$I(1);
this.graph.deleteSeries$I(2);
this.graph.deleteSeries$I(3);
if (this.showImpedance) {
this.xold = -100;
this.yold = -100;
this.graph.setLabelY$S((I$[7]||$incl$(7)).CURRENT_A);
this.graph.setLabelX$S((I$[7]||$incl$(7)).FREQUENCY_HZ);
this.graph.setMinMaxX$D$D(this.fmin, this.fmax);
this.graph.setMinMaxY$D$D(0, this.volt / this.resVal);
} else {
this.graph.setLabelY$S((I$[7]||$incl$(7)).VOLTAGE_V);
this.graph.setLabelX$S((I$[7]||$incl$(7)).TIME_SEC);
this.graph.setMinMaxX$D$D(0, this.tmax);
this.graph.setMinMaxY$D$D(-1.1 * this.volt, 1.2 * this.volt);
}this.plotFunction();
this.graph.setAutoRefresh$Z(this.$autoRefresh);
this.graph.repaint();
});

Clazz.newMeth(C$, 'checkbox1_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (e.getStateChange() == 1) {
this.setShowImpedance$Z(false);
} else {
this.setShowImpedance$Z(true);
}});
;
(function(){var C$=Clazz.newClass(P$.RCApplet, "RCGraph", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'edu.davidson.display.SGraph');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'paintLast$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
C$.superclazz.prototype.paintLast$java_awt_Graphics$java_awt_Rectangle.apply(this, [g, r]);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).green);
g.setXORMode$java_awt_Color((I$[1]||$incl$(1)).red);
var xx = this.this$0.fSlider.getDValue();
this.this$0.xold = this.this$0.graph.pixFromX$D(xx);
this.this$0.yold = this.this$0.graph.pixFromY$D(this.this$0.volt / this.this$0.zMag$D(xx));
g.fillOval$I$I$I$I(this.this$0.xold - 5, this.this$0.yold - 5, 10, 10);
g.setPaintMode();
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-02-22 01:06:41
