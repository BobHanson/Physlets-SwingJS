(function(){var P$=Clazz.newPackage("qTime"),I$=[['a2s.Button','a2s.TextField','Boolean','java.awt.BorderLayout','a2s.Panel','qTime.QTimeGraph','qTime.TabbedPanel','java.awt.GridLayout','java.awt.Color','edu.davidson.graphics.Box','qTime.QTimeHelp','java.awt.FlowLayout','a2s.Label']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "QTimeHelp", null, 'a2s.Panel');
C$.dcLayout = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.dcLayout = Clazz.new_((I$[12]||$incl$(12)).c$$I$I$I,[1, 10, 5]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.applet = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$qTime_QTime', function (app) {
Clazz.super_(C$, this,1);
this.applet=app;
this.setLayout$java_awt_LayoutManager(C$.dcLayout);
this.setBackground$java_awt_Color((I$[9]||$incl$(9)).lightGray);
var p = Clazz.new_((I$[5]||$incl$(5)));
p.setLayout$java_awt_LayoutManager(Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[3, 1]));
p.add$java_awt_Component(Clazz.new_((I$[13]||$incl$(13)).c$$S$I,["by W. Christian.", 2]));
p.add$java_awt_Component(Clazz.new_((I$[13]||$incl$(13)).c$$S$I,["Davidson College", 2]));
p.add$java_awt_Component(Clazz.new_((I$[13]||$incl$(13)).c$$S$I,["email: wochristian@davidson.edu", 2]));
var helpBox = Clazz.new_((I$[10]||$incl$(10)).c$$java_awt_Component$S,[p, "QTime Ver 1.3"]);
this.add$java_awt_Component(helpBox);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-23 12:59:43 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
