(function(){var P$=Clazz.newPackage("animator4"),I$=[];
var C$=Clazz.newClass(P$, "ImageThing", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.image = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$java_awt_Image$S$S', function (o, im, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.image = im;
this.w = im.getWidth$java_awt_image_ImageObserver(this.canvas);
this.h = im.getHeight$java_awt_image_ImageObserver(this.canvas);
}, 1);

Clazz.newMeth(C$, 'getImage', function () {
return this.image;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.canvas.pixFromX$D(this.vars[1]) + this.xDisplayOff + (this.w/2|0) ;
var ptY = this.canvas.pixFromY$D(this.vars[2]) - this.yDisplayOff + (this.h/2|0);
if ((Math.abs(xPix - ptX) < (this.w/2|0) + 1) && (Math.abs(yPix - ptY) < (this.h/2|0) + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
try {
if (!this.visible) return;
this.w = this.image.getWidth$java_awt_image_ImageObserver(this.canvas);
this.h = this.image.getHeight$java_awt_image_ImageObserver(this.canvas);
if (this.w == -1 || this.h == -1 ) return;
var ptX = Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.image, ptX, ptY, this.canvas);
this.paintTrail$java_awt_Graphics(g);
if (this.showCoordinates) this.paintCoordinates$java_awt_Graphics$I$I(g, ptX + (this.w/2|0), ptY + (this.h/2|0));
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
} else {
throw ex;
}
}
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:13
