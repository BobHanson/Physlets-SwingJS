(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newClass(P$, "BusyFlag");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.busyflag=null;
this.busycount=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.busyflag=null;
this.busycount=0;
}, 1);

Clazz.newMeth(C$, 'getBusyFlag$', function () {
{
return;
}
});

Clazz.newMeth(C$, 'freeBusyFlag$', function () {
{
return;
}
});

Clazz.newMeth(C$, 'getBusyFlagOwner$', function () {
return this.busyflag;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:05 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
