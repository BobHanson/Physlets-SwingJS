(function(){var P$=Clazz.newPackage("emwave4"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Wave", null, 'emwave4.Figure');
C$.lineDensity = 0;
C$.wavelength = 0;
C$.translation = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.lineDensity = 2;
C$.wavelength = 200;
C$.translation = 2;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.h = 0;
this.incrementer = 0;
this.zPropagate = 0;
this.zTerminate = 0;
this.length = 0;
this.amplitude = 0;
this.phase = 0;
this.polarization = 0;
this.zOnDeck = 0;
this.zRelative = 0;
this.offset = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.incrementer = 0;
this.zPropagate = -100;
this.zTerminate = 100;
this.amplitude = 100;
this.phase = 0;
this.polarization = 0;
this.zOnDeck = 0;
this.zRelative = 0;
this.offset = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.length = this.zTerminate - this.zPropagate;
this.numLines = (Math.round(this.length / C$.lineDensity)|0);
this.pts = Clazz.array(Double.TYPE, [2 * this.numLines, 3]);
this.h = this.length / C$.wavelength * 2 * 3.141592653589793 / this.numLines;
this.c = (I$[1]||$incl$(1)).blue;
this.figType = "line";
}, 1);

Clazz.newMeth(C$, 'translate$D', function (dz) {
for (var i = 0; i < 2 * this.numLines; i++) this.pts[i][2] += dz;

this.zOnDeck = (this.zOnDeck+(dz)|0);
this.zRelative = ((this.zOnDeck/C$.lineDensity|0));
if (this.zRelative >= 1) {
this.offset = this.zOnDeck % (C$.lineDensity);
for (var j = 0; j < this.zRelative; j++) {
for (var i = 2 * this.numLines - 1; i > 1; i--) {
this.pts[i][0] = this.pts[i - 2][0];
this.pts[i][1] = this.pts[i - 2][1];
this.pts[i][2] = this.pts[i - 2][2];
}
this.incrementer--;
this.setFirstStick$I$I(this.incrementer, (C$.lineDensity * (this.zRelative - j - 1 ) + this.offset));
}
this.zOnDeck = this.offset;
}});

Clazz.newMeth(C$, 'setFirstStick$I$I', function (a, d) {
});

Clazz.newMeth(C$, 'setLineDensity$I', function (d) {
C$.lineDensity = d;
}, 1);

Clazz.newMeth(C$, 'setWavelength$D', function (l) {
C$.wavelength = l;
}, 1);
})();
//Created 2018-03-17 21:36:50
