(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),p$1={};
var C$=Clazz.newClass(P$, "SRK45", null, 'edu.davidson.numerics.SODE');
C$.maxMessages=0;
C$.b=null;
C$.ch=null;
C$.ct=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.maxMessages=4;
C$.b=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0.2222222222222222]), Clazz.array(Double.TYPE, -1, [0.08333333333333333, 0.25]), Clazz.array(Double.TYPE, -1, [0.5390625, -1.8984375, 2.109375]), Clazz.array(Double.TYPE, -1, [-1.4166666666666667, 6.75, -5.4, 1.0666666666666667]), Clazz.array(Double.TYPE, -1, [0.15046296296296297, -0.3125, 0.8125, 0.14814814814814814, 0.034722222222222224])]);
C$.ch=Clazz.array(Double.TYPE, -1, [0.10444444444444445, 0.0, 0.48, 0.14222222222222222, 0.03333333333333333, 0.24]);
C$.ct=Clazz.array(Double.TYPE, -1, [-0.006666666666666667, 0.0, 0.03, -0.21333333333333335, -0.05, 0.24]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.stepSize=0;
this.fixedStepSize=0;
this.numEqu=0;
this.tempState=null;
this.f=null;
this.equations=null;
this.err=0;
this.tol=0;
this.count=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.stepSize=0.01;
this.fixedStepSize=this.stepSize;
this.numEqu=0;
this.tol=1.0E-6;
this.count=0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'getH$', function () {
return this.stepSize;
});

Clazz.newMeth(C$, 'setH$D', function (h) {
this.stepSize=h;
});

Clazz.newMeth(C$, 'getTol$', function () {
return this.tol;
});

Clazz.newMeth(C$, 'setTol$D', function (t) {
this.tol=t;
});

Clazz.newMeth(C$, 'step$D$DA', function (dx, x) {
if (dx == 0 ) return 0;
if (x.length < this.numEqu) {
this.numEqu=x.length;
this.tempState=Clazz.array(Double.TYPE, [this.numEqu]);
this.f=Clazz.array(Double.TYPE, [6, this.numEqu]);
System.out.println$S("Warning:  Temporary arrays reset.");
}this.fixedStepSize=dx;
if (dx > 0 ) this.stepSize=Math.abs(this.stepSize);
 else this.stepSize=-Math.abs(this.stepSize);
var timeError=0;
this.count=0;
if (this.fixedStepSize > 0 ) timeError=this.fixedStepSize - p$1.plus$DA.apply(this, [x]);
 else timeError=this.fixedStepSize - p$1.minus$DA.apply(this, [x]);
return this.count;
});

Clazz.newMeth(C$, 'stepODE$D$DA', function (dx, x) {
if (x.length < this.numEqu) {
System.out.println$S("Error:  The temporary arrays are not large enough.");
return 0;
}if (dx >= 0 ) this.stepSize=Math.abs(dx);
 else this.stepSize=-Math.abs(dx);
return this.stepRK45$DA(x);
});

Clazz.newMeth(C$, 'stepRK45$DA', function (_x) {
var truncErr;
var state=_x;
if (state.length < this.numEqu) {
this.numEqu=state.length;
this.tempState=Clazz.array(Double.TYPE, [this.numEqu]);
this.f=Clazz.array(Double.TYPE, [6, this.numEqu]);
System.out.println$S("Warning:  Temporary arrays reset.");
}var i;
var j;
var k;
var currentStep=this.stepSize;
System.arraycopy$O$I$O$I$I(state, 0, this.tempState, 0, this.numEqu);
var dydx=this.equations.rate$DA(state);
for (i=0; i < this.numEqu; i++) {
this.f[0][i]=dydx[i];
}
do {
currentStep=this.stepSize;
for (k=1; k < 6; k++) {
for (i=0; i < this.numEqu; i++) {
state[i]=this.tempState[i];
for (j=0; j < k; j++) {
state[i]=state[i] + this.stepSize * C$.b[k - 1][j] * this.f[j][i] ;
}
}
dydx=this.equations.rate$DA(state);
for (i=0; i < this.numEqu; i++) {
this.f[k][i]=dydx[i];
}
}
this.err=0;
for (i=0; i < this.numEqu; i++) {
state[i]=this.tempState[i];
truncErr=0;
for (k=0; k < 6; k++) {
state[i] += this.stepSize * C$.ch[k] * this.f[k][i] ;
truncErr += this.stepSize * C$.ct[k] * this.f[k][i] ;
}
truncErr=Math.abs(truncErr);
if (this.err < truncErr ) {
this.err=truncErr;
}}
if (this.err <= 4.9E-324 ) {
this.err=this.tol / 100000.0;
}if (this.err > this.tol ) {
this.stepSize=0.9 * this.stepSize * Math.pow(this.tol / this.err, 0.25) ;
} else if (this.err < 2.0 * this.tol ) {
this.stepSize=0.9 * this.stepSize * Math.pow(this.tol / this.err, 0.2) ;
}} while (this.err > this.tol );
return currentStep;
});

Clazz.newMeth(C$, 'setDifferentials$edu_davidson_numerics_SDifferentiable', function (d) {
this.equations=d;
this.numEqu=this.equations.getNumEqu$();
this.tempState=Clazz.array(Double.TYPE, [this.numEqu]);
this.f=Clazz.array(Double.TYPE, [6, this.numEqu]);
});

Clazz.newMeth(C$, 'getDiffernetials$', function () {
return this.equations;
});

Clazz.newMeth(C$, 'setNumberOfEquations$I', function (n) {
this.numEqu=n;
this.tempState=Clazz.array(Double.TYPE, [this.numEqu]);
this.f=Clazz.array(Double.TYPE, [6, this.numEqu]);
});

Clazz.newMeth(C$, 'plus$DA', function (_x) {
var remainder=this.fixedStepSize;
if ((this.stepSize <= 0 ) || (this.stepSize > this.fixedStepSize ) || (this.fixedStepSize - this.stepSize == this.fixedStepSize )  ) {
this.stepSize=this.fixedStepSize;
}while (remainder > this.tol * this.fixedStepSize ){
this.count++;
var oldRemainder=remainder;
if (remainder <= this.stepSize ) {
var tempStep=this.stepSize;
this.stepSize=remainder;
var delta=this.stepRK45$DA(_x);
remainder -= delta;
this.stepSize=Math.min(tempStep, delta);
} else {
remainder -= this.stepRK45$DA(_x);
}if ((Math.abs(oldRemainder - remainder) <= 4.94E-322 ) || (this.tol * this.fixedStepSize / 100.0 > this.stepSize ) ) {
if (C$.maxMessages <= 0) {
break;
}C$.maxMessages--;
System.out.println$S("Warning: RK45MultiStep did not converge. Remainder=" + new Double(remainder).toString());
if (C$.maxMessages == 0) {
System.out.println$S("Further warnings surppressed.");
}break;
}}
return remainder;
}, p$1);

Clazz.newMeth(C$, 'minus$DA', function (_x) {
var remainder=this.fixedStepSize;
if ((this.stepSize >= 0 ) || (this.stepSize < this.fixedStepSize ) || (this.fixedStepSize - this.stepSize == this.fixedStepSize )  ) {
this.stepSize=this.fixedStepSize;
}while (remainder < this.tol * this.fixedStepSize ){
this.count++;
var oldRemainder=remainder;
if (remainder >= this.stepSize ) {
var tempStep=this.stepSize;
this.stepSize=remainder;
var delta=this.stepRK45$DA(_x);
remainder -= delta;
this.stepSize=Math.max(tempStep, delta);
} else {
remainder -= this.stepRK45$DA(_x);
}if ((Math.abs(oldRemainder - remainder) <= 4.94E-322 ) || (this.tol * this.fixedStepSize / 100.0 < this.stepSize ) ) {
if (C$.maxMessages <= 0) {
break;
}C$.maxMessages--;
System.out.println$S("Warning: RK45MultiStep did not converge. Remainder=" + new Double(remainder).toString());
if (C$.maxMessages == 0) {
System.out.println$S("Further warnings surppressed.");
}break;
}}
return remainder;
}, p$1);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:04 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
