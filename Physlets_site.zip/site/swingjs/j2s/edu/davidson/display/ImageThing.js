(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[];
var C$=Clazz.newClass(P$, "ImageThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.image = null;
this.drawingComponent = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.drawingComponent = null;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$java_awt_Image$D$D', function (owner, sc, im, x, y) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, x, y]);
C$.$init$.apply(this);
this.image = im;
this.s = 1;
this.applet = owner;
if (Clazz.instanceOf(sc, "java.awt.Component")) {
this.drawingComponent = sc;
this.w = im.getWidth$java_awt_image_ImageObserver(this.drawingComponent);
this.h = im.getHeight$java_awt_image_ImageObserver(this.drawingComponent);
} else {
this.drawingComponent = null;
}}, 1);

Clazz.newMeth(C$, 'getImage', function () {
return this.image;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff + (this.w/2|0) ;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff + (this.h/2|0);
if ((Math.abs(xPix - ptX) < (this.w/2|0) + 1) && (Math.abs(yPix - ptY) < (this.h/2|0) + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible || this.drawingComponent == null  ) return;
this.w = this.image.getWidth$java_awt_image_ImageObserver(this.drawingComponent);
this.h = this.image.getHeight$java_awt_image_ImageObserver(this.drawingComponent);
if (this.w == -1 || this.h == -1 ) return;
var ptX = Math.round(this.canvas.pixFromX$D(this.x)) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.y)) - this.yDisplayOff;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.image, ptX, ptY, this.drawingComponent);
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:24
