(function(){var P$=Clazz.newPackage("doppler"),I$=[['a2s.Button','java.awt.BorderLayout','java.awt.Insets']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SizedButton", null, 'a2s.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.button = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (str) {
Clazz.super_(C$, this,1);
this.button = Clazz.new_((I$[1]||$incl$(1)).c$$S,[str]);
this.setLayout$java_awt_LayoutManager(Clazz.new_((I$[2]||$incl$(2))));
this.add$S$java_awt_Component("Center", this.button);
}, 1);

Clazz.newMeth(C$, 'insets', function () {
var inH = ((this.size().height - 26)/2|0);
if (inH < 0) inH = 0;
return Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I$I,[inH, 2, inH, 2]);
});

Clazz.newMeth(C$, 'action$java_awt_Event$O', function (evt, arg) {
if (evt.target.equals$O(this.button)) {
evt.target = this;
return false;
} else return false;
});

Clazz.newMeth(C$, 'setLabel$S', function (label) {
this.button.setLabel$S(label);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:06:37
