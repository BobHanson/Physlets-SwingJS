(function(){var P$=Clazz.newPackage("eField4"),I$=[['java.awt.Color','edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CursorThing", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$I$D$D', function (o, diameter, x, y) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [o, x, y, 0, 0]);
C$.$init$.apply(this);
this.s = 1;
this.w = diameter;
this.h = diameter;
this.noDrag = false;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.hideThing) return;
var ptX = this.p.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY = this.p.pixFromY$D(this.vars[2]) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.drawOval$I$I$I$I(ptX - (this.w/2|0), ptY - (this.h/2|0), this.w, this.h);
g.drawLine$I$I$I$I(ptX - (this.w/2|0), ptY, ptX - 1, ptY);
g.drawLine$I$I$I$I(ptX + 1, ptY, ptX + (this.w/2|0), ptY);
g.drawLine$I$I$I$I(ptX, ptY - (this.h/2|0), ptX, ptY - 1);
g.drawLine$I$I$I$I(ptX, ptY + 1, ptX, ptY + (this.h/2|0));
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (g) {
if (this.hideThing) return;
var ptX = this.p.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY = this.p.pixFromY$D(this.vars[2]) - this.yDisplayOff;
if (this.color === (I$[1]||$incl$(1)).red ) g.setColor$java_awt_Color((I$[1]||$incl$(1)).blue);
 else g.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
g.drawOval$I$I$I$I(ptX - (this.w/2|0), ptY - (this.h/2|0), this.w, this.h);
C$.superclazz.prototype.paintHighlight$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.p.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY = this.p.pixFromY$D(this.vars[2]) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < (this.w/2|0) + 1) && (Math.abs(yPix - ptY) < (this.h/2|0) + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'paintGhosts$java_awt_Graphics', function (g) {
if (this.ghost && this.footPrints > 0  && this.trailSize > 1  && this.trail.npoints > 1 ) {
g.setColor$java_awt_Color((I$[2]||$incl$(2)).veryPaleColor$java_awt_Color(this.color));
for (var i = 0; i < this.trail.npoints; i = i+(this.footPrints)) {
var ptX = this.trail.xpoints[i] + this.xDisplayOff;
var ptY = this.trail.ypoints[i] - this.yDisplayOff;
g.drawOval$I$I$I$I(ptX - (this.w/2|0), ptY - (this.h/2|0), this.w, this.h);
g.drawLine$I$I$I$I(ptX - (this.w/2|0), ptY, ptX - 1, ptY);
g.drawLine$I$I$I$I(ptX + 1, ptY, ptX + (this.w/2|0), ptY);
g.drawLine$I$I$I$I(ptX, ptY - (this.h/2|0), ptX, ptY - 1);
g.drawLine$I$I$I$I(ptX, ptY + 1, ptX, ptY + (this.h/2|0));
}
}});

Clazz.newMeth(C$);
})();
//Created 2018-03-16 05:19:21
