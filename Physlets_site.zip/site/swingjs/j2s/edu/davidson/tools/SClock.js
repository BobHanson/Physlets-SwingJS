(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[['java.util.Vector','edu.davidson.tools.SApplet','java.lang.Thread','Thread']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SClock", null, null, ['Runnable', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.clockListeners = null;
this.varStrings = null;
this.ds = null;
this.thread = null;
this.runLock = null;
this.shouldRun = false;
this.running = false;
this.time = 0;
this.delay = 0;
this.maxTime = 0;
this.minTime = 0;
this.dt = 0;
this.oneShot = false;
this.cycle = false;
this.owner = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.clockListeners = Clazz.new_((I$[1]||$incl$(1)));
this.varStrings = Clazz.array(java.lang.String, -1, ["t"]);
this.ds = Clazz.array(Double.TYPE, [1, 1]);
this.thread = null;
this.runLock =  Clazz.new_();
this.shouldRun = true;
this.running = false;
this.time = 0.0;
this.delay = 100;
this.maxTime = 100;
this.minTime = 0;
this.dt = 0.1;
this.oneShot = false;
this.cycle = false;
this.owner = null;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.shouldRun = true;
this.running = false;
try {
(I$[2]||$incl$(2)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet', function (owner) {
C$.c$.apply(this, []);
this.owner = owner;
}, 1);

Clazz.newMeth(C$, 'addClockListener$edu_davidson_tools_SStepable', function (cl) {
if (this.thread == null ) {
{
this.shouldRun = true;
this.running = false;
this.thread = Clazz.new_((I$[3]||$incl$(3)).c$$Runnable,[this]);
this.thread.start();
}}if (this.clockListeners.contains$O(cl)) {
return;
} else {
this.clockListeners.addElement$TE(cl);
}});

Clazz.newMeth(C$, 'removeClockListener$edu_davidson_tools_SStepable', function (cl) {
{
if (!this.clockListeners.contains$O(cl)) {
return;
}this.clockListeners.removeElement$O(cl);
}});

Clazz.newMeth(C$, 'removeAllClockListeners', function () {
{
this.clockListeners.removeAllElements();
}});

Clazz.newMeth(C$, 'doStep', function () {
if (this.running) {
this.stopClock();
return;
}var didCycle = false;
if (this.isRunning() || (this.oneShot && (this.dt > 0 ) && (this.time + 0.49 * this.dt >= this.maxTime )  ) || (this.oneShot && (this.dt < 0 ) && (this.time + 0.49 * this.dt <= this.minTime )  ) || (this.cycle && (this.dt < 0 ) && (this.time + this.dt < this.minTime )  )  ) {
return;
}if (this.cycle && (this.time >= this.maxTime ) && (this.dt > 0 )  ) {
this.time = this.minTime;
didCycle = true;
}if (this.cycle && (this.time < this.minTime ) && (this.dt < 0 )  ) {
this.time = this.maxTime;
didCycle = true;
}for (var e = this.clockListeners.elements(); e.hasMoreElements(); ) {
var clockListener = e.nextElement();
if (this.shouldRun) {
clockListener.step$D$D(this.dt, this.time);
}}
if ((this.owner != null ) && didCycle ) {
this.owner.cyclingClock();
}if ((this.owner != null ) && this.shouldRun ) {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}this.time += this.dt;
});

Clazz.newMeth(C$, 'runningStep', function () {
var didCycle = false;
if (this.cycle && (this.time + 0.49 * this.dt >= this.maxTime ) && (this.dt > 0 )  ) {
this.time = this.minTime;
didCycle = true;
}var clockListener;
for (var e = this.clockListeners.elements(); e.hasMoreElements(); ) {
clockListener = e.nextElement();
if (this.shouldRun) {
clockListener.step$D$D(this.dt, this.time);
}}
if ((this.owner != null ) && this.shouldRun ) {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}this.time += this.dt;
if ((this.owner != null ) && ((I$[2]||$incl$(2)).runningID != null ) && (this.owner !== (I$[2]||$incl$(2)).runningID )  ) {
this.running = false;
this.owner.pausingClock();
}if ((this.cycle && (this.dt < 0 ) && (this.time + 0.49 * this.dt < this.minTime )  ) || (this.oneShot && (this.dt < 0 ) && (this.time + 0.49 * this.dt <= this.minTime )  ) || (this.oneShot && (this.dt > 0 ) && (this.time + 0.49 * this.dt >= this.maxTime )  )  ) {
this.running = false;
this.owner.stoppingClock();
}if ((this.owner != null ) && didCycle ) {
this.owner.cyclingClock();
}});

Clazz.newMeth(C$, 'getTime', function () {
return this.time;
});

Clazz.newMeth(C$, 'getMinTime', function () {
return this.minTime;
});

Clazz.newMeth(C$, 'getMaxTime', function () {
return this.maxTime;
});

Clazz.newMeth(C$, 'setTime$D', function (t) {
var oldRunning = this.running;
this.running = false;
{
this.time = t;
for (var e = this.clockListeners.elements(); e.hasMoreElements(); ) {
var clockListener = e.nextElement();
clockListener.step$D$D(0, this.time);
}
}if (oldRunning) {
this.startClock();
} else {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}});

Clazz.newMeth(C$, 'getDt', function () {
return this.dt;
});

Clazz.newMeth(C$, 'setDt$D', function (newDt) {
var oldRunning = this.running;
this.running = false;
{
this.dt = newDt;
}if (oldRunning) {
this.startClock();
}});

Clazz.newMeth(C$, 'getTimeStep', function () {
return this.getDt();
});

Clazz.newMeth(C$, 'setTimeStep$D', function (newDt) {
this.setDt$D(newDt);
});

Clazz.newMeth(C$, 'setContinuous', function () {
this.cycle = false;
this.oneShot = false;
});

Clazz.newMeth(C$, 'setCycle$D$D', function (min, max) {
var oldRunning = this.running;
var oldTime = this.time;
this.running = false;
{
this.minTime = Math.min(min, max);
this.maxTime = Math.max(min, max);
this.time = Math.max(this.time, this.minTime);
this.time = Math.min(this.time, this.maxTime);
this.oneShot = false;
this.cycle = true;
}if (oldRunning) {
this.startClock();
} else if (oldTime != this.time ) {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}});

Clazz.newMeth(C$, 'setOneShot$D$D', function (min, max) {
var oldRunning = this.running;
var oldTime = this.time;
this.running = false;
{
this.minTime = Math.min(min, max);
this.maxTime = Math.max(min, max);
this.time = Math.max(this.time, this.minTime);
this.time = Math.min(this.time, this.maxTime);
this.oneShot = true;
this.cycle = false;
}if (oldRunning) {
this.startClock();
} else if (oldTime != this.time ) {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}});

Clazz.newMeth(C$, 'startClock', function () {
if (this.owner != null ) {
(I$[2]||$incl$(2)).runningID = this.owner;
}if (this.running && (this.thread != null ) ) {
return;
}if (this.oneShot && (this.dt > 0 ) && (this.time + 0.49 * this.dt >= this.maxTime )  ) {
this.running = false;
this.owner.stoppingClock();
return;
}if ((this.oneShot || this.cycle ) && (this.dt < 0 ) && (this.time + 0.49 * this.dt <= this.minTime )  ) {
this.running = false;
this.owner.stoppingClock();
return;
}if (this.thread == null ) {
this.shouldRun = true;
this.thread = Clazz.new_((I$[3]||$incl$(3)).c$$Runnable,[this]);
this.thread.start();
} else {
{
this.running = true;
this.runLock.notifyAll();
}}});

Clazz.newMeth(C$, 'panicStopClock', function () {
this.shouldRun = false;
if (this.thread == null ) {
return;
}this.startClock();
var tempThread = this.thread;
if (tempThread != null ) {
try {
tempThread.interrupt();
tempThread.join$J(1000);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
tempThread.stop();
} else {
throw e;
}
}
}this.thread = null;
});

Clazz.newMeth(C$, 'stopClock', function () {
if (!this.running) {
return;
}this.running = false;
{
;}});

Clazz.newMeth(C$, 'getFPS', function () {
return 1000.0 / this.delay;
});

Clazz.newMeth(C$, 'setFPS$D', function (fps) {
this.delay = Math.max(0, ((1000 / fps)|0));
});

Clazz.newMeth(C$, 'isCycle', function () {
return this.cycle;
});

Clazz.newMeth(C$, 'isOneShot', function () {
return this.oneShot;
});

Clazz.newMeth(C$, 'isContinous', function () {
return !(this.oneShot || this.cycle );
});

Clazz.newMeth(C$, 'isRunning', function () {
return this.running;
});

Clazz.newMeth(C$, 'run', function () {
while (this.shouldRun){
{
while (this.running == false ){
try {
this.runLock.wait();
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
return;
} else {
throw ie;
}
}
}
if (this.shouldRun) {
p$.runningStep.apply(this, []);
}}if (this.shouldRun) {
try {
(I$[4]||$incl$(4)).sleep$J(this.delay);
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
return;
} else {
throw ie;
}
}
}}
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.time;
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
this.owner = owner;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});
})();
//Created 2018-02-06 13:41:56
