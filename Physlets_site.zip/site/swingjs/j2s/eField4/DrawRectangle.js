(function(){var P$=Clazz.newPackage("eField4"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DrawRectangle", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$I$I', function (p, x, y, width, height) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [p, x, y, 0, 0]);
C$.$init$.apply(this);
this.s = 1;
this.w = width;
this.h = height;
this.p = p;
this.vars[0] = 0;
this.vars[1] = x;
this.vars[2] = y;
this.initVars[0] = 0;
this.initVars[1] = x;
this.initVars[2] = y;
this.color = (I$[1]||$incl$(1)).gray;
this.ds = Clazz.array(Double.TYPE, [1, 8]);
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "vx", "vy", "ax", "ay", "f"]);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (this.hideThing) return;
var ptX = this.p.pixFromX$D(this.vars[1]) - (this.w/2|0) + this.xDisplayOff;
var ptY = this.p.pixFromY$D(this.vars[2]) - (this.h/2|0) - this.yDisplayOff;
osg.setColor$java_awt_Color(this.color);
osg.fillRect$I$I$I$I(ptX, ptY, this.w, this.h);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
if (this.hideThing) return;
var ptX = this.p.pixFromX$D(this.vars[1]) - (this.w/2|0) + this.xDisplayOff;
var ptY = this.p.pixFromY$D(this.vars[2]) - (this.h/2|0) - this.yDisplayOff;
if (this.color === (I$[1]||$incl$(1)).black ) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
 else osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
osg.drawRect$I$I$I$I(ptX, ptY, this.w, this.h);
osg.drawRect$I$I$I$I(ptX - 1, ptY - 1, this.w + 2, this.h + 2);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.p.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY = this.p.pixFromY$D(this.vars[2]) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < (this.w/2|0) + 1) && (Math.abs(yPix - ptY) < (this.h/2|0) + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.vars[0];
this.ds[0][1] = this.vars[1];
this.ds[0][2] = this.vars[2];
this.ds[0][3] = this.vars[3];
this.ds[0][4] = this.vars[4];
this.ds[0][5] = this.vars[5];
this.ds[0][6] = this.vars[6];
this.ds[0][7] = this.calcFlux();
return this.ds;
});

Clazz.newMeth(C$, 'calculateState', function () {
this.calcFlux();
});

Clazz.newMeth(C$, 'calcFlux', function () {
if (this.w < 2 || this.h < 2 ) return 0.0;
var sum1 = 0;
var sum2 = 0;
var ptX = this.p.pixFromX$D(this.vars[1]) - (this.w/2|0);
var ptY = this.p.pixFromY$D(this.vars[2]) - (this.h/2|0);
var x1 = 0;
var y1 = 0;
var x2 = 0;
var y2 = 0;
var x = 0;
var y = 0;
var prec = 4;
y1 = this.p.yFromPix$I(ptY);
y2 = this.p.yFromPix$I(ptY + this.h);
var dy = (y1 - y2) / this.h / prec ;
x1 = this.p.xFromPix$I(ptX);
x2 = this.p.xFromPix$I(ptX + this.w);
x = x1;
var dx = (x2 - x1) / this.w / prec ;
for (var i = 0; i < this.w * prec ; i++) {
sum1 = sum1 - this.p.dudy$D$D(x + dx, y1);
sum1 = sum1 - (-this.p.dudy$D$D(x, y2));
x += dx;
}
sum1 = (x2 - x1) * sum1 / 2 / this.w / prec;
y = y2;
for (var i = 0; i < this.h * prec ; i++) {
sum2 = sum2 + (-this.p.dudx$D$D(x1, y + dy));
sum2 = sum2 - (-this.p.dudx$D$D(x2, y));
y += dy;
}
sum2 = (y2 - y1) * sum2 / 2 / this.h / prec;
this.flux = sum1 + sum2 + 3.141592653589793 * this.enclosedCharge() * 4  ;
return this.flux;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:18
