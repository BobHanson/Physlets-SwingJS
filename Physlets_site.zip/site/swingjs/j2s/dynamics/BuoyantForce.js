(function(){var P$=Clazz.newPackage("dynamics"),I$=[[0,'java.awt.Color','dynamics.BuoyantBlock','java.awt.Dimension','javax.swing.Timer']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "BuoyantForce", null, 'java.applet.Applet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.yOffset=0;
this.running=false;
this.area=null;
this.offDimension=null;
this.offImage=null;
this.blockImage=null;
this.g=null;
this.gb=null;
this.yc=0;
this.x0=0;
this.y0=0;
this.w=0;
this.h=0;
this.rho=0;
this.bgColor=null;
this.fgColor=null;
this.block=null;
this.rts=null;
this.yb=0;
this.startTime=0;
this.lastTime=0;
this.delay=0;
this.delta=0;
this.size=0;
this.size2=0;
this.count=0;
this.prevyb=0;
this.sign=0;
this.dragging=false;
this.oscillating=false;
this.d=0;
this.x1=0;
this.y1=0;
this.xa=0;
this.xx=0;
this.yy=0;
this.xb=0;
this.arw=0;
this.timer=null;
this.sleepTime=0;
this.counter0=0;
this.counter2=0;
this.state=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.yOffset=0;
this.sleepTime=10;
this.counter0=0;
this.counter2=0;
this.state=0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.yOffset=0;
this.running=false;
this.x0=25;
this.y0=10;
this.w=100;
this.h=100;
this.rho=0.4;
this.bgColor=Clazz.load('java.awt.Color').white;
this.fgColor=$I$(1).lightGray;
this.block=Clazz.new_(Clazz.load('dynamics.BuoyantBlock'));
this.startTime=0;
this.delay=50;
this.size=2;
this.size2=2 * this.size;
this.count=100;
this.sign=1;
this.dragging=false;
this.oscillating=false;
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
this.resize$I$I(400, 400);
this.area=Clazz.new_(Clazz.load('java.awt.Dimension').c$$I$I,[400, 400]);
var area=this.area;
area.height-=this.yOffset;
this.offDimension=this.area;
this.offImage=this.createImage$I$I(this.area.width, this.area.height);
this.g=this.offImage.getGraphics$();
this.blockImage=this.createImage$I$I(this.w, this.h);
this.gb=this.blockImage.getGraphics$();
this.yc=((this.area.height * 0.6)|0);
this.reset$Z(true);
});

Clazz.newMeth(C$, ['setDensity$D','setDensity'], function (density) {
this.stop$();
if (this.rho != density ) {
this.rho=density;
}});

Clazz.newMeth(C$, ['reset$Z','reset'], function (b) {
this.yb=this.y0;
this.clear$();
if (b) {
this.running=false;
}});

Clazz.newMeth(C$, 'd2String$D', function (n) {
var s=String.valueOf$F((((n * 100.0)|0) / 100.0));
if (s.indexOf$S(".") == -1) {
s += ".0";
}return s;
});

Clazz.newMeth(C$, ['start$','start'], function () {
this.state=0;
this.runTimer$();
});

Clazz.newMeth(C$, ['stop$','stop'], function () {
this.timer.stop$();
this.running=false;
});

Clazz.newMeth(C$, 'runTimer$', function () {
this.gb.setColor$java_awt_Color($I$(1).white);
this.gb.drawRect$I$I$I$I(0, 0, this.w, this.h - 1);
switch (this.state) {
case 0:
this.advance0$I(this.counter0);
this.counter0++;
if (this.counter0 >= this.d) this.state=1;
break;
case 1:
this.advance1$();
++this.yb;
if (this.yb >= this.yc + this.d - this.w) {
this.counter2=this.yc + this.w - this.d;
this.state=2;
}break;
case 2:
this.advance2$I(this.counter2);
this.counter2--;
if (this.counter2 <= this.yc) this.state=3;
break;
case 3:
this.running=false;
return;
}
this.timer=Clazz.new_(Clazz.load('javax.swing.Timer').c$$I$java_awt_event_ActionListener,[this.sleepTime, ((P$.BuoyantForce$1||
(function(){var C$=Clazz.newClass(P$, "BuoyantForce$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (e) {
this.b$['dynamics.BuoyantForce'].runTimer$.apply(this.b$['dynamics.BuoyantForce'], []);
});
})()
), Clazz.new_(P$.BuoyantForce$1.$init$, [this, null]))]);
this.timer.setRepeats$Z(false);
this.timer.start$();
});

Clazz.newMeth(C$, ['advance0$I','advance0'], function (i) {
var n=1.0 / this.rho;
var n2=this.x1 + this.w - 1;
this.gb.setColor$java_awt_Color(this.bgColor);
var gb=this.gb;
var n3=1;
var n4=this.h - this.d + i;
gb.drawLine$I$I$I$I(1, n4, n2, n4);
this.gb.setColor$java_awt_Color(this.fgColor);
var gb2=this.gb;
var n5=1;
var n6=((i * n)|0);
gb2.drawLine$I$I$I$I(1, n6, n2, n6);
this.gb.setColor$java_awt_Color($I$(1).black);
this.gb.drawRect$I$I$I$I(1, 0, this.w - 1, this.h - 1);
this.gb.setColor$java_awt_Color($I$(1).red);
this.gb.drawLine$I$I$I$I(this.xx=(this.w/2|0), this.yy=this.h - this.d, this.xx, this.yy+=this.d);
this.gb.drawLine$I$I$I$I(this.xx, this.yy, this.xx - this.arw, this.yy - this.arw);
this.gb.drawLine$I$I$I$I(this.xx, this.yy, this.xx + this.arw, this.yy - this.arw);
this.gb.setColor$java_awt_Color($I$(1).black);
this.gb.drawRect$I$I$I$I(1, 0, this.w - 1, this.h - 1);
this.repaint$();
});

Clazz.newMeth(C$, ['advance1$','advance1'], function () {
var n7=this.yb + this.h - this.yc;
if (n7 > 0) {
this.g.setColor$java_awt_Color(this.fgColor);
this.g.drawLine$I$I$I$I(this.x0 + 1, this.yy=this.yc + this.h - n7, this.xa - 1, this.yy);
this.g.setColor$java_awt_Color($I$(1).green);
this.xx=this.x1 + (this.w/2|0);
this.yy=this.yc + n7;
if (n7 > 1) {
this.g.drawLine$I$I$I$I(this.xb + 1, this.yy, this.xb + n7 - 1, this.yy);
}}this.gb.setColor$java_awt_Color($I$(1).black);
this.gb.drawRect$I$I$I$I(1, 0, this.w - 1, this.h - 1);
this.repaint$();
});

Clazz.newMeth(C$, ['advance2$I','advance2'], function (j) {
this.g.setColor$java_awt_Color(this.bgColor);
this.g.drawLine$I$I$I$I(this.x0, this.yy=j + this.d, this.x0 + this.w - 1, this.yy--);
this.g.setColor$java_awt_Color(this.fgColor);
this.g.drawLine$I$I$I$I(this.x0 + 1, j, this.x0 + this.w - 1, j);
this.g.setColor$java_awt_Color($I$(1).black);
this.g.drawLine$I$I$I$I(this.x0, this.yy, this.x0 + this.w, this.yy);
this.g.drawLine$I$I$I$I(this.x0, this.yy=j + this.d - this.w, this.x0, this.yy);
this.g.drawLine$I$I$I$I(this.xx=this.x0 + this.w, this.yy, this.xx, this.yy);
this.gb.setColor$java_awt_Color($I$(1).black);
this.gb.drawRect$I$I$I$I(1, 0, this.w - 1, this.h - 1);
this.repaint$();
});

Clazz.newMeth(C$, 'clear$', function () {
if (this.g != null ) {
this.g.clearRect$I$I$I$I(0, 0, this.area.width, this.area.height);
this.g.setColor$java_awt_Color(this.fgColor);
this.d=((this.rho * this.h)|0);
this.g.fillRect$I$I$I$I(this.xa=this.x0 + this.w, this.yc, this.w + 2 * this.x0, this.yc);
this.g.fillRect$I$I$I$I(this.x0, this.y1=this.y0 + this.h - this.d, this.w, this.d);
this.g.setColor$java_awt_Color($I$(1).red);
this.g.drawLine$I$I$I$I(this.xx=this.x0 + (this.w/2|0), this.yy=this.y1, this.xx, this.yy+=this.d);
this.arw=((this.rho * 10.0)|0);
this.g.drawLine$I$I$I$I(this.xx, this.yy, this.xx - this.arw, this.yy - this.arw);
this.g.drawLine$I$I$I$I(this.xx, this.yy, this.xx + this.arw, this.yy - this.arw);
this.x1=2 * this.x0 + this.w;
this.gb.clearRect$I$I$I$I(0, 0, this.w, this.h);
this.gb.setColor$java_awt_Color(this.fgColor);
this.gb.fillRect$I$I$I$I(0, this.h - this.d, this.w, this.d);
this.g.setColor$java_awt_Color($I$(1).black);
this.g.drawString$S$I$I("density", 5, this.yy=this.y0 + this.w + 15 );
this.g.drawString$S$I$I("0.0", 5, this.yy - 15);
this.g.drawString$S$I$I("1.0", 5, 15);
this.g.drawRect$I$I$I$I(0, 0, this.area.width - 1, this.area.height - 1);
this.g.drawLine$I$I$I$I(this.xa, this.yc, this.xa, this.area.height);
this.g.drawLine$I$I$I$I(this.xx=this.xa + this.w + 2 * this.x0 , this.yc - this.h, this.xx, this.area.height);
this.g.drawRect$I$I$I$I(this.x0, this.y0, this.w, this.h);
this.g.drawLine$I$I$I$I(this.xa - this.w, this.yc, this.xa - this.w, this.yc + this.h);
this.g.drawLine$I$I$I$I(this.xa - this.w, this.yc + this.h, this.xa, this.yc + this.h);
this.g.setColor$java_awt_Color($I$(1).blue);
this.g.drawLine$I$I$I$I(this.xb=this.xx + 5, this.yc, this.area.width - 1, this.yc);
this.g.drawLine$I$I$I$I(this.xb, this.yc, this.xb, this.area.height - 1);
this.g.drawString$S$I$I("P", this.area.width - 15, this.yc - 5);
this.g.drawString$S$I$I("Y", this.xb + 5, this.area.height - 5);
this.g.drawLine$I$I$I$I(this.xb, this.yc, this.area.width - 1, this.yc + this.area.width - 1 - this.xb);
this.gb.setColor$java_awt_Color($I$(1).black);
this.gb.drawRect$I$I$I$I(0, 0, this.w - 1, this.h - 1);
}});

Clazz.newMeth(C$, 'redraw$', function () {
this.clear$();
this.repaint$();
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
this.updateScreen$java_awt_Graphics(g);
});

Clazz.newMeth(C$, ['updateScreen$java_awt_Graphics','updateScreen'], function (graphics) {
this.g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.blockImage, this.x1, this.yb, this);
this.g.setColor$java_awt_Color(this.bgColor);
this.g.drawLine$I$I$I$I(this.x1, this.yb - 1, this.x1 + this.w, this.yb - 1);
graphics.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.offImage, 0, this.yOffset, this);
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:12 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
