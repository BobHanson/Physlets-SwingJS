(function(){var P$=Clazz.newPackage("emwave4"),I$=[];
var C$=Clazz.newClass(P$, "Axis3D", null, 'emwave4.Figure');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$D$java_awt_Color', function (x, y, z, s, clr) {
Clazz.super_(C$, this,1);
this.numLines = 3;
this.c = clr;
this.pts = Clazz.array(Double.TYPE, [2 * this.numLines, 3]);
this.pts[0][0] = x;
this.pts[0][1] = y;
this.pts[0][2] = z;
this.pts[1][0] = s + x;
this.pts[1][1] = y;
this.pts[1][2] = z;
this.pts[2][0] = x;
this.pts[2][1] = y;
this.pts[2][2] = z;
this.pts[3][0] = x;
this.pts[3][1] = s + y;
this.pts[3][2] = z;
this.pts[4][0] = x;
this.pts[4][1] = y;
this.pts[4][2] = z;
this.pts[5][0] = x;
this.pts[5][1] = y;
this.pts[5][2] = s + z;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:36:49
