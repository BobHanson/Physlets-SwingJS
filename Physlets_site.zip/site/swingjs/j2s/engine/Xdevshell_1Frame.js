(function(){var P$=Clazz.newPackage("engine"),I$=[];
var C$=Clazz.newClass(P$, "Xdevshell_1Frame", null, 'java.awt.Frame');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$parent = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_applet_Applet', function (parentApplet) {
Clazz.super_(C$, this,1);
this.$parent = parentApplet;
}, 1);

Clazz.newMeth(C$, 'handleEvent$java_awt_Event', function (event) {
this.$parent.postEvent$java_awt_Event(event);
return C$.superclazz.prototype.handleEvent$java_awt_Event.apply(this, [event]);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:05:20
