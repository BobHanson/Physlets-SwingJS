(function(){var P$=Clazz.newPackage("filters"),I$=[['edu.davidson.tools.SApplet','edu.davidson.numerics.Parser',['filters.Outter','.Listener']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Outter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SDataSource');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.varStrings = null;
this.ds = null;
this.parserVars = null;
this.parserValues = null;
this.parser = null;
this.func = null;
this.listenerOne = null;
this.listenerTwo = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.varStrings = Clazz.array(java.lang.String, -1, ["surfacedata"]);
this.ds = null;
this.parserVars = null;
this.parserValues = null;
this.parser = null;
this.func = "0";
this.listenerOne = null;
this.listenerTwo = null;
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.parser=Clazz.new_((I$[2]||$incl$(2)).c$$I,[6]);
this.parserVars=Clazz.array(java.lang.String, [6]);
this.parserValues=Clazz.array(Double.TYPE, [6]);
this.parserVars[0]="x1";
this.parserVars[1]="y1";
this.parserVars[2]="y1minus";
this.parserVars[3]="x2";
this.parserVars[4]="y2";
this.parserVars[5]="y2minus";
this.func="0";
this.parser.defineVariables$SA(this.parserVars);
this.parser.parse();
edu.davidson.tools.SApplet.addDataSource$O(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Multiplexer Physlet writen by Wolfgang Christian.  wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
return null;
});

Clazz.newMeth(C$, 'getVariables', function () {
if (this.listenerOne == null  || this.listenerTwo == null  ) {
System.out.println$S("Warning: no data listeners in Multiplexer Physlet.");
this.ds=Clazz.array(Double.TYPE, [1, 1]);
return this.ds;
}var len1 = this.listenerOne.lastValues.length;
var len2 = this.listenerTwo.lastValues.length;
if (this.ds == null  || this.ds.length != len1  || this.ds[0].length != len2 ) this.ds=Clazz.array(Double.TYPE, [len1, len2]);
for (var row = 0; row < len1; row++) {
this.parserValues[0]=this.listenerOne.lastValues[row][0];
this.parserValues[1]=this.listenerOne.lastValues[row][1];
this.parserValues[2]=this.listenerOne.lastValues[len1 - row - 1 ][1];
for (var col = 0; col < len2; col++) {
this.parserValues[3]=this.listenerTwo.lastValues[col][0];
this.parserValues[4]=this.listenerTwo.lastValues[col][1];
this.parserValues[5]=this.listenerTwo.lastValues[len2 - col - 1 ][1];
this.ds[row][col]=this.parser.evaluate$DA(this.parserValues);
}
}
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.clock.stopClock();
this.deleteDataConnections();
this.clock.setContinuous();
this.clock.setTime$D(0);
this.func="0";
this.parser.define$S(this.func);
this.parser.parse();
});

Clazz.newMeth(C$, ['setFunction$S','setFunction'], function (funcStr) {
if (this.listenerOne == null  || this.listenerTwo == null  ) {
System.out.println$S("Create data listeners before you define the output function.");
return false;
}this.func=funcStr;
this.parser.defineVariables$SA(this.parserVars);
this.parser.define$S(this.func);
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
System.out.println$S("Failed to parse function): " + this.func);
System.out.println$S("Parse error in Outter: " + this.parser.getErrorString() + " at math fuinction, position " + this.parser.getErrorPosition() );
return false;
}return true;
});

Clazz.newMeth(C$, 'getFirstDataListener', function () {
if (this.listenerOne == null ) this.listenerOne=Clazz.new_((I$[3]||$incl$(3)).c$$I, [this, null, 1]);
return this.listenerOne.getID();
});

Clazz.newMeth(C$, 'getSecondDataListener', function () {
if (this.listenerTwo == null ) this.listenerTwo=Clazz.new_((I$[3]||$incl$(3)).c$$I, [this, null, 2]);
return this.listenerTwo.getID();
});
;
(function(){var C$=Clazz.newClass(P$.Outter, "Listener", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.index = 0;
this.xStr = null;
this.yStr = null;
this.active = false;
this.lastValues = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.index = 0;
this.xStr = "x0";
this.yStr = "y0";
this.active = true;
this.lastValues = Clazz.array(Double.TYPE, [1, 2]);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (i) {
C$.$init$.apply(this);
this.index=i;
this.xStr="x" + i;
this.yStr="y" + i;
try {
(I$[1]||$incl$(1)).addDataListener$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.this$0.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'deleteSeries$I', function (id) {
;});

Clazz.newMeth(C$, 'clearSeries$I', function (id) {
;});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (s, id, x, y) {
this.lastValues[0][0]=x;
this.lastValues[0][1]=y;
if (this.active) this.this$0.updateDataConnections();
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (s, id, x, y) {
if (x.length != this.lastValues.length) {
this.lastValues=Clazz.array(Double.TYPE, [x.length, 2]);
}for (var i = 0; i < x.length; i++) {
this.lastValues[i][0]=x[i];
this.lastValues[i][1]=y[i];
}
if (this.active) this.this$0.updateDataConnections();
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-07-23 12:59:29 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
