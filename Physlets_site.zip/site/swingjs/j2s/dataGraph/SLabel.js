(function(){var P$=Clazz.newPackage("dataGraph"),I$=[['edu.davidson.display.Format','java.awt.Dimension','java.awt.Color','edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SLabel", null, 'a2s.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.val = 0;
this.preferredW = 0;
this.chopVal = 0;
this.format = null;
this.formatI = null;
this.ms = null;
this.ps = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.val = 0;
this.preferredW = 20;
this.chopVal = 1.0E-12;
this.format = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+6.2g"]);
this.formatI = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+6d"]);
this.ms = Clazz.new_((I$[2]||$incl$(2)).c$$I$I,[20, 17]);
this.ps = Clazz.new_((I$[2]||$incl$(2)).c$$I$I,[this.preferredW, 17]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.setBackground$java_awt_Color((I$[3]||$incl$(3)).white);
}, 1);

Clazz.newMeth(C$, 'setValue$D', function (_val) {
this.val = _val;
this.repaint();
});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
this.format = Clazz.new_((I$[1]||$incl$(1)).c$$S,[str]);
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var h = this.getBounds().height;
var w = this.getBounds().width;
g.setColor$java_awt_Color(this.getBackground());
g.fillRect$I$I$I$I(0, 0, w, h);
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
var str;
if (Math.abs(this.val - (this.val|0)) <= this.chopVal ) str = this.formatI.form$J((this.val|0));
 else str = this.format.form$D((I$[4]||$incl$(4)).chop$D$D(this.val, this.chopVal));
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
var sw = fm.stringWidth$S(str);
if (sw > this.preferredW) {
this.preferredW = sw + 4;
this.ps = Clazz.new_((I$[2]||$incl$(2)).c$$I$I,[this.preferredW, 17]);
this.getParent().invalidate();
this.getParent().validate();
}g.drawString$S$I$I(str, ((w - sw)/2|0), h - fm.getDescent() - 2 );
});

Clazz.newMeth(C$, 'getMinimumSize', function () {
return this.ms;
});

Clazz.newMeth(C$, 'setMinimumSize$java_awt_Dimension', function (s) {
this.ms = s;
});

Clazz.newMeth(C$, 'getPreferredSize', function () {
return this.ps;
});

Clazz.newMeth(C$, 'setPreferredSize$java_awt_Dimension', function (s) {
this.ps = s;
});
})();
//Created 2018-03-17 21:37:04
