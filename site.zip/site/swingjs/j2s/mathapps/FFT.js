(function(){var P$=Clazz.newPackage("mathapps"),I$=[['edu.davidson.tools.SApplet','edu.davidson.graphics.EtchedBorder','java.awt.Button','java.awt.Label','java.awt.FlowLayout','java.awt.Panel','edu.davidson.display.SNumber','edu.davidson.display.SInteger','java.awt.TextField','java.awt.BorderLayout','mathapps.VerticalFlowLayout','Boolean','mathapps.FFT$1','java.awt.Color','java.awt.Frame','java.awt.Toolkit','jnt.fft.RealDoubleFFT_Even','edu.davidson.numerics.Parser',['mathapps.FFT','.MathFunction']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FFT", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataSource', 'edu.davidson.tools.SStepable']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.min = 0;
this.max = 0;
this.numPts = 0;
this.functionStr = null;
this.variableStr = null;
this.showControls = false;
this.explicitTime = false;
this.validFunction = false;
this.showDC = false;
this.dx = 0;
this.varStrings = null;
this.ds = null;
this.data = null;
this.parser = null;
this.fftPts = 0;
this.fft = null;
this.localTime = 0;
this.$function = null;
this.etchedBorder1 = null;
this.setBtn = null;
this.maxLabel = null;
this.flowLayout1 = null;
this.buttonPanel = null;
this.numLabel = null;
this.maxField = null;
this.minField = null;
this.panel3 = null;
this.panel2 = null;
this.panel1 = null;
this.numField = null;
this.minLabel2 = null;
this.panel4 = null;
this.label1 = null;
this.funcField = null;
this.borderLayout1 = null;
this.verticalFlowLayout1 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.explicitTime = false;
this.validFunction = false;
this.showDC = false;
this.varStrings = Clazz.array(java.lang.String, -1, ["n", "f", "fftcos", "fftsin", "fft"]);
this.ds = null;
this.data = null;
this.parser = null;
this.fft = null;
this.localTime = 0;
this.$function = null;
this.etchedBorder1 = Clazz.new_((I$[2]||$incl$(2)));
this.setBtn = Clazz.new_((I$[3]||$incl$(3)));
this.maxLabel = Clazz.new_((I$[4]||$incl$(4)));
this.flowLayout1 = Clazz.new_((I$[5]||$incl$(5)));
this.buttonPanel = Clazz.new_((I$[6]||$incl$(6)));
this.numLabel = Clazz.new_((I$[4]||$incl$(4)));
this.maxField = Clazz.new_((I$[7]||$incl$(7)));
this.minField = Clazz.new_((I$[7]||$incl$(7)));
this.panel3 = Clazz.new_((I$[6]||$incl$(6)));
this.panel2 = Clazz.new_((I$[6]||$incl$(6)));
this.panel1 = Clazz.new_((I$[6]||$incl$(6)));
this.numField = Clazz.new_((I$[8]||$incl$(8)));
this.minLabel2 = Clazz.new_((I$[4]||$incl$(4)));
this.panel4 = Clazz.new_((I$[6]||$incl$(6)));
this.label1 = Clazz.new_((I$[4]||$incl$(4)));
this.funcField = Clazz.new_((I$[9]||$incl$(9)));
this.borderLayout1 = Clazz.new_((I$[10]||$incl$(10)));
this.verticalFlowLayout1 = Clazz.new_((I$[11]||$incl$(11)));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.min=Double.$valueOf(this.getParameter$S$S("Min", "-1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.max=Double.$valueOf(this.getParameter$S$S("Max", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.numPts=Integer.parseInt(this.getParameter$S$S("NumPts", "64"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.functionStr=this.getParameter$S$S("Function", "sin(x*pi)");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.variableStr=this.getParameter$S$S("Variable", "x");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls=(I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.buttonPanel.setVisible$Z(this.showControls);
this.funcField.setText$S(this.functionStr);
this.setFunction$S$S(this.functionStr, this.variableStr);
this.setNumPts$I(this.numPts);
(I$[1]||$incl$(1)).addDataSource$O(this);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setBtn.setLabel$S("Set");
this.setBtn.setLabel$S("Set");
this.setBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "FFT$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['mathapps.FFT'].setBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[13]||$incl$(13)).$init$, [this, null])));
this.maxLabel.setAlignment$I(2);
this.maxLabel.setText$S("Max");
this.maxLabel.setAlignment$I(2);
this.maxLabel.setText$S("Max");
this.buttonPanel.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
this.buttonPanel.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.maxField.setValue$D(1.0);
this.numField.setValue$I(64);
this.minLabel2.setText$S("Min");
this.minLabel2.setAlignment$I(2);
this.minLabel2.setAlignment$I(2);
this.minLabel2.setText$S("Min");
this.etchedBorder1.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.verticalFlowLayout1);
this.label1.setAlignment$I(2);
this.label1.setText$S("f(x,t) = ");
this.funcField.setText$S("textField1");
this.panel4.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.verticalFlowLayout1.setAlignment$I(1);
this.verticalFlowLayout1.setVgap$I(2);
this.verticalFlowLayout1.setVerticalFill$Z(true);
this.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
this.add$java_awt_Component$O(this.etchedBorder1, null);
this.etchedBorder1.add$java_awt_Component$O(this.buttonPanel, null);
this.buttonPanel.add$java_awt_Component$O(this.setBtn, null);
this.buttonPanel.add$java_awt_Component$O(this.panel3, null);
this.panel3.add$java_awt_Component$O(this.minLabel2, null);
this.panel3.add$java_awt_Component$O(this.minField, null);
this.buttonPanel.add$java_awt_Component$O(this.panel2, null);
this.panel2.add$java_awt_Component$O(this.maxLabel, null);
this.panel2.add$java_awt_Component$O(this.maxField, null);
this.buttonPanel.add$java_awt_Component$O(this.panel1, null);
this.panel1.add$java_awt_Component$O(this.numLabel, null);
this.panel1.add$java_awt_Component$O(this.numField, null);
this.etchedBorder1.add$java_awt_Component$O(this.panel4, null);
this.panel4.add$java_awt_Component$O(this.label1, "West");
this.panel4.add$java_awt_Component$O(this.funcField, "Center");
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "FFT Physlet evaluates an analytic function and calculates its fast fourier transform.";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Min", "double", "Minimum value"]), Clazz.array(java.lang.String, -1, ["Max", "double", "Maximum value"]), Clazz.array(java.lang.String, -1, ["NumPts", "int", "Number of Points"]), Clazz.array(java.lang.String, -1, ["Function", "String", "The function string"]), Clazz.array(java.lang.String, -1, ["Variable", "String", "The independent variable."]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the user interface"])]);
return pinfo;
});

Clazz.newMeth(C$, 'main', function (args) {
var applet = Clazz.new_(C$);
applet.$isStandalone=true;
var frame;
frame=((
(function(){var C$=Clazz.newClass(P$, "FFT$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.Frame'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'processWindowEvent$java_awt_event_WindowEvent', function (e) {
C$.superclazz.prototype.processWindowEvent$java_awt_event_WindowEvent.apply(this, [e]);
if (e.getID() == 201) {
System.exit(0);
}});

Clazz.newMeth(C$, ['setTitle$S','setTitle'], function (title) {
C$.superclazz.prototype.setTitle$S.apply(this, [title]);
this.enableEvents$J(64);
});
})()
), Clazz.new_((I$[15]||$incl$(15)), [this, null],P$.FFT$2));
frame.setTitle$S("Applet Frame");
frame.add$java_awt_Component$O(applet, "Center");
applet.init();
applet.start();
frame.setSize$I$I(400, 320);
var d = (I$[16]||$incl$(16)).getDefaultToolkit().getScreenSize();
frame.setLocation$I$I(((d.width - frame.getSize().width)/2|0), ((d.height - frame.getSize().height)/2|0));
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, ['setNumPts$I','setNumPts'], function (n) {
if (n < 2) {
System.out.println$S("Number of points must be >1.");
}this.numPts=Math.max(2, n);
this.fftPts=this.numPts - this.numPts % 2;
this.dx=(this.max - this.min) / (this.numPts - 1);
this.ds=Clazz.array(Double.TYPE, [this.fftPts - 1, 5]);
this.data=Clazz.array(Double.TYPE, [this.fftPts]);
if (this.$function != null ) this.$function.setNum$I(this.fftPts);
this.fft=Clazz.new_((I$[17]||$incl$(17)).c$$I,[this.fftPts]);
this.setMinMax$D$D(this.min, this.max);
if (this.showControls && this.getBounds().width > 50 ) {
this.numField.setValue$I(this.numPts);
this.minField.setValue$D(this.min);
this.maxField.setValue$D(this.max);
}});

Clazz.newMeth(C$, ['setShowDC$Z','setShowDC'], function (set) {
if (this.showDC == set ) return;
this.showDC=set;
if (this.autoRefresh) {
this.evaluate();
this.updateDataConnections();
}});

Clazz.newMeth(C$, ['setMinMax$D$D','setMinMax'], function (min_, max_) {
if (this.parser == null  || !this.validFunction ) {
System.out.println$S("Invalid function.");
return;
}this.max=max_;
this.min=min_;
if (this.max < this.min ) {
System.out.println$S("Maximum must be >  minimum.");
var temp = this.max;
this.max=this.min;
this.min=temp;
}if (this.max == this.min ) {
System.out.println$S("Maximum cannot be =  minimum.");
this.max=this.max + 1.0;
}var fmin = 1 / (this.max - this.min);
var numHalf = (this.fftPts/2|0);
for (var i = 0; i < this.fftPts - 1; i++) {
this.ds[i][0]=i;
this.ds[i][1]=(-numHalf + i + 1 ) * fmin;
this.ds[i][2]=0;
this.ds[i][3]=0;
this.ds[i][4]=0;
}
var dx = (this.max - this.min) / (this.numPts - 1);
var val = this.min;
if (this.$function != null ) for (var i = 0; i < this.fftPts; i++) {
this.$function.v[i][0]=val;
this.$function.v[i][1]=0;
val += dx;
}
if (this.showControls && this.getBounds().width > 50 ) {
this.minField.setValue$D(this.min);
this.maxField.setValue$D(this.max);
}if (this.autoRefresh) {
this.evaluate();
this.updateDataConnections();
}});

Clazz.newMeth(C$, 'evaluate', function () {
var dx = (this.max - this.min) / (this.numPts - 1);
var val = this.min;
for (var i = 0; i < this.fftPts; i++) {
if (this.explicitTime) this.data[i]=this.parser.evaluate$D$D(val, this.localTime);
 else this.data[i]=this.parser.evaluate$D(val);
val += dx;
if (this.$function != null ) this.$function.v[i][1]=this.data[i];
}
this.fft.transform$DA(this.data);
this.data=this.fft.toWraparoundOrder$DA(this.data);
if (!this.showDC) this.data[0]=0;
var numHalf = (this.fftPts/2|0);
for (var i = 0; i < numHalf; i++) {
this.ds[i + numHalf - 1][2]=this.data[2 * i] / numHalf;
this.ds[i][2]=this.data[this.fftPts - 2 * i - 2] / numHalf;
this.ds[i + numHalf - 1][3]=this.data[2 * i + 1] / numHalf;
this.ds[i][3]=this.data[this.fftPts - 2 * i - 1] / numHalf;
this.ds[i + numHalf - 1][4]=Math.sqrt(this.ds[i + numHalf - 1][2] * this.ds[i + numHalf - 1][2] + this.ds[i + numHalf - 1][3] * this.ds[i + numHalf - 1][3]);
this.ds[i][4]=Math.sqrt(this.ds[i][2] * this.ds[i][2] + this.ds[i][3] * this.ds[i][3]);
}
});

Clazz.newMeth(C$, 'parseOneVariable$S', function (string) {
var oneFunc = Clazz.new_((I$[18]||$incl$(18)).c$$I,[1]);
var str =  String.instantialize(string);
oneFunc.defineVariable$I$S(1, this.variableStr);
oneFunc.define$S(str.toLowerCase());
oneFunc.parse();
if (oneFunc.getErrorCode() != 0) {
this.validFunction=false;
return false;
}this.validFunction=true;
this.explicitTime=false;
this.parser=oneFunc;
this.functionStr=string;
return true;
});

Clazz.newMeth(C$, 'parseTwoVariables$S', function (string) {
var twoFunc = Clazz.new_((I$[18]||$incl$(18)).c$$I,[2]);
var str =  String.instantialize(string);
twoFunc.defineVariable$I$S(1, this.variableStr);
twoFunc.defineVariable$I$S(2, "t");
twoFunc.define$S(str.toLowerCase());
twoFunc.parse();
if (twoFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse f(x,t)): " + str);
System.out.println$S("Parse error in MathFunction: " + twoFunc.getErrorString() + " at function 1, position " + twoFunc.getErrorPosition() );
p$.parseOneVariable$S.apply(this, ["0"]);
this.validFunction=false;
return false;
}this.validFunction=true;
this.explicitTime=true;
this.parser=twoFunc;
this.functionStr=string;
return true;
});

Clazz.newMeth(C$, ['setFunction$S$S','setFunction'], function ($function, variable) {
this.variableStr= String.instantialize(variable.trim().toLowerCase());
var str = $function.trim();
if (!p$.parseOneVariable$S.apply(this, [str])) p$.parseTwoVariables$S.apply(this, [str]);
if (this.ds == null ) this.setNumPts$I(this.numPts);
 else this.setMinMax$D$D(this.min, this.max);
return this.validFunction;
});

Clazz.newMeth(C$, ['setFunctionStr$S','setFunctionStr'], function ($function) {
var str = $function.trim();
this.setFunction$S$S(str, this.variableStr);
return this.validFunction;
});

Clazz.newMeth(C$, ['getFunctionStr$S','getFunctionStr'], function (string) {
return this.functionStr;
});

Clazz.newMeth(C$, 'getFunctionID', function () {
if (this.$function != null ) return this.$function.getID();
this.$function=Clazz.new_((I$[19]||$incl$(19)).c$$I, [this, null, this.fftPts]);
var dx = (this.max - this.min) / (this.numPts - 1);
var val = this.min;
for (var i = 0; i < this.fftPts; i++) {
this.$function.v[i][0]=val;
if (this.explicitTime) this.data[i]=this.parser.evaluate$D$D(val, this.localTime);
 else this.data[i]=this.parser.evaluate$D(val);
this.$function.v[i][1]=this.data[i];
val += dx;
}
return this.$function.getID();
});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
if (this.parser == null  || !this.validFunction ) {
System.out.println$S("Invalid function.");
return;
}this.localTime=time + dt;
if (this.explicitTime) this.evaluate();
this.updateDataConnections();
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (refresh) {
if (this.autoRefresh == refresh ) return;
this.autoRefresh=refresh;
if (refresh) this.evaluate();
});

Clazz.newMeth(C$, 'setDefault', function () {
this.deleteDataConnections();
this.clock.stopClock();
this.clock.setTime$D(0);
this.localTime=0;
this.$function=null;
});

Clazz.newMeth(C$, 'reset', function () {
this.clock.stopClock();
this.clock.setTime$D(0);
this.localTime=0;
if (this.autoRefresh) {
this.evaluate();
this.updateDataConnections();
}});

Clazz.newMeth(C$, 'setBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.min=this.minField.getValue();
this.max=this.maxField.getValue();
this.autoRefresh=false;
this.setFunctionStr$S(this.funcField.getText());
this.autoRefresh=true;
this.setNumPts$I(this.numField.getValue());
});
;
(function(){var C$=Clazz.newClass(P$.FFT, "MathFunction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.v = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y"]);
this.v = null;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (num) {
C$.$init$.apply(this);
this.v=Clazz.array(Double.TYPE, [num, 2]);
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'setNum$I', function (num) {
if (this.v != null  && this.v.length == num ) return;
this.v=Clazz.array(Double.TYPE, [num, 2]);
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.v;
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-07-20 18:09:37
