(function(){var P$=Clazz.newPackage("java.awt.dnd.peer"),I$=[];
var C$=Clazz.newInterface(P$, "DropTargetContextPeer");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-23 09:05:20 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
