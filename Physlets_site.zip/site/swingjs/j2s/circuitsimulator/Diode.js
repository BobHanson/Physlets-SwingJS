(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Diode", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.nv = 0;
this.ov = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.ov = 0;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$I$S', function (circuit, isat, d, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circuit, d, r, c, t]);
C$.$init$.apply(this);
this.value = isat;
this.unity = "A";
this.leftlinear = false;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'impedance', function () {
this.nv = this.ov;
this.ov = this.getV();
this.nv = this.nv == 0  ? 1.0 / (this.value * 38.9) : this.nv / (this.value * (Math.exp(38.9 * this.nv) - 1.0));
return Math.abs(this.nv);
});

Clazz.newMeth(C$, 'rightFunction$D', function (sign) {
return 0;
});

Clazz.newMeth(C$, 'valueStr', function () {
return this.$function;
});

Clazz.newMeth(C$, 'getStringAdditions', function () {
return ",isat=" + Double.toString(this.value);
});

Clazz.newMeth(C$, 'set$S', function (list) {
var ret = C$.superclazz.prototype.set$S.apply(this, [list]);
if ((I$[1]||$incl$(1)).parameterExist$S$S(list, "isat=")) this.value = (I$[1]||$incl$(1)).getParam$S$S(list, "isat=");
return ret;
});
})();
//Created 2018-02-06 06:55:33
