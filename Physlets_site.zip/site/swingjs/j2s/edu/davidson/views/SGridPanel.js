(function(){var P$=Clazz.newPackage("edu.davidson.views"),I$=[['edu.davidson.tools.SApplet','edu.davidson.graphics.EtchedBorder','java.awt.Panel','java.awt.Label','java.awt.TextField','java.awt.BorderLayout','java.awt.Button','edu.davidson.graphics.SPanel','edu.davidson.views.SGrid','java.awt.ScrollPane','java.awt.Color','edu.davidson.views.SGridPanel$1','edu.davidson.graphics.Util','java.net.URL','java.io.StreamTokenizer',['edu.davidson.views.SGridPanel','.SeriesDataSource']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SGridPanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.graphics.EtchedBorder', 'edu.davidson.tools.SDataListener');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.showScrollBars = false;
this.owner = null;
this.scrollPane = null;
this.controlPanel = null;
this.panel2 = null;
this.label1 = null;
this.panel3 = null;
this.colField = null;
this.label2 = null;
this.borderLayout2 = null;
this.panel4 = null;
this.enterBtn = null;
this.rowField = null;
this.label3 = null;
this.borderLayout1 = null;
this.panel1 = null;
this.cellField = null;
this.borderLayout3 = null;
this.autosizeGrid = false;
this.sgrid = null;
this.borderLayout4 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.showScrollBars = true;
this.owner = null;
this.controlPanel = Clazz.new_((I$[2]||$incl$(2)));
this.panel2 = Clazz.new_((I$[3]||$incl$(3)));
this.label1 = Clazz.new_((I$[4]||$incl$(4)));
this.panel3 = Clazz.new_((I$[3]||$incl$(3)));
this.colField = Clazz.new_((I$[5]||$incl$(5)));
this.label2 = Clazz.new_((I$[4]||$incl$(4)));
this.borderLayout2 = Clazz.new_((I$[6]||$incl$(6)));
this.panel4 = Clazz.new_((I$[3]||$incl$(3)));
this.enterBtn = Clazz.new_((I$[7]||$incl$(7)));
this.rowField = Clazz.new_((I$[5]||$incl$(5)));
this.label3 = Clazz.new_((I$[4]||$incl$(4)));
this.borderLayout1 = Clazz.new_((I$[6]||$incl$(6)));
this.panel1 = Clazz.new_((I$[8]||$incl$(8)));
this.cellField = Clazz.new_((I$[5]||$incl$(5)));
this.borderLayout3 = Clazz.new_((I$[6]||$incl$(6)));
this.autosizeGrid = false;
this.sgrid = Clazz.new_((I$[9]||$incl$(9)).c$$edu_davidson_views_SGridPanel,[this]);
this.borderLayout4 = Clazz.new_((I$[6]||$incl$(6)));
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$Z', function (o, sb) {
Clazz.super_(C$, this,1);
this.showScrollBars = sb;
if (this.showScrollBars) this.scrollPane = Clazz.new_((I$[10]||$incl$(10)).c$$I,[0]);
 else this.scrollPane = Clazz.new_((I$[3]||$incl$(3)));
try {
this.setLayout$java_awt_LayoutManager(Clazz.new_((I$[6]||$incl$(6))));
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.setBackground$java_awt_Color((I$[11]||$incl$(11)).lightGray);
this.owner = o;
try {
(I$[1]||$incl$(1)).addDataListener$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'jbInit', function () {
if (!this.showScrollBars) this.scrollPane.setLayout$java_awt_LayoutManager(this.borderLayout4);
this.panel2.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.controlPanel.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.label1.setAlignment$I(2);
this.label1.setText$S("Cell:");
this.colField.setText$S("A");
this.label2.setAlignment$I(2);
this.label2.setText$S("C:");
this.enterBtn.setLabel$S("Enter");
this.enterBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "SGridPanel$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['edu.davidson.views.SGridPanel'].enterBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[12]||$incl$(12)).$init$, [this, null])));
this.rowField.setText$S("1");
this.label3.setAlignment$I(2);
this.label3.setText$S("R:");
this.panel1.setVinsets$I(5);
this.panel1.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.add$java_awt_Component$O(this.scrollPane, "Center");
if (this.showScrollBars) this.scrollPane.add$java_awt_Component$O(this.sgrid, null);
 else this.scrollPane.add$java_awt_Component$O(this.sgrid, "Center");
this.add$java_awt_Component$O(this.controlPanel, "North");
this.controlPanel.add$java_awt_Component$O(this.panel3, "West");
this.panel3.add$java_awt_Component$O(this.label3, null);
this.panel3.add$java_awt_Component$O(this.rowField, null);
this.panel3.add$java_awt_Component$O(this.label2, null);
this.panel3.add$java_awt_Component$O(this.colField, null);
this.controlPanel.add$java_awt_Component$O(this.panel2, "Center");
this.panel2.add$java_awt_Component$O(this.label1, "West");
this.panel2.add$java_awt_Component$O(this.panel1, "Center");
this.panel1.add$java_awt_Component$O(this.cellField, "Center");
this.controlPanel.add$java_awt_Component$O(this.panel4, "East");
this.panel4.add$java_awt_Component$O(this.enterBtn, null);
});

Clazz.newMeth(C$, 'setNumericFormat$I$S', function (sid, str) {
this.sgrid.setNumericFormat$I$S(sid, str);
});

Clazz.newMeth(C$, 'setShowActiveCell$Z', function (show) {
this.sgrid.setShowActiveCell$Z(show);
});

Clazz.newMeth(C$, 'getActiveCellValue', function () {
return this.sgrid.getActiveCellValue();
});

Clazz.newMeth(C$, 'initCells$I$I', function (r, c) {
this.sgrid.initCells$I$I(r + 1, c + 1);
});

Clazz.newMeth(C$, 'setAutoRefresh$Z', function (auto) {
this.sgrid.setAutoRefresh$Z(auto);
});

Clazz.newMeth(C$, 'setShowRowHeader$Z', function (showRowHeader) {
this.sgrid.setShowRowHeader$Z(showRowHeader);
});

Clazz.newMeth(C$, 'setShowColHeader$Z', function (showColHeader) {
this.sgrid.setShowColHeader$Z(showColHeader);
});

Clazz.newMeth(C$, 'setLastOnTop$Z', function (lot) {
this.sgrid.setLastOnTop$Z(lot);
});

Clazz.newMeth(C$, 'setShowControls$Z', function (sc) {
this.controlPanel.setVisible$Z(sc);
if (this.owner != null ) this.owner.invalidate();
});

Clazz.newMeth(C$, 'getActiveCellRow', function () {
return this.sgrid.getActiveCellRow();
});

Clazz.newMeth(C$, 'getActiveCellCol', function () {
return this.sgrid.getActiveCellCol();
});

Clazz.newMeth(C$, 'setActiveCellValue$D', function (val) {
return this.sgrid.setActiveCellValue$D(val);
});

Clazz.newMeth(C$, 'setActiveCell$I$I', function (row, col) {
return this.sgrid.setActiveCell$I$I(row, col);
});

Clazz.newMeth(C$, 'loadFile$I$S', function (series, file) {
var applet = this.owner;
if (applet == null ) applet = (I$[13]||$incl$(13)).getApplet$java_awt_Component(this);
if (applet == null ) {
System.out.println$S("File load failed. Aplet not found.");
return;
}var temp = this.sgrid.autoRefresh;
this.sgrid.autoRefresh = false;
this.clearSeries$I(series);
try {
var is = Clazz.new_((I$[14]||$incl$(14)).c$$java_net_URL$S,[applet.getDocumentBase(), file]).openStream();
this.readFile$I$java_io_InputStream(series, is);
is.close();
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
System.out.println$S("file load failed: " + ex.getMessage());
} else {
throw ex;
}
}
this.sgrid.autoRefresh = temp;
if (this.sgrid.autoRefresh) {
this.sgrid.paintOsi();
}});

Clazz.newMeth(C$, 'readFile$I$java_io_InputStream', function (series, is) {
var x;
var y;
var st = Clazz.new_((I$[15]||$incl$(15)).c$$java_io_InputStream,[is]);
st.eolIsSignificant$Z(true);
st.commentChar$I("#".$c());
scan : while (st.ttype != -1){
switch (st.nextToken()) {
default:
break scan;
case 10:
break;
case -3:
if ("series".equals$O(st.sval)) {
st.nextToken();
series = (st.nval|0);
this.clearSeries$I(series);
break;
}case -2:
x = st.nval;
this.addDatum$I$D$D(series, x, 0);
break;
}
while (st.ttype != 10 && st.ttype != -1 )st.nextToken();

}
});

Clazz.newMeth(C$, 'setDataStride$I$I', function (id, stride) {
this.sgrid.setDataStride$I$I(id, stride);
});

Clazz.newMeth(C$, 'setSeriesLabel$I$S', function (series, str) {
return this.sgrid.setColLabel$I$S(series, str);
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'addDatum$I$D$D', function (id, x, y) {
this.sgrid.addDatum$I$D(id, x);
this.owner.updateDataConnections();
});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (s, id, x, y) {
this.sgrid.addDatum$I$D(id, x);
if (s.getOwner() !== this.owner ) this.owner.updateDataConnections();
});

Clazz.newMeth(C$, 'addData$I$DA$DA', function (id, x, y) {
this.sgrid.addData$I$DA(id, x);
this.owner.updateDataConnections();
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (s, id, x, y) {
this.sgrid.addData$I$DA(id, x);
if (s.getOwner() !== this.owner ) this.owner.updateDataConnections();
});

Clazz.newMeth(C$, 'setDefault', function () {
this.owner.deleteDataConnections();
this.sgrid.setDefault();
if (this.autosizeGrid) this.sgrid.sizeToFit();
 else this.sgrid.setGridSize();
});

Clazz.newMeth(C$, 'setDefaultCellWidth$I', function (dcw) {
this.sgrid.setDefaultCellWidth$I(dcw);
});

Clazz.newMeth(C$, 'deleteSeries$I', function (id) {
this.sgrid.clearSeries$I(id);
});

Clazz.newMeth(C$, 'clearSeries$I', function (id) {
this.sgrid.clearSeries$I(id);
});

Clazz.newMeth(C$, 'clearAllSeries', function () {
this.sgrid.clearAllSeries();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (o) {
this.owner = o;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'setFormat$edu_davidson_tools_SDataSource$S', function (ds, fstr) {
if (Clazz.instanceOf(ds, "edu.davidson.views.SGridPanel.SeriesDataSource")) {
var sid = (ds).sid;
return this.sgrid.setNumericFormat$I$S(sid, fstr);
} else return false;
});

Clazz.newMeth(C$, 'setFormat$S', function (fstr) {
return this.sgrid.setFormat$S(fstr);
});

Clazz.newMeth(C$, 'getSeriesWidth$I', function (id) {
return this.sgrid.getColWidth$I(id);
});

Clazz.newMeth(C$, 'setSeriesWidth$I$I', function (id, width) {
this.sgrid.setColWidth$I$I(id, width);
});

Clazz.newMeth(C$, 'sizeToFit$Z', function (stf) {
this.autosizeGrid = stf;
if (stf) this.sgrid.sizeToFit();
 else this.sgrid.setGridSize();
});

Clazz.newMeth(C$, 'enterBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
var row = 0;
try {
row = ( new Integer(this.rowField.getText())).intValue();
this.rowField.setBackground$java_awt_Color((I$[11]||$incl$(11)).white);
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.NumberFormatException")){
this.rowField.setBackground$java_awt_Color((I$[11]||$incl$(11)).red);
return;
} else {
throw ex;
}
}
var col = this.sgrid.getCol$S(this.colField.getText());
if (col < 0) {
this.colField.setBackground$java_awt_Color((I$[11]||$incl$(11)).red);
return;
} else this.colField.setBackground$java_awt_Color((I$[11]||$incl$(11)).white);
this.sgrid.setHighlight$I$I(row, col);
this.sgrid.setCell$I$I$S(row, col, this.cellField.getText());
});

Clazz.newMeth(C$, 'getSeriesID$I', function (sid) {
var source = Clazz.new_((I$[16]||$incl$(16)).c$$I, [this, null, sid]);
return source.hashCode();
});
;
(function(){var C$=Clazz.newClass(P$.SGridPanel, "SeriesDataSource", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.ds = null;
this.sid = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "dx"]);
this.ds = Clazz.array(Double.TYPE, [1, 2]);
this.sid = 0;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (_sid) {
C$.$init$.apply(this);
this.sid = _sid;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
var len = this.this$0.sgrid.getNextRow$I(this.sid) - 1;
if (len > 0) this.ds = Clazz.array(Double.TYPE, [len, 2]);
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
var len = this.this$0.sgrid.getNextRow$I(this.sid) - 1;
if (this.ds == null  || this.ds.length != len ) this.ds = Clazz.array(Double.TYPE, [len, 2]);
for (var i = 0; i < this.ds.length; i++) {
this.ds[i][0] = this.this$0.sgrid.getCellValue$I$I(i + 1, this.sid);
}
for (var i = 0; i < this.ds.length - 1; i++) {
this.ds[i][1] = this.ds[i + 1][0] - this.ds[i][0];
}
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0.owner;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-08 01:51:46
