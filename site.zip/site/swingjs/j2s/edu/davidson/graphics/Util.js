(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['java.awt.MediaTracker','edu.davidson.graphics.Assert','java.awt.Cursor','edu.davidson.tools.SClock','java.net.URL']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Util");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getDialog$java_awt_Component', function (c) {
if (Clazz.instanceOf(c, "a2s.Dialog")) return c;
while ((c=c.getParent()) != null ){
if (Clazz.instanceOf(c, "a2s.Dialog")) return c;
}
return null;
}, 1);

Clazz.newMeth(C$, 'getFrame$java_awt_Component', function (c) {
if (Clazz.instanceOf(c, "a2s.Frame")) return c;
while ((c=c.getParent()) != null ){
if (Clazz.instanceOf(c, "a2s.Frame")) return c;
}
return null;
}, 1);

Clazz.newMeth(C$, 'getApplet$java_awt_Component', function (c) {
if (Clazz.instanceOf(c, "a2s.Applet")) return c;
while ((c=c.getParent()) != null ){
if (Clazz.instanceOf(c, "a2s.Applet")) return c;
}
return null;
}, 1);

Clazz.newMeth(C$, 'waitForImage$java_awt_Component$java_awt_Image', function (component, image) {
var tracker = Clazz.new_((I$[1]||$incl$(1)).c$$java_awt_Component,[component]);
try {
tracker.addImage$java_awt_Image$I(image, 0);
tracker.waitForID$I$J(0, 10000);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'wallPaper$java_awt_Component$java_awt_Graphics$java_awt_Image', function (component, g, image) {
var compsize = component.getSize();
C$.waitForImage$java_awt_Component$java_awt_Image(component, image);
var patchW = image.getWidth$java_awt_image_ImageObserver(component);
var patchH = image.getHeight$java_awt_image_ImageObserver(component);
(I$[2]||$incl$(2)).notFalse$Z(patchW != -1 && patchH != -1 );
for (var r = 0; r < compsize.width; r+=patchW) {
for (var c = 0; c < compsize.height; c+=patchH) g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(image, r, c, component);

}
}, 1);

Clazz.newMeth(C$, 'stretchImage$java_awt_Component$java_awt_Graphics$java_awt_Image', function (component, g, image) {
var sz = component.getSize();
C$.waitForImage$java_awt_Component$java_awt_Image(component, image);
g.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(image, 0, 0, sz.width, sz.height, component);
}, 1);

Clazz.newMeth(C$, 'setCursor$I$java_awt_Component', function (cursor, component) {
component.setCursor$java_awt_Cursor((I$[3]||$incl$(3)).getPredefinedCursor$I(cursor));
}, 1);

Clazz.newMeth(C$, 'isMicrosoft', function () {
if ((I$[4]||$incl$(4)).isJS) {
return false;
}var vendor = System.getProperty("java.vendor").toLowerCase();
return (vendor.startsWith$S("microsoft"));
}, 1);

Clazz.newMeth(C$, 'getImage$S$a2s_Applet', function (file, applet) {
var im = null;
var url;
if (applet == null ) System.out.println$S("Applet not found in getImage method.");
try {
var resourcePath = file;
if (!file.startsWith$S("/")) resourcePath="/" + file;
url=Clazz.getClass(C$).getResource$S(resourcePath);
im=applet.getImage$java_net_URL(url);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
im=null;
} else {
throw e;
}
}
if (im == null ) try {
im=applet.getImage$java_net_URL$S(applet.getCodeBase(), file);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
im=null;
} else {
throw e;
}
}
if (im == null ) try {
im=applet.getImage$java_net_URL$S(applet.getDocumentBase(), file);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
im=null;
} else {
throw e;
}
}
if (im == null ) try {
url=Clazz.new_((I$[5]||$incl$(5)).c$$S,[file]);
im=applet.getImage$java_net_URL(url);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
im=null;
} else {
throw e;
}
}
if (im == null ) {
System.out.println$S("Failed to load image file. file=" + file);
return im;
}var tracker = Clazz.new_((I$[1]||$incl$(1)).c$$java_awt_Component,[applet]);
try {
tracker.addImage$java_awt_Image$I(im, 0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return im;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:40
