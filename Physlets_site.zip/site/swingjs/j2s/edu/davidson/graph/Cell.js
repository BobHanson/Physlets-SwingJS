(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[];
var C$=Clazz.newClass(P$, "Cell");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.i = 0;
this.j = 0;
this.face = null;
this.visited = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.face = Clazz.array(Integer.TYPE, [2]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.i = -1;
this.j = -1;
this.face[0] = 0;
this.face[1] = 0;
}, 1);
})();
//Created 2018-02-25 19:20:26
