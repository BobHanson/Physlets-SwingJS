(function(){var P$=Clazz.newPackage("filters"),I$=[['edu.davidson.tools.SApplet',['filters.Integral','.Definite'],'edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Integral", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataListener', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.xiStr = null;
this.xIntegrand = null;
this.yiStr = null;
this.yIntegrand = null;
this.definite = null;
this.varStrings = null;
this.variables = null;
this.n = 0;
this.sumX = 0;
this.sumY = 0;
this.lastX = 0;
this.lastY = 0;
this.lastXIntegrand = 0;
this.lastYIntegrand = 0;
this.dx = 0;
this.dy = 0;
this.ds = 0;
this.$isStandalone = false;
this.mode = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.xIntegrand = null;
this.yIntegrand = null;
this.definite = Clazz.new_((I$[2]||$incl$(2)).c$$edu_davidson_tools_SApplet, [this, null, this]);
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "n", "integral", "ds"]);
this.variables = null;
this.n = 0;
this.sumX = 0;
this.sumY = 0;
this.lastX = 0;
this.lastY = 0;
this.dx = 0;
this.dy = 0;
this.ds = 0;
this.$isStandalone = false;
this.mode = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
try {
(I$[1]||$incl$(1)).addDataListener$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'init', function () {
var diffStr = "dx";
var maxPoints = 500;
try {
this.varStrings[0]=this.getParameter$S$S("Independent", "x");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
diffStr=this.getParameter$S$S("Differential", "dx");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xiStr=this.getParameter$S$S("Integrand", this.varStrings[1]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
maxPoints=Integer.parseInt(this.getParameter$S$S("MaxPoints", "500"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.variables=Clazz.array(Double.TYPE, [maxPoints, 5]);
this.yiStr= String.instantialize(this.xiStr);
diffStr=diffStr.toLowerCase();
if (diffStr.equals$O("dx")) this.mode=0;
 else if (diffStr.equals$O("dy")) this.mode=1;
 else if (diffStr.equals$O("ds")) this.mode=2;
 else {
this.mode=0;
System.out.println$S("Differential parameter invalid. Use dx, dy or ds.");
}});

Clazz.newMeth(C$, 'parseXIntegrand$edu_davidson_tools_SDataSource', function (s) {
this.xiStr=this.xiStr.trim();
this.xiStr=this.xiStr.toLowerCase();
var num = s.getVarStrings().length;
this.xIntegrand=Clazz.new_((I$[3]||$incl$(3)).c$$I,[num]);
for (var i = 0; i < num; i++) {
this.xIntegrand.defineVariable$I$S(1 + i, s.getVarStrings()[i]);
}
this.xIntegrand.define$S(this.xiStr);
this.xIntegrand.parse();
if (this.xIntegrand.getErrorCode() != 0) {
System.out.println$S("Failed to parse the x integrand in filters.Integrator: " + this.xiStr);
System.out.println$S("Parse error: " + this.xIntegrand.getErrorString() + " at function 1, position " + this.xIntegrand.getErrorPosition() );
this.xIntegrand=null;
return false;
}return true;
});

Clazz.newMeth(C$, 'parseYIntegrand$edu_davidson_tools_SDataSource', function (s) {
this.yiStr=this.yiStr.trim();
this.yiStr=this.yiStr.toLowerCase();
var num = s.getVarStrings().length;
this.yIntegrand=Clazz.new_((I$[3]||$incl$(3)).c$$I,[num]);
for (var i = 0; i < num; i++) {
this.yIntegrand.defineVariable$I$S(1 + i, s.getVarStrings()[i]);
}
this.yIntegrand.define$S(this.yiStr);
this.yIntegrand.parse();
if (this.yIntegrand.getErrorCode() != 0) {
System.out.println$S("Failed to parse the y integrand in filters.Integrator: " + this.yiStr);
System.out.println$S("Parse error: " + this.yIntegrand.getErrorString() + " at function 1, position " + this.yIntegrand.getErrorPosition() );
this.yIntegrand=null;
return false;
}return true;
});

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Integrator Physlets";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Integrand", "String", "Integrand"]), Clazz.array(java.lang.String, -1, ["Differential", "String", "Differential"])]);
return pinfo;
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.variables;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, 'reset', function () {
this.sumX=0;
this.sumY=0;
this.n=0;
this.updateDataConnections();
});

Clazz.newMeth(C$, ['setLineIntegralMode$S$S','setLineIntegralMode'], function (xComponent, yComponent) {
this.mode=3;
this.xIntegrand=null;
this.yIntegrand=null;
this.xiStr=xComponent;
this.yiStr=yComponent;
this.sumX=0;
this.sumY=0;
this.n=0;
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, x, y) {
if (this.xIntegrand == null  && this.xiStr != null  ) p$.parseXIntegrand$edu_davidson_tools_SDataSource.apply(this, [s]);
if (this.yIntegrand == null  && this.yiStr != null  ) p$.parseYIntegrand$edu_davidson_tools_SDataSource.apply(this, [s]);
this.dx=(x - this.lastX);
this.dy=(y - this.lastY);
this.ds=Math.sqrt(this.dx * this.dx + this.dy * this.dy);
var tmp = 0;
if (this.n > 0) switch (this.mode) {
case 0:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += (tmp + this.lastXIntegrand) * this.dx / 2;
this.lastXIntegrand=tmp;
break;
case 1:
if (this.yIntegrand != null ) tmp=this.yIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumY += (tmp + this.lastYIntegrand) * this.dy / 2;
this.lastYIntegrand=tmp;
break;
case 2:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += (tmp + this.lastXIntegrand) * this.ds / 2;
this.lastXIntegrand=tmp;
break;
case 3:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += (tmp + this.lastXIntegrand) * this.dx / 2;
this.lastXIntegrand=tmp;
if (this.yIntegrand != null ) tmp=this.yIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumY += (tmp + this.lastYIntegrand) * this.dy / 2;
this.lastYIntegrand=tmp;
break;
default:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(s.getVariables()[0]);
 else break;
this.sumX += (tmp + this.lastXIntegrand) * this.dx / 2;
this.lastXIntegrand=tmp;
}
this.lastX=x;
this.lastY=y;
if (this.n < this.variables.length) {
this.variables[this.n][0]=this.lastX;
this.variables[this.n][1]=this.lastY;
this.variables[this.n][2]=this.n;
this.variables[this.n][3]=this.sumX + this.sumY;
if (this.n > 0) this.variables[this.n][4]=this.ds;
 else this.variables[this.n][4]=0;
}for (var i = this.n + 1; i < this.variables.length; i++) {
this.variables[i][0]=this.lastX;
this.variables[i][1]=this.lastY;
this.variables[i][2]=i;
this.variables[i][3]=this.sumX + this.sumY;
this.variables[i][4]=0;
}
this.n++;
this.updateDataConnections();
});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
this.n=x.length;
if (this.n < 2) return;
if (this.n != this.variables.length) this.variables=Clazz.array(Double.TYPE, [this.n, 5]);
if (this.xIntegrand == null  && this.xiStr != null  ) p$.parseXIntegrand$edu_davidson_tools_SDataSource.apply(this, [s]);
if (this.yIntegrand == null  && this.yiStr != null  ) p$.parseYIntegrand$edu_davidson_tools_SDataSource.apply(this, [s]);
this.sumX=0;
this.sumY=0;
var tmp = 0;
this.dx=(x[1] - x[0]) / 2;
this.dy=(y[1] - y[0]) / 2;
var sourceVars = s.getVariables();
for (var i = 0; i < this.n; i++) {
this.ds=Math.sqrt(this.dx * this.dx + this.dy * this.dy);
switch (this.mode) {
case 0:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(sourceVars[i]);
 else break;
this.sumX += tmp * this.dx;
break;
case 1:
if (this.yIntegrand != null ) tmp=this.yIntegrand.evaluate$DA(sourceVars[i]);
 else break;
this.sumY += tmp * this.dy;
break;
case 2:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(sourceVars[i]);
 else break;
this.sumX += tmp * this.ds;
break;
case 3:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(sourceVars[i]);
 else break;
this.sumX += tmp * this.dx;
if (this.yIntegrand != null ) tmp=this.yIntegrand.evaluate$DA(sourceVars[i]);
 else break;
this.sumY += tmp * this.dy;
break;
default:
if (this.xIntegrand != null ) tmp=this.xIntegrand.evaluate$DA(sourceVars[i]);
 else break;
this.sumX += tmp * this.dx;
}
if (i < this.n - 3) {
this.dx=(x[i + 2] - x[i + 1]);
this.dy=(y[i + 2] - y[i + 1]);
} else if (i < this.n - 2) {
this.dx=(x[i + 2] - x[i + 1]) / 2;
this.dy=(y[i + 2] - y[i + 1]) / 2;
} else {
}this.variables[i][0]=x[i];
this.variables[i][1]=y[i];
this.variables[i][2]=i;
this.variables[i][3]=this.sumX + this.sumY;
this.variables[i][4]=this.ds;
}
this.updateDataConnections();
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.reset();
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
this.reset();
});

Clazz.newMeth(C$, ['getDefiniteIntegralID$D$D','getDefiniteIntegralID'], function (start, stop) {
this.definite.setLimits$D$D(start, stop);
return this.definite.getID();
});

Clazz.newMeth(C$, ['getDefiniteIntegral$D$D','getDefiniteIntegral'], function (start, stop) {
return this.definite.getDefinate$D$D(start, stop);
});
;
(function(){var C$=Clazz.newClass(P$.Integral, "Definite", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.vars = null;
this.start = 0;
this.stop = 0;
this.owner = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["start", "stop", "integral"]);
this.vars = Clazz.array(Double.TYPE, [1, 3]);
this.start = 0;
this.stop = 0;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet', function (o) {
C$.$init$.apply(this);
this.owner=o;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'setLimits$D$D', function (start, stop) {
this.start=start;
this.stop=stop;
});

Clazz.newMeth(C$, 'getStartIndex$D', function (start) {
if (this.this$0.variables == null ) {
return -1;
}for (var i = 0; i < this.this$0.variables.length; i++) if (this.this$0.variables[i][0] >= start ) return i;

return this.this$0.variables.length - 1;
});

Clazz.newMeth(C$, 'getEndIndex$D', function (stop) {
if (this.this$0.variables == null ) {
return -1;
}for (var i = 0; i < this.this$0.variables.length; i++) if (this.this$0.variables[i][0] >= stop ) return i;

return this.this$0.variables.length - 1;
});

Clazz.newMeth(C$, 'getDefinate$D$D', function (start, stop) {
var sum = 0;
var istart = this.getStartIndex$D(start);
var iend = this.getEndIndex$D(stop);
if (istart < 0 || iend <= 0 ) {
return 0;
}sum=this.this$0.variables[iend][3] - this.this$0.variables[istart][3];
if (istart > 1 && this.this$0.variables.length > 1 ) {
var frac = 0;
frac=(this.this$0.variables[istart][0] - start) / (this.this$0.variables[istart][0] - this.this$0.variables[istart - 1][0]);
sum=sum + frac * (this.this$0.variables[istart][3] - this.this$0.variables[istart - 1][3]);
}if (iend < this.this$0.variables.length - 1 && this.this$0.variables.length > 1  && stop < this.this$0.variables[this.this$0.variables.length - 1][0]  ) {
var frac = 0;
frac=(this.this$0.variables[iend][0] - stop) / (this.this$0.variables[iend][0] - this.this$0.variables[iend - 1][0]);
sum=sum - frac * (this.this$0.variables[iend][3] - this.this$0.variables[iend - 1][3]);
}return sum;
});

Clazz.newMeth(C$, 'getVariables', function () {
var istart = this.getStartIndex$D(this.start);
var iend = this.getEndIndex$D(this.stop);
if (istart < 0 || iend <= 0 ) {
this.vars[0][0]=0;
this.vars[0][1]=0;
this.vars[0][2]=0;
return this.vars;
}this.vars[0][0]=Math.max(this.start, this.this$0.variables[0][0]);
this.vars[0][1]=Math.min(this.stop, this.this$0.variables[this.this$0.variables.length - 1][0]);
this.vars[0][2]=this.this$0.variables[iend][3] - this.this$0.variables[istart][3];
if (istart > 1 && this.this$0.variables.length > 1 ) {
var frac = 0;
frac=(this.this$0.variables[istart][0] - this.start) / (this.this$0.variables[istart][0] - this.this$0.variables[istart - 1][0]);
this.vars[0][2]=this.vars[0][2] + frac * (this.this$0.variables[istart][3] - this.this$0.variables[istart - 1][3]);
}if (iend < this.this$0.variables.length - 1 && this.this$0.variables.length > 1  && this.stop < this.this$0.variables[this.this$0.variables.length - 1][0]  ) {
var frac = 0;
frac=(this.this$0.variables[iend][0] - this.stop) / (this.this$0.variables[iend][0] - this.this$0.variables[iend - 1][0]);
this.vars[0][2]=this.vars[0][2] - frac * (this.this$0.variables[iend][3] - this.this$0.variables[iend - 1][3]);
}return this.vars;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (o) {
this.owner=o;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-07-20 18:09:32
