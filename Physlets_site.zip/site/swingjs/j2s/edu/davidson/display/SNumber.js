(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['edu.davidson.display.Format','java.beans.PropertyChangeSupport','edu.davidson.display.SNumber_this_textAdapter','java.awt.Color','java.awt.SystemColor']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SNumber", null, 'java.awt.TextField', 'java.beans.PropertyChangeListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.boundSupport = null;
this.value = 0;
this.formStr = null;
this.valFormat = null;
this.validData = false;
this.noColor = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.value = 0.0;
this.formStr = "%-+6.3g";
this.valFormat = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+6.3g"]);
this.validData = true;
this.noColor = false;
}, 1);

Clazz.newMeth(C$, 'c$$D', function (d) {
Clazz.super_(C$, this,1);
this.boundSupport = Clazz.new_((I$[2]||$incl$(2)).c$$O,[this]);
this.value = d;
this.setText$S(this.valFormat.form$D(this.value));
this.addTextListener$java_awt_event_TextListener(Clazz.new_((I$[3]||$incl$(3)).c$$edu_davidson_display_SNumber,[this]));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D.apply(this, [0.0]);
}, 1);

Clazz.newMeth(C$, 'setFormat$S', function (f) {
if (this.formStr.equals$O(f)) return;
this.formStr = f;
this.valFormat = Clazz.new_((I$[1]||$incl$(1)).c$$S,[f]);
this.setText$S(this.valFormat.form$D(this.value));
});

Clazz.newMeth(C$, 'getFormat', function () {
return this.formStr;
});

Clazz.newMeth(C$, 'setValue$D', function (d) {
this.validData = true;
if (d == this.value ) {
return;
}var oldVal = this.value;
this.value = d;
this.setText$S(this.valFormat.form$D(this.value));
this.boundSupport.firePropertyChange$S$O$O("DValue",  new Double(oldVal),  new Double(this.value));
if (this.isEditable()) this.setBackground$java_awt_Color((I$[4]||$incl$(4)).white);
 else this.setBackground$java_awt_Color((I$[5]||$incl$(5)).control);
});

Clazz.newMeth(C$, 'getValue', function () {
if (this.noColor) return this.value;
if (!this.isEditable()) this.setBackground$java_awt_Color((I$[5]||$incl$(5)).control);
 else if (!this.validData) this.setBackground$java_awt_Color((I$[4]||$incl$(4)).red);
 else this.setBackground$java_awt_Color((I$[4]||$incl$(4)).white);
return this.value;
});

Clazz.newMeth(C$, 'isValid', function () {
return this.validData;
});

Clazz.newMeth(C$, 'isNoColor', function () {
return this.noColor;
});

Clazz.newMeth(C$, 'setNoColor$Z', function (nc) {
this.noColor = nc;
});

Clazz.newMeth(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener', function (l) {
this.boundSupport.addPropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener', function (l) {
this.boundSupport.removePropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, 'propertyChange$java_beans_PropertyChangeEvent', function (evt) {
if (!this.isEditable()) this.setBackground$java_awt_Color((I$[5]||$incl$(5)).control);
 else this.setBackground$java_awt_Color((I$[4]||$incl$(4)).white);
if (evt.getPropertyName().equals$O("DValue")) {
var val = evt.getNewValue();
try {
if (val.doubleValue() == this.value ) {
return;
} else {
var str = this.valFormat.form$D(val.doubleValue());
this.value = Double.$valueOf(str).doubleValue();
this.setText$S(str);
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'this_textValueChanged$java_awt_event_TextEvent', function (evt) {
var oldValue = this.value;
var str = this.getText().trim();
try {
this.validData = true;
if (str != null  && str != "" ) {
this.value = Double.$valueOf(str).doubleValue();
if (!this.noColor) this.setBackground$java_awt_Color((I$[4]||$incl$(4)).yellow);
if (this.value == oldValue ) return;
this.boundSupport.firePropertyChange$S$O$O("DValue",  new Double(oldValue),  new Double(this.value));
} else {
if (!this.noColor) this.setBackground$java_awt_Color((I$[4]||$incl$(4)).red);
this.validData = false;
this.value = oldValue;
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
if (!this.noColor) this.setBackground$java_awt_Color((I$[4]||$incl$(4)).red);
this.validData = false;
this.value = oldValue;
} else {
throw e;
}
}
});
})();
//Created 2018-02-06 13:05:37
