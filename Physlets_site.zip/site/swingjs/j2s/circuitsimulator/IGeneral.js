(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'edu.davidson.numerics.Parser','java.awt.Font']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "IGeneral", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.parser=null;
this.$var=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.parser=Clazz.new_(Clazz.load('edu.davidson.numerics.Parser').c$$I,[2]);
this.$var=Clazz.array(Double.TYPE, [2]);
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$S$I$I$S', function (circuit, f, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$S.apply(this, [circuit, r, c, t]);
C$.$init$.apply(this);
this.reverseEquation=true;
this.$font=Clazz.new_(Clazz.load('java.awt.Font').c$$S$I$I,["TimesRoman", 0, 8]);
this.rightlinear=false;
this.$function="" + f;
this.parsefunction$();
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'parsefunction$', function () {
this.parser.defineVariable$I$S(1, "v");
this.parser.defineVariable$I$S(2, "i");
this.parser.define$S(this.$function.toLowerCase$());
this.parser.parse$();
if (this.parser.getErrorCode$() != $I$(1).NO_ERROR) {
System.out.println$S("Failed to parse function: " + this.$function);
System.out.println$S("Parse error: " + this.parser.getErrorString$() + " function position " + this.parser.getErrorPosition$() );
}});

Clazz.newMeth(C$, 'setvalue$S', function (s) {
this.$function="" + s;
this.parsefunction$();
});

Clazz.newMeth(C$, 'rightFunction$D', function (sign) {
this.$var[0]=this.getV$();
this.$var[1]=this.getI$();
return this.parser.evaluate$DA(this.$var);
});

Clazz.newMeth(C$, 'valueStr$', function () {
return this.$function;
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",func=" + this.$function;
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:15 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
