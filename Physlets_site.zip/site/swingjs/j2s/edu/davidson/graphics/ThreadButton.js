(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),p$1={},I$=[[0,'java.awt.event.ActionEvent','java.awt.Color','java.awt.event.MouseAdapter']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ThreadButton", null, 'java.awt.Button', 'Runnable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.evt=null;
this.backgroundColor=null;
this.downColor=null;
this.longTick=0;
this.shortTick=0;
this.tick=0;
this.running=false;
this.count=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.evt=Clazz.new_(Clazz.load('java.awt.event.ActionEvent').c$$O$I$S,[this, 1001, "THREAD"]);
this.backgroundColor=Clazz.load('java.awt.Color').lightGray;
this.downColor=$I$(2).green;
this.longTick=500;
this.shortTick=100;
this.tick=this.longTick;
this.running=false;
this.count=0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'destroy$', function () {
this.running=true;
});

Clazz.newMeth(C$, 'startThread', function () {
this.running=true;
}, p$1);

Clazz.newMeth(C$, 'stopThread', function () {
if (!this.running) return;
this.running=false;
this.tick=this.longTick;
this.count=0;
}, p$1);

Clazz.newMeth(C$, 'run$', function () {
this.count=0;
while (this.count < 100000){
this.count++;
if (this.count > 0) this.tick=this.shortTick;
}
});

Clazz.newMeth(C$, 'jbInit', function () {
this.addMouseListener$java_awt_event_MouseListener(((P$.ThreadButton$1||
(function(){var C$=Clazz.newClass(P$, "ThreadButton$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.b$['edu.davidson.graphics.ThreadButton'].this_mousePressed$java_awt_event_MouseEvent.apply(this.b$['edu.davidson.graphics.ThreadButton'], [e]);
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.b$['edu.davidson.graphics.ThreadButton'].this_mouseReleased$java_awt_event_MouseEvent.apply(this.b$['edu.davidson.graphics.ThreadButton'], [e]);
});
})()
), Clazz.new_(Clazz.load('java.awt.event.MouseAdapter'), [this, null],P$.ThreadButton$1)));
}, p$1);

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
if (this.running) return;
this.running=true;
this.setBackground$java_awt_Color(this.downColor);
p$1.startThread.apply(this, []);
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.setBackground$java_awt_Color(this.backgroundColor);
p$1.stopThread.apply(this, []);
this.running=false;
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:31 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
