(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ArrowThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.horz = 0;
this.vert = 0;
this.thickness = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.thickness = 1;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D$D$D', function (owner, sc, s, h, v, x, y) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, x, y]);
C$.$init$.apply(this);
this.s = s;
this.horz = h;
this.vert = v;
this.applet = owner;
}, 1);

Clazz.newMeth(C$, 'getHorz', function () {
return this.horz;
});

Clazz.newMeth(C$, 'getVert', function () {
return this.vert;
});

Clazz.newMeth(C$, 'setProperties$I$D$D', function (sid, alpha, beta) {
if (sid == 0 || sid == 1 ) {
this.setXY$D$D(alpha, beta);
} else if (sid == 2) {
this.horz = alpha;
this.vert = beta;
} else if (sid == 6) {
this.setX$D(alpha);
} else if (sid == 7) {
this.setY$D(beta);
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
var xpixPerUnit = this.canvas.pixFromX$D(1) - this.canvas.pixFromX$D(0);
var ypixPerUnit = -this.canvas.pixFromY$D(1) + this.canvas.pixFromY$D(0);
var x = xpixPerUnit * this.getHorz();
var y = ypixPerUnit * this.getVert();
osg.setColor$java_awt_Color(this.color);
var x2 = ((ptX + x)|0);
var y2 = ((ptY - y)|0);
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
if (Math.abs(x) < 1  && Math.abs(y) < 1  ) {
return;
}var h = Math.sqrt(x * x + y * y);
var w;
if (h > 3 * this.s ) w = this.s;
 else w = h / 3;
if (this.thickness > 1) {
(I$[1]||$incl$(1)).drawThickArrow$java_awt_Graphics$I$I$I$I$I$I(osg, ptX, ptY, x2, y2, (w|0), this.thickness);
return;
}if (h > 1 ) {
var u = (w * x / h);
var v = -(w * y / h);
var base_x = x2 - 3 * u;
var base_y = y2 - 3 * v;
osg.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x2, y2);
osg.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x2, y2);
}});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
var pixPerUnit = this.canvas.pixFromX$D(1) - this.canvas.pixFromX$D(0);
var x = pixPerUnit * this.horz;
var y = pixPerUnit * this.vert;
osg.setColor$java_awt_Color(this.color);
var x2 = ((ptX + x)|0);
var y2 = ((ptY - y)|0);
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
var h = Math.sqrt(x * x + y * y);
var w;
if (h > 3 * this.s ) w = this.s;
 else w = h / 3;
if (h > 1 ) {
var u = (w * x / h);
var v = -(w * y / h);
var base_x = x2 - 3 * u;
var base_y = y2 - 3 * v;
osg.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x2, y2);
osg.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x2, y2);
}});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < 5) && (Math.abs(yPix - ptY) < 5) ) return true;
 else return false;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:05:35
