(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newClass(P$, "Label", null, 'javax.swing.JLabel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$S$I.apply(this, ["", 0]);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
C$.c$$S$I.apply(this, [text, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$S$I', function (text, center) {
C$.superclazz.c$$S$I.apply(this, [text, center]);
C$.$init$.apply(this);
C$.superclazz.prototype.setBackground$java_awt_Color.apply(this, [null]);
this.setAlignment$I(0);
}, 1);

Clazz.newMeth(C$, 'setBackground$java_awt_Color', function (c) {
C$.superclazz.prototype.setBackground$java_awt_Color.apply(this, [c]);
this.setOpaque$Z(c != null );
});

Clazz.newMeth(C$, 'setAlignment$I', function (alignment) {
var xAlignment=0.0;
var yAlignment=0.5;
switch (alignment) {
case 0:
alignment=2;
xAlignment=0;
break;
case 2:
alignment=4;
xAlignment=1;
break;
case 1:
alignment=0;
xAlignment=0.5;
break;
}
this.setAlignmentX$F(xAlignment);
this.setAlignmentY$F(yAlignment);
this.setHorizontalAlignment$I(alignment);
this.setVerticalAlignment$I(0);
this.setVerticalTextPosition$I(0);
});
})();
;Clazz.setTVer('3.2.4.00');//Created 2018-10-23 12:28:17 Java2ScriptVisitor version 3.2.4.00 net.sf.j2s.core.jar version 3.2.4.00
