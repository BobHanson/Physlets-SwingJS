(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newInterface(P$, "SDataSource");
})();
//Created 2018-02-25 19:20:28
