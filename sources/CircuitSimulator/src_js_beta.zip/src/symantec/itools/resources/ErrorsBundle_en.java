package symantec.itools.resources;

public class ErrorsBundle_en extends ErrorsBundle {
}