(function(){var P$=Clazz.newPackage("eField4"),I$=[];
var C$=Clazz.newClass(P$, "OdeCanvas_mouseMotionAdapter", null, 'java.awt.event.MouseMotionAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas', function (adaptee) {
Clazz.super_(C$, this,1);
this.adaptee = adaptee;
}, 1);

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
this.adaptee.this_mouseDragged$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
this.adaptee.this_mouseMoved$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:33
