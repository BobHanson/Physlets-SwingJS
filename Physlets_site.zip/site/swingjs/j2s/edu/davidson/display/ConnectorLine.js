(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[];
var C$=Clazz.newClass(P$, "ConnectorLine", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.thing1 = null;
this.thing2 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$edu_davidson_display_Thing$edu_davidson_display_Thing', function (owner, sc, t1, t2) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, 0, 0]);
C$.$init$.apply(this);
this.s = 1;
this.thing1 = t1;
this.thing2 = t2;
this.applet = owner;
this.visible = true;
}, 1);

Clazz.newMeth(C$, 'setConnectorIDs$edu_davidson_display_Thing$edu_davidson_display_Thing', function (t1, t2) {
this.thing1 = t1;
this.thing2 = t2;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible || this.thing1 == null   || this.thing2 == null  ) return;
var ptX1 = this.canvas.pixFromX$D(this.thing1.getX());
var ptY1 = this.canvas.pixFromY$D(this.thing1.getY());
var ptX2 = this.canvas.pixFromX$D(this.thing2.getX());
var ptY2 = this.canvas.pixFromY$D(this.thing2.getY());
osg.setColor$java_awt_Color(this.color);
osg.drawLine$I$I$I$I(ptX1, ptY1, ptX2, ptY2);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
return false;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:21
