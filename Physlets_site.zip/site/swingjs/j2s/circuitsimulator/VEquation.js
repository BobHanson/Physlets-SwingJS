(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "VEquation");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.indexV1 = 0;
this.indexV2 = 0;
this.indexI1 = 0;
this.indexI2 = 0;
this.sign = 0;
this.z = null;
this.fromr = 0;
this.fromc = 0;
this.tor = 0;
this.toc = 0;
this.direction = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.indexV1 = this.indexV2 = this.indexI1 = this.indexI2 = 0;
this.fromr = this.fromc = this.tor = this.toc = 0;
this.z = null;
this.sign = 1;
this.direction = 0;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_GridElement$I$I$I$I', function (thisel, dir, hereVIndex, nextVIndex, iIndex) {
C$.$init$.apply(this);
this.z = thisel.connection[dir];
this.direction = dir;
this.sign = (dir != thisel.connection[dir].direction) ? -1 : 1;
this.indexV1 = hereVIndex;
this.indexV2 = nextVIndex;
this.indexI1 = iIndex;
thisel.connection[dir].vequation = this;
}, 1);

Clazz.newMeth(C$, 'leftValue$I$circuitsimulator_Matrix$I', function (nOV, matrix, r) {
matrix.set_elem$I$I$D(r, this.indexV1, this.z.indexVHere());
matrix.set_elem$I$I$D(r, this.indexV2, this.z.indexVNext());
matrix.set_elem$I$I$D(r, nOV + this.indexI1, this.z.impedance());
if (this.z.numberOfNodes == 4) matrix.set_elem$I$I$D(r, nOV + this.z.indexIcoupled(), this.z.impedanceCoupled());
});

Clazz.newMeth(C$, 'rightValue$I$I$circuitsimulator_Matrix$I', function (nOV, nOPars, matrix, r) {
matrix.set_elem$I$I$D(r, nOPars + this.z.inputIndex, this.z.input$D(this.sign));
matrix.set_elem$I$I$D(r, nOPars, -1 * this.z.rightFunction$D(this.sign));
matrix.set_elem$I$I$D(r, this.indexV1, this.z.integralVHere());
matrix.set_elem$I$I$D(r, this.indexV2, this.z.integralVNext());
matrix.set_elem$I$I$D(r, nOV + this.indexI1, this.z.differential());
if (this.z.numberOfNodes == 4) matrix.set_elem$I$I$D(r, nOV + this.z.indexIcoupled(), this.z.differentialCoupled());
});

Clazz.newMeth(C$, 'print', function () {
System.out.println$S(this.z.name() + " in VEquation: indexV1/indexV2/indexI1: " + this.indexV1 + "/" + this.indexV2 + "/" + this.indexI1 );
});
})();
//Created 2018-02-06 06:55:34
