(function(){var P$=Clazz.newPackage("eField4"),I$=[];
var C$=Clazz.newClass(P$, "EField_chargeBox_itemAdapter", null, null, 'java.awt.event.ItemListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_EField', function (adaptee) {
C$.$init$.apply(this);
this.adaptee = adaptee;
}, 1);

Clazz.newMeth(C$, 'itemStateChanged$java_awt_event_ItemEvent', function (e) {
this.adaptee.chargeBox_itemStateChanged$java_awt_event_ItemEvent(e);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:07:23
