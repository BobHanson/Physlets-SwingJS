(function(){var P$=Clazz.newPackage("dynamics"),I$=[[0,'java.awt.Panel','a2s.Button','a2s.Checkbox','javax.swing.Timer','edu.davidson.graphics.Util','java.awt.Color','dynamics.MovingProjectile']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ProjectileOrbit", null, 'a2s.Applet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.yOffset=0;
this.time=0;
this.ts=0;
this.area=null;
this.bgImage=null;
this.fgImage=null;
this.gb=null;
this.g=null;
this.bgColor=null;
this.mb=null;
this.bs=null;
this.cb=null;
this.state=false;
this.rts=null;
this.STR=null;
this.id=0;
this.xx=0;
this.yy=0;
this.running=false;
this.startTime=0;
this.lastTime=0;
this.delay=0;
this.delta=0;
this.rightClick=false;
this.dragging=false;
this.fm=null;
this.chy=0;
this.xc=0;
this.yc=0;
this.Re=0;
this.De=0;
this.w1=0;
this.w0=0;
this.w2=0;
this.v0=0;
this.dv=0;
this.v=0;
this.r0=0;
this.rcst=0;
this.tcst=0;
this.cst=0;
this.rcst2=0;
this.earth=null;
this.$height=0;
this.$width=0;
this.x1=0;
this.y1=0;
this.stry=0;
this.xs=0;
this.ys=0;
this.vcst=0;
this.dc=0;
this.timer=null;
this.imagedir=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.imagedir="./";
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
this.setSize$I$I(700, 600);
for (var i=0; i < this.STR.length; ++i) {
if ((this.rts=this.getParameter$S(this.STR[i])) != null ) {
this.STR[i]= String.instantialize(this.rts);
}}
this.setBackground$java_awt_Color(this.bgColor);
var panel=Clazz.new_($I$(1));
panel.add$java_awt_Component(Clazz.new_($I$(2).c$$S,[this.STR[0]]));
panel.add$java_awt_Component(this.bs=Clazz.new_($I$(2).c$$S,[this.STR[1]]));
panel.add$java_awt_Component(Clazz.new_($I$(2).c$$S,[this.STR[3]]));
panel.add$java_awt_Component(Clazz.new_($I$(2).c$$S,[this.STR[4]]));
panel.add$java_awt_Component(this.cb=Clazz.new_($I$(3).c$$S,[this.STR[5]]));
this.add$S$java_awt_Component("North", panel);
this.area=this.size$();
var area=this.area;
area.height-=this.yOffset;
var s=this.getParameter$S("imagedir");
if (s == null ) {
this.imagedir="./";
} else {
this.imagedir += s + "/";
}this.reset$Z(true);
});

Clazz.newMeth(C$, ['action$java_awt_Event$O','action'], function (event, o) {
if (Clazz.instanceOf(event.target, "a2s.Button")) {
var s=o;
if (s.equals$O(this.STR[0])) {
this.bs.setLabel$S(this.STR[1]);
this.reset$Z(true);
} else if (s.equals$O(this.STR[1])) {
this.running=true;
this.bs.setLabel$S(this.STR[6]);
this.start$();
this.timer.start$();
this.running=true;
} else if (s.equals$O(this.STR[6])) {
this.running=false;
this.mb.setup$D$D$D$D(0.0, this.v, this.r0, 0.0);
this.repaint$();
this.bs.setLabel$S(this.STR[1]);
} else {
if (s.equals$O(this.STR[4])) {
++this.id;
} else if (s.equals$O(this.STR[3])) {
--this.id;
if (this.id < 2) {
this.id=2;
}}this.running=false;
this.v=this.id * this.v0;
this.mb.setup$D$D$D$D(0.0, this.v, this.r0, 0.0);
this.repaint$();
this.bs.setLabel$S(this.STR[1]);
}}if (Clazz.instanceOf(event.target, "a2s.Checkbox")) {
this.state=!this.cb.getState$();
}return true;
});

Clazz.newMeth(C$, ['reset$Z','reset'], function (b) {
this.clear$();
this.running=false;
if (b) {
var n=0.0;
this.time=0.0;
this.ts=0.0;
}this.repaint$();
});

Clazz.newMeth(C$, ['start$','start'], function () {
this.delta=200;
if (this.timer == null ) this.timer=Clazz.new_($I$(4).c$$I$java_awt_event_ActionListener,[((this.delta|0)/2|0), ((P$.ProjectileOrbit$1||
(function(){var C$=Clazz.newClass(P$, "ProjectileOrbit$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (ae) {
this.b$['dynamics.ProjectileOrbit'].run$.apply(this.b$['dynamics.ProjectileOrbit'], []);
});
})()
), Clazz.new_(P$.ProjectileOrbit$1.$init$, [this, null]))]);
this.timer.setRepeats$Z(true);
});

Clazz.newMeth(C$, ['stop$','stop'], function () {
this.timer.stop$();
this.running=false;
});

Clazz.newMeth(C$, ['run$','run'], function () {
if (this.running) {
this.advanced$D(this.delta / 8000.0);
}});

Clazz.newMeth(C$, 'advanced$D', function (n) {
this.time += n;
this.ts += n;
n /= 5.0;
for (var i=0; i < 5; ++i) {
this.mb.advanced$D(n);
this.gb.drawLine$I$I$I$I(this.xx=this.xc + (this.mb.getX$()|0), this.yy=this.yc + (this.mb.getY$()|0), this.xx, this.yy);
if (this.state && this.mb.R$() < this.Re  ) {
this.running=false;
this.bs.setLabel$S("Back");
this.repaint$();
return;
}}
this.repaint$();
});

Clazz.newMeth(C$, ['mouseDown$java_awt_Event$I$I','mouseDown'], function (event, n, n2) {
if ((n2-=this.yOffset) < 0) {
return false;
}if (event.modifiers == 4) {
this.rightClick=true;
this.running=!this.running;
} else if (Math.sqrt((n - this.xs) * (n - this.xs) + (n2 - this.ys) * (n2 - this.ys)) < 5.0 ) {
this.xx=this.xc + (this.mb.getX$()|0);
this.yy=this.yc + (this.mb.getY$()|0);
this.dragging=true;
}return true;
});

Clazz.newMeth(C$, ['mouseDrag$java_awt_Event$I$I','mouseDrag'], function (event, n, n2) {
if ((n2-=this.yOffset) < 0) {
return false;
}if (this.dragging) {
this.mb.setupDrag$D$D((n - this.xx) * this.vcst, (n2 - this.yy) * this.vcst);
this.repaint$();
}return true;
});

Clazz.newMeth(C$, ['mouseUp$java_awt_Event$I$I','mouseUp'], function (event, n, n2) {
if ((n2-=this.yOffset) < 0) {
return false;
}if (this.rightClick) {
this.rightClick=false;
}this.dragging=false;
return true;
});

Clazz.newMeth(C$, 'clear$', function () {
if (this.g == null ) {
this.bgImage=this.createImage$I$I(this.area.width, this.area.height);
this.gb=this.bgImage.getGraphics$();
this.fgImage=this.createImage$I$I(this.area.width, this.area.height);
this.g=this.fgImage.getGraphics$();
this.fm=this.gb.getFontMetrics$();
this.chy=this.fm.getHeight$();
this.xc=(this.area.width/2|0);
this.yc=(this.area.height/2|0);
this.Re=-8 + ((this.xc > this.yc) ? ((this.yc/2|0)) : ((this.xc/2|0)));
this.De=2 * this.Re;
this.yc-=(this.Re/2|0) - 15;
this.earth=$I$(5).getImage$S$java_applet_Applet(this.imagedir + "earth.jpg", this);
if (this.earth != null ) {
this.$height=this.earth.getHeight$java_awt_image_ImageObserver(this);
this.$width=this.earth.getWidth$java_awt_image_ImageObserver(this);
}}this.gb.setColor$java_awt_Color(this.bgColor);
this.gb.fillRect$I$I$I$I(0, 0, this.area.width, this.area.height);
this.gb.setColor$java_awt_Color($I$(6).black);
this.gb.drawRect$I$I$I$I(0, 0, this.area.width - 1, this.area.height - 1);
this.gb.setColor$java_awt_Color($I$(6).black);
this.gb.fillOval$I$I$I$I(this.xx=this.xc - this.w1, this.yy=this.yc - (3 * this.Re/2|0), this.w2, this.Re);
if (this.earth != null ) this.gb.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.earth, this.xc - (this.$width/2|0), this.yc - (this.$height/2|0), this);
this.gb.setColor$java_awt_Color($I$(6).white);
this.gb.fillOval$I$I$I$I(this.xc - this.w0, this.yc - this.w0, this.w1, this.w1);
var n=6.67E-11;
var n2=6374000.0;
var n3=5.976E24;
this.rcst=6374000.0 / (this.yc - this.yy);
this.rcst2=this.rcst / 1000.0;
this.cst=this.rcst / this.tcst;
this.mb.setGM$D(6.67E-11 * 5.976E24 * this.tcst * this.tcst  / (this.rcst * this.rcst * this.rcst ));
this.v0=Math.sqrt(6.253517414496391E7) / this.cst / 10.0 ;
this.id=2;
this.v=this.id * this.v0;
this.r0=this.yy - this.yc - this.w0 ;
this.mb.setup$D$D$D$D(0.0, this.v, this.r0, 0.0);
this.stry=0;
this.g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.bgImage, 0, 0, this);
this.x1=this.xc - this.w0;
this.y1=this.yc - this.w0;
});

Clazz.newMeth(C$, 'paintComponent_$java_awt_Graphics', function (g) {
this.updateScreen$java_awt_Graphics(g);
});

Clazz.newMeth(C$, ['updateScreen$java_awt_Graphics','updateScreen'], function (graphics) {
this.g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.bgImage, 0, 0, this);
this.g.setColor$java_awt_Color($I$(6).black);
this.g.drawString$S$I$I(this.STR[2] + this.d2String$D(this.time * 3600.0), 100, this.chy);
this.g.setColor$java_awt_Color($I$(6).green);
this.g.fillOval$I$I$I$I(this.xx=this.x1 + (this.mb.getX$()|0), this.yy=this.y1 + (this.mb.getY$()|0), this.w1, this.w1);
this.g.setColor$java_awt_Color($I$(6).red);
this.g.drawString$S$I$I("V =" + this.d2String$D(this.mb.V$()) + "m/s" , 5, this.stry + this.chy);
this.drawArrow2$I$I$D$D(this.xx+=this.w0, this.yy+=this.w0, this.mb.vx$() / this.vcst, this.mb.vy$() / this.vcst);
this.xs=this.xx + ((this.mb.vx$() / this.vcst)|0);
this.ys=this.yy + ((this.mb.vy$() / this.vcst)|0);
this.g.setColor$java_awt_Color($I$(6).white);
this.g.drawLine$I$I$I$I(this.xx, this.yy, this.xc, this.yc);
this.g.drawString$S$I$I("x=" + this.d2String$D(this.mb.getX$() * this.rcst2) + " km, y=" + this.d2String$D(-this.mb.getY$() * this.rcst2) + " km" , this.xc, this.chy);
if (this.dragging) {
this.g.setColor$java_awt_Color($I$(6).black);
this.g.drawString$S$I$I("(Vx,Vy)=(" + this.d2String$D(this.mb.vx$()) + " , " + this.d2String$D(-this.mb.vy$()) + " )" , 100, 2 * this.chy);
}graphics.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.fgImage, 0, this.yOffset, this);
});

Clazz.newMeth(C$, 'd2String$D', function (n) {
return String.valueOf$I(((n * this.cst)|0));
});

Clazz.newMeth(C$, 'drawArrow$I$I$D$D', function (n, n2, n3, n4) {
this.g.drawLine$I$I$I$I(n, n2, n+=((n3 * Math.cos(n4))|0), n2+=((n3 * Math.sin(n4))|0));
n3 *= 0.2;
this.g.drawLine$I$I$I$I(n, n2, n - ((n3 * Math.cos(n4 + this.dc))|0), n2 - ((n3 * Math.sin(n4 + this.dc))|0));
this.g.drawLine$I$I$I$I(n, n2, n - ((n3 * Math.cos(n4 - this.dc))|0), n2 - ((n3 * Math.sin(n4 - this.dc))|0));
});

Clazz.newMeth(C$, 'drawArrow2$I$I$D$D', function (n, n2, n3, n4) {
var atan=1.5707963267948966;
if (n3 == 0.0 ) {
if (n4 < 0.0 ) {
atan=-atan;
}} else {
atan=Math.atan(n4 / n3);
if (n3 < 0.0 ) {
atan += 3.141592653589793;
}}this.drawArrow$I$I$D$D(n, n2, Math.sqrt(n3 * n3 + n4 * n4), atan);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.yOffset=40;
this.time=0.0;
this.ts=0.0;
this.bgColor=$I$(6).lightGray;
this.mb=Clazz.new_($I$(7));
this.state=true;
this.STR=Clazz.array(String, -1, ["Reset", "Start", "Time", "-", "+", "full", "Back"]);
this.id=2;
this.running=false;
this.startTime=0;
this.delay=50;
this.rightClick=false;
this.dragging=false;
this.w1=6;
this.w0=(this.w1/2|0);
this.w2=2 * this.w1;
this.v0=300.0;
this.tcst=3600.0;
this.vcst=10.0;
this.dc=0.5235987755982988;
}, 1);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:44 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
