BH 2019.03

Because there is no java class in this directory, 
the transpiler will not automatically move these 
resource files to circuit/circuitimages. So we
must do that ourselves.

This directory is accessed only if the "imagedir"
parameter (default "../circuit/circuitimages"