(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newInterface(P$, "SDifferentiable");
})();
//Created 2018-02-24 16:21:12
