(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newInterface(P$, "TimerClient");
})();
//Created 2018-02-24 16:21:14
