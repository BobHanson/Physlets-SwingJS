(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['java.awt.BorderLayout','java.awt.event.WindowAdapter']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SFrame", null, 'a2s.Frame');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.borderLayout1 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.borderLayout1 = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$S.apply(this, ["NO_TITLE"]);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (title) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
if (title.equals$O("NO_TITLE")) title = this.getClass().getName();
this.setSize$I$I(400, 300);
this.setLocation$I$I(((300 * Math.random())|0), ((300 * Math.random())|0));
this.addWindowListener$java_awt_event_WindowListener(((
(function(){var C$=Clazz.newClass(P$, "SFrame$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (e) {
this.b$['edu.davidson.graphics.SFrame'].setVisible$Z(false);
this.b$['edu.davidson.graphics.SFrame'].dispose();
});
})()
), Clazz.new_((I$[2]||$incl$(2)), [this, null],P$.SFrame$1)));
this.setTitle$S(title);
}, 1);
})();
//Created 2018-02-25 19:20:26
