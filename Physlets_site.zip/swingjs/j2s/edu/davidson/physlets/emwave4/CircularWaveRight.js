(function(){var P$=Clazz.newPackage("edu.davidson.physlets.emwave4"),I$=[['edu.davidson.physlets.emwave4.Wave']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CircularWaveRight", null, 'edu.davidson.physlets.emwave4.Wave');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D$D$java_awt_Color', function (z1, z2, a, ph, clr) {
Clazz.super_(C$, this,1);
this.zPropagate = z1;
this.zTerminate = z2;
this.amplitude = a;
this.phase = ph;
this.length = this.zTerminate - this.zPropagate;
this.numLines = (Math.round(this.length / (I$[1]||$incl$(1)).lineDensity)|0);
this.c = clr;
this.pts = Clazz.array(Double.TYPE, [2 * this.numLines, 3]);
for (var i = 1, j = 0; i < 2 * this.numLines; i = i+(2), j++) {
this.pts[i][0] = Math.cos(j * this.h + this.phase) * this.amplitude;
this.pts[i][1] = Math.sin(j * this.h + this.phase) * this.amplitude;
this.pts[i][2] = j * (I$[1]||$incl$(1)).lineDensity + this.zPropagate;
}
for (var i = 0, j = 0; i < 2 * this.numLines; i = i+(2), j++) {
this.pts[i][0] = 0;
this.pts[i][1] = 0;
this.pts[i][2] = j * (I$[1]||$incl$(1)).lineDensity + this.zPropagate;
}
}, 1);

Clazz.newMeth(C$, 'setFirstStick$I$I', function (incrementer, offset) {
this.pts[0][0] = 0;
this.pts[0][1] = 0;
this.pts[0][2] = this.zPropagate + offset;
this.pts[1][0] = Math.cos(incrementer * this.h + this.phase) * this.amplitude;
this.pts[1][1] = Math.sin(incrementer * this.h + this.phase) * this.amplitude;
this.pts[1][2] = this.zPropagate + offset;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:24
