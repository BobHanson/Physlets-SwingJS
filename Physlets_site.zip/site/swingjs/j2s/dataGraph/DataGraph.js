(function(){var P$=Clazz.newPackage("dataGraph"),I$=[['edu.davidson.graphics.EtchedBorder','edu.davidson.display.SGraph','a2s.Button','java.awt.BorderLayout','a2s.TextField','edu.davidson.display.SNumber','a2s.Label','a2s.Panel','java.awt.FlowLayout','java.awt.GridLayout','dataGraph.DataGraph$1','Boolean','java.awt.Color','dataGraph.DataGraph$2','dataGraph.DataGraph$3','dataGraph.DataGraph$4','dataGraph.DataGraph$5','dataGraph.DataGraph$6','dataGraph.DataGraph$7','dataGraph.DataGraph$8','java.awt.event.ComponentAdapter','edu.davidson.tools.SUtil','edu.davidson.display.GraphThing','edu.davidson.display.BoxThing','edu.davidson.display.RectangleThing','edu.davidson.display.ProtractorThing','edu.davidson.display.TangentThing','edu.davidson.display.CircleThing','edu.davidson.display.MarkerThing','edu.davidson.display.ShellThing','edu.davidson.display.PhaseThing','edu.davidson.display.ArrowThing','edu.davidson.display.TextThing','edu.davidson.display.CaptionThing','edu.davidson.display.ComplexThing','edu.davidson.display.ImageThing','java.net.URL','java.awt.MediaTracker','edu.davidson.display.SGraphFrame']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DataGraph", null, 'edu.davidson.tools.SApplet');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.button_clear_data = null;
this.button_clear_function = null;
this.button_reset = null;
this.button_add = null;
this.button_plot = null;
this.label_time = null;
this.$firstTime = false;
this.showControls = false;
this.autoX = false;
this.autoY = false;
this.$function = null;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.dataFile = null;
this.etchedBorder1 = null;
this.graph = null;
this.clearSeriesBtn = null;
this.borderLayout1 = null;
this.etchedBorder2 = null;
this.etchedBorder3 = null;
this.addDatumBtn = null;
this.addFuncBtn = null;
this.clearFuncBtn = null;
this.funcField = null;
this.yField = null;
this.xField = null;
this.borderLayout2 = null;
this.label1 = null;
this.border1 = null;
this.flowLayout1 = null;
this.borderLayout3 = null;
this.border2 = null;
this.border3 = null;
this.label2 = null;
this.label3 = null;
this.borderLayout4 = null;
this.flowLayout2 = null;
this.panel1 = null;
this.panel2 = null;
this.gridLayout1 = null;
this.borderLayout5 = null;
this.borderLayout6 = null;
this.button4 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.button_clear_data = "Clear";
this.button_clear_function = "Clear";
this.button_reset = "Reset";
this.button_add = "Add";
this.button_plot = "Plot";
this.label_time = "Time: ";
this.$firstTime = true;
this.showControls = true;
this.etchedBorder1 = Clazz.new_((I$[1]||$incl$(1)));
this.graph = Clazz.new_((I$[2]||$incl$(2)).c$$edu_davidson_tools_SApplet,[this]);
this.clearSeriesBtn = Clazz.new_((I$[3]||$incl$(3)));
this.borderLayout1 = Clazz.new_((I$[4]||$incl$(4)));
this.etchedBorder2 = Clazz.new_((I$[1]||$incl$(1)));
this.etchedBorder3 = Clazz.new_((I$[1]||$incl$(1)));
this.addDatumBtn = Clazz.new_((I$[3]||$incl$(3)));
this.addFuncBtn = Clazz.new_((I$[3]||$incl$(3)));
this.clearFuncBtn = Clazz.new_((I$[3]||$incl$(3)));
this.funcField = Clazz.new_((I$[5]||$incl$(5)));
this.yField = Clazz.new_((I$[6]||$incl$(6)));
this.xField = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout2 = Clazz.new_((I$[4]||$incl$(4)));
this.label1 = Clazz.new_((I$[7]||$incl$(7)));
this.border1 = Clazz.new_((I$[8]||$incl$(8)));
this.flowLayout1 = Clazz.new_((I$[9]||$incl$(9)));
this.borderLayout3 = Clazz.new_((I$[4]||$incl$(4)));
this.border2 = Clazz.new_((I$[8]||$incl$(8)));
this.border3 = Clazz.new_((I$[8]||$incl$(8)));
this.label2 = Clazz.new_((I$[7]||$incl$(7)));
this.label3 = Clazz.new_((I$[7]||$incl$(7)));
this.borderLayout4 = Clazz.new_((I$[4]||$incl$(4)));
this.flowLayout2 = Clazz.new_((I$[9]||$incl$(9)));
this.panel1 = Clazz.new_((I$[8]||$incl$(8)));
this.panel2 = Clazz.new_((I$[8]||$incl$(8)));
this.gridLayout1 = Clazz.new_((I$[10]||$incl$(10)));
this.borderLayout5 = Clazz.new_((I$[4]||$incl$(4)));
this.borderLayout6 = Clazz.new_((I$[4]||$incl$(4)));
this.button4 = Clazz.new_((I$[3]||$incl$(3)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.funcField.addKeyListener$java_awt_event_KeyListener(((
(function(){var C$=Clazz.newClass(P$, "DataGraph$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.KeyListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['keyTyped$java_awt_event_KeyEvent','keyTyped'], function (e) {
System.out.println$S(e.getKeyCode() + " " + (0 + (e.getKeyChar()).$c()) + " typed" );
});

Clazz.newMeth(C$, ['keyPressed$java_awt_event_KeyEvent','keyPressed'], function (e) {
System.out.println$S(e.getKeyCode() + " " + (0 + (e.getKeyChar()).$c()) + " pressed" );
});

Clazz.newMeth(C$, ['keyReleased$java_awt_event_KeyEvent','keyReleased'], function (e) {
System.out.println$S(e.getKeyCode() + " " + (0 + (e.getKeyChar()).$c()) + " released" );
});
})()
), Clazz.new_((I$[11]||$incl$(11)).$init$, [this, null])));
}, 1);

Clazz.newMeth(C$, 'setResources', function () {
this.button_clear_data = this.localProperties.getProperty$S$S("button.clear_data", this.button_clear_data);
this.button_clear_function = this.localProperties.getProperty$S$S("button.clear_function", this.button_clear_function);
this.button_reset = this.localProperties.getProperty$S$S("button.reset", this.button_reset);
this.button_add = this.localProperties.getProperty$S$S("button.add", this.button_add);
this.button_plot = this.localProperties.getProperty$S$S("button.plot", this.button_plot);
this.label_time = this.localProperties.getProperty$S$S("label.time", this.label_time);
this.graph.label_time = this.label_time;
});

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
try {
this.$function = this.getParameter$S$S("Function", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xmin = Double.$valueOf(this.getParameter$S$S("XMin", "-1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xmax = Double.$valueOf(this.getParameter$S$S("XMax", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ymin = Double.$valueOf(this.getParameter$S$S("YMin", "-1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ymax = Double.$valueOf(this.getParameter$S$S("YMax", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.dataFile = this.getParameter$S$S("DataFile", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.autoX = (I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("AutoScaleX", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.autoY = (I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("AutoScaleY", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls = (I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
if (!this.showControls) this.etchedBorder1.setVisible$Z(false);
if (this.$function != null  && !this.$function.equals$O("") ) this.funcField.setText$S(this.$function);
this.graph.setEnableMouse$Z(true);
this.graph.setAutoscaleX$Z(this.autoX);
this.graph.setAutoscaleY$Z(this.autoY);
this.graph.setMinMaxX$D$D(this.xmin, this.xmax);
this.graph.setMinMaxY$D$D(this.ymin, this.ymax);
if (this.dataFile != null  && !this.dataFile.equals$O("") ) this.graph.loadFile$I$S(1, this.dataFile);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.etchedBorder1.setBackground$java_awt_Color((I$[13]||$incl$(13)).lightGray);
this.graph.setSampleData$Z(false);
this.graph.setLabelX$S("x");
this.graph.setBorders$S("0,10,15,0");
this.graph.setLabelY$S("y");
this.clearSeriesBtn.setLabel$S(this.button_clear_data);
this.etchedBorder3.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.etchedBorder2.setLayout$java_awt_LayoutManager(this.borderLayout4);
this.addDatumBtn.setLabel$S(this.button_add);
this.addDatumBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DataGraph$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dataGraph.DataGraph'].addDatumBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[14]||$incl$(14)).$init$, [this, null])));
this.addFuncBtn.setLabel$S(this.button_plot);
this.addFuncBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DataGraph$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dataGraph.DataGraph'].addFuncBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[15]||$incl$(15)).$init$, [this, null])));
this.addFuncBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DataGraph$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dataGraph.DataGraph'].addFuncBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[16]||$incl$(16)).$init$, [this, null])));
this.addFuncBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DataGraph$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dataGraph.DataGraph'].addFuncBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[17]||$incl$(17)).$init$, [this, null])));
this.clearFuncBtn.setLabel$S(this.button_clear_function);
this.clearFuncBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DataGraph$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dataGraph.DataGraph'].clearFuncBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[18]||$incl$(18)).$init$, [this, null])));
this.funcField.setText$S("sin(2*pi*x)");
this.label1.setAlignment$I(2);
this.label1.setText$S("F(x) =");
this.flowLayout1.setHgap$I(0);
this.flowLayout1.setVgap$I(0);
this.border2.setLayout$java_awt_LayoutManager(this.flowLayout2);
this.border3.setLayout$java_awt_LayoutManager(this.gridLayout1);
this.label2.setAlignment$I(2);
this.label2.setText$S("x = ");
this.label3.setAlignment$I(2);
this.label3.setText$S("y = ");
this.flowLayout2.setHgap$I(0);
this.flowLayout2.setVgap$I(0);
this.button4.setLabel$S(this.button_reset);
this.button4.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DataGraph$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dataGraph.DataGraph'].button4_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[19]||$incl$(19)).$init$, [this, null])));
this.panel1.setLayout$java_awt_LayoutManager(this.borderLayout6);
this.panel2.setLayout$java_awt_LayoutManager(this.borderLayout5);
this.border1.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.clearSeriesBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DataGraph$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dataGraph.DataGraph'].clearSeriesBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[20]||$incl$(20)).$init$, [this, null])));
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.addComponentListener$java_awt_event_ComponentListener(((
(function(){var C$=Clazz.newClass(P$, "DataGraph$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.ComponentAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);
})()
), Clazz.new_((I$[21]||$incl$(21)), [this, null],P$.DataGraph$9)));
this.add$java_awt_Component$O(this.etchedBorder1, "South");
this.etchedBorder1.add$java_awt_Component$O(this.etchedBorder3, "South");
this.etchedBorder3.add$java_awt_Component$O(this.border1, "East");
this.border1.add$java_awt_Component$O(this.addFuncBtn, null);
this.border1.add$java_awt_Component$O(this.clearFuncBtn, null);
this.etchedBorder3.add$java_awt_Component$O(this.label1, "West");
this.etchedBorder3.add$java_awt_Component$O(this.funcField, "Center");
this.etchedBorder1.add$java_awt_Component$O(this.etchedBorder2, "North");
this.etchedBorder2.add$java_awt_Component$O(this.border3, "Center");
this.border3.add$java_awt_Component$O(this.panel2, null);
this.panel2.add$java_awt_Component$O(this.label2, "West");
this.panel2.add$java_awt_Component$O(this.xField, "Center");
this.border3.add$java_awt_Component$O(this.panel1, null);
this.panel1.add$java_awt_Component$O(this.label3, "West");
this.panel1.add$java_awt_Component$O(this.yField, "Center");
this.etchedBorder2.add$java_awt_Component$O(this.border2, "East");
this.border2.add$java_awt_Component$O(this.addDatumBtn, null);
this.border2.add$java_awt_Component$O(this.clearSeriesBtn, null);
this.etchedBorder2.add$java_awt_Component$O(this.button4, "West");
this.add$java_awt_Component$O(this.graph, "Center");
});

Clazz.newMeth(C$, 'destroy', function () {
this.destroyed = true;
this.setAutoRefresh$Z(false);
if (this.clock.isRunning()) this.clock.stopClock();
this.graph.destroy();
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.$firstTime) return 0;
 else return C$.superclazz.prototype.getAppletCount.apply(this, []);
});

Clazz.newMeth(C$, 'start', function () {
if (this.$firstTime) {
this.$firstTime = false;
this.graph.setOwner$edu_davidson_tools_SApplet(this);
if (this.$function != null  && !this.$function.equals$O("") ) this.graph.addFunction$S(this.$function);
}C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'stop', function () {
C$.superclazz.prototype.stop.apply(this, []);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "DataGraph was written by W. Christian. Email:wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Function", "String", "A function to plot."]), Clazz.array(java.lang.String, -1, ["XMin", "double", "Minumum X value"]), Clazz.array(java.lang.String, -1, ["XMax", "double", "Maximum X value"]), Clazz.array(java.lang.String, -1, ["YMin", "double", "Minimum Y value"]), Clazz.array(java.lang.String, -1, ["YMax", "double", "Maximum Y value"]), Clazz.array(java.lang.String, -1, ["AutoScaleX", "boolean", "Autoscale the x axis."]), Clazz.array(java.lang.String, -1, ["AutoScaleY", "boolean", "Autoscale the y axis."]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the control buttons at the bottom of the applet."]), Clazz.array(java.lang.String, -1, ["DataFile", "String", "Data points file"])]);
return pinfo;
});

Clazz.newMeth(C$, 'clearSeriesBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.clearSeries$I(1);
});

Clazz.newMeth(C$, 'getGraphID', function () {
return this.graph.hashCode();
});

Clazz.newMeth(C$, ['getSeriesID$I','getSeriesID'], function (sid) {
return this.graph.getIDFromSID$I(sid);
});

Clazz.newMeth(C$, ['getRegressionID$I$I$I','getRegressionID'], function (sid, start, end) {
return this.graph.getRegressionID$I$I$I(sid, start, end);
});

Clazz.newMeth(C$, ['addData$I$DA$DA','addData'], function (sid, x, y) {
this.graph.addData$I$DA$DA(sid, x, y);
});

Clazz.newMeth(C$, ['addDatum$I$D$D','addDatum'], function (sid, x, y) {
this.graph.addDatum$I$D$D(sid, x, y);
});

Clazz.newMeth(C$, ['addCursor$D$D','addCursor'], function (x, y) {
return this.graph.addCursor$edu_davidson_tools_SApplet$I$D$D(this, 10, x, y);
});

Clazz.newMeth(C$, ['addConnectorLine$I$I','addConnectorLine'], function (id1, id2) {
return this.graph.addConnectorLine$edu_davidson_tools_SApplet$I$I(this, id1, id2);
});

Clazz.newMeth(C$, ['addObject$S$S','addObject'], function (name, parList) {
if (this.destroyed) return 0;
var t = null;
var x = 0;
var y = 0;
var width = 20;
var height = 20;
var r = 10;
name = name.toLowerCase().trim();
name = (I$[22]||$incl$(22)).removeWhitespace$S(name);
if (parList == null ) parList = " ";
var parList2 = parList.trim();
parList = (I$[22]||$incl$(22)).removeWhitespace$S(parList);
if (name.equals$O("graph")) {
t = Clazz.new_((I$[23]||$incl$(23)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable,[this, this.graph]);
} else if (name.equals$O("box")) {
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "w=")) width = ((I$[22]||$incl$(22)).getParam$S$S(parList, "w=")|0);
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "h=")) height = ((I$[22]||$incl$(22)).getParam$S$S(parList, "h=")|0);
t = Clazz.new_((I$[24]||$incl$(24)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I$I,[this, this.graph, x, y, width, height]);
} else if (name.equals$O("rectangle")) {
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "w=")) width = ((I$[22]||$incl$(22)).getParam$S$S(parList, "w=")|0);
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "h=")) height = ((I$[22]||$incl$(22)).getParam$S$S(parList, "h=")|0);
t = Clazz.new_((I$[25]||$incl$(25)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I$I,[this, this.graph, x, y, width, height]);
} else if (name.equals$O("protractor")) {
var s = 40;
var theta = 0;
var theta0 = 0;
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "theta=")) {
theta = (I$[22]||$incl$(22)).getParam$S$S(parList, "theta=");
}if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "theta0=")) {
theta0 = (I$[22]||$incl$(22)).getParam$S$S(parList, "theta0=");
}if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "s=")) {
s = ((I$[22]||$incl$(22)).getParam$S$S(parList, "s=")|0);
}var p = Clazz.new_((I$[26]||$incl$(26)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D$D$D,[this, this.graph, s, theta, theta0, x, y]);
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "fixedbase")) {
p.fixedBase = true;
}if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "fixedlength")) {
p.fixedlength = true;
}t = p;
} else if (name.equals$O("tangent")) {
var rise = 20;
var run = 20;
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "w=")) run = (I$[22]||$incl$(22)).getParam$S$S(parList, "w=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "h=")) rise = (I$[22]||$incl$(22)).getParam$S$S(parList, "h=");
t = Clazz.new_((I$[27]||$incl$(27)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$D$D,[this, this.graph, x, y, run, rise]);
} else if (name.equals$O("circle")) {
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "r=")) r = ((I$[22]||$incl$(22)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[28]||$incl$(28)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I,[this, this.graph, x, y, r]);
} else if (name.equals$O("cursor")) {
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "r=")) r = ((I$[22]||$incl$(22)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[29]||$incl$(29)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D,[this, this.graph, 2 * r + 1, x, y]);
} else if (name.equals$O("shell")) {
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "r=")) r = ((I$[22]||$incl$(22)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[30]||$incl$(30)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I,[this, this.graph, x, y, r]);
} else if (name.equals$O("phasewheel")) {
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "r=")) r = ((I$[22]||$incl$(22)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[31]||$incl$(31)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I,[this, this.graph, x, y, r]);
} else if (name.equals$O("arrow")) {
var h = 1;
var v = 1;
var s = 4;
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "s=")) s = ((I$[22]||$incl$(22)).getParam$S$S(parList, "s=")|0);
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "h=")) h = (I$[22]||$incl$(22)).getParam$S$S(parList, "h=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "v=")) v = (I$[22]||$incl$(22)).getParam$S$S(parList, "v=");
t = Clazz.new_((I$[32]||$incl$(32)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D$D$D,[this, this.graph, s, h, v, x, y]);
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "thickness=")) {
(t).thickness = Math.max(((I$[22]||$incl$(22)).getParam$S$S(parList, "thickness=")|0), 1);
}} else if (name.equals$O("text") || name.equals$O("calculation") ) {
var txt = "";
var calc = "";
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "txt=")) txt = (I$[22]||$incl$(22)).getParamStr$S$S(parList2, "txt=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "text=")) txt = (I$[22]||$incl$(22)).getParamStr$S$S(parList2, "text=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "calc=")) calc = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "calc=");
t = Clazz.new_((I$[33]||$incl$(33)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$S$S$D$D,[this, this.graph, txt, calc, x, y]);
} else if (name.equals$O("caption")) {
var txt = "";
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "txt=")) txt = (I$[22]||$incl$(22)).getParamStr$S$S(parList2, "txt=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "text=")) txt = (I$[22]||$incl$(22)).getParamStr$S$S(parList2, "text=");
t = Clazz.new_((I$[34]||$incl$(34)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$S$D$D,[this, this.graph, txt, x, y]);
} else if (name.equals$O("complexdata")) {
var ct = Clazz.new_((I$[35]||$incl$(35)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable,[this, this.graph]);
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "centered=")) {
ct.setCentered$Z((I$[22]||$incl$(22)).getParamStr$S$S(parList, "centered=").equals$O("true"));
}t = ct;
} else if (name.equals$O("function")) {
var func = "0";
var indVar = "x";
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "f=")) func = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "f=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "var=")) indVar = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "var=");
var id = this.addFunction$S$S(indVar, func);
if (((I$[22]||$incl$(22)).parameterExist$S$S(parList, "xmin=")) && ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "xmax=")) ) {
var n = 100;
n = Math.max((this.graph.getSize().width/2|0), n);
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "n=")) n = ((I$[22]||$incl$(22)).getParam$S$S(parList, "n=")|0);
var xmin = (I$[22]||$incl$(22)).getParam$S$S(parList, "xmin=");
var xmax = (I$[22]||$incl$(22)).getParam$S$S(parList, "xmax=");
this.graph.setFunctionRange$I$D$D$I(id, xmin, xmax, n);
}if (((I$[22]||$incl$(22)).parameterExist$S$S(parList, "ymin=")) && ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "ymax=")) ) {
var min = (I$[22]||$incl$(22)).getParam$S$S(parList, "ymin=");
var max = (I$[22]||$incl$(22)).getParam$S$S(parList, "ymax=");
this.graph.setFunctionClip$I$D$D(id, min, max);
}return id;
} else if (name.equals$O("vectorfield")) {
var fx = "0";
var fy = "0";
var n = 32;
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "fx=")) fx = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "fx=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "fy=")) fy = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "fy=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "n=")) n = ((I$[22]||$incl$(22)).getParam$S$S(parList, "n=")|0);
var id = this.graph.addVectorField$S$S$I(fx, fy, n);
return id;
} else if (name.equals$O("cfunction")) {
var funcRe = "0";
var funcIm = "0";
var indVar = "x";
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "re=")) funcRe = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "re=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "im=")) funcIm = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "im=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "var=")) indVar = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "var=");
var isCentered = true;
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "centered=")) {
isCentered = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "centered=").equals$O("true");
}var id = this.graph.addCFunction$S$S$S$Z(indVar, funcRe, funcIm, isCentered);
if (((I$[22]||$incl$(22)).parameterExist$S$S(parList, "xmin=")) && ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "xmax=")) ) {
var n = 100;
n = Math.max((this.graph.getSize().width/2|0), n);
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "n=")) n = ((I$[22]||$incl$(22)).getParam$S$S(parList, "n=")|0);
var xmin = (I$[22]||$incl$(22)).getParam$S$S(parList, "xmin=");
var xmax = (I$[22]||$incl$(22)).getParam$S$S(parList, "xmax=");
this.graph.setFunctionRange$I$D$D$I(id, xmin, xmax, 400);
}return id;
} else if (name.equals$O("image")) {
var file = " ";
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "x=")) x = (I$[22]||$incl$(22)).getParam$S$S(parList, "x=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "y=")) y = (I$[22]||$incl$(22)).getParam$S$S(parList, "y=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "gif=")) file = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "gif=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "file=")) file = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "file=");
if (file == null ) return 0;
var im = p$.getImage$S.apply(this, [file]);
if (im != null ) t = Clazz.new_((I$[36]||$incl$(36)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$java_awt_Image$D$D,[this, this.graph, im, x, y]);
 else t = null;
}if (t != null  && (I$[22]||$incl$(22)).parameterExist$S$S(parList, "label=") ) t.setLabel$S((I$[22]||$incl$(22)).getParamStr$S$S(parList2, "label="));
if (t == null ) {
System.out.println$S("Object not created. name:" + name + "parameter list:" + parList );
return 0;
}return this.graph.addThing$edu_davidson_display_Thing(t);
});

Clazz.newMeth(C$, 'getImage$S', function (file) {
var im;
try {
im = this.getImage$java_net_URL$S(this.getCodeBase(), file);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
im = null;
} else {
throw e;
}
}
if (im == null ) try {
im = this.getImage$java_net_URL$S(this.getDocumentBase(), file);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
im = null;
} else {
throw e;
}
}
if (im == null ) try {
var url = Clazz.new_((I$[37]||$incl$(37)).c$$S,[file]);
im = this.getImage$java_net_URL(url);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
im = null;
} else {
throw e;
}
}
if (im == null ) {
System.out.println$S("Failed to load image file.");
return im;
}var tracker = Clazz.new_((I$[38]||$incl$(38)).c$$java_awt_Component,[this]);
try {
tracker.addImage$java_awt_Image$I(im, 0);
tracker.waitForID$I$J(0, 1000);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return im;
});

Clazz.newMeth(C$, ['set$I$S$S','set'], function (id, name, parList) {
name = name.toLowerCase().trim();
name = (I$[22]||$incl$(22)).removeWhitespace$S(name);
parList = (I$[22]||$incl$(22)).removeWhitespace$S(parList);
var str = "true";
if (name.equals$O("scale")) {
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "autoscalex")) {
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "autoscalex=")) str = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "autoscalex=");
str = (I$[22]||$incl$(22)).removeWhitespace$S(str.toLowerCase());
if (str.equals$O("false")) this.graph.setAutoscaleX$Z(false);
 else this.graph.setAutoscaleX$Z(true);
}if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "noautoscalex")) {
this.graph.setAutoscaleX$Z(false);
}if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "autoscaley")) {
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "autoscaley=")) str = (I$[22]||$incl$(22)).getParamStr$S$S(parList, "autoscaley=");
str = (I$[22]||$incl$(22)).removeWhitespace$S(str.toLowerCase());
if (str.equals$O("false")) this.graph.setAutoscaleY$Z(false);
 else this.graph.setAutoscaleY$Z(true);
}if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "noautoscaley")) {
this.graph.setAutoscaleY$Z(false);
}var xmin = this.graph.getMinX();
var xmax = this.graph.getMaxX();
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "xmin=")) xmin = (I$[22]||$incl$(22)).getParam$S$S(parList, "xmin=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "xmax=")) xmax = (I$[22]||$incl$(22)).getParam$S$S(parList, "xmax=");
if (((I$[22]||$incl$(22)).parameterExist$S$S(parList, "xmin=")) || ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "xmax=")) ) {
this.graph.setMinMaxX$D$D(xmin, xmax);
}var ymin = this.graph.getMinY();
var ymax = this.graph.getMaxY();
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "ymin=")) ymin = (I$[22]||$incl$(22)).getParam$S$S(parList, "ymin=");
if ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "ymax=")) ymax = (I$[22]||$incl$(22)).getParam$S$S(parList, "ymax=");
if (((I$[22]||$incl$(22)).parameterExist$S$S(parList, "ymin=")) || ((I$[22]||$incl$(22)).parameterExist$S$S(parList, "ymax=")) ) {
this.graph.setMinMaxY$D$D(ymin, ymax);
}return true;
}var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object property not set.  Property name=" + name + "Property value=" + parList );
return false;
}return false;
});

Clazz.newMeth(C$, ['setAnimationSlave$I$I','setAnimationSlave'], function (masterID, slaveID) {
var master = this.graph.getThing$I(masterID);
var slave = this.graph.getThing$I(slaveID);
if (master == null  || slave == null  ) return false;
master.addSlave$edu_davidson_display_Thing(slave);
if (this.autoRefresh) this.graph.repaint();
return true;
});

Clazz.newMeth(C$, ['addFunction$S$S','addFunction'], function (indVar, str) {
if (str != null ) this.funcField.setText$S(str);
return this.graph.addFunction$S$S(indVar, str);
});

Clazz.newMeth(C$, ['addCFunction$S$S$S','addCFunction'], function (indVar, strRe, strIm) {
return this.graph.addCFunction$S$S$S$Z(indVar, strRe, strIm, true);
});

Clazz.newMeth(C$, ['deleteFunction$I','deleteFunction'], function (id) {
this.graph.deleteFunction$I(id);
});

Clazz.newMeth(C$, ['deleteObject$I','deleteObject'], function (id) {
this.graph.deleteObject$I(id);
});

Clazz.newMeth(C$, 'deleteAllFunctions', function () {
this.graph.deleteAllFunctions();
});

Clazz.newMeth(C$, ['createSeries$I','createSeries'], function (sid) {
this.graph.createSeries$I(sid);
return this.graph.getIDFromSID$I(sid);
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (s) {
this.graph.deleteSeries$I(s);
});

Clazz.newMeth(C$, 'deleteAllSeries', function () {
this.graph.deleteAllSeries();
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (s) {
this.graph.clearSeriesData$I(s);
});

Clazz.newMeth(C$, 'clearAllSeries', function () {
this.graph.clearAllSeries();
});

Clazz.newMeth(C$, ['makeDataConnection$I$I$I$S$S','makeDataConnection'], function (sourceID, listenerID, seriesID, xStr, yStr) {
var source = this.graph.getThing$I(sourceID);
if (Clazz.instanceOf(source, "edu.davidson.tools.SStepable")) {
this.clock.addClockListener$edu_davidson_tools_SStepable(source);
source.setTime$D(this.clock.getTime());
}return C$.superclazz.prototype.makeDataConnection$I$I$I$S$S.apply(this, [sourceID, listenerID, seriesID, xStr, yStr]);
});

Clazz.newMeth(C$, ['loadDataFile$I$S','loadDataFile'], function (sid, fileName) {
this.graph.loadFile$I$S(sid, fileName);
});

Clazz.newMeth(C$, ['plotRegression$I$I$I','plotRegression'], function (sid, start, end) {
return this.graph.plotRegression$I$I$I(sid, start, end);
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (auto) {
this.autoRefresh = auto;
this.graph.setAutoRefresh$Z(auto);
});

Clazz.newMeth(C$, ['setAddRepeatedDatum$I$Z','setAddRepeatedDatum'], function (sid, add) {
this.graph.setAddRepeatedDatum$I$Z(sid, add);
});

Clazz.newMeth(C$, ['setAutoscaleX$Z','setAutoscaleX'], function (autoOn) {
this.graph.setAutoscaleX$Z(autoOn);
});

Clazz.newMeth(C$, ['setAutoscaleY$Z','setAutoscaleY'], function (autoOn) {
this.graph.setAutoscaleY$Z(autoOn);
});

Clazz.newMeth(C$, ['setDrawGrid$Z','setDrawGrid'], function (drawOn) {
this.graph.setDrawGrid$Z(drawOn);
});

Clazz.newMeth(C$, ['setDrawZero$Z','setDrawZero'], function (drawOn) {
this.graph.setDrawZero$Z(drawOn);
});

Clazz.newMeth(C$, 'setDefault', function () {
this.clock.stopClock();
this.clock.setTime$D(0);
this.graph.setTimeDisplay$Z(false);
this.clock.removeClockListener$edu_davidson_tools_SStepable(this.graph);
this.graph.deleteAllSeries();
this.graph.deleteAllFunctions();
this.graph.clearAllThings();
this.deleteDataConnections();
});

Clazz.newMeth(C$, ['getH$I','getH'], function (id) {
var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not found in getH method.");
return 0;
}return t.getHeight();
});

Clazz.newMeth(C$, ['setH$I$D','setH'], function (id, h) {
var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not found in setH method.");
return false;
}t.setHeight$I((h|0));
return true;
});

Clazz.newMeth(C$, ['getW$I','getW'], function (id) {
var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not found in getW method.");
return 0;
}return t.getWidth();
});

Clazz.newMeth(C$, ['setW$I$D','setW'], function (id, w) {
var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not found in setW method.");
return false;
}t.setWidth$I((w|0));
return true;
});

Clazz.newMeth(C$, ['getX$I','getX'], function (id) {
var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not found in getX method.");
return 0;
}return t.getX();
});

Clazz.newMeth(C$, ['getY$I','getY'], function (id) {
var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not found in getY method.");
return 0;
}return t.getY();
});

Clazz.newMeth(C$, ['getXPos$I','getXPos'], function (id) {
return this.getX$I(id);
});

Clazz.newMeth(C$, ['getYPos$I','getYPos'], function (id) {
return this.getY$I(id);
});

Clazz.newMeth(C$, ['setXY$I$D$D','setXY'], function (id, x, y) {
var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not found in setX method.");
return false;
}t.setXY$D$D(x, y);
t.updateMySlaves();
if (!this.clock.isRunning()) this.updateDataConnections();
return true;
});

Clazz.newMeth(C$, ['setX$I$D','setX'], function (id, x) {
var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not found in setX method.");
return false;
}t.setX$D(x);
t.updateMySlaves();
if (!this.clock.isRunning()) this.updateDataConnections();
return true;
});

Clazz.newMeth(C$, ['setXPos$I$D','setXPos'], function (id, x) {
return this.setX$I$D(id, x);
});

Clazz.newMeth(C$, ['setY$I$D','setY'], function (id, y) {
var t = this.graph.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not found in setY method.");
return false;
}t.setY$D(y);
t.updateMySlaves();
if (!this.clock.isRunning()) this.updateDataConnections();
return true;
});

Clazz.newMeth(C$, ['setYPos$I$D','setYPos'], function (id, y) {
return this.setY$I$D(id, y);
});

Clazz.newMeth(C$, ['setVisibility$I$Z','setVisibility'], function (id, show) {
var t = this.graph.getThing$I(id);
if (t != null ) {
t.setVisible$Z(show);
if (this.autoRefresh) this.graph.repaint();
return true;
}var func = this.graph.getFunction$I(id);
if (func != null ) {
func.visible = show;
if (this.autoRefresh) this.graph.repaint();
return true;
}return false;
});

Clazz.newMeth(C$, ['setDisplayOffset$I$I$I','setDisplayOffset'], function (id, xOff, yOff) {
var t = this.graph.getThing$I(id);
if (t == null ) return false;
t.setDisplayOff$I$I(xOff, yOff);
if (this.autoRefresh) this.graph.repaint();
return true;
});

Clazz.newMeth(C$, ['setDragable$I$Z','setDragable'], function (id, drag) {
var t = this.graph.getThing$I(id);
if (t == null ) return false;
t.setDragable$Z(drag);
return true;
});

Clazz.newMeth(C$, ['setResizable$I$Z','setResizable'], function (id, resize) {
var t = this.graph.getThing$I(id);
if (t == null ) return false;
t.setResizable$Z(resize);
return true;
});

Clazz.newMeth(C$, ['setSketchMode$Z','setSketchMode'], function (sketch) {
return this.graph.setSketchMode$Z(sketch);
});

Clazz.newMeth(C$, ['setEnableMouse$Z','setEnableMouse'], function (mouseOn) {
this.graph.setEnableMouse$Z(mouseOn);
});

Clazz.newMeth(C$, ['setFunctionRange$I$D$D$I','setFunctionRange'], function (id, xmin, xmax, n) {
this.graph.setFunctionRange$I$D$D$I(id, xmin, xmax, n);
});

Clazz.newMeth(C$, ['setFunctionClip$I$D$D','setFunctionClip'], function (id, min, max) {
this.graph.setFunctionClip$I$D$D(id, min, max);
});

Clazz.newMeth(C$, ['setYScaleFromFunction$I','setYScaleFromFunction'], function (id) {
this.graph.setYScaleFromFunction$I(id);
});

Clazz.newMeth(C$, ['setFunctionString$I$S','setFunctionString'], function (id, str) {
if (str != null ) this.funcField.setText$S(str);
return this.graph.setFunctionString$I$S(id, str);
});

Clazz.newMeth(C$, ['swapZOrder$I$I','swapZOrder'], function (id1, id2) {
return this.graph.swapZOrder$I$I(id1, id2);
});

Clazz.newMeth(C$, ['getFunctionString$I','getFunctionString'], function (id) {
return this.graph.getFunctionString$I(id);
});

Clazz.newMeth(C$, ['setFunctionVariable$I$S','setFunctionVariable'], function (id, str) {
return this.graph.setFunctionVariable$I$S(id, str);
});

Clazz.newMeth(C$, ['setGutters$I$I$I$I','setGutters'], function (g1, g2, g3, g4) {
this.graph.setGutters$I$I$I$I(g1, g2, g3, g4);
});

Clazz.newMeth(C$, ['setFormat$S','setFormat'], function (str) {
this.graph.setFormat$S(str);
});

Clazz.newMeth(C$, 'cloneGraph', function () {
var graphFrame = Clazz.new_((I$[39]||$incl$(39)).c$$edu_davidson_display_SGraph,[this.graph.clone()]);
graphFrame.setSize$I$I(this.getSize().width, this.getSize().height);
graphFrame.show();
});

Clazz.newMeth(C$, ['setFormat$I$S','setFormat'], function (id, fstr) {
var t = this.graph.getThing$I(id);
if (t == null  && (id == 0 || id == this.graph.hashCode() ) ) {
this.graph.setFormat$S(fstr);
return true;
}var result = t.setFormat$S(fstr);
if (this.autoRefresh) this.graph.repaint();
return result;
});

Clazz.newMeth(C$, ['setLabelX$S','setLabelX'], function (s) {
this.graph.setLabelX$S(s);
});

Clazz.newMeth(C$, ['setLabelY$S','setLabelY'], function (s) {
this.graph.setLabelY$S(s);
});

Clazz.newMeth(C$, ['setMarkerSize$I$D','setMarkerSize'], function (id, size) {
this.graph.setMarkerSize$I$D(id, size);
});

Clazz.newMeth(C$, ['setMinMaxX$D$D','setMinMaxX'], function (min, max) {
this.graph.setMinMaxX$D$D(min, max);
});

Clazz.newMeth(C$, ['setMinMaxY$D$D','setMinMaxY'], function (min, max) {
this.graph.setMinMaxY$D$D(min, max);
});

Clazz.newMeth(C$, ['setMinXRange$Z$D$D','setMinXRange'], function (enable, min, max) {
this.graph.setMinXRange$Z$D$D(enable, min, max);
});

Clazz.newMeth(C$, ['setMinYRange$Z$D$D','setMinYRange'], function (enable, min, max) {
this.graph.setMinYRange$Z$D$D(enable, min, max);
});

Clazz.newMeth(C$, ['setSeriesLegend$I$I$I$S','setSeriesLegend'], function (id, xpix, ypix, legend) {
this.graph.setSeriesLegend$I$I$I$S(id, xpix, ypix, legend);
});

Clazz.newMeth(C$, ['setSeriesLegendRGB$I$I$I$I','setSeriesLegendRGB'], function (id, r, g, b) {
this.graph.setSeriesLegendColor$I$java_awt_Color(id, Clazz.new_((I$[13]||$incl$(13)).c$$I$I$I,[r, g, b]));
});

Clazz.newMeth(C$, ['setSeriesStyle$I$Z$I','setSeriesStyle'], function (id, conPts, m) {
this.graph.setSeriesStyle$I$Z$I(id, conPts, m);
});

Clazz.newMeth(C$, ['setSeriesRGB$I$I$I$I','setSeriesRGB'], function (id, r, g, b) {
this.graph.setSeriesColor$I$java_awt_Color(id, Clazz.new_((I$[13]||$incl$(13)).c$$I$I$I,[r, g, b]));
});

Clazz.newMeth(C$, ['setRGB$I$I$I$I','setRGB'], function (id, r, g, b) {
var c = Clazz.new_((I$[13]||$incl$(13)).c$$I$I$I,[r, g, b]);
this.graph.setObjectColor$I$java_awt_Color(id, c);
});

Clazz.newMeth(C$, ['setAutoReplaceData$I$Z','setAutoReplaceData'], function (id, auto) {
this.graph.setAutoReplaceData$I$Z(id, auto);
});

Clazz.newMeth(C$, ['setLastPointMarker$I$Z','setLastPointMarker'], function (id, lpm) {
this.graph.setLastPointMarker$I$Z(id, lpm);
});

Clazz.newMeth(C$, ['setTitle$S','setTitle'], function (str) {
this.graph.setTitle$S(str);
});

Clazz.newMeth(C$, ['setTimeDisplay$Z','setTimeDisplay'], function (show) {
this.graph.setTimeDisplay$Z(show);
if (this.autoRefresh) this.graph.repaint();
});

Clazz.newMeth(C$, ['setShowAxes$Z','setShowAxes'], function (show) {
if (this.graph.isShowAxis() == show ) return;
if (show) {
this.graph.setGutters$I$I$I$I(20, 20, 20, 20);
this.graph.drawgrid = true;
} else {
this.graph.setGutters$I$I$I$I(0, 0, 0, 0);
this.graph.drawgrid = false;
}this.graph.setShowAxes$Z(show);
});

Clazz.newMeth(C$, ['setSquare$Z','setSquare'], function (isSquare) {
this.graph.setSquare$Z(isSquare);
});

Clazz.newMeth(C$, ['setSorted$I$Z','setSorted'], function (sid, sorted) {
this.graph.setSeriesSorted$I$Z(sid, sorted);
});

Clazz.newMeth(C$, ['setStripChart$I$I$Z','setStripChart'], function (sid, numPts, stripChart) {
this.graph.setSeriesStripChart$I$I$Z(sid, numPts, stripChart);
});

Clazz.newMeth(C$, ['xFromPix$I','xFromPix'], function (x) {
return this.graph.xFromPix$I(x);
});

Clazz.newMeth(C$, ['yFromPix$I','yFromPix'], function (y) {
return this.graph.yFromPix$I(y);
});

Clazz.newMeth(C$, ['pixFromX$D','pixFromX'], function (x) {
return this.graph.pixFromX$D(x);
});

Clazz.newMeth(C$, ['pixFromY$D','pixFromY'], function (y) {
return this.graph.pixFromY$D(y);
});

Clazz.newMeth(C$, 'addFuncBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.graph.deleteAllFunctions();
this.addFunction$S$S("x", this.funcField.getText());
});

Clazz.newMeth(C$, 'addDatumBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.addDatum$I$D$D(1, this.xField.getValue(), this.yField.getValue());
});

Clazz.newMeth(C$, 'button4_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.graph.clearAllData();
});

Clazz.newMeth(C$, 'clearFuncBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.graph.deleteAllFunctions();
});
})();
//Created 2018-03-16 05:19:04
