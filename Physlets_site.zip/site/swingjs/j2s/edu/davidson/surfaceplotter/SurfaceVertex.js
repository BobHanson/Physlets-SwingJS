(function(){var P$=Clazz.newPackage("edu.davidson.surfaceplotter"),I$=[];
var C$=Clazz.newClass(P$, "SurfaceVertex");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.surfaceCanvas = null;
this.$projection = null;
this.project_index = 0;
this.x = 0;
this.y = 0;
this.z = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$edu_davidson_surfaceplotter_SurfaceCanvas', function (ix, iy, iz, sc) {
C$.$init$.apply(this);
this.surfaceCanvas = sc;
this.x = ix;
this.y = iy;
this.z = iz;
this.project_index = sc.master_project_indexV - 1;
}, 1);

Clazz.newMeth(C$, 'isInvalid', function () {
return Float.isNaN(this.z);
});

Clazz.newMeth(C$, 'projection', function () {
if (this.project_index != this.surfaceCanvas.master_project_indexV) {
this.$projection = this.surfaceCanvas.projector.project$F$F$F(this.x, this.y, (this.z - this.surfaceCanvas.zminV) * this.surfaceCanvas.zfactorV - 10);
this.project_index = this.surfaceCanvas.master_project_indexV;
}return this.$projection;
});

Clazz.newMeth(C$, 'transform', function () {
this.x = this.x / this.surfaceCanvas.projector.getXScaling();
this.y = this.y / this.surfaceCanvas.projector.getYScaling();
this.z = (this.surfaceCanvas.zmaxV - this.surfaceCanvas.zminV) * (this.z / this.surfaceCanvas.projector.getZScaling() + 10) / 20 + this.surfaceCanvas.zminV;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:07:02
