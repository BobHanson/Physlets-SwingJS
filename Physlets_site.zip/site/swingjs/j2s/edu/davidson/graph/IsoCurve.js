(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['java.util.Vector','edu.davidson.graph.Cell']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "IsoCurve");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.cells = null;
this.grid = null;
this.nx = 0;
this.ny = 0;
this.curve = null;
this.size = 0;
this.value = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.cells = null;
this.grid = null;
this.nx = 0;
this.ny = 0;
this.curve = null;
this.size = 0;
this.value = 0.0;
}, 1);

Clazz.newMeth(C$, 'c$$DA$I$I', function (grid, nx, ny) {
C$.c$.apply(this, []);
this.setGrid$DA$I$I(grid, nx, ny);
}, 1);

Clazz.newMeth(C$, 'setGrid$DA$I$I', function (grid, nx, ny) {
this.grid = grid;
this.nx = nx;
this.ny = ny;
});

Clazz.newMeth(C$, 'setValue$D', function (value) {
this.value = value;
if (this.grid == null ) return;
this.createCells();
});

Clazz.newMeth(C$, 'getCurve', function () {
this.size = 0;
this.getcurve();
if (this.size == 0 || this.curve == null  ) {
return null;
}var tmp = Clazz.array(Double.TYPE, [this.size]);
System.arraycopy(this.curve, 0, tmp, 0, this.size);
return tmp;
});

Clazz.newMeth(C$, 'createCells', function () {
var bl;
var br;
var tl;
var tr;
var bottom;
var top;
var right;
var left;
var cell;
var jcell;
var icell;
var i;
var j;
var count;
if (this.cells == null ) this.cells = Clazz.new_((I$[1]||$incl$(1)));
 else this.cells.removeAllElements();
for (j = 0; j < this.ny - 1; j++) {
jcell = j * this.nx;
for (i = 0; i < this.nx - 1; i++) {
icell = i + jcell;
bl = this.grid[icell];
br = this.grid[icell + 1];
tl = this.grid[icell + this.nx];
tr = this.grid[icell + this.nx + 1 ];
bottom = false;
top = false;
left = false;
right = false;
if ((bl - this.value) * (br - this.value) <= 0.0 ) bottom = true;
if ((br - this.value) * (tr - this.value) <= 0.0 ) right = true;
if ((tr - this.value) * (tl - this.value) <= 0.0 ) top = true;
if ((tl - this.value) * (bl - this.value) <= 0.0 ) left = true;
if (top && bottom && left && right  ) {
if (tr >= tl  && bl >= br  ) {
cell = Clazz.new_((I$[2]||$incl$(2)));
cell.i = i;
cell.j = j;
cell.face[0] = 3;
cell.face[1] = 1;
this.cells.addElement$TE(cell);
cell = Clazz.new_((I$[2]||$incl$(2)));
cell.i = i;
cell.j = j;
cell.face[0] = 4;
cell.face[1] = 2;
this.cells.addElement$TE(cell);
} else if (tl >= tr  && br >= bl  ) {
cell = Clazz.new_((I$[2]||$incl$(2)));
cell.i = i;
cell.j = j;
cell.face[0] = 3;
cell.face[1] = 1;
this.cells.addElement$TE(cell);
cell = Clazz.new_((I$[2]||$incl$(2)));
cell.i = i;
cell.j = j;
cell.face[0] = 4;
cell.face[1] = 2;
}} else if (top || bottom || left || right  ) {
cell = Clazz.new_((I$[2]||$incl$(2)));
this.cells.addElement$TE(cell);
cell.i = i;
cell.j = j;
if (bl == this.value  && br == this.value  ) bottom = false;
if (bl == this.value  && tl == this.value  ) left = false;
if (tr == this.value  && tl == this.value  ) top = false;
if (tr == this.value  && br == this.value  ) right = false;
count = 0;
if (bottom) count++;
if (top) count++;
if (left) count++;
if (right) count++;
if (count > 2) {
} else {
count = 0;
if (bottom) {
cell.face[count] = 4;
count++;
}if (top) {
cell.face[count] = 3;
count++;
}if (left) {
cell.face[count] = 1;
count++;
}if (right) {
cell.face[count] = 2;
count++;
}}}}
}
});

Clazz.newMeth(C$, 'getcurve', function () {
var current;
var face = 0;
var ifcell = -1;
var jfcell = -1;
var icell;
var jcell;
var bl;
var br;
var tl;
var tr;
var index;
var i;
var d = Clazz.array(Double.TYPE, [2]);
this.size = 0;
if (this.cells == null  || this.cells.isEmpty() ) return;
current = (this.cells.firstElement());
if (current.face[0] == 0 && current.face[1] == 0 ) {
this.cells.removeElement$O(current);
return;
}icell = current.i;
jcell = current.j;
ifcell = -1;
jfcell = -1;
if (this.search$I$I(icell - 1, jcell) == null  && (current.face[0] == 1 || current.face[1] == 1 ) ) {
this.addDataPoint$I$I$I(1, icell, jcell);
face = 1;
} else if (this.search$I$I(icell + 1, jcell) == null  && (current.face[0] == 2 || current.face[1] == 2 ) ) {
this.addDataPoint$I$I$I(2, icell, jcell);
face = 2;
} else if (this.search$I$I(icell, jcell - this.nx) == null  && (current.face[0] == 4 || current.face[1] == 4 ) ) {
this.addDataPoint$I$I$I(4, icell, jcell);
face = 4;
} else if (this.search$I$I(icell, jcell + this.nx) == null  && (current.face[0] == 3 || current.face[1] == 3 ) ) {
this.addDataPoint$I$I$I(3, icell, jcell);
face = 3;
} else {
index = 0;
if (current.face[0] == 0) index = 1;
this.addDataPoint$I$I$I(current.face[index], icell, jcell);
face = current.face[index];
if (face == 3) {
ifcell = current.i;
jfcell = current.j + 1;
} else if (face == 4) {
ifcell = current.i;
jfcell = current.j - 1;
} else if (face == 1) {
ifcell = current.i - 1;
jfcell = current.j;
} else if (face == 2) {
ifcell = current.i + 1;
jfcell = current.j;
}}while (current != null ){
icell = current.i;
jcell = current.j;
if (current.face[0] == face) face = current.face[1];
 else face = current.face[0];
if (face != 0) this.addDataPoint$I$I$I(face, icell, jcell);
if (face == 3) {
jcell++;
face = 4;
} else if (face == 4) {
jcell--;
face = 3;
} else if (face == 1) {
icell--;
face = 2;
} else if (face == 2) {
icell++;
face = 1;
}this.cells.removeElement$O(current);
if (icell == ifcell && jcell == jfcell ) {
this.addDataPoint$D$D(this.curve[0], this.curve[1]);
current = null;
} else {
current = this.search$I$I(icell, jcell);
}}
});

Clazz.newMeth(C$, 'getPoint$I$I$I', function (wall, icell, jcell) {
var d = Clazz.array(Double.TYPE, [2]);
var bl;
var br;
var tl;
var tr;
var index = icell + jcell * this.nx;
if (wall == 3) {
tl = this.grid[index + this.nx];
tr = this.grid[index + this.nx + 1 ];
d[1] = (jcell + 1);
d[0] = icell + (this.value - tl) / (tr - tl);
} else if (wall == 4) {
bl = this.grid[index];
br = this.grid[index + 1];
d[1] = jcell;
d[0] = icell + (this.value - bl) / (br - bl);
} else if (wall == 1) {
bl = this.grid[index];
tl = this.grid[index + this.nx];
d[1] = jcell + (this.value - bl) / (tl - bl);
d[0] = icell;
} else if (wall == 2) {
br = this.grid[index + 1];
tr = this.grid[index + 1 + this.nx ];
d[1] = jcell + (this.value - br) / (tr - br);
d[0] = (icell + 1);
}return d;
});

Clazz.newMeth(C$, 'addDataPoint$I$I$I', function (wall, icell, jcell) {
var d;
d = this.getPoint$I$I$I(wall, icell, jcell);
this.addDataPoint$D$D(d[0], d[1]);
});

Clazz.newMeth(C$, 'addDataPoint$D$D', function (x, y) {
if (this.size >= 1998) return;
if (this.curve == null ) {
this.curve = Clazz.array(Double.TYPE, [100]);
} else if (this.size == this.curve.length - 2) {
var tmp = Clazz.array(Double.TYPE, [2 * this.size]);
System.arraycopy(this.curve, 0, tmp, 0, this.size);
this.curve = tmp;
}this.curve[this.size] = x;
this.size++;
this.curve[this.size] = y;
this.size++;
});

Clazz.newMeth(C$, 'search$I$I', function (icell, jcell) {
var i;
var current = null;
if (this.cells.isEmpty()) return null;
for (i = 0; i < this.cells.size(); i++) {
current = (this.cells.elementAt$I(i));
if (current.i == icell && current.j == jcell ) return current;
}
return null;
});
})();
//Created 2018-02-06 13:05:38
