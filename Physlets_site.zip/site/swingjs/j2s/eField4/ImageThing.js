(function(){var P$=Clazz.newPackage("eField4"),I$=[];
var C$=Clazz.newClass(P$, "ImageThing", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.image=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$java_awt_Image$D$D', function (p, im, x, y) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [p, x, y, 0, 0]);
C$.$init$.apply(this);
this.image=im;
this.w=im.getWidth$java_awt_image_ImageObserver(p);
this.h=im.getHeight$java_awt_image_ImageObserver(p);
this.noDrag=true;
}, 1);

Clazz.newMeth(C$, 'getImage$', function () {
return this.image;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX=this.p.pixFromX$D(this.vars[1]) + this.xDisplayOff + (this.w/2|0) ;
var ptY=this.p.pixFromY$D(this.vars[2]) - this.yDisplayOff + (this.h/2|0);
if ((Math.abs(xPix - ptX) < (this.w/2|0) + 1) && (Math.abs(yPix - ptY) < (this.h/2|0) + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.hideThing) return;
this.w=this.image.getWidth$java_awt_image_ImageObserver(this.p);
this.h=this.image.getHeight$java_awt_image_ImageObserver(this.p);
if (this.w == -1 || this.h == -1 ) return;
var ptX=Math.round(this.p.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY=Math.round(this.p.pixFromY$D(this.vars[2])) - this.yDisplayOff;
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.image, ptX, ptY, this.p);
this.paintTrail$java_awt_Graphics(g);
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:19 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
