(function(){var P$=Clazz.newPackage("circuitsimulator");
var C$=Clazz.newClass(P$, "BranchPoint");

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.xcoord=0;
this.ycoord=0;
this.iIndex=null;
this.iSign=null;
this.lastDirection=0;
this.toDefine=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.iIndex=Clazz.array(Integer.TYPE, [4]);
this.iSign=Clazz.array(Integer.TYPE, [4]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.xcoord=0;
this.ycoord=0;
for (var i=0; i < 4; i++) {
this.iIndex[i]=0;
this.iSign[i]=0;
}
this.lastDirection=0;
this.toDefine=4;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_GridElement$I$I$I$I$I', function (curel, x, y, comeFromDir, goToDir, iInd) {
C$.$init$.apply(this);
this.xcoord=x;
this.ycoord=y;
this.iIndex[(comeFromDir + 2) % 4]=iInd;
this.iSign[(comeFromDir + 2) % 4]=-1;
this.iIndex[goToDir]=iInd + 1;
this.iSign[goToDir]=1;
this.lastDirection=goToDir;
this.toDefine=curel.numberOfCons$() - 2;
}, 1);

Clazz.newMeth(C$, 'start$circuitsimulator_GridElement$I', function (curel, iInd) {
var direction;
direction=(this.lastDirection + 1) % 4;
while (!!(curel.connection[direction] == null  | this.iSign[direction] != 0))direction=(direction + 1) % 4;

this.iIndex[direction]=iInd + 1;
this.iSign[direction]=1;
this.lastDirection=direction;
this.toDefine--;
return direction;
});

Clazz.newMeth(C$, 'stop$I$I', function (direction, iInd) {
this.iIndex[(direction + 2) % 4]=iInd;
this.iSign[(direction + 2) % 4]=-1;
this.lastDirection=direction;
this.toDefine--;
});

Clazz.newMeth(C$, 'print$', function () {
System.out.println$S("BranchPoint: x/y/lastDir/todefine: " + this.xcoord + "/" + this.ycoord + "/" + this.lastDirection + "/" + this.toDefine );
for (var i=0; i < 4; i++) {
System.out.print$S(this.iIndex[i] + " " + this.iSign[i] + " " );
}
System.out.println$();
});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:48 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
