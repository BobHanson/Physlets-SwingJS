(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'edu.davidson.tools.SUtil','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Probe", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.type=null;
this.row2=0;
this.col2=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.type="voltage";
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$S$I$I$I$I', function (circuit, ntype, rb, cb, re, ce) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$S.apply(this, [circuit, rb, cb, "h"]);
C$.$init$.apply(this);
this.type="" + ntype;
this.row2=re;
this.col2=ce;
}, 1);

Clazz.newMeth(C$, 'set$S', function (list) {
list=list.toLowerCase$().trim$();
list=$I$(1).removeWhitespace$S(list);
if ($I$(1).parameterExist$S$S(list, "type=")) this.type="" + $I$(1).getParamStr$S$S(list, "type=");
if ($I$(1).parameterExist$S$S(list, "row=")) this.row=($I$(1).getParam$S$S(list, "row=")|0);
if ($I$(1).parameterExist$S$S(list, "col=")) this.col=($I$(1).getParam$S$S(list, "col=")|0);
if ($I$(1).parameterExist$S$S(list, "row2=")) this.row2=($I$(1).getParam$S$S(list, "row2=")|0);
if ($I$(1).parameterExist$S$S(list, "col2=")) this.col2=($I$(1).getParam$S$S(list, "col2=")|0);
return true;
});

Clazz.newMeth(C$, 'getI$', function () {
return 0.0;
});

Clazz.newMeth(C$, 'getV$', function () {
var b=this.circuit.cirgrid.element[this.row][this.col].getVIndex$();
var e=this.circuit.cirgrid.element[this.row2][this.col2].getVIndex$();
return this.circuit.cirgrid.y[e] - this.circuit.cirgrid.y[b];
});

Clazz.newMeth(C$, 'getAddObjectString$', function () {
var s="addObject(\"" + this.getMyName$() + "\",\"type=" + this.type + ",row=" + this.row + ",col=" + this.col + ",row2=" + this.row2 + ",col2=" + this.col2 + "\");\n" ;
return s;
});

Clazz.newMeth(C$, 'paintImage$java_awt_Graphics', function (g) {
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var d=this.circuit.interGrid;
var b=(d/2|0);
g.setFont$java_awt_Font(this.$font);
g.setColor$java_awt_Color($I$(2).blue);
g.fillOval$I$I$I$I(b + this.col * d - 3, b + this.row * d - 3, 6, 6);
g.drawString$S$I$I(this.label + "-", b + this.col * d + 3, b + this.row * d - 3);
g.fillOval$I$I$I$I(b + this.col2 * d - 3, b + this.row2 * d - 3, 6, 6);
g.drawString$S$I$I(this.label + "+", b + this.col2 * d + 3, b + this.row2 * d - 3);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:49 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
