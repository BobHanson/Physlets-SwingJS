(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['edu.davidson.graphics.Assert','java.awt.SystemColor','java.awt.Rectangle']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DrawnRectangle", null, 'java.awt.Rectangle');
C$._defaultThickness = 0;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$._defaultThickness = 2;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.drawInto = null;
this.thick = 0;
this.lineColor = null;
this.fillColor = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component', function (drawInto) {
C$.c$$java_awt_Component$I$I$I$I$I.apply(this, [drawInto, C$._defaultThickness, 0, 0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I', function (drawInto, thick) {
C$.c$$java_awt_Component$I$I$I$I$I.apply(this, [drawInto, thick, 0, 0, 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I$I$I$I', function (drawInto, x, y, w, h) {
C$.c$$java_awt_Component$I$I$I$I$I.apply(this, [drawInto, C$._defaultThickness, x, y, w, h]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$I$I$I$I$I', function (drawInto, thick, x, y, w, h) {
Clazz.super_(C$, this,1);
(I$[1]||$incl$(1)).notNull$O(drawInto);
(I$[1]||$incl$(1)).notFalse$Z(thick > 0);
this.drawInto=drawInto;
this.thick=thick;
this.setBounds$I$I$I$I(x, y, w, h);
}, 1);

Clazz.newMeth(C$, 'component', function () {
return this.drawInto;
});

Clazz.newMeth(C$, 'getThickness', function () {
return this.thick;
});

Clazz.newMeth(C$, 'setThickness$I', function (thick) {
this.thick=thick;
});

Clazz.newMeth(C$, 'setLineColor$java_awt_Color', function (lineColor) {
this.lineColor=lineColor;
});

Clazz.newMeth(C$, 'setFillColor$java_awt_Color', function (fillColor) {
this.fillColor=fillColor;
});

Clazz.newMeth(C$, 'fill', function () {
this.fill$java_awt_Color(this.getFillColor());
});

Clazz.newMeth(C$, 'getLineColor', function () {
if (this.lineColor == null ) this.lineColor=(I$[2]||$incl$(2)).controlShadow;
return this.lineColor;
});

Clazz.newMeth(C$, 'getFillColor', function () {
if (this.fillColor == null ) this.fillColor=this.drawInto.getBackground();
return this.fillColor;
});

Clazz.newMeth(C$, 'getInnerBounds', function () {
return Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I$I,[this.x + this.thick, this.y + this.thick, this.width - (this.thick * 2), this.height - (this.thick * 2)]);
});

Clazz.newMeth(C$, 'paint', function () {
var g = this.drawInto.getGraphics();
p$.paintFlat$java_awt_Graphics$java_awt_Color.apply(this, [g, this.getLineColor()]);
});

Clazz.newMeth(C$, 'paintFlat$java_awt_Graphics$java_awt_Color', function (g, color) {
if (g != null ) {
g.setColor$java_awt_Color(color);
for (var i = 0; i < this.thick; ++i) g.drawRect$I$I$I$I(this.x + i, this.y + i, this.width - (i * 2) - 1 , this.height - (i * 2) - 1 );

g.dispose();
}});

Clazz.newMeth(C$, 'clearInterior', function () {
this.fill$java_awt_Color(this.drawInto.getBackground());
});

Clazz.newMeth(C$, 'clearExterior', function () {
p$.paintFlat$java_awt_Graphics$java_awt_Color.apply(this, [this.drawInto.getGraphics(), this.drawInto.getBackground()]);
});

Clazz.newMeth(C$, 'clear', function () {
this.clearExterior();
this.clearInterior();
});

Clazz.newMeth(C$, 'fill$java_awt_Color', function (color) {
var g = this.drawInto.getGraphics();
if (g != null ) {
var r = this.getInnerBounds();
g.setColor$java_awt_Color(color);
g.fillRect$I$I$I$I(r.x, r.y, r.width, r.height);
this.setFillColor$java_awt_Color(color);
g.dispose();
}});

Clazz.newMeth(C$, 'toString', function () {
return C$.superclazz.prototype.toString.apply(this, []) + "[" + this.paramString() + "]" ;
});

Clazz.newMeth(C$, 'paramString', function () {
return "color=" + this.getLineColor() + ",thickness=" + this.thick + ",fillColor=" + this.getFillColor() ;
});

Clazz.newMeth(C$, 'brighter', function () {
return this.getLineColor().brighter().brighter().brighter().brighter();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:40
