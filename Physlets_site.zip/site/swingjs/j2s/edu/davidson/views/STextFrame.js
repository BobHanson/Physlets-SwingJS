(function(){var P$=Clazz.newPackage("edu.davidson.views"),I$=[['java.awt.BorderLayout','edu.davidson.views.STextArea','java.awt.Color','java.awt.event.WindowAdapter']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "STextFrame", null, 'a2s.Frame');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.borderLayout1 = null;
this.textArea = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.borderLayout1 = Clazz.new_((I$[1]||$incl$(1)));
this.textArea = Clazz.new_((I$[2]||$incl$(2)));
}, 1);

Clazz.newMeth(C$, 'c$$S', function (title) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.setSize$I$I(400, 300);
this.setLocation$I$I(((300 * Math.random())|0), ((300 * Math.random())|0));
if (title == null ) this.setTitle$S(this.getClass().getName());
 else this.setTitle$S(title);
this.textArea.setEditable$Z(false);
this.textArea.setBackground$java_awt_Color((I$[3]||$incl$(3)).white);
}, 1);

Clazz.newMeth(C$, 'getTextArea', function () {
return this.textArea;
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.addWindowListener$java_awt_event_WindowListener(((
(function(){var C$=Clazz.newClass(P$, "STextFrame$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowOpened$java_awt_event_WindowEvent', function (e) {
this.b$['edu.davidson.views.STextFrame'].this_windowOpened$java_awt_event_WindowEvent(e);
});

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (e) {
this.b$['edu.davidson.views.STextFrame'].this_windowClosing$java_awt_event_WindowEvent(e);
});

Clazz.newMeth(C$, 'windowActivated$java_awt_event_WindowEvent', function (e) {
this.b$['edu.davidson.views.STextFrame'].this_windowActivated$java_awt_event_WindowEvent(e);
});

Clazz.newMeth(C$, 'windowDeiconified$java_awt_event_WindowEvent', function (e) {
this.b$['edu.davidson.views.STextFrame'].this_windowDeiconified$java_awt_event_WindowEvent(e);
});
})()
), Clazz.new_((I$[4]||$incl$(4)), [this, null],P$.STextFrame$1)));
this.add$java_awt_Component$O(this.textArea, "Center");
});

Clazz.newMeth(C$, 'this_windowOpened$java_awt_event_WindowEvent', function (e) {
});

Clazz.newMeth(C$, 'this_windowClosing$java_awt_event_WindowEvent', function (e) {
this.setVisible$Z(false);
});

Clazz.newMeth(C$, 'this_windowActivated$java_awt_event_WindowEvent', function (e) {
});

Clazz.newMeth(C$, 'this_windowDeiconified$java_awt_event_WindowEvent', function (e) {
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:14
