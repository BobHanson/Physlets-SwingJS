(function(){var P$=Clazz.newPackage("bfield"),I$=[['edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FieldArrow", null, 'edu.davidson.display.ArrowThing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.hStr = null;
this.vStr = null;
this.tempVars = null;
this.hFunc = null;
this.vFunc = null;
this.fieldPanel = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.tempVars = Clazz.array(Double.TYPE, [4]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$bfield_FieldPanel$I$S$S$D$D', function (owner, fp, s, h, v, x, y) {
C$.superclazz.c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D$D$D.apply(this, [owner, fp, s, 0, 0, x, y]);
C$.$init$.apply(this);
this.fieldPanel = fp;
this.applet = owner;
this.s = s;
this.hStr = h;
this.vStr = v;
this.hFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[4]);
this.hFunc.defineVariable$I$S(1, "x");
this.hFunc.defineVariable$I$S(2, "y");
this.hFunc.defineVariable$I$S(3, "bx");
this.hFunc.defineVariable$I$S(4, "by");
this.hFunc.define$S(this.hStr);
this.hFunc.parse();
if (this.hFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse horzizontal component of vector: " + this.hStr);
System.out.println$S("Parse error: " + this.hFunc.getErrorString() + " at position " + this.hFunc.getErrorPosition() );
return;
}this.vFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[4]);
this.vFunc.defineVariable$I$S(1, "x");
this.vFunc.defineVariable$I$S(2, "y");
this.vFunc.defineVariable$I$S(3, "bx");
this.vFunc.defineVariable$I$S(4, "by");
this.vFunc.define$S(this.vStr);
this.vFunc.parse();
if (this.vFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse vertical component of vector: " + this.vStr);
System.out.println$S("Parse error: " + this.vFunc.getErrorString() + " at position " + this.vFunc.getErrorPosition() );
return;
}}, 1);

Clazz.newMeth(C$, 'getHorz', function () {
var h = 0;
this.tempVars[0] = this.x;
this.tempVars[1] = this.y;
if (Clazz.instanceOf(this.getMaster(), "bfield.Wire")) {
this.tempVars[2] = this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, this.getMaster());
this.tempVars[3] = this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, this.getMaster());
} else {
this.tempVars[2] = this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, null);
this.tempVars[3] = this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, null);
}try {
h = this.hFunc.evaluate$DA(this.tempVars);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return h;
});

Clazz.newMeth(C$, 'getVert', function () {
var val = 0;
this.tempVars[0] = this.x;
this.tempVars[1] = this.y;
if (Clazz.instanceOf(this.getMaster(), "bfield.Wire")) {
this.tempVars[2] = this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, this.getMaster());
this.tempVars[3] = this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, this.getMaster());
} else {
this.tempVars[2] = this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, null);
this.tempVars[3] = this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, null);
}try {
val = this.vFunc.evaluate$DA(this.tempVars);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return val;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:07
