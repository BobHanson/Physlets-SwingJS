(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newClass(P$, "BusyFlag");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.busyflag = null;
this.busycount = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.busyflag = null;
this.busycount = 0;
}, 1);

Clazz.newMeth(C$, 'getBusyFlag', function () {
{
return;
}
});

Clazz.newMeth(C$, 'freeBusyFlag', function () {
{
return;
}
});

Clazz.newMeth(C$, 'getBusyFlagOwner', function () {
return this.busyflag;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:13
