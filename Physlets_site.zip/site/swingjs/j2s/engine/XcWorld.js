(function(){var P$=Clazz.newPackage("engine"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "XcWorld", null, 'engine.World');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.msgString = null;
this.msgXpos = 0;
this.msgYpos = 0;
this.msgColor = null;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.sx = 0;
this.sz = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.sx = 0;
this.sz = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.xmin = 0.0;
this.ymin = 0.0;
this.xmax = 1.0;
this.ymax = 1.0;
this.msgXpos = 10;
this.msgYpos = 10;
this.msgColor = (I$[1]||$incl$(1)).white;
this.msgString =  String.instantialize("                   ");
}, 1);

Clazz.newMeth(C$, 'XcWorldMovePoint$I$D$D', function (i, x1, y1) {
this.points[i - 1].x = x1;
this.points[i - 1].y = y1;
});

Clazz.newMeth(C$, 'XcWorldChangePointColor$I$S', function (i, c) {
c.toLowerCase();
this.points[i - 1].paintMode = 1;
if (c.equals$O("black")) this.points[i - 1].col = (I$[1]||$incl$(1)).black;
 else if (c.equals$O("blue")) this.points[i - 1].col = (I$[1]||$incl$(1)).blue;
 else if (c.equals$O("cyan")) this.points[i - 1].col = (I$[1]||$incl$(1)).cyan;
 else if (c.equals$O("darkgray")) this.points[i - 1].col = (I$[1]||$incl$(1)).darkGray;
 else if (c.equals$O("gray")) this.points[i - 1].col = (I$[1]||$incl$(1)).gray;
 else if (c.equals$O("green")) this.points[i - 1].col = (I$[1]||$incl$(1)).green;
 else if (c.equals$O("lightgray")) this.points[i - 1].col = (I$[1]||$incl$(1)).lightGray;
 else if (c.equals$O("magenta")) this.points[i - 1].col = (I$[1]||$incl$(1)).magenta;
 else if (c.equals$O("orange")) this.points[i - 1].col = (I$[1]||$incl$(1)).orange;
 else if (c.equals$O("pink")) this.points[i - 1].col = (I$[1]||$incl$(1)).pink;
 else if (c.equals$O("red")) this.points[i - 1].col = (I$[1]||$incl$(1)).red;
 else if (c.equals$O("white")) this.points[i - 1].col = (I$[1]||$incl$(1)).white;
 else if (c.equals$O("yellow")) this.points[i - 1].col = (I$[1]||$incl$(1)).yellow;
 else if (c.equals$O("background")) {
this.points[i - 1].paintMode = 0;
} else this.points[i - 1].col = (I$[1]||$incl$(1)).white;
});

Clazz.newMeth(C$, 'XcWorldChangePointMode$I$I', function (i, m) {
this.points[i - 1].mode = m;
});

Clazz.newMeth(C$, 'XcWorldMoveParticle$I$D$D', function (i, x1, y1) {
this.particles[i - 1].x = x1;
this.particles[i - 1].y = y1;
});

Clazz.newMeth(C$, 'XcWorldChangeParticleColor$I$S', function (i, c) {
c.toLowerCase();
if (c.equals$O("black")) this.particles[i - 1].col = (I$[1]||$incl$(1)).black;
 else if (c.equals$O("blue")) this.particles[i - 1].col = (I$[1]||$incl$(1)).blue;
 else if (c.equals$O("cyan")) this.particles[i - 1].col = (I$[1]||$incl$(1)).cyan;
 else if (c.equals$O("darkgray")) this.particles[i - 1].col = (I$[1]||$incl$(1)).darkGray;
 else if (c.equals$O("gray")) this.particles[i - 1].col = (I$[1]||$incl$(1)).gray;
 else if (c.equals$O("green")) this.particles[i - 1].col = (I$[1]||$incl$(1)).green;
 else if (c.equals$O("lightgray")) this.particles[i - 1].col = (I$[1]||$incl$(1)).lightGray;
 else if (c.equals$O("magenta")) this.particles[i - 1].col = (I$[1]||$incl$(1)).magenta;
 else if (c.equals$O("orange")) this.particles[i - 1].col = (I$[1]||$incl$(1)).orange;
 else if (c.equals$O("pink")) this.particles[i - 1].col = (I$[1]||$incl$(1)).pink;
 else if (c.equals$O("red")) this.particles[i - 1].col = (I$[1]||$incl$(1)).red;
 else if (c.equals$O("white")) this.particles[i - 1].col = (I$[1]||$incl$(1)).white;
 else if (c.equals$O("yellow")) this.particles[i - 1].col = (I$[1]||$incl$(1)).yellow;
 else this.particles[i - 1].col = (I$[1]||$incl$(1)).white;
});

Clazz.newMeth(C$, 'XcWorldChangeParticleMode$I$I', function (i, m) {
this.particles[i - 1].mode = m;
});

Clazz.newMeth(C$, 'XcWorldChangeParticleSize$I$I', function (i, size) {
this.particles[i - 1].rx = 0.5 * size;
this.particles[i - 1].ry = 0.5 * size;
});

Clazz.newMeth(C$, 'XcWorldChangeParticleSizes$I$I$I', function (i, sizex, sizey) {
this.particles[i - 1].rx = 0.5 * sizex;
this.particles[i - 1].ry = 0.5 * sizey;
});

Clazz.newMeth(C$, 'XcWorldMoveSegment$I$D$D$D$D', function (i, x11, y11, x22, y22) {
this.segments[i - 1].p1.x = x11;
this.segments[i - 1].p1.y = y11;
this.segments[i - 1].p2.x = x22;
this.segments[i - 1].p2.y = y22;
});

Clazz.newMeth(C$, 'XcWorldChangeSegmentColor$I$S', function (i, c) {
c.toLowerCase();
if (c.equals$O("black")) this.segments[i - 1].col = (I$[1]||$incl$(1)).black;
 else if (c.equals$O("blue")) this.segments[i - 1].col = (I$[1]||$incl$(1)).blue;
 else if (c.equals$O("cyan")) this.segments[i - 1].col = (I$[1]||$incl$(1)).cyan;
 else if (c.equals$O("darkgray")) this.segments[i - 1].col = (I$[1]||$incl$(1)).darkGray;
 else if (c.equals$O("gray")) this.segments[i - 1].col = (I$[1]||$incl$(1)).gray;
 else if (c.equals$O("green")) this.segments[i - 1].col = (I$[1]||$incl$(1)).green;
 else if (c.equals$O("lightgray")) this.segments[i - 1].col = (I$[1]||$incl$(1)).lightGray;
 else if (c.equals$O("magenta")) this.segments[i - 1].col = (I$[1]||$incl$(1)).magenta;
 else if (c.equals$O("orange")) this.segments[i - 1].col = (I$[1]||$incl$(1)).orange;
 else if (c.equals$O("pink")) this.segments[i - 1].col = (I$[1]||$incl$(1)).pink;
 else if (c.equals$O("red")) this.segments[i - 1].col = (I$[1]||$incl$(1)).red;
 else if (c.equals$O("white")) this.segments[i - 1].col = (I$[1]||$incl$(1)).white;
 else if (c.equals$O("yellow")) this.segments[i - 1].col = (I$[1]||$incl$(1)).yellow;
 else this.segments[i - 1].col = (I$[1]||$incl$(1)).white;
});

Clazz.newMeth(C$, 'XcWorldChangeSegmentMode$I$I', function (i, m) {
this.segments[i - 1].mode = m;
});

Clazz.newMeth(C$, 'XcWorldUpdate', function () {
var g = this.getGraphics();
if (this.traceOn) this.draw$java_awt_Graphics(g);
 else {
if (!this.doubleBuffering) {
this.repaint();
} else {
this.startUpdate$java_awt_Graphics(g);
this.draw$java_awt_Graphics(this.offGraphics);
this.finishUpdate$java_awt_Graphics(g);
}}});

Clazz.newMeth(C$, 'startUpdate$java_awt_Graphics', function (g) {
this.d = this.getSize();
if ((this.offGraphics == null ) || (this.d.width != this.offDimension.width) || (this.d.height != this.offDimension.height)  ) {
this.offDimension = this.d;
this.offImage = this.createImage$I$I(this.d.width, this.d.height);
this.offGraphics = this.offImage.getGraphics();
}this.offGraphics.setColor$java_awt_Color(this.getBackground());
this.offGraphics.fillRect$I$I$I$I(0, 0, this.d.width, this.d.height);
this.offGraphics.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
this.offGraphics.draw3DRect$I$I$I$I$Z(0, 0, this.d.width - 1, this.d.height - 1, true);
});

Clazz.newMeth(C$, 'finishUpdate$java_awt_Graphics', function (g) {
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.offImage, 0, 0, this);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.draw$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics', function (g) {
var p;
var p1;
var s;
var w = this.getBounds();
var x0 = 0.0;
var y0 = 0.0;
var xRange;
var yRange;
var particleHeight;
{
xRange = w.width / (this.xmax - this.xmin);
yRange = w.height / (this.ymax - this.ymin);
for (var i = 0; i < this.nOfParticles; i++) {
p1 = this.particles[i];
p1.pa = (p1.x - this.xmin) * xRange;
particleHeight = yRange;
p1.pb = w.height - ((p1.y - this.ymin) * yRange);
p1.showParticle$java_awt_Graphics$D(g, particleHeight);
}
for (var i = 0; i < this.nOfPoints; i++) {
p = this.points[i];
p.pa = (p.x - this.xmin) * xRange;
p.pb = w.height - ((p.y - this.ymin) * yRange);
if ((p.mode == 1) && (i > 0) ) {
if (p.paintMode > 0) {
g.setColor$java_awt_Color(p.col);
g.drawLine$I$I$I$I((x0|0), (y0|0), (p.pa|0), (p.pb|0));
}}p.showPoint$java_awt_Graphics(g);
x0 = p.pa;
y0 = p.pb;
}
for (var i = 0; i < this.nOfSegments; i++) {
s = this.segments[i];
s.p1.pa = (s.p1.x - this.xmin) * xRange;
s.p1.pb = w.height - ((s.p1.y - this.ymin) * yRange);
s.p2.pa = (s.p2.x - this.xmin) * xRange;
s.p2.pb = w.height - ((s.p2.y - this.ymin) * yRange);
s.showSegment$java_awt_Graphics(g);
}
}g.setColor$java_awt_Color(this.msgColor);
g.drawString$S$I$I(this.msgString, this.msgXpos, this.msgYpos);
});

Clazz.newMeth(C$, 'mouseDown$java_awt_Event$I$I', function (event, x1, y1) {
var dx;
var dy;
var xm;
var ym;
var delta = 5.0;
this.elementSelected = 0;
this.posMouse.x = x1;
this.posMouse.y = y1;
xm = this.posMouse.x;
ym = this.posMouse.y;
var i = 1;
while ((this.elementSelected == 0) && (i < this.nOfParticles) ){
dx = Math.abs(this.particles[i - 1].pa - xm);
dy = Math.abs(this.particles[i - 1].pb - ym);
if ((dx < delta ) && (dy < delta ) ) {
this.elementSelected = i;
this.elementType = 1;
}i++;
}
i = 1;
while ((this.elementSelected == 0) && (i < this.nOfSegments) ){
dx = Math.abs(this.segments[i - 1].p1.pa - xm);
dy = Math.abs(this.segments[i - 1].p1.pb - ym);
if ((dx < delta ) && (dy < delta ) ) {
this.elementSelected = i;
this.elementType = 2;
}dx = Math.abs(this.segments[i - 1].p2.pa - xm);
dy = Math.abs(this.segments[i - 1].p2.pb - ym);
if ((dx < delta ) && (dy < delta ) ) {
this.elementSelected = i;
this.elementType = 2;
}i++;
}
i = 1;
while ((this.elementSelected == 0) && (i < this.nOfPoints) ){
dx = Math.abs(this.points[i - 1].pa - xm);
dy = Math.abs(this.points[i - 1].pb - ym);
if ((dx < delta ) && (dy < delta ) ) {
this.elementSelected = i;
this.elementType = 3;
}i++;
}
if (this.elementSelected > 0) {
}return false;
});
})();
//Created 2018-02-25 19:20:10
