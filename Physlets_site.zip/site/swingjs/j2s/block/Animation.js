(function(){var P$=Clazz.newPackage("block"),I$=[[0,'block.Block','block.Control','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Animation", null, 'java.awt.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.area=null;
this.p=null;
this.cnt=0;
this.b=null;
this.bc=null;
this.offset=0;
this.xMax=0;
this.id=0;
this.xs=0;
this.moving=false;
this.cgStatus=false;
this.offDimension=null;
this.offImage=null;
this.g=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$block_MainWindow', function (m) {
Clazz.super_(C$, this,1);
this.cnt=5;
this.b=Clazz.array($I$(1), [this.cnt]);
this.bc=Clazz.array(Double.TYPE, [this.cnt]);
m.add$S$java_awt_Component("North", this.p=Clazz.new_($I$(2).c$$block_Animation,[this]));
this.setBackground$java_awt_Color($I$(3).white);
this.init$();
}, 1);

Clazz.newMeth(C$, 'reset$Z', function (clean) {
this.area=this.size$();
$I$(1).width=120;
this.xMax=0;
for (var i=1; i < this.cnt; ++i) {
this.xMax+=($I$(1).width/i|0);
}
this.xMax=(this.xMax/(2)|0);
$I$(1).height=(this.area.height/(this.cnt + 1)|0);
this.offset=-$I$(1).width / 2.0;
var y0=this.area.height - $I$(1).height;
if (clean) {
this.b[0].init$I$I(0, y0);
for (var i=1; i < this.cnt; ++i) {
y0-=$I$(1).height;
this.b[i].init$I$I(0, y0);
this.bc[i]=this.offset;
}
} else {
for (var i=0; i < this.cnt; ++i, y0-=$I$(1).height) {
this.b[i].changeY$I(y0);
}
}this.repaint$();
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (gs) {
this.update$java_awt_Graphics(gs);
});

Clazz.newMeth(C$, 'mouseUp$java_awt_Event$I$I', function (e, x, y) {
if (this.moving) {
this.repaint$();
}this.moving=false;
return true;
});

Clazz.newMeth(C$, 'writeText$I$I', function (x, y) {
this.p.mouseP.setText$S(String.valueOf$I(x) + " , " + String.valueOf$I(this.b[0].y - y) );
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (gs) {
var y0=this.b[0].y;
if (this.g == null  || this.area.width != this.offDimension.width  || this.area.height != this.offDimension.height ) {
this.offDimension=this.area;
this.offImage=this.createImage$I$I(this.area.width, this.area.height);
this.g=this.offImage.getGraphics$();
$I$(1).g=this.g;
}this.g.setColor$java_awt_Color(this.getBackground$());
this.g.fillRect$I$I$I$I(0, 0, this.area.width, this.area.height);
this.g.setColor$java_awt_Color($I$(3).black);
var dy=($I$(1).height/5|0);
var dx=($I$(1).width/10|0);
this.g.fillRect$I$I$I$I(0, y0, $I$(1).width + 1, dy);
this.g.fillRect$I$I$I$I(dx, y0 + dy, dy, $I$(1).height - dy);
this.g.fillRect$I$I$I$I($I$(1).width - 2 * dx, y0 + dy, dy, $I$(1).height - dy);
this.g.drawString$S$I$I(String.valueOf$I($I$(1).width), $I$(1).width, this.b[0].y + ($I$(1).height/2|0));
var fillColor=$I$(3).green;
for (var i=1; i < this.cnt; ++i) {
if (fillColor === $I$(3).green ) {
var tmp=this.b[i - 1].x - this.bc[i];
if (tmp > 0.0 ) {
fillColor=$I$(3).green;
} else if (tmp == 0.0 ) {
fillColor=$I$(3).yellow;
} else {
fillColor=$I$(3).red;
}}this.b[i].draw$java_awt_Color(fillColor);
}
for (var i=this.cnt - 1; i > 0; --i) {
if (this.cgStatus) {
var xx=(this.bc[i]|0) + $I$(1).width;
var yy=((this.b[this.cnt - 1].y + this.b[i].y + $I$(1).height )/2|0);
this.g.setColor$java_awt_Color($I$(3).black);
this.g.drawOval$I$I$I$I(xx - 2, yy - 2, 4, 4);
yy+=((this.cnt - i) * $I$(1).height/2|0);
this.g.drawLine$I$I$I$I(xx, yy, xx, yy - ((this.cnt - i) * $I$(1).height/2|0));
this.g.drawLine$I$I$I$I(xx, yy, xx - 3, yy - 3);
this.g.drawLine$I$I$I$I(xx, yy, xx + 3, yy - 3);
this.g.drawString$S$I$I(String.valueOf$D(this.bc[i] + $I$(1).width), xx, yy);
}}
var fraction=(this.b[this.cnt - 1].x/this.xMax|0);
if (fraction == 1.0  && fillColor !== $I$(3).red  ) {
this.g.setColor$java_awt_Color($I$(3).red);
var xx=this.b[1].x + $I$(1).width + 30 ;
var yy=this.b[0].y - 10;
this.g.setColor$java_awt_Color($I$(3).black);
this.g.drawOval$I$I$I$I(xx, yy, 2, 2);
xx-=10;
this.g.drawOval$I$I$I$I(xx, yy, 2, 2);
this.g.drawArc$I$I$I$I$I$I(xx, yy, 12, 12, -132, 92);
xx+=20;
yy+=10;
this.g.drawString$S$I$I("You did it!", xx, yy);
}if (fillColor === $I$(3).red ) {
fraction=0.0;
}this.g.drawString$S$I$I(this.d2String$D(fraction * 100.0) + "%", this.b[this.cnt - 1].x + $I$(1).width + 5 , this.b[this.cnt - 1].y);
gs.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.offImage, 0, 0, this);
});

Clazz.newMeth(C$, 'mouseDown$java_awt_Event$I$I', function (e, x, y) {
this.xs=x;
this.id=1;
while (this.id < this.cnt){
if (this.b[this.id].inside$I$I(x, y)) {
return this.moving=true;
}++this.id;
}
this.id=0;
this.repaint$();
return true;
});

Clazz.newMeth(C$, 'init$', function () {
for (var i=0; i < this.cnt; ++i) {
this.b[i]=Clazz.new_($I$(1));
}
});

Clazz.newMeth(C$, 'cgState$Z', function (s) {
this.cgStatus=s;
this.repaint$();
});

Clazz.newMeth(C$, 'mouseDrag$java_awt_Event$I$I', function (e, x, y) {
var dx=x - this.xs;
if (this.moving) {
var i;
for (i=this.id; i < this.cnt; ++i) {
this.b[i].moveX$I(dx);
}
--i;
this.bc[i]=this.b[i].x + this.offset;
for (i=this.cnt - 2; i > 0; --i) {
this.bc[i]=(this.bc[i + 1] * (this.cnt - i - 1 ) + this.b[i].x + this.offset) / (this.cnt - i);
}
this.writeText$I$I(this.xs=x, y);
this.repaint$();
}return true;
});

Clazz.newMeth(C$, 'd2String$D', function (d) {
var d2=(((100.0 * d)|0) / 100.0);
var str=String.valueOf$F(d2);
if (str.indexOf$S(".") == -1) {
str += ".0";
}return str;
});

Clazz.newMeth(C$, 'mouseMove$java_awt_Event$I$I', function (e, x, y) {
this.writeText$I$I(x, y);
return true;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:43 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
