(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[[0,'edu.davidson.display.Format','java.beans.PropertyChangeSupport','java.awt.Dimension','edu.davidson.display.SNumber_this_textAdapter','java.awt.Color','java.awt.SystemColor']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "SNumber", null, 'java.awt.TextField', 'java.beans.PropertyChangeListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.boundSupport=null;
this.value=0;
this.formStr=null;
this.valFormat=null;
this.validData=false;
this.noColor=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.value=0.0;
this.formStr="%-+6.3g";
this.valFormat=Clazz.new_($I$(1).c$$S,["%-+6.3g"]);
this.validData=true;
this.noColor=false;
}, 1);

Clazz.newMeth(C$, 'c$$D', function (d) {
C$.c$$D$S.apply(this, [d, null]);
}, 1);

Clazz.newMeth(C$, 'c$$D$S', function (d, strFormat) {
Clazz.super_(C$, this,1);
if (strFormat != null ) this.setFormat$S(strFormat);
this.boundSupport=Clazz.new_($I$(2).c$$O,[this]);
this.value=0;
this.setText$S(this.valFormat.form$D(this.value));
this.setPreferredSize$java_awt_Dimension(Clazz.new_($I$(3).c$$I$I,[50, 25]));
this.addTextListener$java_awt_event_TextListener(Clazz.new_($I$(4).c$$edu_davidson_display_SNumber,[this]));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$S.apply(this, [0.0, null]);
}, 1);

Clazz.newMeth(C$, 'setFormat$S', function (f) {
if (this.formStr.equals$O(f)) return;
this.formStr=f;
this.valFormat=Clazz.new_($I$(1).c$$S,[f]);
this.setText$S(this.valFormat.form$D(this.value));
});

Clazz.newMeth(C$, 'getFormat$', function () {
return this.formStr;
});

Clazz.newMeth(C$, 'setValue$D', function (d) {
this.validData=true;
if (d == this.value ) {
return;
}var oldVal=this.value;
this.value=d;
this.setText$S(this.valFormat.form$D(this.value));
this.boundSupport.firePropertyChange$S$O$O("DValue",  new Double(oldVal),  new Double(this.value));
if (this.isEditable$()) this.setBackground$java_awt_Color($I$(5).white);
 else this.setBackground$java_awt_Color($I$(6).control);
});

Clazz.newMeth(C$, 'getValue$', function () {
if (this.noColor) return this.value;
if (!this.isEditable$()) this.setBackground$java_awt_Color($I$(6).control);
 else if (!this.validData) this.setBackground$java_awt_Color($I$(5).red);
 else this.setBackground$java_awt_Color($I$(5).white);
return this.value;
});

Clazz.newMeth(C$, 'isValid$', function () {
return this.validData;
});

Clazz.newMeth(C$, 'isNoColor$', function () {
return this.noColor;
});

Clazz.newMeth(C$, 'setNoColor$Z', function (nc) {
this.noColor=nc;
});

Clazz.newMeth(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener', function (l) {
if (this.boundSupport == null ) C$.superclazz.prototype.addPropertyChangeListener$java_beans_PropertyChangeListener.apply(this, [l]);
 else this.boundSupport.addPropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener', function (l) {
this.boundSupport.removePropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, ['propertyChange$java_beans_PropertyChangeEvent','propertyChange$'], function (evt) {
if (!this.isEditable$()) this.setBackground$java_awt_Color($I$(6).control);
 else this.setBackground$java_awt_Color($I$(5).white);
if (evt.getPropertyName$().equals$O("DValue")) {
var val=evt.getNewValue$();
try {
if (val.doubleValue$() == this.value ) {
return;
} else {
var str=this.valFormat.form$D(val.doubleValue$());
this.value=Double.valueOf$S(str).doubleValue$();
this.setText$S(str);
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'this_textValueChanged$java_awt_event_TextEvent', function (evt) {
this.updateValueFromText$();
});

Clazz.newMeth(C$, 'updateValueFromText$', function () {
var oldValue=this.value;
try {
var str=this.getText$().trim$();
if (str == null  || str.equals$O("") ) return;
this.validData=true;
if (str != null  && str != "" ) {
this.value=Double.valueOf$S(str).doubleValue$();
if (!this.noColor) this.setBackground$java_awt_Color($I$(5).yellow);
if (this.value == oldValue ) return;
this.boundSupport.firePropertyChange$S$O$O("DValue",  new Double(oldValue),  new Double(this.value));
} else {
if (!this.noColor) this.setBackground$java_awt_Color($I$(5).red);
this.validData=false;
this.value=oldValue;
}} catch (e) {
if (Clazz.exceptionOf(e,"NumberFormatException")){
if (!this.noColor) this.setBackground$java_awt_Color($I$(5).red);
this.validData=false;
this.value=oldValue;
} else {
throw e;
}
}
});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:03 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
