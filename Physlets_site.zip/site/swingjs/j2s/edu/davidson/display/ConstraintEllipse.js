(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[];
var C$=Clazz.newClass(P$, "ConstraintEllipse", null, 'edu.davidson.display.Constraint');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$D$D', function (owner, sc, l, r, b, t) {
C$.superclazz.c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$D$D.apply(this, [owner, sc, l, r, b, t]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX=this.canvas.pixFromX$D(this.left);
var ptY=this.canvas.pixFromY$D(this.top);
this.w=this.canvas.pixFromX$D(this.right) - ptX;
this.h=this.canvas.pixFromY$D(this.bottom) - ptY;
osg.setColor$java_awt_Color(this.color);
if (this.w > 0 && this.h > 0 ) osg.drawOval$I$I$I$I(ptX, ptY, this.w, this.h);
 else if (this.w > 0 && this.h == 0 ) osg.drawLine$I$I$I$I(ptX, ptY, ptX + this.w, ptY);
 else if (this.w == 0 && this.h > 0 ) osg.drawLine$I$I$I$I(ptX, ptY, ptX, ptY + this.h);
});

Clazz.newMeth(C$, 'enforceConstraint$edu_davidson_display_Thing', function (t) {
var x=t.x;
var y=t.y;
var a=Math.abs(this.right - this.left) / 2.0;
var b=Math.abs(this.top - this.bottom) / 2.0;
if (a > 0  && b > 0  ) {
var theta=Math.atan2(x, y);
var cos=Math.cos(theta);
var sin=Math.sin(theta);
var d=1.0 / Math.sqrt(cos * cos / a / a + sin * sin / b / b);
t.x=d * Math.sin(theta);
t.y=d * Math.cos(theta);
} else if (a == 0  && b > 0  ) {
t.x=this.right;
} else if (b == 0  && a > 0  ) {
t.y=this.top;
} else {
t.x=this.right;
t.y=this.top;
}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:29 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
