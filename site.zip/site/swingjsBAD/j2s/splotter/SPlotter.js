(function(){var P$=Clazz.newPackage("splotter"),I$=[['edu.davidson.graphics.EtchedBorder','a2s.Button','edu.davidson.surfaceplotter.SurfacePanel','java.awt.BorderLayout','a2s.TextField','a2s.Panel','Boolean','splotter.SPlotter$1','splotter.SPlotter$2','splotter.SPlotter$3','java.awt.SystemColor','edu.davidson.tools.SUtil','java.awt.Font']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SPlotter", null, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SStepable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.$firstTime = false;
this.funcStr = null;
this.func2Str = null;
this.scaleStr = null;
this.typeStr = null;
this.gridPts = 0;
this.numLevels = 0;
this.scaleFactor = 0;
this.showControls = false;
this.etchedBorder1 = null;
this.plotBtn = null;
this.surfacePanel = null;
this.borderLayout1 = null;
this.funcField = null;
this.panel1 = null;
this.rotateBtn = null;
this.runBtn = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.$firstTime = true;
this.scaleFactor = 10;
this.etchedBorder1 = Clazz.new_((I$[1]||$incl$(1)));
this.plotBtn = Clazz.new_((I$[2]||$incl$(2)));
this.surfacePanel = Clazz.new_((I$[3]||$incl$(3)).c$$edu_davidson_tools_SApplet,[this]);
this.borderLayout1 = Clazz.new_((I$[4]||$incl$(4)));
this.funcField = Clazz.new_((I$[5]||$incl$(5)));
this.panel1 = Clazz.new_((I$[6]||$incl$(6)));
this.rotateBtn = Clazz.new_((I$[2]||$incl$(2)));
this.runBtn = Clazz.new_((I$[2]||$incl$(2)));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
var dt = 0.1;
var fps = 10;
try {
fps=Double.$valueOf(this.getParameter$S$S("FPS", "10")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
dt=Double.$valueOf(this.getParameter$S$S("dt", "0.1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.funcStr=this.getParameter$S$S("Function", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.func2Str=this.getParameter$S$S("Function2", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.scaleStr=this.getParameter$S$S("Scale", "xmin=-1,xmax=1,ymin=-1,ymax=1,zmin=-1,zmax=1");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.gridPts=Integer.parseInt(this.getParameter$S$S("GridPts", "32"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.numLevels=Integer.parseInt(this.getParameter$S$S("Levels", "10"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.scaleFactor=Integer.parseInt(this.getParameter$S$S("ScaleFactor", "10"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.typeStr=this.getParameter$S$S("Type", "threed");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls=(I$[7]||$incl$(7)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.clock.setDt$D(dt);
this.clock.setFPS$D((fps|0));
this.etchedBorder1.setVisible$Z(this.showControls);
this.setGridPoints$I(this.gridPts);
this.setNumLevels$I(this.numLevels);
this.set$I$S$S(0, "style", "scalefactor=" + this.scaleFactor);
this.surfacePanel.surfaceCanvas.setNoDrawing$Z(true);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
{
this.resize$I$I(350, 400);
}this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.plotBtn.setLabel$S("Plot");
this.plotBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "SPlotter$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['splotter.SPlotter'].plotBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[8]||$incl$(8)).$init$, [this, null])));
this.funcField.setText$S("x*y");
this.rotateBtn.setName$S("rotateBtn");
this.rotateBtn.setLabel$S("Rotate");
this.rotateBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "SPlotter$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['splotter.SPlotter'].rotateBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[9]||$incl$(9)).$init$, [this, null])));
this.runBtn.setName$S("runBtn");
this.runBtn.setLabel$S("Run");
this.runBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "SPlotter$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['splotter.SPlotter'].runBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[10]||$incl$(10)).$init$, [this, null])));
this.etchedBorder1.setBackground$java_awt_Color((I$[11]||$incl$(11)).inactiveCaptionText);
this.add$java_awt_Component$O(this.etchedBorder1, "South");
this.etchedBorder1.add$java_awt_Component$O(this.plotBtn, "West");
this.etchedBorder1.add$java_awt_Component$O(this.funcField, "Center");
this.etchedBorder1.add$java_awt_Component$O(this.panel1, "East");
this.panel1.add$java_awt_Component$O(this.runBtn, null);
this.panel1.add$java_awt_Component$O(this.rotateBtn, null);
this.panel1.setBackground$java_awt_Color((I$[11]||$incl$(11)).inactiveCaptionBorder);
this.add$java_awt_Component$O(this.surfacePanel, "Center");
});

Clazz.newMeth(C$, 'start', function () {
C$.superclazz.prototype.start.apply(this, []);
if (this.$firstTime) {
this.$firstTime=false;
this.set$I$S$S(0, "type", this.typeStr);
this.set$I$S$S(0, "scale", this.scaleStr);
this.setFunction1$S(this.funcStr);
this.setFunction2$S(this.func2Str);
}});

Clazz.newMeth(C$, 'stop', function () {
C$.superclazz.prototype.stop.apply(this, []);
});

Clazz.newMeth(C$, 'destroy', function () {
this.surfacePanel.destroyThread();
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Applet Information";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Function", "String", "Analytic Function, f(x,y)"]), Clazz.array(java.lang.String, -1, ["GridPts", "int", "Grid points along axis"]), Clazz.array(java.lang.String, -1, ["Levels", "int", "Number of contour levels."]), Clazz.array(java.lang.String, -1, ["Mode", "String", "Contour or 3D"]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show user interface"])]);
return pinfo;
});

Clazz.newMeth(C$, ['setFunction$S','setFunction'], function (funcStr) {
this.setFunction1$S(funcStr);
});

Clazz.newMeth(C$, ['setFunction1$S','setFunction1'], function (funcStr) {
this.funcField.setText$S(funcStr);
this.clock.stopClock();
this.surfacePanel.setFunction1$S(funcStr);
});

Clazz.newMeth(C$, ['setFunction2$S','setFunction2'], function (funcStr) {
this.clock.stopClock();
this.surfacePanel.setFunction2$S(funcStr);
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (ar) {
this.autoRefresh=ar;
this.surfacePanel.setAutoRefresh$Z(ar);
});

Clazz.newMeth(C$, ['set$I$S$S','set'], function (id, name, parList) {
name=name.toLowerCase().trim();
name=(I$[12]||$incl$(12)).removeWhitespace$S(name);
var parList2 = parList.trim();
;parList=(I$[12]||$incl$(12)).removeWhitespace$S(parList);
var str = "false";
var xmin = this.surfacePanel.getMinX();
var xmax = this.surfacePanel.getMaxX();
var ymin = this.surfacePanel.getMinY();
var ymax = this.surfacePanel.getMaxY();
var zmin = this.surfacePanel.getMinZ();
var zmax = this.surfacePanel.getMaxZ();
if (name.equals$O("scale")) {
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "xmin=")) xmin=(I$[12]||$incl$(12)).getParam$S$S(parList, "xmin=");
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "xmax=")) xmax=(I$[12]||$incl$(12)).getParam$S$S(parList, "xmax=");
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "ymin=")) ymin=(I$[12]||$incl$(12)).getParam$S$S(parList, "ymin=");
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "ymax=")) ymax=(I$[12]||$incl$(12)).getParam$S$S(parList, "ymax=");
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "zmin=")) zmin=(I$[12]||$incl$(12)).getParam$S$S(parList, "zmin=");
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "zmax=")) zmax=(I$[12]||$incl$(12)).getParam$S$S(parList, "zmax=");
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "autoscalez=")) {
str=(I$[12]||$incl$(12)).getParamStr$S$S(parList, "autoscalez=");
str=(I$[12]||$incl$(12)).removeWhitespace$S(str.toLowerCase());
if (str.equals$O("false")) this.surfacePanel.setAutoscaleZ$Z(false);
 else this.surfacePanel.setAutoscaleZ$Z(true);
}this.surfacePanel.setMinX$D(xmin);
this.surfacePanel.setMaxX$D(xmax);
this.surfacePanel.setMinY$D(ymin);
this.surfacePanel.setMaxY$D(ymax);
this.surfacePanel.setMinZ$D(zmin);
this.surfacePanel.setMaxZ$D(zmax);
} else if (name.equals$O("font")) {
var family = "Helvetica";
var style = 0;
var size = 10;
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "family=")) family=(I$[12]||$incl$(12)).getParamStr$S$S(parList, "family=");
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "style=")) style=((I$[12]||$incl$(12)).getParam$S$S(parList, "style=")|0);
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "size=")) size=((I$[12]||$incl$(12)).getParam$S$S(parList, "size=")|0);
var font = Clazz.new_((I$[13]||$incl$(13)).c$$S$I$I,[family, style, size]);
this.surfacePanel.setGraphFont$java_awt_Font(font);
} else if (name.equals$O("mode")) {
var mode = this.surfacePanel.getMode();
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "mesh") || (I$[12]||$incl$(12)).parameterExist$S$S(parList, "wireframe") ) mode=0;
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "hidden")) mode=1;
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "spectrum")) mode=2;
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "grayscale")) mode=3;
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "dualshade")) mode=4;
this.surfacePanel.setMode$I(mode);
} else if (name.equals$O("type")) {
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "contour")) this.surfacePanel.setContour();
 else if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "density")) this.surfacePanel.setDensity();
 else if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "threed")) this.surfacePanel.setThreeD();
 else if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "none")) this.surfacePanel.setNoDrawing();
} else if (name.equals$O("view")) {
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "scalefactor=")) {
var scalefactor = 10;
scalefactor=((I$[12]||$incl$(12)).getParam$S$S(parList, "scalefactor=")|0);
scalefactor=Math.max(scalefactor, 1);
this.surfacePanel.setScaleFactor$I(scalefactor);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "distance=")) {
var distance = 200;
distance=((I$[12]||$incl$(12)).getParam$S$S(parList, "distance=")|0);
distance=Math.max(distance, 50);
this.surfacePanel.setDistance$I(distance);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "rotationangle=")) {
var a = 45;
a=((I$[12]||$incl$(12)).getParam$S$S(parList, "rotationangle=")|0);
this.surfacePanel.setRotationAngle$D(a);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "elevationangle=")) {
var a = 10;
a=((I$[12]||$incl$(12)).getParam$S$S(parList, "elevationangle=")|0);
this.surfacePanel.setElevationAngle$D(a);
}} else if (name.equals$O("style")) {
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "box")) this.surfacePanel.setShowBox$Z(true);
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "mesh")) this.surfacePanel.setShowMesh$Z(true);
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "facegrid")) this.surfacePanel.setShowFaceGrids$Z(true);
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "scaledbox")) this.surfacePanel.setScaledBox$Z(true);
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "xyticks")) this.surfacePanel.setShowXYticks$Z(true);
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "zticks")) this.surfacePanel.setShowZticks$Z(true);
if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "gutter=")) {
var gutter = 0;
gutter=((I$[12]||$incl$(12)).getParam$S$S(parList, "gutter=")|0);
gutter=Math.max(gutter, 0);
gutter=Math.min(gutter, 200);
this.surfacePanel.setGutter$I(gutter);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "numlevels=")) {
var numlevels = 10;
numlevels=((I$[12]||$incl$(12)).getParam$S$S(parList, "numlevels=")|0);
numlevels=Math.max(numlevels, 1);
numlevels=Math.min(numlevels, 100);
this.surfacePanel.setNumLevels$I(numlevels);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "scaledbox=")) {
str=(I$[12]||$incl$(12)).getParamStr$S$S(parList, "scaledbox=");
str=(I$[12]||$incl$(12)).removeWhitespace$S(str.toLowerCase());
if (str.equals$O("false")) this.surfacePanel.setScaledBox$Z(false);
 else this.surfacePanel.setScaledBox$Z(true);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "box=")) {
str=(I$[12]||$incl$(12)).getParamStr$S$S(parList, "box=");
str=(I$[12]||$incl$(12)).removeWhitespace$S(str.toLowerCase());
if (str.equals$O("false")) this.surfacePanel.setShowBox$Z(false);
 else this.surfacePanel.setShowBox$Z(true);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "mesh=")) {
str=(I$[12]||$incl$(12)).getParamStr$S$S(parList, "mesh=");
str=(I$[12]||$incl$(12)).removeWhitespace$S(str.toLowerCase());
if (str.equals$O("false")) this.surfacePanel.setShowMesh$Z(false);
 else this.surfacePanel.setShowMesh$Z(true);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "facegrid=")) {
str=(I$[12]||$incl$(12)).getParamStr$S$S(parList, "facegrid=");
str=(I$[12]||$incl$(12)).removeWhitespace$S(str.toLowerCase());
if (str.equals$O("false")) this.surfacePanel.setShowFaceGrids$Z(false);
 else this.surfacePanel.setShowFaceGrids$Z(true);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "xyticks=")) {
str=(I$[12]||$incl$(12)).getParamStr$S$S(parList, "xyticks=");
str=(I$[12]||$incl$(12)).removeWhitespace$S(str.toLowerCase());
if (str.equals$O("false")) this.surfacePanel.setShowXYticks$Z(false);
 else this.surfacePanel.setShowXYticks$Z(true);
}if ((I$[12]||$incl$(12)).parameterExist$S$S(parList, "zticks=")) {
str=(I$[12]||$incl$(12)).getParamStr$S$S(parList, "zticks=");
str=(I$[12]||$incl$(12)).removeWhitespace$S(str.toLowerCase());
if (str.equals$O("false")) this.surfacePanel.setShowZticks$Z(false);
 else this.surfacePanel.setShowZticks$Z(true);
}} else {
System.out.println$S("Set property not found: " + name + "parameter list: " + parList );
return false;
}this.setAutoRefresh$Z(this.autoRefresh);
return true;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.deleteDataConnections();
this.surfacePanel.setDefault();
});

Clazz.newMeth(C$, ['setGridPoints$I','setGridPoints'], function (pts) {
this.surfacePanel.setGridPts$I(pts);
});

Clazz.newMeth(C$, ['setNumLevels$I','setNumLevels'], function (num) {
this.surfacePanel.setNumLevels$I(num);
});

Clazz.newMeth(C$, 'getRotationAngle', function () {
return this.surfacePanel.getRotationAngle();
});

Clazz.newMeth(C$, ['setRotationAngle$D','setRotationAngle'], function (angle) {
this.surfacePanel.setRotationAngle$D(angle);
});

Clazz.newMeth(C$, 'getElevationAngle', function () {
return this.surfacePanel.getElevationAngle();
});

Clazz.newMeth(C$, ['setElevationAngle$D','setElevationAngle'], function (angle) {
this.surfacePanel.setElevationAngle$D(angle);
});

Clazz.newMeth(C$, 'getPlotID', function () {
return this.surfacePanel.hashCode();
});

Clazz.newMeth(C$, 'rotateBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.rotateBtn.getLabel().equals$O("Rotate")) {
this.rotateBtn.setLabel$S("Static");
this.surfacePanel.startRotate();
} else {
this.rotateBtn.setLabel$S("Rotate");
this.surfacePanel.stopRotate();
}});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, t) {
this.surfacePanel.setTime$D(t);
});

Clazz.newMeth(C$, 'runBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.runBtn.getLabel().equals$O("Run")) {
this.runBtn.setLabel$S("Stop");
this.clock.startClock();
} else {
this.runBtn.setLabel$S("Run");
this.clock.stopClock();
this.rotateBtn.setLabel$S("Rotate");
this.surfacePanel.stopRotate();
}this.surfacePanel.surfaceCanvas.startPlot();
});

Clazz.newMeth(C$, 'plotBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.clock.stopClock();
this.clock.setTime$D(0);
this.surfacePanel.setFunction1$S(this.funcField.getText());
this.surfacePanel.resetTime();
if (this.rotateBtn.getLabel().equals$O("Static")) {
this.surfacePanel.startRotate();
}if (this.runBtn.getLabel().equals$O("Stop")) {
this.clock.startClock();
}this.surfacePanel.surfaceCanvas.startPlot();
});
})();
//Created 2018-07-23 12:59:44 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
