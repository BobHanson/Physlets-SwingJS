(function(){var P$=Clazz.newPackage("dynamics"),I$=[[0,'java.awt.Panel','a2s.Button','javax.swing.Timer','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "EqualArea", null, 'a2s.Applet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.area=null;
this.bs=null;
this.rts=null;
this.STR=null;
this.bgColor=null;
this.bgImage=null;
this.gb=null;
this.size=0;
this.size2=0;
this.$x=0;
this.deltaX=0;
this.deltaT=0;
this.xmax=0;
this.id=0;
this.imax=0;
this.X=null;
this.Y=null;
this.ys=0;
this.X2=null;
this.c=null;
this.fill=false;
this.$height=0;
this.$width=0;
this.ydrop=0;
this.yOffset=0;
this.startTime=0;
this.lastTime=0;
this.delay=0;
this.delta=0;
this.running=false;
this.vi=0;
this.dropId=0;
this.yfill=0;
this.xfill=0;
this.timer=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
for (var i=0; i < this.STR.length; ++i) {
if ((this.rts=this.getParameter$S(this.STR[i])) != null ) {
this.STR[i]= String.instantialize(this.rts);
}}
this.setBackground$java_awt_Color(this.bgColor);
var panel=Clazz.new_($I$(1));
panel.add$java_awt_Component(this.bs=Clazz.new_($I$(2).c$$S,[this.STR[1]]));
this.add$S$java_awt_Component("North", panel);
this.reset$();
});

Clazz.newMeth(C$, ['reset$','reset'], function () {
this.area=this.size$();
var area=this.area;
area.height-=this.yOffset;
this.X[0]=(this.X[1]=50);
this.X2[0]=this.X[0];
this.$width=((this.vi * this.deltaT)|0);
for (var i=1; i < this.imax; ++i) {
this.X2[i]=this.X2[i - 1] + this.$width;
}
var n=this.X[0];
this.deltaX=n;
this.$x=n;
var y=this.Y;
var n2=1;
var y2=this.Y;
var n3=2;
var ys=(this.area.height/6|0);
y[1]=(y2[2]=ys);
this.ys=ys;
this.$height=this.Y[0] - this.Y[1];
this.Y[0]=this.Y[1] + (this.area.height/4|0);
this.id=0;
this.clear$();
this.drawBall$I$I$Z$Z((this.$x|0), this.ys, false, false);
this.drawBox$();
this.fill=true;
this.ydrop=-1;
this.repaint$();
});

Clazz.newMeth(C$, ['action$java_awt_Event$O','action'], function (event, o) {
var s=o;
if (Clazz.instanceOf(event.target, "a2s.Button")) {
if (s.equals$O(this.STR[1])) {
this.bs.setLabel$S(this.STR[0]);
}this.reset$();
this.timer.start$();
this.running=true;
}return true;
});

Clazz.newMeth(C$, ['start$','start'], function () {
this.delta=100;
if (this.timer == null ) this.timer=Clazz.new_($I$(3).c$$I$java_awt_event_ActionListener,[((this.delta|0)/2|0), ((P$.EqualArea$1||
(function(){var C$=Clazz.newClass(P$, "EqualArea$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (ae) {
this.b$['dynamics.EqualArea'].run$.apply(this.b$['dynamics.EqualArea'], []);
});
})()
), Clazz.new_(P$.EqualArea$1.$init$, [this, null]))]);
this.timer.setRepeats$Z(true);
});

Clazz.newMeth(C$, ['stop$','stop'], function () {
this.timer.stop$();
this.running=false;
});

Clazz.newMeth(C$, ['run$','run'], function () {
if (this.running) {
this.advanced$D(this.delta / 2000.0);
}});

Clazz.newMeth(C$, 'advanced$D', function (n) {
this.$x += this.vi * n;
if (this.fill) {
if (this.$x > this.X2[this.imax - 1] ) {
this.drawBall$I$I$Z$Z((this.$x|0), this.ys, true, false);
if (this.$x > this.area.width ) {
this.fill=false;
this.running=false;
}} else if (this.$x > this.deltaX ) {
this.$x=this.deltaX;
++this.id;
this.deltaX=this.X2[this.id];
}this.drawBall$I$I$Z$Z((this.$x|0), this.ys, true, true);
this.repaint$();
} else if (this.ydrop > -1) {
this.dropit$I$I(this.dropId, this.ydrop++);
if (this.ydrop > this.$height) {
this.ydrop=-1;
this.gb.setColor$java_awt_Color($I$(4).white);
this.gb.drawLine$I$I$I$I(this.X2[0], this.Y[0] + 1, this.X2[this.dropId], this.Y[0] + 1);
this.gb.drawLine$I$I$I$I(this.X2[this.dropId], this.Y[0] + 1, this.X2[this.dropId], this.Y[0] + (this.$height/2|0) + 1);
}this.repaint$();
}});

Clazz.newMeth(C$, 'drawBall$I$I$Z$Z', function (n, n2, b, b2) {
this.X[2]=n;
if (b) {
this.gb.setColor$java_awt_Color(this.bgColor);
this.gb.fillOval$I$I$I$I(this.X[1] - this.size, this.Y[1] - this.size2, this.size2, this.size2);
}this.gb.setColor$java_awt_Color($I$(4).black);
this.gb.fillOval$I$I$I$I(this.X[2] - this.size, this.Y[2] - this.size2, this.size2, this.size2);
if (b2) {
this.gb.setColor$java_awt_Color(this.c[this.id]);
this.gb.fillPolygon$IA$IA$I(this.X, this.Y, 3);
}this.X[1]=n;
});

Clazz.newMeth(C$, 'getID$I$I', function (n, n2) {
var n3=((this.Y[0] - n2)/(n - this.X2[0])|0);
for (var i=1; i < this.imax; ++i) {
if (n3 > (this.$height/(this.X2[i] - this.X2[0])|0) ) {
return i - 1;
}}
return -1;
});

Clazz.newMeth(C$, ['mouseDown$java_awt_Event$I$I','mouseDown'], function (event, n, n2) {
n2-=this.yOffset;
if (!this.fill && this.ydrop == -1 ) {
var id=this.getID$I$I(n, n2);
if (id == -1) {
return true;
}this.dropId=id;
this.gb.setColor$java_awt_Color(this.c[this.dropId + 1]);
this.gb.drawLine$I$I$I$I(this.X2[0], this.Y[0] + 1, this.X2[this.dropId], this.Y[0] + 1);
this.gb.drawLine$I$I$I$I(this.X2[this.dropId], this.Y[0] + 1, this.X2[this.dropId], this.Y[0] + this.$height);
this.yfill=this.Y[0] + this.$height + 1 ;
this.xfill=-1;
this.ydrop=0;
this.running=true;
}return true;
});

Clazz.newMeth(C$, 'clear$', function () {
if (this.gb == null ) {
this.bgImage=this.createImage$I$I(this.area.width, this.area.height);
this.gb=this.bgImage.getGraphics$();
}this.gb.setColor$java_awt_Color(this.bgColor);
this.gb.fillRect$I$I$I$I(0, 0, this.area.width, this.area.height);
});

Clazz.newMeth(C$, 'drawBox$', function () {
var n=this.Y[0] - this.Y[1];
var n2=this.Y[0] + 1;
var n3=this.X2[0] - 1;
this.gb.setColor$java_awt_Color($I$(4).black);
for (var i=0; i < this.imax - 1; ++i) {
this.gb.drawLine$I$I$I$I(n3, n2, n3, n2 + n);
this.gb.drawLine$I$I$I$I(n3, n2 + n, n3 + this.$width, n2 + n);
n3+=this.$width;
}
this.gb.drawLine$I$I$I$I(n3, n2, n3, n2 + n);
});

Clazz.newMeth(C$, 'dropit$I$I', function (n, n2) {
var xfill=(((this.X2[n + 1] - this.X2[n]) * (1.0 - (n2/this.$height|0)))|0);
this.gb.setColor$java_awt_Color(this.bgColor);
this.gb.drawLine$I$I$I$I(this.X2[n] - ((this.X2[n] - this.X2[0]) * n2/this.$height|0), this.Y[1] + n2, this.X2[n + 1] - ((this.X2[n + 1] - this.X2[0]) * n2/this.$height|0), this.Y[1] + n2);
this.gb.setColor$java_awt_Color(this.c[n + 1]);
this.xfill+=xfill;
if (this.xfill > this.$width - 2) {
--this.yfill;
this.xfill-=this.$width;
xfill=this.xfill;
this.gb.drawLine$I$I$I$I(this.X2[n], this.yfill, this.X2[n] + this.$width - 2, this.yfill);
}this.gb.drawLine$I$I$I$I(this.X2[n] + this.xfill, this.yfill, this.X2[n] + this.xfill - xfill, this.yfill);
});

Clazz.newMeth(C$, 'paintComponent_$java_awt_Graphics', function (g) {
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.bgImage, 0, this.yOffset, this);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.STR=Clazz.array(String, -1, ["Reset", "Start"]);
this.bgColor=Clazz.new_($I$(4).c$$I$I$I,[200, 223, 208]);
this.size=2;
this.size2=2 * this.size;
this.deltaT=1.0;
this.xmax=600;
this.imax=6;
this.X=Clazz.array(Integer.TYPE, [3]);
this.Y=Clazz.array(Integer.TYPE, [3]);
this.X2=Clazz.array(Integer.TYPE, [this.imax]);
this.c=Clazz.array($I$(4), -1, [$I$(4).black, $I$(4).red, $I$(4).orange, $I$(4).yellow, $I$(4).green, $I$(4).blue, $I$(4).pink]);
this.yOffset=40;
this.startTime=0;
this.delay=100;
this.running=false;
this.vi=100.0;
}, 1);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:44 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
