(function(){var P$=Clazz.newPackage("diatomic"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EnsemblePanel", null, 'java.awt.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.iwidth = 0;
this.iheight = 0;
this.radiusD = 0;
this.separationD = 0;
this.d = 0;
this.mD = 0;
this.mM = 0;
this.IM = 0;
this.mnMax = 0;
this.anMax = 0;
this.mn = 0;
this.an = 0;
this.mnC = 0;
this.anC = 0;
this.mnC_Ncb = 0;
this.mnC_cb = 0;
this.mn_cb = 0;
this.mwc = 0;
this.tcount = 0;
this.tEnerAv = 0;
this.wc = 0;
this.wc0 = 0;
this.wc1 = 0;
this.wc2 = 0;
this.wcn = 0;
this.cb = 0;
this.cb0 = 0;
this.cbn = 0;
this.MDcol = 0;
this.KinEnDiat = 0;
this.KinEnDiatTrans = 0;
this.KinEnDiatRot = 0;
this.keRot_keTrans = 0;
this.KinEnMonoat = 0;
this.KinEnTotalMD = 0;
this.momChange = 0;
this.momChangeM = 0;
this.momChangeD = 0;
this.tempM = 0;
this.tempD = 0;
this.tMav = 0;
this.tDav = 0;
this.theTime = 0;
this.dt = 0;
this.molColor = null;
this.$x = null;
this.$y = null;
this.vx = null;
this.vy = null;
this.xcm = null;
this.ycm = null;
this.vxcm = null;
this.vycm = null;
this.teta = null;
this.w = null;
this.xcm0 = null;
this.ycm0 = null;
this.vxcm0 = null;
this.vycm0 = null;
this.w0 = null;
this.teta0 = null;
this.vDinit = 0;
this.wDinit = 0;
this.tetaDinit = 0;
this.atomFixed = null;
this.atomColor = null;
this.ax = null;
this.ay = null;
this.avx = null;
this.avy = null;
this.ax0 = null;
this.ay0 = null;
this.avx0 = null;
this.avy0 = null;
this.radiusM = 0;
this.vMinit = 0;
this.dotProduct = 0;
this.energyCalls = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.iwidth = 0;
this.iheight = 0;
this.radiusD = 10;
this.separationD = 1.2;
this.d = this.radiusD * this.separationD;
this.mD = 2.0;
this.mM = 1.0;
this.IM = this.mD * this.d * this.d ;
this.mnMax = 0;
this.anMax = 0;
this.mn = 1;
this.an = 1;
this.mnC = 1;
this.anC = 1;
this.mnC_Ncb = 1;
this.mnC_cb = 1;
this.mn_cb = 1;
this.wc = 0;
this.wc0 = 0;
this.MDcol = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'InitSemiRandDValues', function () {
var rd;
var interx;
var intery;
var nxy;
var remx;
var remy;
this.theTime = 0;
this.tcount = 0;
this.tEnerAv = 0;
this.keRot_keTrans = 0;
nxy = ((Math.sqrt(this.mnMax * 1.0) + 1)|0);
this.mn = 1;
interx = this.iwidth / (nxy + 1.0);
intery = this.iheight / (nxy + 1.0);
remy = 0;
while (this.mn < this.mnMax + 1){
remx = ((this.mn - 1) % nxy);
if (remx == 0) {
remy = remy + 1;
}this.xcm[this.mn] = (remx + 1) * interx;
this.ycm[this.mn] = (remy) * intery;
rd = (Math.random() - 0.5) * 2.0;
this.vxcm[this.mn] = rd * this.vDinit;
rd = (Math.random() - 0.5) * 2.0;
this.vycm[this.mn] = rd * this.vDinit;
rd = (Math.random() - 0.5) * 2.0;
this.w[this.mn] = rd * this.wDinit;
rd = (Math.random() - 0.5) * 2.0;
this.teta[this.mn] = rd * this.tetaDinit;
this.BallDValues$I(this.mn);
this.mn = this.mn + 1;
}
this.mn = 1;
this.energyCalls = 0;
});

Clazz.newMeth(C$, 'InitSemiRandMValues', function () {
var rd;
var interx;
var intery;
var nxy;
var remx;
var remy;
this.theTime = 0;
this.tcount = 0;
this.tEnerAv = 0;
this.keRot_keTrans = 0;
nxy = ((Math.sqrt(this.anMax * 1.0) + 1)|0);
this.an = 1;
interx = this.iwidth / (nxy + 1.0);
intery = this.iheight / (nxy + 1.0);
remy = 0;
while (this.an < this.anMax + 1){
remx = ((this.an - 1) % nxy);
if (remx == 0) {
remy = remy + 1;
}this.ax[this.an] = (remx + 1) * interx + 10.0;
this.ay[this.an] = (remy) * intery + 10.0;
rd = (Math.random() - 0.5) * 2.0;
this.avx[this.an] = rd * this.vMinit;
rd = (Math.random() - 0.5) * 2.0;
this.avy[this.an] = rd * this.vMinit;
if (this.atomFixed[this.an]) {
this.avx[this.an] = 0.0;
this.avy[this.an] = 0.0;
}this.an = this.an + 1;
}
this.an = 1;
this.energyCalls = 0;
});

Clazz.newMeth(C$, 'setAtomNum$I', function (num) {
if (num > 99) {
num = 99;
System.out.println$S("Number of atoms cannot be greater than 99");
}this.mn = 1;
this.an = 1;
this.anMax = num;
this.InitSemiRandMValues();
this.InitSemiRandDValues();
this.mn = 1;
this.an = 1;
this.KinEnTotal();
});

Clazz.newMeth(C$, 'setAtomRad$I', function (r) {
this.radiusM = Math.max(1, r);
var anAux;
anAux = this.an;
this.an = 1;
this.theTime = 0;
this.tcount = 0;
this.tEnerAv = 0;
this.keRot_keTrans = 0;
this.energyCalls = 0;
this.an = anAux;
this.KinEnTotal();
});

Clazz.newMeth(C$, 'setAtomFixed$I$Z', function (i, fix) {
if (i >= this.atomFixed.length || this.atomFixed[i] == fix  ) return;
this.atomFixed[i] = fix;
if (this.atomFixed[i]) {
this.avx[i] = 0.0;
this.avy[i] = 0.0;
}this.KinEnTotal();
});

Clazz.newMeth(C$, 'setMolNum$I', function (num) {
if (num > 99) {
num = 99;
System.out.println$S("Number of diatomics cannot be greater than 99");
}this.mn = 1;
this.an = 1;
this.mnMax = num;
this.InitSemiRandMValues();
this.InitSemiRandDValues();
this.mn = 1;
this.an = 1;
this.KinEnTotal();
});

Clazz.newMeth(C$, 'setMolRad$I', function (r) {
this.radiusD = Math.max(1, r);
var mnAux = this.mn;
this.mn = 1;
this.d = this.radiusD * this.separationD;
this.IM = this.mD * this.d * this.d ;
this.theTime = 0;
this.tcount = 0;
this.tEnerAv = 0;
this.keRot_keTrans = 0;
this.energyCalls = 0;
while (this.mn < this.mnMax + 1){
this.BallDValues$I(this.mn);
this.mn = this.mn + 1;
}
this.mn = mnAux;
this.KinEnTotal();
});

Clazz.newMeth(C$, 'setMolSeparation$D', function (sep) {
var mnAux = this.mn;
this.separationD = Math.max(sep, 0.001);
this.mn = 1;
this.d = this.radiusD * this.separationD;
this.IM = this.mD * this.d * this.d ;
this.theTime = 0;
this.tcount = 0;
this.tEnerAv = 0;
this.keRot_keTrans = 0;
this.energyCalls = 0;
while (this.mn < this.mnMax + 1){
this.BallDValues$I(this.mn);
this.mn = this.mn + 1;
}
this.mn = mnAux;
this.KinEnTotal();
});

Clazz.newMeth(C$, 'initialize', function () {
this.theTime = 0;
this.dt = 0.1;
this.$x = Clazz.array(Double.TYPE, [220, 3]);
this.$y = Clazz.array(Double.TYPE, [220, 3]);
this.vx = Clazz.array(Double.TYPE, [220, 3]);
this.vy = Clazz.array(Double.TYPE, [220, 3]);
this.xcm = Clazz.array(Double.TYPE, [110]);
this.ycm = Clazz.array(Double.TYPE, [110]);
this.vxcm = Clazz.array(Double.TYPE, [110]);
this.vycm = Clazz.array(Double.TYPE, [110]);
this.teta = Clazz.array(Double.TYPE, [110]);
this.w = Clazz.array(Double.TYPE, [110]);
this.xcm0 = Clazz.array(Double.TYPE, [110]);
this.ycm0 = Clazz.array(Double.TYPE, [110]);
this.vxcm0 = Clazz.array(Double.TYPE, [110]);
this.vycm0 = Clazz.array(Double.TYPE, [110]);
this.w0 = Clazz.array(Double.TYPE, [110]);
this.teta0 = Clazz.array(Double.TYPE, [110]);
this.molColor = Clazz.array((I$[1]||$incl$(1)), [110]);
this.radiusD = 10;
this.atomFixed = Clazz.array(Boolean.TYPE, [100]);
this.atomColor = Clazz.array((I$[1]||$incl$(1)), [100]);
this.ax = Clazz.array(Double.TYPE, [100]);
this.ay = Clazz.array(Double.TYPE, [100]);
this.avx = Clazz.array(Double.TYPE, [100]);
this.avy = Clazz.array(Double.TYPE, [100]);
this.ax0 = Clazz.array(Double.TYPE, [100]);
this.ay0 = Clazz.array(Double.TYPE, [100]);
this.avx0 = Clazz.array(Double.TYPE, [100]);
this.avy0 = Clazz.array(Double.TYPE, [100]);
this.radiusM = 10;
this.mD = 2.0;
this.mM = 1.0;
this.d = this.radiusD * this.separationD;
this.IM = this.mD * this.d * this.d ;
this.tcount = 0;
this.tEnerAv = 0;
this.wc1 = 0;
this.wc = 0;
this.wcn = 0;
this.MDcol = 1;
this.setDefault();
});

Clazz.newMeth(C$, 'setDefault', function () {
this.theTime = 0.0;
this.tcount = 0;
this.energyCalls = 0;
this.mn = 1;
this.an = 1;
this.dt = 0.1;
this.mD = 2.0;
this.mM = 1.0;
this.radiusD = 8;
this.radiusM = 8;
var scale = 5;
this.vMinit = 250.0 / scale;
this.vDinit = 250.0 / scale;
this.wDinit = 50.0 / scale;
this.tetaDinit = 7.0;
this.d = this.radiusD * this.separationD;
this.IM = this.mD * this.d * this.d ;
for (var ii = 0; ii < this.atomFixed.length; ii++) this.atomFixed[ii] = false;

for (var ii = 0; ii < this.atomColor.length; ii++) this.atomColor[ii] = (I$[1]||$incl$(1)).red;

for (var ii = 0; ii < this.molColor.length; ii++) this.molColor[ii] = (I$[1]||$incl$(1)).green;

});

Clazz.newMeth(C$, 'monodiLoop', function () {
this.tcount = this.tcount + 1;
this.theTime = this.theTime + this.dt;
for (this.mn = 1; this.mn < this.mnMax + 1; this.mn++) {
this.teta0[this.mn] = this.teta[this.mn];
this.xcm0[this.mn] = this.xcm[this.mn];
this.ycm0[this.mn] = this.ycm[this.mn];
this.vxcm0[this.mn] = this.vxcm[this.mn];
this.vycm0[this.mn] = this.vycm[this.mn];
this.w0[this.mn] = this.w[this.mn];
this.teta[this.mn] = this.teta0[this.mn] + this.w[this.mn] * this.dt;
this.xcm[this.mn] = this.xcm0[this.mn] + this.vxcm[this.mn] * this.dt;
this.ycm[this.mn] = this.ycm0[this.mn] + this.vycm[this.mn] * this.dt;
this.BallDValues$I(this.mn);
this.dwContact();
this.mnC = 0;
this.ddContact();
this.anC = 0;
if (this.MDcol == 1) {
this.dmContact();
}if (this.anC > 0) {
this.BallBounceDM();
}}
for (this.an = 1; this.an < this.anMax + 1; this.an++) {
this.ax0[this.an] = this.ax[this.an];
this.ay0[this.an] = this.ay[this.an];
this.avx0[this.an] = this.avx[this.an];
this.avy0[this.an] = this.avy[this.an];
this.ax[this.an] = this.ax[this.an] + this.avx[this.an] * this.dt;
this.ay[this.an] = this.ay[this.an] + this.avy[this.an] * this.dt;
this.mwContact();
this.anC = 0;
this.mmContact();
if (this.anC != 0) {
this.BallBounceMM();
}this.mnC = 0;
}
if (this.tcount == 1) {
this.KinEnTotal();
}});

Clazz.newMeth(C$, 'BallBounceDD', function () {
var vdMod;
var vdx;
var vdy;
var dVp1;
var dVp2;
var dw1;
var dw2;
var bvp1;
var bvp2;
var y1;
var y2;
var mn_Ncb;
var mnC_Ncb;
if (this.mn_cb == 1) {
mn_Ncb = 2;
} else {
mn_Ncb = 1;
}if (this.mnC_cb == 1) {
mnC_Ncb = 2;
} else {
mnC_Ncb = 1;
}vdx = this.$x[this.mnC][this.mnC_cb] - this.$x[this.mn][this.mn_cb];
vdy = this.$y[this.mnC][this.mnC_cb] - this.$y[this.mn][this.mn_cb];
vdMod = Math.sqrt(vdx * vdx + vdy * vdy);
bvp1 = (this.vx[this.mn][this.mn_cb] * vdx + this.vy[this.mn][this.mn_cb] * vdy) / vdMod;
bvp2 = (this.vx[this.mnC][this.mnC_cb] * vdx + this.vy[this.mnC][this.mnC_cb] * vdy) / vdMod;
y1 = (vdx * (this.$y[this.mn][mn_Ncb] - this.$y[this.mn][this.mn_cb]) - vdy * (this.$x[this.mn][mn_Ncb] - this.$x[this.mn][this.mn_cb])) / (2.0 * vdMod);
y2 = (vdx * (this.$y[this.mnC][mnC_Ncb] - this.$y[this.mnC][this.mnC_cb]) - vdy * (this.$x[this.mnC][mnC_Ncb] - this.$x[this.mnC][this.mnC_cb])) / (2.0 * vdMod);
dVp1 = 2.0 * (bvp2 - bvp1) / (1.0 + (y1 / this.d) * (y1 / this.d) + (this.mD / this.mD) * (1.0 + (y2 / this.d) * (y2 / this.d)));
dVp2 = 2.0 * (bvp1 - bvp2) / (1.0 + (y2 / this.d) * (y2 / this.d) + (this.mD / this.mD) * (1.0 + (y1 / this.d) * (y1 / this.d)));
dw1 = (y1 / (this.d * this.d)) * dVp1;
dw2 = (y2 / (this.d * this.d)) * dVp2;
this.vxcm0[this.mn] = this.vxcm[this.mn];
this.vycm0[this.mn] = this.vycm[this.mn];
this.vxcm0[this.mnC] = this.vxcm[this.mnC];
this.vycm0[this.mnC] = this.vycm[this.mnC];
this.w0[this.mn] = this.w[this.mn];
this.w0[this.mnC] = this.w[this.mnC];
this.vxcm[this.mn] = this.vxcm0[this.mn] + dVp1 * vdx / vdMod;
this.vycm[this.mn] = this.vycm0[this.mn] + dVp1 * vdy / vdMod;
this.vxcm[this.mnC] = this.vxcm0[this.mnC] + dVp2 * vdx / vdMod;
this.vycm[this.mnC] = this.vycm0[this.mnC] + dVp2 * vdy / vdMod;
this.w[this.mn] = this.w0[this.mn] + dw1;
this.w[this.mnC] = this.w0[this.mnC] + dw2;
var KEDchangeTrans = 0.0;
var KEDchangeRot = 0.0;
this.BallDVelValues$I(this.mn);
this.BallDVelValues$I(this.mnC);
KEDchangeTrans = 0.5 * this.mD * (this.vxcm[this.mn] * this.vxcm[this.mn] - this.vxcm0[this.mn] * this.vxcm0[this.mn]) ;
KEDchangeTrans += 0.5 * this.mD * (this.vycm[this.mn] * this.vycm[this.mn] - this.vycm0[this.mn] * this.vycm0[this.mn]) ;
KEDchangeTrans += 0.5 * this.mD * (this.vxcm[this.mnC] * this.vxcm[this.mnC] - this.vxcm0[this.mnC] * this.vxcm0[this.mnC]) ;
KEDchangeTrans += 0.5 * this.mD * (this.vycm[this.mnC] * this.vycm[this.mnC] - this.vycm0[this.mnC] * this.vycm0[this.mnC]) ;
KEDchangeRot = 0.5 * this.IM * (this.w[this.mn] * this.w[this.mn] - this.w0[this.mn] * this.w0[this.mn]) ;
KEDchangeRot += 0.5 * this.IM * (this.w[this.mnC] * this.w[this.mnC] - this.w0[this.mnC] * this.w0[this.mnC]) ;
this.KinEnDiatTrans += KEDchangeTrans;
this.KinEnDiatRot += KEDchangeRot;
this.KinEnDiat = this.KinEnDiatTrans + this.KinEnDiatRot;
this.KinEnTotalMD = this.KinEnMonoat + this.KinEnDiat;
});

Clazz.newMeth(C$, 'BallBounceDM', function () {
var vdMod;
var vdx;
var vdy;
var dVp1;
var dVp2;
var dw1;
var bvp1;
var bvp2;
var y1;
var y2;
var mn_Ncb;
if (this.mn_cb == 1) {
mn_Ncb = 2;
} else {
mn_Ncb = 1;
}vdx = this.$x[this.mn][this.mn_cb] - this.ax[this.anC];
vdy = this.$y[this.mn][this.mn_cb] - this.ay[this.anC];
vdMod = Math.sqrt(vdx * vdx + vdy * vdy);
bvp1 = (this.vx[this.mn][this.mn_cb] * vdx + this.vy[this.mn][this.mn_cb] * vdy) / vdMod;
bvp2 = (this.avx[this.anC] * vdx + this.avy[this.anC] * vdy) / vdMod;
y1 = (vdx * (this.$y[this.mn][mn_Ncb] - this.$y[this.mn][this.mn_cb]) - vdy * (this.$x[this.mn][mn_Ncb] - this.$x[this.mn][this.mn_cb])) / (2.0 * vdMod);
y2 = 0.0;
if (this.atomFixed[this.anC]) {
bvp2 = 0.0;
dVp1 = 2.0 * (bvp2 - bvp1) / (1.0 + (y1 / this.d) * (y1 / this.d));
dVp2 = 0.0;
} else {
dVp1 = 2.0 * (bvp2 - bvp1) / (1.0 + (y1 / this.d) * (y1 / this.d) + (this.mD / this.mM) * (1.0 + (y2 / this.d) * (y2 / this.d)));
dVp2 = 2.0 * (bvp1 - bvp2) / (1.0 + (y2 / this.d) * (y2 / this.d) + (this.mM / this.mD) * (1.0 + (y1 / this.d) * (y1 / this.d)));
}dw1 = (y1 / (this.d * this.d)) * dVp1;
this.avx0[this.anC] = this.avx[this.anC];
this.avy0[this.anC] = this.avy[this.anC];
this.vxcm0[this.mn] = this.vxcm[this.mn];
this.vycm0[this.mn] = this.vycm[this.mn];
this.w0[this.mn] = this.w[this.mn];
this.avx[this.anC] = this.avx0[this.anC] + dVp2 * vdx / vdMod;
this.avy[this.anC] = this.avy0[this.anC] + dVp2 * vdy / vdMod;
this.vxcm[this.mn] = this.vxcm0[this.mn] + dVp1 * vdx / vdMod;
this.vycm[this.mn] = this.vycm0[this.mn] + dVp1 * vdy / vdMod;
this.w[this.mn] = this.w0[this.mn] + dw1;
var KEDchangeTrans = 0.0;
var KEDchangeRot = 0.0;
var KEMchange = 0.0;
this.BallDVelValues$I(this.mn);
KEDchangeTrans = 0.5 * this.mD * (this.vxcm[this.mn] * this.vxcm[this.mn] - this.vxcm0[this.mn] * this.vxcm0[this.mn]) ;
KEDchangeTrans += 0.5 * this.mD * (this.vycm[this.mn] * this.vycm[this.mn] - this.vycm0[this.mn] * this.vycm0[this.mn]) ;
KEDchangeRot = 0.5 * this.IM * (this.w[this.mn] * this.w[this.mn] - this.w0[this.mn] * this.w0[this.mn]) ;
this.KinEnDiatTrans += KEDchangeTrans;
this.KinEnDiatRot += KEDchangeRot;
this.KinEnDiat = this.KinEnDiatTrans + this.KinEnDiatRot;
KEMchange = 0.5 * this.mM * (this.avx[this.anC] * this.avx[this.anC] - this.avx0[this.anC] * this.avx0[this.anC]) ;
KEMchange += 0.5 * this.mM * (this.avy[this.anC] * this.avy[this.anC] - this.avy0[this.anC] * this.avy0[this.anC]) ;
this.KinEnMonoat += KEMchange;
this.KinEnTotalMD = this.KinEnMonoat + this.KinEnDiat;
});

Clazz.newMeth(C$, 'BallBounceMM', function () {
var vdMod;
var vdx;
var vdy;
var bvp1;
var bvp2;
var dbvp1;
var dbvp2;
vdx = this.ax[this.anC] - this.ax[this.an];
vdy = this.ay[this.anC] - this.ay[this.an];
vdMod = Math.sqrt(vdx * vdx + vdy * vdy);
bvp1 = (this.avx[this.an] * vdx + this.avy[this.an] * vdy) / vdMod;
bvp2 = (this.avx[this.anC] * vdx + this.avy[this.anC] * vdy) / vdMod;
if (this.atomFixed[this.anC]) {
bvp2 = 0.0;
dbvp1 = 2.0 * (bvp2 - bvp1);
dbvp2 = 0.0;
} else if (this.atomFixed[this.an]) {
bvp1 = 0.0;
dbvp2 = 2.0 * (bvp1 - bvp2);
dbvp1 = 0.0;
} else {
dbvp1 = 2.0 * (bvp2 - bvp1) / (1 + this.mM / this.mM);
dbvp2 = 2.0 * (bvp1 - bvp2) / (1 + this.mM / this.mM);
}this.avx0[this.an] = this.avx[this.an];
this.avy0[this.an] = this.avy[this.an];
this.avx0[this.anC] = this.avx[this.anC];
this.avy0[this.anC] = this.avy[this.anC];
this.avx[this.an] = this.avx0[this.an] + dbvp1 * vdx / vdMod;
this.avy[this.an] = this.avy0[this.an] + dbvp1 * vdy / vdMod;
this.avx[this.anC] = this.avx0[this.anC] + dbvp2 * vdx / vdMod;
this.avy[this.anC] = this.avy0[this.anC] + dbvp2 * vdy / vdMod;
var KEMchange = 0.0;
KEMchange = 0.5 * this.mM * (this.avx[this.an] * this.avx[this.an] - this.avx0[this.an] * this.avx0[this.an]) ;
KEMchange += 0.5 * this.mM * (this.avy[this.an] * this.avy[this.an] - this.avy0[this.an] * this.avy0[this.an]) ;
KEMchange += 0.5 * this.mM * (this.avx[this.anC] * this.avx[this.anC] - this.avx0[this.anC] * this.avx0[this.anC]) ;
KEMchange += 0.5 * this.mM * (this.avy[this.anC] * this.avy[this.anC] - this.avy0[this.anC] * this.avy0[this.anC]) ;
this.KinEnMonoat += KEMchange;
this.KinEnTotalMD = this.KinEnMonoat + this.KinEnDiat;
});

Clazz.newMeth(C$, 'ddContact', function () {
var i;
var j;
var mnAuxiliar = this.mn + 1;
var dist2;
this.mnC = 0;
for (mnAuxiliar = this.mn + 1; mnAuxiliar < this.mnMax + 1; mnAuxiliar++) {
for (i = 1; i < 3; i++) {
for (j = 1; j < 3; j++) {
this.dotProduct = (this.$x[mnAuxiliar][j] - this.$x[this.mn][i]) * (this.vx[mnAuxiliar][j] - this.vx[this.mn][i]) + (this.$y[mnAuxiliar][j] - this.$y[this.mn][i]) * (this.vy[mnAuxiliar][j] - this.vy[this.mn][i]);
dist2 = (this.$x[this.mn][i] - this.$x[mnAuxiliar][j]) * (this.$x[this.mn][i] - this.$x[mnAuxiliar][j]) + (this.$y[this.mn][i] - this.$y[mnAuxiliar][j]) * (this.$y[this.mn][i] - this.$y[mnAuxiliar][j]);
if ((dist2 < (4 * this.radiusD * this.radiusD ) ) && (this.dotProduct < 0.0 ) ) {
this.mnC = mnAuxiliar;
this.mn_cb = i;
this.mnC_cb = j;
this.BallBounceDD();
}}
}
}
});

Clazz.newMeth(C$, 'mmContact', function () {
var anAux = this.an + 1;
var dist2;
this.anC = 0;
for (anAux = this.an + 1; anAux < this.anMax + 1; anAux++) {
this.dotProduct = (this.ax[anAux] - this.ax[this.an]) * (this.avx[anAux] - this.avx[this.an]) + (this.ay[anAux] - this.ay[this.an]) * (this.avy[anAux] - this.avy[this.an]);
dist2 = (this.ax[this.an] - this.ax[anAux]) * (this.ax[this.an] - this.ax[anAux]) + (this.ay[this.an] - this.ay[anAux]) * (this.ay[this.an] - this.ay[anAux]);
if ((!this.atomFixed[anAux] || !this.atomFixed[this.an] ) && (dist2 < (4 * this.radiusM * this.radiusM ) ) && ((this.dotProduct < 0.0 ))  ) {
this.anC = anAux;
return;
}}
});

Clazz.newMeth(C$, 'mwContact', function () {
this.mwc = 0;
if ((this.ax[this.an] + this.radiusM > this.iwidth ) && (this.avx[this.an] > 0.0 ) ) {
this.avx[this.an] = -this.avx[this.an];
}if ((this.ay[this.an] + this.radiusM > this.iheight ) && (this.avy[this.an] > 0.0 ) ) {
this.avy[this.an] = -this.avy[this.an];
}if ((this.ax[this.an] - this.radiusM < 0 ) && (this.avx[this.an] < 0.0 ) ) {
this.avx[this.an] = -this.avx[this.an];
}if ((this.ay[this.an] - this.radiusM < 0 ) && (this.avy[this.an] < 0.0 ) ) {
this.avy[this.an] = -this.avy[this.an];
}var KEMchange = 0.0;
KEMchange = 0.5 * this.mM * (this.avx[this.an] * this.avx[this.an] - this.avx0[this.an] * this.avx0[this.an]) ;
KEMchange += 0.5 * this.mM * (this.avy[this.an] * this.avy[this.an] - this.avy0[this.an] * this.avy0[this.an]) ;
this.KinEnMonoat += KEMchange;
this.KinEnTotalMD = this.KinEnMonoat + this.KinEnDiat;
});

Clazz.newMeth(C$, 'dmContact', function () {
var j;
var anAuxiliar = 1;
var dist2;
var sumaRad;
sumaRad = (this.radiusD + this.radiusM);
this.anC = 0;
for (anAuxiliar = 1; anAuxiliar < this.anMax + 1; anAuxiliar++) {
j = 1;
for (j = 1; j < 3; j++) {
this.dotProduct = (this.ax[anAuxiliar] - this.$x[this.mn][j]) * (this.avx[anAuxiliar] - this.vx[this.mn][j]) + (this.ay[anAuxiliar] - this.$y[this.mn][j]) * (this.avy[anAuxiliar] - this.vy[this.mn][j]);
dist2 = (this.ax[anAuxiliar] - this.$x[this.mn][j]) * (this.ax[anAuxiliar] - this.$x[this.mn][j]) + (this.ay[anAuxiliar] - this.$y[this.mn][j]) * (this.ay[anAuxiliar] - this.$y[this.mn][j]);
if ((dist2 < sumaRad * sumaRad ) && (this.dotProduct < 0.0 ) ) {
this.anC = anAuxiliar;
this.mn_cb = j;
return;
}}
}
});

Clazz.newMeth(C$, 'dwContact', function () {
this.wc1 = 0;
this.wc2 = 0;
this.cb = 0;
this.cb0 = 0;
this.wcn = 0;
if ((this.$x[this.mn][1] + this.radiusD > this.iwidth ) && (this.vx[this.mn][1] > 0.0 ) ) {
this.wc = 1;
this.cb = 1;
this.WallBounceD();
}if ((this.$y[this.mn][1] + this.radiusD > this.iheight ) && (this.vy[this.mn][1] > 0.0 ) ) {
this.wc = 2;
this.cb = 1;
this.WallBounceD();
}if ((this.$x[this.mn][1] - this.radiusD < 0 ) && (this.vx[this.mn][1] < 0.0 ) ) {
this.wc = 3;
this.cb = 1;
this.WallBounceD();
}if ((this.$y[this.mn][1] - this.radiusD < 0 ) && (this.vy[this.mn][1] < 0.0 ) ) {
this.wc = 4;
this.cb = 1;
this.WallBounceD();
}if ((this.$x[this.mn][2] + this.radiusD > this.iwidth ) && (this.vx[this.mn][2] > 0.0 ) ) {
this.wc = 1;
this.cb = 2;
this.WallBounceD();
}if ((this.$y[this.mn][2] + this.radiusD > this.iheight ) && (this.vy[this.mn][2] > 0.0 ) ) {
this.wc = 2;
this.cb = 2;
this.WallBounceD();
}if ((this.$x[this.mn][2] - this.radiusD < 0 ) && (this.vx[this.mn][2] < 0.0 ) ) {
this.wc = 3;
this.cb = 2;
this.WallBounceD();
}if ((this.$y[this.mn][2] - this.radiusD < 0 ) && (this.vy[this.mn][2] < 0.0 ) ) {
this.wc = 4;
this.cb = 2;
this.WallBounceD();
}});

Clazz.newMeth(C$, 'BallDValues$I', function (m) {
var dx;
var dy;
dx = this.d * Math.cos(this.teta[m]);
dy = this.d * Math.sin(this.teta[m]);
this.$x[m][1] = this.xcm[m] - dx;
this.$y[m][1] = this.ycm[m] - dy;
this.$x[m][2] = this.xcm[m] + dx;
this.$y[m][2] = this.ycm[m] + dy;
this.vx[m][1] = this.vxcm[m] + this.w[m] * this.d * Math.sin(this.teta[m]) ;
this.vx[m][2] = this.vxcm[m] - this.w[m] * this.d * Math.sin(this.teta[m]) ;
this.vy[m][1] = this.vycm[m] - this.w[m] * this.d * Math.cos(this.teta[m]) ;
this.vy[m][2] = this.vycm[m] + this.w[m] * this.d * Math.cos(this.teta[m]) ;
});

Clazz.newMeth(C$, 'BallDVelValues$I', function (m) {
this.vx[m][1] = this.vxcm[m] + this.w[m] * this.d * Math.sin(this.teta[m]) ;
this.vx[m][2] = this.vxcm[m] - this.w[m] * this.d * Math.sin(this.teta[m]) ;
this.vy[m][1] = this.vycm[m] - this.w[m] * this.d * Math.cos(this.teta[m]) ;
this.vy[m][2] = this.vycm[m] + this.w[m] * this.d * Math.cos(this.teta[m]) ;
});

Clazz.newMeth(C$, 'WallBounceD', function () {
var vdMod;
var vdx = 0;
var vdy = 0;
var Vp1;
var dVp1;
var w1;
var dw1;
var y1;
var mn_Ncb;
this.mn_cb = this.cb;
mn_Ncb = 3 - this.cb;
if (this.wc == 1) {
vdx = 1;
vdy = 0;
}if (this.wc == 2) {
vdx = 0;
vdy = 1;
}if (this.wc == 3) {
vdx = -1;
vdy = 0;
}if (this.wc == 4) {
vdx = 0;
vdy = -1;
}w1 = this.w[this.mn];
vdMod = Math.sqrt(vdx * vdx + vdy * vdy);
Vp1 = (this.vxcm[this.mn] * vdx + this.vycm[this.mn] * vdy) / vdMod;
y1 = (vdx * (this.$y[this.mn][mn_Ncb] - this.$y[this.mn][this.mn_cb]) - vdy * (this.$x[this.mn][mn_Ncb] - this.$x[this.mn][this.mn_cb])) / (2.0 * vdMod);
dVp1 = -2.0 * (Vp1 + y1 * w1) / (1.0 + (y1 / this.d) * (y1 / this.d));
dw1 = (y1 / (this.d * this.d)) * dVp1;
this.vxcm0[this.mn] = this.vxcm[this.mn];
this.vycm0[this.mn] = this.vycm[this.mn];
this.w0[this.mn] = this.w[this.mn];
this.w0[this.mnC] = this.w[this.mnC];
this.vxcm[this.mn] = this.vxcm0[this.mn] + dVp1 * vdx / vdMod;
this.vycm[this.mn] = this.vycm0[this.mn] + dVp1 * vdy / vdMod;
this.w[this.mn] = this.w0[this.mn] + dw1;
this.wc = 0;
this.BallDVelValues$I(this.mn);
var KEDchangeTrans = 0.0;
var KEDchangeRot = 0.0;
KEDchangeTrans = 0.5 * this.mD * (this.vxcm[this.mn] * this.vxcm[this.mn] - this.vxcm0[this.mn] * this.vxcm0[this.mn]) ;
KEDchangeTrans += 0.5 * this.mD * (this.vycm[this.mn] * this.vycm[this.mn] - this.vycm0[this.mn] * this.vycm0[this.mn]) ;
KEDchangeRot = 0.5 * this.IM * (this.w[this.mn] * this.w[this.mn] - this.w0[this.mn] * this.w0[this.mn]) ;
this.KinEnDiatTrans += KEDchangeTrans;
this.KinEnDiatRot += KEDchangeRot;
this.KinEnDiat = this.KinEnDiatTrans + this.KinEnDiatRot;
this.KinEnTotalMD = this.KinEnMonoat + this.KinEnDiat;
});

Clazz.newMeth(C$, 'WallBounceM', function () {
if (this.mwc == 1) {
this.avx[this.an] = -this.avx[this.an];
}if (this.mwc == 3) {
this.avx[this.an] = -this.avx[this.an];
}if (this.mwc == 2) {
this.avy[this.an] = -this.avy[this.an];
}if (this.mwc == 4) {
this.avy[this.an] = -this.avy[this.an];
}});

Clazz.newMeth(C$, 'KinEnTotal', function () {
this.energyCalls++;
this.KinEnDiatTrans = 0.0;
this.KinEnDiatRot = 0.0;
this.KinEnDiat = 0.0;
this.KinEnMonoat = 0;
this.KinEnD();
this.KinEnM();
this.KinEnTotalMD = this.KinEnMonoat + this.KinEnDiat;
});

Clazz.newMeth(C$, 'KinEnM', function () {
this.KinEnMonoat = 0.0;
for (var anAux = 1; anAux < this.anMax + 1; anAux++) {
this.KinEnMonoat = this.KinEnMonoat + 0.5 * this.mM * (this.avx[anAux] * this.avx[anAux] + this.avy[anAux] * this.avy[anAux]) ;
}
});

Clazz.newMeth(C$, 'KinEnD', function () {
var mnAux = 1;
this.KinEnDiatTrans = 0.0;
this.KinEnDiatRot = 0.0;
while (mnAux < this.mnMax + 1){
this.vx[mnAux][1] = this.vxcm[mnAux] + this.w[mnAux] * this.d * Math.sin(this.teta[mnAux]) ;
this.vx[mnAux][2] = this.vxcm[mnAux] - this.w[mnAux] * this.d * Math.sin(this.teta[mnAux]) ;
this.vy[mnAux][1] = this.vycm[mnAux] - this.w[mnAux] * this.d * Math.cos(this.teta[mnAux]) ;
this.vy[mnAux][2] = this.vycm[mnAux] + this.w[mnAux] * this.d * Math.cos(this.teta[mnAux]) ;
this.KinEnDiatTrans = this.KinEnDiatTrans + 0.5 * (this.mD) * (this.vxcm[mnAux] * this.vxcm[mnAux] + this.vycm[mnAux] * this.vycm[mnAux]) ;
this.KinEnDiatRot = this.KinEnDiatRot + 0.5 * this.IM * this.w[mnAux] * this.w[mnAux] ;
mnAux = mnAux + 1;
}
this.KinEnDiat = this.KinEnDiatTrans + this.KinEnDiatRot;
this.keRot_keTrans = this.keRot_keTrans + this.KinEnDiatRot / this.KinEnDiatTrans;
this.tEnerAv = this.tEnerAv + 1;
if (this.mnMax != 0) {
this.tempD = this.KinEnDiatTrans / this.mnMax;
} else {
this.tempD = 0.0;
}});
})();
//Created 2018-03-16 05:19:05
