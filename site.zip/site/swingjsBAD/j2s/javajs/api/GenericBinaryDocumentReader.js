(function(){var P$=Clazz.newPackage("javajs.api"),I$=[];
var C$=Clazz.newInterface(P$, "GenericBinaryDocumentReader");
})();
//Created 2018-07-22 16:19:53 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
