(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'java.awt.Button','java.awt.TextArea','java.awt.Color',['circuitsimulator.ValueInput','.SymAction']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ValueInput", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.Dialog');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.changeOK=false;
this.cb=null;
this.ce=null;
this.mode=null;
this.fComponentsAdjusted=false;
this.buttonOK=null;
this.buttonCancel=null;
this.textInput=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.changeOK=false;
this.cb=null;
this.ce=null;
this.mode="Properties";
this.fComponentsAdjusted=false;
this.buttonOK=Clazz.new_($I$(1));
this.buttonCancel=Clazz.new_($I$(1));
this.textInput=Clazz.new_($I$(2).c$$S$I$I,["", 0, 0]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component', function (parent) {
C$.superclazz.c$$java_awt_Frame$S$Z.apply(this, [null, "", false]);
C$.$init$.apply(this);
this.setLayout$java_awt_LayoutManager(null);
this.setSize$I$I(306, 130);
this.setVisible$Z(false);
this.setLocationRelativeTo$java_awt_Component(parent);
this.add$java_awt_Component(this.buttonOK);
this.buttonOK.setBackground$java_awt_Color($I$(3).lightGray);
this.buttonOK.setBounds$I$I$I$I(68, 85, 68, 24);
this.add$java_awt_Component(this.buttonCancel);
this.buttonCancel.setBackground$java_awt_Color($I$(3).lightGray);
this.buttonCancel.setBounds$I$I$I$I(158, 84, 71, 24);
this.add$java_awt_Component(this.textInput);
this.textInput.setBounds$I$I$I$I(7, 7, 287, 71);
var lSymAction=Clazz.new_($I$(4), [this, null]);
this.buttonOK.addActionListener$java_awt_event_ActionListener(lSymAction);
this.buttonCancel.addActionListener$java_awt_event_ActionListener(lSymAction);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$java_awt_Component.apply(this, [null]);
}, 1);

Clazz.newMeth(C$, 'c$$S$circuitsimulator_CircuitBuilder$java_awt_Component', function (sTitle, cirbuilder, parent) {
C$.c$$java_awt_Component.apply(this, [parent]);
this.cb=cirbuilder;
this.ce=this.cb.currentElement;
this.setTitle$S(sTitle);
if (this.getTitle$().equals$O(this.cb.cirProp.getProperty$S("changevalue_title"))) {
this.textInput.setText$S(this.ce.get$());
this.mode="Properties";
} else if (this.getTitle$().equals$O(this.cb.cirProp.getProperty$S("elemlabel_title"))) {
this.textInput.setText$S(this.ce.getlabel$());
this.mode="Label";
}this.buttonOK.setLabel$S(this.cb.cirProp.getProperty$S("OK"));
this.buttonCancel.setLabel$S(this.cb.cirProp.getProperty$S("Cancel"));
this.setTitle$S(this.cb.cirProp.getProperty$S(this.ce.getMyName$()) + ": " + sTitle );
this.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'addNotify$', function () {
var d=this.getSize$();
C$.superclazz.prototype.addNotify$.apply(this, []);
if (this.fComponentsAdjusted) return;
var ins=this.getInsets$();
this.setSize$I$I(ins.left + ins.right + d.width , ins.top + ins.bottom + d.height );
var components=this.getComponents$();
for (var i=0; i < components.length; i++) {
var p=components[i].getLocation$();
p.translate$I$I(ins.left, ins.top);
components[i].setLocation$java_awt_Point(p);
}
this.fComponentsAdjusted=true;
});

Clazz.newMeth(C$, 'buttonOK_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.changeOK=true;
if (this.mode.equals$O("Properties")) {
this.cb.set$I$S(this.cb.currentElement.hashCode$(), this.textInput.getText$());
this.cb.calculateCircuit$();
this.cb.repaintMeters$();
} else if (this.mode.equals$O("Label")) {
this.cb.setLabel$I$S(this.cb.currentElement.hashCode$(), this.textInput.getText$());
}this.setVisible$Z(false);
});

Clazz.newMeth(C$, 'buttonCancel_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.changeOK=false;
this.setVisible$Z(false);
});

Clazz.newMeth(C$, 'getchangeOK$', function () {
return this.changeOK;
});
;
(function(){var C$=Clazz.newClass(P$.ValueInput, "SymAction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (event) {
var object=event.getSource$();
if (object === this.this$0.buttonOK ) this.this$0.buttonOK_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.buttonCancel ) this.this$0.buttonCancel_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:49 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
