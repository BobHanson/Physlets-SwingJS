(function(){var P$=Clazz.newPackage("blackbody"),I$=[['java.awt.Color','blackbody.BlackBody','java.awt.Dimension',['blackbody.BlackBody','.BBGraph'],['blackbody.BlackBody','.PyroPanel'],'java.awt.Checkbox','edu.davidson.display.SNumber','java.awt.Label','edu.davidson.graphics.EtchedBorder','java.awt.FlowLayout','java.awt.BorderLayout','edu.davidson.display.Format','edu.davidson.display.SSlider','Boolean','java.lang.Thread','edu.davidson.tools.SApplet','blackbody.BlackBody_graph_mouseMotionAdapter','blackbody.BlackBody_graph_mouseAdapter','blackbody.BlackBody_autox_itemAdapter','blackbody.BlackBody_autoy_itemAdapter','blackbody.BlackBody_slider_mouseAdapter','blackbody.BlackBody_slider_adjustmentAdapter','blackbody.BlackBody_redNumber_actionAdapter','blackbody.BlackBody_tempNumber_actionAdapter','edu.davidson.display.CaptionThing','Thread','java.awt.Cursor']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "BlackBody", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', ['Runnable', 'edu.davidson.tools.SDataSource']);
C$.h = 0;
C$.c = 0;
C$.k = 0;
C$.pi = 0;
C$.exp = 0;
C$.phcc = 0;
C$.hc = 0;
C$.np = 0;
C$.halfWidth = 0;
C$.saturation = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.h = 6.626075E-34;
C$.c = 2.99792458E8;
C$.k = 1.380658E-23;
C$.pi = 3.141592653589793;
C$.exp = 2.718281828459045;
C$.phcc = (2 * C$.pi * C$.h * C$.c * C$.c );
C$.hc = C$.h * C$.c;
C$.np = 1000;
C$.halfWidth = 160;
C$.saturation = Clazz.array(Integer.TYPE, [C$.halfWidth * 2]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.label_wavelength = null;
this.label_appearance = null;
this.label_title = null;
this.label_energydensity = null;
this.label_lambdamax = null;
this.label_r = null;
this.label_g = null;
this.label_b = null;
this.label_t = null;
this.label_autox = null;
this.label_autoy = null;
this.$lock = null;
this.paintThread = null;
this.varStrings = null;
this.ds = null;
this.graph = null;
this.swatch = null;
this.autox = null;
this.autoy = null;
this.redNumber = null;
this.greenNumber = null;
this.blueNumber = null;
this.label1 = null;
this.label2 = null;
this.label3 = null;
this.totalNumber = null;
this.bevelPanel1 = null;
this.flowLayout1 = null;
this.label4 = null;
this.bevelPanel2 = null;
this.bevelPanel3 = null;
this.temperature = 0;
this.lambda = 0;
this.r = 0;
this.g = 0;
this.b = 0;
this.greenColor = 0;
this.showControls = false;
this.colorSwatch = false;
this.enableCursor = false;
this.i = 0;
this.xPos1 = 0;
this.xPos2 = 0;
this.$x = null;
this.$y = null;
this.newData = false;
this.borderLayout3 = null;
this.label5 = null;
this.label6 = null;
this.borderLayout4 = null;
this.mouseFormat = null;
this.slider = null;
this.tempNumber = null;
this.borderLayout1 = null;
this.borderLayout2 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.label_wavelength = "Wavelength [m]";
this.label_appearance = "Appearance";
this.label_title = "Blackbody Radiation";
this.label_energydensity = "Energy Density [J/m^{4}]";
this.label_lambdamax = "lambda max =";
this.label_r = "R";
this.label_g = "G";
this.label_b = "B";
this.label_t = "T=";
this.label_autox = "Auto X";
this.label_autoy = "Auto Y";
this.$lock =  Clazz.new_();
this.paintThread = null;
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "lambda"]);
this.ds = Clazz.array(Double.TYPE, [1, 2]);
this.graph = Clazz.new_((I$[4]||$incl$(4)).c$$blackbody_BlackBody, [this, null, this]);
this.swatch = Clazz.new_((I$[5]||$incl$(5)), [this, null]);
this.autox = Clazz.new_((I$[6]||$incl$(6)));
this.autoy = Clazz.new_((I$[6]||$incl$(6)));
this.redNumber = Clazz.new_((I$[7]||$incl$(7)));
this.greenNumber = Clazz.new_((I$[7]||$incl$(7)));
this.blueNumber = Clazz.new_((I$[7]||$incl$(7)));
this.label1 = Clazz.new_((I$[8]||$incl$(8)));
this.label2 = Clazz.new_((I$[8]||$incl$(8)));
this.label3 = Clazz.new_((I$[8]||$incl$(8)));
this.totalNumber = Clazz.new_((I$[7]||$incl$(7)));
this.bevelPanel1 = Clazz.new_((I$[9]||$incl$(9)));
this.flowLayout1 = Clazz.new_((I$[10]||$incl$(10)));
this.label4 = Clazz.new_((I$[8]||$incl$(8)));
this.bevelPanel2 = Clazz.new_((I$[9]||$incl$(9)));
this.bevelPanel3 = Clazz.new_((I$[9]||$incl$(9)));
this.showControls = true;
this.colorSwatch = true;
this.enableCursor = true;
this.i = 0;
this.$x = Clazz.array(Double.TYPE, [C$.np]);
this.$y = Clazz.array(Double.TYPE, [C$.np]);
this.newData = false;
this.borderLayout3 = Clazz.new_((I$[11]||$incl$(11)));
this.label5 = Clazz.new_((I$[8]||$incl$(8)));
this.label6 = Clazz.new_((I$[8]||$incl$(8)));
this.borderLayout4 = Clazz.new_((I$[11]||$incl$(11)));
this.mouseFormat = Clazz.new_((I$[12]||$incl$(12)).c$$S,["%-3.3g"]);
this.slider = Clazz.new_((I$[13]||$incl$(13)));
this.tempNumber = Clazz.new_((I$[7]||$incl$(7)));
this.borderLayout1 = Clazz.new_((I$[11]||$incl$(11)));
this.borderLayout2 = Clazz.new_((I$[11]||$incl$(11)));
}, 1);

Clazz.newMeth(C$, 'calSaturation', function () {
var w = C$.halfWidth * 2;
for (var i = 0; i < w; i++) {
var arg = 1.4 * (i - C$.halfWidth) / C$.halfWidth;
C$.saturation[i] = ((255 * Math.exp(-arg * arg))|0);
;}
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'setResources', function () {
this.label_wavelength = this.localProperties.getProperty$S$S("label.wavelength", this.label_wavelength);
this.label_appearance = this.localProperties.getProperty$S$S("label.appearance", this.label_appearance);
this.label_title = this.localProperties.getProperty$S$S("label.title", this.label_title);
this.label_energydensity = this.localProperties.getProperty$S$S("label.energydensity", this.label_energydensity);
this.label_lambdamax = this.localProperties.getProperty$S$S("label.lambdamax", this.label_lambdamax);
this.label_r = this.localProperties.getProperty$S$S("label.r", this.label_r);
this.label_g = this.localProperties.getProperty$S$S("label.g", this.label_g);
this.label_b = this.localProperties.getProperty$S$S("label.b", this.label_b);
this.label_t = this.localProperties.getProperty$S$S("label.t", this.label_t);
this.label_autox = this.localProperties.getProperty$S$S("label.autox", this.label_autox);
this.label_autoy = this.localProperties.getProperty$S$S("label.autoy", this.label_autoy);
});

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
try {
this.showControls = (I$[14]||$incl$(14)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.colorSwatch = (I$[14]||$incl$(14)).$valueOf(this.getParameter$S$S("ColorSwatch", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.enableCursor = (I$[14]||$incl$(14)).$valueOf(this.getParameter$S$S("EnableCursor", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.temperature = Double.$valueOf(this.getParameter$S$S("Temp", "5321")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.jbInit();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(1, (I$[1]||$incl$(1)).red, true, 0);
this.graph.setAutoReplaceData$I$Z(1, true);
C$.calSaturation();
this.tempNumber.setFormat$S("%+6.2f");
this.paintThread = Clazz.new_((I$[15]||$incl$(15)).c$$Runnable,[this]);
this.paintThread.start();
try {
(I$[16]||$incl$(16)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.setSize$java_awt_Dimension(Clazz.new_((I$[3]||$incl$(3)).c$$I$I,[445, 378]));
this.graph.setBorders$S("20,20,50,20");
this.graph.setLabelY$S(this.label_energydensity);
this.graph.addMouseMotionListener$java_awt_event_MouseMotionListener(Clazz.new_((I$[17]||$incl$(17)).c$$blackbody_BlackBody,[this]));
this.graph.addMouseListener$java_awt_event_MouseListener(Clazz.new_((I$[18]||$incl$(18)).c$$blackbody_BlackBody,[this]));
this.autox.setState$Z(true);
this.autox.addItemListener$java_awt_event_ItemListener(Clazz.new_((I$[19]||$incl$(19)).c$$blackbody_BlackBody,[this]));
this.autox.setVisible$Z(true);
this.autox.setLabel$S(this.label_autox);
this.autoy.setState$Z(true);
this.autoy.addItemListener$java_awt_event_ItemListener(Clazz.new_((I$[20]||$incl$(20)).c$$blackbody_BlackBody,[this]));
this.swatch.setLayout$java_awt_LayoutManager(this.borderLayout4);
this.label1.setText$S("blue");
this.label2.setText$S("green");
this.label3.setText$S("red");
this.bevelPanel1.setVisible$Z(false);
this.label4.setText$S("total");
this.label5.setText$S(this.label_title);
this.label6.setBackground$java_awt_Color((I$[1]||$incl$(1)).black);
this.label6.setForeground$java_awt_Color((I$[1]||$incl$(1)).white);
this.label6.setText$S("        Colors");
this.slider.addMouseListener$java_awt_event_MouseListener(Clazz.new_((I$[21]||$incl$(21)).c$$blackbody_BlackBody,[this]));
this.slider.addAdjustmentListener$java_awt_event_AdjustmentListener(Clazz.new_((I$[22]||$incl$(22)).c$$blackbody_BlackBody,[this]));
this.bevelPanel3.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.bevelPanel2.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.bevelPanel1.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.redNumber.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[23]||$incl$(23)).c$$blackbody_BlackBody,[this]));
this.autoy.setVisible$Z(true);
this.autoy.setLabel$S(this.label_autoy);
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.add$java_awt_Component$O(this.graph, "Center");
if (this.colorSwatch) {
this.add$java_awt_Component$O(this.swatch, "West");
}this.swatch.setBackground$java_awt_Color((I$[1]||$incl$(1)).black);
this.graph.setBackground$java_awt_Color(Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[230, 230, 230]));
this.graph.setLabelX$S(this.label_wavelength);
if (this.showControls) {
this.add$java_awt_Component$O(this.bevelPanel2, "South");
}this.bevelPanel2.add$java_awt_Component$O(this.bevelPanel1, "North");
this.bevelPanel1.add$java_awt_Component$O(this.label1, null);
this.bevelPanel1.add$java_awt_Component$O(this.blueNumber, null);
this.bevelPanel1.add$java_awt_Component$O(this.label2, null);
this.bevelPanel1.add$java_awt_Component$O(this.greenNumber, null);
this.bevelPanel1.add$java_awt_Component$O(this.label3, null);
this.bevelPanel1.add$java_awt_Component$O(this.redNumber, null);
this.bevelPanel1.add$java_awt_Component$O(this.label4, null);
this.bevelPanel1.add$java_awt_Component$O(this.totalNumber, null);
this.bevelPanel2.add$java_awt_Component$O(this.bevelPanel3, "South");
this.bevelPanel2.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.bevelPanel3.setBackground$java_awt_Color((I$[1]||$incl$(1)).lightGray);
this.bevelPanel3.add$java_awt_Component$O(this.autox, "West");
this.bevelPanel3.add$java_awt_Component$O(this.autoy, "Center");
this.bevelPanel3.add$java_awt_Component$O(this.label5, "East");
this.bevelPanel2.add$java_awt_Component$O(this.slider, "Center");
this.bevelPanel2.add$java_awt_Component$O(this.tempNumber, "East");
this.setT$D(this.temperature);
this.slider.setDValue$D(this.temperature / 10000);
this.tempNumber.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[24]||$incl$(24)).c$$blackbody_BlackBody,[this]));
});

Clazz.newMeth(C$, 'start', function () {
{
this.newData = true;
this.graph.iheight = 0;
this.$lock.notify();
}C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'setDefault', function () {
this.pause();
this.deleteDataConnections();
this.graph.clearAllThings();
});

Clazz.newMeth(C$, 'destroy', function () {
this.destroyed = true;
this.autoRefresh = false;
this.graph.destroy();
this.paintThread = null;
{
this.newData = true;
this.$lock.notify();
}C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Name: BlackBody\u000d\u000aAuthor: Wolfgang Christian and Mike Lee\u000d\u000aemail:wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Temp", "double", "Temperature"]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "whether or not to show UI controls"]), Clazz.array(java.lang.String, -1, ["colorSwatch", "integer", "whether or not to show color swatch"]), Clazz.array(java.lang.String, -1, ["EnableCursor", "integer", "whether or not to enable cursor"])]);
return pinfo;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.temperature;
this.ds[0][1] = this.lambda * 1.0E9;
return this.ds;
});

Clazz.newMeth(C$, ['addCaption$S','addCaption'], function (txt) {
var t = Clazz.new_((I$[25]||$incl$(25)).c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$S$D$D,[this, this.graph, txt, 0, 0]);
t.setDisplayOff$I$I(0, -40);
var id = this.graph.addThing$edu_davidson_display_Thing(t);
{
this.newData = true;
this.$lock.notify();
}this.graph.repaint();
return id;
});

Clazz.newMeth(C$, ['setRGB$I$I$I$I','setRGB'], function (id, r, g, b) {
var c = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[r, g, b]);
this.graph.setObjectColor$I$java_awt_Color(id, c);
});

Clazz.newMeth(C$, ['setDisplayOffset$I$I$I','setDisplayOffset'], function (id, xOff, yOff) {
var t = this.graph.getThing$I(id);
if (t == null ) {
return false;
}t.setDisplayOff$I$I(xOff, yOff);
{
this.newData = true;
this.$lock.notify();
}this.graph.repaint();
return true;
});

Clazz.newMeth(C$, ['setTemperature$D','setTemperature'], function (temp) {
this.setT$D(temp);
});

Clazz.newMeth(C$, ['setT$D','setT'], function (temp) {
this.graph.clearSeries$I(1);
var maximumXValue = 1.0E-6;
var delta = maximumXValue / C$.np;
this.temperature = temp;
var redValue = 0;
var greenValue = 0;
var blueValue = 0;
var totalValue = 0;
var maxValue = 0;
var redUnrounded;
var greenUnrounded;
var blueUnrounded;
var colorScale = C$.np / 60.0;
for (this.i = 1; this.i < C$.np; this.i++) {
this.$x[this.i] = this.i * delta;
if (this.$x[this.i] * C$.k * this.temperature  <= 0 ) {
this.$y[this.i] = 0;
} else {
this.$y[this.i] = C$.phcc / ((Math.pow(C$.exp, C$.hc / (this.$x[this.i] * C$.k * this.temperature )) - 1) * Math.pow(this.$x[this.i], 5));
}if (!!(this.i >= 19 * colorScale  & this.i <= 29 * colorScale )) {
blueValue = blueValue + this.$y[this.i];
}if (!!(this.i >= 29 * colorScale  & this.i <= 38 * colorScale )) {
greenValue = greenValue + this.$y[this.i];
}if (!!(this.i >= 38 * colorScale  & this.i <= 46 * colorScale )) {
redValue = redValue + this.$y[this.i];
}}
totalValue = blueValue + greenValue + redValue ;
maxValue = Math.max(blueValue, redValue);
maxValue = Math.max(maxValue, greenValue);
if (redValue < 6.158 ) {
redUnrounded = 0;
} else {
redUnrounded = 255.0 * redValue / maxValue * (Math.log(totalValue) / 20);
}if (greenValue < 6.158 ) {
greenUnrounded = 0;
} else {
greenUnrounded = 255.0 * greenValue / maxValue * (Math.log(totalValue) / 20);
}if (blueValue < 6.158 ) {
blueUnrounded = 0;
} else {
blueUnrounded = 255.0 * blueValue / maxValue * (Math.log(totalValue) / 20);
}this.r = (Math.min(redUnrounded, 255)|0);
this.g = (Math.min(greenUnrounded, 255)|0);
this.greenColor = this.g;
this.b = (Math.min(blueUnrounded, 255)|0);
this.redNumber.setValue$D(redValue);
this.greenNumber.setValue$D(greenValue);
this.blueNumber.setValue$D(blueValue);
this.totalNumber.setValue$D(totalValue);
this.graph.addData$I$DA$DA(1, this.$x, this.$y);
this.swatch.repaint();
this.tempNumber.setValue$D(this.temperature);
this.lambda = 0.0029 / this.temperature;
{
this.newData = true;
this.$lock.notify();
}this.updateDataConnections();
});

Clazz.newMeth(C$, 'run', function () {
while (this.paintThread != null ){
{
if (!this.newData) {
try {
this.$lock.wait();
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
} else {
throw ie;
}
}
}this.newData = false;
if (this.paintThread != null ) {
this.graph.paintImage();
}}if (this.paintThread != null ) {
try {
(I$[26]||$incl$(26)).sleep$J(50);
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
} else {
throw ie;
}
}
}}
});

Clazz.newMeth(C$, ['setAutoscale$Z$Z','setAutoscale'], function (x, y) {
if (x) {
this.graph.setAutoscaleX$Z(true);
} else {
this.graph.setAutoscaleX$Z(false);
}if (y) {
this.graph.setAutoscaleY$Z(true);
} else {
this.graph.setAutoscaleY$Z(false);
}});

Clazz.newMeth(C$, 'slider_adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
this.setT$D(this.slider.getDValue() * 10000);
this.graph.repaint();
});

Clazz.newMeth(C$, 'redNumber_actionPerformed$java_awt_event_ActionEvent', function (e) {
});

Clazz.newMeth(C$, 'graph_mousePressed$java_awt_event_MouseEvent', function (e) {
if (this.enableCursor) {
var g = this.graph.getGraphics();
g.setColor$java_awt_Color((I$[1]||$incl$(1)).yellow);
g.fillRect$I$I$I$I(25, this.graph.pixFromY$D(0) + 28, 155, 15);
this.lambda = 0.0029 / this.temperature;
this.xPos1 = this.graph.pixFromX$D(this.lambda);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).blue);
g.drawLine$I$I$I$I(this.xPos1, 0, this.xPos1, 12);
g.drawLine$I$I$I$I(this.xPos1, 12, this.xPos1 - 3, 9);
g.drawLine$I$I$I$I(this.xPos1, 12, this.xPos1 + 3, 9);
this.xPos2 = e.getX();
if (this.xPos2 <= this.graph.pixFromX$D(0)) {
this.xPos2 = this.graph.pixFromX$D(0) + 1;
}if (this.xPos2 >= this.graph.pixFromX$D(1.0E-6)) {
this.xPos2 = this.graph.pixFromX$D(1.0E-6);
}g.drawLine$I$I$I$I(this.xPos2, 0, this.xPos2, 12);
g.drawLine$I$I$I$I(this.xPos2, 12, this.xPos2 - 3, 9);
g.drawLine$I$I$I$I(this.xPos2, 12, this.xPos2 + 3, 9);
this.lambda = this.graph.xFromPix$I(this.xPos2);
g.drawString$S$I$I(this.label_lambdamax + " " + this.mouseFormat.form$D(this.lambda * 1.0E9) + " nm" , 30, this.graph.pixFromY$D(0) + 40);
this.slider.setDValue$D(((0.0029 / this.lambda)) / 10000);
this.tempNumber.setValue$D(((0.0029 / this.lambda)));
this.temperature = 0.0029 / this.lambda;
g.dispose();
this.updateDataConnections();
}});

Clazz.newMeth(C$, 'graph_mouseDragged$java_awt_event_MouseEvent', function (e) {
if (this.enableCursor) {
var g = this.graph.getGraphics();
g.setColor$java_awt_Color(Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[230, 230, 230]));
g.drawLine$I$I$I$I(this.xPos2, 0, this.xPos2, 12);
g.drawLine$I$I$I$I(this.xPos2, 12, this.xPos2 - 3, 9);
g.drawLine$I$I$I$I(this.xPos2, 12, this.xPos2 + 3, 9);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).yellow);
g.fillRect$I$I$I$I(25, this.graph.pixFromY$D(0) + 28, 155, 15);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).blue);
this.xPos2 = e.getX();
if (this.xPos2 <= this.graph.pixFromX$D(0)) {
this.xPos2 = this.graph.pixFromX$D(0) + 1;
}if (this.xPos2 >= this.graph.pixFromX$D(1.0E-6)) {
this.xPos2 = this.graph.pixFromX$D(1.0E-6);
}g.drawLine$I$I$I$I(this.xPos1, 0, this.xPos1, 12);
g.drawLine$I$I$I$I(this.xPos1, 12, this.xPos1 - 3, 9);
g.drawLine$I$I$I$I(this.xPos1, 12, this.xPos1 + 3, 9);
g.drawLine$I$I$I$I(this.xPos2, 0, this.xPos2, 12);
g.drawLine$I$I$I$I(this.xPos2, 12, this.xPos2 - 3, 9);
g.drawLine$I$I$I$I(this.xPos2, 12, this.xPos2 + 3, 9);
this.lambda = this.graph.xFromPix$I(this.xPos2);
g.drawString$S$I$I(this.label_lambdamax + " " + this.mouseFormat.form$D(this.lambda * 1.0E9) + " nm" , 30, this.graph.pixFromY$D(0) + 40);
this.slider.setDValue$D(((0.0029 / this.lambda)) / 10000);
this.tempNumber.setValue$D(((0.0029 / this.lambda)));
this.temperature = 0.0029 / this.lambda;
g.dispose();
this.updateDataConnections();
}});

Clazz.newMeth(C$, 'graph_mouseReleased$java_awt_event_MouseEvent', function (e) {
if (this.enableCursor) {
this.xPos2 = e.getX();
if (this.xPos2 <= this.graph.pixFromX$D(0)) {
this.xPos2 = this.graph.pixFromX$D(0) + 1;
}if (this.xPos2 >= this.graph.pixFromX$D(1.0E-6)) {
this.xPos2 = this.graph.pixFromX$D(1.0E-6);
}this.lambda = this.graph.xFromPix$I(this.xPos2);
this.setT$D(0.0029 / this.lambda);
this.slider.setDValue$D(((0.0029 / this.lambda)) / 10000);
this.tempNumber.setValue$D(((0.0029 / this.lambda)));
}});

Clazz.newMeth(C$, 'slider_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.setAutoscale$Z$Z(this.autox.getState(), this.autoy.getState());
this.setT$D(this.slider.getDValue() * 10000);
this.graph.repaint();
});

Clazz.newMeth(C$, 'graph_mouseEntered$java_awt_event_MouseEvent', function (e) {
if (this.enableCursor) {
this.setCursor$java_awt_Cursor((I$[27]||$incl$(27)).getPredefinedCursor$I(12));
}});

Clazz.newMeth(C$, 'graph_mouseExited$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor((I$[27]||$incl$(27)).getPredefinedCursor$I(0));
});

Clazz.newMeth(C$, 'autoy_itemStateChanged$java_awt_event_ItemEvent', function (e) {
{
this.newData = true;
this.$lock.notify();
}this.setAutoscale$Z$Z(this.autox.getState(), this.autoy.getState());
});

Clazz.newMeth(C$, 'autox_itemStateChanged$java_awt_event_ItemEvent', function (e) {
{
this.newData = true;
this.$lock.notify();
}this.setAutoscale$Z$Z(this.autox.getState(), this.autoy.getState());
});

Clazz.newMeth(C$, 'tempNumber_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.setT$D(this.tempNumber.getValue());
this.slider.setDValue$D((this.tempNumber.getValue()) / 10000);
});
;
(function(){var C$=Clazz.newClass(P$.BlackBody, "BBGraph", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'edu.davidson.display.SGraph');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.iheight = 0;
this.iwidth = 0;
this.osi = null;
this.applet = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.iheight = 0;
this.iwidth = 0;
this.osi = null;
}, 1);

Clazz.newMeth(C$, 'c$$blackbody_BlackBody', function (app) {
C$.superclazz.c$$edu_davidson_tools_SApplet.apply(this, [app]);
C$.$init$.apply(this);
this.applet = app;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.applet.destroyed) {
return;
}{
if (!this.this$0.newData && (this.osi != null ) ) {
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
} else {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
}}});

Clazz.newMeth(C$, 'paintImage', function () {
if (this.applet.destroyed) {
return;
}if ((this.osi == null ) || (this.iwidth != this.getSize().width) || (this.iheight != this.getSize().height)  ) {
this.iwidth = this.getSize().width;
this.iheight = this.getSize().height;
if ((this.iheight < 10) || (this.iwidth < 10) ) {
this.osi = null;
return;
}this.osi = this.createImage$I$I(this.iwidth, this.iheight);
}if (this.osi == null ) {
return;
}var osg = this.osi.getGraphics();
osg.setColor$java_awt_Color(this.getBackground());
osg.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
if (this.applet.destroyed) {
return;
}C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [osg]);
osg.dispose();
var g = this.getGraphics();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
g.dispose();
});

Clazz.newMeth(C$, 'getIntensity$D', function (x) {
if (x * (I$[2]||$incl$(2)).k * this.this$0.temperature  <= 0 ) {
return 0;
}return (I$[2]||$incl$(2)).phcc / ((Math.pow((I$[2]||$incl$(2)).exp, (I$[2]||$incl$(2)).hc / (x * (I$[2]||$incl$(2)).k * this.this$0.temperature )) - 1) * Math.pow(x, 5));
});

Clazz.newMeth(C$, 'getColor$D', function (x) {
var r = 0;
var g = 0;
var b = 0;
var nm = ((x * 1.0E9)|0);
if ((nm > 400 - (I$[2]||$incl$(2)).halfWidth) && (nm < 400 + (I$[2]||$incl$(2)).halfWidth) ) {
b = (I$[2]||$incl$(2)).saturation[nm - 400 + (I$[2]||$incl$(2)).halfWidth];
}if ((nm > 500 - (I$[2]||$incl$(2)).halfWidth) && (nm < 500 + (I$[2]||$incl$(2)).halfWidth) ) {
g = (I$[2]||$incl$(2)).saturation[nm - 500 + (I$[2]||$incl$(2)).halfWidth];
}if ((nm > 600 - (I$[2]||$incl$(2)).halfWidth) && (nm < 600 + (I$[2]||$incl$(2)).halfWidth) ) {
r = (I$[2]||$incl$(2)).saturation[nm - 600 + (I$[2]||$incl$(2)).halfWidth];
}return Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, 'paintLast$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
if (this.applet.destroyed) {
return;
}this.paintSpectrum$java_awt_Graphics(g);
C$.superclazz.prototype.paintLast$java_awt_Graphics$java_awt_Rectangle.apply(this, [g, r]);
});

Clazz.newMeth(C$, 'paintSpectrum$java_awt_Graphics', function (g) {
if (this.applet.destroyed) {
return;
}var iStart = this.pixFromX$D(this.this$0.$x[1]);
var iEnd = this.pixFromX$D(this.this$0.$x[(I$[2]||$incl$(2)).np - 1]);
var y0 = this.pixFromY$D(0);
var y = 0;
var x = 0;
for (var i = iStart; i < iEnd; i++) {
x = this.xFromPix$I(i);
y = this.getIntensity$D(x);
g.setColor$java_awt_Color(this.getColor$D(x));
g.drawLine$I$I$I$I(i, y0, i, this.pixFromY$D(y));
}
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.BlackBody, "PyroPanel", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'edu.davidson.graphics.SPanel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.setMinimumSize$java_awt_Dimension(Clazz.new_((I$[3]||$incl$(3)).c$$I$I,[80, 100]));
this.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[3]||$incl$(3)).c$$I$I,[80, 100]));
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color(Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[this.this$0.r, 0, 0]));
g.fillOval$I$I$I$I((this.getBounds().width/2|0) - 15, 15, 30, 30);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
g.drawString$S$I$I(this.this$0.label_r, (this.getBounds().width/2|0) - 30, 35);
g.setColor$java_awt_Color(Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, this.this$0.greenColor, 0]));
g.fillOval$I$I$I$I((this.getBounds().width/2|0) - 15, 50, 30, 30);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
g.drawString$S$I$I(this.this$0.label_g, (this.getBounds().width/2|0) - 30, 70);
g.setColor$java_awt_Color(Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 0, this.this$0.b]));
g.fillOval$I$I$I$I((this.getBounds().width/2|0) - 15, 85, 30, 30);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
g.drawString$S$I$I(this.this$0.label_r, (this.getBounds().width/2|0) - 30, 105);
g.setColor$java_awt_Color(Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[this.this$0.r, this.this$0.greenColor, this.this$0.b]));
g.fillOval$I$I$I$I((this.getBounds().width/2|0) - 20, 150, 40, 40);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
g.drawString$S$I$I(this.this$0.label_appearance, (this.getBounds().width/2|0) - 35, 210);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
g.drawString$S$I$I(this.this$0.label_t + (this.this$0.temperature|0) + " K" , (this.getBounds().width/2|0) - 30, 240);
});
})()
})();
//Created 2018-02-19 20:23:15
