(function(){var P$=Clazz.newPackage("galton"),I$=[];
var C$=Clazz.newClass(P$, "Ball", null, null, 'java.awt.image.ImageObserver');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x = 0;
this.y = 0;
this.vx = 0;
this.vy = 0;
this.vlen = 0;
this.r = 0;
this.w = 0;
this.h = 0;
this.itsImage = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.itsImage = null;
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (tx, ty) {
C$.$init$.apply(this);
this.x = tx;
this.y = ty;
this.vx = 0;
this.vy = 0;
this.vlen = 0;
}, 1);

Clazz.newMeth(C$, 'Move', function () {
this.x += this.vx;
this.y += this.vy;
});

Clazz.newMeth(C$, 'Accelerate$D$D', function (ax, ay) {
this.vx += ax;
this.vy += ay;
this.vlen = Math.sqrt(this.vx * this.vx + this.vy * this.vy);
});

Clazz.newMeth(C$, 'Boink$I$I$D', function (pinx, piny, pinr) {
var dx;
var dy;
var dist;
dx = this.x - pinx;
dy = this.y - piny;
dist = Math.sqrt(dx * dx + dy * dy);
if (dist <= pinr + this.r ) {
var tvx;
var tvy;
var proj;
tvx = this.vx / this.vlen;
tvy = this.vy / this.vlen;
dx /= dist;
dy /= dist;
proj = tvx * dx + tvy * dy;
tvx -= 2.0 * proj * dx ;
tvy -= 2.0 * proj * dy ;
this.vx = tvx * this.vlen;
this.vy = tvy * this.vlen;
do {
this.x += this.vx;
this.y += this.vy;
dx = this.x - pinx;
dy = this.y - piny;
dist = Math.sqrt(dx * dx + dy * dy);
} while (dist <= pinr + this.r );
this.vx *= 0.75;
this.vy *= 0.75;
this.vlen = Math.sqrt(this.vx * this.vx + this.vy * this.vy);
return true;
} else return false;
});

Clazz.newMeth(C$, 'SetImage$java_awt_Image', function (aImage) {
this.itsImage = aImage;
this.w = this.itsImage.getWidth$java_awt_image_ImageObserver(this);
this.h = this.itsImage.getHeight$java_awt_image_ImageObserver(this);
this.r = this.w / 2.0;
});

Clazz.newMeth(C$, 'Draw$java_awt_Graphics', function (g) {
if (this.itsImage != null ) g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.itsImage, (this.x|0) - (this.w/2|0), (this.y|0) - (this.h/2|0), this);
});

Clazz.newMeth(C$, 'imageUpdate$java_awt_Image$I$I$I$I$I', function (img, infoflags, x, y, width, height) {
if ((infoflags & 3) == 3) {
if (img === this.itsImage ) {
this.w = width;
this.h = height;
this.r = (this.w/2|0);
}return false;
}return true;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:18
