(function(){var P$=Clazz.newPackage("circuit"),I$=[];
var C$=Clazz.newClass(P$, "IVApplet_vSlider_adjustmentAdapter", null, null, 'java.awt.event.AdjustmentListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuit_IVApplet', function (adaptee) {
C$.$init$.apply(this);
this.adaptee = adaptee;
}, 1);

Clazz.newMeth(C$, 'adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
this.adaptee.vSlider_adjustmentValueChanged$java_awt_event_AdjustmentEvent(e);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-26 06:56:25
