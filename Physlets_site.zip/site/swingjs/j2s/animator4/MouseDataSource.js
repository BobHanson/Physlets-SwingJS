(function(){var P$=Clazz.newPackage("animator4"),I$=[];
var C$=Clazz.newClass(P$, "MouseDataSource", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.owner = null;
this.trackMove = false;
this.trackDrag = false;
this.trackClick = false;
this.trackRelease = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.trackMove = false;
this.trackDrag = false;
this.trackClick = false;
this.trackRelease = false;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas', function (c) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [c, "0", "0"]);
C$.$init$.apply(this);
this.canvas = c;
this.owner = c.owner;
this.ds[0][0] = 0;
this.ds[0][1] = 0;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y"]);
this.ds = Clazz.array(Double.TYPE, [1, 2]);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
;});

Clazz.newMeth(C$, 'getX', function () {
return this.ds[0][0];
});

Clazz.newMeth(C$, 'getY', function () {
return this.ds[0][1];
});

Clazz.newMeth(C$, 'moveXY$I$I', function (xpix, ypix) {
if (!this.trackMove) return;
this.ds[0][0] = this.canvas.xFromPix$I(xpix);
this.ds[0][1] = this.canvas.yFromPix$I(ypix);
this.vars[1] = this.ds[0][0];
this.vars[2] = this.ds[0][1];
this.owner.updateDataConnection$I(this.hashCode());
});

Clazz.newMeth(C$, 'dragXY$D$D', function (x, y) {
if (!this.trackDrag) return;
this.ds[0][0] = x;
this.ds[0][1] = y;
this.vars[1] = x;
this.vars[2] = y;
this.owner.updateDataConnection$I(this.hashCode());
});

Clazz.newMeth(C$, 'clickXY$I$I', function (xpix, ypix) {
if (!this.trackClick) return;
this.ds[0][0] = this.canvas.xFromPix$I(xpix);
this.ds[0][1] = this.canvas.yFromPix$I(ypix);
this.vars[1] = this.ds[0][0];
this.vars[2] = this.ds[0][1];
this.owner.updateDataConnection$I(this.hashCode());
});

Clazz.newMeth(C$, 'releaseXY$I$I', function (xpix, ypix) {
if (!this.trackRelease) return;
this.ds[0][0] = this.canvas.xFromPix$I(xpix);
this.ds[0][1] = this.canvas.yFromPix$I(ypix);
this.vars[1] = this.ds[0][0];
this.vars[2] = this.ds[0][1];
this.owner.updateDataConnection$I(this.hashCode());
});

Clazz.newMeth(C$, 'setTrackMove$Z', function (track) {
this.trackMove = track;
});

Clazz.newMeth(C$, 'setTrackDrag$Z', function (track) {
this.trackDrag = track;
});

Clazz.newMeth(C$, 'setTrackClick$Z', function (track) {
this.trackClick = track;
});

Clazz.newMeth(C$, 'setTrackRelease$Z', function (track) {
this.trackRelease = track;
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$);
})();
//Created 2018-03-16 05:18:58
