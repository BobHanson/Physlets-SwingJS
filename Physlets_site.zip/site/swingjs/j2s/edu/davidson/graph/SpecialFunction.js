(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[];
var C$=Clazz.newClass(P$, "SpecialFunction");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'log10$D', function (x) {
if (x <= 0.0 ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["range exception"]);
return Math.log(x) / 2.302585092994046;
}, 1);

Clazz.newMeth(C$, 'cosh$D', function (x) {
var a;
a = x;
if (a < 0.0 ) a = Math.abs(x);
a = Math.exp(a);
return 0.5 * (a + 1 / a);
}, 1);

Clazz.newMeth(C$, 'sinh$D', function (x) {
var a;
if (x == 0.0 ) return x;
a = x;
if (a < 0.0 ) a = Math.abs(x);
a = Math.exp(a);
if (x < 0.0 ) return -0.5 * (a - 1 / a);
 else return 0.5 * (a - 1 / a);
}, 1);

Clazz.newMeth(C$, 'tanh$D', function (x) {
var a;
if (x == 0.0 ) return x;
a = x;
if (a < 0.0 ) a = Math.abs(x);
a = Math.exp(2.0 * a);
if (x < 0.0 ) return -(1.0 - 2.0 / (a + 1.0));
 else return (1.0 - 2.0 / (a + 1.0));
}, 1);

Clazz.newMeth(C$, 'acosh$D', function (x) {
if (x < 1.0 ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["range exception"]);
return Math.log(x + Math.sqrt(x * x - 1));
}, 1);

Clazz.newMeth(C$, 'asinh$D', function (xx) {
var x;
var sign;
if (xx == 0.0 ) return xx;
if (xx < 0.0 ) {
sign = -1;
x = -xx;
} else {
sign = 1;
x = xx;
}return sign * Math.log(x + Math.sqrt(x * x + 1));
}, 1);

Clazz.newMeth(C$, 'atanh$D', function (x) {
if (x > 1.0  || x < -1.0  ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["range exception"]);
return 0.5 * Math.log((1.0 + x) / (1.0 - x));
}, 1);

Clazz.newMeth(C$, 'j0$D', function (x) {
var ax;
if ((ax = Math.abs(x)) < 8.0 ) {
var y = x * x;
var ans1 = 5.7568490574E10 + y * (-1.3362590354E10 + y * (6.516196407E8 + y * (-1.121442418E7 + y * (77392.33017 + y * -184.9052456))));
var ans2 = 5.7568490411E10 + y * (1.029532985E9 + y * (9494680.718 + y * (59272.64853 + y * (267.8532712 + y * 1.0))));
return ans1 / ans2;
} else {
var z = 8.0 / ax;
var y = z * z;
var xx = ax - 0.785398164;
var ans1 = 1.0 + y * (-0.001098628627 + y * (2.734510407E-5 + y * (-2.073370639E-6 + y * 2.093887211E-7)));
var ans2 = -0.01562499995 + y * (1.430488765E-4 + y * (-6.911147651E-6 + y * (7.621095161E-7 - y * 9.34935152E-8)));
return Math.sqrt(0.636619772 / ax) * (Math.cos(xx) * ans1 - z * Math.sin(xx) * ans2 );
}}, 1);

Clazz.newMeth(C$, 'j1$D', function (x) {
var ax;
var y;
var ans1;
var ans2;
if ((ax = Math.abs(x)) < 8.0 ) {
y = x * x;
ans1 = x * (7.2362614232E10 + y * (-7.895059235E9 + y * (2.423968531E8 + y * (-2972611.439 + y * (15704.4826 + y * -30.16036606)))));
ans2 = 1.44725228442E11 + y * (2.300535178E9 + y * (1.858330474E7 + y * (99447.43394 + y * (376.9991397 + y * 1.0))));
return ans1 / ans2;
} else {
var z = 8.0 / ax;
var xx = ax - 2.356194491;
y = z * z;
ans1 = 1.0 + y * (0.00183105 + y * (-3.516396496E-5 + y * (2.457520174E-6 + y * -2.40337019E-7)));
ans2 = 0.04687499995 + y * (-2.002690873E-4 + y * (8.449199096E-6 + y * (-8.8228987E-7 + y * 1.05787412E-7)));
var ans = Math.sqrt(0.636619772 / ax) * (Math.cos(xx) * ans1 - z * Math.sin(xx) * ans2 );
if (x < 0.0 ) ans = -ans;
return ans;
}}, 1);

Clazz.newMeth(C$, 'jn$I$D', function (n, x) {
var j;
var m;
var ax;
var bj;
var bjm;
var bjp;
var sum;
var tox;
var ans;
var jsum;
var ACC = 40.0;
var BIGNO = 1.0E10;
var BIGNI = 1.0E-10;
if (n == 0) return C$.j0$D(x);
if (n == 1) return C$.j1$D(x);
ax = Math.abs(x);
if (ax == 0.0 ) return 0.0;
 else if (ax > n ) {
tox = 2.0 / ax;
bjm = C$.j0$D(ax);
bj = C$.j1$D(ax);
for (j = 1; j < n; j++) {
bjp = j * tox * bj  - bjm;
bjm = bj;
bj = bjp;
}
ans = bj;
} else {
tox = 2.0 / ax;
m = 2 * (((n + (Math.sqrt(ACC * n)|0))/2|0));
jsum = false;
bjp = ans = sum = 0.0;
bj = 1.0;
for (j = m; j > 0; j--) {
bjm = j * tox * bj  - bjp;
bjp = bj;
bj = bjm;
if (Math.abs(bj) > BIGNO ) {
bj *= BIGNI;
bjp *= BIGNI;
ans *= BIGNI;
sum *= BIGNI;
}if (jsum) sum += bj;
jsum = !jsum;
if (j == n) ans = bjp;
}
sum = 2.0 * sum - bj;
ans /= sum;
}return x < 0.0  && n % 2 == 1  ? -ans : ans;
}, 1);

Clazz.newMeth(C$, 'y0$D', function (x) {
if (x < 8.0 ) {
var y = x * x;
var ans1 = -2.957821389E9 + y * (7.062834065E9 + y * (-5.123598036E8 + y * (1.087988129E7 + y * (-86327.92757 + y * 228.4622733))));
var ans2 = 4.0076544269E10 + y * (7.452499648E8 + y * (7189466.438 + y * (47447.2647 + y * (226.1030244 + y * 1.0))));
return (ans1 / ans2) + 0.636619772 * C$.j0$D(x) * Math.log(x) ;
} else {
var z = 8.0 / x;
var y = z * z;
var xx = x - 0.785398164;
var ans1 = 1.0 + y * (-0.001098628627 + y * (2.734510407E-5 + y * (-2.073370639E-6 + y * 2.093887211E-7)));
var ans2 = -0.01562499995 + y * (1.430488765E-4 + y * (-6.911147651E-6 + y * (7.621095161E-7 + y * -9.34945152E-8)));
return Math.sqrt(0.636619772 / x) * (Math.sin(xx) * ans1 + z * Math.cos(xx) * ans2 );
}}, 1);

Clazz.newMeth(C$, 'y1$D', function (x) {
if (x < 8.0 ) {
var y = x * x;
var ans1 = x * (-4.900604943E12 + y * (1.27527439E12 + y * (-5.153438139E10 + y * (7.349264551E8 + y * (-4237922.726 + y * 8511.937935)))));
var ans2 = 2.49958057E13 + y * (4.244419664E11 + y * (3.733650367E9 + y * (2.245904002E7 + y * (102042.605 + y * (354.9632885 + y)))));
return (ans1 / ans2) + 0.636619772 * (C$.j1$D(x) * Math.log(x) - 1.0 / x);
} else {
var z = 8.0 / x;
var y = z * z;
var xx = x - 2.356194491;
var ans1 = 1.0 + y * (0.00183105 + y * (-3.516396496E-5 + y * (2.457520174E-6 + y * -2.40337019E-7)));
var ans2 = 0.04687499995 + y * (-2.002690873E-4 + y * (8.449199096E-6 + y * (-8.8228987E-7 + y * 1.05787412E-7)));
return Math.sqrt(0.636619772 / x) * (Math.sin(xx) * ans1 + z * Math.cos(xx) * ans2 );
}}, 1);

Clazz.newMeth(C$, 'yn$I$D', function (n, x) {
var by;
var bym;
var byp;
var tox;
if (n == 0) return C$.y0$D(x);
if (n == 1) return C$.y1$D(x);
tox = 2.0 / x;
by = C$.y1$D(x);
bym = C$.y0$D(x);
for (var j = 1; j < n; j++) {
byp = j * tox * by  - bym;
bym = by;
by = byp;
}
return by;
}, 1);

Clazz.newMeth(C$, 'fac$D', function (x) {
var d = Math.abs(x);
if (Math.floor(d) == d ) return C$.fac$I((x|0));
 else return C$.gamma$D(x + 1.0);
}, 1);

Clazz.newMeth(C$, 'fac$I', function (j) {
var i = j;
var d = 1;
if (j < 0) i = Math.abs(j);
while (i > 1){
d = d*(i--);
}
if (j < 0) return -d;
 else return d;
}, 1);

Clazz.newMeth(C$, 'gamma$D', function (x) {
var P = Clazz.array(Double.TYPE, -1, [1.6011952247675185E-4, 0.0011913514700658638, 0.010421379756176158, 0.04763678004571372, 0.20744822764843598, 0.4942148268014971, 1.0]);
var Q = Clazz.array(Double.TYPE, -1, [-2.3158187332412014E-5, 5.396055804933034E-4, -0.004456419138517973, 0.011813978522206043, 0.035823639860549865, -0.23459179571824335, 0.0714304917030273, 1.0]);
var MAXGAM = 171.6243769563027;
var LOGPI = 1.1447298858494002;
var p;
var z;
var i;
var q = Math.abs(x);
if (q > 33.0 ) {
if (x < 0.0 ) {
p = Math.floor(q);
if (p == q ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["gamma: overflow"]);
i = (p|0);
z = q - p;
if (z > 0.5 ) {
p += 1.0;
z = q - p;
}z = q * Math.sin(3.141592653589793 * z);
if (z == 0.0 ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["gamma: overflow"]);
z = Math.abs(z);
z = 3.141592653589793 / (z * C$.stirf$D(q));
return -z;
} else {
return C$.stirf$D(x);
}}z = 1.0;
while (x >= 3.0 ){
x -= 1.0;
z *= x;
}
while (x < 0.0 ){
if (x == 0.0 ) {
throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["gamma: singular"]);
} else if (x > -1.0E-9 ) {
return (z / ((1.0 + 0.5772156649015329 * x) * x));
}z /= x;
x += 1.0;
}
while (x < 2.0 ){
if (x == 0.0 ) {
throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["gamma: singular"]);
} else if (x < 1.0E-9 ) {
return (z / ((1.0 + 0.5772156649015329 * x) * x));
}z /= x;
x += 1.0;
}
if ((x == 2.0 ) || (x == 3.0 ) ) return z;
x -= 2.0;
p = C$.polevl$D$DA$I(x, P, 6);
q = C$.polevl$D$DA$I(x, Q, 7);
return z * p / q;
}, 1);

Clazz.newMeth(C$, 'stirf$D', function (x) {
var STIR = Clazz.array(Double.TYPE, -1, [7.873113957930937E-4, -2.2954996161337813E-4, -0.0026813261780578124, 0.0034722222160545866, 0.08333333333334822]);
var MAXSTIR = 143.01608;
var w = 1.0 / x;
var y = Math.exp(x);
w = 1.0 + w * C$.polevl$D$DA$I(w, STIR, 4);
if (x > MAXSTIR ) {
var v = Math.pow(x, 0.5 * x - 0.25);
y = v * (v / y);
} else {
y = Math.pow(x, x - 0.5) / y;
}y = 2.5066282746310007 * y * w ;
return y;
}, 1);

Clazz.newMeth(C$, 'igamc$D$D', function (a, x) {
var big = 4.503599627370496E15;
var biginv = 2.220446049250313E-16;
var ans;
var ax;
var c;
var yc;
var r;
var t;
var y;
var z;
var pk;
var pkm1;
var pkm2;
var qk;
var qkm1;
var qkm2;
if (x <= 0  || a <= 0  ) return 1.0;
if (x < 1.0  || x < a  ) return 1.0 - C$.igam$D$D(a, x);
ax = a * Math.log(x) - x - C$.lgamma$D(a);
if (ax < -709.782712893384 ) return 0.0;
ax = Math.exp(ax);
y = 1.0 - a;
z = x + y + 1.0 ;
c = 0.0;
pkm2 = 1.0;
qkm2 = x;
pkm1 = x + 1.0;
qkm1 = z * x;
ans = pkm1 / qkm1;
do {
c += 1.0;
y += 1.0;
z += 2.0;
yc = y * c;
pk = pkm1 * z - pkm2 * yc;
qk = qkm1 * z - qkm2 * yc;
if (qk != 0 ) {
r = pk / qk;
t = Math.abs((ans - r) / r);
ans = r;
} else t = 1.0;
pkm2 = pkm1;
pkm1 = pk;
qkm2 = qkm1;
qkm1 = qk;
if (Math.abs(pk) > big ) {
pkm2 *= biginv;
pkm1 *= biginv;
qkm2 *= biginv;
qkm1 *= biginv;
}} while (t > 1.1102230246251565E-16 );
return ans * ax;
}, 1);

Clazz.newMeth(C$, 'igam$D$D', function (a, x) {
var ans;
var ax;
var c;
var r;
if (x <= 0  || a <= 0  ) return 0.0;
if (x > 1.0  && x > a  ) return 1.0 - C$.igamc$D$D(a, x);
ax = a * Math.log(x) - x - C$.lgamma$D(a);
if (ax < -709.782712893384 ) return 0.0;
ax = Math.exp(ax);
r = a;
c = 1.0;
ans = 1.0;
do {
r += 1.0;
c *= x / r;
ans += c;
} while (c / ans > 1.1102230246251565E-16 );
return (ans * ax / a);
}, 1);

Clazz.newMeth(C$, 'chisq$D$D', function (df, x) {
if (x < 0.0  || df < 1.0  ) return 0.0;
return C$.igam$D$D(df / 2.0, x / 2.0);
}, 1);

Clazz.newMeth(C$, 'chisqc$D$D', function (df, x) {
if (x < 0.0  || df < 1.0  ) return 0.0;
return C$.igamc$D$D(df / 2.0, x / 2.0);
}, 1);

Clazz.newMeth(C$, 'poisson$I$D', function (k, x) {
if (k < 0 || x < 0  ) return 0.0;
return C$.igamc$D$D((k + 1), x);
}, 1);

Clazz.newMeth(C$, 'poissonc$I$D', function (k, x) {
if (k < 0 || x < 0  ) return 0.0;
return C$.igam$D$D((k + 1), x);
}, 1);

Clazz.newMeth(C$, 'normal$D', function (a) {
var x;
var y;
var z;
x = a * 0.7071067811865476;
z = Math.abs(x);
if (z < 0.7071067811865476 ) y = 0.5 + 0.5 * C$.erf$D(x);
 else {
y = 0.5 * C$.erfc$D(z);
if (x > 0 ) y = 1.0 - y;
}return y;
}, 1);

Clazz.newMeth(C$, 'erfc$D', function (a) {
var x;
var y;
var z;
var p;
var q;
var P = Clazz.array(Double.TYPE, -1, [2.461969814735305E-10, 0.5641895648310689, 7.463210564422699, 48.63719709856814, 196.5208329560771, 526.4451949954773, 934.5285271719576, 1027.5518868951572, 557.5353353693994]);
var Q = Clazz.array(Double.TYPE, -1, [13.228195115474499, 86.70721408859897, 354.9377788878199, 975.7085017432055, 1823.9091668790973, 2246.3376081871097, 1656.6630919416134, 557.5353408177277]);
var R = Clazz.array(Double.TYPE, -1, [0.5641895835477551, 1.275366707599781, 5.019050422511805, 6.160210979930536, 7.4097426995044895, 2.9788666537210022]);
var S = Clazz.array(Double.TYPE, -1, [2.2605286322011726, 9.396035249380015, 12.048953980809666, 17.08144507475659, 9.608968090632859, 3.369076451000815]);
if (a < 0.0 ) x = -a;
 else x = a;
if (x < 1.0 ) return 1.0 - C$.erf$D(a);
z = -a * a;
if (z < -709.782712893384 ) {
if (a < 0 ) return 2.0;
 else return 0.0;
}z = Math.exp(z);
if (x < 8.0 ) {
p = C$.polevl$D$DA$I(x, P, 8);
q = C$.p1evl$D$DA$I(x, Q, 8);
} else {
p = C$.polevl$D$DA$I(x, R, 5);
q = C$.p1evl$D$DA$I(x, S, 6);
}y = (z * p) / q;
if (a < 0 ) y = 2.0 - y;
if (y == 0.0 ) {
if (a < 0 ) return 2.0;
 else return 0.0;
}return y;
}, 1);

Clazz.newMeth(C$, 'erf$D', function (x) {
var y;
var z;
var T = Clazz.array(Double.TYPE, -1, [9.604973739870516, 90.02601972038427, 2232.005345946843, 7003.325141128051, 55592.30130103949]);
var U = Clazz.array(Double.TYPE, -1, [33.56171416475031, 521.3579497801527, 4594.323829709801, 22629.000061389095, 49267.39426086359]);
if (Math.abs(x) > 1.0 ) return (1.0 - C$.erfc$D(x));
z = x * x;
y = x * C$.polevl$D$DA$I(z, T, 4) / C$.p1evl$D$DA$I(z, U, 5);
return y;
}, 1);

Clazz.newMeth(C$, 'polevl$D$DA$I', function (x, coef, N) {
var ans;
ans = coef[0];
for (var i = 1; i <= N; i++) {
ans = ans * x + coef[i];
}
return ans;
}, 1);

Clazz.newMeth(C$, 'p1evl$D$DA$I', function (x, coef, N) {
var ans;
ans = x + coef[0];
for (var i = 1; i < N; i++) {
ans = ans * x + coef[i];
}
return ans;
}, 1);

Clazz.newMeth(C$, 'lgamma$D', function (x) {
var p;
var q;
var w;
var z;
var A = Clazz.array(Double.TYPE, -1, [8.116141674705085E-4, -5.950619042843014E-4, 7.936503404577169E-4, -0.002777777777300997, 0.08333333333333319]);
var B = Clazz.array(Double.TYPE, -1, [-1378.2515256912086, -38801.631513463784, -331612.9927388712, -1162370.974927623, -1721737.0082083966, -853555.6642457654]);
var C = Clazz.array(Double.TYPE, -1, [-351.81570143652345, -17064.210665188115, -220528.59055385445, -1139334.4436798252, -2532523.0717758294, -2018891.4143353277]);
if (x < -34.0 ) {
q = -x;
w = C$.lgamma$D(q);
p = Math.floor(q);
if (p == q ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["lgam: Overflow"]);
z = q - p;
if (z > 0.5 ) {
p += 1.0;
z = p - q;
}z = q * Math.sin(3.141592653589793 * z);
if (z == 0.0 ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["lgamma: Overflow"]);
z = 1.1447298858494002 - Math.log(z) - w ;
return z;
}if (x < 13.0 ) {
z = 1.0;
while (x >= 3.0 ){
x -= 1.0;
z *= x;
}
while (x < 2.0 ){
if (x == 0.0 ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["lgamma: Overflow"]);
z /= x;
x += 1.0;
}
if (z < 0.0 ) z = -z;
if (x == 2.0 ) return Math.log(z);
x -= 2.0;
p = x * C$.polevl$D$DA$I(x, B, 5) / C$.p1evl$D$DA$I(x, C, 6);
return (Math.log(z) + p);
}if (x > 2.556348E305 ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["lgamma: Overflow"]);
q = (x - 0.5) * Math.log(x) - x + 0.9189385332046728;
if (x > 1.0E8 ) return (q);
p = 1.0 / (x * x);
if (x >= 1000.0 ) q += ((7.936507936507937E-4 * p - 0.002777777777777778) * p + 0.08333333333333333) / x;
 else q += C$.polevl$D$DA$I(p, A, 4) / x;
return q;
}, 1);

Clazz.newMeth(C$, 'ibeta$D$D$D', function (aa, bb, xx) {
var a;
var b;
var t;
var x;
var xc;
var w;
var y;
var flag;
if (aa <= 0.0  || bb <= 0.0  ) throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["ibeta: Domain error!"]);
if ((xx <= 0.0 ) || (xx >= 1.0 ) ) {
if (xx == 0.0 ) return 0.0;
if (xx == 1.0 ) return 1.0;
throw Clazz.new_(Clazz.load('java.lang.ArithmeticException').c$$S,["ibeta: Domain error!"]);
}flag = false;
if ((bb * xx) <= 1.0  && xx <= 0.95  ) {
t = C$.pseries$D$D$D(aa, bb, xx);
return t;
}w = 1.0 - xx;
if (xx > (aa / (aa + bb)) ) {
flag = true;
a = bb;
b = aa;
xc = xx;
x = w;
} else {
a = aa;
b = bb;
xc = w;
x = xx;
}if (flag && (b * x) <= 1.0   && x <= 0.95  ) {
t = C$.pseries$D$D$D(a, b, x);
if (t <= 1.1102230246251565E-16 ) t = 0.9999999999999999;
 else t = 1.0 - t;
return t;
}y = x * (a + b - 2.0) - (a - 1.0);
if (y < 0.0 ) w = C$.incbcf$D$D$D(a, b, x);
 else w = C$.incbd$D$D$D(a, b, x) / xc;
y = a * Math.log(x);
t = b * Math.log(xc);
if ((a + b) < 171.6243769563027  && Math.abs(y) < 709.782712893384   && Math.abs(t) < 709.782712893384  ) {
t = Math.pow(xc, b);
t *= Math.pow(x, a);
t /= a;
t *= w;
t *= C$.gamma$D(a + b) / (C$.gamma$D(a) * C$.gamma$D(b));
if (flag) {
if (t <= 1.1102230246251565E-16 ) t = 0.9999999999999999;
 else t = 1.0 - t;
}return t;
}y += t + C$.lgamma$D(a + b) - C$.lgamma$D(a) - C$.lgamma$D(b);
y += Math.log(w / a);
if (y < -745.1332191019412 ) t = 0.0;
 else t = Math.exp(y);
if (flag) {
if (t <= 1.1102230246251565E-16 ) t = 0.9999999999999999;
 else t = 1.0 - t;
}return t;
}, 1);

Clazz.newMeth(C$, 'incbcf$D$D$D', function (a, b, x) {
var xk;
var pk;
var pkm1;
var pkm2;
var qk;
var qkm1;
var qkm2;
var k1;
var k2;
var k3;
var k4;
var k5;
var k6;
var k7;
var k8;
var r;
var t;
var ans;
var thresh;
var n;
var big = 4.503599627370496E15;
var biginv = 2.220446049250313E-16;
k1 = a;
k2 = a + b;
k3 = a;
k4 = a + 1.0;
k5 = 1.0;
k6 = b - 1.0;
k7 = k4;
k8 = a + 2.0;
pkm2 = 0.0;
qkm2 = 1.0;
pkm1 = 1.0;
qkm1 = 1.0;
ans = 1.0;
r = 1.0;
n = 0;
thresh = 3.3306690738754696E-16;
do {
xk = -(x * k1 * k2 ) / (k3 * k4);
pk = pkm1 + pkm2 * xk;
qk = qkm1 + qkm2 * xk;
pkm2 = pkm1;
pkm1 = pk;
qkm2 = qkm1;
qkm1 = qk;
xk = (x * k5 * k6 ) / (k7 * k8);
pk = pkm1 + pkm2 * xk;
qk = qkm1 + qkm2 * xk;
pkm2 = pkm1;
pkm1 = pk;
qkm2 = qkm1;
qkm1 = qk;
if (qk != 0 ) r = pk / qk;
if (r != 0 ) {
t = Math.abs((ans - r) / r);
ans = r;
} else t = 1.0;
if (t < thresh ) return ans;
k1 += 1.0;
k2 += 1.0;
k3 += 2.0;
k4 += 2.0;
k5 += 1.0;
k6 -= 1.0;
k7 += 2.0;
k8 += 2.0;
if ((Math.abs(qk) + Math.abs(pk)) > big ) {
pkm2 *= biginv;
pkm1 *= biginv;
qkm2 *= biginv;
qkm1 *= biginv;
}if ((Math.abs(qk) < biginv ) || (Math.abs(pk) < biginv ) ) {
pkm2 *= big;
pkm1 *= big;
qkm2 *= big;
qkm1 *= big;
}} while (++n < 300);
return ans;
}, 1);

Clazz.newMeth(C$, 'incbd$D$D$D', function (a, b, x) {
var xk;
var pk;
var pkm1;
var pkm2;
var qk;
var qkm1;
var qkm2;
var k1;
var k2;
var k3;
var k4;
var k5;
var k6;
var k7;
var k8;
var r;
var t;
var ans;
var z;
var thresh;
var n;
var big = 4.503599627370496E15;
var biginv = 2.220446049250313E-16;
k1 = a;
k2 = b - 1.0;
k3 = a;
k4 = a + 1.0;
k5 = 1.0;
k6 = a + b;
k7 = a + 1.0;
;k8 = a + 2.0;
pkm2 = 0.0;
qkm2 = 1.0;
pkm1 = 1.0;
qkm1 = 1.0;
z = x / (1.0 - x);
ans = 1.0;
r = 1.0;
n = 0;
thresh = 3.3306690738754696E-16;
do {
xk = -(z * k1 * k2 ) / (k3 * k4);
pk = pkm1 + pkm2 * xk;
qk = qkm1 + qkm2 * xk;
pkm2 = pkm1;
pkm1 = pk;
qkm2 = qkm1;
qkm1 = qk;
xk = (z * k5 * k6 ) / (k7 * k8);
pk = pkm1 + pkm2 * xk;
qk = qkm1 + qkm2 * xk;
pkm2 = pkm1;
pkm1 = pk;
qkm2 = qkm1;
qkm1 = qk;
if (qk != 0 ) r = pk / qk;
if (r != 0 ) {
t = Math.abs((ans - r) / r);
ans = r;
} else t = 1.0;
if (t < thresh ) return ans;
k1 += 1.0;
k2 -= 1.0;
k3 += 2.0;
k4 += 2.0;
k5 += 1.0;
k6 += 1.0;
k7 += 2.0;
k8 += 2.0;
if ((Math.abs(qk) + Math.abs(pk)) > big ) {
pkm2 *= biginv;
pkm1 *= biginv;
qkm2 *= biginv;
qkm1 *= biginv;
}if ((Math.abs(qk) < biginv ) || (Math.abs(pk) < biginv ) ) {
pkm2 *= big;
pkm1 *= big;
qkm2 *= big;
qkm1 *= big;
}} while (++n < 300);
return ans;
}, 1);

Clazz.newMeth(C$, 'pseries$D$D$D', function (a, b, x) {
var s;
var t;
var u;
var v;
var n;
var t1;
var z;
var ai;
ai = 1.0 / a;
u = (1.0 - b) * x;
v = u / (a + 1.0);
t1 = v;
t = u;
n = 2.0;
s = 0.0;
z = 1.1102230246251565E-16 * ai;
while (Math.abs(v) > z ){
u = (n - b) * x / n;
t *= u;
v = t / (a + n);
s += v;
n += 1.0;
}
s += t1;
s += ai;
u = a * Math.log(x);
if ((a + b) < 171.6243769563027  && Math.abs(u) < 709.782712893384  ) {
t = C$.gamma$D(a + b) / (C$.gamma$D(a) * C$.gamma$D(b));
s = s * t * Math.pow(x, a) ;
} else {
t = C$.lgamma$D(a + b) - C$.lgamma$D(a) - C$.lgamma$D(b)  + u + Math.log(s);
if (t < -745.1332191019412 ) s = 0.0;
 else s = Math.exp(t);
}return s;
}, 1);
})();
//Created 2018-03-16 05:19:12
