(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'java.awt.Color','circuitsimulator.Circuit']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "CircuitCanvas", null, 'java.awt.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.d=0;
this.b=0;
this.parsedbgColor=null;
this.notparsedbgColor=null;
this.bgColor=null;
this.cirgrid=null;
this.circuit=null;
this.osIm=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.d=54;
this.b=27;
this.parsedbgColor=Clazz.new_($I$(1).c$$I$I$I,[255, 255, 185]);
this.notparsedbgColor=Clazz.new_($I$(1).c$$I$I$I,[192, 192, 192]);
this.osIm=null;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit', function (circ) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.circuit=circ;
this.bgColor=this.circuit.parsed ? this.parsedbgColor : this.notparsedbgColor;
this.setBackground$java_awt_Color(this.bgColor);
this.d=this.circuit.interGrid;
this.b=(this.d/2|0);
this.cirgrid=this.circuit.cirgrid;
var insetx=(((this.circuit.gridZone.width - (((this.cirgrid.cols + 0.5) * this.d)|0))/2|0));
var insety=(((this.circuit.gridZone.height - this.cirgrid.rows * this.d)/2|0));
this.setBounds$I$I$I$I(insetx, insety, (((this.cirgrid.cols + 0.5) * this.d)|0), this.cirgrid.rows * this.d);
if ((this.circuit.debugLevel & $I$(2).DEBUG_IO) > 0) {
System.out.println$S("canvas construction completed...");
}this.setSize$I$I(0, 0);
}, 1);

Clazz.newMeth(C$, 'reconnect$', function () {
this.d=this.circuit.interGrid;
this.b=(this.d/2|0);
this.cirgrid=this.circuit.cirgrid;
var insetx=(((this.circuit.gridZone.width - (((this.cirgrid.cols + 0.5) * this.d)|0))/2|0));
var insety=(((this.circuit.gridZone.height - this.cirgrid.rows * this.d)/2|0));
this.setBounds$I$I$I$I(insetx, insety, (((this.cirgrid.cols + 0.5) * this.d)|0), this.cirgrid.rows * this.d);
this.bgColor=this.circuit.parsed ? this.parsedbgColor : this.notparsedbgColor;
this.setBackground$java_awt_Color(this.bgColor);
if ((this.getSize$().width >= 1) && (this.getSize$().height >= 1) ) {
this.osIm=this.createImage$I$I(this.getSize$().width, this.getSize$().height);
this.redraw$();
}if ((this.circuit.debugLevel & $I$(2).DEBUG_IO) > 0) {
System.out.println$S("canvas construction completed..." + this.getSize$());
}});

Clazz.newMeth(C$, 'redraw$', function () {
if (this.osIm == null  || this.getSize$().width < 4  || this.getSize$().height < 4 ) {
return;
}this.bgColor=this.circuit.parsed ? this.parsedbgColor : this.notparsedbgColor;
var osGr=this.osIm.getGraphics$();

xxi = this.osIm
osGr.setColor$java_awt_Color(this.bgColor);
osGr.fillRect$I$I$I$I(1, 1, this.getSize$().width - 2, this.getSize$().height - 2);
osGr.setColor$java_awt_Color($I$(1).black);
osGr.drawRect$I$I$I$I(0, 0, this.getSize$().width - 1, this.getSize$().height - 1);
for (var i=0; i < this.cirgrid.rows; i++) {
for (var j=0; j < this.cirgrid.cols; j++) {
osGr.fillOval$I$I$I$I(this.b + j * this.d - 2, this.b + i * this.d - 2, 4, 4);
}
}
var list=this.cirgrid.cirElemList.clone$();
for (var i=0, n=list.size$(); i < n; i++) {
list.elementAt$I(i).paint$java_awt_Graphics(osGr);
list.elementAt$I(i).repaintImage$java_awt_Graphics(osGr);
}
osGr.dispose$();
this.repaint$();
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.osIm != null ) {
var osGr=this.osIm.getGraphics$();
for (var i=0; i < this.cirgrid.cirElemList.size$(); i++) {
this.cirgrid.cirElemList.elementAt$I(i).repaintImage$java_awt_Graphics(osGr);
}
osGr.dispose$();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osIm, 0, 0, this);
}return;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:48 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
