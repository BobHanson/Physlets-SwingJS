(function(){var P$=Clazz.newPackage("animator4"),I$=[];
var C$=Clazz.newClass(P$, "CollisionDataSource", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.owner = null;
this.blockStrings = null;
this.block = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.blockStrings = Clazz.array(java.lang.String, -1, ["blocked", "x", "y"]);
this.block = true;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas', function (c) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [c, "0", "0"]);
C$.$init$.apply(this);
this.canvas = c;
this.owner = c.owner;
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y"]);
this.ds = Clazz.array(Double.TYPE, [1, 3]);
this.ds[0][0] = 0;
this.ds[0][1] = 0;
this.ds[0][2] = 0;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
;});

Clazz.newMeth(C$, 'setBlock$Z', function (block) {
this.block = block;
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
this.ds[0][0] = this.owner.clock.getTime();
this.ds[0][1] = x;
this.ds[0][2] = y;
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
if (this.block) return this.blockStrings;
 else return this.varStrings;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:20:58
