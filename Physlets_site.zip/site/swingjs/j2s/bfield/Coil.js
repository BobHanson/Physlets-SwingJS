(function(){var P$=Clazz.newPackage("bfield"),I$=[[0,'java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Coil", null, 'bfield.Wire');
C$.n=0;
C$.theta=0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.n=6;
C$.theta=3.141592653589793 / C$.n;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.ptY1=0;
this.ptY2=0;
this.lastBReading=null;
this.lastPosition=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.ptY1=0;
this.ptY2=0;
this.lastBReading=Clazz.array(Double.TYPE, [2]);
this.lastPosition=Clazz.array(Double.TYPE, [2]);
}, 1);

Clazz.newMeth(C$, 'c$$bfield_FieldPanel$D$D$D', function (p, x, y, c) {
C$.superclazz.c$$bfield_FieldPanel$D$D$D.apply(this, [p, x, y, c]);
C$.$init$.apply(this);
this.s=10;
this.radius=0.5;
this.color=null;
this.showF=false;
this.showFComponents=false;
}, 1);

Clazz.newMeth(C$, 'getB$DA', function (h) {
var x1=h[0];
var y1=h[1];
var phi=C$.theta / 2;
var dl=this.radius * Math.sqrt(2 * (1 - Math.cos(C$.theta)));
var bx=0;
var by=0;
var dy;
var dz;
var rx;
var ry;
var rz;
var r2;
var r3;
for (var i=0; i < C$.n; i++) {
dy=-Math.sin(phi);
dz=Math.cos(phi);
rx=x1 - this.x + this.xo;
ry=y1 - this.y - this.radius * Math.cos(phi)  + this.yo;
rz=-this.radius * Math.sin(phi);
r2=rx * rx + ry * ry + rz * rz;
r3=Math.sqrt(r2) * r2;
bx += rz * dy / r3 - ry * dz / r3;
by += rx * dz / r3;
phi += C$.theta;
}
h[0]=2 * this.current * dl * bx ;
h[1]=2 * this.current * dl * by ;
return h;
});

Clazz.newMeth(C$, 'getWireBx$D$D', function (x1, y1) {
this.lastPosition[0]=x1;
this.lastPosition[1]=y1;
this.lastBReading=this.getB$DA(this.lastPosition);
return this.lastBReading[0];
});

Clazz.newMeth(C$, 'getWireBy$D$D', function (x1, y1) {
this.lastPosition[0]=x1;
this.lastPosition[1]=y1;
this.lastBReading=this.getB$DA(this.lastPosition);
return this.lastBReading[1];
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.isVisible$()) return;
this.xPix=this.p.pixFromX$D(this.x) + this.xDisplayOff;
this.ptY1=this.p.pixFromY$D(this.y - this.radius) - this.yDisplayOff;
this.ptY2=this.p.pixFromY$D(this.y + this.radius) - this.yDisplayOff;
this.yPix=((this.ptY1 + this.ptY2)/2|0) - this.yDisplayOff;
osg.setColor$java_awt_Color(Clazz.new_($I$(1).c$$I$I$I,[192, 128, 192]));
osg.fillRect$I$I$I$I((this.xPix - (this.s/2|0) + 1), (this.ptY2), this.s - 2, this.ptY1 - this.ptY2);
if (this.color != null ) osg.setColor$java_awt_Color(this.color);
 else if (this.current > 0 ) osg.setColor$java_awt_Color($I$(1).blue);
 else osg.setColor$java_awt_Color($I$(1).red);
osg.fillOval$I$I$I$I((this.xPix - (this.s/2|0)), (this.ptY1 - (this.s/2|0)), this.s, this.s);
if (this.color != null ) osg.setColor$java_awt_Color(this.color);
 else if (this.current > 0 ) osg.setColor$java_awt_Color($I$(1).red);
 else osg.setColor$java_awt_Color($I$(1).blue);
osg.fillOval$I$I$I$I((this.xPix - (this.s/2|0)), (this.ptY2 - (this.s/2|0)), this.s, this.s);
if (this.label != null ) {
var oldFont=osg.getFont$();
osg.setFont$java_awt_Font(this.font);
osg.setColor$java_awt_Color($I$(1).white);
osg.drawString$S$I$I(this.label, this.xPix - 4, this.yPix + 5);
osg.setColor$java_awt_Color($I$(1).black);
osg.setFont$java_awt_Font(oldFont);
}});

Clazz.newMeth(C$, 'setShowF$Z', function (sf) {
;});

Clazz.newMeth(C$, 'setShowFComponents$Z', function (sfc) {
;});

Clazz.newMeth(C$, 'isInsidePix$I$I', function (x, y) {
if (!this.noDrag && (Math.abs(this.xPix - x) < this.s + 1) && (Math.abs(this.yPix - y) < this.s + 1)  ) return true;
if (!this.noOptionDrag && (Math.abs(this.xPix - x) < this.s + 1) && ((Math.abs(this.ptY2 - y) < this.s + 1) || (Math.abs(this.ptY1 - y) < this.s + 1) )  ) return true;
 else return false;
});

Clazz.newMeth(C$, 'isInsideWire$D$D$I', function (x, y, hs) {
var xpix=this.p.pixFromX$D(x);
var ypix=this.p.pixFromY$D(y);
if (this.getHotSpot$I$I(xpix, ypix) != hs) return false;
return this.isInsidePix$I$I(xpix, ypix);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (i, j) {
return this.isInsidePix$I$I(i, j);
});

Clazz.newMeth(C$, 'getHotSpot$I$I', function (x, y) {
if (!this.noOptionDrag && Math.abs(this.ptY2 - y) < this.s + 1 ) return 1;
 else if (!this.noOptionDrag && Math.abs(this.ptY1 - y) < this.s + 1 ) return -1;
 else return 0;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:45 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
