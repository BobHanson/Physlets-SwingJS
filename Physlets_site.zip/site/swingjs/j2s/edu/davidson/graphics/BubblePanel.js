(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[[0,'edu.davidson.graphics.Util','edu.davidson.graphics.BubblePanel','java.awt.Color','edu.davidson.tools.SClock','java.awt.Dimension']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "BubblePanel", null, 'java.awt.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.text=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (text) {
Clazz.super_(C$, this,1);
this.text=text;
this.setForeground$java_awt_Color($I$(3).black);
this.setBackground$java_awt_Color($I$(3).yellow);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var size=this.getSize$();
var fm=g.getFontMetrics$();
g.drawRect$I$I$I$I(0, 0, size.width - 1, size.height - 1);
g.drawString$S$I$I(this.text, 2, fm.getAscent$() + 2);
});

Clazz.newMeth(C$, 'getPreferredSize$', function () {
var vendor="unknown";
if (!$I$(4).isJS) {
vendor=System.getProperty$S("java.vendor");
}var g=this.getGraphics$();
if (g == null ) return Clazz.new_($I$(5).c$$I$I,[10, 10]);
var fm=g.getFontMetrics$();
var width=fm.stringWidth$S(this.text) + 4;
var height=fm.getHeight$() + 4;
if (width < 50) width=50;
if (!vendor.startsWith$S("Microsoft")) height=height + 15;
return Clazz.new_($I$(5).c$$I$I,[width, height]);
});

Clazz.newMeth(C$, 'setText$S', function (text) {
this.text=text;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:04 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
