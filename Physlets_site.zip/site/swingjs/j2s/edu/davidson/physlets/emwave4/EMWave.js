(function(){var P$=Clazz.newPackage("edu.davidson.physlets.emwave4"),I$=[['java.awt.Color','edu.davidson.physlets.emwave4.ThreeDPanel','java.awt.BorderLayout','edu.davidson.display.VerticalFlowLayout','edu.davidson.graphics.EtchedBorder','java.awt.Panel','edu.davidson.display.SSlider','edu.davidson.graphics.SPanel','java.awt.Label','Boolean','edu.davidson.physlets.emwave4.Figure','java.awt.Dimension','edu.davidson.physlets.emwave4.EMWave_this_componentAdapter','java.util.Locale','edu.davidson.physlets.emwave4.EMWave$1','edu.davidson.physlets.emwave4.EMWave$2','edu.davidson.physlets.emwave4.EMWave$3','edu.davidson.physlets.emwave4.EMWave_threeDView_mouseMotionAdapter','edu.davidson.physlets.emwave4.Wave','edu.davidson.physlets.emwave4.Plane','edu.davidson.physlets.emwave4.Axis3D','edu.davidson.physlets.emwave4.AxesLabel','edu.davidson.physlets.emwave4.Square','edu.davidson.physlets.emwave4.FilledSquare','edu.davidson.physlets.emwave4.LinearWave','edu.davidson.physlets.emwave4.CircularWaveRight','edu.davidson.physlets.emwave4.CircularWaveLeft','edu.davidson.physlets.emwave4.ParsedWave']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EMWave", null, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SStepable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.color = null;
this.colorDispenser = 0;
this.showControls = false;
this.wLineDensity = 0;
this.pixPerUnit = 0;
this.rotateZAxis = 0;
this.rotateYAxis = 0;
this.rotateXAxis = 0;
this.xPrevious = 0;
this.yPrevious = 0;
this.rotate = false;
this.orientation = 0;
this.fps = 0;
this.dz = 0;
this.threeDView = null;
this.borderLayout1 = null;
this.verticalFlowLayout1 = null;
this.sliderPanel = null;
this.panel1 = null;
this.alpha = null;
this.borderLayout2 = null;
this.panel2 = null;
this.panel3 = null;
this.theta = null;
this.phi = null;
this.borderLayout3 = null;
this.borderLayout4 = null;
this.panel4 = null;
this.label2 = null;
this.panel5 = null;
this.panel6 = null;
this.label3 = null;
this.label1 = null;
this.borderLayout5 = null;
this.borderLayout6 = null;
this.borderLayout7 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.color = (I$[1]||$incl$(1)).black;
this.colorDispenser = 0;
this.showControls = true;
this.wLineDensity = 2;
this.pixPerUnit = 10;
this.rotateZAxis = 0;
this.rotateYAxis = 0;
this.rotateXAxis = 0;
this.rotate = true;
this.orientation = 1;
this.fps = 20;
this.threeDView = Clazz.new_((I$[2]||$incl$(2)));
this.borderLayout1 = Clazz.new_((I$[3]||$incl$(3)));
this.verticalFlowLayout1 = Clazz.new_((I$[4]||$incl$(4)));
this.sliderPanel = Clazz.new_((I$[5]||$incl$(5)));
this.panel1 = Clazz.new_((I$[6]||$incl$(6)));
this.alpha = Clazz.new_((I$[7]||$incl$(7)));
this.borderLayout2 = Clazz.new_((I$[3]||$incl$(3)));
this.panel2 = Clazz.new_((I$[6]||$incl$(6)));
this.panel3 = Clazz.new_((I$[6]||$incl$(6)));
this.theta = Clazz.new_((I$[7]||$incl$(7)));
this.phi = Clazz.new_((I$[7]||$incl$(7)));
this.borderLayout3 = Clazz.new_((I$[3]||$incl$(3)));
this.borderLayout4 = Clazz.new_((I$[3]||$incl$(3)));
this.panel4 = Clazz.new_((I$[8]||$incl$(8)));
this.label2 = Clazz.new_((I$[9]||$incl$(9)));
this.panel5 = Clazz.new_((I$[8]||$incl$(8)));
this.panel6 = Clazz.new_((I$[8]||$incl$(8)));
this.label3 = Clazz.new_((I$[9]||$incl$(9)));
this.label1 = Clazz.new_((I$[9]||$incl$(9)));
this.borderLayout5 = Clazz.new_((I$[3]||$incl$(3)));
this.borderLayout6 = Clazz.new_((I$[3]||$incl$(3)));
this.borderLayout7 = Clazz.new_((I$[3]||$incl$(3)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.showControls = (I$[10]||$incl$(10)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.orientation = Integer.parseInt(this.getParameter$S$S("Orientation", "0"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.fps = Integer.parseInt(this.getParameter$S$S("framesPerSec", "20"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.fps = Integer.parseInt(this.getParameter$S$S("FPS", "20"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.dz = this.pixPerUnit * Double.$valueOf(this.getParameter$S$S("Translation", ".2")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.jbInit();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.sliderPanel.setVisible$Z(this.showControls);
if (this.orientation == 0) {
this.rotateZAxis = 0.7853981633974483;
this.rotateYAxis = 0;
this.rotateXAxis = 0.7853981633974483;
this.threeDView.setAngles$D$D$D(this.rotateZAxis, this.rotateYAxis, this.rotateXAxis);
}if (this.orientation == 1) {
this.rotateZAxis = 0.7853981633974483;
this.rotateYAxis = 0.7853981633974483;
this.rotateXAxis = 0;
this.threeDView.setAngles$D$D$D(this.rotateZAxis, this.rotateYAxis, this.rotateXAxis);
}(I$[11]||$incl$(11)).setOrigin$I$I((this.getSize().width/2|0), (this.getSize().height/2|0));
this.setRGB$I$I$I(0, 0, 0);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.setSize$java_awt_Dimension(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[600, 650]));
this.addComponentListener$java_awt_event_ComponentListener(Clazz.new_((I$[13]||$incl$(13)).c$$edu_davidson_physlets_emwave4_EMWave,[this]));
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.sliderPanel.setLayout$java_awt_LayoutManager(this.verticalFlowLayout1);
this.sliderPanel.setLocale$java_util_Locale((I$[14]||$incl$(14)).getDefault());
this.sliderPanel.setThickness$I(1);
this.alpha.setDMax$D(6.28);
this.alpha.addAdjustmentListener$java_awt_event_AdjustmentListener(((
(function(){var C$=Clazz.newClass(P$, "EMWave$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.AdjustmentListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['adjustmentValueChanged$java_awt_event_AdjustmentEvent','adjustmentValueChanged'], function (e) {
this.b$['edu.davidson.physlets.emwave4.EMWave'].alpha_adjustmentValueChanged$java_awt_event_AdjustmentEvent(e);
});
})()
), Clazz.new_((I$[15]||$incl$(15)).$init$, [this, null])));
this.alpha.setDValue$D(this.rotateYAxis);
this.alpha.setDMin$D(0);
this.panel1.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.theta.setDMax$D(6.28);
this.theta.addAdjustmentListener$java_awt_event_AdjustmentListener(((
(function(){var C$=Clazz.newClass(P$, "EMWave$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.AdjustmentListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['adjustmentValueChanged$java_awt_event_AdjustmentEvent','adjustmentValueChanged'], function (e) {
this.b$['edu.davidson.physlets.emwave4.EMWave'].theta_adjustmentValueChanged$java_awt_event_AdjustmentEvent(e);
});
})()
), Clazz.new_((I$[16]||$incl$(16)).$init$, [this, null])));
this.theta.setDValue$D(this.rotateZAxis);
this.theta.setDMin$D(0);
this.phi.setDMax$D(6.28);
this.phi.addAdjustmentListener$java_awt_event_AdjustmentListener(((
(function(){var C$=Clazz.newClass(P$, "EMWave$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.AdjustmentListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['adjustmentValueChanged$java_awt_event_AdjustmentEvent','adjustmentValueChanged'], function (e) {
this.b$['edu.davidson.physlets.emwave4.EMWave'].phi_adjustmentValueChanged$java_awt_event_AdjustmentEvent(e);
});
})()
), Clazz.new_((I$[17]||$incl$(17)).$init$, [this, null])));
this.phi.setDValue$D(this.rotateXAxis);
this.phi.setDMin$D(0);
this.panel3.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.panel2.setLayout$java_awt_LayoutManager(this.borderLayout4);
this.label2.setText$S("theta = ");
this.label2.setAlignment$I(2);
this.label3.setText$S("  phi = ");
this.label3.setAlignment$I(2);
this.label1.setAlignment$I(2);
this.label1.setText$S("alpha = ");
this.panel4.setMinimumSize$java_awt_Dimension(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[50, 20]));
this.panel4.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[50, 20]));
this.panel4.setLayout$java_awt_LayoutManager(this.borderLayout5);
this.panel5.setMinimumSize$java_awt_Dimension(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[50, 20]));
this.panel5.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[50, 20]));
this.panel5.setLayout$java_awt_LayoutManager(this.borderLayout6);
this.panel6.setMinimumSize$java_awt_Dimension(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[50, 20]));
this.panel6.setPreferredSize$java_awt_Dimension(Clazz.new_((I$[12]||$incl$(12)).c$$I$I,[50, 20]));
this.panel6.setLayout$java_awt_LayoutManager(this.borderLayout7);
this.add$java_awt_Component$O(this.threeDView, "Center");
this.add$java_awt_Component$O(this.sliderPanel, "South");
this.sliderPanel.add$java_awt_Component$O(this.panel3, null);
this.panel3.add$java_awt_Component$O(this.theta, "Center");
this.panel3.add$java_awt_Component$O(this.panel4, "West");
this.panel4.add$java_awt_Component$O(this.label2, "Center");
this.sliderPanel.add$java_awt_Component$O(this.panel2, null);
this.panel2.add$java_awt_Component$O(this.phi, "Center");
this.panel2.add$java_awt_Component$O(this.panel5, "West");
this.panel5.add$java_awt_Component$O(this.label3, "West");
this.sliderPanel.add$java_awt_Component$O(this.panel1, null);
this.panel1.add$java_awt_Component$O(this.alpha, "Center");
this.panel1.add$java_awt_Component$O(this.panel6, "West");
this.panel6.add$java_awt_Component$O(this.label1, "West");
this.clock.setFPS$D(this.fps);
this.clock.setDt$D(1);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
this.threeDView.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.threeDView.addMouseMotionListener$java_awt_event_MouseMotionListener(Clazz.new_((I$[18]||$incl$(18)).c$$edu_davidson_physlets_emwave4_EMWave,[this]));
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Applet Information";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show sliders"]), Clazz.array(java.lang.String, -1, ["Animate", "boolean", "animate figures"]), Clazz.array(java.lang.String, -1, ["Orientation", "int", "orientation of figure"]), Clazz.array(java.lang.String, -1, ["fps", "int", "frames per second"]), Clazz.array(java.lang.String, -1, ["Translation", "double", "translation distance of wave"])]);
return pinfo;
});

Clazz.newMeth(C$, 'start', function () {
this.threeDView.paint();
this.clock.startClock();
});

Clazz.newMeth(C$, 'forward', function () {
this.threeDView.paint();
this.clock.startClock();
});

Clazz.newMeth(C$, 'stop', function () {
this.clock.stopClock();
});

Clazz.newMeth(C$, 'pause', function () {
this.clock.stopClock();
});

Clazz.newMeth(C$, 'destroy', function () {
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
this.threeDView.translate$D(this.dz);
});

Clazz.newMeth(C$, ['setOrientation$D$D$D','setOrientation'], function (t, a, p) {
this.rotateZAxis = t;
this.rotateYAxis = a;
this.rotateXAxis = p;
this.threeDView.setAngles$D$D$D(this.rotateZAxis, this.rotateYAxis, this.rotateXAxis);
});

Clazz.newMeth(C$, ['setOrigin$I$I','setOrigin'], function (x, y) {
(I$[11]||$incl$(11)).setOrigin$I$I(x, y);
});

Clazz.newMeth(C$, ['setWaveLineDensity$I','setWaveLineDensity'], function (d) {
this.wLineDensity = d;
(I$[19]||$incl$(19)).setLineDensity$I(d);
});

Clazz.newMeth(C$, ['setPlaneLineDensity$I','setPlaneLineDensity'], function (d) {
(I$[20]||$incl$(20)).setLineDensity$I(d);
});

Clazz.newMeth(C$, ['setPixPerUnit$I','setPixPerUnit'], function (ppu) {
this.pixPerUnit = ppu;
});

Clazz.newMeth(C$, ['setWavelength$D','setWavelength'], function (l) {
(I$[19]||$incl$(19)).setWavelength$D(l * this.pixPerUnit);
});

Clazz.newMeth(C$, ['setRGB$I$I$I','setRGB'], function (r, g, b) {
this.color = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[Math.min(255, Math.abs(r)), Math.min(255, Math.abs(g)), Math.min(255, Math.abs(b))]);
var f = this.threeDView.getGraphics();
if (f == null ) {
return;
}f.setColor$java_awt_Color(this.color);
f.dispose();
});

Clazz.newMeth(C$, ['createAxes$D$D$D$D','createAxes'], function (x, y, z, s) {
var axes = Clazz.new_((I$[21]||$incl$(21)).c$$I$I$I$D$java_awt_Color,[((x * this.pixPerUnit)|0), ((y * this.pixPerUnit)|0), ((z * this.pixPerUnit)|0), s * this.pixPerUnit, this.color]);
this.threeDView.addFigure$edu_davidson_physlets_emwave4_Figure(axes);
var labels = Clazz.new_((I$[22]||$incl$(22)).c$$I$I$I$D$java_awt_Color,[(x|0) * this.pixPerUnit, (y|0) * this.pixPerUnit, ((z * this.pixPerUnit)|0), s * this.pixPerUnit, this.color]);
this.threeDView.addFigure$edu_davidson_physlets_emwave4_Figure(labels);
});

Clazz.newMeth(C$, ['createSquare$D$D','createSquare'], function (z, s) {
var base = Clazz.new_((I$[23]||$incl$(23)).c$$D$D$java_awt_Color,[z * this.pixPerUnit, s * this.pixPerUnit, this.color]);
this.threeDView.addFigure$edu_davidson_physlets_emwave4_Figure(base);
});

Clazz.newMeth(C$, ['createFilledSquare$D$D','createFilledSquare'], function (z, s) {
var base = Clazz.new_((I$[24]||$incl$(24)).c$$D$D$java_awt_Color,[z * this.pixPerUnit, s * this.pixPerUnit, this.color]);
this.threeDView.addFigure$edu_davidson_physlets_emwave4_Figure(base);
});

Clazz.newMeth(C$, ['createLinear$D$D$D$D$D','createLinear'], function (z1, z2, a, ph, p) {
var linear = Clazz.new_((I$[25]||$incl$(25)).c$$D$D$D$D$D$java_awt_Color,[z1 * this.pixPerUnit, z2 * this.pixPerUnit, a * this.pixPerUnit, ph, p, this.color]);
this.threeDView.addFigure$edu_davidson_physlets_emwave4_Figure(linear);
});

Clazz.newMeth(C$, ['createCircularRight$D$D$D$D','createCircularRight'], function (z1, z2, a, ph) {
var circular = Clazz.new_((I$[26]||$incl$(26)).c$$D$D$D$D$java_awt_Color,[z1 * this.pixPerUnit, z2 * this.pixPerUnit, a * this.pixPerUnit, ph, this.color]);
this.threeDView.addFigure$edu_davidson_physlets_emwave4_Figure(circular);
});

Clazz.newMeth(C$, ['createCircularLeft$D$D$D$D','createCircularLeft'], function (z1, z2, a, ph) {
var circular = Clazz.new_((I$[27]||$incl$(27)).c$$D$D$D$D$java_awt_Color,[z1 * this.pixPerUnit, z2 * this.pixPerUnit, a * this.pixPerUnit, ph, this.color]);
this.threeDView.addFigure$edu_davidson_physlets_emwave4_Figure(circular);
});

Clazz.newMeth(C$, ['createPlane$D$D$D$D','createPlane'], function (z1, length, width, p) {
var plate = Clazz.new_((I$[20]||$incl$(20)).c$$D$D$D$D$java_awt_Color,[z1 * this.pixPerUnit, length * this.pixPerUnit, width * this.pixPerUnit, p, this.color]);
this.threeDView.addFigure$edu_davidson_physlets_emwave4_Figure(plate);
});

Clazz.newMeth(C$, ['createParsed$S$D$D$D','createParsed'], function (s, z1, z2, p) {
var parsed = Clazz.new_((I$[28]||$incl$(28)).c$$S$D$D$D$D$java_awt_Color,[s, z1 * this.pixPerUnit, z2 * this.pixPerUnit, this.pixPerUnit, p, this.color]);
this.threeDView.addFigure$edu_davidson_physlets_emwave4_Figure(parsed);
});

Clazz.newMeth(C$, 'deleteAll', function () {
this.threeDView.clear();
});

Clazz.newMeth(C$, 'theta_adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
this.threeDView.setTheta$D(this.theta.getDValue());
});

Clazz.newMeth(C$, 'alpha_adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
this.threeDView.setAlpha$D(this.alpha.getDValue());
});

Clazz.newMeth(C$, 'phi_adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
this.threeDView.setPhi$D(this.phi.getDValue());
});

Clazz.newMeth(C$, 'graph_mouseClicked$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'clear_mouseClicked$java_awt_event_MouseEvent', function (e) {
this.deleteAll();
});

Clazz.newMeth(C$, 'linearWave_mouseClicked$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'linearPol_mouseClicked$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'circular_mouseClicked$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'circularPol_mouseClicked$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'plane_mouseClicked$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'threeDView_mouseDragged$java_awt_event_MouseEvent', function (e) {
var x = e.getX();
var y = e.getY();
if (this.orientation == 0) {
this.threeDView.setAlpha$D(0);
if (x < this.xPrevious) {
this.threeDView.setTheta$D(this.rotateZAxis += 0.08);
}if (x > this.xPrevious) {
this.threeDView.setTheta$D(this.rotateZAxis -= 0.08);
}if (y < this.yPrevious) {
if (this.rotateXAxis <= 1.5 ) {
this.threeDView.setPhi$D(this.rotateXAxis += 0.08);
}}if (y > this.yPrevious) {
if (this.rotateXAxis >= 0 ) {
this.threeDView.setPhi$D(this.rotateXAxis -= 0.08);
}}}if (this.orientation == 1) {
this.threeDView.setPhi$D(0);
if (y < this.yPrevious) {
if (this.rotateYAxis > 0 ) {
this.threeDView.setTheta$D(this.rotateZAxis -= 0.08);
} else {
this.threeDView.setTheta$D(this.rotateZAxis += 0.08);
}}if (y > this.yPrevious) {
if (this.rotateYAxis > 0 ) {
this.threeDView.setTheta$D(this.rotateZAxis += 0.08);
} else {
this.threeDView.setTheta$D(this.rotateZAxis -= 0.08);
}}if (x < this.xPrevious) {
if (this.rotateYAxis <= 1.5707963267948966 ) {
this.threeDView.setAlpha$D(this.rotateYAxis += 0.08);
}}if (x > this.xPrevious) {
if (this.rotateYAxis >= -1.5707963267948966 ) {
this.threeDView.setAlpha$D(this.rotateYAxis -= 0.08);
}}}this.xPrevious = x;
this.yPrevious = y;
});

Clazz.newMeth(C$, 'this_componentResized$java_awt_event_ComponentEvent', function (e) {
(I$[11]||$incl$(11)).setOrigin$I$I((this.getSize().width/2|0), (this.getSize().height/2|0));
});
})();
//Created 2018-02-25 19:20:27
