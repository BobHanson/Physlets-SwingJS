(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Resistor", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$S', function (circuit, v, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$S.apply(this, [circuit, r, c, t]);
C$.$init$.apply(this);
this.value = v;
this.unity = "Ohm";
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$I$S', function (circuit, v, pol, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circuit, pol, r, c, t]);
C$.$init$.apply(this);
this.value = v;
this.unity = "Ohm";
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit', function (circuit) {
C$.superclazz.c$$circuitsimulator_Circuit.apply(this, [circuit]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'impedance', function () {
return this.value;
});

Clazz.newMeth(C$, 'getStringAdditions', function () {
return ",r=" + Double.toString(this.value);
});

Clazz.newMeth(C$, 'set$S', function (list) {
var ret = C$.superclazz.prototype.set$S.apply(this, [list]);
if ((I$[1]||$incl$(1)).parameterExist$S$S(list, "r=")) this.value = (I$[1]||$incl$(1)).getParam$S$S(list, "r=");
return ret;
});
})();
//Created 2018-02-06 06:55:34
