(function(){var P$=Clazz.newPackage("eField4"),I$=[['eField4.OdeCanvas','edu.davidson.graphics.EtchedBorder','a2s.Button','java.awt.FlowLayout','java.awt.BorderLayout','a2s.TextField','a2s.Checkbox','Boolean','java.awt.Dimension','eField4.EField_pauseBtn_actionAdapter','eField4.EField_reverseBtn_actionAdapter','eField4.EField_stepBackBtn_actionAdapter','eField4.EField_stepForwardBtn_actionAdapter','java.awt.Color','eField4.EField_newBtn_actionAdapter','eField4.EField_clearBtn_actionAdapter','java.awt.Font','eField4.EField_negBtn_actionAdapter','eField4.EField_chargeBox_itemAdapter','eField4.EField_labelBox_itemAdapter','eField4.EField_fieldVectorsBox_itemAdapter','eField4.EField_contoursBox_itemAdapter','eField4.EField_posBtn_actionAdapter','eField4.EField_potBtn_actionAdapter','eField4.EField_resetBtn_actionAdapter','eField4.EField_playBtn_actionAdapter','edu.davidson.tools.SUtil','eField4.Box','eField4.DrawRectangle','eField4.Circle','eField4.CursorThing','eField4.Shell','eField4.Arrow','eField4.TextThing','eField4.CaptionThing','eField4.ConnectorLine','eField4.ConnectorSpring','eField4.LineAnchor','java.net.URL','eField4.SpringAnchor','java.util.StringTokenizer','edu.davidson.display.Format']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EField", null, 'edu.davidson.tools.SApplet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.button_start = null;
this.button_stop = null;
this.button_test = null;
this.button_clear = null;
this.button_reset = null;
this.button_reverse = null;
this.button_forward = null;
this.button_back = null;
this.button_potential = null;
this.label_collision = null;
this.label_charge = null;
this.label_labels = null;
this.label_vectors = null;
this.label_contours = null;
this.label_time = null;
this.label_volt = null;
this.label_volt_undefined = null;
this.label_field = null;
this.label_field_undefined = null;
this.label_force = null;
this.label_force_undefined = null;
this.label_calculating = null;
this.showControls = false;
this.showContours = false;
this.showFieldLines = false;
this.showLabels = false;
this.showPoles = false;
this.showFieldVectors = false;
this.showForce = false;
this.showVelocity = false;
this.pixPerUnit = 0;
this.dt = 0;
this.gridUnit = 0;
this.potStr = null;
this.rangeStr = null;
this.gridSize = 0;
this.noDrag = false;
this.hideCharge = false;
this.pointChargeMode = false;
this.odeCanvas = null;
this.bevelPanel1 = null;
this.playBtn = null;
this.pauseBtn = null;
this.reverseBtn = null;
this.stepBackBtn = null;
this.stepForwardBtn = null;
this.resetBtn = null;
this.flowLayout1 = null;
this.borderLayout1 = null;
this.bevelPanel2 = null;
this.bevelPanel4 = null;
this.newBtn = null;
this.clearBtn = null;
this.flowLayout3 = null;
this.borderLayout2 = null;
this.bevelPanel5 = null;
this.funcField = null;
this.borderLayout3 = null;
this.potBtn = null;
this.negBtn = null;
this.posBtn = null;
this.bevelPanel3 = null;
this.chargeBox = null;
this.labelBox = null;
this.flowLayout2 = null;
this.fieldVectorsBox = null;
this.contoursBox = null;
this.chargeColor = null;
this.chargeLabel = null;
this.chargeTrail = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.button_start = "Play";
this.button_stop = "Pause";
this.button_test = "Test";
this.button_clear = "Clear";
this.button_reset = "Reset";
this.button_reverse = "Reverse";
this.button_forward = "Step>>";
this.button_back = "<<Step";
this.button_potential = "U ( x, y )";
this.label_collision = "collision";
this.label_charge = "Charge";
this.label_labels = "Labels";
this.label_vectors = "Field Vec.";
this.label_contours = "Contours";
this.label_time = "Time: ";
this.label_volt = "V=";
this.label_volt_undefined = "V=Undefined";
this.label_field = "|E|=";
this.label_field_undefined = "E=Undefined";
this.label_force = "|F|=";
this.label_force_undefined = "F=Undefined";
this.label_calculating = "Calculating. Please wait.";
this.showForce = false;
this.showVelocity = false;
this.noDrag = true;
this.hideCharge = false;
this.pointChargeMode = true;
this.odeCanvas = Clazz.new_((I$[1]||$incl$(1)).c$$eField4_EField,[this]);
this.bevelPanel1 = Clazz.new_((I$[2]||$incl$(2)));
this.playBtn = Clazz.new_((I$[3]||$incl$(3)));
this.pauseBtn = Clazz.new_((I$[3]||$incl$(3)));
this.reverseBtn = Clazz.new_((I$[3]||$incl$(3)));
this.stepBackBtn = Clazz.new_((I$[3]||$incl$(3)));
this.stepForwardBtn = Clazz.new_((I$[3]||$incl$(3)));
this.resetBtn = Clazz.new_((I$[3]||$incl$(3)));
this.flowLayout1 = Clazz.new_((I$[4]||$incl$(4)));
this.borderLayout1 = Clazz.new_((I$[5]||$incl$(5)));
this.bevelPanel2 = Clazz.new_((I$[2]||$incl$(2)));
this.bevelPanel4 = Clazz.new_((I$[2]||$incl$(2)));
this.newBtn = Clazz.new_((I$[3]||$incl$(3)));
this.clearBtn = Clazz.new_((I$[3]||$incl$(3)));
this.flowLayout3 = Clazz.new_((I$[4]||$incl$(4)));
this.borderLayout2 = Clazz.new_((I$[5]||$incl$(5)));
this.bevelPanel5 = Clazz.new_((I$[2]||$incl$(2)));
this.funcField = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout3 = Clazz.new_((I$[5]||$incl$(5)));
this.potBtn = Clazz.new_((I$[3]||$incl$(3)));
this.negBtn = Clazz.new_((I$[3]||$incl$(3)));
this.posBtn = Clazz.new_((I$[3]||$incl$(3)));
this.bevelPanel3 = Clazz.new_((I$[2]||$incl$(2)));
this.chargeBox = Clazz.new_((I$[7]||$incl$(7)));
this.labelBox = Clazz.new_((I$[7]||$incl$(7)));
this.flowLayout2 = Clazz.new_((I$[4]||$incl$(4)));
this.fieldVectorsBox = Clazz.new_((I$[7]||$incl$(7)));
this.contoursBox = Clazz.new_((I$[7]||$incl$(7)));
this.chargeColor = null;
this.chargeLabel = null;
this.chargeTrail = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'setResources', function () {
this.button_start = this.localProperties.getProperty$S$S("button.start", this.button_start);
this.button_stop = this.localProperties.getProperty$S$S("button.stop", this.button_stop);
this.button_reverse = this.localProperties.getProperty$S$S("button.reverse", this.button_reverse);
this.button_reset = this.localProperties.getProperty$S$S("button.reset", this.button_reset);
this.button_forward = this.localProperties.getProperty$S$S("button.forward", this.button_forward);
this.button_back = this.localProperties.getProperty$S$S("button.back", this.button_back);
this.button_test = this.localProperties.getProperty$S$S("button.test", this.button_test);
this.button_clear = this.localProperties.getProperty$S$S("button.clear", this.button_clear);
this.button_potential = this.localProperties.getProperty$S$S("button.potential", this.button_potential);
this.label_collision = this.localProperties.getProperty$S$S("label.collision", this.label_collision);
this.label_charge = this.localProperties.getProperty$S$S("label.charge", this.label_charge);
this.label_labels = this.localProperties.getProperty$S$S("label.labels", this.label_labels);
this.label_vectors = this.localProperties.getProperty$S$S("label.vectors", this.label_vectors);
this.label_contours = this.localProperties.getProperty$S$S("label.contours", this.label_contours);
this.label_time = this.localProperties.getProperty$S$S("label.time", this.label_time);
this.label_volt = this.localProperties.getProperty$S$S("label.volt", this.label_volt);
this.label_volt_undefined = this.localProperties.getProperty$S$S("label.volt_undefined", this.label_volt_undefined);
this.label_field = this.localProperties.getProperty$S$S("label.field", this.label_field);
this.label_field_undefined = this.localProperties.getProperty$S$S("label.field_undefined", this.label_field_undefined);
this.label_force = this.localProperties.getProperty$S$S("label.force", this.label_force);
this.label_force_undefined = this.localProperties.getProperty$S$S("label.force_undefined", this.label_force_undefined);
this.label_calculating = this.localProperties.getProperty$S$S("label.calculating", this.label_calculating);
});

Clazz.newMeth(C$, 'init', function () {
var fps = 10;
this.initResources$S(null);
try {
fps = Double.$valueOf(this.getParameter$S$S("FPS", "10")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls = (I$[8]||$incl$(8)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showContours = (I$[8]||$incl$(8)).$valueOf(this.getParameter$S$S("ShowContours", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showPoles = (I$[8]||$incl$(8)).$valueOf(this.getParameter$S$S("ShowCharge", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showLabels = (I$[8]||$incl$(8)).$valueOf(this.getParameter$S$S("ShowLabels", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showFieldLines = (I$[8]||$incl$(8)).$valueOf(this.getParameter$S$S("ShowFieldLines", "false")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showFieldVectors = (I$[8]||$incl$(8)).$valueOf(this.getParameter$S$S("ShowFieldVectors", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.pointChargeMode = (I$[8]||$incl$(8)).$valueOf(this.getParameter$S$S("PointChargeMode", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.pixPerUnit = Double.$valueOf(this.getParameter$S$S("PixPerUnit", "10")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.dt = Double.$valueOf(this.getParameter$S$S("dt", "0.1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.gridUnit = Double.$valueOf(this.getParameter$S$S("GridUnit", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.potStr = this.getParameter$S$S("Potential", "0");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.rangeStr = this.getParameter$S$S("Range", "-1,1,-1,1");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.gridSize = Integer.parseInt(this.getParameter$S$S("GridSize", "64"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.jbInit();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.odeCanvas.setGridSize$I(this.gridSize);
this.odeCanvas.setShowContours$Z(this.showContours);
this.contoursBox.setState$Z(this.showContours);
this.odeCanvas.pointChargeMode = this.pointChargeMode;
this.odeCanvas.setShowFieldLines$Z(this.showFieldLines);
this.odeCanvas.setShowFieldVectors$Z(this.showFieldVectors);
this.fieldVectorsBox.setState$Z(this.showFieldVectors);
this.odeCanvas.setShowPoles$Z(this.showPoles);
this.chargeBox.setState$Z(this.showPoles);
this.odeCanvas.setShowLabels$Z(this.showLabels);
this.labelBox.setState$Z(this.showLabels);
this.odeCanvas.setRange$S(this.rangeStr);
this.odeCanvas.setPotStr$S(this.potStr);
this.funcField.setText$S(this.potStr);
this.setRunningID$O(this);
this.clock.addClockListener$edu_davidson_tools_SStepable(this.odeCanvas);
this.clock.setDt$D(this.dt);
this.clock.setFPS$D((fps|0));
if (this.showControls) {
this.odeCanvas.setShowVOnDrag$Z(true);
this.odeCanvas.setShowEOnDrag$Z(true);
this.noDrag = false;
}});

Clazz.newMeth(C$, 'jbInit', function () {
this.bevelPanel1.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.setSize$java_awt_Dimension(Clazz.new_((I$[9]||$incl$(9)).c$$I$I,[488, 491]));
this.playBtn.setLabel$S(this.button_start);
this.pauseBtn.setLabel$S(this.button_stop);
this.pauseBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[10]||$incl$(10)).c$$eField4_EField,[this]));
this.reverseBtn.setLabel$S(this.button_reverse);
this.reverseBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[11]||$incl$(11)).c$$eField4_EField,[this]));
this.stepBackBtn.setLabel$S(this.button_back);
this.stepBackBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[12]||$incl$(12)).c$$eField4_EField,[this]));
this.stepForwardBtn.setLabel$S(this.button_forward);
this.stepForwardBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[13]||$incl$(13)).c$$eField4_EField,[this]));
this.resetBtn.setLabel$S(this.button_reset);
this.bevelPanel2.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.bevelPanel2.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
this.bevelPanel4.setLayout$java_awt_LayoutManager(this.flowLayout3);
this.bevelPanel4.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
this.newBtn.setLabel$S(this.button_test);
this.newBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[15]||$incl$(15)).c$$eField4_EField,[this]));
this.clearBtn.setLabel$S(this.button_clear);
this.clearBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[16]||$incl$(16)).c$$eField4_EField,[this]));
this.bevelPanel5.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
this.borderLayout3.setHgap$I(5);
this.potBtn.setFont$java_awt_Font(Clazz.new_((I$[17]||$incl$(17)).c$$S$I$I,["Dialog", 1, 12]));
this.potBtn.setLabel$S(this.button_potential);
this.negBtn.setLabel$S("-");
this.negBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[18]||$incl$(18)).c$$eField4_EField,[this]));
this.posBtn.setLabel$S("+");
this.bevelPanel3.setLayout$java_awt_LayoutManager(this.flowLayout2);
this.chargeBox.setLabel$S(this.label_charge);
this.chargeBox.addItemListener$java_awt_event_ItemListener(Clazz.new_((I$[19]||$incl$(19)).c$$eField4_EField,[this]));
this.labelBox.setLabel$S(this.label_labels);
this.labelBox.addItemListener$java_awt_event_ItemListener(Clazz.new_((I$[20]||$incl$(20)).c$$eField4_EField,[this]));
this.fieldVectorsBox.setLabel$S(this.label_vectors);
this.fieldVectorsBox.addItemListener$java_awt_event_ItemListener(Clazz.new_((I$[21]||$incl$(21)).c$$eField4_EField,[this]));
this.contoursBox.setLabel$S(this.label_contours);
this.contoursBox.addItemListener$java_awt_event_ItemListener(Clazz.new_((I$[22]||$incl$(22)).c$$eField4_EField,[this]));
this.posBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[23]||$incl$(23)).c$$eField4_EField,[this]));
this.potBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[24]||$incl$(24)).c$$eField4_EField,[this]));
this.bevelPanel5.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.resetBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[25]||$incl$(25)).c$$eField4_EField,[this]));
this.playBtn.addActionListener$java_awt_event_ActionListener(Clazz.new_((I$[26]||$incl$(26)).c$$eField4_EField,[this]));
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.add$java_awt_Component$O(this.odeCanvas, "Center");
if (this.showControls) this.add$java_awt_Component$O(this.bevelPanel1, "South");
this.bevelPanel1.add$java_awt_Component$O(this.playBtn, null);
this.bevelPanel1.add$java_awt_Component$O(this.pauseBtn, null);
this.bevelPanel1.add$java_awt_Component$O(this.reverseBtn, null);
this.bevelPanel1.add$java_awt_Component$O(this.stepBackBtn, null);
this.bevelPanel1.add$java_awt_Component$O(this.stepForwardBtn, null);
this.bevelPanel1.add$java_awt_Component$O(this.resetBtn, null);
this.bevelPanel1.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
if (this.showControls) this.add$java_awt_Component$O(this.bevelPanel2, "North");
this.bevelPanel2.add$java_awt_Component$O(this.bevelPanel4, "East");
this.bevelPanel4.add$java_awt_Component$O(this.posBtn, null);
this.bevelPanel4.add$java_awt_Component$O(this.negBtn, null);
this.bevelPanel4.add$java_awt_Component$O(this.newBtn, null);
this.bevelPanel4.add$java_awt_Component$O(this.clearBtn, null);
this.bevelPanel2.add$java_awt_Component$O(this.bevelPanel5, "Center");
this.bevelPanel5.add$java_awt_Component$O(this.funcField, "Center");
this.bevelPanel5.add$java_awt_Component$O(this.potBtn, "West");
this.bevelPanel2.add$java_awt_Component$O(this.bevelPanel3, "South");
this.bevelPanel3.add$java_awt_Component$O(this.contoursBox, null);
this.bevelPanel3.add$java_awt_Component$O(this.fieldVectorsBox, null);
this.bevelPanel3.add$java_awt_Component$O(this.chargeBox, null);
this.bevelPanel3.add$java_awt_Component$O(this.labelBox, null);
this.bevelPanel3.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
});

Clazz.newMeth(C$, 'stoppingClock', function () {
this.odeCanvas.setMessage$S(this.oneShotMsg);
});

Clazz.newMeth(C$, 'cyclingClock', function () {
this.clock.setTime$D(0);
this.odeCanvas.resetTime();
this.clearAllData();
});

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.firstTime) return 0;
 else return C$.superclazz.prototype.getAppletCount.apply(this, []);
});

Clazz.newMeth(C$, 'start', function () {
if (this.firstTime) {
this.firstTime = false;
}C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'stop', function () {
C$.superclazz.prototype.stop.apply(this, []);
});

Clazz.newMeth(C$, 'destroy', function () {
this.destroyed = true;
this.setAutoRefresh$Z(false);
this.clock.stopClock();
this.odeCanvas.destroy();
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "EField written by W. Christian.  Email:wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getPhysletCanvas', function () {
return this.odeCanvas;
});

Clazz.newMeth(C$, 'getGraphID', function () {
return this.odeCanvas.contour.hashCode();
});

Clazz.newMeth(C$, 'getCollisionID', function () {
return this.odeCanvas.getCollisionThing().hashCode();
});

Clazz.newMeth(C$, ['getSeriesID$I','getSeriesID'], function (sid) {
return this.odeCanvas.contour.getIDFromSID$I(sid);
});

Clazz.newMeth(C$, ['setSeriesStyle$I$Z$I','setSeriesStyle'], function (id, conPts, m) {
this.odeCanvas.contour.setSeriesStyle$I$Z$I(id, conPts, m);
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (s) {
this.odeCanvas.contour.deleteSeries$I(s);
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (s) {
this.odeCanvas.contour.clearSeriesData$I(s);
});

Clazz.newMeth(C$, ['getX$I','getX'], function (id) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return 0;
return t.getX();
});

Clazz.newMeth(C$, ['getY$I','getY'], function (id) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return 0;
return t.getY();
});

Clazz.newMeth(C$, ['getVX$I','getVX'], function (id) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return 0;
return t.getVX();
});

Clazz.newMeth(C$, ['getVY$I','getVY'], function (id) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return 0;
return t.getVY();
});

Clazz.newMeth(C$, 'getTime', function () {
return this.odeCanvas.time;
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["FPS", "double", "Frames per Second"]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show controls at bottom of applet."]), Clazz.array(java.lang.String, -1, ["PixPerUnit", "double", "Pixels per unit scale factor."]), Clazz.array(java.lang.String, -1, ["dt", "double", "TimeStep"]), Clazz.array(java.lang.String, -1, ["GridUnit", "double", "Grid Unit"]), Clazz.array(java.lang.String, -1, ["Potential", "String", "Potential U(x,y)"]), Clazz.array(java.lang.String, -1, ["Range", "String", "xmin, xmax, ymin, ymax"]), Clazz.array(java.lang.String, -1, ["GridSize", "int", "Grid Size"])]);
return pinfo;
});

Clazz.newMeth(C$, 'reverseBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.reverse();
});

Clazz.newMeth(C$, 'forwardBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.forward();
});

Clazz.newMeth(C$, 'stepBackBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.stepBack();
});

Clazz.newMeth(C$, 'stepForwardBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.stepForward();
});

Clazz.newMeth(C$, ['addObject$S$S','addObject'], function (name, parList) {
if (this.destroyed) return 0;
var t = null;
var x = 0;
var y = 0;
var width = 20;
var height = 20;
var r = 20;
var mass = 1;
if (parList == null ) parList = "";
name = name.toLowerCase().trim();
name = (I$[27]||$incl$(27)).removeWhitespace$S(name);
var parList2 = parList.trim();
;parList = (I$[27]||$incl$(27)).removeWhitespace$S(parList);
if (name.equals$O("box")) {
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "w=")) width = ((I$[27]||$incl$(27)).getParam$S$S(parList, "w=")|0);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "h=")) height = ((I$[27]||$incl$(27)).getParam$S$S(parList, "h=")|0);
t = Clazz.new_((I$[28]||$incl$(28)).c$$eField4_OdeCanvas$D$D$I$I,[this.odeCanvas, x, y, width, height]);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "m=")) mass = (I$[27]||$incl$(27)).getParam$S$S(parList, "m=");
if (mass != 1 ) t.mass = mass;
} else if (name.equals$O("rectangle")) {
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "w=")) width = ((I$[27]||$incl$(27)).getParam$S$S(parList, "w=")|0);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "h=")) height = ((I$[27]||$incl$(27)).getParam$S$S(parList, "h=")|0);
t = Clazz.new_((I$[29]||$incl$(29)).c$$eField4_OdeCanvas$D$D$I$I,[this.odeCanvas, x, y, width, height]);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "m=")) mass = (I$[27]||$incl$(27)).getParam$S$S(parList, "m=");
if (mass != 1 ) t.mass = mass;
} else if (name.equals$O("circle")) {
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "r=")) r = ((I$[27]||$incl$(27)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[30]||$incl$(30)).c$$eField4_OdeCanvas$D$D$I,[this.odeCanvas, x, y, r]);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "m=")) mass = (I$[27]||$incl$(27)).getParam$S$S(parList, "m=");
if (mass != 1 ) t.mass = mass;
} else if (name.equals$O("cursor")) {
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "r=")) r = ((I$[27]||$incl$(27)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[31]||$incl$(31)).c$$eField4_OdeCanvas$I$D$D,[this.odeCanvas, 2 * r + 1, x, y]);
} else if (name.equals$O("shell")) {
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "r=")) r = ((I$[27]||$incl$(27)).getParam$S$S(parList, "r=")|0);
t = Clazz.new_((I$[32]||$incl$(32)).c$$eField4_OdeCanvas$D$D$I,[this.odeCanvas, x, y, r]);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "m=")) mass = (I$[27]||$incl$(27)).getParam$S$S(parList, "m=");
if (mass != 1 ) t.mass = mass;
} else if (name.equals$O("arrow")) {
var horz = "1";
var vert = "1";
var s = 4;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "h=")) horz = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "h=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "v=")) vert = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "v=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "s=")) s = ((I$[27]||$incl$(27)).getParam$S$S(parList, "s=")|0);
t = Clazz.new_((I$[33]||$incl$(33)).c$$eField4_OdeCanvas$I$S$S$D$D,[this.odeCanvas, s, horz, vert, x, y]);
} else if (name.equals$O("line")) {
var horz = "1";
var vert = "1";
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "h=")) horz = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "h=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "v=")) vert = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "v=");
t = Clazz.new_((I$[33]||$incl$(33)).c$$eField4_OdeCanvas$I$S$S$D$D,[this.odeCanvas, 0, horz, vert, x, y]);
} else if (name.equals$O("text")) {
var txt = "";
var calc = null;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "txt=")) txt = (I$[27]||$incl$(27)).getParamStr$S$S(parList2, "txt=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "text=")) txt = (I$[27]||$incl$(27)).getParamStr$S$S(parList2, "text=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "calc=")) calc = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "calc=");
t = Clazz.new_((I$[34]||$incl$(34)).c$$eField4_OdeCanvas$S$S$D$D,[this.odeCanvas, txt, calc, x, y]);
} else if (name.equals$O("caption")) {
var txt = "";
var calc = null;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "txt=")) txt = (I$[27]||$incl$(27)).getParamStr$S$S(parList2, "txt=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "text=")) txt = (I$[27]||$incl$(27)).getParamStr$S$S(parList2, "text=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "calc=")) calc = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "calc=");
t = Clazz.new_((I$[35]||$incl$(35)).c$$eField4_OdeCanvas$S$S$D$D,[this.odeCanvas, txt, calc, x, y]);
} else if (name.equals$O("connectorline")) {
var id1 = 0;
var id2 = 0;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "id1=")) id1 = ((I$[27]||$incl$(27)).getParam$S$S(parList, "id1=")|0);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "id2=")) id2 = ((I$[27]||$incl$(27)).getParam$S$S(parList, "id2=")|0);
var t1 = this.odeCanvas.getThing$I(id1);
var t2 = this.odeCanvas.getThing$I(id2);
t = Clazz.new_((I$[36]||$incl$(36)).c$$eField4_OdeCanvas$eField4_Thing$eField4_Thing,[this.odeCanvas, t1, t2]);
} else if (name.equals$O("connectorspring")) {
var id1 = 0;
var id2 = 0;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "id1=")) id1 = ((I$[27]||$incl$(27)).getParam$S$S(parList, "id1=")|0);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "id2=")) id2 = ((I$[27]||$incl$(27)).getParam$S$S(parList, "id2=")|0);
var t1 = this.odeCanvas.getThing$I(id1);
var t2 = this.odeCanvas.getThing$I(id2);
t = Clazz.new_((I$[37]||$incl$(37)).c$$eField4_OdeCanvas$eField4_Thing$eField4_Thing,[this.odeCanvas, t1, t2]);
} else if (name.equals$O("charge")) {
var q = 1;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "q=")) q = (I$[27]||$incl$(27)).getParam$S$S(parList, "q=");
r = 9;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "r=")) r = ((I$[27]||$incl$(27)).getParam$S$S(parList, "r=")|0);
t = this.odeCanvas.addPole$D$D$D(x, y, q);
t.setNoDrag$Z(this.noDrag);
t.setHideThing$Z(this.hideCharge);
t.setShowFVector$Z(this.showForce);
t.showFOnDrag = this.showForce;
t.showFOnDrag = this.showForce;
t.setSize$I(r);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "m=")) mass = (I$[27]||$incl$(27)).getParam$S$S(parList, "m=");
if (mass != 1 ) t.mass = mass;
if (this.chargeLabel != null ) t.setLabel$S(this.chargeLabel);
if (this.chargeColor != null ) t.setColor$java_awt_Color(this.chargeColor);
return t.hashCode();
} else if (name.equals$O("testcharge")) {
var q = 1;
var vx = 0;
var vy = 0;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "vx=")) vx = (I$[27]||$incl$(27)).getParam$S$S(parList, "vx=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "vy=")) vy = (I$[27]||$incl$(27)).getParam$S$S(parList, "vy=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "q=")) q = (I$[27]||$incl$(27)).getParam$S$S(parList, "q=");
r = 5;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "r=")) r = ((I$[27]||$incl$(27)).getParam$S$S(parList, "r=")|0);
t = this.odeCanvas.addTestCharge$D$D$D$D(x, y, vx, vy);
t.setNoDrag$Z(this.noDrag);
t.setShowV$Z(this.showVelocity);
t.setShowFVector$Z(this.showForce);
t.showFOnDrag = this.showForce;
t.setLabel$S(this.chargeLabel);
t.setTrailSize$I(this.chargeTrail);
t.mag = q;
t.setSize$I(r);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "m=")) mass = (I$[27]||$incl$(27)).getParam$S$S(parList, "m=");
if (mass != 1 ) t.mass = mass;
if (this.chargeColor != null ) t.setColor$java_awt_Color(this.chargeColor);
return t.hashCode();
} else if (name.equals$O("image")) {
var file = " ";
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "gif=")) file = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "gif=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "file=")) file = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "file=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "x=")) x = (I$[27]||$incl$(27)).getParam$S$S(parList, "x=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "y=")) y = (I$[27]||$incl$(27)).getParam$S$S(parList, "y=");
if (file == null ) return 0;
var id = this.addImage$S$D$D(file, x, y);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "m=")) mass = (I$[27]||$incl$(27)).getParam$S$S(parList, "m=");
if (mass != 1 ) this.setMass$I$D(id, mass);
return id;
}if (t == null ) {
System.out.println$S("Object not created. name:" + name + "parameter list:" + parList );
return 0;
}this.odeCanvas.drawThings.addElement$TE(t);
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return t.hashCode();
});

Clazz.newMeth(C$, ['addTestCharge$D$D$D$D','addTestCharge'], function (x, y, vx, vy) {
var c = this.odeCanvas.addTestCharge$D$D$D$D(x, y, vx, vy);
c.setNoDrag$Z(this.noDrag);
c.setShowV$Z(this.showVelocity);
c.setShowFVector$Z(this.showForce);
c.showFOnDrag = this.showForce;
c.setLabel$S(this.chargeLabel);
c.setTrailSize$I(this.chargeTrail);
if (this.chargeColor != null ) c.setColor$java_awt_Color(this.chargeColor);
return c.hashCode();
});

Clazz.newMeth(C$, ['addCharge$D$D$D','addCharge'], function (x, y, q) {
var c = this.odeCanvas.addPole$D$D$D(x, y, q);
c.setNoDrag$Z(this.noDrag);
c.setHideThing$Z(this.hideCharge);
c.setShowFVector$Z(this.showForce);
c.showFOnDrag = this.showForce;
c.showFOnDrag = this.showForce;
if (this.chargeLabel != null ) c.setLabel$S(this.chargeLabel);
if (this.chargeColor != null ) c.setColor$java_awt_Color(this.chargeColor);
return c.hashCode();
});

Clazz.newMeth(C$, ['addRectangle$D$D$I$I','addRectangle'], function (x, y, width, height) {
var r = Clazz.new_((I$[29]||$incl$(29)).c$$eField4_OdeCanvas$D$D$I$I,[this.odeCanvas, x, y, width, height]);
r.setNoDrag$Z(this.noDrag);
this.odeCanvas.drawThings.addElement$TE(r);
return r.hashCode();
});

Clazz.newMeth(C$, ['addBox$D$D$I$I','addBox'], function (x, y, width, height) {
var b = Clazz.new_((I$[28]||$incl$(28)).c$$eField4_OdeCanvas$D$D$I$I,[this.odeCanvas, x, y, width, height]);
b.setNoDrag$Z(this.noDrag);
this.odeCanvas.drawThings.addElement$TE(b);
return b.hashCode();
});

Clazz.newMeth(C$, ['addLineAnchor$I$D$D','addLineAnchor'], function (id, x, y) {
var t = this.odeCanvas.getThing$I(id);
var a = Clazz.new_((I$[38]||$incl$(38)).c$$eField4_OdeCanvas$D$D$eField4_Thing,[this.odeCanvas, x, y, t]);
this.odeCanvas.drawThings.addElement$TE(a);
return a.hashCode();
});

Clazz.newMeth(C$, ['addImage$S$D$D','addImage'], function (file, x, y) {
var id = 0;
var im = null;
try {
im = this.getImage$java_net_URL$S(this.getCodeBase(), file);
id = this.odeCanvas.addImage$java_awt_Image$D$D(im, x, y);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
id = 0;
} else {
throw e;
}
}
if (id == 0) try {
im = this.getImage$java_net_URL$S(this.getDocumentBase(), file);
id = this.odeCanvas.addImage$java_awt_Image$D$D(im, x, y);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
id = 0;
} else {
throw e;
}
}
if (id == 0) try {
var url = Clazz.new_((I$[39]||$incl$(39)).c$$S,[file]);
im = this.getImage$java_net_URL(url);
id = this.odeCanvas.addImage$java_awt_Image$D$D(im, x, y);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
id = 0;
} else {
throw e;
}
}
if (id == 0) {
System.out.println$S("Failed to load image file.");
}return id;
});

Clazz.newMeth(C$, ['addSpringAnchor$I$D$D','addSpringAnchor'], function (id, x, y) {
var t = this.odeCanvas.getThing$I(id);
var a = Clazz.new_((I$[40]||$incl$(40)).c$$eField4_OdeCanvas$D$D$eField4_Thing,[this.odeCanvas, x, y, t]);
this.odeCanvas.drawThings.addElement$TE(a);
return a.hashCode();
});

Clazz.newMeth(C$, ['addCircle$D$D$I','addCircle'], function (x, y, radius) {
var c = Clazz.new_((I$[30]||$incl$(30)).c$$eField4_OdeCanvas$D$D$I,[this.odeCanvas, x, y, radius]);
c.setNoDrag$Z(this.noDrag);
this.odeCanvas.drawThings.addElement$TE(c);
return c.hashCode();
});

Clazz.newMeth(C$, ['addShell$D$D$I','addShell'], function (x, y, radius) {
var s = Clazz.new_((I$[32]||$incl$(32)).c$$eField4_OdeCanvas$D$D$I,[this.odeCanvas, x, y, radius]);
s.setNoDrag$Z(this.noDrag);
this.odeCanvas.drawThings.addElement$TE(s);
return s.hashCode();
});

Clazz.newMeth(C$, ['addPolyShape$I$S$S$D$D','addPolyShape'], function (n, hStr, vStr, x, y) {
var htokens = Clazz.new_((I$[41]||$incl$(41)).c$$S$S,[hStr, ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
var vtokens = Clazz.new_((I$[41]||$incl$(41)).c$$S$S,[vStr, ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
if ((htokens.countTokens() != n) || (htokens.countTokens() != n) ) return 0;
var h = Clazz.array(Integer.TYPE, [n]);
var v = Clazz.array(Integer.TYPE, [n]);
for (var i = 0; i < n; i++) {
h[i] = (I$[42]||$incl$(42)).atoi$S(htokens.nextToken());
v[i] = (I$[42]||$incl$(42)).atoi$S(vtokens.nextToken());
}
return this.odeCanvas.addPolyShape$I$IA$IA$D$D(n, h, v, x, y);
});

Clazz.newMeth(C$, ['addRelPolyShape$I$S$S$D$D','addRelPolyShape'], function (n, hStr, vStr, x, y) {
var htokens = Clazz.new_((I$[41]||$incl$(41)).c$$S$S,[hStr, ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
var vtokens = Clazz.new_((I$[41]||$incl$(41)).c$$S$S,[vStr, ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
if ((htokens.countTokens() != n) || (htokens.countTokens() != n) ) return 0;
var h = Clazz.array(Integer.TYPE, [n]);
var v = Clazz.array(Integer.TYPE, [n]);
for (var i = 0; i < n; i++) {
h[i] = (I$[42]||$incl$(42)).atoi$S(htokens.nextToken());
v[i] = (I$[42]||$incl$(42)).atoi$S(vtokens.nextToken());
}
for (var i = 1; i < n; i++) {
h[i] = h[i - 1] + h[i];
v[i] = v[i - 1] + v[i];
}
return this.odeCanvas.addPolyShape$I$IA$IA$D$D(n, h, v, x, y);
});

Clazz.newMeth(C$, ['deleteObject$I','deleteObject'], function (id) {
this.odeCanvas.deleteObject$I(id);
});

Clazz.newMeth(C$, 'deleteTestCharges', function () {
this.odeCanvas.clearTestCharges();
});

Clazz.newMeth(C$, 'deleteCharges', function () {
this.odeCanvas.clearPoles();
});

Clazz.newMeth(C$, ['setDamping$I$D','setDamping'], function (id, d) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.damping = d;
return true;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.pause();
this.deleteDataConnections();
this.clock.setContinuous();
this.clock.setTime$D(0);
this.setShowFieldLines$Z(false);
this.setShowFieldVectors$Z(false);
this.setShowContours$Z(false);
this.setShowCharge$Z(true);
this.noDrag = false;
this.showVelocity = false;
this.showForce = false;
this.chargeLabel = null;
this.chargeColor = null;
this.odeCanvas.setDefault();
});

Clazz.newMeth(C$, ['setXRange$D$D','setXRange'], function (xmin, xmax) {
this.odeCanvas.setXRange$D$D(xmin, xmax);
var ar = this.odeCanvas.autoRefresh;
this.odeCanvas.autoRefresh = true;
this.odeCanvas.setFields();
this.odeCanvas.autoRefresh = ar;
this.odeCanvas.clearTrails();
});

Clazz.newMeth(C$, ['setYRange$D$D','setYRange'], function (ymin, ymax) {
this.odeCanvas.setYRange$D$D(ymin, ymax);
var ar = this.odeCanvas.autoRefresh;
this.odeCanvas.autoRefresh = true;
this.odeCanvas.setFields();
this.odeCanvas.autoRefresh = ar;
this.odeCanvas.clearTrails();
});

Clazz.newMeth(C$, ['setZColorScale$D','setZColorScale'], function (colorScale) {
this.odeCanvas.field.scale = colorScale;
});

Clazz.newMeth(C$, ['getXPos$I','getXPos'], function (id) {
return this.getX$I(id);
});

Clazz.newMeth(C$, ['getYPos$I','getYPos'], function (id) {
return this.getY$I(id);
});

Clazz.newMeth(C$, ['setX$I$D','setX'], function (id, x) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.setX$D(x);
if (Clazz.instanceOf(t, "eField4.Charge")) (t).setAcceleration();
t.updateMySlaves();
if (!this.clock.isRunning()) this.updateDataConnections();
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['setXPos$I$D','setXPos'], function (id, x) {
return this.setX$I$D(id, x);
});

Clazz.newMeth(C$, ['setY$I$D','setY'], function (id, y) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.setY$D(y);
if (Clazz.instanceOf(t, "eField4.Charge")) (t).setAcceleration();
t.updateMySlaves();
if (!this.clock.isRunning()) this.updateDataConnections();
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['setYPos$I$D','setYPos'], function (id, y) {
return this.setY$I$D(id, y);
});

Clazz.newMeth(C$, ['setXY$I$D$D','setXY'], function (id, x, y) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.setXY$D$D(x, y);
if (Clazz.instanceOf(t, "eField4.Charge")) (t).setAcceleration();
t.updateMySlaves();
if (!this.clock.isRunning()) this.updateDataConnections();
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['setDrag$Z','setDrag'], function (drag) {
this.noDrag = !drag;
});

Clazz.newMeth(C$, ['setDampOnMousePressed$Z','setDampOnMousePressed'], function (damp) {
this.odeCanvas.dampOnMousePressed = damp;
});

Clazz.newMeth(C$, ['setDragable$I$Z','setDragable'], function (id, drag) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.noDrag = !drag;
return true;
});

Clazz.newMeth(C$, ['setVisibility$I$Z','setVisibility'], function (id, show) {
if (id == this.getClockID()) {
this.odeCanvas.setShowTime$Z(show);
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
}var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.hideThing = !show;
return true;
});

Clazz.newMeth(C$, ['setFont$I$S$I$I','setFont'], function (id, family, style, size) {
var font = Clazz.new_((I$[17]||$incl$(17)).c$$S$I$I,[family, style, size]);
var t = this.odeCanvas.getThing$I(id);
if (t == null  || font == null  ) return false;
t.font = font;
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['setObjectFont$I$S$I$I','setObjectFont'], function (id, family, style, size) {
return this.setFont$I$S$I$I(id, family, style, size);
});

Clazz.newMeth(C$, ['setFormat$I$S','setFormat'], function (id, fstr) {
var t = this.odeCanvas.getThing$I(id);
if (t == null  && (id == 0 || id == this.odeCanvas.hashCode() ) ) {
return this.odeCanvas.setFormat$S(fstr);
}var result = t.setFormat$S(fstr);
if (this.autoRefresh) this.odeCanvas.repaint();
return result;
});

Clazz.newMeth(C$, ['setFootPrints$I$I','setFootPrints'], function (id, n) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.footPrints = n;
return true;
});

Clazz.newMeth(C$, ['setHideCharge$Z','setHideCharge'], function (hc) {
if (hc) this.hideCharge = false;
 else this.hideCharge = true;
});

Clazz.newMeth(C$, ['setLabel$I$S','setLabel'], function (id, label) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.label = label;
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['setCollisionMessage$S','setCollisionMessage'], function (msg) {
this.label_collision = msg;
});

Clazz.newMeth(C$, ['setShowFieldLines$Z','setShowFieldLines'], function (sfl) {
this.showFieldLines = sfl;
this.odeCanvas.setShowFieldLines$Z(sfl);
});

Clazz.newMeth(C$, ['setShowFieldVectors$Z','setShowFieldVectors'], function (sfv) {
this.fieldVectorsBox.setState$Z(sfv);
this.showFieldVectors = sfv;
this.odeCanvas.setShowFieldVectors$Z(sfv);
});

Clazz.newMeth(C$, ['setShowContours$Z','setShowContours'], function (sc) {
this.contoursBox.setState$Z(sc);
this.odeCanvas.setShowContours$Z(sc);
this.showContours = sc;
});

Clazz.newMeth(C$, ['setPointChargeMode$Z','setPointChargeMode'], function (pcm) {
this.odeCanvas.pointChargeMode = pcm;
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
});

Clazz.newMeth(C$, ['setShowLabels$Z','setShowLabels'], function (sl) {
this.labelBox.setState$Z(sl);
this.odeCanvas.setShowLabels$Z(sl);
this.showLabels = sl;
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (ar) {
this.autoRefresh = ar;
this.odeCanvas.setAutoRefresh$Z(ar);
});

Clazz.newMeth(C$, ['setAnimationSlave$I$I','setAnimationSlave'], function (masterID, slaveID) {
var master = this.odeCanvas.getThing$I(masterID);
var slave = this.odeCanvas.getThing$I(slaveID);
if (master == null  || slave == null  ) return false;
if (master.myMaster === slave ) master.myMaster = null;
master.mySlaves.addElement$TE(slave);
slave.myMaster = master;
slave.setVarsFromMaster();
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['set$I$S$S','set'], function (id, name, parList) {
if (parList == null ) parList = "";
name = name.toLowerCase().trim();
name = (I$[27]||$incl$(27)).removeWhitespace$S(name);
parList = (I$[27]||$incl$(27)).removeWhitespace$S(parList);
var xmin = this.odeCanvas.contour.getMinX();
var xmax = this.odeCanvas.contour.getMaxX();
var ymin = this.odeCanvas.contour.getMinY();
var ymax = this.odeCanvas.contour.getMaxY();
if (name.equals$O("potential")) {
var ps = "0";
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "u=")) ps = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "u=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "v=")) ps = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "v=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "potential=")) ps = (I$[27]||$incl$(27)).getParamStr$S$S(parList, "potential=");
this.setPotential$S$D$D$D$D(ps, xmin, xmax, ymin, ymax);
return true;
} else if (name.equals$O("scale")) {
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "xmin=")) xmin = (I$[27]||$incl$(27)).getParam$S$S(parList, "xmin=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "xmax=")) xmax = (I$[27]||$incl$(27)).getParam$S$S(parList, "xmax=");
if (((I$[27]||$incl$(27)).parameterExist$S$S(parList, "xmin=")) || ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "xmax=")) ) {
this.odeCanvas.setXRange$D$D(xmin, xmax);
}if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "ymin=")) ymin = (I$[27]||$incl$(27)).getParam$S$S(parList, "ymin=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "ymax=")) ymax = (I$[27]||$incl$(27)).getParam$S$S(parList, "ymax=");
if (((I$[27]||$incl$(27)).parameterExist$S$S(parList, "ymin=")) || ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "ymax=")) ) {
this.odeCanvas.setYRange$D$D(ymin, ymax);
}var zlevels = 11;
var zmin = -1;
var zmax = 1;
;var delta = 0.2;
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "zmin=")) zmin = (I$[27]||$incl$(27)).getParam$S$S(parList, "zmin=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "zmax=")) zmax = (I$[27]||$incl$(27)).getParam$S$S(parList, "zmax=");
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "zlevels=")) zlevels = ((I$[27]||$incl$(27)).getParam$S$S(parList, "zlevels=")|0);
if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "delta=")) delta = (I$[27]||$incl$(27)).getParam$S$S(parList, "delta=");
if (((I$[27]||$incl$(27)).parameterExist$S$S(parList, "zmin=")) || ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "zmax=")) ) {
if (zlevels > 2) delta = (zmax - zmin) / (zlevels - 1);
}if ((I$[27]||$incl$(27)).parameterExist$S$S(parList, "zmin=")) {
this.odeCanvas.contour.setLevels$D$D$I(zmin, delta, zlevels);
}return true;
}var t = this.odeCanvas.getThing$I(id);
if (t == null ) {
System.out.println$S("Object not created. name:" + name + "parameter list:" + parList );
return false;
}return true;
});

Clazz.newMeth(C$, ['setBz$D','setBz'], function (bz) {
this.odeCanvas.setBz$D(bz);
});

Clazz.newMeth(C$, ['setCaption$S','setCaption'], function (c) {
this.odeCanvas.setCaption$S(c);
});

Clazz.newMeth(C$, ['setChargeLabel$S','setChargeLabel'], function (l) {
if (l == null  || l.trim().equals$O("") ) this.chargeLabel = null;
 else this.chargeLabel = l;
});

Clazz.newMeth(C$, ['setChargeMagnitude$I$D','setChargeMagnitude'], function (id, mag) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.mag = mag;
this.odeCanvas.setFields();
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['setChargeRGB$I$I$I','setChargeRGB'], function (r, g, b) {
this.chargeColor = Clazz.new_((I$[14]||$incl$(14)).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, ['setMass$I$D','setMass'], function (id, m) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.mass = m;
return true;
});

Clazz.newMeth(C$, ['setConstraintStr$I$S$D$D','setConstraintStr'], function (id, str, xmin, xmax) {
var t = this.odeCanvas.getThing$I(id);
return t.setConstraintStr$S$D$D(str, xmin, xmax);
});

Clazz.newMeth(C$, ['setConstrainX$I$D$D$D','setConstrainX'], function (id, x, xmin, xmax) {
var t = this.odeCanvas.getThing$I(id);
return t.setConstrainX$D$D$D(x, xmin, xmax);
});

Clazz.newMeth(C$, ['setConstrainR$I$D$D$D','setConstrainR'], function (id, r, x, y) {
var t = this.odeCanvas.getThing$I(id);
return t.setConstrainR$D$D$D(r, x, y);
});

Clazz.newMeth(C$, ['setConstrainY$I$D$D$D','setConstrainY'], function (id, y, ymin, ymax) {
var t = this.odeCanvas.getThing$I(id);
return t.setConstrainY$D$D$D(y, ymin, ymax);
});

Clazz.newMeth(C$, ['setDisplayOffset$I$I$I','setDisplayOffset'], function (id, xOff, yOff) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.xDisplayOff = xOff;
t.yDisplayOff = yOff;
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['setChargeTrail$I','setChargeTrail'], function (t) {
this.chargeTrail = t;
});

Clazz.newMeth(C$, ['setRGB$I$I$I$I','setRGB'], function (id, r, g, b) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) {
this.odeCanvas.contour.setObjectColor$I$java_awt_Color(id, Clazz.new_((I$[14]||$incl$(14)).c$$I$I$I,[r, g, b]));
return false;
}t.setColor$java_awt_Color(Clazz.new_((I$[14]||$incl$(14)).c$$I$I$I,[r, g, b]));
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['setSeriesRGB$I$I$I$I','setSeriesRGB'], function (id, r, g, b) {
this.odeCanvas.contour.setSeriesColor$I$java_awt_Color(id, Clazz.new_((I$[14]||$incl$(14)).c$$I$I$I,[r, g, b]));
});

Clazz.newMeth(C$, ['setOnScreenSize$I$I','setOnScreenSize'], function (id, size) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.setSize$I(size);
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['makeDataConnection$I$I$I$S$S','makeDataConnection'], function (sourceID, listenerID, seriesID, xStr, yStr) {
return C$.superclazz.prototype.makeDataConnection$I$I$I$S$S.apply(this, [sourceID, listenerID, seriesID, xStr, yStr]);
});

Clazz.newMeth(C$, ['deleteDataConnection$I','deleteDataConnection'], function (id) {
C$.superclazz.prototype.deleteDataConnection$I.apply(this, [id]);
});

Clazz.newMeth(C$, 'deleteDataConnections', function () {
C$.superclazz.prototype.deleteDataConnections.apply(this, []);
});

Clazz.newMeth(C$, ['setShowTime$Z','setShowTime'], function (st) {
this.odeCanvas.setShowTime$Z(st);
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
});

Clazz.newMeth(C$, ['setShowCoordOnDrag$Z','setShowCoordOnDrag'], function (sc) {
this.odeCanvas.setShowCoordOnDrag$Z(sc);
});

Clazz.newMeth(C$, ['setShowVOnDrag$Z','setShowVOnDrag'], function (sv) {
this.odeCanvas.setShowVOnDrag$Z(sv);
});

Clazz.newMeth(C$, ['setShowEOnDrag$Z','setShowEOnDrag'], function (se) {
this.odeCanvas.setShowEOnDrag$Z(se);
});

Clazz.newMeth(C$, ['setShowEquipotentialOnClick$Z','setShowEquipotentialOnClick'], function (sp) {
this.odeCanvas.setShowEquipotentialOnClick$Z(sp);
});

Clazz.newMeth(C$, ['setShowEquipotentialOnDoubleClick$Z','setShowEquipotentialOnDoubleClick'], function (sp) {
this.odeCanvas.setShowEquipotentialOnDoubleClick$Z(sp);
});

Clazz.newMeth(C$, ['setShowFieldLineOnClick$Z','setShowFieldLineOnClick'], function (sfl) {
this.odeCanvas.setShowFieldLineOnClick$Z(sfl);
});

Clazz.newMeth(C$, ['setShowFieldLineOnDoubleClick$Z','setShowFieldLineOnDoubleClick'], function (sfl) {
this.odeCanvas.setShowFieldLineOnDoubleClick$Z(sfl);
});

Clazz.newMeth(C$, ['setShowConstraintPath$I$Z','setShowConstraintPath'], function (id, sc) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return;
t.showConstraintPath = sc;
});

Clazz.newMeth(C$, ['setShowFComponents$I$Z','setShowFComponents'], function (id, sc) {
return this.odeCanvas.setShowFComponents$I$Z(id, sc);
});

Clazz.newMeth(C$, ['setShowFOnDrag$I$Z','setShowFOnDrag'], function (id, sfm) {
return this.odeCanvas.setShowFOnDrag$I$Z(id, sfm);
});

Clazz.newMeth(C$, ['setShowFVector$I$Z','setShowFVector'], function (id, sf) {
return this.odeCanvas.setShowFVector$I$Z(id, sf);
});

Clazz.newMeth(C$, ['setFieldResolution$I','setFieldResolution'], function (r) {
this.odeCanvas.setFieldResolution$I(r);
});

Clazz.newMeth(C$, ['setGridSize$I','setGridSize'], function (n) {
this.odeCanvas.setGridSize$I(n);
});

Clazz.newMeth(C$, ['setGhost$I$Z','setGhost'], function (id, ghost) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.ghost = ghost;
return true;
});

Clazz.newMeth(C$, ['setShowForce$Z','setShowForce'], function (sf) {
this.showForce = sf;
});

Clazz.newMeth(C$, ['setShowVelocity$Z','setShowVelocity'], function (sv) {
this.showVelocity = sv;
});

Clazz.newMeth(C$, ['setShowVComponents$I$Z','setShowVComponents'], function (id, svc) {
return this.odeCanvas.setShowVComponents$I$Z(id, svc);
});

Clazz.newMeth(C$, ['setShowVVector$I$Z','setShowVVector'], function (id, sv) {
return this.odeCanvas.setShowVVector$I$Z(id, sv);
});

Clazz.newMeth(C$, ['setSketchMode$Z','setSketchMode'], function (sketch) {
return this.odeCanvas.setSketchMode$Z(sketch);
});

Clazz.newMeth(C$, ['setSticky$I$Z','setSticky'], function (id, isSticky) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.sticky = isSticky;
return true;
});

Clazz.newMeth(C$, ['setSpeed$I$D','setSpeed'], function (id, speed) {
return this.odeCanvas.setSpeed$I$D(id, speed);
});

Clazz.newMeth(C$, ['setShowCharge$Z','setShowCharge'], function (sc) {
this.showPoles = sc;
this.odeCanvas.setShowPoles$Z(this.showPoles);
this.chargeBox.setState$Z(this.showPoles);
});

Clazz.newMeth(C$, ['setTrail$I$I','setTrail'], function (id, pts) {
var t = this.odeCanvas.getThing$I(id);
if (t == null ) return false;
t.setTrailSize$I(pts);
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
return true;
});

Clazz.newMeth(C$, ['setTimeVisibility$Z','setTimeVisibility'], function (visible) {
this.odeCanvas.setShowTime$Z(visible);
if (this.odeCanvas.autoRefresh) this.odeCanvas.repaint();
});

Clazz.newMeth(C$, 'setTimeContinuous', function () {
this.clock.setContinuous();
this.odeCanvas.setMessage$S(null);
});

Clazz.newMeth(C$, ['setTimeCycle$D','setTimeCycle'], function (max) {
if (this.clock.getDt() < 0 ) this.clock.setDt$D(-this.clock.getDt());
this.clock.setCycle$D$D(0, max);
this.reset();
});

Clazz.newMeth(C$, ['setTimeOneShot$D$S','setTimeOneShot'], function (max, msg) {
this.setMaxTime$D$S(max, msg);
});

Clazz.newMeth(C$, ['setTolerance$D','setTolerance'], function (t) {
this.odeCanvas.setTolerance$D(t);
});

Clazz.newMeth(C$, ['setTrajectory$I$S$S','setTrajectory'], function (id, xStr, yStr) {
return this.odeCanvas.setTrajectory$I$S$S(id, xStr, yStr);
});

Clazz.newMeth(C$, ['setPotential$S$D$D$D$D','setPotential'], function (ps, xmin, xmax, ymin, ymax) {
this.odeCanvas.setPotStr$S$D$D$D$D(ps, xmin, xmax, ymin, ymax);
var ar = this.odeCanvas.autoRefresh;
this.odeCanvas.autoRefresh = true;
this.odeCanvas.setFields();
this.odeCanvas.autoRefresh = ar;
this.odeCanvas.clearTrails();
});

Clazz.newMeth(C$, ['setMaxTime$D$S','setMaxTime'], function (max, msg) {
if (this.clock.getDt() < 0 ) this.clock.setDt$D(-this.clock.getDt());
this.clock.setOneShot$D$D(0, max);
this.oneShotMsg = msg;
this.odeCanvas.setMessage$S(null);
});

Clazz.newMeth(C$, 'pause', function () {
this.clock.stopClock();
});

Clazz.newMeth(C$, 'forward', function () {
if (this.odeCanvas.calculatingFieldLines) return;
if (this.clock.getDt() < 0 ) this.clock.setDt$D(-this.clock.getDt());
var keepRunning = !this.odeCanvas.testForCollision();
this.odeCanvas.collision = !keepRunning;
this.odeCanvas.setMessage$S(null);
if (keepRunning) this.clock.startClock();
});

Clazz.newMeth(C$, 'reverse', function () {
if (this.odeCanvas.calculatingFieldLines) return;
if (this.clock.getDt() > 0 ) this.clock.setDt$D(-this.clock.getDt());
var keepRunning = !this.odeCanvas.testForCollision();
this.odeCanvas.collision = !keepRunning;
this.odeCanvas.setMessage$S(null);
if (keepRunning) this.clock.startClock();
});

Clazz.newMeth(C$, 'stepTimeForward', function () {
if (this.odeCanvas.testForCollision()) return;
var dt = this.clock.getDt();
if (dt < 0 ) this.clock.setDt$D(-dt);
this.odeCanvas.setMessage$S(null);
this.clock.doStep();
});

Clazz.newMeth(C$, 'stepForward', function () {
this.stepTimeForward();
});

Clazz.newMeth(C$, 'stepTimeBack', function () {
if (this.odeCanvas.testForCollision()) return;
var dt = this.clock.getDt();
if (dt > 0 ) this.clock.setDt$D(-dt);
this.odeCanvas.setMessage$S(null);
if ((this.clock.getTime() - Math.abs(dt)) <= 0 ) this.reset();
 else this.clock.doStep();
});

Clazz.newMeth(C$, 'stepBack', function () {
this.stepTimeBack();
});

Clazz.newMeth(C$, 'pauseBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.pause();
});

Clazz.newMeth(C$, 'reset', function () {
this.pause();
this.clock.setTime$D(0);
this.odeCanvas.resetTime();
});

Clazz.newMeth(C$, 'resetBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.reset();
});

Clazz.newMeth(C$, 'potBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
var fStr = this.funcField.getText();
if (this.odeCanvas.setPotStr$S(fStr)) this.funcField.setBackground$java_awt_Color((I$[14]||$incl$(14)).white);
 else this.funcField.setBackground$java_awt_Color((I$[14]||$incl$(14)).red);
});

Clazz.newMeth(C$, 'newBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.odeCanvas.addTestCharge();
});

Clazz.newMeth(C$, 'clearBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.odeCanvas.clearTestCharges();
this.odeCanvas.clearPoles();
this.odeCanvas.drawThings.removeAllElements();
this.odeCanvas.contour.detachDataSets();
});

Clazz.newMeth(C$, 'posBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.odeCanvas.addPole$D(1);
});

Clazz.newMeth(C$, 'negBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.odeCanvas.addPole$D(-1);
});

Clazz.newMeth(C$, 'fieldVectorsBox_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (e.getStateChange() == 1) {
this.odeCanvas.setShowFieldVectors$Z(true);
this.showFieldVectors = true;
} else {
this.odeCanvas.setShowFieldVectors$Z(false);
this.showFieldVectors = false;
}});

Clazz.newMeth(C$, 'contoursBox_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (e.getStateChange() == 1) this.odeCanvas.setShowContours$Z(true);
 else this.odeCanvas.setShowContours$Z(false);
});

Clazz.newMeth(C$, 'chargeBox_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (e.getStateChange() == 1) this.odeCanvas.setShowPoles$Z(true);
 else this.odeCanvas.setShowPoles$Z(false);
});

Clazz.newMeth(C$, 'labelBox_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (e.getStateChange() == 1) this.odeCanvas.setShowLabels$Z(true);
 else this.odeCanvas.setShowLabels$Z(false);
});
})();
//Created 2018-02-20 07:13:10
