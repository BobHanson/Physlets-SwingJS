(function(){var P$=Clazz.newPackage("bfield"),I$=[];
var C$=Clazz.newClass(P$, "FieldCircle", null, 'edu.davidson.display.CircleThing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fieldPanel=null;
this.integral=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.integral=0;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I', function (owner, fp, x, y, radius) {
C$.superclazz.c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I.apply(this, [owner, fp, x, y, radius]);
C$.$init$.apply(this);
this.fieldPanel=fp;
this.varStrings=Clazz.array(String, -1, ["x", "y", "bx", "by", "path"]);
this.ds=Clazz.array(Double.TYPE, [1, 5]);
}, 1);

Clazz.newMeth(C$, 'doLineIntegral$', function () {
var numPts=100;
var sum1=0;
var sum2=0;
if (this.w < 2 || this.h < 2 ) return 0;
var ptX=this.fieldPanel.pixFromX$D(this.x) + this.xDisplayOff;
var ptY=this.fieldPanel.pixFromY$D(this.y) - this.yDisplayOff;
var x0;
var y0;
x0=this.fieldPanel.xFromPix$I(ptX);
var rad=(this.fieldPanel.xFromPix$I(ptX + this.w) - x0);
y0=this.fieldPanel.yFromPix$I(ptY);
var sin=0;
var cos=1;
var theta=0;
var dtheta=6.283185307179586 / numPts;
for (var i=0; i < numPts; i++) {
sin=Math.sin(theta);
cos=Math.cos(theta);
sum1 -= this.fieldPanel.getBx$D$D$bfield_Wire(x0 + cos * rad, y0 + sin * rad, null) * sin;
sum2 += this.fieldPanel.getBy$D$D$bfield_Wire(x0 + cos * rad, y0 + sin * rad, null) * cos;
theta += dtheta;
}
this.integral=(sum1 + sum2) * 2 * 3.141592653589793 * rad  / numPts;
return this.integral;
});

Clazz.newMeth(C$, 'getVariables$', function () {
this.ds[0][0]=this.x;
this.ds[0][1]=this.y;
this.ds[0][2]=this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, null);
this.ds[0][3]=this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, null);
;this.ds[0][4]=this.doLineIntegral$();
return this.ds;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:46 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
