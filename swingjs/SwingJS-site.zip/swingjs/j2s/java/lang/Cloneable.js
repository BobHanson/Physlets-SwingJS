(function(){var P$=java.lang,I$=[];
var C$=Clazz.newInterface(P$, "Cloneable");
})();
;Clazz.setTVer('3.2.2.06');//Created 2018-09-17 18:44:52 Java2ScriptVisitor version 3.2.2.06 net.sf.j2s.core.jar version 3.2.2.06
