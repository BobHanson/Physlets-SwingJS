(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['java.awt.Color','java.awt.Font','edu.davidson.display.Format','java.util.Vector','java.awt.Polygon','edu.davidson.tools.SApplet']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Thing", null, null, ['edu.davidson.tools.SStepable', 'edu.davidson.tools.SDataSource', 'edu.davidson.tools.SDataListener']);
C$.darkGreen = null;
C$.lightGreen = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.darkGreen = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 128, 0]);
C$.lightGreen = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[128, 255, 128]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.noDrag = false;
this.visible = false;
this.resizable = false;
this.highlight = false;
this.hotSpot = 0;
this.applet = null;
this.w = 0;
this.h = 0;
this.s = 0;
this.color = null;
this.x = 0;
this.y = 0;
this.time = 0;
this.canvas = null;
this.constraint = null;
this.font = null;
this.format = null;
this.xDisplayOff = 0;
this.yDisplayOff = 0;
this.varStrings = null;
this.ds = null;
this.label = null;
this.myMaster = null;
this.mySlaves = null;
this.highlightColor = null;
this.trail = null;
this.trailSize = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.noDrag = true;
this.visible = true;
this.resizable = true;
this.highlight = false;
this.hotSpot = 0;
this.applet = null;
this.w = 5;
this.h = 5;
this.s = 5;
this.color = (I$[1]||$incl$(1)).black;
this.constraint = null;
this.font = Clazz.new_((I$[2]||$incl$(2)).c$$S$I$I,["Helvetica", 1, 14]);
this.format = Clazz.new_((I$[3]||$incl$(3)).c$$S,["%-+6.3g"]);
this.xDisplayOff = 0;
this.yDisplayOff = 0;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "w", "h", "t"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
this.label = null;
this.myMaster = null;
this.mySlaves = Clazz.new_((I$[4]||$incl$(4)));
this.highlightColor = (I$[1]||$incl$(1)).red;
this.trail = Clazz.new_((I$[5]||$incl$(5)));
this.trailSize = 0;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_display_SScalable', function (sc) {
C$.$init$.apply(this);
this.canvas=sc;
try {
(I$[6]||$incl$(6)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
(I$[6]||$incl$(6)).addDataListener$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_display_SScalable$D$D', function (sc, x, y) {
C$.c$$edu_davidson_display_SScalable.apply(this, [sc]);
this.x=x;
this.y=y;
}, 1);

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'isNoDrag', function () {
return this.noDrag;
});

Clazz.newMeth(C$, 'setNoDrag$Z', function (nd) {
this.noDrag=nd;
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (o) {
this.applet=o;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.applet;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (i, j) {
return false;
});

Clazz.newMeth(C$, 'getSize', function () {
return this.s;
});

Clazz.newMeth(C$, 'setSize$I', function (sz) {
this.s=sz;
});

Clazz.newMeth(C$, 'getColor', function () {
return this.color;
});

Clazz.newMeth(C$, 'setColor$java_awt_Color', function (c) {
this.color=c;
});

Clazz.newMeth(C$, 'setDragable$Z', function (d) {
this.noDrag=!d;
});

Clazz.newMeth(C$, 'setVisible$Z', function (v) {
this.visible=v;
});

Clazz.newMeth(C$, 'setHighlight$Z', function (hl) {
this.highlight=hl;
});

Clazz.newMeth(C$, 'isHighlight', function () {
return this.highlight;
});

Clazz.newMeth(C$, 'isVisible', function () {
return this.visible;
});

Clazz.newMeth(C$, 'setResizable$Z', function (rs) {
this.resizable=rs;
});

Clazz.newMeth(C$, 'isResizable', function () {
return this.resizable;
});

Clazz.newMeth(C$, 'getMaster', function () {
return this.myMaster;
});

Clazz.newMeth(C$, 'getSlaves', function () {
return this.mySlaves;
});

Clazz.newMeth(C$, 'setLabel$S', function (l) {
this.label=l;
});

Clazz.newMeth(C$, 'getLabel', function () {
return this.label;
});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
try {
this.format=Clazz.new_((I$[3]||$incl$(3)).c$$S,[str]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.IllegalArgumentException")){
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'setFont$java_awt_Font', function (f) {
this.font=f;
if (this.font == null ) this.font=Clazz.new_((I$[2]||$incl$(2)).c$$S$I$I,["Helvetica", 1, 14]);
return true;
});

Clazz.newMeth(C$, 'setDisplayOff$I$I', function (xOff, yOff) {
this.xDisplayOff=xOff;
this.yDisplayOff=yOff;
});

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'setX$D', function (x) {
if (this.myMaster != null ) {
this.x=this.myMaster.x;
return;
}this.x=x;
if (this.constraint != null ) this.constraint.enforceConstraint$edu_davidson_display_Thing(this);
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
if (this.myMaster != null ) {
this.x=this.myMaster.x;
this.y=this.myMaster.y;
return;
}this.x=x;
this.y=y;
if (this.constraint != null ) this.constraint.enforceConstraint$edu_davidson_display_Thing(this);
this.updateMySlaves();
});

Clazz.newMeth(C$, 'setProperties$I$D$D', function (sid, alpha, beta) {
if (sid == 0 || sid == 1 ) {
this.setXY$D$D(alpha, beta);
} else if (sid == 2) {
this.w=(alpha|0);
this.h=(beta|0);
} else if (sid == 6) {
this.setX$D(alpha);
} else if (sid == 7) {
this.setY$D(beta);
}});

Clazz.newMeth(C$, 'dragMe$D$D', function (x, y) {
this.setXY$D$D(x, y);
});

Clazz.newMeth(C$, 'getXPix', function () {
return this.canvas.pixFromX$D(this.x);
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'setY$D', function (y) {
if (this.myMaster != null ) {
this.y=this.myMaster.y;
return;
}this.y=y;
if (this.constraint != null ) this.constraint.enforceConstraint$edu_davidson_display_Thing(this);
});

Clazz.newMeth(C$, 'setTime$D', function (t) {
this.time=t;
});

Clazz.newMeth(C$, 'getYPix', function () {
return this.canvas.pixFromY$D(this.y);
});

Clazz.newMeth(C$, 'getHeight', function () {
return this.h;
});

Clazz.newMeth(C$, 'setHeight$I', function (h) {
this.h=h;
});

Clazz.newMeth(C$, 'getWidth', function () {
return this.w;
});

Clazz.newMeth(C$, 'setWidth$I', function (w) {
this.w=w;
});

Clazz.newMeth(C$, 'setConstraint$edu_davidson_display_Constraint', function (c) {
if (c == null ) return;
this.constraint=c;
this.constraint.enforceConstraint$edu_davidson_display_Thing(this);
});

Clazz.newMeth(C$, 'addSlave$edu_davidson_display_Thing', function (slave) {
if (this.myMaster === slave ) this.myMaster=null;
this.mySlaves.addElement$TE(slave);
slave.myMaster=this;
slave.setVarsFromMaster();
});

Clazz.newMeth(C$, 'setVarsFromMaster', function () {
if (this.myMaster == null ) return;
this.x=this.myMaster.x;
this.y=this.myMaster.y;
var t = null;
for (var e = this.mySlaves.elements(); e.hasMoreElements(); ) {
t=e.nextElement();
if (t !== this  && t.myMaster === this  ) t.setVarsFromMaster();
}
});

Clazz.newMeth(C$, 'updateMySlaves', function () {
var slave = null;
for (var e = this.mySlaves.elements(); e.hasMoreElements(); ) {
slave=e.nextElement();
slave.setVarsFromMaster();
}
});

Clazz.newMeth(C$, 'paintMySlaves$java_awt_Graphics', function (g) {
var slave = null;
for (var e = this.mySlaves.elements(); e.hasMoreElements(); ) {
slave=e.nextElement();
slave.paint$java_awt_Graphics(g);
}
});

Clazz.newMeth(C$, 'step$D$D', function (dt, time) {
this.time=time + dt;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0]=this.x;
this.ds[0][1]=this.y;
this.ds[0][2]=this.w;
this.ds[0][3]=this.h;
this.ds[0][4]=this.time;
return this.ds;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
;});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'clearSeries$I', function (sid) {
;});

Clazz.newMeth(C$, 'deleteSeries$I', function (sid) {
;});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (ds, sid, x, y) {
this.setProperties$I$D$D(sid, x, y);
if (Clazz.instanceOf(this.canvas, "a2s.Canvas")) (this.canvas).repaint();
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (ds, sid, x, y) {
var last = x.length - 1;
this.setProperties$I$D$D(sid, x[last], y[last]);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:40
