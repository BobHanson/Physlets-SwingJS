(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['java.awt.Dimension','java.awt.Insets']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SPanel", null, 'a2s.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.ms = null;
this.ps = null;
this.vinset = 0;
this.hinset = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.ms = Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[10, 10]);
this.ps = Clazz.new_((I$[1]||$incl$(1)).c$$I$I,[10, 10]);
this.vinset = 0;
this.hinset = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'getInsets', function () {
return Clazz.new_((I$[2]||$incl$(2)).c$$I$I$I$I,[this.vinset, this.hinset, this.vinset, this.hinset]);
});

Clazz.newMeth(C$, 'setVinsets$I', function (v) {
this.vinset=v;
this.invalidate();
if (this.getParent() != null ) this.getParent().validate();
});

Clazz.newMeth(C$, 'getVinsets', function () {
return this.vinset;
});

Clazz.newMeth(C$, 'setHinsets$I', function (h) {
this.hinset=h;
this.invalidate();
if (this.getParent() != null ) this.getParent().validate();
});

Clazz.newMeth(C$, 'getHinsets', function () {
return this.hinset;
});

Clazz.newMeth(C$, 'getMinimumSize', function () {
return this.ms;
});

Clazz.newMeth(C$, 'setMinimumSize$java_awt_Dimension', function (s) {
this.ms=s;
});

Clazz.newMeth(C$, 'getPreferredSize', function () {
return this.ps;
});

Clazz.newMeth(C$, 'setPreferredSize$java_awt_Dimension', function (s) {
this.ps=s;
});
})();
//Created 2018-07-23 12:59:46 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
