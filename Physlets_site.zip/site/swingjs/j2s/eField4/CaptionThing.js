(function(){var P$=Clazz.newPackage("eField4"),I$=[[0,'java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "CaptionThing", null, 'eField4.TextThing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$S$S$D$D', function (o, txt, cs, x, y) {
C$.superclazz.c$$eField4_OdeCanvas$S$S$D$D.apply(this, [o, txt, cs, x, y]);
C$.$init$.apply(this);
this.color=$I$(1).black;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.hideThing) return;
var caption=this.getText$();
if (caption == null ) return;
g.setColor$java_awt_Color(this.color);
var f=g.getFont$();
g.setFont$java_awt_Font(this.font);
var fm=g.getFontMetrics$java_awt_Font(this.font);
g.drawString$S$I$I(caption, ((this.p.getSize$().width - fm.stringWidth$S(caption))/2|0) + this.xDisplayOff, 25 - this.yDisplayOff);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:51 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
