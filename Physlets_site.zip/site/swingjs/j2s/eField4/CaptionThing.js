(function(){var P$=Clazz.newPackage("eField4"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CaptionThing", null, 'eField4.TextThing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$S$S$D$D', function (o, txt, cs, x, y) {
C$.superclazz.c$$eField4_OdeCanvas$S$S$D$D.apply(this, [o, txt, cs, x, y]);
C$.$init$.apply(this);
this.color = (I$[1]||$incl$(1)).black;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.hideThing) return;
var caption = this.getText();
if (caption == null ) return;
g.setColor$java_awt_Color(this.color);
var f = g.getFont();
g.setFont$java_awt_Font(this.font);
var fm = g.getFontMetrics$java_awt_Font(this.font);
g.drawString$S$I$I(caption, ((this.p.getSize().width - fm.stringWidth$S(caption))/2|0) + this.xDisplayOff, 25 - this.yDisplayOff);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:17
