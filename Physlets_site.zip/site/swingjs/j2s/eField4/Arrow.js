(function(){var P$=Clazz.newPackage("eField4"),I$=[['edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Arrow", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.hStr = null;
this.vStr = null;
this.tempVars = null;
this.hFunc = null;
this.vFunc = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.tempVars = Clazz.array(Double.TYPE, [8]);
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$I$S$S$D$D', function (canvas, s, h, v, x, y) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [canvas, x, y, 0, 0]);
C$.$init$.apply(this);
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "vx", "vy", "ax", "ay", "m", "horz", "vert"]);
this.ds = Clazz.array(Double.TYPE, [1, 10]);
this.s = s;
this.hStr = h;
this.vStr = v;
this.hFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[8]);
this.hFunc.defineVariable$I$S(1, "t");
this.hFunc.defineVariable$I$S(2, "x");
this.hFunc.defineVariable$I$S(3, "y");
this.hFunc.defineVariable$I$S(4, "vx");
this.hFunc.defineVariable$I$S(5, "vy");
this.hFunc.defineVariable$I$S(6, "ax");
this.hFunc.defineVariable$I$S(7, "ay");
this.hFunc.defineVariable$I$S(8, "m");
this.hFunc.define$S(this.hStr);
this.hFunc.parse();
if (this.hFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse horzizontal component of vector: " + this.hStr);
System.out.println$S("Parse error: " + this.hFunc.getErrorString() + " at position " + this.hFunc.getErrorPosition() );
return;
}this.vFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[8]);
this.vFunc.defineVariable$I$S(1, "t");
this.vFunc.defineVariable$I$S(2, "x");
this.vFunc.defineVariable$I$S(3, "y");
this.vFunc.defineVariable$I$S(4, "vx");
this.vFunc.defineVariable$I$S(5, "vy");
this.vFunc.defineVariable$I$S(6, "ax");
this.vFunc.defineVariable$I$S(7, "ay");
this.vFunc.defineVariable$I$S(8, "m");
this.vFunc.define$S(this.vStr);
this.vFunc.parse();
if (this.vFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse vertical component of vector: " + this.vStr);
System.out.println$S("Parse error: " + this.vFunc.getErrorString() + " at position " + this.vFunc.getErrorPosition() );
return;
}}, 1);

Clazz.newMeth(C$, 'getHorz$DA', function (v) {
var h = 0;
this.tempVars[0] = v[0];
this.tempVars[1] = v[1];
this.tempVars[2] = v[2];
this.tempVars[3] = v[3];
this.tempVars[4] = v[4];
this.tempVars[5] = v[5];
this.tempVars[6] = v[6];
this.tempVars[7] = this.mass;
try {
h = this.hFunc.evaluate$DA(this.tempVars);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return h;
});

Clazz.newMeth(C$, 'getVert$DA', function (v) {
var val = 0;
this.tempVars[0] = v[0];
this.tempVars[1] = v[1];
this.tempVars[2] = v[2];
this.tempVars[3] = v[3];
this.tempVars[4] = v[4];
this.tempVars[5] = v[5];
this.tempVars[6] = v[6];
this.tempVars[7] = this.mass;
try {
val = this.vFunc.evaluate$DA(this.tempVars);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return val;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (this.hideThing) return;
var ptX = Math.round(this.p.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.p.pixFromY$D(this.vars[2])) - this.yDisplayOff;
var pixPerUnit = this.p.pixFromX$D(1) - this.p.pixFromX$D(0);
var x = pixPerUnit * this.getHorz$DA(this.vars);
var y = pixPerUnit * this.getVert$DA(this.vars);
if (this.showVVector) {
x = pixPerUnit * this.vars[3];
y = pixPerUnit * this.vars[4];
}if (this.showAVector) {
x = pixPerUnit * this.vars[5];
y = pixPerUnit * this.vars[6];
}if (this.dynamic && this.showFVector ) {
x = pixPerUnit * this.vars[5] * this.mass ;
y = pixPerUnit * this.vars[6] * this.mass ;
}if (!this.dynamic && this.showFVector ) {
x = pixPerUnit * this.vars[5] * this.mass ;
y = pixPerUnit * this.vars[6] * this.mass ;
}osg.setColor$java_awt_Color(this.color);
var x2 = ((ptX + x)|0);
var y2 = ((ptY - y)|0);
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
var h = Math.sqrt(x * x + y * y);
var w;
if (h > 3 * this.s ) w = this.s;
 else w = h / 3;
if (h > 1 ) {
var u = (w * x / h);
var v = -(w * y / h);
var base_x = x2 - 3 * u;
var base_y = y2 - 3 * v;
osg.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x2, y2);
osg.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x2, y2);
}});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
if (this.hideThing) return;
var ptX = Math.round(this.p.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.p.pixFromY$D(this.vars[2])) - this.yDisplayOff;
var pixPerUnit = this.p.pixFromX$D(1) - this.p.pixFromX$D(0);
var x = pixPerUnit * this.getHorz$DA(this.vars);
var y = pixPerUnit * this.getVert$DA(this.vars);
if (this.showVVector) {
x = pixPerUnit * this.vars[3];
y = pixPerUnit * this.vars[4];
}if (this.dynamic && this.showFVector ) {
x = pixPerUnit * this.vars[5];
y = pixPerUnit * this.vars[6];
}if (!this.dynamic && this.showFVector ) {
x = pixPerUnit * this.vars[5];
y = pixPerUnit * this.vars[6];
}osg.setColor$java_awt_Color(this.highlightColor);
var x2 = ((ptX + x)|0);
var y2 = ((ptY - y)|0);
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
var h = Math.sqrt(x * x + y * y);
var w;
if (h > 3 * this.s ) w = this.s;
 else w = h / 3;
if (h > 1 ) {
var u = (w * x / h);
var v = -(w * y / h);
var base_x = x2 - 3 * u;
var base_y = y2 - 3 * v;
osg.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x2, y2);
osg.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x2, y2);
}});

Clazz.newMeth(C$, 'getVariables', function () {
var horz = 0;
var vert = 0;
if (this.showVVector) {
horz = this.vars[3];
vert = this.vars[4];
} else if (this.dynamic && this.showFVector ) {
horz = this.vars[5];
vert = this.vars[6];
} else if (!this.dynamic && this.showFVector ) {
horz = this.vars[5];
vert = this.vars[6];
} else {
horz = this.getHorz$DA(this.vars);
vert = this.getVert$DA(this.vars);
}this.ds[0][0] = this.vars[0];
this.ds[0][1] = this.vars[1];
this.ds[0][2] = this.vars[2];
this.ds[0][3] = this.vars[3];
this.ds[0][4] = this.vars[4];
this.ds[0][5] = this.vars[5];
this.ds[0][6] = this.vars[6];
this.ds[0][7] = this.mass;
this.ds[0][8] = horz;
this.ds[0][9] = vert;
return this.ds;
});

Clazz.newMeth(C$);
})();
//Created 2018-03-16 05:19:21
