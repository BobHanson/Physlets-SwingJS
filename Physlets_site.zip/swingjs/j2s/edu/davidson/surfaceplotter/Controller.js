(function(){var P$=Clazz.newPackage("edu.davidson.surfaceplotter"),I$=[];
var C$=Clazz.newClass(P$, "Controller");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.calc_divisions = 0;
this.disp_divisions = 0;
this.delay_regen = false;
this.boxed = false;
this.showMesh = false;
this.autoScale = false;
this.displayXYTicks = false;
this.displayZTicks = false;
this.showFaceGrids = false;
this.minStr = null;
this.maxStr = null;
this.function1Str = null;
this.function2Str = null;
this.showFunction1 = false;
this.showFunction2 = false;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.zmin = 0;
this.zmax = 0;
this.numContourLines = 0;
this.plotMode = 0;
this.autoScaleHeigth = false;
this.hmin = 0;
this.hmax = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.calc_divisions = 20;
this.disp_divisions = 20;
this.delay_regen = false;
this.boxed = true;
this.showMesh = true;
this.autoScale = false;
this.displayXYTicks = true;
this.displayZTicks = true;
this.showFaceGrids = false;
this.minStr = "";
this.maxStr = "";
this.function1Str = "x*y";
this.function2Str = null;
this.showFunction1 = true;
this.showFunction2 = false;
this.xmin = -1;
this.xmax = 1;
this.ymin = -1;
this.ymax = 1;
this.zmin = -1;
this.zmax = 1;
this.numContourLines = 10;
this.plotMode = 4;
this.autoScaleHeigth = false;
this.hmin = 0;
this.hmax = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setDefault', function () {
this.delay_regen = false;
this.boxed = true;
this.showMesh = true;
this.autoScale = false;
this.displayXYTicks = true;
this.displayZTicks = true;
this.showFaceGrids = false;
this.numContourLines = 10;
this.plotMode = 4;
this.function1Str = null;
this.function2Str = null;
this.showFunction1 = false;
this.showFunction2 = false;
});

Clazz.newMeth(C$, 'isExpectDelay', function () {
return this.delay_regen;
});

Clazz.newMeth(C$, 'rotationStarts', function () {
});

Clazz.newMeth(C$, 'rotationStops', function () {
});

Clazz.newMeth(C$, 'getPlotMode', function () {
return this.plotMode;
});

Clazz.newMeth(C$, 'isPlotFunction1', function () {
if (this.function1Str == null ) return false;
return this.showFunction1;
});

Clazz.newMeth(C$, 'isPlotFunction2', function () {
if (this.function2Str == null ) return false;
return this.showFunction2;
});

Clazz.newMeth(C$, 'getFunction1Definition', function () {
return this.function1Str;
});

Clazz.newMeth(C$, 'getFunction2Definition', function () {
return this.function2Str;
});

Clazz.newMeth(C$, 'getContourLines', function () {
return this.numContourLines;
});

Clazz.newMeth(C$, 'getCalcDivisions', function () {
return this.calc_divisions;
});

Clazz.newMeth(C$, 'getDispDivisions', function () {
var plot_density;
plot_density = this.disp_divisions;
if (plot_density > this.calc_divisions) plot_density = this.calc_divisions;
while ((this.calc_divisions % plot_density) != 0)plot_density++;

return plot_density;
});

Clazz.newMeth(C$, 'setDispDivisions$I', function (divisions) {
this.disp_divisions = divisions;
});

Clazz.newMeth(C$, 'setFunction1$S', function (str) {
this.function1Str = str;
if (this.function1Str == null ) {
this.showFunction1 = false;
} else {
this.showFunction1 = true;
}});

Clazz.newMeth(C$, 'setFunction2$S', function (str) {
this.function2Str = str;
if (this.function2Str == null ) {
this.showFunction2 = false;
} else {
this.showFunction2 = true;
}});

Clazz.newMeth(C$, 'setMinimumResult$F', function (val) {
this.minStr = Float.toString(val);
this.hmin = val;
});

Clazz.newMeth(C$, 'setMinimumResult$S', function (val) {
this.minStr = val;
this.hmin = 0;
});

Clazz.newMeth(C$, 'setMaximumResult$F', function (val) {
this.maxStr = Float.toString(val);
this.hmax = val;
});

Clazz.newMeth(C$, 'setMaximumResult$S', function (val) {
this.maxStr = val;
this.hmax = 0;
});

Clazz.newMeth(C$, 'getXMin', function () {
return this.xmin;
});

Clazz.newMeth(C$, 'getYMin', function () {
return this.ymin;
});

Clazz.newMeth(C$, 'getZMin', function () {
if (this.autoScaleHeigth) return this.hmin;
return this.zmin;
});

Clazz.newMeth(C$, 'getXMax', function () {
return this.xmax;
});

Clazz.newMeth(C$, 'getYMax', function () {
return this.ymax;
});

Clazz.newMeth(C$, 'getZMax', function () {
if (this.autoScaleHeigth) return this.hmax;
return this.zmax;
});

Clazz.newMeth(C$, 'isBoxed', function () {
return this.boxed;
});

Clazz.newMeth(C$, 'isMesh', function () {
return this.showMesh;
});

Clazz.newMeth(C$, 'isScaleBox', function () {
return this.autoScale;
});

Clazz.newMeth(C$, 'isDisplayXY', function () {
return this.displayXYTicks;
});

Clazz.newMeth(C$, 'isDisplayZ', function () {
return this.displayZTicks;
});

Clazz.newMeth(C$, 'isDisplayGrids', function () {
return this.showFaceGrids;
});
})();
//Created 2018-02-19 20:23:14
