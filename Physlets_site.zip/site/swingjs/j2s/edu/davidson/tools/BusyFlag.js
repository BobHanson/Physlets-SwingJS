(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[['Thread']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "BusyFlag");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.busyflag = null;
this.busycount = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.busyflag = null;
this.busycount = 0;
}, 1);

Clazz.newMeth(C$, 'getBusyFlag', function () {
while (this.tryGetBusyFlag() == false ){
try {
this.wait();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
;} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'tryGetBusyFlag', function () {
if (this.busyflag == null ) {
this.busyflag = (I$[1]||$incl$(1)).currentThread();
this.busycount = 1;
return true;
}if (this.busyflag === (I$[1]||$incl$(1)).currentThread() ) {
this.busycount++;
return true;
}return false;
});

Clazz.newMeth(C$, 'freeBusyFlag', function () {
if (this.getBusyFlagOwner() === (I$[1]||$incl$(1)).currentThread() ) {
this.busycount--;
if (this.busycount == 0) {
this.busyflag = null;
this.notify();
}}});

Clazz.newMeth(C$, 'getBusyFlagOwner', function () {
return this.busyflag;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:05:40
