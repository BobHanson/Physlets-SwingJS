(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[[0,'java.awt.Font','edu.davidson.numerics.Parser','edu.davidson.tools.SUtil','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "TextThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.text=null;
this.calcStr=null;
this.textVars=null;
this.calcFunc=null;
this.valStr=null;
this.chopValue=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.textVars=Clazz.array(Double.TYPE, [3]);
this.valStr="";
this.chopValue=1.0E-12;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$S$D$D', function (owner, sc, txt, x, y) {
C$.c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$S$S$D$D.apply(this, [owner, sc, txt, null, x, y]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$S$S$D$D', function (owner, sc, txt, cs, x, y) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, x, y]);
C$.$init$.apply(this);
this.font=Clazz.new_($I$(1).c$$S$I$I,["Helvetica", 1, 14]);
this.text=txt;
this.applet=owner;
this.calcStr=cs;
if (this.calcStr == null  || this.calcStr.equals$O("") ) return;
this.calcFunc=Clazz.new_($I$(2).c$$I,[3]);
this.calcFunc.defineVariable$I$S(1, "t");
this.calcFunc.defineVariable$I$S(2, "x");
this.calcFunc.defineVariable$I$S(3, "y");
this.calcFunc.define$S(this.calcStr);
this.calcFunc.parse$();
if (this.calcFunc.getErrorCode$() != 0) {
System.out.println$S("Failed to parse calc-text: " + this.calcStr);
System.out.println$S("Parse error: " + this.calcFunc.getErrorString$() + " at function 1, position " + this.calcFunc.getErrorPosition$() );
return;
}}, 1);

Clazz.newMeth(C$, 'setProperties$I$D$D', function (sid, a, b) {
if (sid == 0 || sid == 1 ) {
this.setXY$D$D(a, b);
} else if (sid == 2) {
var val=0;
try {
val=$I$(3).chop$D$D(a, this.chopValue);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
this.valStr=this.format.form$D(val);
} else if (sid == 6) {
this.setX$D(a);
} else if (sid == 7) {
this.setY$D(b);
}});

Clazz.newMeth(C$, 'getText$', function () {
var val=0;
if (this.calcStr == null  || this.calcStr.equals$O("") ) return this.text + this.valStr;
if (this.applet != null ) {
this.textVars[0]=this.applet.clock.getTime$();
}this.textVars[1]=this.x;
this.textVars[2]=this.y;
try {
val=this.calcFunc.evaluate$DA(this.textVars);
val=$I$(3).chop$D$D(val, this.chopValue);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return this.text + " " + this.format.form$D(val) ;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var f=g.getFont$();
g.setFont$java_awt_Font(this.font);
var ptX=this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY=this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.drawString$S$I$I(this.getText$(), ptX, ptY);
g.setColor$java_awt_Color($I$(4).black);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:03 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
