(function(){var P$=Clazz.newPackage("sun.awt.datatransfer"),I$=[['java.util.HashMap','sun.awt.datatransfer.DataTransferer','java.util.Collections','java.io.InputStream','java.io.Reader',['sun.awt.datatransfer.DataTransferer','.CharsetComparator'],'java.util.HashSet','java.util.logging.Logger','java.awt.datatransfer.DataFlavor','java.lang.Boolean','java.util.ArrayList',['sun.awt.datatransfer.DataTransferer','.DataFlavorComparator'],'sun.awt.SunToolkit','java.awt.AWTError','sun.awt.datatransfer.DataTransferer$1','java.security.AccessController','java.util.logging.Level','java.util.TreeSet','sun.awt.datatransfer.DataTransferer$2','java.util.TreeMap',['sun.awt.datatransfer.DataTransferer','.IndexOrderComparator'],'java.util.Arrays','java.lang.StringBuffer','java.io.ByteArrayOutputStream','java.io.ByteArrayInputStream','java.io.File','java.io.StringReader','java.io.InputStreamReader','sun.awt.datatransfer.DataTransferer$3','java.lang.reflect.Modifier','java.io.SequenceInputStream','java.util.Stack','sun.awt.datatransfer.DataTransferer$4','java.awt.EventQueue','sun.awt.AppContext']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DataTransferer", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.charArrayClass = null;
C$.byteArrayClass = null;
C$.plainTextStringFlavor = null;
C$.javaTextEncodingFlavor = null;
C$.$standardEncodings = null;
C$.textMIMESubtypeCharsetSupport = null;
C$.defaultEncoding = null;
C$.textNatives = null;
C$.nativeCharsets = null;
C$.nativeEOLNs = null;
C$.nativeTerminators = null;
C$.transferer = null;
C$.dtLog = null;
var p$=C$.prototype;
C$.DEPLOYMENT_CACHE_PROPERTIES = null;
C$.deploymentCacheDirectoryList = null;
C$.defaultCharsetComparator = null;
C$.defaultFlavorComparator = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.charArrayClass = null;
C$.byteArrayClass = null;
C$.plainTextStringFlavor = null;
C$.javaTextEncodingFlavor = null;
C$.textMIMESubtypeCharsetSupport = null;
C$.textNatives = (I$[3]||$incl$(3)).synchronizedSet$java_util_Set(Clazz.new_((I$[7]||$incl$(7))));
C$.nativeCharsets = (I$[3]||$incl$(3)).synchronizedMap$java_util_Map(Clazz.new_((I$[1]||$incl$(1))));
C$.nativeEOLNs = (I$[3]||$incl$(3)).synchronizedMap$java_util_Map(Clazz.new_((I$[1]||$incl$(1))));
C$.nativeTerminators = (I$[3]||$incl$(3)).synchronizedMap$java_util_Map(Clazz.new_((I$[1]||$incl$(1))));
C$.dtLog = (I$[8]||$incl$(8)).getLogger$S("sun.awt.datatransfer.DataTransfer");
{
var tCharArrayClass = null;
var tByteArrayClass = null;
try {
tCharArrayClass=Clazz.forName("[C");
tByteArrayClass=Clazz.forName("[B");
} catch (cannotHappen) {
if (Clazz.exceptionOf(cannotHappen, "java.lang.ClassNotFoundException")){
} else {
throw cannotHappen;
}
}
C$.charArrayClass=tCharArrayClass;
C$.byteArrayClass=tByteArrayClass;
var tPlainTextStringFlavor = null;
try {
tPlainTextStringFlavor=Clazz.new_((I$[9]||$incl$(9)).c$$S,["text/plain;charset=Unicode;class=java.lang.String"]);
} catch (cannotHappen) {
if (Clazz.exceptionOf(cannotHappen, "java.lang.ClassNotFoundException")){
} else {
throw cannotHappen;
}
}
C$.plainTextStringFlavor=tPlainTextStringFlavor;
var tJavaTextEncodingFlavor = null;
try {
tJavaTextEncodingFlavor=Clazz.new_((I$[9]||$incl$(9)).c$$S,["application/x-java-text-encoding;class=\"[B\""]);
} catch (cannotHappen) {
if (Clazz.exceptionOf(cannotHappen, "java.lang.ClassNotFoundException")){
} else {
throw cannotHappen;
}
}
C$.javaTextEncodingFlavor=tJavaTextEncodingFlavor;
var tempMap = Clazz.new_((I$[1]||$incl$(1)).c$$I,[17]);
tempMap.put$TK$TV("sgml", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("xml", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("html", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("enriched", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("richtext", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("uri-list", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("directory", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("css", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("calendar", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("plain", (I$[10]||$incl$(10)).TRUE);
tempMap.put$TK$TV("rtf", (I$[10]||$incl$(10)).FALSE);
tempMap.put$TK$TV("tab-separated-values", (I$[10]||$incl$(10)).FALSE);
tempMap.put$TK$TV("t140", (I$[10]||$incl$(10)).FALSE);
tempMap.put$TK$TV("rfc822-headers", (I$[10]||$incl$(10)).FALSE);
tempMap.put$TK$TV("parityfec", (I$[10]||$incl$(10)).FALSE);
C$.textMIMESubtypeCharsetSupport=(I$[3]||$incl$(3)).synchronizedMap$java_util_Map(tempMap);
}
;
C$.DEPLOYMENT_CACHE_PROPERTIES = Clazz.array(java.lang.String, -1, ["deployment.system.cachedir", "deployment.user.cachedir", "deployment.javaws.cachedir", "deployment.javapi.cachedir"]);
C$.deploymentCacheDirectoryList = Clazz.new_((I$[11]||$incl$(11)));
C$.defaultCharsetComparator = Clazz.new_((I$[6]||$incl$(6)).c$$Z,[false]);
C$.defaultFlavorComparator = Clazz.new_((I$[12]||$incl$(12)).c$$Z,[false]);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getInstance', function () {
if (C$.transferer == null ) {
{
if (C$.transferer == null ) {
var name = (I$[13]||$incl$(13)).getDataTransfererClassName();
if (name != null ) {
var action = ((
(function(){var C$=Clazz.newClass(P$, "DataTransferer$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.security.PrivilegedAction', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run', function () {
var cls = null;
var method = null;
var ret = null;
try {
cls=Clazz.forName(this.$finals.name);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.ClassNotFoundException")){
var cl = ClassLoader.getSystemClassLoader();
if (cl != null ) {
try {
cls=cl.loadClass$S(this.$finals.name);
} catch (ee) {
if (Clazz.exceptionOf(ee, "java.lang.ClassNotFoundException")){
ee.printStackTrace();
throw Clazz.new_((I$[14]||$incl$(14)).c$$S,["DataTransferer not found: " + this.$finals.name]);
} else {
throw ee;
}
}
}} else {
throw e;
}
}
if (cls != null ) {
try {
method=cls.getDeclaredMethod$S$ClassA("getInstanceImpl", []);
method.setAccessible$Z(true);
} catch (e$$) {
if (Clazz.exceptionOf(e$$, "java.lang.NoSuchMethodException")){
var e = e$$;
{
e.printStackTrace();
throw Clazz.new_((I$[14]||$incl$(14)).c$$S,["Cannot instantiate DataTransferer: " + this.$finals.name]);
}
} else if (Clazz.exceptionOf(e$$, "java.lang.SecurityException")){
var e = e$$;
{
e.printStackTrace();
throw Clazz.new_((I$[14]||$incl$(14)).c$$S,["Access is denied for DataTransferer: " + this.$finals.name]);
}
} else {
throw e$$;
}
}
}if (method != null ) {
try {
ret=method.invoke$O$OA(null, null);
} catch (e$$) {
if (Clazz.exceptionOf(e$$, "java.lang.reflect.InvocationTargetException")){
var e = e$$;
{
e.printStackTrace();
throw Clazz.new_((I$[14]||$incl$(14)).c$$S,["Cannot instantiate DataTransferer: " + this.$finals.name]);
}
} else if (Clazz.exceptionOf(e$$, "java.lang.IllegalAccessException")){
var e = e$$;
{
e.printStackTrace();
throw Clazz.new_((I$[14]||$incl$(14)).c$$S,["Cannot access DataTransferer: " + this.$finals.name]);
}
} else {
throw e$$;
}
}
}return ret;
});
})()
), Clazz.new_((I$[15]||$incl$(15)).$init$, [this, {name: name}]));
C$.transferer=(I$[16]||$incl$(16)).doPrivileged$java_security_PrivilegedAction(action);
}}}}return C$.transferer;
}, 1);

Clazz.newMeth(C$, 'canonicalName$S', function (encoding) {
if (encoding == null ) {
return null;
}return encoding;
}, 1);

Clazz.newMeth(C$, 'getTextCharset$java_awt_datatransfer_DataFlavor', function (flavor) {
if (!C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor)) {
return null;
}var encoding = flavor.getParameter$S("charset");
return (encoding != null ) ? encoding : C$.getDefaultTextCharset();
}, 1);

Clazz.newMeth(C$, 'getDefaultTextCharset', function () {
if (C$.defaultEncoding != null ) {
return C$.defaultEncoding;
}return null;
}, 1);

Clazz.newMeth(C$, 'doesSubtypeSupportCharset$java_awt_datatransfer_DataFlavor', function (flavor) {
if (C$.dtLog.isLoggable$java_util_logging_Level((I$[17]||$incl$(17)).FINE)) {
if (!"text".equals$O(flavor.getPrimaryType())) {
C$.dtLog.log$java_util_logging_Level$S((I$[17]||$incl$(17)).FINE, "Assertion (\"text\".equals(flavor.getPrimaryType())) failed");
}}var subType = flavor.getSubType();
if (subType == null ) {
return false;
}var support = C$.textMIMESubtypeCharsetSupport.get$O(subType);
if (support != null ) {
return (support === (I$[10]||$incl$(10)).TRUE );
}var ret_val = (flavor.getParameter$S("charset") != null );
C$.textMIMESubtypeCharsetSupport.put$TK$TV(subType, (ret_val) ? (I$[10]||$incl$(10)).TRUE : (I$[10]||$incl$(10)).FALSE);
return ret_val;
}, 1);

Clazz.newMeth(C$, 'doesSubtypeSupportCharset$S$S', function (subType, charset) {
var support = C$.textMIMESubtypeCharsetSupport.get$O(subType);
if (support != null ) {
return (support === (I$[10]||$incl$(10)).TRUE );
}var ret_val = (charset != null );
C$.textMIMESubtypeCharsetSupport.put$TK$TV(subType, (ret_val) ? (I$[10]||$incl$(10)).TRUE : (I$[10]||$incl$(10)).FALSE);
return ret_val;
}, 1);

Clazz.newMeth(C$, 'isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor', function (flavor) {
if ((I$[9]||$incl$(9)).stringFlavor.equals$java_awt_datatransfer_DataFlavor(flavor)) {
return true;
}if (!"text".equals$O(flavor.getPrimaryType()) || !C$.doesSubtypeSupportCharset$java_awt_datatransfer_DataFlavor(flavor) ) {
return false;
}var rep_class = flavor.getRepresentationClass();
if (flavor.isRepresentationClassReader() || Clazz.getClass(java.lang.String).equals$O(rep_class) || flavor.isRepresentationClassCharBuffer() || C$.charArrayClass.equals$O(rep_class)  ) {
return true;
}if (!(flavor.isRepresentationClassInputStream() || flavor.isRepresentationClassByteBuffer() || C$.byteArrayClass.equals$O(rep_class)  )) {
return false;
}var charset = flavor.getParameter$S("charset");
return (charset != null ) ? C$.isEncodingSupported$S(charset) : true;
}, 1);

Clazz.newMeth(C$, 'isFlavorNoncharsetTextType$java_awt_datatransfer_DataFlavor', function (flavor) {
if (!"text".equals$O(flavor.getPrimaryType()) || C$.doesSubtypeSupportCharset$java_awt_datatransfer_DataFlavor(flavor) ) {
return false;
}return (flavor.isRepresentationClassInputStream() || flavor.isRepresentationClassByteBuffer() || C$.byteArrayClass.equals$O(flavor.getRepresentationClass())  );
}, 1);

Clazz.newMeth(C$, 'isEncodingSupported$S', function (encoding) {
if (encoding == null ) {
return false;
}return false;
}, 1);

Clazz.newMeth(C$, 'standardEncodings', function () {
if (C$.$standardEncodings == null ) {
var tempSet = Clazz.new_((I$[18]||$incl$(18)).c$$java_util_Comparator,[C$.defaultCharsetComparator]);
tempSet.add$TE("US-ASCII");
tempSet.add$TE("ISO-8859-1");
tempSet.add$TE("UTF-8");
tempSet.add$TE("UTF-16BE");
tempSet.add$TE("UTF-16LE");
tempSet.add$TE("UTF-16");
tempSet.add$TE(C$.getDefaultTextCharset());
C$.$standardEncodings=(I$[3]||$incl$(3)).unmodifiableSortedSet$java_util_SortedSet(tempSet);
}return C$.$standardEncodings.iterator();
}, 1);

Clazz.newMeth(C$, 'adaptFlavorMap$java_awt_datatransfer_FlavorMap', function (map) {
if (Clazz.instanceOf(map, "java.awt.datatransfer.FlavorTable")) {
return map;
}return ((
(function(){var C$=Clazz.newClass(P$, "DataTransferer$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.datatransfer.FlavorTable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getNativesForFlavors$java_awt_datatransfer_DataFlavorA', function (flavors) {
return this.$finals.map.getNativesForFlavors$java_awt_datatransfer_DataFlavorA(flavors);
});

Clazz.newMeth(C$, 'getFlavorsForNatives$SA', function (natives) {
return this.$finals.map.getFlavorsForNatives$SA(natives);
});

Clazz.newMeth(C$, 'getNativesForFlavor$java_awt_datatransfer_DataFlavor', function (flav) {
var natives = this.getNativesForFlavors$java_awt_datatransfer_DataFlavorA(Clazz.array((I$[9]||$incl$(9)), -1, [flav]));
var nat = natives.get$O(flav);
if (nat != null ) {
var list = Clazz.new_((I$[11]||$incl$(11)).c$$I,[1]);
list.add$TE(nat);
return list;
} else {
return (I$[3]||$incl$(3)).EMPTY_LIST;
}});

Clazz.newMeth(C$, 'getFlavorsForNative$S', function (nat) {
var flavors = this.getFlavorsForNatives$SA(Clazz.array(java.lang.String, -1, [nat]));
var flavor = flavors.get$O(nat);
if (flavor != null ) {
var list = Clazz.new_((I$[11]||$incl$(11)).c$$I,[1]);
list.add$TE(flavor);
return list;
} else {
return (I$[3]||$incl$(3)).EMPTY_LIST;
}});
})()
), Clazz.new_((I$[19]||$incl$(19)).$init$, [this, {map: map}]));
}, 1);

Clazz.newMeth(C$, 'registerTextFlavorProperties$S$S$S$S', function (nat, charset, eoln, terminators) {
var format = this.getFormatForNativeAsLong$S(nat);
C$.textNatives.add$TE(format);
C$.nativeCharsets.put$TK$TV(format, (charset != null  && charset.length$() != 0 ) ? charset : C$.getDefaultTextCharset());
if (eoln != null  && eoln.length$() != 0  && !eoln.equals$O("\u000a") ) {
C$.nativeEOLNs.put$TK$TV(format, eoln);
}if (terminators != null  && terminators.length$() != 0 ) {
var iTerminators = Integer.$valueOf(terminators);
if (iTerminators.intValue() > 0) {
C$.nativeTerminators.put$TK$TV(format, iTerminators);
}}});

Clazz.newMeth(C$, 'isTextFormat$J', function (format) {
return C$.textNatives.contains$O(Long.$valueOf(format));
});

Clazz.newMeth(C$, 'getCharsetForTextFormat$Long', function (lFormat) {
return C$.nativeCharsets.get$O(lFormat);
});

Clazz.newMeth(C$, 'getFormatsForTransferable$java_awt_datatransfer_Transferable$java_awt_datatransfer_FlavorTable', function (contents, map) {
var flavors = contents.getTransferDataFlavors();
if (flavors == null ) {
return Clazz.new_((I$[20]||$incl$(20)));
}return this.getFormatsForFlavors$java_awt_datatransfer_DataFlavorA$java_awt_datatransfer_FlavorTable(flavors, map);
});

Clazz.newMeth(C$, 'getFormatsForFlavor$java_awt_datatransfer_DataFlavor$java_awt_datatransfer_FlavorTable', function (flavor, map) {
return this.getFormatsForFlavors$java_awt_datatransfer_DataFlavorA$java_awt_datatransfer_FlavorTable(Clazz.array((I$[9]||$incl$(9)), -1, [flavor]), map);
});

Clazz.newMeth(C$, 'getFormatsForFlavors$java_awt_datatransfer_DataFlavorA$java_awt_datatransfer_FlavorTable', function (flavors, map) {
var formatMap = Clazz.new_((I$[1]||$incl$(1)).c$$I,[flavors.length]);
var textPlainMap = Clazz.new_((I$[1]||$incl$(1)).c$$I,[flavors.length]);
var indexMap = Clazz.new_((I$[1]||$incl$(1)).c$$I,[flavors.length]);
var textPlainIndexMap = Clazz.new_((I$[1]||$incl$(1)).c$$I,[flavors.length]);
var currentIndex = 0;
for (var i = flavors.length - 1; i >= 0; i--) {
var flavor = flavors[i];
if (flavor == null ) continue;
if (flavor.isFlavorTextType() || flavor.isFlavorJavaFileListType() || (I$[9]||$incl$(9)).imageFlavor.equals$java_awt_datatransfer_DataFlavor(flavor) || flavor.isRepresentationClassSerializable() || flavor.isRepresentationClassInputStream() || flavor.isRepresentationClassRemote()  ) {
var natives = map.getNativesForFlavor$java_awt_datatransfer_DataFlavor(flavor);
currentIndex+=natives.size();
for (var iter = natives.iterator(); iter.hasNext(); ) {
var lFormat = this.getFormatForNativeAsLong$S(iter.next());
var index = Integer.$valueOf(currentIndex--);
formatMap.put$TK$TV(lFormat, flavor);
indexMap.put$TK$TV(lFormat, index);
if (("text".equals$O(flavor.getPrimaryType()) && "plain".equals$O(flavor.getSubType()) ) || flavor.equals$java_awt_datatransfer_DataFlavor((I$[9]||$incl$(9)).stringFlavor) ) {
textPlainMap.put$TK$TV(lFormat, flavor);
textPlainIndexMap.put$TK$TV(lFormat, index);
}}
currentIndex+=natives.size();
}}
formatMap.putAll$java_util_Map(textPlainMap);
indexMap.putAll$java_util_Map(textPlainIndexMap);
var comparator = Clazz.new_((I$[21]||$incl$(21)).c$$java_util_Map$Z,[indexMap, false]);
var sortedMap = Clazz.new_((I$[20]||$incl$(20)).c$$java_util_Comparator,[comparator]);
sortedMap.putAll$java_util_Map(formatMap);
return sortedMap;
});

Clazz.newMeth(C$, 'getFormatsForTransferableAsArray$java_awt_datatransfer_Transferable$java_awt_datatransfer_FlavorTable', function (contents, map) {
return C$.keysToLongArray$java_util_SortedMap(this.getFormatsForTransferable$java_awt_datatransfer_Transferable$java_awt_datatransfer_FlavorTable(contents, map));
});

Clazz.newMeth(C$, 'getFormatsForFlavorAsArray$java_awt_datatransfer_DataFlavor$java_awt_datatransfer_FlavorTable', function (flavor, map) {
return C$.keysToLongArray$java_util_SortedMap(this.getFormatsForFlavor$java_awt_datatransfer_DataFlavor$java_awt_datatransfer_FlavorTable(flavor, map));
});

Clazz.newMeth(C$, 'getFormatsForFlavorsAsArray$java_awt_datatransfer_DataFlavorA$java_awt_datatransfer_FlavorTable', function (flavors, map) {
return C$.keysToLongArray$java_util_SortedMap(this.getFormatsForFlavors$java_awt_datatransfer_DataFlavorA$java_awt_datatransfer_FlavorTable(flavors, map));
});

Clazz.newMeth(C$, 'getFlavorsForFormat$J$java_awt_datatransfer_FlavorTable', function (format, map) {
return this.getFlavorsForFormats$JA$java_awt_datatransfer_FlavorTable(Clazz.array(Long.TYPE, -1, [format]), map);
});

Clazz.newMeth(C$, 'getFlavorsForFormats$JA$java_awt_datatransfer_FlavorTable', function (formats, map) {
var flavorMap = Clazz.new_((I$[1]||$incl$(1)).c$$I,[formats.length]);
var mappingSet = Clazz.new_((I$[7]||$incl$(7)).c$$I,[formats.length]);
var flavorSet = Clazz.new_((I$[7]||$incl$(7)).c$$I,[formats.length]);
for (var i = 0; i < formats.length; i++) {
var format = formats[i];
var nat = this.getNativeForFormat$J(format);
var flavors = map.getFlavorsForNative$S(nat);
for (var iter = flavors.iterator(); iter.hasNext(); ) {
var flavor = iter.next();
if (flavor.isFlavorTextType() || flavor.isFlavorJavaFileListType() || (I$[9]||$incl$(9)).imageFlavor.equals$java_awt_datatransfer_DataFlavor(flavor) || flavor.isRepresentationClassSerializable() || flavor.isRepresentationClassInputStream() || flavor.isRepresentationClassRemote()  ) {
var lFormat = Long.$valueOf(format);
var mapping = C$.createMapping$O$O(lFormat, flavor);
flavorMap.put$TK$TV(flavor, lFormat);
mappingSet.add$TE(mapping);
flavorSet.add$TE(flavor);
}}
}
for (var flavorIter = flavorSet.iterator(); flavorIter.hasNext(); ) {
var flavor = flavorIter.next();
var natives = map.getNativesForFlavor$java_awt_datatransfer_DataFlavor(flavor);
for (var nativeIter = natives.iterator(); nativeIter.hasNext(); ) {
var lFormat = this.getFormatForNativeAsLong$S(nativeIter.next());
var mapping = C$.createMapping$O$O(lFormat, flavor);
if (mappingSet.contains$O(mapping)) {
flavorMap.put$TK$TV(flavor, lFormat);
break;
}}
}
return flavorMap;
});

Clazz.newMeth(C$, 'getFlavorsForFormatsAsSet$JA$java_awt_datatransfer_FlavorTable', function (formats, map) {
var flavorSet = Clazz.new_((I$[7]||$incl$(7)).c$$I,[formats.length]);
for (var i = 0; i < formats.length; i++) {
var nat = this.getNativeForFormat$J(formats[i]);
var flavors = map.getFlavorsForNative$S(nat);
for (var iter = flavors.iterator(); iter.hasNext(); ) {
var flavor = iter.next();
if (flavor.isFlavorTextType() || flavor.isFlavorJavaFileListType() || (I$[9]||$incl$(9)).imageFlavor.equals$java_awt_datatransfer_DataFlavor(flavor) || flavor.isRepresentationClassSerializable() || flavor.isRepresentationClassInputStream() || flavor.isRepresentationClassRemote()  ) {
flavorSet.add$TE(flavor);
}}
}
return flavorSet;
});

Clazz.newMeth(C$, 'getFlavorsForFormatAsArray$J$java_awt_datatransfer_FlavorTable', function (format, map) {
return this.getFlavorsForFormatsAsArray$JA$java_awt_datatransfer_FlavorTable(Clazz.array(Long.TYPE, -1, [format]), map);
});

Clazz.newMeth(C$, 'getFlavorsForFormatsAsArray$JA$java_awt_datatransfer_FlavorTable', function (formats, map) {
return C$.setToSortedDataFlavorArray$java_util_Set(this.getFlavorsForFormatsAsSet$JA$java_awt_datatransfer_FlavorTable(formats, map));
});

Clazz.newMeth(C$, 'createMapping$O$O', function (key, value) {
return (I$[22]||$incl$(22)).asList$TTA(Clazz.array(java.lang.Object, -1, [key, value]));
}, 1);

Clazz.newMeth(C$, 'getBestCharsetForTextFormat$Long$java_awt_datatransfer_Transferable', function (lFormat, localeTransferable) {
var charset = null;
if (localeTransferable != null  && this.isLocaleDependentTextFormat$J((lFormat).longValue())  && localeTransferable.isDataFlavorSupported$java_awt_datatransfer_DataFlavor(C$.javaTextEncodingFlavor) ) {
try {
charset= String.instantialize(localeTransferable.getTransferData$java_awt_datatransfer_DataFlavor(C$.javaTextEncodingFlavor), "UTF-8");
} catch (cannotHappen) {
if (Clazz.exceptionOf(cannotHappen, "java.awt.datatransfer.UnsupportedFlavorException")){
} else {
throw cannotHappen;
}
}
} else {
charset=this.getCharsetForTextFormat$Long(lFormat);
}if (charset == null ) {
charset=C$.getDefaultTextCharset();
}return charset;
});

Clazz.newMeth(C$, 'translateTransferableString$S$J', function (str, format) {
var lFormat = Long.$valueOf(format);
var charset = p$.getBestCharsetForTextFormat$Long$java_awt_datatransfer_Transferable.apply(this, [lFormat, null]);
var eoln = C$.nativeEOLNs.get$O(lFormat);
if (eoln != null ) {
var length = str.length$();
var buffer = Clazz.new_((I$[23]||$incl$(23)).c$$I,[length * 2]);
for (var i = 0; i < length; i++) {
if (str.startsWith$S$I(eoln, i)) {
buffer.append$S(eoln);
i+=eoln.length$() - 1;
continue;
}var c = str.charAt(i);
if (c == "\u000a") {
buffer.append$S(eoln);
} else {
buffer.append$C(c);
}}
str=buffer.toString();
}var bytes = str.getBytes(charset);
var terminators = C$.nativeTerminators.get$O(lFormat);
if (terminators != null ) {
var numTerminators = terminators.intValue();
var terminatedBytes = Clazz.array(Byte.TYPE, [bytes.length + numTerminators]);
System.arraycopy(bytes, 0, terminatedBytes, 0, bytes.length);
for (var i = bytes.length; i < terminatedBytes.length; i++) {
terminatedBytes[i]=(0|0);
}
bytes=terminatedBytes;
}return bytes;
});

Clazz.newMeth(C$, 'translateBytesOrStreamToString$java_io_InputStream$BA$J$java_awt_datatransfer_Transferable', function (str, bytes, format, localeTransferable) {
if (bytes == null ) {
bytes=C$.inputStreamToByteArray$java_io_InputStream(str);
}str.close();
var lFormat = Long.$valueOf(format);
var charset = p$.getBestCharsetForTextFormat$Long$java_awt_datatransfer_Transferable.apply(this, [lFormat, localeTransferable]);
var eoln = C$.nativeEOLNs.get$O(lFormat);
var terminators = C$.nativeTerminators.get$O(lFormat);
var count;
if (terminators != null ) {
var numTerminators = terminators.intValue();
search : for (count=0; count < (bytes.length - numTerminators + 1); count+=numTerminators) {
for (var i = count; i < count + numTerminators; i++) {
if (bytes[i] != 0) {
continue search;
}}
break search;
}
} else {
count=bytes.length;
}var converted =  String.instantialize(bytes, 0, count, charset);
if (eoln != null ) {
var buf = converted.toCharArray();
var eoln_arr = eoln.toCharArray();
converted=null;
var j = 0;
var match;
for (var i = 0; i < buf.length; ) {
if (i + eoln_arr.length > buf.length) {
buf[j++]=buf[i++];
continue;
}match=true;
for (var k = 0, l = i; k < eoln_arr.length; k++, l++) {
if (eoln_arr[k] != buf[l]) {
match=false;
break;
}}
if (match) {
buf[j++]="\u000a";
i+=eoln_arr.length;
} else {
buf[j++]=buf[i++];
}}
converted= String.instantialize(buf, 0, j);
}return converted;
});

Clazz.newMeth(C$, 'translateTransferable$java_awt_datatransfer_Transferable$java_awt_datatransfer_DataFlavor$J', function (contents, flavor, format) {
var obj;
var stringSelectionHack;
try {
obj=contents.getTransferData$java_awt_datatransfer_DataFlavor(flavor);
if (obj == null ) {
return null;
}if (flavor.equals$java_awt_datatransfer_DataFlavor((I$[9]||$incl$(9)).plainTextFlavor) && !(Clazz.instanceOf(obj, "java.io.InputStream")) ) {
obj=contents.getTransferData$java_awt_datatransfer_DataFlavor((I$[9]||$incl$(9)).stringFlavor);
if (obj == null ) {
return null;
}stringSelectionHack=true;
} else {
stringSelectionHack=false;
}} catch (e) {
if (Clazz.exceptionOf(e, "java.awt.datatransfer.UnsupportedFlavorException")){
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,[e.getMessage()]);
} else {
throw e;
}
}
if (stringSelectionHack || (Clazz.getClass(java.lang.String).equals$O(flavor.getRepresentationClass()) && C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format)  ) ) {
return p$.translateTransferableString$S$J.apply(this, [p$.removeSuspectedData$java_awt_datatransfer_DataFlavor$java_awt_datatransfer_Transferable$S.apply(this, [flavor, contents, obj]), format]);
} else if (flavor.isRepresentationClassReader()) {
if (!(C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) )) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["cannot transfer non-text data as Reader"]);
}var r = obj;
var buf = Clazz.new_((I$[23]||$incl$(23)));
var c;
while ((c=r.read()) != -1){
buf.append$C(String.fromCharCode(c));
}
r.close();
return p$.translateTransferableString$S$J.apply(this, [buf.toString(), format]);
} else if (flavor.isRepresentationClassCharBuffer()) {
if (!(C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) )) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["cannot transfer non-text data as CharBuffer"]);
}return null;
} else if (C$.charArrayClass.equals$O(flavor.getRepresentationClass())) {
if (!(C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) )) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["cannot transfer non-text data as char array"]);
}return p$.translateTransferableString$S$J.apply(this, [ String.instantialize(obj), format]);
} else if (flavor.isRepresentationClassByteBuffer()) {
} else if (C$.byteArrayClass.equals$O(flavor.getRepresentationClass())) {
var bytes = obj;
if (C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) ) {
var sourceEncoding = C$.getTextCharset$java_awt_datatransfer_DataFlavor(flavor);
return p$.translateTransferableString$S$J.apply(this, [ String.instantialize(bytes, sourceEncoding), format]);
} else {
return bytes;
}} else if ((I$[9]||$incl$(9)).imageFlavor.equals$java_awt_datatransfer_DataFlavor(flavor)) {
if (!this.isImageFormat$J(format)) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["Data translation failed: not an image format"]);
}var image = obj;
var bytes = this.imageToPlatformBytes$java_awt_Image$J(image, format);
if (bytes == null ) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["Data translation failed: cannot convert java image to native format"]);
}return bytes;
}var bos = Clazz.new_((I$[24]||$incl$(24)));
if (this.isFileFormat$J(format)) {
if (!(I$[9]||$incl$(9)).javaFileListFlavor.equals$java_awt_datatransfer_DataFlavor(flavor)) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["data translation failed"]);
}var list = obj;
var fileList = Clazz.new_((I$[11]||$incl$(11)));
var nFiles = 0;
for (var i = 0; i < list.size(); i++) {
var o = list.get$I(i);
if (Clazz.instanceOf(o, "java.io.File") || Clazz.instanceOf(o, "java.lang.String") ) {
nFiles++;
}}
var files = Clazz.array(java.lang.String, [nFiles]);
for (var i = 0, j = 0; i < list.size(); i++) {
var o = list.get$I(i);
var file = p$.castToFile$O.apply(this, [o]);
fileList.add$TE(file.getCanonicalPath());
}
for (var fileName, $fileName = fileList.iterator(); $fileName.hasNext()&&((fileName=$fileName.next()),1);) {
var bytes = fileName.getBytes();
bos.write$BA$I$I(bytes, 0, bytes.length);
bos.write$I(0);
}
bos.write$I(0);
} else if (flavor.isRepresentationClassInputStream()) {
var is = obj;
var eof = false;
var avail = is.available();
var tmp = Clazz.array(Byte.TYPE, [avail > 8192 ? avail : 8192]);
do {
var ret;
if (!(eof=(ret=is.read$BA$I$I(tmp, 0, tmp.length)) == -1)) {
bos.write$BA$I$I(tmp, 0, ret);
}} while (!eof);
is.close();
if (C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) ) {
var bytes = bos.toByteArray();
bos.close();
var sourceEncoding = C$.getTextCharset$java_awt_datatransfer_DataFlavor(flavor);
return p$.translateTransferableString$S$J.apply(this, [ String.instantialize(bytes, sourceEncoding), format]);
}} else {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["data translation failed"]);
}var ret = bos.toByteArray();
bos.close();
return ret;
});

Clazz.newMeth(C$, 'translateBytes$BA$java_awt_datatransfer_DataFlavor$J$java_awt_datatransfer_Transferable', function (bytes, flavor, format, localeTransferable) {
return this.translateBytesOrStream$java_io_InputStream$BA$java_awt_datatransfer_DataFlavor$J$java_awt_datatransfer_Transferable(null, bytes, flavor, format, localeTransferable);
});

Clazz.newMeth(C$, 'translateStream$java_io_InputStream$java_awt_datatransfer_DataFlavor$J$java_awt_datatransfer_Transferable', function (str, flavor, format, localeTransferable) {
return this.translateBytesOrStream$java_io_InputStream$BA$java_awt_datatransfer_DataFlavor$J$java_awt_datatransfer_Transferable(str, null, flavor, format, localeTransferable);
});

Clazz.newMeth(C$, 'translateBytesOrStream$java_io_InputStream$BA$java_awt_datatransfer_DataFlavor$J$java_awt_datatransfer_Transferable', function (str, bytes, flavor, format, localeTransferable) {
if (str == null ) {
str=Clazz.new_((I$[25]||$incl$(25)).c$$BA,[bytes]);
}if (this.isFileFormat$J(format)) {
if (!(I$[9]||$incl$(9)).javaFileListFlavor.equals$java_awt_datatransfer_DataFlavor(flavor)) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["data translation failed"]);
}if (bytes == null ) {
bytes=C$.inputStreamToByteArray$java_io_InputStream(str);
}var filenames = this.dragQueryFile$BA(bytes);
if (filenames == null ) {
str.close();
return null;
}var files = Clazz.array((I$[26]||$incl$(26)), [filenames.length]);
for (var i = 0; i < filenames.length; i++) {
files[i]=Clazz.new_((I$[26]||$incl$(26)).c$$S,[filenames[i]]);
}
str.close();
return (I$[22]||$incl$(22)).asList$TTA(files);
} else if (Clazz.getClass(java.lang.String).equals$O(flavor.getRepresentationClass()) && C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format)  ) {
return p$.translateBytesOrStreamToString$java_io_InputStream$BA$J$java_awt_datatransfer_Transferable.apply(this, [str, bytes, format, localeTransferable]);
} else if ((I$[9]||$incl$(9)).plainTextFlavor.equals$java_awt_datatransfer_DataFlavor(flavor)) {
return Clazz.new_((I$[27]||$incl$(27)).c$$S,[p$.translateBytesOrStreamToString$java_io_InputStream$BA$J$java_awt_datatransfer_Transferable.apply(this, [str, bytes, format, localeTransferable])]);
} else if (flavor.isRepresentationClassInputStream()) {
return p$.translateBytesOrStreamToInputStream$java_io_InputStream$java_awt_datatransfer_DataFlavor$J$java_awt_datatransfer_Transferable.apply(this, [str, flavor, format, localeTransferable]);
} else if (flavor.isRepresentationClassReader()) {
if (!(C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) )) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["cannot transfer non-text data as Reader"]);
}var is = p$.translateBytesOrStreamToInputStream$java_io_InputStream$java_awt_datatransfer_DataFlavor$J$java_awt_datatransfer_Transferable.apply(this, [str, (I$[9]||$incl$(9)).plainTextFlavor, format, localeTransferable]);
var unicode = C$.getTextCharset$java_awt_datatransfer_DataFlavor((I$[9]||$incl$(9)).plainTextFlavor);
var reader = Clazz.new_((I$[28]||$incl$(28)).c$$java_io_InputStream$S,[is, unicode]);
return p$.constructFlavoredObject$O$java_awt_datatransfer_DataFlavor$Class.apply(this, [reader, flavor, Clazz.getClass((I$[5]||$incl$(5)))]);
} else if (flavor.isRepresentationClassCharBuffer()) {
if (!(C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) )) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["cannot transfer non-text data as CharBuffer"]);
}return null;
} else if (C$.charArrayClass.equals$O(flavor.getRepresentationClass())) {
if (!(C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) )) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["cannot transfer non-text data as char array"]);
}return p$.translateBytesOrStreamToString$java_io_InputStream$BA$J$java_awt_datatransfer_Transferable.apply(this, [str, bytes, format, localeTransferable]).toCharArray();
} else if (flavor.isRepresentationClassByteBuffer()) {
if (C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) ) {
bytes=p$.translateBytesOrStreamToString$java_io_InputStream$BA$J$java_awt_datatransfer_Transferable.apply(this, [str, bytes, format, localeTransferable]).getBytes(C$.getTextCharset$java_awt_datatransfer_DataFlavor(flavor));
} else {
if (bytes == null ) {
bytes=C$.inputStreamToByteArray$java_io_InputStream(str);
}}return null;
} else if (C$.byteArrayClass.equals$O(flavor.getRepresentationClass())) {
if (C$.isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(flavor) && this.isTextFormat$J(format) ) {
return p$.translateBytesOrStreamToString$java_io_InputStream$BA$J$java_awt_datatransfer_Transferable.apply(this, [str, bytes, format, localeTransferable]).getBytes(C$.getTextCharset$java_awt_datatransfer_DataFlavor(flavor));
} else {
return (bytes != null ) ? bytes : C$.inputStreamToByteArray$java_io_InputStream(str);
}} else if ((I$[9]||$incl$(9)).imageFlavor.equals$java_awt_datatransfer_DataFlavor(flavor)) {
if (!this.isImageFormat$J(format)) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["data translation failed"]);
}var image = this.platformImageBytesOrStreamToImage$java_io_InputStream$BA$J(str, bytes, format);
str.close();
return image;
}throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["data translation failed"]);
});

Clazz.newMeth(C$, 'translateBytesOrStreamToInputStream$java_io_InputStream$java_awt_datatransfer_DataFlavor$J$java_awt_datatransfer_Transferable', function (str, flavor, format, localeTransferable) {
return p$.constructFlavoredObject$O$java_awt_datatransfer_DataFlavor$Class.apply(this, [str, flavor, Clazz.getClass((I$[4]||$incl$(4)))]);
});

Clazz.newMeth(C$, 'removeSuspectedData$java_awt_datatransfer_DataFlavor$java_awt_datatransfer_Transferable$S', function (flavor, contents, str) {
if (null == System.getSecurityManager()  || !flavor.isMimeTypeEqual$S("text/uri-list") ) {
return str;
}var ret_val = "";
var allowedFiles = Clazz.new_((I$[23]||$incl$(23)).c$$I,[str.length$()]);
for (var i = 0; i < str.$plit("(\\s)+").length; i++) {
var fileName = str.$plit("(\\s)+")[i];
var file = Clazz.new_((I$[26]||$incl$(26)).c$$S,[fileName]);
if (file.exists() && C$.isFileInWebstartedCache$java_io_File(file) ) {
continue;
}if (0 != allowedFiles.length$()) {
allowedFiles.append$S("\\r\\n");
}allowedFiles.append$S(fileName);
}
ret_val=allowedFiles.toString();
return ret_val;
});

Clazz.newMeth(C$, 'castToFile$O', function (fileObject) {
var filePath = null;
if (Clazz.instanceOf(fileObject, "java.io.File")) {
filePath=(fileObject).getCanonicalPath();
} else if (Clazz.instanceOf(fileObject, "java.lang.String")) {
filePath=fileObject;
}return Clazz.new_((I$[26]||$incl$(26)).c$$S,[filePath]);
});

Clazz.newMeth(C$, 'isFileInWebstartedCache$java_io_File', function (f) {
if (C$.deploymentCacheDirectoryList.isEmpty()) {
for (var cacheDirectoryProperty, $cacheDirectoryProperty = 0, $$cacheDirectoryProperty = C$.DEPLOYMENT_CACHE_PROPERTIES; $cacheDirectoryProperty<$$cacheDirectoryProperty.length&&((cacheDirectoryProperty=$$cacheDirectoryProperty[$cacheDirectoryProperty]),1);$cacheDirectoryProperty++) {
var cacheDirectoryPath = System.getProperty(cacheDirectoryProperty);
if (cacheDirectoryPath != null ) {
try {
var cacheDirectory = (Clazz.new_((I$[26]||$incl$(26)).c$$S,[cacheDirectoryPath])).getCanonicalFile();
if (cacheDirectory != null ) {
C$.deploymentCacheDirectoryList.add$TE(cacheDirectory);
}} catch (ioe) {
if (Clazz.exceptionOf(ioe, "java.io.IOException")){
} else {
throw ioe;
}
}
}}
}for (var it = C$.deploymentCacheDirectoryList.iterator(); it.hasNext(); ) {
var deploymentCacheDirectory = it.next();
for (var dir = f; dir != null ; dir=dir.getParentFile()) {
if (dir.equals$O(deploymentCacheDirectory)) {
return true;
}}
}
return false;
}, 1);

Clazz.newMeth(C$, 'constructFlavoredObject$O$java_awt_datatransfer_DataFlavor$Class', function (arg, flavor, clazz) {
var dfrc = flavor.getRepresentationClass();
if (clazz.equals$O(dfrc)) {
return arg;
} else {
var constructors = null;
try {
constructors=(I$[16]||$incl$(16)).doPrivileged$java_security_PrivilegedAction(((
(function(){var C$=Clazz.newClass(P$, "DataTransferer$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.security.PrivilegedAction', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'run', function () {
return this.$finals.dfrc.getConstructors();
});
})()
), Clazz.new_((I$[29]||$incl$(29)).$init$, [this, {dfrc: dfrc}])));
} catch (se) {
if (Clazz.exceptionOf(se, "java.lang.SecurityException")){
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,[se.getMessage()]);
} else {
throw se;
}
}
var constructor = null;
for (var j = 0; j < constructors.length; j++) {
if (!(I$[30]||$incl$(30)).isPublic$I(constructors[j].getModifiers())) {
continue;
}var ptypes = constructors[j].getParameterTypes();
if (ptypes != null  && ptypes.length == 1  && clazz.equals$O(ptypes[0]) ) {
constructor=constructors[j];
break;
}}
if (constructor == null ) {
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["can't find <init>(L" + clazz + ";)V for class: " + dfrc.getName() ]);
}try {
return constructor.newInstance$OA(Clazz.array(java.lang.Object, -1, [arg]));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,[e.getMessage()]);
} else {
throw e;
}
}
}});

Clazz.newMeth(C$, 'concatData$O$O', function (obj1, obj2) {
var str1 = null;
var str2 = null;
if (Clazz.instanceOf(obj1, Clazz.array(Byte.TYPE, -1))) {
var arr1 = obj1;
if (Clazz.instanceOf(obj2, Clazz.array(Byte.TYPE, -1))) {
var arr2 = obj2;
var ret = Clazz.array(Byte.TYPE, [arr1.length + arr2.length]);
System.arraycopy(arr1, 0, ret, 0, arr1.length);
System.arraycopy(arr2, 0, ret, arr1.length, arr2.length);
return ret;
} else {
str1=Clazz.new_((I$[25]||$incl$(25)).c$$BA,[arr1]);
str2=obj2;
}} else {
str1=obj1;
if (Clazz.instanceOf(obj2, Clazz.array(Byte.TYPE, -1))) {
str2=Clazz.new_((I$[25]||$incl$(25)).c$$BA,[obj2]);
} else {
str2=obj2;
}}return Clazz.new_((I$[31]||$incl$(31)).c$$java_io_InputStream$java_io_InputStream,[str1, str2]);
});

Clazz.newMeth(C$, 'convertData$O$java_awt_datatransfer_Transferable$J$java_util_Map$Z', function (source, contents, format, formatMap, isToolkitThread) {
var ret = null;
if (isToolkitThread) try {
var stack = Clazz.new_((I$[32]||$incl$(32)));
var dataConverter = ((
(function(){var C$=Clazz.newClass(P$, "DataTransferer$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.done = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.done = false;
}, 1);

Clazz.newMeth(C$, 'run', function () {
if (this.done) {
return;
}var data = null;
try {
var flavor = this.$finals.formatMap.get$O(Long.$valueOf(this.$finals.format));
if (flavor != null ) {
data=this.b$['sun.awt.datatransfer.DataTransferer'].translateTransferable$java_awt_datatransfer_Transferable$java_awt_datatransfer_DataFlavor$J(this.$finals.contents, flavor, this.$finals.format);
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
data=null;
} else {
throw e;
}
}
try {
this.b$['sun.awt.datatransfer.DataTransferer'].getToolkitThreadBlockedHandler().lock();
this.$finals.stack.push$TE(data);
this.b$['sun.awt.datatransfer.DataTransferer'].getToolkitThreadBlockedHandler().exit();
} finally {
this.b$['sun.awt.datatransfer.DataTransferer'].getToolkitThreadBlockedHandler().unlock();
this.done=true;
}
});
})()
), Clazz.new_((I$[33]||$incl$(33)).$init$, [this, {formatMap: formatMap, format: format, contents: contents, stack: stack}]));
var appContext = (I$[13]||$incl$(13)).targetToAppContext$O(source);
this.getToolkitThreadBlockedHandler().lock();
if (appContext != null ) {
appContext.put$O$O("DATA_CONVERTER_KEY", dataConverter);
}(I$[13]||$incl$(13)).executeOnEventHandlerThread$O$Runnable(source, dataConverter);
while (stack.empty()){
this.getToolkitThreadBlockedHandler().enter();
}
if (appContext != null ) {
appContext.remove$O("DATA_CONVERTER_KEY");
}ret=stack.pop();
} finally {
this.getToolkitThreadBlockedHandler().unlock();
}
 else {
var flavor = formatMap.get$O(Long.$valueOf(format));
if (flavor != null ) {
ret=this.translateTransferable$java_awt_datatransfer_Transferable$java_awt_datatransfer_DataFlavor$J(contents, flavor, format);
}}return ret;
});

Clazz.newMeth(C$, 'processDataConversionRequests', function () {
if ((I$[34]||$incl$(34)).isDispatchThread()) {
var appContext = (I$[35]||$incl$(35)).getAppContext();
this.getToolkitThreadBlockedHandler().lock();
try {
var dataConverter = appContext.get$O("DATA_CONVERTER_KEY");
if (dataConverter != null ) {
dataConverter.run();
appContext.remove$O("DATA_CONVERTER_KEY");
}} finally {
this.getToolkitThreadBlockedHandler().unlock();
}
}});

Clazz.newMeth(C$, 'keysToLongArray$java_util_SortedMap', function (map) {
var keySet = map.keySet();
var retval = Clazz.array(Long.TYPE, [keySet.size()]);
var i = 0;
for (var iter = keySet.iterator(); iter.hasNext(); i++) {
retval[i]=(iter.next()).longValue();
}
return retval;
}, 1);

Clazz.newMeth(C$, 'keysToDataFlavorArray$java_util_Map', function (map) {
return C$.setToSortedDataFlavorArray$java_util_Set$java_util_Map(map.keySet(), map);
}, 1);

Clazz.newMeth(C$, 'setToSortedDataFlavorArray$java_util_Set', function (flavorsSet) {
var flavors = Clazz.array((I$[9]||$incl$(9)), [flavorsSet.size()]);
flavorsSet.toArray$TTA(flavors);
(I$[22]||$incl$(22)).sort$TTA$java_util_Comparator(flavors, C$.defaultFlavorComparator);
return flavors;
}, 1);

Clazz.newMeth(C$, 'setToSortedDataFlavorArray$java_util_Set$java_util_Map', function (flavorsSet, flavorToNativeMap) {
var flavors = Clazz.array((I$[9]||$incl$(9)), [flavorsSet.size()]);
flavorsSet.toArray$TTA(flavors);
var comparator = Clazz.new_((I$[12]||$incl$(12)).c$$java_util_Map$Z,[flavorToNativeMap, false]);
(I$[22]||$incl$(22)).sort$TTA$java_util_Comparator(flavors, comparator);
return flavors;
}, 1);

Clazz.newMeth(C$, 'inputStreamToByteArray$java_io_InputStream', function (str) {
var baos = Clazz.new_((I$[24]||$incl$(24)));
var len = 0;
var buf = Clazz.array(Byte.TYPE, [8192]);
while ((len=str.read$BA(buf)) != -1){
baos.write$BA$I$I(buf, 0, len);
}
return baos.toByteArray();
}, 1);

Clazz.newMeth(C$, 'getPlatformMappingsForNative$S', function (nat) {
return Clazz.new_((I$[11]||$incl$(11)));
});

Clazz.newMeth(C$, 'getPlatformMappingsForFlavor$java_awt_datatransfer_DataFlavor', function (df) {
return Clazz.new_((I$[11]||$incl$(11)));
});
;
(function(){var C$=Clazz.newClass(P$.DataTransferer, "IndexedComparator", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'java.util.Comparator');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.order = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$Z.apply(this, [true]);
}, 1);

Clazz.newMeth(C$, 'c$$Z', function (order) {
C$.$init$.apply(this);
this.order=order;
}, 1);

Clazz.newMeth(C$, 'compareIndices$java_util_Map$O$O$Integer', function (indexMap, obj1, obj2, fallbackIndex) {
var index1 = indexMap.get$O(obj1);
var index2 = indexMap.get$O(obj2);
if (index1 == null ) {
index1=fallbackIndex;
}if (index2 == null ) {
index2=fallbackIndex;
}return index1.compareTo(index2);
}, 1);

Clazz.newMeth(C$, 'compareLongs$java_util_Map$O$O$Long', function (indexMap, obj1, obj2, fallbackIndex) {
var index1 = indexMap.get$O(obj1);
var index2 = indexMap.get$O(obj2);
if (index1 == null ) {
index1=fallbackIndex;
}if (index2 == null ) {
index2=fallbackIndex;
}return index1.compareTo(index2);
}, 1);
})()
;
(function(){var C$=Clazz.newClass(P$.DataTransferer, "CharsetComparator", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, ['sun.awt.datatransfer.DataTransferer','sun.awt.datatransfer.DataTransferer.IndexedComparator']);
C$.charsets = null;
C$.defaultEncoding = null;
C$.DEFAULT_CHARSET_INDEX = null;
C$.OTHER_CHARSET_INDEX = null;
C$.WORST_CHARSET_INDEX = null;
C$.UNSUPPORTED_CHARSET_INDEX = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.charsets = null;
C$.DEFAULT_CHARSET_INDEX = Integer.$valueOf(2);
C$.OTHER_CHARSET_INDEX = Integer.$valueOf(1);
C$.WORST_CHARSET_INDEX = Integer.$valueOf(0);
C$.UNSUPPORTED_CHARSET_INDEX = Integer.$valueOf(-2147483648);
{
var charsetsMap = Clazz.new_((I$[1]||$incl$(1)).c$$I$F,[8, 1.0]);
charsetsMap.put$TK$TV(P$.DataTransferer.canonicalName$S("UTF-16LE"), Integer.$valueOf(4));
charsetsMap.put$TK$TV(P$.DataTransferer.canonicalName$S("UTF-16BE"), Integer.$valueOf(5));
charsetsMap.put$TK$TV(P$.DataTransferer.canonicalName$S("UTF-8"), Integer.$valueOf(6));
charsetsMap.put$TK$TV(P$.DataTransferer.canonicalName$S("UTF-16"), Integer.$valueOf(7));
charsetsMap.put$TK$TV(P$.DataTransferer.canonicalName$S("US-ASCII"), C$.WORST_CHARSET_INDEX);
var defEncoding = (I$[2]||$incl$(2)).canonicalName$S((I$[2]||$incl$(2)).getDefaultTextCharset());
if (charsetsMap.get$O(C$.defaultEncoding) == null ) {
charsetsMap.put$TK$TV(C$.defaultEncoding, C$.DEFAULT_CHARSET_INDEX);
}charsetsMap.put$TK$TV("UNSUPPORTED", C$.UNSUPPORTED_CHARSET_INDEX);
C$.charsets=(I$[3]||$incl$(3)).unmodifiableMap$java_util_Map(charsetsMap);
}
;
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$Z.apply(this, [true]);
}, 1);

Clazz.newMeth(C$, 'c$$Z', function (order) {
C$.superclazz.c$$Z.apply(this, [order]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, ['compare$O$O','compare$TT$TT'], function (obj1, obj2) {
var charset1 = null;
var charset2 = null;
if (this.order == true ) {
charset1=obj1;
charset2=obj2;
} else {
charset1=obj2;
charset2=obj1;
}return this.compareCharsets$S$S(charset1, charset2);
});

Clazz.newMeth(C$, 'compareCharsets$S$S', function (charset1, charset2) {
charset1=C$.getEncoding$S(charset1);
charset2=C$.getEncoding$S(charset2);
var comp = P$.DataTransferer.IndexedComparator.compareIndices$java_util_Map$O$O$Integer(C$.charsets, charset1, charset2, C$.OTHER_CHARSET_INDEX);
if (comp == 0) {
return charset2.compareTo$S(charset1);
}return comp;
});

Clazz.newMeth(C$, 'getEncoding$S', function (charset) {
if (charset == null ) {
return null;
} else if (!(I$[2]||$incl$(2)).isEncodingSupported$S(charset)) {
return "UNSUPPORTED";
} else {
var canonicalName = (I$[2]||$incl$(2)).canonicalName$S(charset);
return (C$.charsets.containsKey$O(canonicalName)) ? canonicalName : charset;
}}, 1);
})()
;
(function(){var C$=Clazz.newClass(P$.DataTransferer, "DataFlavorComparator", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, ['sun.awt.datatransfer.DataTransferer','sun.awt.datatransfer.DataTransferer.IndexedComparator']);
C$.exactTypes = null;
C$.primaryTypes = null;
C$.nonTextRepresentations = null;
C$.textTypes = null;
C$.decodedTextRepresentations = null;
C$.encodedTextRepresentations = null;
C$.UNKNOWN_OBJECT_LOSES = null;
C$.UNKNOWN_OBJECT_WINS = null;
C$.UNKNOWN_OBJECT_LOSES_L = null;
C$.UNKNOWN_OBJECT_WINS_L = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.exactTypes = null;
C$.primaryTypes = null;
C$.nonTextRepresentations = null;
C$.textTypes = null;
C$.decodedTextRepresentations = null;
C$.encodedTextRepresentations = null;
C$.UNKNOWN_OBJECT_LOSES = Integer.$valueOf(-2147483648);
C$.UNKNOWN_OBJECT_WINS = Integer.$valueOf(2147483647);
C$.UNKNOWN_OBJECT_LOSES_L = Long.$valueOf(-9223372036854775808);
C$.UNKNOWN_OBJECT_WINS_L = Long.$valueOf(9223372036854775807);
{
{
var exactTypesMap = Clazz.new_((I$[1]||$incl$(1)).c$$I$F,[4, 1.0]);
exactTypesMap.put$TK$TV("application/x-java-file-list", Integer.$valueOf(0));
C$.exactTypes=(I$[3]||$incl$(3)).unmodifiableMap$java_util_Map(exactTypesMap);
}{
var primaryTypesMap = Clazz.new_((I$[1]||$incl$(1)).c$$I$F,[1, 1.0]);
primaryTypesMap.put$TK$TV("application", Integer.$valueOf(0));
C$.primaryTypes=(I$[3]||$incl$(3)).unmodifiableMap$java_util_Map(primaryTypesMap);
}{
var nonTextRepresentationsMap = Clazz.new_((I$[1]||$incl$(1)).c$$I$F,[3, 1.0]);
nonTextRepresentationsMap.put$TK$TV(Clazz.getClass((I$[4]||$incl$(4))), Integer.$valueOf(0));
C$.nonTextRepresentations=(I$[3]||$incl$(3)).unmodifiableMap$java_util_Map(nonTextRepresentationsMap);
}{
var textTypesMap = Clazz.new_((I$[1]||$incl$(1)).c$$I$F,[16, 1.0]);
textTypesMap.put$TK$TV("text/plain", Integer.$valueOf(0));
textTypesMap.put$TK$TV("application/x-java-serialized-object", Integer.$valueOf(1));
textTypesMap.put$TK$TV("text/calendar", Integer.$valueOf(2));
textTypesMap.put$TK$TV("text/css", Integer.$valueOf(3));
textTypesMap.put$TK$TV("text/directory", Integer.$valueOf(4));
textTypesMap.put$TK$TV("text/parityfec", Integer.$valueOf(5));
textTypesMap.put$TK$TV("text/rfc822-headers", Integer.$valueOf(6));
textTypesMap.put$TK$TV("text/t140", Integer.$valueOf(7));
textTypesMap.put$TK$TV("text/tab-separated-values", Integer.$valueOf(8));
textTypesMap.put$TK$TV("text/uri-list", Integer.$valueOf(9));
textTypesMap.put$TK$TV("text/richtext", Integer.$valueOf(10));
textTypesMap.put$TK$TV("text/enriched", Integer.$valueOf(11));
textTypesMap.put$TK$TV("text/rtf", Integer.$valueOf(12));
textTypesMap.put$TK$TV("text/html", Integer.$valueOf(13));
textTypesMap.put$TK$TV("text/xml", Integer.$valueOf(14));
textTypesMap.put$TK$TV("text/sgml", Integer.$valueOf(15));
C$.textTypes=(I$[3]||$incl$(3)).unmodifiableMap$java_util_Map(textTypesMap);
}{
var decodedTextRepresentationsMap = Clazz.new_((I$[1]||$incl$(1)).c$$I$F,[4, 1.0]);
decodedTextRepresentationsMap.put$TK$TV((I$[2]||$incl$(2)).charArrayClass, Integer.$valueOf(0));
decodedTextRepresentationsMap.put$TK$TV(Clazz.getClass(java.lang.String), Integer.$valueOf(2));
decodedTextRepresentationsMap.put$TK$TV(Clazz.getClass((I$[5]||$incl$(5))), Integer.$valueOf(3));
C$.decodedTextRepresentations=(I$[3]||$incl$(3)).unmodifiableMap$java_util_Map(decodedTextRepresentationsMap);
}{
var encodedTextRepresentationsMap = Clazz.new_((I$[1]||$incl$(1)).c$$I$F,[3, 1.0]);
encodedTextRepresentationsMap.put$TK$TV((I$[2]||$incl$(2)).byteArrayClass, Integer.$valueOf(0));
encodedTextRepresentationsMap.put$TK$TV(Clazz.getClass((I$[4]||$incl$(4))), Integer.$valueOf(2));
C$.encodedTextRepresentations=(I$[3]||$incl$(3)).unmodifiableMap$java_util_Map(encodedTextRepresentationsMap);
}}
;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.flavorToFormatMap = null;
this.charsetComparator = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$Z.apply(this, [true]);
}, 1);

Clazz.newMeth(C$, 'c$$Z', function (order) {
C$.superclazz.c$$Z.apply(this, [order]);
C$.$init$.apply(this);
this.charsetComparator=Clazz.new_((I$[6]||$incl$(6)).c$$Z,[order]);
this.flavorToFormatMap=(I$[3]||$incl$(3)).EMPTY_MAP;
}, 1);

Clazz.newMeth(C$, 'c$$java_util_Map', function (map) {
C$.c$$java_util_Map$Z.apply(this, [map, true]);
}, 1);

Clazz.newMeth(C$, 'c$$java_util_Map$Z', function (map, order) {
C$.superclazz.c$$Z.apply(this, [order]);
C$.$init$.apply(this);
this.charsetComparator=Clazz.new_((I$[6]||$incl$(6)).c$$Z,[order]);
var hashMap = Clazz.new_((I$[1]||$incl$(1)).c$$I,[map.size()]);
hashMap.putAll$java_util_Map(map);
this.flavorToFormatMap=(I$[3]||$incl$(3)).unmodifiableMap$java_util_Map(hashMap);
}, 1);

Clazz.newMeth(C$, ['compare$O$O','compare$TT$TT'], function (obj1, obj2) {
var flavor1 = null;
var flavor2 = null;
if (this.order == true ) {
flavor1=obj1;
flavor2=obj2;
} else {
flavor1=obj2;
flavor2=obj1;
}if (flavor1.equals$java_awt_datatransfer_DataFlavor(flavor2)) {
return 0;
}var comp = 0;
var primaryType1 = flavor1.getPrimaryType();
var subType1 = flavor1.getSubType();
var mimeType1 = primaryType1 + "/" + subType1 ;
var class1 = flavor1.getRepresentationClass();
var primaryType2 = flavor2.getPrimaryType();
var subType2 = flavor2.getSubType();
var mimeType2 = primaryType2 + "/" + subType2 ;
var class2 = flavor2.getRepresentationClass();
if (flavor1.isFlavorTextType() && flavor2.isFlavorTextType() ) {
comp=P$.DataTransferer.IndexedComparator.compareIndices$java_util_Map$O$O$Integer(C$.textTypes, mimeType1, mimeType2, C$.UNKNOWN_OBJECT_LOSES);
if (comp != 0) {
return comp;
}if (P$.DataTransferer.doesSubtypeSupportCharset$java_awt_datatransfer_DataFlavor(flavor1)) {
comp=P$.DataTransferer.IndexedComparator.compareIndices$java_util_Map$O$O$Integer(C$.decodedTextRepresentations, class1, class2, C$.UNKNOWN_OBJECT_LOSES);
if (comp != 0) {
return comp;
}comp=this.charsetComparator.compareCharsets$S$S((I$[2]||$incl$(2)).getTextCharset$java_awt_datatransfer_DataFlavor(flavor1), (I$[2]||$incl$(2)).getTextCharset$java_awt_datatransfer_DataFlavor(flavor2));
if (comp != 0) {
return comp;
}}comp=P$.DataTransferer.IndexedComparator.compareIndices$java_util_Map$O$O$Integer(C$.encodedTextRepresentations, class1, class2, C$.UNKNOWN_OBJECT_LOSES);
if (comp != 0) {
return comp;
}} else {
comp=P$.DataTransferer.IndexedComparator.compareIndices$java_util_Map$O$O$Integer(C$.primaryTypes, primaryType1, primaryType2, C$.UNKNOWN_OBJECT_LOSES);
if (comp != 0) {
return comp;
}comp=P$.DataTransferer.IndexedComparator.compareIndices$java_util_Map$O$O$Integer(C$.exactTypes, mimeType1, mimeType2, C$.UNKNOWN_OBJECT_WINS);
if (comp != 0) {
return comp;
}comp=P$.DataTransferer.IndexedComparator.compareIndices$java_util_Map$O$O$Integer(C$.nonTextRepresentations, class1, class2, C$.UNKNOWN_OBJECT_LOSES);
if (comp != 0) {
return comp;
}}return P$.DataTransferer.IndexedComparator.compareLongs$java_util_Map$O$O$Long(this.flavorToFormatMap, flavor1, flavor2, C$.UNKNOWN_OBJECT_LOSES_L);
});
})()
;
(function(){var C$=Clazz.newClass(P$.DataTransferer, "IndexOrderComparator", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, ['sun.awt.datatransfer.DataTransferer','sun.awt.datatransfer.DataTransferer.IndexedComparator']);
C$.FALLBACK_INDEX = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.FALLBACK_INDEX = Integer.$valueOf(-2147483648);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.indexMap = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_util_Map', function (indexMap) {
C$.superclazz.c$$Z.apply(this, [true]);
C$.$init$.apply(this);
this.indexMap=indexMap;
}, 1);

Clazz.newMeth(C$, 'c$$java_util_Map$Z', function (indexMap, order) {
C$.superclazz.c$$Z.apply(this, [order]);
C$.$init$.apply(this);
this.indexMap=indexMap;
}, 1);

Clazz.newMeth(C$, ['compare$O$O','compare$TT$TT'], function (obj1, obj2) {
if (this.order == false ) {
return -P$.DataTransferer.IndexedComparator.compareIndices$java_util_Map$O$O$Integer(this.indexMap, obj1, obj2, C$.FALLBACK_INDEX);
} else {
return P$.DataTransferer.IndexedComparator.compareIndices$java_util_Map$O$O$Integer(this.indexMap, obj1, obj2, C$.FALLBACK_INDEX);
}});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-05-24 08:47:24
