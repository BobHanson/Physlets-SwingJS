(function(){var P$=Clazz.newPackage("eField4"),I$=[['java.awt.Color','edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ArrowHead");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.p = null;
this.x = 0;
this.y = 0;
this.u = 0;
this.v = 0;
this.s = 0;
this.color = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.s = 4;
this.color = (I$[1]||$incl$(1)).black;
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$D$D$java_awt_Color', function (p, x, y, u, v, c) {
C$.$init$.apply(this);
this.x = x;
this.y = y;
this.u = u;
this.v = v;
this.p = p;
this.color = c;
}, 1);

Clazz.newMeth(C$, 'getX', function () {
return this.x;
});

Clazz.newMeth(C$, 'setX$D', function (x) {
this.x = x;
return;
});

Clazz.newMeth(C$, 'getY', function () {
return this.y;
});

Clazz.newMeth(C$, 'setY$D', function (y) {
this.y = y;
return;
});

Clazz.newMeth(C$, 'getU', function () {
return this.u;
});

Clazz.newMeth(C$, 'setU$D', function (u) {
this.u = u;
return;
});

Clazz.newMeth(C$, 'getV', function () {
return this.v;
});

Clazz.newMeth(C$, 'setV$D', function (v) {
this.v = v;
return;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var x0 = this.p.pixFromX$D(this.x);
var y0 = this.p.pixFromY$D(this.y);
var x1 = this.p.pixFromX$D(this.x + this.u);
var y1 = this.p.pixFromY$D(this.y + this.v);
g.setColor$java_awt_Color(this.color);
(I$[2]||$incl$(2)).drawArrowHead$java_awt_Graphics$I$I$I$I$I(g, x0, y0, x1, y1, this.s);
});

Clazz.newMeth(C$, 'getSize', function () {
return this.s;
});

Clazz.newMeth(C$, 'setSize$I', function (sz) {
this.s = sz;
});

Clazz.newMeth(C$, 'getColor', function () {
return this.color;
});

Clazz.newMeth(C$, 'setColor$java_awt_Color', function (c) {
this.color = c;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-26 19:23:01
