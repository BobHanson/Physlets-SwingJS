(function(){var P$=Clazz.newPackage("circuit"),I$=[['java.awt.Color','circuit.Common','circuit.Part']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Ammeter", null, 'circuit.Part');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I', function (o, c, i1, j1, i2, j2) {
C$.superclazz.c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I.apply(this, [o, c, i1, j1, i2, j2]);
C$.$init$.apply(this);
this.label = "A";
this.voltRMS = 0;
this.currentRMS = 5;
this.showZ = false;
this.showV = false;
this.showCurrent = true;
}, 1);

Clazz.newMeth(C$, 'drawLabel$java_awt_Graphics$I$I$I$I', function (g, x, y, xOff, yOff) {
if (this.label == null ) return;
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawString$S$I$I(this.label, x - 4, y + 5);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'drawSymbol$java_awt_Graphics$I$I$I$I$I', function (g, x1, y1, x2, y2, s) {
g.setColor$java_awt_Color(this.color);
var x = x2 - x1;
var y = -(y2 - y1);
var h = Math.sqrt(x * x + y * y);
if (h < 2 ) return;
var w = (h / 2.0 - 10);
var base_x1 = ((x1 + (x * w) / h)|0);
var base_y1 = ((y1 - (y * w) / h)|0);
var base_x2 = ((x2 - (x * w) / h)|0);
var base_y2 = ((y2 + (y * w) / h)|0);
g.drawLine$I$I$I$I(x1, y1, base_x1, base_y1);
g.drawLine$I$I$I$I(x2, y2, base_x2, base_y2);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).yellow);
g.fillOval$I$I$I$I(((x1 + x2)/2|0) - 10, ((y1 + y2)/2|0) - 10, 20, 20);
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawString$S$I$I("+", (base_x1 - 10), (base_y1 + 2));
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'getMSHint', function () {
var msg = "";
if (this.showCurrent && !this.milliAmp ) msg += (I$[2]||$incl$(2)).LEGEND_AMMETER + this.format3.form$D(this.currentRMS) + " A" ;
if (this.showCurrent && this.milliAmp ) msg += (I$[2]||$incl$(2)).LEGEND_AMMETER + this.format3.form$D(this.currentRMS) + " mA" ;
if (this.showPhase) msg += "    " + (I$[2]||$incl$(2)).LEGEND_CURRENTPHASE + ((this.phase)|0) + " " + (I$[2]||$incl$(2)).DEGREE + "." ;
return msg;
});

Clazz.newMeth(C$, 'getHint', function () {
if (this.customHint != null ) return this.customHint;
if (P$.Part.isMicrosoft()) {
return this.getMSHint();
}var msg = "";
if (this.showCurrent && !this.milliAmp ) msg += (I$[2]||$incl$(2)).LEGEND_AMMETER + this.format3.form$D(this.currentRMS) + " A" ;
if (this.showCurrent && this.milliAmp ) msg += (I$[2]||$incl$(2)).LEGEND_AMMETER + this.format3.form$D(this.currentRMS) + " mA" ;
if (this.showPhase) msg += "   " + (I$[2]||$incl$(2)).CURRENT + " " + (I$[3]||$incl$(3)).phi + "=" + ((this.phase)|0) + (I$[3]||$incl$(3)).degree + "  " ;
return msg;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:20:42
