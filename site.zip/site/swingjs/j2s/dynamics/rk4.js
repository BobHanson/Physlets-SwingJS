(function(){var P$=Clazz.newPackage("dynamics"),I$=[];
var C$=Clazz.newClass(P$, "rk4");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.n = 0;
this.dydx = null;
this.y = null;
this.yout = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'init$I$Z', function (n, bl) {
this.n=n;
this.dydx=Clazz.array(Double.TYPE, [this.n]);
this.yout=Clazz.array(Double.TYPE, [this.n]);
if (bl) {
this.y=this.yout;
return;
}this.y=Clazz.array(Double.TYPE, [this.n]);
});

Clazz.newMeth(C$, 'nextmove$D$DA', function (d, arrd) {
this.y=arrd;
this.core$D$D(0.0, d);
});

Clazz.newMeth(C$, 'nextmove$D', function (d) {
this.core$D$D(0.0, d);
});

Clazz.newMeth(C$, 'core$D$D', function (d, d2) {
var arrd = Clazz.array(Double.TYPE, [this.n]);
var arrd2 = Clazz.array(Double.TYPE, [this.n]);
var arrd3 = Clazz.array(Double.TYPE, [this.n]);
var d3 = d2 * 0.5;
var d4 = d2 / 6.0;
var d5 = d + d3;
this.derivs$D$DA$DA(d5, this.y, this.dydx);
var n = 0;
while (n < this.n){
arrd3[n]=this.y[n] + d3 * this.dydx[n];
++n;
}
this.derivs$D$DA$DA(d5, arrd3, arrd2);
n=0;
while (n < this.n){
arrd3[n]=this.y[n] + d3 * arrd2[n];
++n;
}
this.derivs$D$DA$DA(d5, arrd3, arrd);
n=0;
while (n < this.n){
arrd3[n]=this.y[n] + d2 * arrd[n];
var arrd4 = arrd;
var n2 = n;
arrd4[n2]=arrd4[n2] + arrd2[n];
++n;
}
this.derivs$D$DA$DA(d + d2, arrd3, arrd2);
n=0;
while (n < this.n){
this.yout[n]=this.y[n] + d4 * (this.dydx[n] + arrd2[n] + 2.0 * arrd[n] );
++n;
}
});

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-07-20 18:09:32
