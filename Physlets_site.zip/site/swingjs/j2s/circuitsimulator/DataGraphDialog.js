(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['circuitsimulator.BorderPanel','java.awt.Button','java.awt.TextField','java.awt.Label','edu.davidson.display.SGraph','java.awt.Color',['circuitsimulator.DataGraphDialog','.SymWindow'],['circuitsimulator.DataGraphDialog','.SymAction']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DataGraphDialog", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.Dialog');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$type = null;
this.cb = null;
this.ce = null;
this.fComponentsAdjusted = false;
this.borderCanvas = null;
this.stripChart = null;
this.periodInput = null;
this.label1 = null;
this.dataGraph = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.fComponentsAdjusted = false;
this.borderCanvas = Clazz.new_((I$[1]||$incl$(1)));
this.stripChart = Clazz.new_((I$[2]||$incl$(2)));
this.periodInput = Clazz.new_((I$[3]||$incl$(3)));
this.label1 = Clazz.new_((I$[4]||$incl$(4)));
this.dataGraph = Clazz.new_((I$[5]||$incl$(5)));
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame$circuitsimulator_CircuitBuilder$S', function (parent, cirbuilder, s) {
C$.superclazz.c$$java_awt_Frame.apply(this, [parent]);
C$.$init$.apply(this);
this.cb = cirbuilder;
this.ce = this.cb.currentElement;
this.$type = "" + s;
var title;
if (this.$type.equals$O("v")) title = this.cb.cirProp.getProperty$S("vgraph_title");
 else title = this.cb.cirProp.getProperty$S("igraph_title");
this.setTitle$S(title + " " + this.cb.cirProp.getProperty$S(this.ce.name()) + " " + this.ce.getlabel() );
this.periodInput.setText$S(Double.toString(this.cb.numberofdt * this.cb.dt));
this.setLayout$java_awt_LayoutManager(null);
this.setBackground$java_awt_Color(Clazz.new_((I$[6]||$incl$(6)).c$$I$I$I,[220, 200, 160]));
this.setSize$I$I(550, 393);
this.setVisible$Z(false);
try {
this.borderCanvas.setBevelStyle$S((I$[1]||$incl$(1)).BEVEL_LOWERED);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderCanvas.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.borderCanvas.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.borderCanvas);
this.borderCanvas.setBackground$java_awt_Color((I$[6]||$incl$(6)).white);
this.borderCanvas.setBounds$I$I$I$I(10, 8, 525, 344);
this.add$java_awt_Component(this.stripChart);
this.stripChart.setBackground$java_awt_Color((I$[6]||$incl$(6)).lightGray);
this.stripChart.setBounds$I$I$I$I(11, 359, 107, 24);
this.add$java_awt_Component(this.periodInput);
this.periodInput.setBounds$I$I$I$I(248, 362, 119, 21);
this.label1.setAlignment$I(2);
this.add$java_awt_Component(this.label1);
this.label1.setBounds$I$I$I$I(132, 361, 110, 23);
this.borderCanvas.add$java_awt_Component(this.dataGraph);
this.dataGraph.setBounds$I$I$I$I(15, 18, 500, 320);
var aSymWindow = Clazz.new_((I$[7]||$incl$(7)), [this, null]);
this.addWindowListener$java_awt_event_WindowListener(aSymWindow);
var lSymAction = Clazz.new_((I$[8]||$incl$(8)), [this, null]);
this.stripChart.addActionListener$java_awt_event_ActionListener(lSymAction);
this.stripChart.setLabel$S(this.cb.cirProp.getProperty$S("gmode_strip"));
this.label1.setText$S(this.cb.cirProp.getProperty$S("twindow"));
this.dataGraph.clearSeries$I(1);
this.dataGraph.setSeriesStyle$I$Z$I(1, true, 0);
this.dataGraph.setLabelX$S(this.cb.cirProp.getProperty$S("taxis"));
if (this.$type.equals$O("v")) this.dataGraph.setLabelY$S(this.cb.cirProp.getProperty$S("vaxis"));
 else this.dataGraph.setLabelY$S(this.cb.cirProp.getProperty$S("iaxis"));
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_CircuitBuilder', function (cirbuilder) {
C$.c$$java_awt_Frame$circuitsimulator_CircuitBuilder$S.apply(this, [null, cirbuilder, "v"]);
}, 1);

Clazz.newMeth(C$, 'addNotify', function () {
var d = this.getSize();
C$.superclazz.prototype.addNotify.apply(this, []);
if (this.fComponentsAdjusted) return;
var insets = this.getInsets();
this.setSize$I$I(insets.left + insets.right + d.width , insets.top + insets.bottom + d.height );
var components = this.getComponents();
for (var i = 0; i < components.length; i++) {
var p = components[i].getLocation();
p.translate$I$I(insets.left, insets.top);
components[i].setLocation$java_awt_Point(p);
}
this.fComponentsAdjusted = true;
});

Clazz.newMeth(C$, 'setVisible$Z', function (b) {
if (b) this.setLocation$I$I(100, 100);
C$.superclazz.prototype.setVisible$Z.apply(this, [b]);
});

Clazz.newMeth(C$, 'addData', function () {
this.dataGraph.addDatum$I$D$D(1, this.cb.realt, this.$type.equals$O("v") ? this.ce.getV() : this.ce.getI());
});

Clazz.newMeth(C$, 'clearGraph', function () {
this.dataGraph.setAutoReplaceData$I$Z(1, false);
this.dataGraph.clearSeriesData$I(1);
this.dataGraph.setAutoRefresh$Z(true);
this.dataGraph.setAutoReplaceData$I$Z(1, true);
});

Clazz.newMeth(C$, 'stripChart_ActionPerformed$java_awt_event_ActionEvent', function (event) {
if (this.stripChart.getLabel().equals$O(this.cb.cirProp.getProperty$S("gmode_strip"))) {
var nop = ((Double.$valueOf(this.periodInput.getText()).doubleValue() / (this.cb.dt * this.cb.noc))|0);
this.dataGraph.setSeriesStripChart$I$I$Z(1, nop, true);
this.stripChart.setLabel$S(this.cb.cirProp.getProperty$S("gmode_full"));
} else {
this.dataGraph.setSeriesStripChart$I$I$Z(1, 100, false);
this.stripChart.setLabel$S(this.cb.cirProp.getProperty$S("gmode_strip"));
}});
;
(function(){var C$=Clazz.newClass(P$.DataGraphDialog, "SymWindow", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.WindowAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (event) {
var object = event.getSource();
if (object === this.this$0 ) {
this.this$0.setVisible$Z(false);
}});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.DataGraphDialog, "SymAction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (event) {
var object = event.getSource();
if (object === this.this$0.stripChart ) this.this$0.stripChart_ActionPerformed$java_awt_event_ActionEvent(event);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-06 06:55:33
