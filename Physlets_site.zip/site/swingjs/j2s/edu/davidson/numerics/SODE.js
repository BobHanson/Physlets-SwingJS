(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newClass(P$, "SODE");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-02-22 01:07:16
