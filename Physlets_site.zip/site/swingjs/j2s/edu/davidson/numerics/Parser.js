(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[['java.util.Hashtable','java.util.Vector','java.lang.StringBuffer']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Parser");
C$.LOG10 = 0;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.LOG10 = Math.log(10);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.var_count = 0;
this.var_name = null;
this.var_value = null;
this.number = null;
this.$function = null;
this.postfix_code = null;
this.valid = false;
this.error = 0;
this.ISBOOLEAN = false;
this.INRELATION = false;
this.position = 0;
this.start = 0;
this.num = 0;
this.character = '\0';
this.radian = false;
this.numberindex = 0;
this.refvalue = null;
this.stack = null;
this.references = null;
this.refnames = null;
this.funcname = null;
this.extfunc = null;
this.postfix_code_ints = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$function = "";
this.postfix_code = "";
this.valid = false;
this.ISBOOLEAN = false;
this.INRELATION = false;
this.refvalue = null;
this.stack = Clazz.array(Double.TYPE, [50]);
this.references = null;
this.refnames = null;
this.funcname = Clazz.array(java.lang.String, -1, ["sin", "cos", "tan", "ln", "log", "abs", "int", "frac", "asin", "acos", "atan", "sinh", "cosh", "tanh", "asinh", "acosh", "atanh", "ceil", "floor", "round", "exp", "sqr", "sqrt", "sign", "step", "random", "sen"]);
this.extfunc = Clazz.array(java.lang.String, -1, ["min", "max", "mod", "atan2"]);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (variablecount) {
C$.$init$.apply(this);
this.var_count = variablecount;
this.references = Clazz.new_((I$[1]||$incl$(1)));
this.refnames = Clazz.new_((I$[2]||$incl$(2)));
this.radian = true;
this.var_name = Clazz.array(java.lang.String, [variablecount]);
this.var_value = Clazz.array(Double.TYPE, [variablecount]);
this.number = Clazz.array(Double.TYPE, [200]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
var variablecount = 1;
this.var_count = variablecount;
this.references = Clazz.new_((I$[1]||$incl$(1)));
this.refnames = Clazz.new_((I$[2]||$incl$(2)));
this.radian = true;
this.var_name = Clazz.array(java.lang.String, [variablecount]);
this.var_value = Clazz.array(Double.TYPE, [variablecount]);
this.number = Clazz.array(Double.TYPE, [200]);
}, 1);

Clazz.newMeth(C$, 'adjustVarCount$I', function (variablecount) {
this.var_count = variablecount;
this.references = Clazz.new_((I$[1]||$incl$(1)));
this.refnames = Clazz.new_((I$[2]||$incl$(2)));
this.var_name = Clazz.array(java.lang.String, [variablecount]);
this.var_value = Clazz.array(Double.TYPE, [variablecount]);
this.number = Clazz.array(Double.TYPE, [200]);
});

Clazz.newMeth(C$, 'useRadian', function () {
this.radian = true;
});

Clazz.newMeth(C$, 'useDegree', function () {
this.radian = false;
});

Clazz.newMeth(C$, 'defineVariable$I$S', function (index, name) {
if (index > this.var_count) return;
this.var_name[index - 1] = name;
});

Clazz.newMeth(C$, 'defineVariables$SA', function (newVars) {
if (newVars.length != this.var_count) p$.adjustVarCount$I.apply(this, [newVars.length]);
for (var i = 0; i < newVars.length; i++) {
this.defineVariable$I$S(i + 1, newVars[i]);
}
});

Clazz.newMeth(C$, 'setVariable$I$D', function (index, value) {
if (index > this.var_count) return;
this.var_value[index - 1] = value;
});

Clazz.newMeth(C$, 'setVariable$S$D', function (name, value) {
for (var i = 0; i < this.var_count; i++) {
if (this.var_name[i].equals$O(name)) {
this.var_value[i] = value;
break;
}}
});

Clazz.newMeth(C$, 'removeEscapeCharacter$S', function (str) {
if (str == null  || str.length$() < 1 ) return str;
var sb = Clazz.new_((I$[3]||$incl$(3)).c$$I,[str.length$()]);
for (var i = 0; i < str.length$(); i++) {
if (str.charAt(i) != "\\") sb.append$C(str.charAt(i));
}
return sb.toString();
});

Clazz.newMeth(C$, 'fixUnaryMinus$S', function (str) {
if (str == null  || str.length$() < 1 ) return str;
var sb = Clazz.new_((I$[3]||$incl$(3)).c$$I,[str.length$()]);
if (str.charAt(0) == "-") sb.append$C("0");
for (var i = 0; i < str.length$(); i++) {
if (i > 0 && str.charAt(i) == "-"  && str.charAt(i - 1) == "(" ) sb.append$C("0");
sb.append$C(str.charAt(i));
}
return sb.toString();
});

Clazz.newMeth(C$, 'define$S', function (definition) {
this.$function = definition;
this.$function.toLowerCase();
this.$function = p$.removeEscapeCharacter$S.apply(this, [this.$function]);
this.$function = p$.fixUnaryMinus$S.apply(this, [this.$function]);
this.valid = false;
});

Clazz.newMeth(C$, 'parse', function () {
var allFunction =  String.instantialize(this.$function);
var orgFunction =  String.instantialize(this.$function);
var index;
if (this.valid) return;
this.num = 0;
this.error = 0;
this.references.clear();
this.refnames.removeAllElements();
while ((index = allFunction.lastIndexOf(";")) != -1){
this.$function = allFunction.substring(index + 1) + ')';
allFunction = allFunction.substring(0, index++);
var refname = null;
var separator = this.$function.indexOf(":");
if (separator == -1) {
this.error = 14;
for (this.position = 0; this.position < this.$function.length$(); this.position++) if (this.$function.charAt(this.position) != " ") break;

this.position++;
} else {
refname = this.$function.substring(0, separator);
this.$function = this.$function.substring(separator + 1);
refname = refname.trim();
if (refname.equals$O("")) {
this.error = 15;
this.position = 1;
} else {
index = index+(++separator);
p$.parseSubFunction.apply(this, []);
}}if (this.error != 0) {
this.position = this.position+(index);
break;
}this.references.put$TK$TV(refname, p$.getints$S.apply(this, [this.postfix_code]));
this.refnames.addElement$TE(refname);
}
if (this.error == 0) {
this.$function = allFunction + ')';
p$.parseSubFunction.apply(this, []);
this.postfix_code_ints = p$.getints$S.apply(this, [this.postfix_code]);
}this.$function = orgFunction;
this.valid = (this.error == 0);
});

Clazz.newMeth(C$, 'getints$S', function (postfix_code) {
var a = Clazz.array(Integer.TYPE, [postfix_code.length$()]);
for (var i = a.length; --i >= 0; ) a[i] = postfix_code.codePointAt(i);

return a;
});

Clazz.newMeth(C$, 'evaluate$D$D', function (x, y) {
if (this.var_count != 2) return 0;
this.var_value[0] = x;
this.var_value[1] = y;
return this.evaluate();
});

Clazz.newMeth(C$, 'evaluate$D$D$D', function (x, y, z) {
if (this.var_count != 3) return 0;
this.var_value[0] = x;
this.var_value[1] = y;
this.var_value[2] = z;
return this.evaluate();
});

Clazz.newMeth(C$, 'evaluate$D', function (x) {
if (this.var_count != 1) return 0;
this.var_value[0] = x;
return this.evaluate();
});

Clazz.newMeth(C$, 'evaluate$DA', function (v) {
if (this.var_value.length != v.length) return 0;
System.arraycopy(v, 0, this.var_value, 0, v.length);
return this.evaluate();
});

Clazz.newMeth(C$, 'evaluate', function () {
var size = this.refnames.size();
var result;
if (!this.valid) {
this.error = 3;
return 0;
}this.error = 0;
this.numberindex = 0;
if (size != 0) {
var orgPFC = this.postfix_code_ints;
this.refvalue = Clazz.array(Double.TYPE, [size]);
for (var i = 0; i < size; i++) {
var name = this.refnames.elementAt$I(i);
this.postfix_code_ints = this.references.get$O(name);
result = p$.evaluateSubFunction.apply(this, []);
if (this.error != 0) {
this.postfix_code_ints = orgPFC;
this.refvalue = null;
return result;
}this.refvalue[i] = result;
}
this.postfix_code_ints = orgPFC;
}result = p$.evaluateSubFunction.apply(this, []);
this.refvalue = null;
if (Double.isNaN(result)) result = 0.0;
return result;
});

Clazz.newMeth(C$, 'getErrorCode', function () {
return this.error;
});

Clazz.newMeth(C$, 'getErrorString', function () {
return C$.toErrorString$I(this.error);
});

Clazz.newMeth(C$, 'getErrorPosition', function () {
return this.position;
});

Clazz.newMeth(C$, 'toErrorString$I', function (errorcode) {
var s = "";
switch (errorcode) {
case 0:
s = "no error";
break;
case 1:
s = "syntax error";
break;
case 2:
s = "parenthesis expected";
break;
case 3:
s = "uncompiled function";
break;
case 4:
s = "expression expected";
break;
case 5:
s = "unknown identifier";
break;
case 6:
s = "operator expected";
break;
case 7:
s = "parentheses not match";
break;
case 8:
s = "internal code damaged";
break;
case 9:
s = "execution stack overflow";
break;
case 10:
s = "too many constants";
break;
case 11:
s = "comma expected";
break;
case 12:
s = "invalid operand type";
break;
case 13:
s = "invalid operator";
break;
case 14:
s = "bad reference definition (: expected)";
break;
case 15:
s = "reference name expected";
break;
}
return s;
}, 1);

Clazz.newMeth(C$, 'getFunctionString', function () {
return this.$function;
});

Clazz.newMeth(C$, 'skipSpaces', function () {
try {
while (this.$function.charAt(this.position - 1) == " ")this.position++;

this.character = this.$function.charAt(this.position - 1);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.StringIndexOutOfBoundsException")){
throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[7]);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getNextCharacter', function () {
this.position++;
try {
this.character = this.$function.charAt(this.position - 1);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.StringIndexOutOfBoundsException")){
throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[7]);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'addCode$I', function (code) {
this.postfix_code += String.fromCharCode(code);
});

Clazz.newMeth(C$, 'scanNumber', function () {
var numstr = "";
var value;
if (this.num == 200) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[10]);
if (this.character != ".") do {
numstr += this.character;
p$.getNextCharacter.apply(this, []);
} while ((this.character >= "0") && (this.character <= "9") );
 else {
numstr += "0";
}if (this.character == ".") {
do {
numstr += this.character;
p$.getNextCharacter.apply(this, []);
} while ((this.character >= "0") && (this.character <= "9") );
}if (this.character == "e") {
numstr += this.character;
p$.getNextCharacter.apply(this, []);
if ((this.character == "+") || (this.character == "-") ) {
numstr += this.character;
p$.getNextCharacter.apply(this, []);
}while ((this.character >= "0") && (this.character <= "9") ){
numstr += this.character;
p$.getNextCharacter.apply(this, []);
}
}try {
value = Double.$valueOf(numstr).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
this.position = this.start;
throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[1]);
} else {
throw e;
}
}
this.number[this.num++] = value;
p$.addCode$I.apply(this, ["\u00ff".$c()]);
});

Clazz.newMeth(C$, 'scanNonNumeric', function () {
var stream = "";
if ((this.character == "*") || (this.character == "/") || (this.character == "^") || (this.character == ")") || (this.character == ",") || (this.character == "<") || (this.character == ">") || (this.character == "=") || (this.character == "&") || (this.character == "|")  ) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[1]);
do {
stream += this.character;
p$.getNextCharacter.apply(this, []);
} while (!((this.character == " ") || (this.character == "+") || (this.character == "-") || (this.character == "*") || (this.character == "/") || (this.character == "^") || (this.character == "(") || (this.character == ")") || (this.character == ",") || (this.character == "<") || (this.character == ">") || (this.character == "=") || (this.character == "&") || (this.character == "|")  ));
if (stream.equals$O("pi")) {
p$.addCode$I.apply(this, ["\u00fd".$c()]);
return;
} else if (stream.equals$O("e")) {
p$.addCode$I.apply(this, ["\u00fe".$c()]);
return;
}if (stream.equals$O("if")) {
p$.skipSpaces.apply(this, []);
if (this.character != "(") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[2]);
p$.scanAndParse.apply(this, []);
if (this.character != ",") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[11]);
p$.addCode$I.apply(this, ["\u0008".$c()]);
var savecode =  String.instantialize(this.postfix_code);
this.postfix_code = "";
p$.scanAndParse.apply(this, []);
if (this.character != ",") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[11]);
p$.addCode$I.apply(this, ["\u0001".$c()]);
savecode += String.fromCharCode((this.postfix_code.length$() + 2));
savecode += this.postfix_code;
this.postfix_code = "";
p$.scanAndParse.apply(this, []);
if (this.character != ")") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[2]);
savecode += String.fromCharCode((this.postfix_code.length$() + 1));
savecode += this.postfix_code;
this.postfix_code =  String.instantialize(savecode);
p$.getNextCharacter.apply(this, []);
return;
}for (var i = 0; i < 27; i++) {
if (stream.equals$O(this.funcname[i])) {
p$.skipSpaces.apply(this, []);
if (this.character != "(") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[2]);
p$.scanAndParse.apply(this, []);
if (this.character != ")") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[2]);
p$.getNextCharacter.apply(this, []);
p$.addCode$I.apply(this, [String.fromCharCode((i + 1000)).$c()]);
return;
}}
for (var i = 0; i < 4; i++) {
if (stream.equals$O(this.extfunc[i])) {
p$.skipSpaces.apply(this, []);
if (this.character != "(") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[2]);
p$.scanAndParse.apply(this, []);
if (this.character != ",") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[11]);
var savecode =  String.instantialize(this.postfix_code);
this.postfix_code = "";
p$.scanAndParse.apply(this, []);
if (this.character != ")") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[2]);
p$.getNextCharacter.apply(this, []);
savecode += this.postfix_code;
this.postfix_code =  String.instantialize(savecode);
p$.addCode$I.apply(this, [String.fromCharCode((i + 1027)).$c()]);
return;
}}
for (var i = 0; i < this.var_count; i++) {
if (stream.equals$O(this.var_name[i])) {
p$.addCode$I.apply(this, [String.fromCharCode((i + 2000)).$c()]);
return;
}}
var index = this.refnames.indexOf$O(stream);
if (index != -1) {
p$.addCode$I.apply(this, [String.fromCharCode((index + 3000)).$c()]);
return;
}this.position = this.start;
throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[5]);
});

Clazz.newMeth(C$, 'getIdentifier', function () {
var negate = false;
p$.getNextCharacter.apply(this, []);
p$.skipSpaces.apply(this, []);
if (this.character == "!") {
p$.getNextCharacter.apply(this, []);
p$.skipSpaces.apply(this, []);
if (this.character != "(") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[2]);
p$.scanAndParse.apply(this, []);
if (this.character != ")") throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[2]);
if (!this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
p$.addCode$I.apply(this, ["\u000c".$c()]);
p$.getNextCharacter.apply(this, []);
return;
}this.ISBOOLEAN = false;
while ((this.character == "+") || (this.character == "-") ){
if (this.character == "-") negate = !negate;
p$.getNextCharacter.apply(this, []);
p$.skipSpaces.apply(this, []);
}
this.start = this.position;
if (((this.character >= "0") && (this.character <= "9") ) || this.character == "." ) p$.scanNumber.apply(this, []);
 else if (this.character == "(") {
p$.scanAndParse.apply(this, []);
p$.getNextCharacter.apply(this, []);
} else p$.scanNonNumeric.apply(this, []);
p$.skipSpaces.apply(this, []);
if (negate) p$.addCode$I.apply(this, ["_".$c()]);
});

Clazz.newMeth(C$, 'arithmeticLevel3', function () {
var repcount = 0;
if (this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
do {
p$.getIdentifier.apply(this, []);
if (this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
repcount++;
} while (this.character == "^");
for (var i = 1; i <= repcount; i++) p$.addCode$I.apply(this, ["^".$c()]);

});

Clazz.newMeth(C$, 'arithmeticLevel2', function () {
if (this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
do {
var operator = this.character;
p$.getIdentifier.apply(this, []);
if (this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
if (this.character == "^") p$.arithmeticLevel3.apply(this, []);
p$.addCode$I.apply(this, [operator.$c()]);
} while ((this.character == "*") || (this.character == "/") );
});

Clazz.newMeth(C$, 'arithmeticLevel1', function () {
if (this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
do {
var operator = this.character;
p$.getIdentifier.apply(this, []);
if (this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
if (this.character == "^") p$.arithmeticLevel3.apply(this, []);
 else if ((this.character == "*") || (this.character == "/") ) p$.arithmeticLevel2.apply(this, []);
p$.addCode$I.apply(this, [operator.$c()]);
} while ((this.character == "+") || (this.character == "-") );
});

Clazz.newMeth(C$, 'relationLevel', function () {
var code = "\u0000";
if (this.INRELATION) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[13]);
this.INRELATION = true;
if (this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
switch (this.character.$c()) {
case 61:
code = String.fromCharCode(7);
break;
case 60:
code = String.fromCharCode(2);
p$.getNextCharacter.apply(this, []);
if (this.character == ">") code = String.fromCharCode(6);
 else if (this.character == "=") code = String.fromCharCode(4);
 else this.position--;
break;
case 62:
code = String.fromCharCode(3);
p$.getNextCharacter.apply(this, []);
if (this.character == "=") code = String.fromCharCode(5);
 else this.position--;
break;
}
p$.scanAndParse.apply(this, []);
this.INRELATION = false;
if (this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
p$.addCode$I.apply(this, [code.$c()]);
this.ISBOOLEAN = true;
});

Clazz.newMeth(C$, 'booleanLevel', function () {
if (!this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
var operator = this.character;
p$.scanAndParse.apply(this, []);
if (!this.ISBOOLEAN) throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[12]);
switch (operator.$c()) {
case 38:
p$.addCode$I.apply(this, ["\u000a".$c()]);
break;
case 124:
p$.addCode$I.apply(this, ["\u000b".$c()]);
break;
}
});

Clazz.newMeth(C$, 'scanAndParse', function () {
p$.getIdentifier.apply(this, []);
do {
switch (this.character.$c()) {
case 43:
case 45:
p$.arithmeticLevel1.apply(this, []);
break;
case 42:
case 47:
p$.arithmeticLevel2.apply(this, []);
break;
case 94:
p$.arithmeticLevel3.apply(this, []);
break;
case 44:
case 41:
return;
case 61:
case 60:
case 62:
p$.relationLevel.apply(this, []);
break;
case 38:
case 124:
p$.booleanLevel.apply(this, []);
break;
default:
throw Clazz.new_(Clazz.load('edu.davidson.numerics.ParserException').c$$I,[6]);
}
} while (true);
});

Clazz.newMeth(C$, 'parseSubFunction', function () {
this.position = 0;
this.postfix_code = "";
this.postfix_code_ints = Clazz.array(Integer.TYPE, [0]);
this.INRELATION = false;
this.ISBOOLEAN = false;
try {
p$.scanAndParse.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "edu.davidson.numerics.ParserException")){
this.error = e.getErrorCode();
if ((this.error == 1) && (this.postfix_code == "") ) this.error = 4;
} else {
throw e;
}
}
if ((this.error == 0) && (this.position != this.$function.length$()) ) this.error = 7;
});

Clazz.newMeth(C$, 'builtInFunction$I$D', function ($function, parameter) {
switch ($function) {
case 0:
if (this.radian) return Math.sin(parameter);
 else return Math.sin(parameter * 0.017453292519943295);
case 1:
if (this.radian) return Math.cos(parameter);
 else return Math.cos(parameter * 0.017453292519943295);
case 2:
if (this.radian) return Math.tan(parameter);
 else return Math.tan(parameter * 0.017453292519943295);
case 3:
return Math.log(parameter);
case 4:
return Math.log(parameter) / C$.LOG10;
case 5:
return Math.abs(parameter);
case 6:
return Math.rint(parameter);
case 7:
return parameter - Math.rint(parameter);
case 8:
if (this.radian) return Math.asin(parameter);
 else return Math.asin(parameter) / 0.017453292519943295;
case 9:
if (this.radian) return Math.acos(parameter);
 else return Math.acos(parameter) / 0.017453292519943295;
case 10:
if (this.radian) return Math.atan(parameter);
 else return Math.atan(parameter) / 0.017453292519943295;
case 11:
return (Math.exp(parameter) - Math.exp(-parameter)) / 2;
case 12:
return (Math.exp(parameter) + Math.exp(-parameter)) / 2;
case 13:
var a = Math.exp(parameter);
var b = Math.exp(-parameter);
return (a - b) / (a + b);
case 14:
return Math.log(parameter + Math.sqrt(parameter * parameter + 1));
case 15:
return Math.log(parameter + Math.sqrt(parameter * parameter - 1));
case 16:
return Math.log((1 + parameter) / (1 - parameter)) / 2;
case 17:
return Math.ceil(parameter);
case 18:
return Math.floor(parameter);
case 19:
return Math.round(parameter);
case 20:
return Math.exp(parameter);
case 21:
return parameter * parameter;
case 22:
return Math.sqrt(parameter);
case 23:
if (parameter == 0.0 ) return 0;
 else if (parameter > 0.0 ) return 1;
 else return -1;
case 24:
if (parameter < 0 ) return 0;
 else return 1;
case 25:
return parameter * Math.random();
case 26:
if (this.radian) return Math.sin(parameter);
 else return Math.sin(parameter * 0.017453292519943295);
default:
this.error = 8;
return NaN;
}
});

Clazz.newMeth(C$, 'builtInExtFunction$I$D$D', function ($function, param1, param2) {
switch ($function) {
case 0:
return Math.min(param1, param2);
case 1:
return Math.max(param1, param2);
case 2:
return Math.IEEEremainder(param1, param2);
case 3:
return Math.atan2(param1, param2);
default:
this.error = 8;
return NaN;
}
});

Clazz.newMeth(C$, 'evaluateSubFunction', function () {
var stack_pointer = -1;
var code_pointer = 0;
var destination;
var code;
var codeLength = this.postfix_code_ints.length;
while (true){
try {
if (code_pointer == codeLength) return this.stack[0];
code = this.postfix_code_ints[code_pointer++];
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.StringIndexOutOfBoundsException")){
return this.stack[0];
} else {
throw e;
}
}
try {
switch (code) {
case 43:
this.stack[stack_pointer - 1] += this.stack[stack_pointer];
stack_pointer--;
break;
case 45:
this.stack[stack_pointer - 1] -= this.stack[stack_pointer];
stack_pointer--;
break;
case 42:
this.stack[stack_pointer - 1] *= this.stack[stack_pointer];
stack_pointer--;
break;
case 47:
if (this.stack[stack_pointer] != 0 ) this.stack[stack_pointer - 1] /= this.stack[stack_pointer];
 else this.stack[stack_pointer - 1] /= 1.0E-128;
stack_pointer--;
break;
case 94:
this.stack[stack_pointer - 1] = Math.pow(this.stack[stack_pointer - 1], this.stack[stack_pointer]);
stack_pointer--;
break;
case 95:
this.stack[stack_pointer] = -this.stack[stack_pointer];
break;
case 1:
destination = code_pointer + this.postfix_code_ints[code_pointer++];
while (code_pointer < destination){
if (this.postfix_code_ints[code_pointer++] == 255) this.numberindex++;
}
break;
case 2:
stack_pointer--;
this.stack[stack_pointer] = (this.stack[stack_pointer] < this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 3:
stack_pointer--;
this.stack[stack_pointer] = (this.stack[stack_pointer] > this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 4:
stack_pointer--;
this.stack[stack_pointer] = (this.stack[stack_pointer] <= this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 5:
stack_pointer--;
this.stack[stack_pointer] = (this.stack[stack_pointer] >= this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 7:
stack_pointer--;
this.stack[stack_pointer] = (this.stack[stack_pointer] == this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 6:
stack_pointer--;
this.stack[stack_pointer] = (this.stack[stack_pointer] != this.stack[stack_pointer + 1] ) ? 1.0 : 0.0;
break;
case 8:
if (this.stack[stack_pointer--] == 0.0 ) {
destination = code_pointer + this.postfix_code_ints[code_pointer++];
while (code_pointer < destination){
if (this.postfix_code_ints[code_pointer++] == 255) this.numberindex++;
}
} else code_pointer++;
break;
case 9:
break;
case 10:
stack_pointer--;
if ((this.stack[stack_pointer] != 0.0 ) && (this.stack[stack_pointer + 1] != 0.0 ) ) this.stack[stack_pointer] = 1.0;
 else this.stack[stack_pointer] = 0.0;
break;
case 11:
stack_pointer--;
if ((this.stack[stack_pointer] != 0.0 ) || (this.stack[stack_pointer + 1] != 0.0 ) ) this.stack[stack_pointer] = 1.0;
 else this.stack[stack_pointer] = 0.0;
break;
case 12:
this.stack[stack_pointer] = (this.stack[stack_pointer] == 0.0 ) ? 1.0 : 0.0;
break;
case 255:
this.stack[++stack_pointer] = this.number[this.numberindex++];
break;
case 253:
this.stack[++stack_pointer] = 3.141592653589793;
break;
case 254:
this.stack[++stack_pointer] = 2.718281828459045;
break;
default:
if (code >= 3000) this.stack[++stack_pointer] = this.refvalue[code - 3000];
 else if (code >= 2000) this.stack[++stack_pointer] = this.var_value[code - 2000];
 else if (code >= 1027) {
this.stack[stack_pointer - 1] = p$.builtInExtFunction$I$D$D.apply(this, [code - 1027, this.stack[stack_pointer - 1], this.stack[stack_pointer]]);
stack_pointer--;
} else if (code >= 1000) {
this.stack[stack_pointer] = p$.builtInFunction$I$D.apply(this, [code - 1000, this.stack[stack_pointer]]);
} else {
this.error = 8;
return NaN;
}}
} catch (e$$) {
if (Clazz.exceptionOf(e$$, "java.lang.ArrayIndexOutOfBoundsException")){
var oe = e$$;
{
this.error = 9;
return NaN;
}
} else if (Clazz.exceptionOf(e$$, "java.lang.NullPointerException")){
var ne = e$$;
{
this.error = 8;
return NaN;
}
} else {
throw e$$;
}
}
}
});
})();
//Created 2018-02-25 19:20:27
