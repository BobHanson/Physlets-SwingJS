(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'edu.davidson.tools.SUtil']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "SquareWave", null, 'circuitsimulator.Source');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.dutyfactor=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.dutyfactor=0.5;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$I$S$D$D$D', function (circ, pol, r, c, t, amp, ph, freq) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circ, pol, r, c, t]);
C$.$init$.apply(this);
this.amplitude=amp;
this.dutyfactor=ph;
this.frequency=freq;
this.$function="(t%(1/" + new Double(this.frequency).toString() + ")<(" + new Double(this.dutyfactor).toString() + "/" + new Double(this.frequency).toString() + ") ? " + new Double(this.amplitude).toString() + ":0" ;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getV$D', function (t) {
return (t % (1 / this.frequency) < (this.dutyfactor / this.frequency) ) ? this.amplitude : 0;
});

Clazz.newMeth(C$, 'parsefunction$', function () {
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",amp=" + new Double(this.amplitude).toString() + ",dutyfactor=" + new Double(this.dutyfactor).toString() + ",freq=" + new Double(this.frequency).toString() ;
});

Clazz.newMeth(C$, 'set$S', function (list) {
var ret=C$.superclazz.prototype.set$S.apply(this, [list]);
if (Clazz.load('edu.davidson.tools.SUtil').parameterExist$S$S(list, "amp=")) this.amplitude=$I$(1).getParam$S$S(list, "amp=");
if ($I$(1).parameterExist$S$S(list, "dutyfactor=")) this.dutyfactor=$I$(1).getParam$S$S(list, "dutyfactor=");
return ret;
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:16 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
