(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newClass(P$, "ParserException", null, 'Exception');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.errorcode = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I', function (code) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.errorcode = code;
}, 1);

Clazz.newMeth(C$, 'getErrorCode', function () {
return this.errorcode;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:27
