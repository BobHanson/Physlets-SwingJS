(function(){var P$=Clazz.newPackage("mathapps"),I$=[['edu.davidson.graphics.EtchedBorder','a2s.Button','a2s.Label','java.awt.FlowLayout','a2s.Panel','edu.davidson.display.SNumber','edu.davidson.display.SInteger','a2s.TextField','java.awt.BorderLayout','mathapps.VerticalFlowLayout','Boolean','edu.davidson.tools.SApplet','mathapps.Analytic$1','java.awt.Color','a2s.Frame','java.awt.Toolkit','edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Analytic", null, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataSource', 'edu.davidson.tools.SStepable']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.min = 0;
this.max = 0;
this.numPts = 0;
this.functionStr = null;
this.variableStr = null;
this.showControls = false;
this.explicitTime = false;
this.validFunction = false;
this.dx = 0;
this.varStrings = null;
this.ds = null;
this.parser = null;
this.etchedBorder1 = null;
this.setBtn = null;
this.maxLabel = null;
this.flowLayout1 = null;
this.buttonPanel = null;
this.numLabel = null;
this.maxField = null;
this.minField = null;
this.panel3 = null;
this.panel2 = null;
this.panel1 = null;
this.numField = null;
this.minLabel2 = null;
this.panel4 = null;
this.label1 = null;
this.funcField = null;
this.borderLayout1 = null;
this.verticalFlowLayout1 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.explicitTime = false;
this.validFunction = false;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "n"]);
this.ds = null;
this.parser = null;
this.etchedBorder1 = Clazz.new_((I$[1]||$incl$(1)));
this.setBtn = Clazz.new_((I$[2]||$incl$(2)));
this.maxLabel = Clazz.new_((I$[3]||$incl$(3)));
this.flowLayout1 = Clazz.new_((I$[4]||$incl$(4)));
this.buttonPanel = Clazz.new_((I$[5]||$incl$(5)));
this.numLabel = Clazz.new_((I$[3]||$incl$(3)));
this.maxField = Clazz.new_((I$[6]||$incl$(6)));
this.minField = Clazz.new_((I$[6]||$incl$(6)));
this.panel3 = Clazz.new_((I$[5]||$incl$(5)));
this.panel2 = Clazz.new_((I$[5]||$incl$(5)));
this.panel1 = Clazz.new_((I$[5]||$incl$(5)));
this.numField = Clazz.new_((I$[7]||$incl$(7)));
this.minLabel2 = Clazz.new_((I$[3]||$incl$(3)));
this.panel4 = Clazz.new_((I$[5]||$incl$(5)));
this.label1 = Clazz.new_((I$[3]||$incl$(3)));
this.funcField = Clazz.new_((I$[8]||$incl$(8)));
this.borderLayout1 = Clazz.new_((I$[9]||$incl$(9)));
this.verticalFlowLayout1 = Clazz.new_((I$[10]||$incl$(10)));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.min=Double.$valueOf(this.getParameter$S$S("Min", "0")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.max=Double.$valueOf(this.getParameter$S$S("Max", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.numPts=Integer.parseInt(this.getParameter$S$S("NumPts", "100"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.functionStr=this.getParameter$S$S("Function", "sin(x)/x");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.variableStr=this.getParameter$S$S("Variable", "x");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls=(I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.buttonPanel.setVisible$Z(this.showControls);
this.funcField.setText$S(this.functionStr);
this.setFuncion$S$S(this.functionStr, this.variableStr);
this.setNumPts$I(this.numPts);
(I$[12]||$incl$(12)).addDataSource$O(this);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setBtn.setLabel$S("Set");
this.setBtn.setLabel$S("Set");
this.setBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Analytic$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['mathapps.Analytic'].setBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[13]||$incl$(13)).$init$, [this, null])));
this.maxLabel.setAlignment$I(2);
this.maxLabel.setText$S("Max");
this.maxLabel.setAlignment$I(2);
this.maxLabel.setText$S("Max");
this.buttonPanel.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
this.buttonPanel.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.maxField.setValue$D(100.0);
this.numField.setValue$I(10);
this.minLabel2.setText$S("Min");
this.minLabel2.setAlignment$I(2);
this.minLabel2.setAlignment$I(2);
this.minLabel2.setText$S("Min");
this.etchedBorder1.setBackground$java_awt_Color((I$[14]||$incl$(14)).lightGray);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.verticalFlowLayout1);
this.label1.setAlignment$I(2);
this.label1.setText$S("f(x,t) = ");
this.funcField.setText$S("textField1");
this.panel4.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.add$java_awt_Component$O(this.etchedBorder1, null);
this.etchedBorder1.add$java_awt_Component$O(this.buttonPanel, null);
this.buttonPanel.add$java_awt_Component$O(this.setBtn, null);
this.buttonPanel.add$java_awt_Component$O(this.panel3, null);
this.panel3.add$java_awt_Component$O(this.minLabel2, null);
this.panel3.add$java_awt_Component$O(this.minField, null);
this.buttonPanel.add$java_awt_Component$O(this.panel2, null);
this.panel2.add$java_awt_Component$O(this.maxLabel, null);
this.panel2.add$java_awt_Component$O(this.maxField, null);
this.buttonPanel.add$java_awt_Component$O(this.panel1, null);
this.panel1.add$java_awt_Component$O(this.numLabel, null);
this.panel1.add$java_awt_Component$O(this.numField, null);
this.etchedBorder1.add$java_awt_Component$O(this.panel4, null);
this.panel4.add$java_awt_Component$O(this.label1, "West");
this.panel4.add$java_awt_Component$O(this.funcField, "Center");
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Analytic Physlet evaluates an analytic function at a specified number of points.";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Min", "double", "Minimum value"]), Clazz.array(java.lang.String, -1, ["Max", "double", "Maximum value"]), Clazz.array(java.lang.String, -1, ["NumPts", "int", "Number of Points"]), Clazz.array(java.lang.String, -1, ["Function", "String", "The function string"]), Clazz.array(java.lang.String, -1, ["Variable", "String", "The independent variable."]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the user interface"])]);
return pinfo;
});

Clazz.newMeth(C$, 'main', function (args) {
var applet = Clazz.new_(C$);
applet.$isStandalone=true;
var frame;
frame=((
(function(){var C$=Clazz.newClass(P$, "Analytic$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('a2s.Frame'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'processWindowEvent$java_awt_event_WindowEvent', function (e) {
C$.superclazz.prototype.processWindowEvent$java_awt_event_WindowEvent.apply(this, [e]);
if (e.getID() == 201) {
System.exit(0);
}});

Clazz.newMeth(C$, ['setTitle$S','setTitle'], function (title) {
C$.superclazz.prototype.setTitle$S.apply(this, [title]);
this.enableEvents$J(64);
});
})()
), Clazz.new_((I$[15]||$incl$(15)), [this, null],P$.Analytic$2));
frame.setTitle$S("Applet Frame");
frame.add$java_awt_Component$O(applet, "Center");
applet.init();
applet.start();
frame.setSize$I$I(400, 320);
var d = (I$[16]||$incl$(16)).getDefaultToolkit().getScreenSize();
frame.setLocation$I$I(((d.width - frame.getSize().width)/2|0), ((d.height - frame.getSize().height)/2|0));
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, ['setNumPts$I','setNumPts'], function (n) {
if (n < 1) {
System.out.println$S("Number of points must be >0.");
}this.numPts=Math.max(1, n);
this.dx=(this.max - this.min) / (this.numPts - 1);
this.ds=Clazz.array(Double.TYPE, [this.numPts, 3]);
this.setMinMax$D$D(this.min, this.max);
if (this.showControls && this.getBounds().width > 50 ) {
this.numField.setValue$I(this.numPts);
}});

Clazz.newMeth(C$, ['setMinMax$D$D','setMinMax'], function (min_, max_) {
if (this.parser == null  || !this.validFunction ) {
System.out.println$S("Invalid function.");
return;
}this.max=max_;
this.min=min_;
if (this.max < this.min ) {
System.out.println$S("Maximum must be >  minimum.");
var temp = this.max;
this.max=this.min;
this.min=temp;
}if (this.max == this.min ) {
System.out.println$S("Maximum cannot be =  minimum.");
this.max=this.max + 1.0;
}this.dx=(this.max - this.min) / (this.numPts - 1);
var val = this.min;
var time = this.clock.getTime();
for (var i = 0; i < this.numPts; i++) {
this.ds[i][0]=val;
if (this.explicitTime) this.ds[i][1]=this.parser.evaluate$D$D(val, time);
 else this.ds[i][1]=this.parser.evaluate$D(val);
this.ds[i][2]=i;
val += this.dx;
}
if (this.showControls && this.getBounds().width > 50 ) {
this.minField.setValue$D(this.min);
this.maxField.setValue$D(this.max);
}this.updateDataConnections();
});

Clazz.newMeth(C$, ['getValue$D','getValue'], function (x) {
if (this.parser == null ) return 0;
if (this.explicitTime) return this.parser.evaluate$D$D(x, this.clock.getTime());
 else return this.parser.evaluate$D(x);
});

Clazz.newMeth(C$, 'evaluate', function () {
var time = this.clock.getTime();
for (var i = 0; i < this.numPts; i++) {
if (this.explicitTime) this.ds[i][1]=this.parser.evaluate$D$D(this.ds[i][0], time);
 else this.ds[i][1]=this.parser.evaluate$D(this.ds[i][0]);
}
});

Clazz.newMeth(C$, 'parseOneVariable$S', function (string) {
var oneFunc = Clazz.new_((I$[17]||$incl$(17)).c$$I,[1]);
var str =  String.instantialize(string);
oneFunc.defineVariable$I$S(1, this.variableStr);
oneFunc.define$S(str.toLowerCase());
oneFunc.parse();
if (oneFunc.getErrorCode() != 0) {
this.validFunction=false;
return false;
}this.validFunction=true;
this.explicitTime=false;
this.parser=oneFunc;
this.functionStr=string;
return true;
});

Clazz.newMeth(C$, 'parseTwoVariables$S', function (string) {
var twoFunc = Clazz.new_((I$[17]||$incl$(17)).c$$I,[2]);
var str =  String.instantialize(string);
twoFunc.defineVariable$I$S(1, this.variableStr);
twoFunc.defineVariable$I$S(2, "t");
twoFunc.define$S(str.toLowerCase());
twoFunc.parse();
if (twoFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse f(x,t)): " + str);
System.out.println$S("Parse error in MathFunction: " + twoFunc.getErrorString() + " at function 1, position " + twoFunc.getErrorPosition() );
p$.parseOneVariable$S.apply(this, ["0"]);
this.validFunction=false;
return false;
}this.validFunction=true;
this.explicitTime=true;
this.parser=twoFunc;
this.functionStr=string;
return true;
});

Clazz.newMeth(C$, 'reset', function () {
this.clock.stopClock();
this.clock.setTime$D(0);
this.evaluate();
this.updateDataConnections();
});

Clazz.newMeth(C$, ['setFuncion$S$S','setFuncion'], function ($function, variable) {
this.variableStr= String.instantialize(variable.trim().toLowerCase());
var str = $function.trim();
if (!p$.parseOneVariable$S.apply(this, [str])) p$.parseTwoVariables$S.apply(this, [str]);
if (this.ds == null ) this.setNumPts$I(this.numPts);
 else this.setMinMax$D$D(this.min, this.max);
return this.validFunction;
});

Clazz.newMeth(C$, ['setFunctionStr$S','setFunctionStr'], function ($function) {
var str = $function.trim();
this.setFuncion$S$S(str, this.variableStr);
return this.validFunction;
});

Clazz.newMeth(C$, ['getFunctionStr$S','getFunctionStr'], function (string) {
return this.functionStr;
});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
if (this.parser == null  || !this.validFunction ) {
System.out.println$S("Invalid function.");
return;
}if (this.explicitTime) this.evaluate();
this.updateDataConnections();
});

Clazz.newMeth(C$, 'setBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.min=this.minField.getValue();
this.max=this.maxField.getValue();
this.setFunctionStr$S(this.funcField.getText());
this.setNumPts$I(this.numField.getValue());
});
})();
//Created 2018-07-23 12:59:40 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
