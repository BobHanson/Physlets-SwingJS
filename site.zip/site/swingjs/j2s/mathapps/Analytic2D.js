(function(){var P$=Clazz.newPackage("mathapps"),I$=[['edu.davidson.graphics.EtchedBorder','a2s.Panel','a2s.Button','a2s.TextField','a2s.Label','java.awt.BorderLayout','mathapps.VerticalFlowLayout','java.awt.FlowLayout','edu.davidson.display.SNumber','edu.davidson.display.SInteger','Boolean','edu.davidson.tools.SApplet','java.awt.Color','mathapps.Analytic2D$1','mathapps.Analytic','a2s.Frame','java.awt.Toolkit','edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Analytic2D", null, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataSource', 'edu.davidson.tools.SStepable']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.xmin = 0;
this.ymin = 0;
this.xmax = 0;
this.ymax = 0;
this.xPts = 0;
this.yPts = 0;
this.functionStr = null;
this.xVariableStr = null;
this.yVariableStr = null;
this.showControls = false;
this.explicitTime = false;
this.validFunction = false;
this.dx = 0;
this.dy = 0;
this.varStrings = null;
this.ds = null;
this.parser = null;
this.etchedBorder1 = null;
this.panel5 = null;
this.panel6 = null;
this.setBtn = null;
this.funcField = null;
this.label1 = null;
this.borderLayout1 = null;
this.borderLayout2 = null;
this.verticalFlowLayout1 = null;
this.maxLabel1 = null;
this.buttonPanel1 = null;
this.flowLayout2 = null;
this.numLabel1 = null;
this.yMaxField = null;
this.yMinField = null;
this.panel4 = null;
this.panel7 = null;
this.panel8 = null;
this.yNumField = null;
this.minLabel3 = null;
this.maxLabel = null;
this.buttonPanel = null;
this.flowLayout1 = null;
this.numLabel = null;
this.xMaxField = null;
this.xMinField = null;
this.panel3 = null;
this.panel2 = null;
this.panel1 = null;
this.xNumField = null;
this.minLabel2 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.explicitTime = false;
this.validFunction = false;
this.dx = 1;
this.dy = 1;
this.varStrings = Clazz.array(java.lang.String, -1, ["surfacedata"]);
this.ds = null;
this.parser = null;
this.etchedBorder1 = Clazz.new_((I$[1]||$incl$(1)));
this.panel5 = Clazz.new_((I$[2]||$incl$(2)));
this.panel6 = Clazz.new_((I$[2]||$incl$(2)));
this.setBtn = Clazz.new_((I$[3]||$incl$(3)));
this.funcField = Clazz.new_((I$[4]||$incl$(4)));
this.label1 = Clazz.new_((I$[5]||$incl$(5)));
this.borderLayout1 = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout2 = Clazz.new_((I$[6]||$incl$(6)));
this.verticalFlowLayout1 = Clazz.new_((I$[7]||$incl$(7)));
this.maxLabel1 = Clazz.new_((I$[5]||$incl$(5)));
this.buttonPanel1 = Clazz.new_((I$[2]||$incl$(2)));
this.flowLayout2 = Clazz.new_((I$[8]||$incl$(8)));
this.numLabel1 = Clazz.new_((I$[5]||$incl$(5)));
this.yMaxField = Clazz.new_((I$[9]||$incl$(9)));
this.yMinField = Clazz.new_((I$[9]||$incl$(9)));
this.panel4 = Clazz.new_((I$[2]||$incl$(2)));
this.panel7 = Clazz.new_((I$[2]||$incl$(2)));
this.panel8 = Clazz.new_((I$[2]||$incl$(2)));
this.yNumField = Clazz.new_((I$[10]||$incl$(10)));
this.minLabel3 = Clazz.new_((I$[5]||$incl$(5)));
this.maxLabel = Clazz.new_((I$[5]||$incl$(5)));
this.buttonPanel = Clazz.new_((I$[2]||$incl$(2)));
this.flowLayout1 = Clazz.new_((I$[8]||$incl$(8)));
this.numLabel = Clazz.new_((I$[5]||$incl$(5)));
this.xMaxField = Clazz.new_((I$[9]||$incl$(9)));
this.xMinField = Clazz.new_((I$[9]||$incl$(9)));
this.panel3 = Clazz.new_((I$[2]||$incl$(2)));
this.panel2 = Clazz.new_((I$[2]||$incl$(2)));
this.panel1 = Clazz.new_((I$[2]||$incl$(2)));
this.xNumField = Clazz.new_((I$[10]||$incl$(10)));
this.minLabel2 = Clazz.new_((I$[5]||$incl$(5)));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.xmin=Double.$valueOf(this.getParameter$S$S("XMin", "-1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xmax=Double.$valueOf(this.getParameter$S$S("XMax", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ymin=Double.$valueOf(this.getParameter$S$S("YMin", "-1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ymax=Double.$valueOf(this.getParameter$S$S("YMax", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xPts=Integer.parseInt(this.getParameter$S$S("XPts", "64"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.yPts=Integer.parseInt(this.getParameter$S$S("YPts", "64"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.functionStr=this.getParameter$S$S("Function", "sin(x*y)");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xVariableStr=this.getParameter$S$S("XVariable", "x");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.yVariableStr=this.getParameter$S$S("YVariable", "y");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls=(I$[11]||$incl$(11)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.buttonPanel.setVisible$Z(this.showControls);
this.funcField.setText$S(this.functionStr);
this.setFuncion$S$S$S(this.functionStr, this.xVariableStr, this.yVariableStr);
this.setNumPts$I$I(this.xPts, this.yPts);
(I$[12]||$incl$(12)).addDataSource$O(this);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.etchedBorder1.setBackground$java_awt_Color((I$[13]||$incl$(13)).lightGray);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.verticalFlowLayout1);
this.setBtn.setLabel$S("Set");
this.setBtn.setLabel$S("Set");
this.setBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Analytic2D$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['mathapps.Analytic2D'].setBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[14]||$incl$(14)).$init$, [this, null])));
this.funcField.setText$S("textField1");
this.label1.setAlignment$I(2);
this.label1.setText$S("f(x,y,t) = ");
this.panel6.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.panel5.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.maxLabel1.setText$S("Max");
this.maxLabel1.setAlignment$I(2);
this.maxLabel1.setText$S("Y Max");
this.maxLabel1.setAlignment$I(2);
this.buttonPanel1.setLayout$java_awt_LayoutManager(this.flowLayout2);
this.buttonPanel1.setBackground$java_awt_Color((I$[13]||$incl$(13)).lightGray);
this.numLabel1.setAlignment$I(2);
this.numLabel1.setText$S("#");
this.numLabel1.setAlignment$I(2);
this.numLabel1.setText$S("#");
this.yMaxField.setValue$D(100.0);
this.yNumField.setValue$I(64);
this.minLabel3.setText$S("Min");
this.minLabel3.setAlignment$I(2);
this.minLabel3.setAlignment$I(2);
this.minLabel3.setText$S("Y Min");
this.maxLabel.setAlignment$I(2);
this.maxLabel.setText$S("Max");
this.maxLabel.setAlignment$I(2);
this.maxLabel.setText$S("X Max");
this.buttonPanel.setBackground$java_awt_Color((I$[13]||$incl$(13)).lightGray);
this.buttonPanel.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.xMaxField.setValue$D(100.0);
this.xNumField.setValue$I(64);
this.minLabel2.setText$S("Min");
this.minLabel2.setAlignment$I(2);
this.minLabel2.setAlignment$I(2);
this.minLabel2.setText$S("X Min");
this.setBackground$java_awt_Color((I$[13]||$incl$(13)).lightGray);
this.add$java_awt_Component$O(this.etchedBorder1, null);
this.etchedBorder1.add$java_awt_Component$O(this.buttonPanel, null);
this.buttonPanel.add$java_awt_Component$O(this.panel3, null);
this.panel3.add$java_awt_Component$O(this.minLabel2, null);
this.panel3.add$java_awt_Component$O(this.xMinField, null);
this.buttonPanel.add$java_awt_Component$O(this.panel2, null);
this.panel2.add$java_awt_Component$O(this.maxLabel, null);
this.panel2.add$java_awt_Component$O(this.xMaxField, null);
this.buttonPanel.add$java_awt_Component$O(this.panel1, null);
this.panel1.add$java_awt_Component$O(this.numLabel, null);
this.panel1.add$java_awt_Component$O(this.xNumField, null);
this.etchedBorder1.add$java_awt_Component$O(this.buttonPanel1, null);
this.buttonPanel1.add$java_awt_Component$O(this.panel4, null);
this.panel4.add$java_awt_Component$O(this.minLabel3, null);
this.panel4.add$java_awt_Component$O(this.yMinField, null);
this.buttonPanel1.add$java_awt_Component$O(this.panel7, null);
this.panel7.add$java_awt_Component$O(this.maxLabel1, null);
this.panel7.add$java_awt_Component$O(this.yMaxField, null);
this.buttonPanel1.add$java_awt_Component$O(this.panel8, null);
this.panel8.add$java_awt_Component$O(this.numLabel1, null);
this.panel8.add$java_awt_Component$O(this.yNumField, null);
this.etchedBorder1.add$java_awt_Component$O(this.panel5, null);
this.panel5.add$java_awt_Component$O(this.setBtn, "East");
this.panel5.add$java_awt_Component$O(this.panel6, "Center");
this.panel6.add$java_awt_Component$O(this.label1, "West");
this.panel6.add$java_awt_Component$O(this.funcField, "Center");
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Analytic Physlet evaluates an analytic function at a specified number of points.";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Min", "double", "Minimum value"]), Clazz.array(java.lang.String, -1, ["Max", "double", "Maximum value"]), Clazz.array(java.lang.String, -1, ["NumPts", "int", "Number of Points"]), Clazz.array(java.lang.String, -1, ["Function", "String", "The function string"]), Clazz.array(java.lang.String, -1, ["Variable", "String", "The independent variable."]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the user interface"])]);
return pinfo;
});

Clazz.newMeth(C$, 'main', function (args) {
var applet = Clazz.new_((I$[15]||$incl$(15)));
applet.$isStandalone=true;
var frame;
frame=((
(function(){var C$=Clazz.newClass(P$, "Analytic2D$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('a2s.Frame'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'processWindowEvent$java_awt_event_WindowEvent', function (e) {
C$.superclazz.prototype.processWindowEvent$java_awt_event_WindowEvent.apply(this, [e]);
if (e.getID() == 201) {
System.exit(0);
}});

Clazz.newMeth(C$, ['setTitle$S','setTitle'], function (title) {
C$.superclazz.prototype.setTitle$S.apply(this, [title]);
this.enableEvents$J(64);
});
})()
), Clazz.new_((I$[16]||$incl$(16)), [this, null],P$.Analytic2D$2));
frame.setTitle$S("Applet Frame");
frame.add$java_awt_Component$O(applet, "Center");
applet.init();
applet.start();
frame.setSize$I$I(400, 320);
var d = (I$[17]||$incl$(17)).getDefaultToolkit().getScreenSize();
frame.setLocation$I$I(((d.width - frame.getSize().width)/2|0), ((d.height - frame.getSize().height)/2|0));
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, ['setNumPts$I$I','setNumPts'], function (nx, ny) {
if (nx < 1) {
System.out.println$S("Number of x points must be >0.");
}this.xPts=Math.max(1, nx);
if (ny < 1) {
System.out.println$S("Number of y points must be >0.");
}this.yPts=Math.max(1, ny);
this.dx=(this.xmax - this.xmin) / (this.xPts - 1);
this.dy=(this.ymax - this.ymin) / (this.yPts - 1);
this.ds=Clazz.array(Double.TYPE, [this.xPts, this.yPts]);
this.setMinMax$D$D$D$D(this.xmin, this.xmax, this.ymin, this.ymax);
if (this.showControls && this.getBounds().width > 50 ) {
this.xNumField.setValue$I(this.xPts);
this.yNumField.setValue$I(this.yPts);
}});

Clazz.newMeth(C$, ['setMinMax$D$D$D$D','setMinMax'], function (xmin_, xmax_, ymin_, ymax_) {
if (this.parser == null  || !this.validFunction ) {
System.out.println$S("Invalid function.");
return;
}this.xmax=xmax_;
this.xmin=xmin_;
this.ymax=ymax_;
this.ymin=ymin_;
if (this.xmax < this.xmin ) {
System.out.println$S("X Maximum must be >  minimum.");
var temp = this.xmax;
this.xmax=this.xmin;
this.xmin=temp;
}if (this.xmax == this.xmin ) {
System.out.println$S("X Maximum cannot be =  minimum.");
this.xmax=this.xmax + 1.0;
}this.dx=(this.xmax - this.xmin) / (this.xPts - 1);
if (this.ymax < this.ymin ) {
System.out.println$S("Y Maximum must be >  minimum.");
var temp = this.ymax;
this.ymax=this.ymin;
this.ymin=temp;
}if (this.ymax == this.ymin ) {
System.out.println$S("Y Maximum cannot be =  minimum.");
this.ymax=this.ymax + 1.0;
}this.evaluate();
if (this.showControls && this.getBounds().width > 50 ) {
this.xMinField.setValue$D(this.xmin);
this.xMaxField.setValue$D(this.xmax);
this.yMinField.setValue$D(this.ymin);
this.yMaxField.setValue$D(this.ymax);
}this.updateDataConnections();
});

Clazz.newMeth(C$, 'evaluate', function () {
if (this.explicitTime) {
this.evaluateExplicitTime();
return;
}var xval = this.xmin;
var yval = this.ymin;
for (var j = 0; j < this.yPts; j++) {
for (var i = 0; i < this.xPts; i++) {
this.ds[i][j]=this.parser.evaluate$D$D(xval, yval);
xval += this.dx;
}
xval=this.xmin;
yval += this.dy;
}
});

Clazz.newMeth(C$, 'evaluateExplicitTime', function () {
var time = this.clock.getTime();
var state = Clazz.array(Double.TYPE, [3]);
state[2]=time;
var xval = this.xmin;
var yval = this.ymin;
for (var j = 0; j < this.yPts; j++) {
for (var i = 0; i < this.xPts; i++) {
this.ds[i][j]=this.parser.evaluate$DA(state);
xval += this.dx;
state[0]=xval;
}
xval=this.xmin;
yval += this.dy;
state[1]=yval;
}
});

Clazz.newMeth(C$, 'parseOneVariable$S', function (string) {
var oneFunc = Clazz.new_((I$[18]||$incl$(18)).c$$I,[2]);
var str =  String.instantialize(string);
oneFunc.defineVariable$I$S(1, this.xVariableStr);
oneFunc.defineVariable$I$S(2, this.yVariableStr);
oneFunc.define$S(str.toLowerCase());
oneFunc.parse();
if (oneFunc.getErrorCode() != 0) {
this.validFunction=false;
return false;
}this.validFunction=true;
this.explicitTime=false;
this.parser=oneFunc;
this.functionStr=string;
return true;
});

Clazz.newMeth(C$, 'parseTwoVariables$S', function (string) {
var twoFunc = Clazz.new_((I$[18]||$incl$(18)).c$$I,[3]);
var str =  String.instantialize(string);
twoFunc.defineVariable$I$S(1, this.xVariableStr);
twoFunc.defineVariable$I$S(2, this.yVariableStr);
twoFunc.defineVariable$I$S(3, "t");
twoFunc.define$S(str.toLowerCase());
twoFunc.parse();
if (twoFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse f(x,t)): " + str);
System.out.println$S("Parse error in MathFunction: " + twoFunc.getErrorString() + " at function 1, position " + twoFunc.getErrorPosition() );
p$.parseOneVariable$S.apply(this, ["0"]);
this.validFunction=false;
return false;
}this.validFunction=true;
this.explicitTime=true;
this.parser=twoFunc;
this.functionStr=string;
return true;
});

Clazz.newMeth(C$, 'reset', function () {
this.clock.stopClock();
this.clock.setTime$D(0);
this.evaluate();
this.updateDataConnections();
});

Clazz.newMeth(C$, ['setFuncion$S$S$S','setFuncion'], function ($function, xvar, yvar) {
this.xVariableStr= String.instantialize(xvar.trim().toLowerCase());
this.yVariableStr= String.instantialize(yvar.trim().toLowerCase());
var str = $function.trim();
if (!p$.parseOneVariable$S.apply(this, [str])) p$.parseTwoVariables$S.apply(this, [str]);
if (this.ds == null ) this.setNumPts$I$I(this.xPts, this.yPts);
 else this.setMinMax$D$D$D$D(this.xmin, this.xmax, this.ymin, this.ymax);
return this.validFunction;
});

Clazz.newMeth(C$, ['setFunctionStr$S','setFunctionStr'], function ($function) {
var str = $function.trim();
this.setFuncion$S$S$S(str, this.xVariableStr, this.yVariableStr);
return this.validFunction;
});

Clazz.newMeth(C$, ['getFunctionStr$S','getFunctionStr'], function (string) {
return this.functionStr;
});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
if (this.parser == null  || !this.validFunction ) {
System.out.println$S("Invalid function.");
return;
}if (this.explicitTime) this.evaluate();
this.updateDataConnections();
});

Clazz.newMeth(C$, 'setBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.xmin=this.xMinField.getValue();
this.xmax=this.xMaxField.getValue();
this.ymin=this.yMinField.getValue();
this.ymax=this.yMaxField.getValue();
this.setFunctionStr$S(this.funcField.getText());
this.setNumPts$I$I(this.xNumField.getValue(), this.yNumField.getValue());
});
})();
//Created 2018-07-20 18:09:37
