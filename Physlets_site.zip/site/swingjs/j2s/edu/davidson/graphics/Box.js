(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['edu.davidson.graphics.Orientation','edu.davidson.graphics.EtchedRectangle','edu.davidson.graphics.HintPanel','a2s.Label','edu.davidson.graphics.Assert','java.awt.GridBagLayout','java.awt.GridBagConstraints','java.awt.Insets','edu.davidson.graphics.Etching']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Box", null, 'a2s.Panel');
C$._defaultOrientation = null;
C$._defaultString = null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$._defaultOrientation = (I$[1]||$incl$(1)).CENTER;
C$._defaultString = "Title";
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.box = null;
this.titleLabel = null;
this.borderMe = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.box = Clazz.new_((I$[2]||$incl$(2)).c$$java_awt_Component,[this]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$java_awt_Component$S.apply(this, [Clazz.new_((I$[3]||$incl$(3))), C$._defaultString]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$S', function (surrounded, title) {
C$.c$$java_awt_Component$a2s_Label$edu_davidson_graphics_Orientation.apply(this, [surrounded, Clazz.new_((I$[4]||$incl$(4)).c$$S$I,[title, 0]), C$._defaultOrientation]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$S$edu_davidson_graphics_Orientation', function (surrounded, title, orient) {
C$.c$$java_awt_Component$a2s_Label$edu_davidson_graphics_Orientation.apply(this, [surrounded, Clazz.new_((I$[4]||$incl$(4)).c$$S$I,[title, 0]), orient]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$a2s_Label', function (surrounded, label) {
C$.c$$java_awt_Component$a2s_Label$edu_davidson_graphics_Orientation.apply(this, [surrounded, label, C$._defaultOrientation]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$a2s_Label$edu_davidson_graphics_Orientation', function (surrounded, label, orient) {
Clazz.super_(C$, this,1);
(I$[5]||$incl$(5)).notNull$O(surrounded);
(I$[5]||$incl$(5)).notNull$O(label);
this.borderMe = surrounded;
this.titleLabel = label;
var gbl = Clazz.new_((I$[6]||$incl$(6)));
var gbc = Clazz.new_((I$[7]||$incl$(7)));
this.setLayout$java_awt_LayoutManager(gbl);
gbc.gridwidth = 0;
if (orient === (I$[1]||$incl$(1)).CENTER ) gbc.anchor = 11;
 else if (orient === (I$[1]||$incl$(1)).RIGHT ) {
gbc.anchor = 12;
gbc.insets = Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I$I,[0, 0, 0, 5]);
} else if (orient === (I$[1]||$incl$(1)).LEFT ) {
gbc.anchor = 18;
gbc.insets = Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I$I,[0, 5, 0, 0]);
}gbl.setConstraints$java_awt_Component$java_awt_GridBagConstraints(this.titleLabel, gbc);
this.add$java_awt_Component(this.titleLabel);
gbc.insets = Clazz.new_((I$[8]||$incl$(8)).c$$I$I$I$I,[0, 5, 5, 5]);
gbc.anchor = 18;
gbc.weighty = 1.0;
gbc.weightx = 1.0;
gbc.fill = 1;
gbl.setConstraints$java_awt_Component$java_awt_GridBagConstraints(surrounded, gbc);
this.add$java_awt_Component(surrounded);
}, 1);

Clazz.newMeth(C$, 'etchedIn', function () {
this.box.etchedIn();
});

Clazz.newMeth(C$, 'etchedOut', function () {
this.box.etchedOut();
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.box.paint();
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'setSize$I$I', function (w, h) {
this.setBounds$I$I$I$I(this.getLocation().x, this.getLocation().y, w, h);
});

Clazz.newMeth(C$, 'setBounds$I$I$I$I', function (x, y, w, h) {
C$.superclazz.prototype.setBounds$I$I$I$I.apply(this, [x, y, w, h]);
var fm = this.titleLabel.getFontMetrics$java_awt_Font(this.titleLabel.getFont());
var top = this.getInsets().top + fm.getAscent();
var size = this.getSize();
this.box.setBounds$I$I$I$I(0, top, size.width - 1, size.height - top - 1 );
});

Clazz.newMeth(C$, 'paramString', function () {
return C$.superclazz.prototype.paramString.apply(this, []) + ",etching=" + (this.box.isEtchedIn() ? (I$[9]||$incl$(9)).IN : (I$[9]||$incl$(9)).OUT) + ",title=" + this.titleLabel ;
});

Clazz.newMeth(C$, 'setHint$S', function (s) {
if (this.borderMe != null  && Clazz.instanceOf(this.borderMe, "edu.davidson.graphics.HintPanel") ) (this.borderMe).setBubbleHelp$S(s);
});

Clazz.newMeth(C$, 'setTitle$S', function (s) {
this.titleLabel.setText$S(s);
this.repaint();
});

Clazz.newMeth(C$, 'getTitle', function () {
return this.titleLabel.getText();
});

Clazz.newMeth(C$, 'getComponent', function () {
return this.borderMe;
});
})();
//Created 2018-02-24 16:21:12
