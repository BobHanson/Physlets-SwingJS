(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['edu.davidson.graphics.Util']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ResistorI", null, 'circuitsimulator.Resistor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$S', function (circuit, v, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$D$I$I$S.apply(this, [circuit, v, r, c, t]);
C$.$init$.apply(this);
this.cirim = circuit.getImage$java_net_URL$S(circuit.base(), "resistor" + this.to + ".gif" );
this.cirim = (I$[1]||$incl$(1)).getImage$S$java_applet_Applet(circuit.imagedir + this.name() + this.to + ".gif" , circuit);
this.leftlinear = false;
}, 1);

Clazz.newMeth(C$, 'impedance', function () {
return Math.abs(this.value * this.getI());
});

Clazz.newMeth(C$, 'valueStr', function () {
return this.format.form$D(this.value) + "*I";
});

Clazz.newMeth(C$, 'getStringAdditions', function () {
return ",r=" + Double.toString(this.value);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 06:55:34
