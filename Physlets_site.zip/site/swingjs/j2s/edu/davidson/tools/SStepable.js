(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newInterface(P$, "SStepable");
})();
//Created 2018-02-22 01:07:17
