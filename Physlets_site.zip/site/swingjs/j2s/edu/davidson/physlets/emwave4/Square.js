(function(){var P$=Clazz.newPackage("edu.davidson.physlets.emwave4"),I$=[];
var C$=Clazz.newClass(P$, "Square", null, 'edu.davidson.physlets.emwave4.Figure');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D$java_awt_Color', function (z1, s, clr) {
Clazz.super_(C$, this,1);
this.numLines = 4;
this.pts = Clazz.array(Double.TYPE, [8, 3]);
this.c = clr;
this.pts[0][0] = -s / 2;
this.pts[0][1] = -s / 2;
this.pts[0][2] = z1;
this.pts[1][0] = -s / 2;
this.pts[1][1] = s / 2;
this.pts[1][2] = z1;
this.pts[2][0] = -s / 2;
this.pts[2][1] = s / 2;
this.pts[2][2] = z1;
this.pts[3][0] = s / 2;
this.pts[3][1] = s / 2;
this.pts[3][2] = z1;
this.pts[4][0] = s / 2;
this.pts[4][1] = s / 2;
this.pts[4][2] = z1;
this.pts[5][0] = s / 2;
this.pts[5][1] = -s / 2;
this.pts[5][2] = z1;
this.pts[6][0] = s / 2;
this.pts[6][1] = -s / 2;
this.pts[6][2] = z1;
this.pts[7][0] = -s / 2;
this.pts[7][1] = -s / 2;
this.pts[7][2] = z1;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:25
