(function(){var P$=Clazz.newPackage("sun.awt.image"),I$=[];
var C$=Clazz.newInterface(P$, "DataStealer");
})();
//Created 2018-05-24 08:47:27
