(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newInterface(P$, "SDifferentiable");
})();
//Created 2018-03-16 05:19:14
