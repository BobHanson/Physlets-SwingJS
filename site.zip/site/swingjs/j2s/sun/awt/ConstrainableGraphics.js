(function(){var P$=Clazz.newPackage("sun.awt"),I$=[];
var C$=Clazz.newInterface(P$, "ConstrainableGraphics");
})();
//Created 2018-05-24 08:47:21
