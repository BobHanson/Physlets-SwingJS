(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[];
var C$=Clazz.newInterface(P$, "SScalable");
})();
//Created 2018-02-06 13:05:37
