(function(){var P$=Clazz.newPackage("animator4"),I$=[['java.awt.Color','edu.davidson.display.Format','java.awt.Font','java.awt.Polygon','java.util.Vector','edu.davidson.tools.SApplet','animator4.Interaction','edu.davidson.tools.SUtil','edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Thing", null, null, ['edu.davidson.tools.SDataSource', 'edu.davidson.tools.SDataListener']);
C$.darkGreen = null;
C$.lightGreen = null;
C$.darkBlue = null;
C$.lightBlue = null;
C$.lightGray = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.darkGreen = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 128, 0]);
C$.lightGreen = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[128, 255, 128]);
C$.darkBlue = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[0, 0, 128]);
C$.lightBlue = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[128, 128, 255]);
C$.lightGray = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[160, 160, 160]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.highlightColor = null;
this.mass = 0;
this.format = null;
this.font = null;
this.canvas = null;
this.s = 0;
this.w = 0;
this.h = 0;
this.color = null;
this.vars = null;
this.initVars = null;
this.varStrings = null;
this.ds = null;
this.trail = null;
this.trailSize = 0;
this.trailOffset = 0;
this.trailCounter = 0;
this.label = null;
this.f = null;
this.noDrag = false;
this.resizable = false;
this.footPrints = 0;
this.paintBeforeGrid = false;
this.ghost = false;
this.showVVector = false;
this.showVComponents = false;
this.showAVector = false;
this.showAComponents = false;
this.showFVector = false;
this.showFComponents = false;
this.visible = false;
this.myMaster = null;
this.mySlaves = null;
this.xDisplayOff = 0;
this.yDisplayOff = 0;
this.showCoordinates = false;
this.xCoordOff = 0;
this.yCoordOff = 0;
this.xStr = null;
this.yStr = null;
this.xFunc = null;
this.yFunc = null;
this.dynamic = false;
this.fxStr = null;
this.fyStr = null;
this.xForce = null;
this.yForce = null;
this.interactions = null;
this.x0 = 0;
this.y0 = 0;
this.vx0 = 0;
this.vy0 = 0;
this.constraintMin = 0;
this.constraintMax = 0;
this.showConstraintPath = false;
this.constrainX = false;
this.constrainY = false;
this.constrainR = false;
this.constantX = 0;
this.constantY = 0;
this.constantRx = 0;
this.constantRy = 0;
this.constantR = 0;
this.sticky = false;
this.bouncy = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.highlightColor = C$.lightGray;
this.mass = 1.0;
this.format = Clazz.new_((I$[2]||$incl$(2)).c$$S,["%-+6.3g"]);
this.font = Clazz.new_((I$[3]||$incl$(3)).c$$S$I$I,["Monospaced", 0, 14]);
this.s = 5;
this.w = 5;
this.h = 5;
this.color = (I$[1]||$incl$(1)).black;
this.vars = Clazz.array(Double.TYPE, [8]);
this.initVars = Clazz.array(Double.TYPE, [8]);
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "vx", "vy", "ax", "ay", "m", "fx", "fy", "w", "h"]);
this.ds = Clazz.array(Double.TYPE, [1, 12]);
this.trail = Clazz.new_((I$[4]||$incl$(4)));
this.trailSize = 0;
this.trailOffset = 0;
this.trailCounter = 0;
this.label = null;
this.f = Clazz.new_((I$[3]||$incl$(3)).c$$S$I$I,["Helvetica", 1, 14]);
this.noDrag = true;
this.resizable = false;
this.footPrints = 0;
this.paintBeforeGrid = false;
this.ghost = false;
this.showVVector = false;
this.showVComponents = false;
this.showAVector = false;
this.showAComponents = false;
this.showFVector = false;
this.showFComponents = false;
this.visible = true;
this.myMaster = null;
this.mySlaves = Clazz.new_((I$[5]||$incl$(5)));
this.xDisplayOff = 0;
this.yDisplayOff = 0;
this.showCoordinates = false;
this.xCoordOff = 0;
this.yCoordOff = 0;
this.xFunc = null;
this.yFunc = null;
this.dynamic = false;
this.xForce = null;
this.yForce = null;
this.interactions = Clazz.new_((I$[5]||$incl$(5)));
this.constraintMin = 0;
this.constraintMax = 0;
this.showConstraintPath = true;
this.constrainX = false;
this.constrainY = false;
this.constrainR = false;
this.constantX = 0;
this.constantY = 0;
this.constantRx = 0;
this.constantRy = 0;
this.constantR = 0;
this.sticky = false;
this.bouncy = false;
}, 1);

Clazz.newMeth(C$, 'setSticky$Z', function (s) {
this.sticky = s;
if (s) this.canvas.stickyCount++;
});

Clazz.newMeth(C$, 'setBouncy$Z', function (b) {
this.bouncy = b;
if (b) this.canvas.bouncyCount++;
});

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas', function (c) {
C$.$init$.apply(this);
this.canvas = c;
this.vars[7] = this.mass;
this.initVars[7] = this.mass;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$S$S', function (c, xStr, yStr) {
C$.$init$.apply(this);
this.vars[7] = this.mass;
this.initVars[7] = this.mass;
this.canvas = c;
this.setTrajectory$S$S(xStr, yStr);
try {
(I$[6]||$incl$(6)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
(I$[6]||$incl$(6)).addDataListener$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'isNoDrag', function () {
return this.noDrag;
});

Clazz.newMeth(C$, 'setNoDrag$Z', function (nd) {
this.noDrag = nd;
});

Clazz.newMeth(C$, 'isResizable', function () {
return this.resizable;
});

Clazz.newMeth(C$, 'setResizable$Z', function (rs) {
this.resizable = rs;
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.canvas.getOwner();
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (i, j) {
return false;
});

Clazz.newMeth(C$, 'getSize', function () {
return this.s;
});

Clazz.newMeth(C$, 'setSize$I', function (sz) {
this.s = sz;
});

Clazz.newMeth(C$, 'getColor', function () {
return this.color;
});

Clazz.newMeth(C$, 'setColor$java_awt_Color', function (c) {
this.color = c;
});

Clazz.newMeth(C$, 'isVisible', function () {
return this.visible;
});

Clazz.newMeth(C$, 'setVisible$Z', function (v) {
this.visible = v;
});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
try {
this.format = Clazz.new_((I$[2]||$incl$(2)).c$$S,[str]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.IllegalArgumentException")){
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'setMass$D', function (m) {
this.mass = m;
this.vars[7] = m;
this.initVars[7] = m;
});

Clazz.newMeth(C$, 'setLabel$S', function (l) {
this.label = l;
});

Clazz.newMeth(C$, 'setProperties$I$D$D', function (sid, alpha, beta) {
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
if (this.myMaster != null ) {
this.vars[1] = this.myMaster.vars[1];
this.vars[2] = this.myMaster.vars[2];
return;
}if (!this.constrainX) this.vars[1] = x;
 else this.vars[2] = y;
if (!this.constrainX && !this.constrainY && !this.constrainR  ) {
this.vars[2] = y;
return;
}if (this.constrainR) {
this.vars[2] = y;
this.enforceConstraintOnR();
} else this.enforceConstraintOnXY();
});

Clazz.newMeth(C$, 'updateDynamics', function () {
if (!this.dynamic) return;
var i = this.canvas.dynamics.dThings.indexOf$O(this);
i = 1 + i * 4;
this.canvas.dynamics.vars[i] = this.vars[1];
this.canvas.dynamics.vars[i + 1] = this.vars[2];
});

Clazz.newMeth(C$, 'getH', function () {
return this.h;
});

Clazz.newMeth(C$, 'setH$D', function (vert) {
this.h = (vert|0);
});

Clazz.newMeth(C$, 'getW', function () {
return this.w;
});

Clazz.newMeth(C$, 'setW$D', function (horz) {
this.w = (horz|0);
});

Clazz.newMeth(C$, 'getX', function () {
return this.vars[1];
});

Clazz.newMeth(C$, 'setX$D', function (x) {
if (this.myMaster != null ) {
this.vars[1] = this.myMaster.vars[1];
return;
}this.vars[1] = x;
if (!this.constrainX && !this.constrainY && !this.constrainR  ) return;
 else this.enforceConstraintOnXY();
});

Clazz.newMeth(C$, 'getY', function () {
return this.vars[2];
});

Clazz.newMeth(C$, 'setY$D', function (y) {
if (this.myMaster != null ) {
this.vars[2] = this.myMaster.vars[2];
return;
}if (this.constrainY || this.constrainR ) return;
this.vars[2] = y;
});

Clazz.newMeth(C$, 'setVarsFromMaster', function () {
if (this.myMaster == null ) return;
this.vars[0] = this.myMaster.vars[0];
this.vars[1] = this.myMaster.vars[1];
this.vars[2] = this.myMaster.vars[2];
this.vars[3] = this.myMaster.vars[3];
this.vars[4] = this.myMaster.vars[4];
this.vars[5] = this.myMaster.vars[5];
this.vars[6] = this.myMaster.vars[6];
this.vars[7] = this.myMaster.vars[7];
this.mass = this.myMaster.mass;
var t = null;
for (var e = this.mySlaves.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (t !== this  && t.myMaster === this  ) t.setVarsFromMaster();
}
});

Clazz.newMeth(C$, 'updateMySlaves', function () {
var slave = null;
for (var e = this.mySlaves.elements(); e.hasMoreElements(); ) {
slave = e.nextElement();
slave.setVarsFromMaster();
}
});

Clazz.newMeth(C$, 'paintMySlaves$java_awt_Graphics', function (g) {
var slave = null;
for (var e = this.mySlaves.elements(); e.hasMoreElements(); ) {
slave = e.nextElement();
slave.paint$java_awt_Graphics(g);
}
});

Clazz.newMeth(C$, 'getVX', function () {
return this.vars[3];
});

Clazz.newMeth(C$, 'setVX$D', function (vx) {
if (this.constrainX) return;
this.vars[3] = vx;
});

Clazz.newMeth(C$, 'getVY', function () {
return this.vars[4];
});

Clazz.newMeth(C$, 'setVY$D', function (vy) {
if (this.constrainY) return;
this.vars[4] = vy;
});

Clazz.newMeth(C$, 'setSpeed$D', function (speed) {
if (this.myMaster != null ) {
return;
}if (speed <= 0 ) {
this.vars[3] = 0;
this.vars[4] = 0;
return;
}var oldSpeed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
if (oldSpeed == 0 ) {
if (this.constrainX) {
this.vars[4] = speed;
} else if (this.constrainY) {
this.vars[3] = speed;
} else if (this.constrainR) {
var u = (this.vars[1] - this.constantRx) / this.constantR;
var v = (this.vars[2] - this.constantRy) / this.constantR;
this.vars[3] = -v * speed;
this.vars[4] = u * speed;
} else {
this.vars[3] = speed;
this.vars[4] = 0;
}} else {
this.vars[3] = this.vars[3] * speed / oldSpeed;
this.vars[4] = this.vars[4] * speed / oldSpeed;
}this.canvas.dynamics.resetDynamicsVariables();
});

Clazz.newMeth(C$, 'constrainedRForce$I$DA', function (i, dxdt) {
var speed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
var rad = this.constantR;
var u = (this.vars[1] - this.constantRx) / rad;
var v = (this.vars[2] - this.constantRy) / rad;
var ax = this.getFx() / this.mass;
var ay = this.getFy() / this.mass;
var acc = (-ax * v + ay * u);
var acc2 = -speed * speed / this.constantR;
dxdt[i + 2] = -acc * v + acc2 * u;
dxdt[i + 3] = acc * u + acc2 * v;
return;
});

Clazz.newMeth(C$, 'getTotalFx', function () {
if (!this.constrainR) return this.getFx();
if (this.constantR == 0 ) return 0;
var speed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
var u = (this.vars[1] - this.constantRx) / this.constantR;
var v = (this.vars[2] - this.constantRy) / this.constantR;
var fx = this.getFx();
var fy = this.getFy();
var force = (-fx * v + fy * u);
var force2 = -this.mass * speed * speed  / this.constantR;
return -force * v + force2 * u;
});

Clazz.newMeth(C$, 'getTotalFy', function () {
if (!this.constrainR) return this.getFy();
if (this.constantR == 0 ) return 0;
var speed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
var u = (this.vars[1] - this.constantRx) / this.constantR;
var v = (this.vars[2] - this.constantRy) / this.constantR;
var fx = this.getFx();
var fy = this.getFy();
var force = (-fx * v + fy * u);
var force2 = -this.mass * speed * speed  / this.constantR;
return force * u + force2 * v;
});

Clazz.newMeth(C$, 'getFx', function () {
if (this.constrainX) return 0;
var fx = 0;
for (var i = 0; i < this.interactions.size(); i++) {
var $in = this.interactions.elementAt$I(i);
fx += $in.getF()[0];
}
if (Clazz.instanceOf(this, "animator4.Charge")) fx += this.getCoulombFx$animator4_Charge(this);
if (this.xForce == null ) return fx;
return this.xForce.evaluate$DA(this.vars) + fx;
});

Clazz.newMeth(C$, 'getCoulombFx$animator4_Charge', function (q1) {
var dx;
var dy;
var r;
var r2;
var t = null;
var q2 = null;
var fx = 0;
for (var e = this.canvas.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (Clazz.instanceOf(t, "animator4.Charge") && t !== q1  ) {
q2 = t;
dx = q1.vars[1] - q2.vars[1];
dy = q1.vars[2] - q2.vars[2];
r2 = dx * dx + dy * dy;
r = Math.sqrt(r2);
if (r > q2.range + q1.range ) {
fx += q1.q * q2.q * dx  / r2 / r;
} else {
fx += q1.q * q2.q * dx ;
}}}
return fx;
});

Clazz.newMeth(C$, 'getCoulombFy$animator4_Charge', function (q1) {
var dx;
var dy;
var r;
var r2;
var t = null;
var q2 = null;
var fy = 0;
for (var e = this.canvas.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (Clazz.instanceOf(t, "animator4.Charge") && t !== q1  ) {
q2 = t;
dx = q1.vars[1] - q2.vars[1];
dy = q1.vars[2] - q2.vars[2];
r2 = dx * dx + dy * dy;
r = Math.sqrt(r2);
if (r > q2.range + q1.range ) {
fy += q1.q * q2.q * dy  / r2 / r;
} else {
fy = q1.q * q2.q * dy ;
}}}
return fy;
});

Clazz.newMeth(C$, 'getFy', function () {
if (this.constrainY) return 0;
var fy = 0;
for (var i = 0; i < this.interactions.size(); i++) {
var $in = this.interactions.elementAt$I(i);
fy += $in.getF()[1];
}
if (Clazz.instanceOf(this, "animator4.Charge")) fy += this.getCoulombFy$animator4_Charge(this);
if (this.yForce == null ) return fy;
return this.yForce.evaluate$DA(this.vars) + fy;
});

Clazz.newMeth(C$, 'addInteraction$animator4_Thing$S$I', function (t, f, mode) {
var i = Clazz.new_((I$[7]||$incl$(7)).c$$animator4_Thing$animator4_Thing$S$I,[this, t, f, mode]);
if (i.force == null ) return false;
this.interactions.addElement$TE(i);
this.vars[5] = this.getFx() / this.mass;
this.vars[6] = this.getFy() / this.mass;
return true;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.vars[0];
this.ds[0][1] = this.vars[1];
this.ds[0][2] = this.vars[2];
this.ds[0][3] = this.vars[3];
this.ds[0][4] = this.vars[4];
this.ds[0][5] = this.vars[5];
this.ds[0][6] = this.vars[6];
this.ds[0][7] = this.mass;
if (this.myMaster == null ) {
this.ds[0][8] = this.getTotalFx();
this.ds[0][9] = this.getTotalFy();
} else {
this.ds[0][8] = this.myMaster.getTotalFx();
this.ds[0][9] = this.myMaster.getTotalFy();
}this.ds[0][10] = this.w;
this.ds[0][11] = this.h;
return this.ds;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.showConstraintPath) {
g.setColor$java_awt_Color((I$[8]||$incl$(8)).paleColor$java_awt_Color(this.color));
if (this.constrainX) this.paintConstraintX$java_awt_Graphics(g);
if (this.constrainY) this.paintConstraintY$java_awt_Graphics(g);
if (this.constrainR) this.paintConstraintR$java_awt_Graphics(g);
}var ptX = this.canvas.pixFromX$D(this.vars[1]);
var ptY = this.canvas.pixFromY$D(this.vars[2]);
if (this.showVComponents) {
g.setColor$java_awt_Color(C$.lightGreen);
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[3]);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[4]);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptY);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptVX, ptY, ptVX, ptVY);
}if (this.showVVector) {
g.setColor$java_awt_Color(C$.darkGreen);
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[3]);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[4]);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptVY);
}if (this.showFComponents) {
g.setColor$java_awt_Color(C$.lightBlue);
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.getTotalFx());
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.getTotalFy());
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptY);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptVX, ptY, ptVX, ptVY);
}if (this.showFVector) {
g.setColor$java_awt_Color(C$.darkBlue);
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.getTotalFx());
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.getTotalFy());
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptVY);
}if (this.showAComponents) {
g.setColor$java_awt_Color(C$.lightBlue);
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[5]);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[6]);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptY);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptVX, ptY, ptVX, ptVY);
}if (this.showAVector) {
g.setColor$java_awt_Color(C$.darkBlue);
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[5]);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[6]);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptVY);
}g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (g) {
var ptX = this.canvas.pixFromX$D(this.vars[1]);
var ptY = this.canvas.pixFromY$D(this.vars[2]);
g.setColor$java_awt_Color(this.highlightColor);
if (this.showVComponents) {
g.setColor$java_awt_Color(C$.lightGreen);
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[3]);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[4]);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptY);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptVX, ptY, ptVX, ptVY);
}if (this.showVVector) {
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[3]);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[4]);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptVY);
}if (this.showFComponents) {
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[5] * this.mass);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[6] * this.mass);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptY);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptVX, ptY, ptVX, ptVY);
}if (this.showFVector) {
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[5] * this.mass);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[6] * this.mass);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptVY);
}if (this.showAComponents) {
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[5]);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[6]);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptY);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptVX, ptY, ptVX, ptVY);
}if (this.showAVector) {
var ptVX = this.canvas.pixFromX$D(this.vars[1] + this.vars[5]);
var ptVY = this.canvas.pixFromY$D(this.vars[2] + this.vars[6]);
(I$[8]||$incl$(8)).drawArrow$java_awt_Graphics$I$I$I$I(g, ptX, ptY, ptVX, ptVY);
}g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
});

Clazz.newMeth(C$, 'paintCoordinates$java_awt_Graphics$I$I', function (g, xpix, ypix) {
var xStr = this.format.form$D((I$[8]||$incl$(8)).chop$D$D(this.vars[1], 1.0E-12));
var yStr = this.format.form$D((I$[8]||$incl$(8)).chop$D$D(this.vars[2], 1.0E-12));
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
var f = g.getFont();
g.setFont$java_awt_Font(this.font);
g.drawString$S$I$I("x:" + xStr, xpix + this.xCoordOff, ypix - 3 - this.yCoordOff );
g.drawString$S$I$I("y:" + yStr, xpix + this.xCoordOff, ypix + 12 - this.yCoordOff);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$, 'paintTrail$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color(this.color);
if (this.trailSize > 1 && this.trail.npoints > 1 ) {
if (this.footPrints == 0) g.drawPolyline$IA$IA$I(this.trail.xpoints, this.trail.ypoints, this.trail.npoints);
 else {
for (var i = 0; i < this.trail.npoints; i = i+(this.footPrints)) {
g.drawLine$I$I$I$I(this.trail.xpoints[i] - 2, this.trail.ypoints[i], this.trail.xpoints[i] + 2, this.trail.ypoints[i]);
g.drawLine$I$I$I$I(this.trail.xpoints[i], this.trail.ypoints[i] - 2, this.trail.xpoints[i], this.trail.ypoints[i] + 2);
}
}}});

Clazz.newMeth(C$, 'paintLabel$java_awt_Graphics$I$I', function (g, xpix, ypix) {
if (this.label == null ) return;
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
var f = g.getFont();
g.setFont$java_awt_Font(this.font);
var fm = g.getFontMetrics$java_awt_Font(this.font);
var off1 = (fm.stringWidth$S(this.label)/2|0);
var off2 = (fm.getHeight()/2|0);
g.drawString$S$I$I(this.label, xpix + off1, ypix + off2);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$, 'paintGhosts$java_awt_Graphics', function (g) {
if (this.ghost && this.footPrints > 0  && this.trailSize > 1  && this.trail.npoints > 1 ) {
g.setColor$java_awt_Color((I$[8]||$incl$(8)).veryPaleColor$java_awt_Color(this.color));
for (var i = 0; i < this.trail.npoints; i = i+(this.footPrints)) g.fillOval$I$I$I$I((this.trail.xpoints[i] - this.s), (this.trail.ypoints[i] - this.s), 2 * this.s, 2 * this.s);

}});

Clazz.newMeth(C$, 'getTime', function () {
return this.vars[0];
});

Clazz.newMeth(C$, 'getMass', function () {
return this.mass;
});

Clazz.newMeth(C$, 'setTrailSize$I', function (n) {
this.trailSize = n;
this.clearTrail();
});

Clazz.newMeth(C$, 'setTrailSize$I$I', function (n, offset) {
this.trailSize = n;
this.trailOffset = offset;
this.clearTrail();
});

Clazz.newMeth(C$, 'clearTrail', function () {
this.trailCounter = 0;
if (this.trail != null  && this.trail.npoints == 0 ) {
;} else this.trail = Clazz.new_((I$[4]||$incl$(4)));
if (this.canvas.osi != null ) this.incTrail();
});

Clazz.newMeth(C$, 'incTrail', function () {
if (this.trail == null  || this.trailSize < 1 ) return;
if (this.trailCounter < this.trailOffset) {
this.trailCounter++;
return;
}this.trailCounter++;
var x = 0;
var y = 0;
if (this.canvas.getReferenceObject() != null ) {
x = this.canvas.pixFromX$D(this.vars[1] - this.canvas.getReferenceObject().getX());
y = this.canvas.pixFromY$D(this.vars[2] - this.canvas.getReferenceObject().getY());
} else {
x = this.canvas.pixFromX$D(this.vars[1]);
y = this.canvas.pixFromY$D(this.vars[2]);
}if (this.trail.npoints < this.trailSize) {
this.trail.addPoint$I$I(x, y);
} else {
System.arraycopy(this.trail.xpoints, 1, this.trail.xpoints, 0, this.trailSize - 1);
System.arraycopy(this.trail.ypoints, 1, this.trail.ypoints, 0, this.trailSize - 1);
this.trail.xpoints[this.trailSize - 1] = x;
this.trail.ypoints[this.trailSize - 1] = y;
}});

Clazz.newMeth(C$, 'setTime$D$D', function (t, dt) {
if (this.dynamic) {
this.vars[0] = t;
this.vars[1] = this.x0;
this.vars[2] = this.y0;
this.vars[3] = this.vx0;
this.vars[4] = this.vy0;
if (this.xForce != null ) this.vars[5] = this.xForce.evaluate$DA(Clazz.array(Double.TYPE, -1, [this.vars[0], this.x0, this.y0, this.vx0, this.vy0]));
if (this.yForce != null ) this.vars[6] = this.yForce.evaluate$DA(Clazz.array(Double.TYPE, -1, [this.vars[0], this.x0, this.y0, this.vx0, this.vy0]));
} else this.setVars$D$D(t, dt);
this.clearTrail();
});

Clazz.newMeth(C$, 'setVars$D$D', function (t, dt) {
var x0 = 0;
var x1 = 0;
var x2 = 0;
var x3 = 0;
var x4 = 0;
var y0 = 0;
var y1 = 0;
var y2 = 0;
var y3 = 0;
var y4 = 0;
this.vars[0] = t;
this.vars[5] = 0;
this.vars[6] = 0;
this.vars[7] = this.mass;
if (this.xFunc == null  || this.yFunc == null  ) return;
try {
x0 = this.xFunc.evaluate$D(t - 2 * dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y0 = this.yFunc.evaluate$D(t - 2 * dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
x1 = this.xFunc.evaluate$D(t - dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y1 = this.yFunc.evaluate$D(t - dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
x2 = this.xFunc.evaluate$D(t);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y2 = this.yFunc.evaluate$D(t);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
x3 = this.xFunc.evaluate$D(t + dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y3 = this.yFunc.evaluate$D(t + dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
x4 = this.xFunc.evaluate$D(t + 2 * dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y4 = this.yFunc.evaluate$D(t + 2 * dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
this.vars[1] = x2;
this.vars[2] = y2;
this.vars[3] = (x3 - x1) / dt / 2 ;
this.vars[4] = (y3 - y1) / dt / 2 ;
this.vars[5] = (-x4 + 16 * x3 - 30 * x2 + 16 * x1 - x0) / dt / dt / 12 ;
this.vars[6] = (-y4 + 16 * y3 - 30 * y2 + 16 * y1 - y0) / dt / dt / 12 ;
return;
});

Clazz.newMeth(C$, 'hasTrajectory', function () {
if (this.xFunc == null  || this.yFunc == null  ) return false;
return true;
});

Clazz.newMeth(C$, 'setTrajectory$S$S', function (xStr, yStr) {
this.dynamic = false;
this.xForce = null;
this.yForce = null;
if (this.interactions != null ) this.interactions.removeAllElements();
if (this.canvas == null ) this.vars[0] = 0;
 else this.vars[0] = this.canvas.time;
this.vars[1] = 0;
this.vars[2] = 0;
this.vars[3] = 0;
this.vars[4] = 0;
this.vars[5] = 0;
this.vars[6] = 0;
this.vars[7] = this.mass;
if (xStr == null  || yStr == null  ) {
this.xStr = xStr;
this.yStr = yStr;
this.xFunc = null;
this.yFunc = null;
return true;
}this.xStr = xStr;
this.yStr = yStr;
var xFunc = Clazz.new_((I$[9]||$incl$(9)).c$$I,[1]);
xFunc.defineVariable$I$S(1, "t");
xFunc.define$S(xStr);
xFunc.parse();
if (xFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse trajectory x(t): " + xStr);
System.out.println$S("Parse error: " + xFunc.getErrorString() + " at function 1, position " + xFunc.getErrorPosition() );
return false;
}this.xFunc = xFunc;
var yFunc = Clazz.new_((I$[9]||$incl$(9)).c$$I,[1]);
yFunc.defineVariable$I$S(1, "t");
yFunc.define$S(yStr);
yFunc.parse();
if (yFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse trajectory y(t): " + yStr);
System.out.println$S("Parse error: " + yFunc.getErrorString() + " at function 1, position " + yFunc.getErrorPosition() );
return false;
}this.yFunc = yFunc;
this.setTime$D$D(this.vars[0], 0.001);
if (this.canvas != null  && this.canvas.autoRefresh ) this.canvas.repaint();
return true;
});

Clazz.newMeth(C$, 'setForce$S$S$D$D$D$D', function (fxStr, fyStr, x0, y0, vx0, vy0) {
this.x0 = x0;
this.y0 = y0;
this.vx0 = vx0;
this.vy0 = vy0;
if (this.canvas == null ) this.vars[0] = 0;
 else this.vars[0] = this.canvas.time;
this.vars[1] = x0;
this.vars[2] = y0;
this.vars[3] = vx0;
this.vars[4] = vy0;
this.vars[5] = 0;
this.vars[6] = 0;
this.vars[7] = this.mass;
if (fxStr == null  || fyStr == null  ) {
this.fxStr = fxStr;
this.fyStr = fyStr;
this.xForce = null;
this.yForce = null;
return true;
}this.fxStr = fxStr;
this.fyStr = fyStr;
var xForce = Clazz.new_((I$[9]||$incl$(9)).c$$I,[8]);
xForce.defineVariable$I$S(1, "t");
xForce.defineVariable$I$S(2, "x");
xForce.defineVariable$I$S(3, "y");
xForce.defineVariable$I$S(4, "vx");
xForce.defineVariable$I$S(5, "vy");
xForce.defineVariable$I$S(6, "ax");
xForce.defineVariable$I$S(7, "ay");
xForce.defineVariable$I$S(8, "m");
xForce.define$S(fxStr);
xForce.parse();
if (xForce.getErrorCode() != 0) {
System.out.println$S("Failed to parse force fx(t,x,y,vx,vy): " + fxStr);
System.out.println$S("Parse error: " + xForce.getErrorString() + " at function 1, position " + xForce.getErrorPosition() );
return false;
}this.xForce = xForce;
var yForce = Clazz.new_((I$[9]||$incl$(9)).c$$I,[8]);
yForce.defineVariable$I$S(1, "t");
yForce.defineVariable$I$S(2, "x");
yForce.defineVariable$I$S(3, "y");
yForce.defineVariable$I$S(4, "vx");
yForce.defineVariable$I$S(5, "vy");
yForce.defineVariable$I$S(6, "ax");
yForce.defineVariable$I$S(7, "ay");
yForce.defineVariable$I$S(8, "m");
yForce.define$S(fyStr);
yForce.parse();
if (yForce.getErrorCode() != 0) {
System.out.println$S("Failed to parse trajectory fy(t,x,y,vx,vy): " + fyStr);
System.out.println$S("Parse error: " + yForce.getErrorString() + " at function 1, position " + yForce.getErrorPosition() );
return false;
}this.yForce = yForce;
this.vars[1] = x0;
this.vars[2] = y0;
this.vars[3] = vx0;
this.vars[4] = vy0;
this.vars[5] = xForce.evaluate$DA(Clazz.array(Double.TYPE, -1, [this.vars[0], x0, y0, vx0, vy0]));
this.vars[6] = yForce.evaluate$DA(Clazz.array(Double.TYPE, -1, [this.vars[0], x0, y0, vx0, vy0]));
this.clearTrail();
this.dynamic = true;
var t = null;
if (this.canvas != null ) for (var e = this.canvas.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (t !== this  && t.myMaster === this  ) t.setVarsFromMaster();
}
if (this.canvas != null  && this.canvas.autoRefresh ) this.canvas.repaint();
return true;
});

Clazz.newMeth(C$, 'enforceConstraintOnR', function () {
var speed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
var rad = Math.sqrt((this.vars[1] - this.constantRx) * (this.vars[1] - this.constantRx) + (this.vars[2] - this.constantRy) * (this.vars[2] - this.constantRy));
if (rad == 0 ) {
this.vars[1] = this.constantRx + this.constantR;
this.vars[2] = this.constantRy;
this.vars[3] = 0;
this.vars[4] = speed;
return;
}var u = (this.vars[1] - this.constantRx) / rad;
var v = (this.vars[2] - this.constantRy) / rad;
this.vars[1] = this.constantRx + this.constantR * u;
this.vars[2] = this.constantRy + this.constantR * v;
if ((-this.vars[3] * v + this.vars[4] * u) > 0 ) {
this.vars[3] = -speed * v;
this.vars[4] = speed * u;
} else {
this.vars[3] = speed * v;
this.vars[4] = -speed * u;
}return;
});

Clazz.newMeth(C$, 'enforceConstraintOnX', function () {
this.vars[3] = 0;
if (this.constraintMin < this.constraintMax ) {
if (this.vars[2] < this.constraintMin ) {
this.vars[2] = this.constraintMin;
if (this.vars[4] < 0 ) {
this.vars[4] = -this.vars[4];
}} else if (this.vars[2] > this.constraintMax ) {
this.vars[2] = this.constraintMax;
if (this.vars[4] > 0 ) {
this.vars[4] = -this.vars[4];
}}}this.vars[1] = this.constantX;
return;
});

Clazz.newMeth(C$, 'enforceConstraintOnY', function () {
this.vars[4] = 0;
if (this.constraintMin < this.constraintMax ) {
if (this.vars[1] < this.constraintMin ) {
this.vars[1] = this.constraintMin;
if (this.vars[3] < 0 ) {
this.vars[3] = -this.vars[3];
}} else if (this.vars[1] > this.constraintMax ) {
this.vars[1] = this.constraintMax;
if (this.vars[3] > 0 ) {
this.vars[3] = -this.vars[3];
}}}this.vars[2] = this.constantY;
return;
});

Clazz.newMeth(C$, 'enforceConstraintOnXY', function () {
if (this.constrainX) {
p$.enforceConstraintOnX.apply(this, []);
return true;
} else if (this.constrainY) {
p$.enforceConstraintOnY.apply(this, []);
return true;
} else if (this.constrainR) {
this.enforceConstraintOnR();
return true;
}return false;
});

Clazz.newMeth(C$, 'setConstrainR$D$D$D', function (r, x, y) {
this.constrainX = false;
this.constrainY = false;
this.constrainR = true;
this.constantRx = x;
this.constantRy = y;
this.constantR = r;
this.enforceConstraintOnXY();
if (this.canvas.autoRefresh) this.canvas.repaint();
return true;
});

Clazz.newMeth(C$, 'setConstrainX$D$D$D', function (x, min, max) {
this.constrainX = true;
this.constrainY = false;
this.constrainR = false;
this.constraintMin = min;
this.constraintMax = max;
this.constantX = x;
this.enforceConstraintOnXY();
if (this.canvas.autoRefresh) this.canvas.repaint();
return true;
});

Clazz.newMeth(C$, 'setConstrainY$D$D$D', function (y, min, max) {
this.constrainX = false;
this.constrainY = true;
this.constrainR = false;
this.constraintMin = min;
this.constraintMax = max;
this.constantY = y;
this.enforceConstraintOnXY();
if (this.canvas.autoRefresh) this.canvas.repaint();
return true;
});

Clazz.newMeth(C$, 'paintConstraintX$java_awt_Graphics', function (g) {
var r = this.canvas.getBounds();
var bottom;
var top;
var xpix = this.canvas.pixFromX$D(this.constantX);
if (this.constraintMin < this.constraintMax ) {
bottom = this.canvas.pixFromY$D(this.constraintMin);
top = this.canvas.pixFromY$D(this.constraintMax);
} else {
top = r.y;
bottom = r.y + r.height - 1;
}g.drawLine$I$I$I$I(xpix, top, xpix, bottom);
});

Clazz.newMeth(C$, 'paintConstraintY$java_awt_Graphics', function (g) {
var r = this.canvas.getBounds();
var left;
var right;
var ypix = this.canvas.pixFromY$D(this.constantY);
if (this.constraintMin < this.constraintMax ) {
left = this.canvas.pixFromX$D(this.constraintMin);
right = this.canvas.pixFromX$D(this.constraintMax);
} else {
left = r.x;
right = r.x + r.width - 1;
}g.drawLine$I$I$I$I(left, ypix, right, ypix);
});

Clazz.newMeth(C$, 'paintConstraintR$java_awt_Graphics', function (g) {
var xpix = this.canvas.pixFromX$D(this.constantRx);
var ypix = this.canvas.pixFromY$D(this.constantRy);
var rpix = this.canvas.pixFromX$D(this.constantRx + this.constantR) - xpix;
xpix = xpix - rpix + this.xDisplayOff;
ypix = ypix - rpix - this.yDisplayOff ;
g.drawOval$I$I$I$I(xpix, ypix, 2 * rpix + 1, 2 * rpix + 1);
});

Clazz.newMeth(C$, 'clearSeries$I', function (sid) {
;});

Clazz.newMeth(C$, 'deleteSeries$I', function (sid) {
;});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (ds, sid, x, y) {
if (this.canvas.owner.debugLevel > 127) {
System.out.println$S("Animator.addDatum sid=" + sid + "  x=" + new Double(x).toString() + "  y=" + new Double(y).toString() );
}if (sid > 2) {
this.setProperties$I$D$D(sid, x, y);
} else if (sid == 2) {
this.setW$D(x);
this.setH$D(y);
} else {
this.setXY$D$D(x, y);
}this.updateDynamics();
this.updateMySlaves();
if (Clazz.instanceOf(this.canvas, "java.awt.Canvas")) (this.canvas).repaint();
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (ds, sid, x, y) {
var last = x.length - 1;
if (this.canvas.owner.debugLevel > 127) {
System.out.println$S("Animator.addDatum sid=" + sid + "  x=" + new Double(x[last]).toString() + "  y=" + new Double(y[last]).toString() );
}if (sid > 2) {
this.setProperties$I$D$D(sid, x[last], y[last]);
} else if (sid == 2) {
this.setW$D(x[last]);
this.setH$D(y[last]);
} else {
this.setXY$D$D(x[last], y[last]);
}this.updateDynamics();
this.updateMySlaves();
if (Clazz.instanceOf(this.canvas, "java.awt.Canvas")) (this.canvas).repaint();
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:41:43
