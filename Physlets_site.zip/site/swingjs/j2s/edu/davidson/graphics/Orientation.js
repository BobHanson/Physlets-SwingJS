(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[];
var C$=Clazz.newClass(P$, "Orientation");
C$.BAD=null;
C$.NORTH=null;
C$.SOUTH=null;
C$.EAST=null;
C$.WEST=null;
C$.CENTER=null;
C$.TOP=null;
C$.LEFT=null;
C$.RIGHT=null;
C$.BOTTOM=null;
C$.HORIZONTAL=null;
C$.VERTICAL=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.BAD=Clazz.new_(C$);
C$.NORTH=Clazz.new_(C$);
C$.SOUTH=Clazz.new_(C$);
C$.EAST=Clazz.new_(C$);
C$.WEST=Clazz.new_(C$);
C$.CENTER=Clazz.new_(C$);
C$.TOP=Clazz.new_(C$);
C$.LEFT=Clazz.new_(C$);
C$.RIGHT=Clazz.new_(C$);
C$.BOTTOM=Clazz.new_(C$);
C$.HORIZONTAL=Clazz.new_(C$);
C$.VERTICAL=Clazz.new_(C$);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'fromString$S', function (s) {
var o=C$.BAD;
if (s.equals$O("NORTH") || s.equals$O("north") ) o=C$.NORTH;
 else if (s.equals$O("SOUTH") || s.equals$O("south") ) o=C$.SOUTH;
 else if (s.equals$O("EAST") || s.equals$O("east") ) o=C$.EAST;
 else if (s.equals$O("WEST") || s.equals$O("west") ) o=C$.WEST;
 else if (s.equals$O("CENTER") || s.equals$O("center") ) o=C$.CENTER;
 else if (s.equals$O("TOP") || s.equals$O("top") ) o=C$.TOP;
 else if (s.equals$O("LEFT") || s.equals$O("left") ) o=C$.LEFT;
 else if (s.equals$O("RIGHT") || s.equals$O("right") ) o=C$.RIGHT;
 else if (s.equals$O("BOTTOM") || s.equals$O("bottom") ) o=C$.BOTTOM;
 else if (s.equals$O("VERTICAL") || s.equals$O("vertical") ) o=C$.VERTICAL;
 else if (s.equals$O("HORIZONTAL") || s.equals$O("horizontal") ) o=C$.HORIZONTAL;
return o;
}, 1);

Clazz.newMeth(C$, 'toString', function () {
var s= String.instantialize();
if (this === C$.NORTH ) s=this.getClass$().getName$() + "=NORTH";
 else if (this === C$.SOUTH ) s=this.getClass$().getName$() + "=SOUTH";
 else if (this === C$.EAST ) s=this.getClass$().getName$() + "=EAST";
 else if (this === C$.WEST ) s=this.getClass$().getName$() + "=WEST";
 else if (this === C$.CENTER ) s=this.getClass$().getName$() + "=CENTER";
 else if (this === C$.TOP ) s=this.getClass$().getName$() + "=TOP";
 else if (this === C$.LEFT ) s=this.getClass$().getName$() + "=LEFT";
 else if (this === C$.RIGHT ) s=this.getClass$().getName$() + "=RIGHT";
 else if (this === C$.BOTTOM ) s=this.getClass$().getName$() + "=BOTTOM";
 else if (this === C$.HORIZONTAL ) s=this.getClass$().getName$() + "=HORIZONTAL";
 else if (this === C$.VERTICAL ) s=this.getClass$().getName$() + "=VERTICAL";
 else if (this === C$.BAD ) s=this.getClass$().getName$() + "=BAD";
return s;
});

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:31 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
