(function(){var P$=Clazz.newPackage("sun.java2d"),I$=[];
var C$=Clazz.newInterface(P$, "Surface");
})();
//Created 2018-05-24 08:47:32
