(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['java.util.Vector','edu.davidson.graph.TextState','java.util.Stack','java.awt.Font','java.lang.StringBuffer','edu.davidson.graph.SpecialFunction']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TextState");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.f = null;
this.s = null;
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.f = null;
this.s = null;
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.s = Clazz.new_((I$[5]||$incl$(5)));
}, 1);

Clazz.newMeth(C$, 'copyAll', function () {
var tmp = this.copyState();
if (this.s.length$() == 0) return tmp;
for (var i = 0; i < this.s.length$(); i++) {
tmp.s.append$C(this.s.charAt$I(i));
}
return tmp;
});

Clazz.newMeth(C$, 'copyState', function () {
var tmp = Clazz.new_(C$);
tmp.f = this.f;
tmp.x = this.x;
tmp.y = this.y;
return tmp;
});

Clazz.newMeth(C$, 'toString', function () {
return this.s.toString();
});

Clazz.newMeth(C$, 'isEmpty', function () {
return (this.s.length$() == 0);
});

Clazz.newMeth(C$, 'getWidth$java_awt_Graphics', function (g) {
if (g == null  || this.f == null   || this.s.length$() == 0 ) return 0;
return g.getFontMetrics$java_awt_Font(this.f).stringWidth$S(this.s.toString());
});

Clazz.newMeth(C$, 'getHeight$java_awt_Graphics', function (g) {
if (g == null  || this.f == null  ) return 0;
return g.getFontMetrics$java_awt_Font(this.f).getHeight();
});

Clazz.newMeth(C$, 'getAscent$java_awt_Graphics', function (g) {
if (g == null  || this.f == null  ) return 0;
return g.getFontMetrics$java_awt_Font(this.f).getAscent();
});

Clazz.newMeth(C$, 'getDescent$java_awt_Graphics', function (g) {
if (g == null  || this.f == null  ) return 0;
return g.getFontMetrics$java_awt_Font(this.f).getDescent();
});

Clazz.newMeth(C$, 'getMaxAscent$java_awt_Graphics', function (g) {
if (g == null  || this.f == null  ) return 0;
return g.getFontMetrics$java_awt_Font(this.f).getMaxAscent();
});

Clazz.newMeth(C$, 'getMaxDescent$java_awt_Graphics', function (g) {
if (g == null  || this.f == null  ) return 0;
return g.getFontMetrics$java_awt_Font(this.f).getMaxDescent();
});

Clazz.newMeth(C$, 'getLeading$java_awt_Graphics', function (g) {
if (g == null  || this.f == null  ) return 0;
return g.getFontMetrics$java_awt_Font(this.f).getLeading();
});
})();
//Created 2018-02-24 16:21:12
