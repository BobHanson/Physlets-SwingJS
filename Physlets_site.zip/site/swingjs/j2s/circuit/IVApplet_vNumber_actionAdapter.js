(function(){var P$=Clazz.newPackage("circuit"),I$=[];
var C$=Clazz.newClass(P$, "IVApplet_vNumber_actionAdapter", null, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuit_IVApplet', function (adaptee) {
C$.$init$.apply(this);
this.adaptee = adaptee;
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.adaptee.vNumber_actionPerformed$java_awt_event_ActionEvent(e);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-08 13:28:02
