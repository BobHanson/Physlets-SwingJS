(function(){var P$=Clazz.newPackage("animator4"),I$=[];
var C$=Clazz.newClass(P$, "Shell", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$S$S', function (o, diameter, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.s=1;
this.w=diameter;
this.h=diameter;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX=this.canvas.pixFromX$D(this.vars[1]) - (this.w/2|0) + this.xDisplayOff;
var ptY=this.canvas.pixFromY$D(this.vars[2]) - (this.h/2|0) - this.yDisplayOff;
this.paintGhosts$java_awt_Graphics(g);
g.setColor$java_awt_Color(this.color);
for (var i=0; i <= this.s; i++) {
g.drawOval$I$I$I$I(ptX + i, ptY + i, this.w - 2 * i, this.h - 2 * i);
}
this.paintTrail$java_awt_Graphics(g);
this.paintLabel$java_awt_Graphics$I$I(g, ptX + (this.w/2|0), ptY + (this.h/2|0));
if (this.showCoordinates) this.paintCoordinates$java_awt_Graphics$I$I(g, ptX + (this.w/2|0), ptY + (this.h/2|0));
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX=this.canvas.pixFromX$D(this.vars[1]) - (this.w/2|0) + this.xDisplayOff;
var ptY=this.canvas.pixFromY$D(this.vars[2]) - (this.h/2|0) - this.yDisplayOff;
this.paintGhosts$java_awt_Graphics(g);
if (this.color === this.highlightColor ) g.setColor$java_awt_Color(Clazz.load('animator4.Thing').lightBlue);
 else g.setColor$java_awt_Color(this.highlightColor);
for (var i=0; i <= this.s; i++) {
g.drawOval$I$I$I$I(ptX + i, ptY + i, this.w - 2 * i, this.h - 2 * i);
g.drawOval$I$I$I$I(ptX + i - 1, ptY + i - 1, this.w - 2 * i + 2, this.h - 2 * i + 2);
}
C$.superclazz.prototype.paintHighlight$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX=this.canvas.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY=this.canvas.pixFromY$D(this.vars[2]) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < (this.w/2|0) + 1) && (Math.abs(yPix - ptY) < (this.h/2|0) + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'paintGhosts$java_awt_Graphics', function (g) {
if (!this.visible) return;
if (this.ghost && this.footPrints > 0  && this.trailSize > 1  && this.trail.npoints > 1 ) {
g.setColor$java_awt_Color(Clazz.load('edu.davidson.tools.SUtil').veryPaleColor$java_awt_Color(this.color));
for (var i=0; i < this.trail.npoints; i+=this.footPrints) for (var j=0; j <= this.s; j++) g.drawOval$I$I$I$I(this.trail.xpoints[i] - (this.w/2|0) + j + this.xDisplayOff, this.trail.ypoints[i] - (this.h/2|0) + j - this.yDisplayOff, this.w - 2 * j, this.h - 2 * j);


}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:13 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
