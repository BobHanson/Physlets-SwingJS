(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[['netscape.javascript.JSObject','Thread']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "OnloadThread", null, 'Thread');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.win = null;
this.jsFunction = null;
this.appletNames = null;
this.applet = null;
this.halt = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.halt = false;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$S$S', function (app, onload, names) {
Clazz.super_(C$, this,1);
this.jsFunction = onload;
this.appletNames = names;
this.applet = app;
try {
this.win = (I$[1]||$incl$(1)).getWindow$java_applet_Applet(this.applet);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
this.win = null;
if (app.debugLevel > 127) System.out.println$S("JSObject getWindow failed.");
} else {
throw e;
}
}
this.start();
}, 1);

Clazz.newMeth(C$, 'run', function () {
var count = 100;
while (count > 0 && !this.halt  && !this.applet.isActive() ){
if (this.applet.debugLevel > 127) System.out.println$S("Running OnloadThread.");
count--;
try {
(I$[2]||$incl$(2)).sleep$J(100);
if (this.halt) return;
if (this.applet.checkAppletNames$S(this.appletNames)) break;
if (this.halt) return;
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
return;
} else {
throw ex;
}
}
}
try {
if (this.halt || !this.applet.isActive() ) return;
this.win.eval$S(this.jsFunction);
this.applet.scriptHasRun = true;
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
} else {
throw ex;
}
}
});

Clazz.newMeth(C$);
})();
//Created 2018-02-08 01:51:45
