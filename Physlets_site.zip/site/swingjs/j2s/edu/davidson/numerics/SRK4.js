(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newClass(P$, "SRK4", null, 'edu.davidson.numerics.SODE');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.h = 0;
this.numEqu = 0;
this.dydx = null;
this.xTemp = null;
this.k1 = null;
this.k2 = null;
this.k3 = null;
this.k4 = null;
this.equations = null;
this.tol = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.h = 0.01;
this.numEqu = 0;
this.tol = this.h * 1.0E-6;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'step$D$DA', function (dx, x) {
if (dx == 0 ) return 0;
if (x.length < this.numEqu) {
this.numEqu = x.length;
this.xTemp = Clazz.array(Double.TYPE, [this.numEqu]);
this.k1 = Clazz.array(Double.TYPE, [this.numEqu]);
this.k2 = Clazz.array(Double.TYPE, [this.numEqu]);
this.k3 = Clazz.array(Double.TYPE, [this.numEqu]);
this.k4 = Clazz.array(Double.TYPE, [this.numEqu]);
this.dydx = Clazz.array(Double.TYPE, [this.numEqu]);
System.out.println$S("Warning:  Temporary arrays reset.");
}var numSteps = (Math.abs(dx / this.h)|0);
for (var i = 0; i < numSteps; i++) p$.stepRK4$D$DA.apply(this, [this.h, x]);

if (dx - numSteps * this.h > this.tol ) {
p$.stepRK4$D$DA.apply(this, [dx - numSteps * this.h, x]);
numSteps++;
}return numSteps;
});

Clazz.newMeth(C$, 'stepODE$D$DA', function (dx, x) {
if (x.length < this.numEqu) {
System.out.println$S("Error:  The temporary arrays are not large enough.");
return 0;
}p$.stepRK4$D$DA.apply(this, [dx, x]);
return dx;
});

Clazz.newMeth(C$, 'stepRK4$D$DA', function (dx, x) {
var i;
var h = dx;
var h2 = 0.5 * dx;
var h6 = dx / 6.0;
this.dydx = this.equations.rate$DA(x);
for (i = 0; i < this.numEqu; i++) {
this.k1[i] = this.dydx[i];
this.xTemp[i] = x[i] + h2 * this.k1[i];
}
this.dydx = this.equations.rate$DA(this.xTemp);
for (i = 0; i < this.numEqu; i++) {
this.k2[i] = this.dydx[i];
}
for (i = 0; i < this.numEqu; i++) {
this.xTemp[i] = x[i] + h2 * this.k2[i];
}
this.dydx = this.equations.rate$DA(this.xTemp);
for (i = 0; i < this.numEqu; i++) {
this.k3[i] = this.dydx[i];
}
for (i = 0; i < this.numEqu; i++) {
this.xTemp[i] = x[i] + h * this.k3[i];
}
this.dydx = this.equations.rate$DA(this.xTemp);
for (i = 0; i < this.numEqu; i++) {
this.k4[i] = this.dydx[i];
}
for (i = 0; i < this.numEqu; i++) {
x[i] = x[i] + h6 * (this.k1[i] + 2 * this.k2[i] + 2 * this.k3[i] + this.k4[i]);
}
});

Clazz.newMeth(C$, 'setDifferentials$edu_davidson_numerics_SDifferentiable', function (d) {
this.equations = d;
this.numEqu = this.equations.getNumEqu();
this.xTemp = Clazz.array(Double.TYPE, [this.numEqu]);
this.k1 = Clazz.array(Double.TYPE, [this.numEqu]);
this.k2 = Clazz.array(Double.TYPE, [this.numEqu]);
this.k3 = Clazz.array(Double.TYPE, [this.numEqu]);
this.k4 = Clazz.array(Double.TYPE, [this.numEqu]);
this.dydx = Clazz.array(Double.TYPE, [this.numEqu]);
});

Clazz.newMeth(C$, 'setNumberOfEquations$I', function (n) {
this.numEqu = n;
this.xTemp = Clazz.array(Double.TYPE, [this.numEqu]);
this.k1 = Clazz.array(Double.TYPE, [this.numEqu]);
this.k2 = Clazz.array(Double.TYPE, [this.numEqu]);
this.k3 = Clazz.array(Double.TYPE, [this.numEqu]);
this.k4 = Clazz.array(Double.TYPE, [this.numEqu]);
this.dydx = Clazz.array(Double.TYPE, [this.numEqu]);
});

Clazz.newMeth(C$, 'getDiffernetials', function () {
return this.equations;
});

Clazz.newMeth(C$, 'getH', function () {
return this.h;
});

Clazz.newMeth(C$, 'setH$D', function (h) {
this.h = h;
this.tol = h * 1.0E-6;
});

Clazz.newMeth(C$, 'setTol$D', function (parm1) {
;});

Clazz.newMeth(C$, 'getTol', function () {
return this.tol;
});
})();
//Created 2018-02-06 13:05:39
