(function(){var P$=Clazz.newPackage("eField4"),I$=[];
var C$=Clazz.newClass(P$, "CollisionThing", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.blockStrings=null;
this.block=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.blockStrings=Clazz.array(String, -1, ["blocked", "x", "y"]);
this.block=true;
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas', function (panel) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [panel, 0, 0, 0, 0]);
C$.$init$.apply(this);
this.varStrings=Clazz.array(String, -1, ["t", "x", "y"]);
this.ds=Clazz.array(Double.TYPE, [1, 3]);
this.ds[0][0]=0;
this.ds[0][1]=0;
this.ds[0][2]=0;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
;});

Clazz.newMeth(C$, 'setXYT$D$D$D', function (x, y, t) {
this.ds[0][0]=t;
this.ds[0][1]=x;
this.ds[0][2]=y;
});

Clazz.newMeth(C$, 'getVariables$', function () {
return this.ds;
});

Clazz.newMeth(C$, 'setBlock$Z', function (block) {
this.block=block;
});

Clazz.newMeth(C$, 'getVarStrings$', function () {
if (this.block) return this.blockStrings;
 else return this.varStrings;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:18 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
