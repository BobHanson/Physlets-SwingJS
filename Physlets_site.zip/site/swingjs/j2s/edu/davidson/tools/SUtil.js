(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[['java.awt.Color','java.lang.StringBuffer','java.util.StringTokenizer','edu.davidson.display.Format','edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SUtil");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'drawArrow$java_awt_Graphics$I$I$I$I', function (g, x0, y0, x1, y1) {
C$.drawArrow$java_awt_Graphics$I$I$I$I$I(g, x0, y0, x1, y1, 5);
}, 1);

Clazz.newMeth(C$, 'drawArrow$java_awt_Graphics$I$I$I$I$I', function (g, x0, y0, x1, y1, s) {
x1 = Math.min(x1, 2000);
x1 = Math.max(x1, -2000);
y1 = Math.min(y1, 2000);
y1 = Math.max(y1, -2000);
g.drawLine$I$I$I$I(x0, y0, x1, y1);
var x = x1 - x0;
var y = -(y1 - y0);
var h = Math.sqrt(x * x + y * y);
var w;
if (h > 3 * s ) w = s;
 else w = h / 3;
if (h > 1 ) {
var u = (w * x / h);
var v = -(w * y / h);
var base_x = x1 - 3 * u;
var base_y = y1 - 3 * v;
g.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x1, y1);
g.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x1, y1);
}}, 1);

Clazz.newMeth(C$, 'drawThickArrow$java_awt_Graphics$I$I$I$I$I$I', function (g, x1, y1, x2, y2, size, thickness) {
if (thickness < 2) {
C$.drawSolidArrow$java_awt_Graphics$I$I$I$I$I(g, x1, y1, x2, y2, size);
return;
}x1 = Math.min(x1, 2000);
x1 = Math.max(x1, -2000);
y1 = Math.min(y1, 2000);
y1 = Math.max(y1, -2000);
var deltaX = x2 - x1;
var deltaY = -(y2 - y1);
var h = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
size = Math.max(1, (size + (thickness/2|0)));
if (h < 4 * size ) size = ((h / 4)|0);
if (2 * thickness > size) thickness = (size/2|0);
var halfWidth = Math.max(thickness / 2.0, 2);
var u = (size * deltaX / h);
var v = -(size * deltaY / h);
var base_x = x2 - 3 * u;
var base_y = y2 - 3 * v;
var xOffset = -(Math.round(halfWidth * deltaY / h)|0);
var yOffset = -(Math.round(halfWidth * deltaX / h)|0);
var xCorners = Clazz.array(Integer.TYPE, -1, [x1 - xOffset, (base_x|0) - xOffset, ((base_x - v)|0), x2, ((base_x + v)|0), (base_x|0) + xOffset, x1 + xOffset]);
var yCorners = Clazz.array(Integer.TYPE, -1, [y1 - yOffset, (base_y|0) - yOffset, ((base_y + u)|0), y2, ((base_y - u)|0), (base_y|0) + yOffset, y1 + yOffset]);
g.fillPolygon$IA$IA$I(xCorners, yCorners, 7);
}, 1);

Clazz.newMeth(C$, 'drawThickLine$java_awt_Graphics$I$I$I$I$I', function (g, x1, y1, x2, y2, lineWidth) {
var angle;
var halfWidth = (lineWidth) / 2.0;
var deltaX = (x2 - x1);
var deltaY = (y2 - y1);
if (x1 == x2) angle = 3.141592653589793;
 else angle = Math.atan(deltaY / deltaX) + 1.5707963267948966;
var xOffset = ((halfWidth * Math.cos(angle))|0);
var yOffset = ((halfWidth * Math.sin(angle))|0);
var xCorners = Clazz.array(Integer.TYPE, -1, [x1 - xOffset, x2 - xOffset, x2 + xOffset, x1 + xOffset]);
var yCorners = Clazz.array(Integer.TYPE, -1, [y1 - yOffset, y2 - yOffset, y2 + yOffset, y1 + yOffset]);
g.fillPolygon$IA$IA$I(xCorners, yCorners, 4);
}, 1);

Clazz.newMeth(C$, 'drawSolidArrow$java_awt_Graphics$I$I$I$I$I', function (g, x0, y0, x1, y1, s) {
x1 = Math.min(x1, 2000);
x1 = Math.max(x1, -2000);
y1 = Math.min(y1, 2000);
y1 = Math.max(y1, -2000);
g.drawLine$I$I$I$I(x0, y0, x1, y1);
var x = x1 - x0;
var y = y1 - y0;
var h = Math.sqrt(x * x + y * y);
var u = s * x / h;
var v = s * y / h;
var base_x = x1 - 3 * u;
var base_y = y1 - 3 * v;
var x2 = ((base_x - v)|0);
var y2 = ((base_y + u)|0);
var x3 = ((base_x + v)|0);
var y3 = ((base_y - u)|0);
g.fillPolygon$IA$IA$I(Clazz.array(Integer.TYPE, -1, [x1, x2, x3]), Clazz.array(Integer.TYPE, -1, [y1, y2, y3]), 3);
}, 1);

Clazz.newMeth(C$, 'drawArrowHead$java_awt_Graphics$I$I$I$I$I', function (g, x0, y0, x1, y1, s) {
x1 = Math.min(x1, 2000);
x1 = Math.max(x1, -2000);
y1 = Math.min(y1, 2000);
y1 = Math.max(y1, -2000);
var x = x1 - x0;
var y = -(y1 - y0);
var h = Math.sqrt(x * x + y * y);
var u = (s * x / h);
var v = -(s * y / h);
var base_x = x0 - 3 * u;
var base_y = y0 - 3 * v;
g.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x0, y0);
g.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x0, y0);
}, 1);

Clazz.newMeth(C$, 'drawSolidArrowHead$java_awt_Graphics$I$I$I$I$I', function (g, x0, y0, x1, y1, s) {
x1 = Math.min(x1, 2000);
x1 = Math.max(x1, -2000);
y1 = Math.min(y1, 2000);
y1 = Math.max(y1, -2000);
var x = x1 - x0;
var y = -(y1 - y0);
var h = Math.sqrt(x * x + y * y);
var u = (s * x / h);
var v = -(s * y / h);
var base_x = x0 - 3 * u;
var base_y = y0 - 3 * v;
g.fillPolygon$IA$IA$I(Clazz.array(Integer.TYPE, -1, [x0, ((base_x - v)|0), ((base_x + v)|0)]), Clazz.array(Integer.TYPE, -1, [y0, ((base_y + u)|0), ((base_y - u)|0)]), 3);
}, 1);

Clazz.newMeth(C$, 'paleColor$java_awt_Color', function (c) {
var r = 255 - ((255 - c.getRed())/2|0);
var g = 255 - ((255 - c.getGreen())/2|0);
var b = 255 - ((255 - c.getBlue())/2|0);
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[r, g, b]);
}, 1);

Clazz.newMeth(C$, 'veryPaleColor$java_awt_Color', function (c) {
var r = 255 - ((255 - c.getRed())/4|0);
var g = 255 - ((255 - c.getGreen())/4|0);
var b = 255 - ((255 - c.getBlue())/4|0);
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[r, g, b]);
}, 1);

Clazz.newMeth(C$, 'complementColor$java_awt_Color', function (c) {
var r = 255 - c.getRed();
var g = 255 - c.getGreen();
var b = 255 - c.getBlue();
return Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[r, g, b]);
}, 1);

Clazz.newMeth(C$, 'chop$D$D', function (val, precision) {
if (Math.abs(val) < Math.abs(precision) ) {
return 0;
} else return val;
}, 1);

Clazz.newMeth(C$, 'removeWhitespace$S', function (str) {
var sb = Clazz.new_((I$[2]||$incl$(2)).c$$I,[32]);
for (var i = 0; i < str.length$(); i++) {
if (!Character.isWhitespace(str.charAt(i))) sb.append$C(str.charAt(i));
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'parameterExist$S$S', function (paramList, param) {
param = param.toLowerCase();
var ptokens = Clazz.new_((I$[3]||$incl$(3)).c$$S$S,[paramList, ",;"]);
var n = ptokens.countTokens();
for (var i = 0; i < n; i++) {
var valStr = ptokens.nextToken().trim();
valStr = valStr.toLowerCase();
if (valStr != null  && !valStr.equals$O("")  && valStr.startsWith$S(param) ) return true;
}
return false;
}, 1);

Clazz.newMeth(C$, 'convertEscapeCharacter$S', function (str) {
if (str == null  || str.length$() < 1 ) return str;
var sb = Clazz.new_((I$[2]||$incl$(2)).c$$I,[str.length$()]);
for (var i = 0; i < str.length$(); i++) {
if (str.charAt(i) != "\\") sb.append$C(str.charAt(i));
 else {
sb.append$C(str.charAt(i));
if ((i < str.length$() - 1) && (str.charAt(i + 1) == ",") ) sb.append$S("#");
if ((i < str.length$() - 1) && (str.charAt(i + 1) == "=") ) sb.append$S("@");
i++;
}}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'restoreEscapeCharacter$S', function (str) {
if (str == null  || str.length$() < 1 ) return str;
var sb = Clazz.new_((I$[2]||$incl$(2)).c$$I,[str.length$()]);
for (var i = 0; i < str.length$(); i++) {
if (str.charAt(i) != "\\") sb.append$C(str.charAt(i));
 else {
if ((i < str.length$() - 1) && (str.charAt(i + 1) == "#") ) sb.append$S(",");
if ((i < str.length$() - 1) && (str.charAt(i + 1) == "@") ) sb.append$S("=");
i++;
}}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getParam$S$S', function (paramList, param) {
param = param.toLowerCase();
var ptokens = Clazz.new_((I$[3]||$incl$(3)).c$$S$S,[paramList, ",;"]);
var n = ptokens.countTokens();
var value = 0;
for (var i = 0; i < n; i++) {
var valStr = ptokens.nextToken().trim();
valStr = valStr.toLowerCase();
if (valStr != null  && !valStr.equals$O("")  && valStr.startsWith$S(param) ) {
valStr = valStr.substring(param.length$());
try {
value = Double.$valueOf(valStr).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Parameter in add method is not a number. param " + param + " " + valStr );
} else {
throw e;
}
}
value = (I$[4]||$incl$(4)).atof$S(valStr);
return value;
}}
System.out.println$S("Error: parameter not found. paramList:" + paramList + "parameter:" + param );
return value;
}, 1);

Clazz.newMeth(C$, 'removeWhitespaceToEqual$S', function (str) {
var equalFound = false;
var sb = Clazz.new_((I$[2]||$incl$(2)).c$$I,[str.length$()]);
for (var i = 0; i < str.length$(); i++) {
if (str.charAt(i) == "=") equalFound = true;
if (equalFound || !Character.isWhitespace(str.charAt(i)) ) sb.append$C(str.charAt(i));
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getParamStr$S$S', function (paramList, param) {
paramList = C$.convertEscapeCharacter$S(paramList);
var ptokens = Clazz.new_((I$[3]||$incl$(3)).c$$S$S,[paramList, ",;"]);
var n = ptokens.countTokens();
for (var i = 0; i < n; i++) {
var valStr = ptokens.nextToken();
valStr = C$.removeWhitespaceToEqual$S(valStr);
if (valStr != null  && !valStr.equals$O("")  && valStr.startsWith$S(param) ) {
valStr = valStr.substring(param.length$());
valStr = C$.restoreEscapeCharacter$S(valStr);
return valStr;
}}
System.out.println$S("Error: parameter not found. paramList:" + paramList + "parameter:" + param );
return null;
}, 1);

Clazz.newMeth(C$, 'isValidFunction$S$S', function (funcStr, varList) {
if (funcStr == null ) return false;
var ptokens = Clazz.new_((I$[3]||$incl$(3)).c$$S$S,[varList, ",;"]);
var n = ptokens.countTokens();
var vars = Clazz.array(java.lang.String, [n]);
for (var i = 0; i < n; i++) {
var valStr = ptokens.nextToken();
vars[i] = C$.removeWhitespaceToEqual$S(valStr);
}
var parser = Clazz.new_((I$[5]||$incl$(5)).c$$I,[vars.length]);
for (var i = 0; i < vars.length; i++) {
parser.defineVariable$I$S(i + 1, vars[i]);
}
parser.define$S(funcStr);
parser.parse();
if (parser.getErrorCode() != 0) {
System.out.println$S("Failed to parse function): " + funcStr);
System.out.println$S("Parse error: " + parser.getErrorString() + " at function 1, position " + parser.getErrorPosition() );
for (var i = 0; i < vars.length; i++) {
System.out.println$S("vars " + vars[i]);
}
return false;
} else {
return true;
}}, 1);
})();
//Created 2018-02-06 13:05:40
