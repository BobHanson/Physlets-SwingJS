(function(){var P$=Clazz.newPackage("edu.davidson.surfaceplotter"),I$=[['edu.davidson.numerics.Parser','java.lang.Thread','Thread','edu.davidson.surfaceplotter.SurfaceVertex']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DataGenerator", null, null, 'Runnable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.calcThread = null;
this.parser1 = null;
this.parser2 = null;
this.runLock = null;
this.shouldRun = false;
this.abort = false;
this.running = false;
this.surfaceCanvas = null;
this.externalData = null;
this.newData = false;
this.newDataArray = null;
this.time = 0;
this.totalMemory = 0;
this.vertex = null;
this.vertexCalc = null;
this.vertexDraw = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.runLock =  Clazz.new_();
this.shouldRun = true;
this.abort = false;
this.running = false;
this.externalData = null;
this.newData = false;
this.newDataArray = null;
this.time = 0;
this.totalMemory = 0;
this.vertex = null;
this.vertexCalc = null;
this.vertexDraw = null;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_surfaceplotter_SurfaceCanvas', function (pp) {
C$.$init$.apply(this);
this.surfaceCanvas = pp;
this.parser1 = Clazz.new_((I$[1]||$incl$(1)).c$$I,[3]);
this.parser1.defineVariable$I$S(1, "x");
this.parser1.defineVariable$I$S(2, "y");
this.parser1.defineVariable$I$S(3, "t");
this.parser2 = Clazz.new_((I$[1]||$incl$(1)).c$$I,[3]);
this.parser2.defineVariable$I$S(1, "x");
this.parser2.defineVariable$I$S(2, "y");
this.parser2.defineVariable$I$S(3, "t");
this.calcThread = Clazz.new_((I$[2]||$incl$(2)).c$$Runnable,[this]);
this.calcThread.start();
}, 1);

Clazz.newMeth(C$, 'isExternalData', function () {
if (this.externalData == null ) return false;
 else return true;
});

Clazz.newMeth(C$, 'setDataArray$DAA', function (dataArray) {
if (dataArray == null  && this.externalData == null  ) return;
this.newData = true;
this.newDataArray = dataArray;
if (dataArray != null ) this.createData();
});

Clazz.newMeth(C$, 'run', function () {
while (this.shouldRun){
{
while (this.running == false )try {
this.runLock.wait();
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.Exception")){
} else {
throw ie;
}
}

this.running = false;
if (this.shouldRun) p$.doCalc.apply(this, []);
if (this.newData) {
this.newData = false;
this.running = true;
this.externalData = this.newDataArray;
}}{

}
}
this.calcThread = null;
});

Clazz.newMeth(C$, 'doCalc', function () {
var stepx;
var stepy;
var x;
var y;
var v;
var xi;
var xx;
var yi;
var yx;
var min;
var max;
var f1;
var f2;
var i;
var j;
var k;
var pixels = null;
var imgwidth = 0;
var imgheight = 0;
try {
xi = this.surfaceCanvas.controller.getXMin();
yi = this.surfaceCanvas.controller.getYMin();
xx = this.surfaceCanvas.controller.getXMax();
yx = this.surfaceCanvas.controller.getYMax();
if ((xi >= xx ) || (yi >= yx ) ) throw Clazz.new_(Clazz.load('java.lang.NumberFormatException'));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
this.surfaceCanvas.setMessage$S("Error in ranges");
return;
} else {
throw e;
}
}
this.surfaceCanvas.setRanges$F$F$F$F(xi, xx, yi, yx);
this.surfaceCanvas.setMessage$S("parsing ...");
f1 = this.surfaceCanvas.controller.isPlotFunction1();
if (f1 && this.externalData == null  ) {
this.parser1.define$S(this.surfaceCanvas.controller.getFunction1Definition());
this.parser1.parse();
if (this.parser1.getErrorCode() != 0) {
this.surfaceCanvas.setMessage$S("Parse error: " + this.parser1.getErrorString() + " at function 1, position " + this.parser1.getErrorPosition() );
return;
}}f2 = this.surfaceCanvas.controller.isPlotFunction2();
if (f2) {
this.parser2.define$S(this.surfaceCanvas.controller.getFunction2Definition());
this.parser2.parse();
if (this.parser2.getErrorCode() != 0) {
this.surfaceCanvas.setMessage$S("Parse error: " + this.parser2.getErrorString() + " at function 2, position " + this.parser2.getErrorPosition() );
return;
}}if (!f1 && !f2 && this.externalData == null   ) {
this.surfaceCanvas.setMessage$S("No function selected");
return;
}(I$[3]||$incl$(3)).yield();
if (this.abort) return;
var calc_divisions = this.surfaceCanvas.controller.getCalcDivisions();
if (this.externalData != null  && ((calc_divisions + 1 != this.externalData.length) || (calc_divisions + 1 != this.externalData[0].length) ) ) {
return;
}stepx = (xx - xi) / calc_divisions;
stepy = (yx - yi) / calc_divisions;
var newMemory = (calc_divisions + 1) * (calc_divisions + 1);
var showf1 = f1 || (this.externalData != null ) ;
if (true) {
this.totalMemory = newMemory;
this.vertexCalc = p$.allocateMemory$Z$Z$I.apply(this, [showf1, f2, this.totalMemory]);
this.vertexDraw = p$.allocateMemory$Z$Z$I.apply(this, [showf1, f2, this.totalMemory]);
this.vertex = this.vertexCalc;
}if (this.vertex == null ) return;
max = NaN;
min = NaN;
this.surfaceCanvas.controller.setMinimumResult$S("");
this.surfaceCanvas.controller.setMaximumResult$S("");
i = 0;
j = 0;
k = 0;
x = xi;
y = yi;
var xfactor = 20 / (xx - xi);
var yfactor = 20 / (yx - yi);
while (i <= calc_divisions){
if (f1 && this.externalData == null  ) {
this.parser1.setVariable$I$D(1, x);
this.parser1.setVariable$I$D(2, y);
this.parser1.setVariable$I$D(3, this.time);
}if (f2) {
this.parser2.setVariable$I$D(1, x);
this.parser2.setVariable$I$D(2, y);
this.parser2.setVariable$I$D(3, this.time);
}while (j <= calc_divisions){
(I$[3]||$incl$(3)).yield();
if (this.abort) return;
if (showf1) {
if (this.externalData != null ) v = this.externalData[i][j];
 else if (f1) v = this.parser1.evaluate();
 else v = 0;
if (Float.isInfinite(v)) v = NaN;
if (!Float.isNaN(v)) {
if (Float.isNaN(max) || (v > max ) ) max = v;
 else if (Float.isNaN(min) || (v < min ) ) min = v;
}this.vertex[0][k] = Clazz.new_((I$[4]||$incl$(4)).c$$F$F$F$edu_davidson_surfaceplotter_SurfaceCanvas,[(x - xi) * xfactor - 10, (y - yi) * yfactor - 10, v, this.surfaceCanvas]);
}if (f2) {
v = this.parser2.evaluate();
if (Float.isInfinite(v)) v = NaN;
if (!Float.isNaN(v)) {
if (Float.isNaN(max) || (v > max ) ) max = v;
 else if (Float.isNaN(min) || (v < min ) ) min = v;
}this.vertex[1][k] = Clazz.new_((I$[4]||$incl$(4)).c$$F$F$F$edu_davidson_surfaceplotter_SurfaceCanvas,[(x - xi) * xfactor - 10, (y - yi) * yfactor - 10, v, this.surfaceCanvas]);
}j++;
y += stepy;
if (f1) this.parser1.setVariable$I$D(2, y);
if (f2) this.parser2.setVariable$I$D(2, y);
k++;
}
if (this.abort) return;
j = 0;
y = yi;
i++;
x += stepx;
}
if (this.abort) return;
this.surfaceCanvas.controller.setMinimumResult$F(min);
this.surfaceCanvas.controller.setMaximumResult$F(max);
var canvasVertex = this.surfaceCanvas.setNewData$edu_davidson_surfaceplotter_SurfaceVertexAA(this.vertex);
if (canvasVertex === this.vertexCalc ) {
this.vertexCalc = this.vertexDraw;
this.vertexDraw = canvasVertex;
this.vertex = this.vertexCalc;
}});

Clazz.newMeth(C$, 'allocateMemory$Z$Z$I', function (f1, f2, total) {
var vertex = null;
try {
vertex = Clazz.array((I$[4]||$incl$(4)), [2, total]);
if (!f1) vertex[0] = null;
if (!f2) vertex[1] = null;
} catch (e$$) {
if (Clazz.exceptionOf(e$$, "java.lang.OutOfMemoryError")){
var e = e$$;
{
this.surfaceCanvas.setMessage$S("Not enough memory");
}
} else if (Clazz.exceptionOf(e$$, "java.lang.Exception")){
var e = e$$;
{
this.surfaceCanvas.setMessage$S("Error: " + e.toString());
}
} else {
throw e$$;
}
}
return vertex;
});

Clazz.newMeth(C$, 'createData', function () {
{
this.running = true;
this.runLock.notify();
}});

Clazz.newMeth(C$, 'destroyThread', function () {
this.calcThread.stop();
this.shouldRun = false;
this.abort = true;
this.calcThread.interrupt();
this.running = true;
this.runLock.notify();
});

Clazz.newMeth(C$, 'setTime$D', function (t) {
if (this.time == t ) return;
{
this.time = t;
this.running = true;
this.runLock.notify();
}});

Clazz.newMeth(C$, 'interrupt', function () {
this.abort = true;
{
this.surfaceCanvas.setDataAvailability$Z(false);
this.abort = false;
}});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:17
