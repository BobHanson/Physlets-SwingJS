(function(){var P$=Clazz.newPackage("circuit"),I$=[];
var C$=Clazz.newClass(P$, "Wire", null, 'circuit.Part');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I', function (o, c, i1, j1, i2, j2) {
C$.superclazz.c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I.apply(this, [o, c, i1, j1, i2, j2]);
C$.$init$.apply(this);
this.label=null;
this.showZ=false;
}, 1);

Clazz.newMeth(C$, 'drawSymbol$java_awt_Graphics$I$I$I$I$I', function (g, x1, y1, x2, y2, s) {
g.setColor$java_awt_Color(this.color);
g.drawLine$I$I$I$I(x1, y1, x2, y2);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:47 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
