(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CurrentSource", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$I$I$I$S', function (circ, a, pol, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circ, pol, r, c, t]);
C$.$init$.apply(this);
this.value = a;
this.reverseEquation = true;
this.unity = "A";
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'rightFunction$D', function (sign) {
return this.value * sign;
});

Clazz.newMeth(C$, 'getStringAdditions', function () {
return ",a=" + Double.toString(this.value);
});

Clazz.newMeth(C$, 'set$S', function (s) {
var ret = C$.superclazz.prototype.set$S.apply(this, [s]);
if ((I$[1]||$incl$(1)).parameterExist$S$S(s, "a=")) this.value = (I$[1]||$incl$(1)).getParam$S$S(s, "a=");
return ret;
});
})();
//Created 2018-02-06 06:55:33
