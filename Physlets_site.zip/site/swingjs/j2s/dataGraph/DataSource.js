(function(){var P$=Clazz.newPackage("dataGraph"),p$1={},I$=[[0,'edu.davidson.graphics.EtchedBorder','java.awt.Button','edu.davidson.display.SNumber','java.awt.FlowLayout','java.awt.BorderLayout','java.awt.Label','java.awt.Panel','java.awt.TextField','java.awt.Dimension']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "DataSource", null, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings=null;
this.$isStandalone=false;
this.variables=null;
this.etchedBorder1=null;
this.addBtn=null;
this.yField=null;
this.flowLayout1=null;
this.clearbtn=null;
this.borderLayout1=null;
this.xField=null;
this.n=0;
this.label1=null;
this.label2=null;
this.etchedBorder2=null;
this.panel1=null;
this.panel2=null;
this.hField=null;
this.vField=null;
this.label3=null;
this.label4=null;
this.borderLayout2=null;
this.borderLayout3=null;
this.borderLayout4=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings=Clazz.array(String, -1, ["n", "x", "y"]);
this.$isStandalone=false;
this.variables=Clazz.array(Double.TYPE, [1, 3]);
this.etchedBorder1=Clazz.new_($I$(1));
this.addBtn=Clazz.new_($I$(2));
this.yField=Clazz.new_($I$(3));
this.flowLayout1=Clazz.new_($I$(4));
this.clearbtn=Clazz.new_($I$(2));
this.borderLayout1=Clazz.new_($I$(5));
this.xField=Clazz.new_($I$(3));
this.n=0;
this.label1=Clazz.new_($I$(6));
this.label2=Clazz.new_($I$(6));
this.etchedBorder2=Clazz.new_($I$(1));
this.panel1=Clazz.new_($I$(7));
this.panel2=Clazz.new_($I$(7));
this.hField=Clazz.new_($I$(8));
this.vField=Clazz.new_($I$(8));
this.label3=Clazz.new_($I$(6));
this.label4=Clazz.new_($I$(6));
this.borderLayout2=Clazz.new_($I$(5));
this.borderLayout3=Clazz.new_($I$(5));
this.borderLayout4=Clazz.new_($I$(5));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty$S$S(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, ['getOwner$','getOwner'], function () {
return this;
});

Clazz.newMeth(C$, ['init$','init'], function () {
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.xField.setValue$D(0);
this.yField.setValue$D(0);
edu.davidson.tools.SApplet.addDataSource$O(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.flowLayout1);
{
this.setSize$java_awt_Dimension(Clazz.new_($I$(9).c$$I$I,[401, 102]));
}this.addBtn.setLabel$S("Add");
this.yField.setText$S("0    ");
this.addBtn.addActionListener$java_awt_event_ActionListener(((P$.DataSource$1||
(function(){var C$=Clazz.newClass(P$, "DataSource$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (e) {
this.b$['dataGraph.DataSource'].addBtn_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['dataGraph.DataSource'], [e]);
});
})()
), Clazz.new_(P$.DataSource$1.$init$, [this, null])));
this.clearbtn.setLabel$S("Clear");
this.xField.setText$S("0    ");
this.label1.setAlignment$I(2);
this.label1.setText$S(" x=");
this.label2.setAlignment$I(2);
this.label2.setText$S(" y=");
this.panel2.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.panel1.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.hField.setText$S("textField1");
this.hField.setEditable$Z(false);
this.vField.setText$S("textField2");
this.vField.setEditable$Z(false);
this.label3.setAlignment$I(1);
this.label3.setText$S("Function 1=f(n,x,y)");
this.label4.setAlignment$I(1);
this.label4.setText$S("Funcion 2=g(n,x,y)");
this.etchedBorder2.setLayout$java_awt_LayoutManager(this.borderLayout4);
this.clearbtn.addActionListener$java_awt_event_ActionListener(((P$.DataSource$2||
(function(){var C$=Clazz.newClass(P$, "DataSource$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (e) {
this.b$['dataGraph.DataSource'].clearbtn_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['dataGraph.DataSource'], [e]);
});
})()
), Clazz.new_(P$.DataSource$2.$init$, [this, null])));
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.add$java_awt_Component$O(this.etchedBorder1, "North");
this.etchedBorder1.add$java_awt_Component$O(this.label1, null);
this.etchedBorder1.add$java_awt_Component$O(this.xField, null);
this.etchedBorder1.add$java_awt_Component$O(this.label2, null);
this.etchedBorder1.add$java_awt_Component$O(this.yField, null);
this.etchedBorder1.add$java_awt_Component$O(this.addBtn, null);
this.etchedBorder1.add$java_awt_Component$O(this.clearbtn, null);
this.add$java_awt_Component$O(this.etchedBorder2, "Center");
this.etchedBorder2.add$java_awt_Component$O(this.panel2, "North");
this.panel2.add$java_awt_Component$O(this.label3, "West");
this.panel2.add$java_awt_Component$O(this.hField, "Center");
this.etchedBorder2.add$java_awt_Component$O(this.panel1, "South");
this.panel1.add$java_awt_Component$O(this.label4, "West");
this.panel1.add$java_awt_Component$O(this.vField, "Center");
}, p$1);

Clazz.newMeth(C$, ['start$','start'], function () {
});

Clazz.newMeth(C$, ['makeDataConnection$I$I$I$S$S','makeDataConnection'], function (sourceID, listenerID, seriesID, xStr, yStr) {
this.vField.setText$S(xStr);
this.hField.setText$S(yStr);
return C$.superclazz.prototype.makeDataConnection$I$I$I$S$S.apply(this, [sourceID, listenerID, seriesID, xStr, yStr]);
});

Clazz.newMeth(C$, ['getVariables$','getVariables'], function () {
return this.variables;
});

Clazz.newMeth(C$, ['getVarStrings$','getVarStrings'], function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['deleteDataConnection$edu_davidson_tools_SDataSource','deleteDataConnection'], function (ds) {
C$.superclazz.prototype.deleteDataConnection$I.apply(this, [ds.hashCode$()]);
});

Clazz.newMeth(C$, ['deleteDataConnections$','deleteDataConnections'], function () {
C$.superclazz.prototype.deleteDataConnections$.apply(this, []);
});

Clazz.newMeth(C$, ['stop$','stop'], function () {
});

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'], function () {
return "Applet Information";
});

Clazz.newMeth(C$, ['getParameterInfo$','getParameterInfo'], function () {
return null;
});

Clazz.newMeth(C$, 'addBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.variables[0][0]=this.n;
this.n++;
this.variables[0][1]=this.xField.getValue$();
this.variables[0][2]=this.yField.getValue$();
this.updateDataConnections$();
});

Clazz.newMeth(C$, 'clearbtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.clearAllData$();
this.n=0;
});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:50 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
