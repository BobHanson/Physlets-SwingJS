(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'java.util.StringTokenizer','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "CircuitProperties", null, 'java.util.Properties');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.defaultProperties$();
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_CircuitProperties', function (defaults) {
C$.superclazz.c$$java_util_Properties.apply(this, [defaults]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getBoolean$S$Z', function (key, def) {
var val=this.getProperty$S(key);
if (val != null ) {
if ("true".equalsIgnoreCase$S(val.trim$())) return true;
 else if ("false".equalsIgnoreCase$S(val.trim$())) return false;
}return def;
});

Clazz.newMeth(C$, 'getColor$S$java_awt_Color', function (key, def) {
var val=this.getProperty$S(key);
if (val != null ) {
var tkn=Clazz.new_($I$(1).c$$S,[val]);
try {
var r=Integer.parseInt$S(tkn.nextToken$());
var g=Integer.parseInt$S(tkn.nextToken$());
var b=Integer.parseInt$S(tkn.nextToken$());
return Clazz.new_($I$(2).c$$I$I$I,[r, g, b]);
} catch (x) {
if (Clazz.exceptionOf(x,"NumberFormatException")){
return def;
} else {
throw x;
}
}
}return def;
});

Clazz.newMeth(C$, 'getDouble$S$D', function (key, def) {
var val=this.getProperty$S(key);
var i=def;
if (val != null ) {
try {
i=Double.valueOf$S(val.trim$()).doubleValue$();
} catch (x) {
if (Clazz.exceptionOf(x,"NumberFormatException")){
} else {
throw x;
}
}
}return i;
});

Clazz.newMeth(C$, 'getInt$S$I', function (key, def) {
var val=this.getProperty$S(key);
var i=def;
if (val != null ) {
try {
i=Integer.parseInt$S(val.trim$());
} catch (x) {
if (Clazz.exceptionOf(x,"NumberFormatException")){
} else {
throw x;
}
}
}return i;
});

Clazz.newMeth(C$, 'getString$S$S', function (key, def) {
var val=this.getProperty$S(key);
if (val != null ) {
var len=val.length$();
var st=0;
while ((st < len) && (val.charAt$I(st) != "\"") ){
st++;
}
st++;
while ((st < len) && (val.charAt$I(len - 1) != "\"") ){
len--;
}
len--;
if (st < len) return val.substring$I$I(st, len);
}return def;
});

Clazz.newMeth(C$, 'getkey$S', function (value) {
var key="";
for (var e=this.propertyNames$(); e.hasMoreElements$(); ) {
key=e.nextElement$();
if (this.getProperty$S(key).equals$O(value)) return key;
}
return value;
});

Clazz.newMeth(C$, 'defaultProperties$', function () {
this.put$TK$TV("nothing", "nothing");
this.put$TK$TV("wire", "wire");
this.put$TK$TV("resistor", "resistor");
this.put$TK$TV("capacitor", "capacitor");
this.put$TK$TV("inductor", "inductor");
this.put$TK$TV("source", "source");
this.put$TK$TV("diode", "diode");
this.put$TK$TV("battery", "battery");
this.put$TK$TV("switch", "switch");
this.put$TK$TV("scope", "scope");
this.put$TK$TV("ameter", "ameter");
this.put$TK$TV("vmeter", "vmeter");
this.put$TK$TV("vgeneral", "vgeneral");
this.put$TK$TV("igeneral", "igeneral");
this.put$TK$TV("bulb", "bulb");
this.put$TK$TV("sinwave", "sinwave");
this.put$TK$TV("squarewave", "squarewave");
this.put$TK$TV("currentsource", "currentsource");
this.put$TK$TV("probe", "probe");
this.put$TK$TV("transformer", "transformer");
this.put$TK$TV("transformercoil", "transformercoil");
this.put$TK$TV("OK", "OK");
this.put$TK$TV("Cancel", "Cancel");
this.put$TK$TV("rows", "rows");
this.put$TK$TV("cols", "cols");
this.put$TK$TV("Load", "Load");
this.put$TK$TV("setgrid", "Set grid");
this.put$TK$TV("List", "List");
this.put$TK$TV("arrows", "Show ->");
this.put$TK$TV("Direction", "Direction");
this.put$TK$TV("down", "+ down/right");
this.put$TK$TV("up", "+ up/left");
this.put$TK$TV("Frequency", "Frequency");
this.put$TK$TV("Calculate", "Calculate");
this.put$TK$TV("Start", "Start");
this.put$TK$TV("Pause", "Pause");
this.put$TK$TV("Reset", "Reset");
this.put$TK$TV("scope_title", "Voltage signal of");
this.put$TK$TV("scope_vscale", "Voltage Scale");
this.put$TK$TV("scope_tbase", "Time Base");
this.put$TK$TV("circuitlist", "List of the build circuit");
this.put$TK$TV("menu_delete", "Delete Component");
this.put$TK$TV("menu_changevalue", "Change Properties");
this.put$TK$TV("menu_knobvalue", "Display Value Knob");
this.put$TK$TV("menu_knobfrequency", "Display Frequency Knob");
this.put$TK$TV("menu_showvalue", "Show/hide Value/Function");
this.put$TK$TV("menu_changeswitch", "Change Switch");
this.put$TK$TV("menu_changepolarity", "Change Polarity");
this.put$TK$TV("menu_elemlabel", "Set Label");
this.put$TK$TV("menu_getvoltage", "Display Oscilloscope");
this.put$TK$TV("menu_voltmeter", "Display Voltmeter");
this.put$TK$TV("menu_ammeter", "Display Amp\u00ef\u00bf\u00bdremeter");
this.put$TK$TV("menu_vgraph", "Display Voltage Graph");
this.put$TK$TV("menu_igraph", "Display Current Graph");
this.put$TK$TV("changevalue_title", "Change properties");
this.put$TK$TV("elemlabel_title", "Change label");
this.put$TK$TV("vgraph_title", "Voltage graph of");
this.put$TK$TV("igraph_title", "Current graph of");
this.put$TK$TV("gmode_strip", "To Strip Chart");
this.put$TK$TV("gmode_full", "To Full Chart");
this.put$TK$TV("vaxis", "Voltage (V)");
this.put$TK$TV("iaxis", "Current (A)");
this.put$TK$TV("taxis", "Time (s)");
this.put$TK$TV("twindow", "Strip Window (s)");
});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:48 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
