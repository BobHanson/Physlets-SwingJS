(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newInterface(P$, "SDifferentiable");
})();
//Created 2018-02-06 13:05:39
