(function(){var P$=Clazz.newPackage("bfield"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CompassThing", null, 'bfield.FieldShell');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x1 = 0;
this.y1 = 0;
this.x2 = 0;
this.y2 = 0;
this.ARROW_SIZE = 0;
this.px = null;
this.py = null;
this.d = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.ARROW_SIZE = 3;
this.px = Clazz.array(Integer.TYPE, [3]);
this.py = Clazz.array(Integer.TYPE, [3]);
this.d = 0;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I', function (owner, fp, x, y, radius) {
C$.superclazz.c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I.apply(this, [owner, fp, x, y, radius]);
C$.$init$.apply(this);
this.d = radius - 4;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [osg]);
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
var bx = this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, null);
var by = this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, null);
var b = Math.sqrt(bx * bx + by * by);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
osg.setFont$java_awt_Font(this.font);
if (b == 0 ) {
this.build$I$I$D$D(ptX, ptY, 0, 1);
osg.fillPolygon$IA$IA$I(this.px, this.py, 3);
osg.drawLine$I$I$I$I(this.x1, this.y1, this.x2, this.y2);
this.build$I$I$D$D(ptX, ptY, 1, 0);
osg.fillPolygon$IA$IA$I(this.px, this.py, 3);
osg.drawLine$I$I$I$I(this.x1, this.y1, this.x2, this.y2);
this.build$I$I$D$D(ptX, ptY, 0, -1);
osg.fillPolygon$IA$IA$I(this.px, this.py, 3);
osg.drawLine$I$I$I$I(this.x1, this.y1, this.x2, this.y2);
this.build$I$I$D$D(ptX, ptY, -1, 0);
osg.fillPolygon$IA$IA$I(this.px, this.py, 3);
osg.drawLine$I$I$I$I(this.x1, this.y1, this.x2, this.y2);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
osg.drawString$S$I$I("?", ptX - 4, ptY);
return;
}var sin = by / b;
var cos = bx / b;
if (this.d <= 0 ) return;
this.build$I$I$D$D(ptX, ptY, cos, sin);
osg.fillPolygon$IA$IA$I(this.px, this.py, 3);
osg.drawLine$I$I$I$I(this.x1, this.y1, this.x2, this.y2);
});

Clazz.newMeth(C$, 'build$I$I$D$D', function (x, y, cos, sin) {
var dx;
var dy;
this.x1 = ((2 * this.d * cos )|0);
this.y1 = ((-2 * this.d * sin )|0);
x = x - (this.x1/2|0);
y = y - (this.y1/2|0);
dx = this.x1 / this.d;
dy = this.y1 / this.d;
this.x1 = this.x1+(x);
this.y1 = this.y1+(y);
this.x2 = x;
this.y2 = y;
var basex = this.x1 - ((this.ARROW_SIZE * 2 * cos )|0);
;var basey = this.y1 + ((this.ARROW_SIZE * 2 * sin )|0);
;this.px[0] = ((basex + this.ARROW_SIZE * 2 * dx )|0);
this.py[0] = ((basey + this.ARROW_SIZE * 2 * dy )|0);
this.px[1] = ((basex + this.ARROW_SIZE * dy)|0);
this.py[1] = ((basey - this.ARROW_SIZE * dx)|0);
this.px[2] = ((basex - this.ARROW_SIZE * dy)|0);
this.py[2] = ((basey + this.ARROW_SIZE * dx)|0);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:36:54
