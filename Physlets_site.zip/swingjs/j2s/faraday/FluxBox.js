(function(){var P$=Clazz.newPackage("faraday"),I$=[];
var C$=Clazz.newClass(P$, "FluxBox", null, 'edu.davidson.display.BoxThing', 'faraday.Fluxable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.schematic = null;
this.measurementTime = 0;
this.flux = 0;
this.volt = 0;
this.lastTime = 0;
this.lastFlux = 0;
this.firstDatum = false;
this.secondDatum = false;
this.showCurrentArrow = false;
this.np = 0;
this.readings = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.measurementTime = 0;
this.flux = 0;
this.volt = 0;
this.lastTime = 0;
this.lastFlux = 0;
this.firstDatum = true;
this.secondDatum = false;
this.showCurrentArrow = true;
this.np = 5;
this.readings = Clazz.array(Double.TYPE, [this.np]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$faraday_Schematic$D$D$I$I', function (owner, sp, x, y, width, height) {
C$.superclazz.c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I$I.apply(this, [owner, sp, x, y, width, height]);
C$.$init$.apply(this);
this.schematic = sp;
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "flux", "v"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
this.doFluxIntegral();
}, 1);

Clazz.newMeth(C$, 'setShowCurrentArrow$Z', function (show) {
this.showCurrentArrow = show;
});

Clazz.newMeth(C$, 'reset', function () {
this.measurementTime = this.schematic.time;
this.lastTime = this.schematic.time;
this.lastFlux = 0;
this.firstDatum = true;
this.volt = 0;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
this.paintCurrentArrow$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintCurrentArrow$java_awt_Graphics', function (g) {
if (!this.showCurrentArrow) return;
if (this.volt == 0 ) return;
var ypix = this.canvas.pixFromY$D(this.y) - (this.h/2|0) - this.yDisplayOff - 15;
var xpix = this.canvas.pixFromX$D(this.x) + this.yDisplayOff;
var xpix1 = xpix - 10;
var xpix2 = xpix + 30;
g.drawLine$I$I$I$I(xpix1, ypix, xpix2, ypix);
g.drawLine$I$I$I$I(xpix1, ypix + 1, xpix2, ypix + 1);
if (this.volt < 0 ) {
g.drawLine$I$I$I$I(xpix2, ypix, xpix2 - 5, ypix - 5);
g.drawLine$I$I$I$I(xpix2, ypix, xpix2 - 5, ypix + 5);
g.drawLine$I$I$I$I(xpix2, ypix + 1, xpix2 - 5, ypix - 4);
g.drawLine$I$I$I$I(xpix2, ypix + 1, xpix2 - 5, ypix + 6);
} else {
g.drawLine$I$I$I$I(xpix1, ypix, xpix1 + 5, ypix - 5);
g.drawLine$I$I$I$I(xpix1, ypix, xpix1 + 5, ypix + 5);
g.drawLine$I$I$I$I(xpix1, ypix + 1, xpix1 + 5, ypix - 4);
g.drawLine$I$I$I$I(xpix1, ypix + 1, xpix1 + 5, ypix + 6);
}g.drawString$S$I$I(this.schematic.owner.label_current, xpix - 10, ypix + 15);
});

Clazz.newMeth(C$, 'getFlux', function () {
return this.flux;
});

Clazz.newMeth(C$, 'getVolt', function () {
return this.volt;
});

Clazz.newMeth(C$, 'average$D', function (v) {
if (this.firstDatum) {
this.lastTime = this.measurementTime;
this.lastFlux = this.flux;
this.firstDatum = false;
this.secondDatum = true;
return 0;
} else if (this.secondDatum) {
for (var i = 0; i < this.np; i++) this.readings[i] = v;

this.secondDatum = false;
return v;
} else {
for (var i = this.np - 1; i > 0; i--) this.readings[i] = this.readings[i - 1];

this.readings[0] = v;
}var avg = 0;
for (var i = 0; i < this.np; i++) {
avg += this.readings[i];
}
return avg / this.np;
});

Clazz.newMeth(C$, 'calcVoltage', function () {
if (this.measurementTime == this.lastTime ) return;
var v = -(this.flux - this.lastFlux) / (this.measurementTime - this.lastTime);
this.lastTime = this.measurementTime;
this.lastFlux = this.flux;
this.volt = p$.average$D.apply(this, [v]);
return;
});

Clazz.newMeth(C$, 'doFluxIntegral', function () {
var numPts = Math.max(this.w, 100);
var dx = (this.schematic.xFromPix$I(this.w) - this.schematic.xFromPix$I(0));
var left = this.x - dx / 2;
dx /= numPts;
this.flux = 0;
for (var i = 0; i < numPts; i++) {
this.flux += this.schematic.getFieldValue$D(left);
left += dx;
}
this.flux = this.flux * dx * this.h  / this.schematic.pixPerUnit;
;this.measurementTime = this.schematic.time;
p$.calcVoltage.apply(this, []);
return this.flux;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.measurementTime;
this.ds[0][1] = this.x;
this.ds[0][2] = this.y;
this.ds[0][3] = this.flux;
this.ds[0][4] = this.volt;
return this.ds;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:18
