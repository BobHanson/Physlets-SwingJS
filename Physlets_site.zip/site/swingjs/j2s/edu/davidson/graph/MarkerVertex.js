(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[];
var C$=Clazz.newClass(P$, "MarkerVertex");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.draw = false;
this.x = 0;
this.y = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:26
