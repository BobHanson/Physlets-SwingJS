(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newInterface(P$, "STableListener", null, null, 'edu.davidson.tools.SDataListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-02-22 01:07:18
