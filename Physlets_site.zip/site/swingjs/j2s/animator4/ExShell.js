(function(){var P$=Clazz.newPackage("animator4"),I$=[['edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ExShell", null, 'animator4.Shell');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.rFunc = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$S$S$S', function (o, tickness, rStr, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$I$S$S.apply(this, [o, 10, xStr, yStr]);
C$.$init$.apply(this);
this.s = tickness;
this.rFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[1]);
this.rFunc.defineVariable$I$S(1, "t");
this.rFunc.define$S(rStr);
this.rFunc.parse();
if (this.rFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse horzizontal component of vector: " + rStr);
System.out.println$S("Parse error: " + this.rFunc.getErrorString() + " at function 1, position " + this.rFunc.getErrorPosition() );
return;
}}, 1);

Clazz.newMeth(C$, 'getRad$D', function (t) {
var r = 0;
try {
r = this.rFunc.evaluate$D(t);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return Math.abs(r);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
this.w = ((this.canvas.pixPerUnit * this.getRad$D(this.vars[0]) * 2 )|0);
this.h = this.w;
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (g) {
if (!this.visible) return;
this.w = ((this.canvas.pixPerUnit * this.getRad$D(this.vars[0]) * 2 )|0);
this.h = this.w;
C$.superclazz.prototype.paintHighlight$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
this.w = ((this.canvas.pixPerUnit * this.getRad$D(this.vars[0]) * 2 )|0);
this.h = this.w;
return C$.superclazz.prototype.isInsideThing$I$I.apply(this, [xPix, yPix]);
});

Clazz.newMeth(C$, 'paintGhosts$java_awt_Graphics', function (g) {
if (!this.visible) return;
this.w = ((this.canvas.pixPerUnit * this.getRad$D(this.vars[0]) * 2 )|0);
this.h = this.w;
C$.superclazz.prototype.paintGhosts$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:13
