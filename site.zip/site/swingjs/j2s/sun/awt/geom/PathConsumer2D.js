(function(){var P$=Clazz.newPackage("sun.awt.geom"),I$=[];
var C$=Clazz.newInterface(P$, "PathConsumer2D");
})();
//Created 2018-05-24 08:47:26
