(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['circuitsimulator.CircuitProperties','circuitsimulator.CircuitGrid','java.lang.Thread','Thread','java.awt.Dimension','java.net.URL','circuitsimulator.CircuitCanvas','edu.davidson.tools.SUtil','circuitsimulator.Nothing','circuitsimulator.Wire','circuitsimulator.Source','circuitsimulator.Battery','circuitsimulator.Resistor','circuitsimulator.Switch','circuitsimulator.Scope','circuitsimulator.Ameter','circuitsimulator.Vmeter','circuitsimulator.Bulb','circuitsimulator.ResistorI','circuitsimulator.Capacitor','circuitsimulator.Inductor','circuitsimulator.VGeneral','circuitsimulator.IGeneral','circuitsimulator.Diode','circuitsimulator.CurrentSource','circuitsimulator.SinWave','circuitsimulator.SquareWave','circuitsimulator.Probe','circuitsimulator.TransformerCoil','java.awt.Font']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Circuit", null, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SStepable', 'Runnable']);
C$.DEBUG_IO = 0;
C$.DEBUG_NUM = 0;
C$.DEBUG = false;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.DEBUG_IO = ($s$[0] = 1, $s$[0]);
C$.DEBUG_NUM = ($s$[0] = 2, $s$[0]);
C$.DEBUG = false;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.numberofdt = 0;
this.dt = 0;
this.noc = 0;
this.fps = 0;
this.realt = 0;
this.$x = null;
this.interGrid = 0;
this.gridZone = null;
this.runner = null;
this.localization = null;
this.cirProp = null;
this.cirgrid = null;
this.circanvas = null;
this.imagebase = null;
this.imagedir = null;
this.parsed = false;
this.showCurrent = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.numberofdt = 400;
this.dt = 0.001;
this.noc = 1;
this.fps = 10.0;
this.realt = 0.0;
this.interGrid = 54;
this.cirProp = Clazz.new_((I$[1]||$incl$(1)).c$$circuitsimulator_CircuitProperties,[Clazz.new_((I$[1]||$incl$(1)))]);
this.cirgrid = Clazz.new_((I$[2]||$incl$(2)).c$$I$I$circuitsimulator_Circuit,[2, 2, this]);
this.imagedir = "";
this.parsed = false;
this.showCurrent = false;
}, 1);

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.firstTime) {
return 0;
} else {
return C$.superclazz.prototype.getAppletCount.apply(this, []);
}});

Clazz.newMeth(C$, 'start', function () {
C$.superclazz.prototype.start.apply(this, []);
if (this.firstTime) {
this.firstTime = false;
}if (C$.DEBUG) {
this.build();
this.clock.startClock();
}if (this.runner == null ) {
this.runner = Clazz.new_((I$[3]||$incl$(3)).c$$Runnable,[this]);
this.runner.start();
}});

Clazz.newMeth(C$, 'run', function () {
while (this.runner === (I$[4]||$incl$(4)).currentThread() ){
if (this.parsed) {
this.circanvas.repaint();
}try {
(I$[4]||$incl$(4)).sleep$J(100);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'stop', function () {
this.runner = null;
C$.superclazz.prototype.stop.apply(this, []);
});

Clazz.newMeth(C$, 'reset', function () {
C$.superclazz.prototype.reset.apply(this, []);
this.clearAllData();
this.clock.setTime$D(0);
this.cirgrid.reset();
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.clock.setDt$D(this.dt * this.noc);
this.clock.setFPS$D(this.fps);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
}, 1);

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
this.gridZone = Clazz.new_((I$[5]||$incl$(5)).c$$java_awt_Dimension,[this.getSize()]);
var s = this.getParameter$S("debugLevel");
if (s != null ) {
this.debugLevel = Integer.parseInt(s);
}s = this.getParameter$S("intergrid");
if (s == null ) {
this.interGrid = 54;
} else {
this.interGrid = Integer.parseInt(s);
}if (this.interGrid < 54) {
this.interGrid = 54;
System.out.println$S("interGrid = 54, because it can not be smaller");
}s = this.getParameter$S("numberofdt");
if (s == null ) {
this.numberofdt = 10;
} else {
this.numberofdt = Integer.parseInt(s);
}s = this.getParameter$S("dt");
if (s == null ) {
this.dt = 0.001;
} else {
this.dt = (Double.$valueOf(s)).doubleValue();
}s = this.getParameter$S("noc");
if (s == null ) {
this.noc = 1;
} else {
this.noc = Integer.parseInt(s);
}if (this.numberofdt < this.noc) {
this.numberofdt = this.noc;
System.out.println$S("numberofdt = noc, because it can not be smaller");
}s = this.getParameter$S("fps");
if (s == null ) {
this.fps = 1.0;
} else {
this.fps = (Double.$valueOf(s)).doubleValue();
}this.resetTiming();
s = this.getParameter$S("localization");
if (s == null ) {
s = this.getParameter$S("Resources");
}if (s != null ) {
this.localization = "" + s;
this.readCircuitProperties();
}s = this.getParameter$S("imagedir");
if (s == null ) {
this.imagedir = "circuitimages/";
} else {
this.imagedir += s + "/";
}try {
this.imagebase = Clazz.new_((I$[6]||$incl$(6)).c$$S,[this.getCodeBase().toString() + this.imagedir]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.net.MalformedURLException")){
System.out.println$S("Bad URL");
} else {
throw e;
}
}
this.circanvas = Clazz.new_((I$[7]||$incl$(7)).c$$circuitsimulator_Circuit,[this]);
this.circanvas.setBounds$I$I$I$I(1, 1, 1, 1);
this.add$java_awt_Component(this.circanvas);
});

Clazz.newMeth(C$, 'readCircuitProperties', function () {
try {
var is = Clazz.new_((I$[6]||$incl$(6)).c$$java_net_URL$S,[this.getCodeBase(), this.localization]).openStream();
this.cirProp.load$java_io_InputStream(is);
if ((this.debugLevel & C$.DEBUG_IO) > 0) {
System.out.println$S(this.cirProp.toString());
}} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
System.out.println$S("problem with circuit properties: " + ex.getMessage());
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'setGrid$I$I', function (r, c) {
this.parsed = false;
this.circanvas.setBounds$I$I$I$I(1, 1, 1, 1);
this.cirgrid = Clazz.new_((I$[2]||$incl$(2)).c$$I$I$circuitsimulator_Circuit,[r, c, this]);
this.circanvas.reconnect();
});

Clazz.newMeth(C$, 'setGrid$S', function (list) {
list = (I$[8]||$incl$(8)).removeWhitespace$S(list);
var r = ((I$[8]||$incl$(8)).getParam$S$S(list, "rows=")|0);
var c = ((I$[8]||$incl$(8)).getParam$S$S(list, "cols=")|0);
this.setGrid$I$I(r, c);
});

Clazz.newMeth(C$, 'calculateCircuit', function () {
if (this.parsed) {
for (var n = 0; n < this.numberofdt; n++) {
this.cirgrid.calculateStep$D(n * this.dt);
for (var i = 0; i < this.cirgrid.numberOfPars; i++) {
this.$x[i][n] = this.cirgrid.y[i];
}
}
} else if ((this.debugLevel & C$.DEBUG_IO) > 0) {
System.out.println$S("Circuit not parsed");
}});

Clazz.newMeth(C$, 'step$D$D', function (dt, time) {
if (dt == 0 ) return;
if (this.parsed) {
this.realt = time * this.dt * this.noc  / dt;
this.cirgrid.calculateStep$D(this.realt);
this.updateDataConnections();
for (var i = 1; i < this.noc; i++) {
this.cirgrid.calculateStep$D(this.realt + i * this.dt);
}
} else if ((this.debugLevel & C$.DEBUG_IO) > 0) {
System.out.println$S("Circuit not parsed");
}var change = false;
for (var e = this.cirgrid.cirElemList.elements(); e.hasMoreElements(); ) {
var cirelem = e.nextElement();
if (cirelem.maxCurrentValue <= Math.abs(cirelem.getI())  && !cirelem.overloaded ) {
change = true;
break;
}if (cirelem.maxCurrentValue <= Math.abs(cirelem.getI())  && !cirelem.overloaded ) {
change = true;
break;
}}
if (change) this.circanvas.redraw();
});

Clazz.newMeth(C$, 'setIntergrid$I', function (ig) {
this.interGrid = ig;
this.circanvas.reconnect();
});

Clazz.newMeth(C$, 'base', function () {
return this.imagebase;
});

Clazz.newMeth(C$, 'parse', function () {
if (this.cirgrid.constructEquationBase() == false ) {
return;
}this.$x = Clazz.array(Double.TYPE, [this.cirgrid.numberOfPars, this.numberofdt]);
this.cirgrid.buildEquations();
this.parsed = true;
this.circanvas.redraw();
});

Clazz.newMeth(C$, 'setDT$D', function (dt) {
this.dt = dt;
this.resetTiming();
});

Clazz.newMeth(C$, 'setNOC$I', function (noc) {
this.noc = noc;
this.resetTiming();
});

Clazz.newMeth(C$, 'setNumberOfDT$I', function (numberofdt) {
this.numberofdt = numberofdt;
});

Clazz.newMeth(C$, 'setFPS$D', function (fps) {
this.fps = fps;
this.resetTiming();
});

Clazz.newMeth(C$, 'resetTiming', function () {
this.clock.removeAllClockListeners();
this.clock.setDt$D(this.dt * this.noc);
this.clock.setFPS$D(this.fps);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
this.cirgrid.buildEquations();
});

Clazz.newMeth(C$, 'setShowCurrent$I', function (sc) {
this.showCurrent = (sc == 0) ? false : true;
});

Clazz.newMeth(C$, 'gett', function () {
var t = Clazz.array(Double.TYPE, [this.numberofdt]);
for (var j = 0; j < this.numberofdt; j++) {
t[j] = j * this.dt;
}
return t;
});

Clazz.newMeth(C$, 'getScript', function () {
return this.cirgrid.getcomponentList();
});

Clazz.newMeth(C$, 'getPar$I', function (par) {
return this.$x[par];
});

Clazz.newMeth(C$, 'getID$I$I$S', function (r, c, to) {
return this.cirgrid.getCircuitElement$I$I$S(r, c, to).hashCode();
});

Clazz.newMeth(C$, 'getCoupledID$I', function (id) {
return this.cirgrid.getCircuitElement$I(id).getCoupledID();
});

Clazz.newMeth(C$, 'getVoltage$I$I$I$I', function (br, bc, er, ec) {
var v = Clazz.array(Double.TYPE, [this.numberofdt]);
var b = this.cirgrid.element[br][bc].getVIndex();
var e = this.cirgrid.element[er][ec].getVIndex();
if ((this.debugLevel & C$.DEBUG_IO) > 0) {
System.out.println$S("b,e=" + b + "," + e );
}for (var j = 0; j < this.numberofdt; j++) {
v[j] = this.$x[e][j] - this.$x[b][j];
}
return v;
});

Clazz.newMeth(C$, 'getVoltage$I', function (id) {
var v = Clazz.array(Double.TYPE, [this.numberofdt]);
var ve = (this.cirgrid.getCircuitElement$I(id)).vequation;
for (var j = 0; j < this.numberofdt; j++) {
v[j] = this.$x[ve.indexV2][j] - this.$x[ve.indexV1][j];
}
return v;
});

Clazz.newMeth(C$, 'getCurrent$I', function (id) {
var current = Clazz.array(Double.TYPE, [this.numberofdt]);
var i = (this.cirgrid.getCircuitElement$I(id)).vequation.indexI1;
for (var j = 0; j < this.numberofdt; j++) {
current[j] = this.$x[this.cirgrid.numberOfV + i][j];
}
return current;
});

Clazz.newMeth(C$, 'getVAmplitude$I', function (id) {
var ulimit = -1.0E20;
var llimit = 1.0E20;
var ve = (this.cirgrid.getCircuitElement$I(id)).vequation;
for (var j = 0; j < this.numberofdt; j++) {
ulimit = Math.max(this.$x[ve.indexV2][j] - this.$x[ve.indexV1][j], ulimit);
llimit = Math.min(this.$x[ve.indexV2][j] - this.$x[ve.indexV1][j], llimit);
}
return (ulimit - llimit) / 2;
});

Clazz.newMeth(C$, 'getIAmplitude$I', function (id) {
var ulimit = -1.0E20;
var llimit = 1.0E20;
var i = (this.cirgrid.getCircuitElement$I(id)).vequation.indexI1;
for (var j = 0; j < this.numberofdt; j++) {
ulimit = Math.max(this.$x[this.cirgrid.numberOfV + i][j], ulimit);
llimit = Math.min(this.$x[this.cirgrid.numberOfV + i][j], llimit);
}
return (ulimit - llimit) / 2;
});

Clazz.newMeth(C$, 'getVMaxT$I', function (id) {
var vMax = 0;
var vTemp;
var ve = (this.cirgrid.getCircuitElement$I(id)).vequation;
for (var j = 1; j < this.numberofdt; j++) {
vTemp = this.$x[ve.indexV2][j] - this.$x[ve.indexV1][j];
vMax = (vTemp > this.$x[ve.indexV2][vMax] - this.$x[ve.indexV1][vMax] ) ? j : vMax;
}
return (vMax * this.dt);
});

Clazz.newMeth(C$, 'getVMinT$I', function (id) {
var vMin = 0;
var vTemp;
var ve = (this.cirgrid.getCircuitElement$I(id)).vequation;
for (var j = 1; j < this.numberofdt; j++) {
vTemp = this.$x[ve.indexV2][j] - this.$x[ve.indexV1][j];
vMin = (vTemp < this.$x[ve.indexV2][vMin] - this.$x[ve.indexV1][vMin] ) ? j : vMin;
}
return (vMin * this.dt);
});

Clazz.newMeth(C$, 'getVrms$I', function (id) {
var ve = (this.cirgrid.getCircuitElement$I(id)).vequation;
var vtemp;
var vrms = 0.0;
for (var j = 0; j < this.numberofdt; j++) {
vtemp = this.$x[ve.indexV2][j] - this.$x[ve.indexV1][j];
vrms += vtemp * vtemp;
}
return Math.sqrt(vrms / this.numberofdt);
});

Clazz.newMeth(C$, 'getIMaxT$I', function (id) {
var vMax = 0;
var i = (this.cirgrid.getCircuitElement$I(id)).vequation.indexI1;
for (var j = 1; j < this.numberofdt; j++) {
vMax = (this.$x[this.cirgrid.numberOfV + i][j] > this.$x[this.cirgrid.numberOfV + i][vMax] ) ? j : vMax;
}
return (vMax * this.dt);
});

Clazz.newMeth(C$, 'getIMinT$I', function (id) {
var vMin = 0;
var i = (this.cirgrid.getCircuitElement$I(id)).vequation.indexI1;
for (var j = 1; j < this.numberofdt; j++) {
vMin = (this.$x[this.cirgrid.numberOfV + i][j] < this.$x[this.cirgrid.numberOfV + i][vMin] ) ? j : vMin;
}
return (vMin * this.dt);
});

Clazz.newMeth(C$, 'getIrms$I', function (id) {
var itemp;
var irms = 0.0;
var i = (this.cirgrid.getCircuitElement$I(id)).vequation.indexI1;
for (var j = 0; j < this.numberofdt; j++) {
itemp = this.$x[this.cirgrid.numberOfV + i][j];
irms += itemp * itemp;
}
return Math.sqrt(irms / this.numberofdt);
});

Clazz.newMeth(C$, 'getDCLevel$I', function (id) {
var dcLevel = 0;
var ve = (this.cirgrid.getCircuitElement$I(id)).vequation;
for (var j = 1; j < this.numberofdt; j++) {
dcLevel += this.$x[ve.indexV2][j] - this.$x[ve.indexV1][j];
}
dcLevel = dcLevel / this.numberofdt;
return dcLevel;
});

Clazz.newMeth(C$, 'addObject$S$S', function (name, list) {
var type = 0;
var r = 0;
var c = 0;
var d = 0;
var st = 0;
var to;
var func = "";
var label = "";
var value = 0.0;
var amp = 1.0;
var phase = 0.0;
var freq = 1.0;
var duty = 0.5;
var imageName = "";
var cirelem = null;
this.parsed = false;
name = name.toLowerCase().trim();
name = (I$[8]||$incl$(8)).removeWhitespace$S(name);
name = this.cirProp.getkey$S(name);
list = (I$[8]||$incl$(8)).removeWhitespace$S(list);
r = ((I$[8]||$incl$(8)).getParam$S$S(list, "row=")|0);
c = ((I$[8]||$incl$(8)).getParam$S$S(list, "col=")|0);
to = "" + (I$[8]||$incl$(8)).getParamStr$S$S(list, "to=");
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "label=")) {
label += (I$[8]||$incl$(8)).getParamStr$S$S(list, "label=");
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "d=")) {
d = ((I$[8]||$incl$(8)).getParam$S$S(list, "d=")|0);
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "r=")) {
value = (I$[8]||$incl$(8)).getParam$S$S(list, "r=");
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "c=")) {
value = (I$[8]||$incl$(8)).getParam$S$S(list, "c=");
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "l=")) {
value = (I$[8]||$incl$(8)).getParam$S$S(list, "l=");
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "func=")) {
func = "" + (I$[8]||$incl$(8)).getParamStr$S$S(list, "func=");
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "freq=")) {
freq = (I$[8]||$incl$(8)).getParam$S$S(list, "freq=");
}imageName += name + to;
if (name.equals$O("nothing")) {
cirelem = Clazz.new_((I$[9]||$incl$(9)).c$$circuitsimulator_Circuit$I$I$S,[this, r, c, to]);
} else if (name.equals$O("wire")) {
cirelem = Clazz.new_((I$[10]||$incl$(10)).c$$circuitsimulator_Circuit$I$I$S,[this, r, c, to]);
} else if (name.equals$O("source")) {
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "st=")) {
st = ((I$[8]||$incl$(8)).getParam$S$S(list, "st=")|0);
amp = (I$[8]||$incl$(8)).getParam$S$S(list, "amp=");
phase = (I$[8]||$incl$(8)).getParam$S$S(list, "phase=");
if (st != 0) {
freq = (I$[8]||$incl$(8)).getParam$S$S(list, "freq=");
}cirelem = Clazz.new_((I$[11]||$incl$(11)).c$$circuitsimulator_Circuit$I$I$I$S$I$D$D$D,[this, d, r, c, to, st, amp, phase, freq]);
} else if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "freq=")) {
cirelem = Clazz.new_((I$[11]||$incl$(11)).c$$circuitsimulator_Circuit$I$I$I$S$S$D,[this, d, r, c, to, func, freq]);
} else {
cirelem = Clazz.new_((I$[11]||$incl$(11)).c$$circuitsimulator_Circuit$I$I$I$S$S,[this, d, r, c, to, func]);
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "r=")) {
(cirelem).internalResistance = (I$[8]||$incl$(8)).getParam$S$S(list, "r=");
}} else if (name.equals$O("battery")) {
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "v=")) {
value = (I$[8]||$incl$(8)).getParam$S$S(list, "v=");
}cirelem = Clazz.new_((I$[12]||$incl$(12)).c$$circuitsimulator_Circuit$I$I$I$S$D,[this, d, r, c, to, value]);
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "r=")) {
(cirelem).internalResistance = (I$[8]||$incl$(8)).getParam$S$S(list, "r=");
}} else if (name.equals$O("resistor")) {
cirelem = Clazz.new_((I$[13]||$incl$(13)).c$$circuitsimulator_Circuit$D$I$I$S,[this, value, r, c, to]);
} else if (name.equals$O("switch")) {
var o = (((I$[8]||$incl$(8)).getParam$S$S(list, "open=")|0) == 1) ? true : false;
cirelem = Clazz.new_((I$[14]||$incl$(14)).c$$circuitsimulator_Circuit$Z$I$I$S,[this, o, r, c, to]);
} else if (name.equals$O("scope")) {
cirelem = Clazz.new_((I$[15]||$incl$(15)).c$$circuitsimulator_Circuit$D$I$I$I$S,[this, value, d, r, c, to]);
} else if (name.equals$O("ameter")) {
cirelem = Clazz.new_((I$[16]||$incl$(16)).c$$circuitsimulator_Circuit$D$I$I$I$S,[this, value, d, r, c, to]);
} else if (name.equals$O("vmeter")) {
cirelem = Clazz.new_((I$[17]||$incl$(17)).c$$circuitsimulator_Circuit$D$I$I$I$S,[this, value, d, r, c, to]);
} else if (name.equals$O("bulb")) {
var v = (I$[8]||$incl$(8)).getParam$S$S(list, "v=");
var w = (I$[8]||$incl$(8)).getParam$S$S(list, "w=");
cirelem = Clazz.new_((I$[18]||$incl$(18)).c$$circuitsimulator_Circuit$D$D$I$I$S,[this, v, w, r, c, to]);
} else if (name.equals$O("resistori")) {
cirelem = Clazz.new_((I$[19]||$incl$(19)).c$$circuitsimulator_Circuit$D$I$I$S,[this, value, r, c, to]);
} else if (name.equals$O("capacitor")) {
cirelem = Clazz.new_((I$[20]||$incl$(20)).c$$circuitsimulator_Circuit$D$I$I$S,[this, value, r, c, to]);
} else if (name.equals$O("inductor")) {
cirelem = Clazz.new_((I$[21]||$incl$(21)).c$$circuitsimulator_Circuit$D$I$I$S,[this, value, r, c, to]);
} else if (name.equals$O("vgeneral")) {
cirelem = Clazz.new_((I$[22]||$incl$(22)).c$$circuitsimulator_Circuit$S$I$I$S,[this, func, r, c, to]);
} else if (name.equals$O("igeneral")) {
cirelem = Clazz.new_((I$[23]||$incl$(23)).c$$circuitsimulator_Circuit$S$I$I$S,[this, func, r, c, to]);
} else if (name.equals$O("diode")) {
value = (I$[8]||$incl$(8)).getParam$S$S(list, "isat=");
cirelem = Clazz.new_((I$[24]||$incl$(24)).c$$circuitsimulator_Circuit$D$I$I$I$S,[this, value, d, r, c, to]);
} else if (name.equals$O("currentsource")) {
value = (I$[8]||$incl$(8)).getParam$S$S(list, "a=");
cirelem = Clazz.new_((I$[25]||$incl$(25)).c$$circuitsimulator_Circuit$D$I$I$I$S,[this, value, d, r, c, to]);
} else if (name.equals$O("sinwave")) {
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "amp=")) {
amp = (I$[8]||$incl$(8)).getParam$S$S(list, "amp=");
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "phase=")) {
phase = (I$[8]||$incl$(8)).getParam$S$S(list, "phase=");
}cirelem = Clazz.new_((I$[26]||$incl$(26)).c$$circuitsimulator_Circuit$I$I$I$S$D$D$D,[this, d, r, c, to, amp, phase, freq]);
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "r=")) {
(cirelem).internalResistance = (I$[8]||$incl$(8)).getParam$S$S(list, "r=");
}} else if (name.equals$O("squarewave")) {
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "amp=")) {
amp = (I$[8]||$incl$(8)).getParam$S$S(list, "amp=");
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "dutyfactor=")) {
duty = (I$[8]||$incl$(8)).getParam$S$S(list, "dutyfactor=");
}cirelem = Clazz.new_((I$[27]||$incl$(27)).c$$circuitsimulator_Circuit$I$I$I$S$D$D$D,[this, d, r, c, to, amp, duty, freq]);
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "r=")) {
(cirelem).internalResistance = (I$[8]||$incl$(8)).getParam$S$S(list, "r=");
}} else if (name.equals$O("probe")) {
var re = 0;
var ce = 0;
var ptype = "voltage";
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "type=")) {
ptype = "" + (I$[8]||$incl$(8)).getParamStr$S$S(list, "type=");
}re = ((I$[8]||$incl$(8)).getParam$S$S(list, "row2=")|0);
ce = ((I$[8]||$incl$(8)).getParam$S$S(list, "col2=")|0);
cirelem = Clazz.new_((I$[28]||$incl$(28)).c$$circuitsimulator_Circuit$S$I$I$I$I,[this, ptype, r, c, re, ce]);
} else if (name.equals$O("transformercoil")) {
var position = 1;
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "position=")) {
position = ((I$[8]||$incl$(8)).getParam$S$S(list, "position=")|0);
}cirelem = Clazz.new_((I$[29]||$incl$(29)).c$$circuitsimulator_Circuit$D$I$I$S$I,[this, value, r, c, to, position]);
} else if (name.equals$O("transformer")) {
var id1;
var id2;
var l1 = value;
var l2;
var ratio;
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "l1=")) {
l1 = (I$[8]||$incl$(8)).getParam$S$S(list, "l1=");
}l2 = l1;
if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "l2=")) {
l2 = (I$[8]||$incl$(8)).getParam$S$S(list, "l1=");
}if ((I$[8]||$incl$(8)).parameterExist$S$S(list, "ratio=")) {
ratio = (I$[8]||$incl$(8)).getParam$S$S(list, "ratio=");
l2 = ratio * ratio * l1 ;
} else {
ratio = Math.sqrt(l2 / l1);
}id1 = this.addObject$S$S("transformercoil", "row=" + Integer.toString(r) + ",col=" + Integer.toString(c) + ",to=" + to + ",position=1,l=" + Double.toString(l1) + ",ratio=" + Double.toString(ratio) );
var r2 = r;
var c2 = c;
if (to.equals$O("h")) {
r2++;
} else {
c2++;
}id2 = this.addObject$S$S("transformercoil", "row=" + Integer.toString(r2) + ",col=" + Integer.toString(c2) + ",to=" + to + ",position=2,l=" + Double.toString(l2) + ",ratio=" + Double.toString(ratio) );
this.couple$I$I(id1, id2);
return id1;
}if (!label.equals$O("")) {
cirelem.setlabel$S(label);
}if ((this.debugLevel & C$.DEBUG_IO) > 0) {
System.out.println$S("element made of type " + cirelem.name() + ", label: " + cirelem.label );
}var hashcode;
try {
hashcode = this.cirgrid.addCircuitElement$circuitsimulator_CircuitElement(cirelem);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.ArrayIndexOutOfBoundsException")){
return -1;
} else {
throw e;
}
}
this.circanvas.redraw();
return hashcode;
});

Clazz.newMeth(C$, 'couple$I$I', function (id1, id2) {
var t1 = this.cirgrid.getCircuitElement$I(id1);
var t2 = this.cirgrid.getCircuitElement$I(id2);
if ((t1 == null ) || (t2 == null ) ) {
return false;
}t1.coupledTo$circuitsimulator_CircuitElement(t2);
t2.coupledTo$circuitsimulator_CircuitElement(t1);
this.cirgrid.buildEquations();
this.circanvas.redraw();
if ((this.debugLevel & C$.DEBUG_IO) > 0) {
System.out.println$S("elements coupled: " + Integer.toString(id1) + " and " + Integer.toString(id2) );
}return true;
});

Clazz.newMeth(C$, 'set$I$S', function (id, s) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.set$S(s);
this.cirgrid.buildEquations();
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'get$I', function (id) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return "";
}return t.get();
});

Clazz.newMeth(C$, 'setValue$I$S', function (id, s) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.setvalue$S(s);
this.cirgrid.buildEquations();
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'setMaxCurrentValue$I$S', function (id, s) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.setMaxCurrentValue$S(s);
this.cirgrid.buildEquations();
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'changePolarity$I', function (id) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.changePolarity();
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'setLabel$I$S', function (id, l) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.setlabel$S(l);
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'setValueVisible$I$Z', function (id, status) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.setValueVisible$Z(status);
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'setImageVisible$I$Z', function (id, status) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.setImageVisible$Z(status);
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'setImage$I$S', function (id, gifname) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.setImage$S(gifname);
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'setFormat$I$S', function (id, fstr) {
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.setFormat$S(fstr);
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'setFont$I$S$I$I', function (id, family, style, size) {
var font = Clazz.new_((I$[30]||$incl$(30)).c$$S$I$I,[family, style, size]);
var t = this.cirgrid.getCircuitElement$I(id);
if (t == null ) {
return false;
}t.setFont$java_awt_Font(font);
this.circanvas.redraw();
return true;
});

Clazz.newMeth(C$, 'setRCTo$I$I$I$S', function (id, r, c, to) {
var b = this.cirgrid.moveCircuitElement$I$I$I$S(id, r, c, to);
this.parsed = false;
this.circanvas.redraw();
return b;
});

Clazz.newMeth(C$, 'getComponent$S', function (posString) {
var r = 0;
var c = 0;
var p = "";
r = ((I$[8]||$incl$(8)).getParam$S$S(posString, "row=")|0);
c = ((I$[8]||$incl$(8)).getParam$S$S(posString, "col=")|0);
p += (I$[8]||$incl$(8)).getParamStr$S$S(posString, "to=");
if ((this.debugLevel & C$.DEBUG_IO) > 0) {
System.out.println$S(r + " " + c + " " + p );
}return this.cirgrid.getCircuitElement$I$I$S(r, c, p);
});

Clazz.newMeth(C$, 'moveComponent$circuitsimulator_CircuitElement$S', function (cirelem, posString) {
if (cirelem == null ) {
return false;
}var r = 0;
var c = 0;
var p = "";
var ok = true;
r = ((I$[8]||$incl$(8)).getParam$S$S(posString, "row=")|0);
c = ((I$[8]||$incl$(8)).getParam$S$S(posString, "col=")|0);
p += (I$[8]||$incl$(8)).getParamStr$S$S(posString, "to=");
if ((this.debugLevel & C$.DEBUG_IO) > 0) {
System.out.println$S(r + " " + c + " " + p );
}if (this.setRCTo$I$I$I$S(cirelem.hashCode(), r, c, p) == false ) {
System.out.println$S("Moving failed");
ok = false;
}return ok;
});

Clazz.newMeth(C$, 'removeObject$I', function (id) {
var b = this.cirgrid.removeCircuitElement$I(id);
this.parsed = false;
this.circanvas.redraw();
return b;
});

Clazz.newMeth(C$, 'build', function () {
this.setGrid$I$I(3, 2);
this.addObject$S$S("wire", "row=0,col=0,to=h");
this.addObject$S$S("resistor", "r=1.0E3,row=2,col=0,to=h");
this.addObject$S$S("wire", "row=1,col=1,to=v");
this.addObject$S$S("capacitor", "c=1.0E-7,row=0,col=1,to=v");
this.addObject$S$S("wire", "row=1,col=0,to=v");
this.addObject$S$S("source", "row=1,col=1,to=v,d=1,v=0,func=round(1-(t*1000-floor(t*1000)))");
this.parse();
});
var $s$ = new Int16Array(1);
})();
//Created 2018-02-06 06:55:32
