(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[[0,'netscape.javascript.JSObject','Thread']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "OnloadThread", null, 'Thread');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.win=null;
this.jsFunction=null;
this.appletNames=null;
this.applet=null;
this.halt=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.halt=false;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$S$S', function (app, onload, names) {
Clazz.super_(C$, this,1);
this.jsFunction=onload;
this.appletNames=names;
this.applet=app;
try {
this.win=Clazz.load('netscape.javascript.JSObject').getWindow$java_applet_Applet(this.applet);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.win=null;
if (app.debugLevel > 127) System.out.println$S("JSObject getWindow failed.");
} else {
throw e;
}
}
this.start$();
}, 1);

Clazz.newMeth(C$, 'run$', function () {
var count=100;
while (count > 0 && !this.halt  && !this.applet.isActive$() ){
if (this.applet.debugLevel > 127) System.out.println$S("Running OnloadThread.");
count--;
try {
Clazz.load('Thread').sleep$J(100);
if (this.halt) return;
if (this.applet.checkAppletNames$S(this.appletNames)) break;
if (this.halt) return;
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
return;
} else {
throw ex;
}
}
}
try {
if (this.halt || !this.applet.isActive$() ) return;
this.win.eval$S(this.jsFunction);
this.applet.scriptHasRun=true;
} catch (ex) {
if (Clazz.exceptionOf(ex,"Exception")){
} else {
throw ex;
}
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:32 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
