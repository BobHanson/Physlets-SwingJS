(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['edu.davidson.graph.TextLine','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DataSet");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.g2d = null;
this.linestyle = 0;
this.linecolor = null;
this.marker = 0;
this.markercolor = null;
this.markerscale = 0;
this.xaxis = null;
this.yaxis = null;
this.xmax = 0;
this.xmin = 0;
this.ymax = 0;
this.ymin = 0;
this.clipping = false;
this.sorted = false;
this.stripChart = false;
this.chartPts = 0;
this.tempDatum = null;
this.lastPoint = null;
this.dxmax = 0;
this.dxmin = 0;
this.dymax = 0;
this.dymin = 0;
this.data = null;
this.length = 0;
this.xrange = 0;
this.yrange = 0;
this.legend_length = 0;
this.legend_text = null;
this.legend_ix = 0;
this.legend_iy = 0;
this.legend_dx = 0;
this.legend_dy = 0;
this.increment = 0;
this.stride = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.linestyle = 1;
this.linecolor = null;
this.marker = 0;
this.markercolor = null;
this.markerscale = 1.0;
this.clipping = true;
this.sorted = false;
this.stripChart = false;
this.chartPts = 0;
this.tempDatum = Clazz.array(Double.TYPE, [2]);
this.lastPoint = Clazz.array(Double.TYPE, [2]);
this.legend_length = 20;
this.legend_text = null;
this.increment = 100;
this.stride = 2;
}, 1);

Clazz.newMeth(C$, 'setSorted$Z', function (s) {
this.sorted=s;
if (this.sorted) this.insertionSort();
});

Clazz.newMeth(C$, 'isSorted', function () {
return this.sorted;
});

Clazz.newMeth(C$, 'setStripChart$I$Z', function (pts, chart) {
this.stripChart=chart;
this.chartPts=Math.max(pts, 1);
if (this.stripChart) this.chartPoints();
});

Clazz.newMeth(C$, 'isStripChart', function () {
return this.stripChart;
});

Clazz.newMeth(C$, 'getLastPoint', function () {
return this.lastPoint;
});

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.length=0;
this.data=null;
this.lastPoint=Clazz.array(Double.TYPE, [this.stride]);
this.range$I(this.stride);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (stride) {
C$.$init$.apply(this);
if (stride < 2) throw Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["Invalid stride parameter!"]);
this.stride=stride;
this.lastPoint=Clazz.array(Double.TYPE, [stride]);
this.length=0;
this.lastPoint=Clazz.array(Double.TYPE, [stride]);
this.range$I(stride);
}, 1);

Clazz.newMeth(C$, 'c$$DA$I', function (d, n) {
C$.$init$.apply(this);
var i;
var k = 0;
this.length=0;
if (d == null  || d.length == 0  || n <= 0 ) {
throw Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["DataSet: Error in parsed data!"]);
}if (d.length > 20000 || n > 20000 ) {
System.out.println$S("Error: DataSet passed to constructor has too many points.  Max Pointst=" + (this.length/this.stride|0));
return;
}this.lastPoint=Clazz.array(Double.TYPE, [this.stride]);
this.data=Clazz.array(Double.TYPE, [n * this.stride]);
this.length=n * this.stride;
System.arraycopy(d, 0, this.data, 0, this.length);
System.arraycopy(d, this.length - this.stride, this.lastPoint, 0, this.stride);
if (this.sorted) this.insertionSort();
if (this.stripChart) this.chartPoints();
this.range$I(this.stride);
}, 1);

Clazz.newMeth(C$, 'c$$DA$I$I', function (d, n, s) {
C$.$init$.apply(this);
if (s < 2) throw Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["Invalid stride parameter!"]);
var i;
var k = 0;
this.length=0;
if (d == null  || d.length == 0  || n <= 0 ) {
throw Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["DataSet: Error in parsed data!"]);
}if (d.length > 20000 || n > 20000 ) {
System.out.println$S("Error: DataSet passed to constructor has too many points.  Max Pointst=" + (this.length/this.stride|0));
return;
}this.stride=s;
this.lastPoint=Clazz.array(Double.TYPE, [this.stride]);
this.data=Clazz.array(Double.TYPE, [n * this.stride]);
this.length=n * this.stride;
System.arraycopy(d, 0, this.data, 0, this.length);
System.arraycopy(d, this.length - this.stride, this.lastPoint, 0, this.stride);
if (this.sorted) this.insertionSort();
if (this.stripChart) this.chartPoints();
this.range$I(this.stride);
}, 1);

Clazz.newMeth(C$, 'replace$DA$I', function (d, n) {
if (n * this.stride > 20000) {
System.out.println$S("Error: DataSet has too many points.  Max Pointst=" + (this.length/this.stride|0));
return;
}if (d == null  || d.length == 0  || n <= 0 ) {
throw Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["DataSet: Error in replace data!"]);
}if (this.data == null  || this.data.length != d.length ) {
this.length=0;
this.data=null;
this.append$DA$I(d, n);
return;
}System.arraycopy(d, 0, this.data, 0, this.length);
System.arraycopy(d, this.length - this.stride, this.lastPoint, 0, this.stride);
if (this.sorted) this.insertionSort();
if (this.stripChart) this.chartPoints();
this.range$I(this.stride);
if (this.xaxis != null ) this.xaxis.resetRange();
if (this.yaxis != null ) this.yaxis.resetRange();
return;
});

Clazz.newMeth(C$, 'append$DA$I', function (d, n) {
if (n * this.stride > 20000) {
System.out.println$S("Error: DataSet has too many points.  Max Pointst=" + (this.length/this.stride|0));
return;
}var i;
var k = 0;
var tmp;
var ln = n * this.stride;
if (d == null  || d.length == 0  || n <= 0 ) {
throw Clazz.new_(Clazz.load('java.lang.Exception').c$$S,["DataSet: Error in append data!"]);
}if (this.data == null ) {
this.data=Clazz.array(Double.TYPE, [n * this.stride]);
this.length=n * this.stride;
System.arraycopy(d, 0, this.data, 0, this.length);
if (this.sorted) this.insertionSort();
if (this.stripChart) this.chartPoints();
this.range$I(this.stride);
if (this.xaxis != null ) this.xaxis.resetRange();
if (this.yaxis != null ) this.yaxis.resetRange();
System.arraycopy(d, ln - this.stride, this.lastPoint, 0, this.stride);
return;
}if (ln + this.length < this.data.length) {
System.arraycopy(d, 0, this.data, this.length, ln);
this.length+=ln;
} else {
tmp=Clazz.array(Double.TYPE, [ln + this.length + this.increment ]);
if (this.length != 0) {
System.arraycopy(this.data, 0, tmp, 0, this.length);
}System.arraycopy(d, 0, tmp, this.length, ln);
this.length+=ln;
this.data=tmp;
}if (this.sorted && ln == this.stride ) p$.insertDatum$I.apply(this, [this.length - ln]);
 else if (this.sorted) this.insertionSort();
if (this.stripChart) this.chartPoints();
System.arraycopy(d, ln - this.stride, this.lastPoint, 0, this.stride);
if (this.stripChart || n > 1  || this.stride != 2  || this.length < 6 ) this.range$I(this.stride);
 else {
if (this.dxmax < d[0] ) {
this.dxmax=d[0];
} else if (this.dxmin > d[0] ) {
this.dxmin=d[0];
}if (this.dymax < d[1] ) {
this.dymax=d[1];
} else if (this.dymin > d[1] ) {
this.dymin=d[1];
}if (this.xaxis == null ) {
this.xmin=this.dxmin;
this.xmax=this.dxmax;
}if (this.yaxis == null ) {
this.ymin=this.dymin;
this.ymax=this.dymax;
}}if (this.xaxis != null ) this.xaxis.resetRange();
if (this.yaxis != null ) this.yaxis.resetRange();
});

Clazz.newMeth(C$, '$delete$I$I', function (start, end) {
var End = this.stride * end;
var Start = this.stride * start;
if (this.length <= 0) return;
if (End < Start) return;
if (Start < 0) Start=0;
if (End > this.length - this.stride) End=this.length - this.stride;
if (End < this.length - this.stride) {
System.arraycopy(this.data, End + this.stride, this.data, Start, this.length - End - this.stride );
}this.length-=End + this.stride - Start;
this.range$I(this.stride);
if (this.xaxis != null ) this.xaxis.resetRange();
if (this.yaxis != null ) this.yaxis.resetRange();
});

Clazz.newMeth(C$, 'deleteData', function () {
this.length=0;
this.data=null;
this.range$I(this.stride);
if (this.xaxis != null ) this.xaxis.resetRange();
if (this.yaxis != null ) this.yaxis.resetRange();
});

Clazz.newMeth(C$, 'draw_data$java_awt_Graphics$java_awt_Rectangle', function (g, bounds) {
var c;
if (this.xaxis != null ) {
this.xmax=this.xaxis.maximum;
this.xmin=this.xaxis.minimum;
}if (this.yaxis != null ) {
this.ymax=this.yaxis.maximum;
this.ymin=this.yaxis.minimum;
}this.xrange=this.xmax - this.xmin;
this.yrange=this.ymax - this.ymin;
this.draw_legend$java_awt_Graphics$java_awt_Rectangle(g, bounds);
if (this.clipping) g.clipRect$I$I$I$I(bounds.x, bounds.y, bounds.width, bounds.height);
c=g.getColor();
if (this.linestyle != 0) {
if (this.linecolor != null ) g.setColor$java_awt_Color(this.linecolor);
 else g.setColor$java_awt_Color(c);
this.draw_lines$java_awt_Graphics$java_awt_Rectangle(g, bounds);
}if (this.linestyle == 0 && this.marker == 0 ) {
if (this.markercolor != null ) g.setColor$java_awt_Color(this.markercolor);
 else g.setColor$java_awt_Color(c);
this.draw_dots$java_awt_Graphics$java_awt_Rectangle(g, bounds);
}if (this.marker > 0) {
if (this.markercolor != null ) g.setColor$java_awt_Color(this.markercolor);
 else g.setColor$java_awt_Color(c);
this.draw_markers$java_awt_Graphics$java_awt_Rectangle(g, bounds);
}if (this.marker == -1) {
if (this.linecolor != null ) g.setColor$java_awt_Color(this.linecolor);
 else g.setColor$java_awt_Color(c);
p$.draw_polygon$java_awt_Graphics$java_awt_Rectangle.apply(this, [g, bounds]);
}if (this.marker == -2) {
if (this.linecolor != null ) g.setColor$java_awt_Color(this.linecolor);
 else g.setColor$java_awt_Color(c);
p$.draw_polygon2$java_awt_Graphics$java_awt_Rectangle.apply(this, [g, bounds]);
}if (this.marker == -3) {
if (this.linecolor != null ) g.setColor$java_awt_Color(this.linecolor);
 else g.setColor$java_awt_Color(c);
this.draw_histogram$java_awt_Graphics$java_awt_Rectangle(g, bounds);
}g.setColor$java_awt_Color(c);
});

Clazz.newMeth(C$, 'getData', function () {
return this.data;
});

Clazz.newMeth(C$, 'getXmax', function () {
return this.dxmax;
});

Clazz.newMeth(C$, 'getXmin', function () {
return this.dxmin;
});

Clazz.newMeth(C$, 'getYmax', function () {
return this.dymax;
});

Clazz.newMeth(C$, 'getYmin', function () {
return this.dymin;
});

Clazz.newMeth(C$, 'legend$I$I$S', function (x, y, text) {
if (text == null ) {
this.legend_text=null;
return;
}if (this.legend_text == null ) this.legend_text=Clazz.new_((I$[1]||$incl$(1)).c$$S,[text]);
 else this.legend_text.setText$S(text);
this.legend_text.setJustification$I(1);
this.legend_ix=x;
this.legend_iy=y;
this.legend_dx=0.0;
this.legend_dy=0.0;
});

Clazz.newMeth(C$, 'getLegend', function () {
return this.legend_text.getText();
});

Clazz.newMeth(C$, 'getLegend_ix', function () {
return this.legend_ix;
});

Clazz.newMeth(C$, 'getLegend_iy', function () {
return this.legend_iy;
});

Clazz.newMeth(C$, 'legend$D$D$S', function (x, y, text) {
if (text == null ) {
this.legend_text=null;
return;
}if (this.legend_text == null ) this.legend_text=Clazz.new_((I$[1]||$incl$(1)).c$$S,[text]);
 else this.legend_text.setText$S(text);
this.legend_text.setJustification$I(1);
this.legend_dx=x;
this.legend_dy=y;
this.legend_ix=0;
this.legend_iy=0;
});

Clazz.newMeth(C$, 'legendFont$java_awt_Font', function (f) {
if (f == null ) return;
if (this.legend_text == null ) this.legend_text=Clazz.new_((I$[1]||$incl$(1)));
this.legend_text.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$, 'legendColor$java_awt_Color', function (c) {
if (c == null ) return;
if (this.legend_text == null ) this.legend_text=Clazz.new_((I$[1]||$incl$(1)));
this.legend_text.setColor$java_awt_Color(c);
});

Clazz.newMeth(C$, 'dataPoints', function () {
return (this.length/this.stride|0);
});

Clazz.newMeth(C$, 'getPoint$I', function (index) {
var point = Clazz.array(Double.TYPE, [this.stride]);
var i = index * this.stride;
if (index < 0 || i > this.length - this.stride ) return null;
for (var j = 0; j < this.stride; j++) point[j]=this.data[i + j];

return point;
});

Clazz.newMeth(C$, 'getClosestPoint$D$D', function (x, y) {
var point = Clazz.array(Double.TYPE, -1, [0.0, 0.0, 0.0]);
var i;
var xdiff;
var ydiff;
var dist2;
xdiff=this.data[0] - x;
ydiff=this.data[1] - y;
point[0]=this.data[0];
point[1]=this.data[1];
point[2]=xdiff * xdiff + ydiff * ydiff;
for (i=this.stride; i < this.length - 1; i+=this.stride) {
xdiff=this.data[i] - x;
ydiff=this.data[i + 1] - y;
dist2=xdiff * xdiff + ydiff * ydiff;
if (dist2 < point[2] ) {
point[0]=this.data[i];
point[1]=this.data[i + 1];
point[2]=dist2;
}}
return point;
});

Clazz.newMeth(C$, 'draw_polygon2$java_awt_Graphics$java_awt_Rectangle', function (g, w) {
if (this.data == null  || this.data.length < this.stride  || this.data.length < 4 ) return;
var i;
var x0 = 0;
var y0 = 0;
var x1 = 0;
var y1 = 0;
var count = 0;
var xpoints = Clazz.array(Integer.TYPE, [(this.data.length/this.stride|0) + 4]);
var ypoints = Clazz.array(Integer.TYPE, [(this.data.length/this.stride|0) + 4]);
var yOrigin = ((w.y + (1.0 - (0 - this.ymin) / this.yrange) * w.height)|0);
var ySave = 0;
var oldColor = g.getColor();
g.setColor$java_awt_Color(Clazz.new_((I$[2]||$incl$(2)).c$$I$I$I,[0, 255, 255]));
if (this.xmin - this.data[0] > 10 * this.xrange ) x0=-100000;
 else if (this.data[0] - this.xmax > 10 * this.xrange ) x0=100000;
 else x0=((w.x + ((this.data[0] - this.xmin) / this.xrange) * w.width)|0);
if (this.ymin - this.data[1] > 10 * this.yrange ) y0=100000;
 else if (this.data[1] - this.ymax > 10 * this.yrange ) y0=-100000;
 else y0=((w.y + (1.0 - (this.data[1] - this.ymin) / this.yrange) * w.height)|0);
ySave=y0;
if (y0 > yOrigin) y0=yOrigin;
for (i=this.stride; i < this.length; i+=this.stride) {
if (this.xmin - this.data[i] > 10 * this.xrange ) x1=-100000;
 else if (this.data[i] - this.xmax > 10 * this.xrange ) x1=100000;
 else x1=((w.x + ((this.data[i] - this.xmin) / this.xrange) * w.width)|0);
if (this.ymin - this.data[i + 1] > 10 * this.yrange ) y1=100000;
 else if (this.data[i + 1] - this.ymax > 10 * this.yrange ) y1=-100000;
 else y1=((w.y + (1.0 - (this.data[i + 1] - this.ymin) / this.yrange) * w.height)|0);
if (y1 != yOrigin && ((y0 - yOrigin) / (y1 - yOrigin) < 0 )  && y1 != y0 ) {
var m = (x1 - x0) / (y1 - y0);
if (y1 > yOrigin) {
x1=((x0 + (yOrigin - y0) * m)|0);
y1=yOrigin;
}} else if (y0 == yOrigin && y1 < yOrigin ) {
y0=ySave;
var m = (x1 - x0) / (y1 - y0);
x0=((x1 + (yOrigin - y1) * m)|0);
y0=yOrigin;
} else if (y1 > yOrigin) {
ySave=y1;
y1=yOrigin;
}xpoints[count]=x0;
ypoints[count]=y0;
count++;
x0=x1;
y0=y1;
}
xpoints[count]=x0;
ypoints[count]=y0;
count++;
xpoints[count]=x0;
ypoints[count]=yOrigin;
count++;
xpoints[count]=xpoints[0];
ypoints[count]=yOrigin;
count++;
g.fillPolygon$IA$IA$I(xpoints, ypoints, count);
g.setColor$java_awt_Color(oldColor);
g.drawPolygon$IA$IA$I(xpoints, ypoints, count);
count=0;
g.setColor$java_awt_Color(Clazz.new_((I$[2]||$incl$(2)).c$$I$I$I,[255, 255, 0]));
if (this.xmin - this.data[0] > 10 * this.xrange ) x0=-10000;
 else if (this.data[0] - this.xmax > 10 * this.xrange ) x0=10000;
 else x0=((w.x + ((this.data[0] - this.xmin) / this.xrange) * w.width)|0);
if (this.ymin - this.data[1] > 10 * this.yrange ) y0=10000;
 else if (this.data[1] - this.ymax > 10 * this.yrange ) y0=-10000;
 else y0=((w.y + (1.0 - (this.data[1] - this.ymin) / this.yrange) * w.height)|0);
ySave=y0;
if (y0 < yOrigin) y0=yOrigin;
for (i=this.stride; i < this.length; i+=this.stride) {
if (this.xmin - this.data[i] > 10 * this.xrange ) x1=-10000;
 else if (this.data[i] - this.xmax > 10 * this.xrange ) x1=10000;
 else x1=((w.x + ((this.data[i] - this.xmin) / this.xrange) * w.width)|0);
if (this.ymin - this.data[i + 1] > 10 * this.yrange ) y1=10000;
 else if (this.data[i + 1] - this.ymax > 10 * this.yrange ) y1=-10000;
 else y1=((w.y + (1.0 - (this.data[i + 1] - this.ymin) / this.yrange) * w.height)|0);
if (y1 != yOrigin && ((y0 - yOrigin) / (y1 - yOrigin) < 0 )  && y1 != y0 ) {
var m = (x1 - x0) / (y1 - y0);
if (y1 < yOrigin) {
x1=((x0 + (yOrigin - y0) * m)|0);
y1=yOrigin;
}} else if (y0 == yOrigin && y1 > yOrigin ) {
y0=ySave;
var m = (x1 - x0) / (y1 - y0);
x0=((x1 + (yOrigin - y1) * m)|0);
y0=yOrigin;
} else if (y1 < yOrigin) {
ySave=y1;
y1=yOrigin;
}xpoints[count]=x0;
ypoints[count]=y0;
count++;
x0=x1;
y0=y1;
}
xpoints[count]=x0;
ypoints[count]=y0;
count++;
xpoints[count]=x0;
ypoints[count]=yOrigin;
count++;
xpoints[count]=xpoints[0];
ypoints[count]=yOrigin;
count++;
g.fillPolygon$IA$IA$I(xpoints, ypoints, count);
g.setColor$java_awt_Color(oldColor);
g.drawPolygon$IA$IA$I(xpoints, ypoints, count);
});

Clazz.newMeth(C$, 'draw_polygon$java_awt_Graphics$java_awt_Rectangle', function (g, w) {
if (this.data == null  || this.data.length < this.stride  || this.data.length < 4 ) return;
var i;
var x0 = 0;
var y0 = 0;
var x1 = 0;
var y1 = 0;
var count = 0;
var xpoints = Clazz.array(Integer.TYPE, [(this.data.length/this.stride|0) + 4]);
var ypoints = Clazz.array(Integer.TYPE, [(this.data.length/this.stride|0) + 4]);
var yOrigin = ((w.y + (1.0 - (0 - this.ymin) / this.yrange) * w.height)|0);
if (this.xmin - this.data[0] > 10 * this.xrange ) x0=-10000;
 else if (this.data[0] - this.xmax > 10 * this.xrange ) x0=10000;
 else x0=((w.x + ((this.data[0] - this.xmin) / this.xrange) * w.width)|0);
if (this.ymin - this.data[1] > 10 * this.yrange ) y0=10000;
 else if (this.data[1] - this.ymax > 10 * this.yrange ) y0=-10000;
 else y0=((w.y + (1.0 - (this.data[1] - this.ymin) / this.yrange) * w.height)|0);
for (i=this.stride; i < this.length; i+=this.stride) {
if (this.xmin - this.data[i] > 10 * this.xrange ) x1=-10000;
 else if (this.data[i] - this.xmax > 10 * this.xrange ) x1=10000;
 else x1=((w.x + ((this.data[i] - this.xmin) / this.xrange) * w.width)|0);
if (this.ymin - this.data[i + 1] > 10 * this.yrange ) y1=10000;
 else if (this.data[i + 1] - this.ymax > 10 * this.yrange ) y1=-10000;
 else y1=((w.y + (1.0 - (this.data[i + 1] - this.ymin) / this.yrange) * w.height)|0);
xpoints[count]=x0;
ypoints[count]=y0;
count++;
x0=x1;
y0=y1;
}
xpoints[count]=x0;
ypoints[count]=y0;
count++;
xpoints[count]=x0;
ypoints[count]=yOrigin;
count++;
xpoints[count]=xpoints[0];
ypoints[count]=yOrigin;
count++;
g.fillPolygon$IA$IA$I(xpoints, ypoints, count);
});

Clazz.newMeth(C$, 'draw_histogram$java_awt_Graphics$java_awt_Rectangle', function (g, w) {
if (this.data == null  || this.data.length < this.stride  || this.data.length < 2 ) return;
var m = this.g2d.getMarkers();
if (m == null ) return;
var binwidth = ((this.markerscale * 2)|0);
var x1 = 0;
var y1 = 0;
var yOrigin = ((w.y + (1.0 - (0 - this.ymin) / this.yrange) * w.height)|0);
for (var i = 0; i < this.length; i+=this.stride) {
if (this.xmin - this.data[i] > 10 * this.xrange ) x1=-10000;
 else if (this.data[i] - this.xmax > 10 * this.xrange ) x1=10000;
 else x1=((w.x + ((this.data[i] - this.xmin) / this.xrange) * w.width)|0);
if (this.ymin - this.data[i + 1] > 10 * this.yrange ) y1=10000;
 else if (this.data[i + 1] - this.ymax > 10 * this.yrange ) y1=-10000;
 else y1=((w.y + (1.0 - (this.data[i + 1] - this.ymin) / this.yrange) * w.height)|0);
if (yOrigin - y1 < 0) g.fillRect$I$I$I$I(x1 - binwidth, yOrigin + 1, 2 * binwidth + 1, -yOrigin + y1);
 else g.fillRect$I$I$I$I(x1 - binwidth, y1 + 1, 2 * binwidth + 1, yOrigin - y1);
}
});

Clazz.newMeth(C$, 'draw_lines$java_awt_Graphics$java_awt_Rectangle', function (g, w) {
var i;
var x0 = 0;
var y0 = 0;
var x1 = 0;
var y1 = 0;
if (this.data == null  || this.data.length < this.stride ) return;
if (this.xmin - this.data[0] > 10 * this.xrange ) x0=-10000;
 else if (this.data[0] - this.xmax > 10 * this.xrange ) x0=10000;
 else x0=((w.x + ((this.data[0] - this.xmin) / this.xrange) * w.width)|0);
if (this.ymin - this.data[1] > 10 * this.yrange ) y0=10000;
 else if (this.data[1] - this.ymax > 10 * this.yrange ) y0=-10000;
 else y0=((w.y + (1.0 - (this.data[1] - this.ymin) / this.yrange) * w.height)|0);
for (i=this.stride; i < this.length; i+=this.stride) {
if (this.xmin - this.data[i] > 10 * this.xrange ) x1=-10000;
 else if (this.data[i] - this.xmax > 10 * this.xrange ) x1=10000;
 else x1=((w.x + ((this.data[i] - this.xmin) / this.xrange) * w.width)|0);
if (this.ymin - this.data[i + 1] > 10 * this.yrange ) y1=10000;
 else if (this.data[i + 1] - this.ymax > 10 * this.yrange ) y1=-10000;
 else y1=((w.y + (1.0 - (this.data[i + 1] - this.ymin) / this.yrange) * w.height)|0);
g.drawLine$I$I$I$I(x0, y0, x1, y1);
x0=x1;
y0=y1;
}
});

Clazz.newMeth(C$, 'inside$D$D', function (x, y) {
if (x >= this.xmin  && x <= this.xmax   && y >= this.ymin   && y <= this.ymax  ) return true;
return false;
});

Clazz.newMeth(C$, 'draw_markers$java_awt_Graphics$java_awt_Rectangle', function (g, w) {
var x1;
var y1;
var i;
var clip = g.getClipBounds();
var xcmin = clip.x;
var xcmax = clip.x + clip.width;
var ycmin = clip.y;
var ycmax = clip.y + clip.height;
var m = this.g2d.getMarkers();
if (m == null ) return;
for (i=0; i < this.length; i+=this.stride) {
if (this.inside$D$D(this.data[i], this.data[i + 1])) {
x1=((w.x + ((this.data[i] - this.xmin) / this.xrange) * w.width)|0);
y1=((w.y + (1.0 - (this.data[i + 1] - this.ymin) / this.yrange) * w.height)|0);
if (x1 >= xcmin && x1 <= xcmax  && y1 >= ycmin  && y1 <= ycmax ) m.draw$java_awt_Graphics$I$D$I$I(g, this.marker, this.markerscale, x1, y1);
}}
});

Clazz.newMeth(C$, 'draw_dots$java_awt_Graphics$java_awt_Rectangle', function (g, w) {
var x1;
var y1;
var i;
var clip = g.getClipBounds();
var xcmin = clip.x;
var xcmax = clip.x + clip.width;
var ycmin = clip.y;
var ycmax = clip.y + clip.height;
for (i=0; i < this.length; i+=this.stride) {
if (this.inside$D$D(this.data[i], this.data[i + 1])) {
x1=((w.x + ((this.data[i] - this.xmin) / this.xrange) * w.width)|0);
y1=((w.y + (1.0 - (this.data[i + 1] - this.ymin) / this.yrange) * w.height)|0);
if (x1 >= xcmin && x1 <= xcmax  && y1 >= ycmin  && y1 <= ycmax ) g.drawLine$I$I$I$I(x1, y1, x1, y1);
}}
});

Clazz.newMeth(C$, 'draw_legend$java_awt_Graphics$java_awt_Rectangle', function (g, w) {
var c = g.getColor();
var m = null;
if (this.legend_text == null ) return;
if (this.legend_text.isNull()) return;
if (this.legend_ix == 0 && this.legend_iy == 0 ) {
this.legend_ix=((w.x + ((this.legend_dx - this.xmin) / this.xrange) * w.width)|0);
this.legend_iy=((w.y + (1.0 - (this.legend_dy - this.ymin) / this.yrange) * w.height)|0);
}if (this.linestyle != 0) {
if (this.linecolor != null ) g.setColor$java_awt_Color(this.linecolor);
g.drawLine$I$I$I$I(this.legend_ix, this.legend_iy, this.legend_ix + this.legend_length, this.legend_iy);
}if (this.marker > 0) {
m=this.g2d.getMarkers();
if (m != null ) {
if (this.markercolor != null ) g.setColor$java_awt_Color(this.markercolor);
 else g.setColor$java_awt_Color(c);
m.draw$java_awt_Graphics$I$D$I$I(g, this.marker, 1.0, this.legend_ix + (this.legend_length/2|0), this.legend_iy);
}}this.legend_text.draw$java_awt_Graphics$I$I(g, this.legend_ix + this.legend_length + this.legend_text.charWidth$java_awt_Graphics$C(g, " ") , this.legend_iy + (this.legend_text.getAscent$java_awt_Graphics(g)/3|0));
g.setColor$java_awt_Color(c);
});

Clazz.newMeth(C$, 'range$I', function (stride) {
var i;
if (this.length >= stride) {
this.dxmax=this.data[0];
this.dymax=this.data[1];
this.dxmin=this.dxmax;
this.dymin=this.dymax;
} else {
this.dxmin=0.0;
this.dxmax=0.0;
this.dymin=0.0;
this.dymax=0.0;
}for (i=stride; i < this.length; i+=stride) {
if (this.dxmax < this.data[i] ) {
this.dxmax=this.data[i];
} else if (this.dxmin > this.data[i] ) {
this.dxmin=this.data[i];
}if (this.dymax < this.data[i + 1] ) {
this.dymax=this.data[i + 1];
} else if (this.dymin > this.data[i + 1] ) {
this.dymin=this.data[i + 1];
}}
if (this.xaxis == null ) {
this.xmin=this.dxmin;
this.xmax=this.dxmax;
}if (this.yaxis == null ) {
this.ymin=this.dymin;
this.ymax=this.dymax;
}});

Clazz.newMeth(C$, 'insertDatum$I', function (index) {
if (this.length < 2 * this.stride) return;
if (this.tempDatum.length != this.stride) this.tempDatum=Clazz.array(Double.TYPE, [this.stride]);
System.arraycopy(this.data, index, this.tempDatum, 0, this.stride);
for (var i = 0; i < this.length; i+=this.stride) {
if (this.data[i] > this.data[index] ) {
System.arraycopy(this.data, i, this.data, i + this.stride, this.length - i - this.stride );
System.arraycopy(this.tempDatum, 0, this.data, i, this.stride);
return;
}}
});

Clazz.newMeth(C$, 'insertionSort', function () {
if (this.length < 2 * this.stride) return;
for (var i = this.stride; i < this.length; i+=this.stride) {
if (this.data[i] < this.data[i - this.stride] ) {
p$.insertDatum$I.apply(this, [i]);
}}
});

Clazz.newMeth(C$, 'chartPoints', function () {
if (this.length <= this.chartPts * this.stride) return;
System.arraycopy(this.data, this.length - this.chartPts * this.stride, this.data, 0, this.chartPts * this.stride);
this.length=this.chartPts * this.stride;
});
})();
//Created 2018-07-23 12:59:46 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
