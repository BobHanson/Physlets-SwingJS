(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['java.awt.Color','edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Battery", null, 'circuitsimulator.Source');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$I$S$D', function (circ, pol, r, c, t, v) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circ, pol, r, c, t]);
C$.$init$.apply(this);
if (v < 0 ) {
v = -v;
this.changePolarity();
}this.value = v;
this.$function = "" + Double.toString(this.value);
this.setValueVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.polarity = "p";
}, 1);

Clazz.newMeth(C$, 'loadImage$java_awt_Graphics', function (g) {
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var p = this.polarity.equals$O("p") ? (this.circuit.interGrid/2|0) + 1 : (this.circuit.interGrid/2|0) - 2;
var p2 = this.polarity.equals$O("p") ? (this.circuit.interGrid/2|0) + 2 : (this.circuit.interGrid/2|0) - 3;
g.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
if (this.to.equals$O("h")) {
g.drawLine$I$I$I$I(this.$x + 3, this.$y, this.$x + (this.circuit.interGrid/2|0) - 2, this.$y);
g.drawLine$I$I$I$I(this.$x + (this.circuit.interGrid/2|0) + 1, this.$y, this.$x + this.circuit.interGrid - 4, this.$y);
g.drawLine$I$I$I$I(this.$x + p, this.$y - 6, this.$x + p, this.$y + 6);
g.drawLine$I$I$I$I(this.$x + this.circuit.interGrid - 1 - p, this.$y - 3, this.$x + this.circuit.interGrid - 1 - p, this.$y + 3);
g.drawLine$I$I$I$I(this.$x + this.circuit.interGrid - 1 - p2, this.$y - 3, this.$x + this.circuit.interGrid - 1 - p2, this.$y + 3);
} else {
g.drawLine$I$I$I$I(this.$x, this.$y + 3, this.$x, this.$y + (this.circuit.interGrid/2|0) - 2);
g.drawLine$I$I$I$I(this.$x, this.$y + (this.circuit.interGrid/2|0) + 1, this.$x, this.$y + this.circuit.interGrid - 4);
g.drawLine$I$I$I$I(this.$x - 6, this.$y + p, this.$x + 6, this.$y + p);
g.drawLine$I$I$I$I(this.$x - 3, this.$y + this.circuit.interGrid - 1 - p, this.$x + 3, this.$y + this.circuit.interGrid - 1 - p);
g.drawLine$I$I$I$I(this.$x - 3, this.$y + this.circuit.interGrid - 1 - p2, this.$x + 3, this.$y + this.circuit.interGrid - 1 - p2);
}});

Clazz.newMeth(C$, 'getV$D', function (t) {
return this.value;
});

Clazz.newMeth(C$, 'valueStr', function () {
return this.format.form$D(this.value);
});

Clazz.newMeth(C$, 'getStringAdditions', function () {
return ",v=" + Double.toString(this.value) + ",r=" + new Double(this.internalResistance).toString() ;
});

Clazz.newMeth(C$, 'parsefunction', function () {
});

Clazz.newMeth(C$, 'set$S', function (list) {
var ret = C$.superclazz.prototype.set$S.apply(this, [list]);
if ((I$[2]||$incl$(2)).parameterExist$S$S(list, "v=")) {
var v = (I$[2]||$incl$(2)).getParam$S$S(list, "v=");
if (v < 0 ) {
v = -v;
this.changePolarity();
}this.value = v;
this.$function = "" + Double.toString(this.value);
}return ret;
});

Clazz.newMeth(C$, 'setvalue$S', function (s) {
var v = (Double.$valueOf(s)).doubleValue();
if (v < 0 ) {
v = -v;
this.changePolarity();
}this.value = v;
this.$function = "" + Double.toString(this.value);
});
})();
//Created 2018-02-06 06:55:32
