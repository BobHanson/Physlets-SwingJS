(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'java.awt.MenuItem',['circuitsimulator.PopupOnElement','.SymAction'],'circuitsimulator.ValueInput','circuitsimulator.ValueKnob','circuitsimulator.OscilloDialog','circuitsimulator.Meter','circuitsimulator.DataGraphDialog']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "PopupOnElement", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.PopupMenu');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.cb=null;
this.$delete=null;
this.changevalue=null;
this.knobvalue=null;
this.knobfrequency=null;
this.showvalue=null;
this.changeswitch=null;
this.changepolarity=null;
this.elemlabel=null;
this.msep=null;
this.getvoltage=null;
this.voltmeter=null;
this.ammeter=null;
this.vgraph=null;
this.igraph=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$delete=Clazz.new_($I$(1));
this.changevalue=Clazz.new_($I$(1));
this.knobvalue=Clazz.new_($I$(1));
this.knobfrequency=Clazz.new_($I$(1));
this.showvalue=Clazz.new_($I$(1));
this.changeswitch=Clazz.new_($I$(1));
this.changepolarity=Clazz.new_($I$(1));
this.elemlabel=Clazz.new_($I$(1));
this.msep=Clazz.new_($I$(1).c$$S,["-"]);
this.getvoltage=Clazz.new_($I$(1));
this.voltmeter=Clazz.new_($I$(1));
this.ammeter=Clazz.new_($I$(1));
this.vgraph=Clazz.new_($I$(1));
this.igraph=Clazz.new_($I$(1));
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_CircuitBuilder', function (circuitBuilder) {
Clazz.super_(C$, this,1);
this.cb=circuitBuilder;
this.vcInit$();
this.$delete.setLabel$S(this.cb.cirProp.getProperty$S("menu_delete"));
this.changevalue.setLabel$S(this.cb.cirProp.getProperty$S("menu_changevalue"));
this.knobvalue.setLabel$S(this.cb.cirProp.getProperty$S("menu_knobvalue"));
this.knobfrequency.setLabel$S(this.cb.cirProp.getProperty$S("menu_knobfrequency"));
this.showvalue.setLabel$S(this.cb.cirProp.getProperty$S("menu_showvalue"));
this.changeswitch.setLabel$S(this.cb.cirProp.getProperty$S("menu_changeswitch"));
this.changepolarity.setLabel$S(this.cb.cirProp.getProperty$S("menu_changepolarity"));
this.elemlabel.setLabel$S(this.cb.cirProp.getProperty$S("menu_elemlabel"));
this.getvoltage.setLabel$S(this.cb.cirProp.getProperty$S("menu_getvoltage"));
this.voltmeter.setLabel$S(this.cb.cirProp.getProperty$S("menu_voltmeter"));
this.ammeter.setLabel$S(this.cb.cirProp.getProperty$S("menu_ammeter"));
this.vgraph.setLabel$S(this.cb.cirProp.getProperty$S("menu_vgraph"));
this.igraph.setLabel$S(this.cb.cirProp.getProperty$S("menu_igraph"));
}, 1);

Clazz.newMeth(C$, 'vcInit$', function () {
this.setLabel$S("Select Action");
this.add$java_awt_MenuItem(this.$delete);
this.add$java_awt_MenuItem(this.changevalue);
this.add$java_awt_MenuItem(this.knobvalue);
this.add$java_awt_MenuItem(this.knobfrequency);
this.add$java_awt_MenuItem(this.showvalue);
this.add$java_awt_MenuItem(this.elemlabel);
this.add$java_awt_MenuItem(this.msep);
this.add$java_awt_MenuItem(this.getvoltage);
this.add$java_awt_MenuItem(this.voltmeter);
this.add$java_awt_MenuItem(this.ammeter);
this.add$java_awt_MenuItem(this.vgraph);
this.add$java_awt_MenuItem(this.igraph);
this.add$java_awt_MenuItem(this.changeswitch);
this.add$java_awt_MenuItem(this.changepolarity);
var lSymAction=Clazz.new_($I$(2), [this, null]);
this.$delete.addActionListener$java_awt_event_ActionListener(lSymAction);
this.changevalue.addActionListener$java_awt_event_ActionListener(lSymAction);
this.knobvalue.addActionListener$java_awt_event_ActionListener(lSymAction);
this.knobfrequency.addActionListener$java_awt_event_ActionListener(lSymAction);
this.showvalue.addActionListener$java_awt_event_ActionListener(lSymAction);
this.elemlabel.addActionListener$java_awt_event_ActionListener(lSymAction);
this.getvoltage.addActionListener$java_awt_event_ActionListener(lSymAction);
this.voltmeter.addActionListener$java_awt_event_ActionListener(lSymAction);
this.ammeter.addActionListener$java_awt_event_ActionListener(lSymAction);
this.vgraph.addActionListener$java_awt_event_ActionListener(lSymAction);
this.igraph.addActionListener$java_awt_event_ActionListener(lSymAction);
this.changeswitch.addActionListener$java_awt_event_ActionListener(lSymAction);
this.changepolarity.addActionListener$java_awt_event_ActionListener(lSymAction);
this.enableItems$();
});

Clazz.newMeth(C$, 'enableItems$', function () {
this.changevalue.setEnabled$Z(true);
this.knobvalue.setEnabled$Z(false);
this.showvalue.setEnabled$Z(true);
this.knobfrequency.setEnabled$Z(false);
this.getvoltage.setEnabled$Z(false);
this.voltmeter.setEnabled$Z(false);
this.ammeter.setEnabled$Z(false);
this.changeswitch.setEnabled$Z(false);
this.changepolarity.setEnabled$Z(false);
});

Clazz.newMeth(C$, 'selectItems$', function () {
if (this.cb == null ) return;
var cename="" + this.cb.currentElement.getMyName$();
this.enableItems$();
if (cename.equals$O("switch")) {
this.changeswitch.setEnabled$Z(true);
this.changevalue.setEnabled$Z(false);
} else if (cename.equals$O("scope")) {
if (this.cb.parsed) this.getvoltage.setEnabled$Z(true);
} else if (cename.equals$O("vmeter")) {
if (this.cb.parsed) this.voltmeter.setEnabled$Z(true);
} else if (cename.equals$O("ameter")) {
if (this.cb.parsed) this.ammeter.setEnabled$Z(true);
} else if (cename.equals$O("resistor") || cename.equals$O("capacitor") || cename.equals$O("inductor") || cename.equals$O("currentsource") || cename.equals$O("battery")  ) {
this.knobvalue.setEnabled$Z(true);
} else if (cename.equals$O("source") || cename.equals$O("sinwave") || cename.equals$O("squarewave")  ) {
if (this.cb.parsed) this.knobfrequency.setEnabled$Z(true);
}if (this.cb.currentElement.polarized) this.changepolarity.setEnabled$Z(true);
});

Clazz.newMeth(C$, 'delete_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.cb.removeObject$I(this.cb.currentElement.hashCode$());
this.cb.parse$();
this.cb.repaintMeters$();
});

Clazz.newMeth(C$, 'changevalue_ActionPerformed$java_awt_event_ActionEvent', function (event) {
Clazz.new_($I$(3).c$$S$circuitsimulator_CircuitBuilder$java_awt_Component,[this.cb.cirProp.getProperty$S("changevalue_title"), this.cb, this.getAnchorPoint$()]);
});

Clazz.newMeth(C$, 'knobvalue_ActionPerformed$java_awt_event_ActionEvent', function (event) {
Clazz.new_($I$(4).c$$S$circuitsimulator_CircuitBuilder$java_awt_Component,["", this.cb, this.getAnchorPoint$()]);
});

Clazz.newMeth(C$, 'knobfrequency_ActionPerformed$java_awt_event_ActionEvent', function (event) {
Clazz.new_($I$(4).c$$S$circuitsimulator_CircuitBuilder$java_awt_Component,["Hz", this.cb, this.getAnchorPoint$()]);
});

Clazz.newMeth(C$, 'showvalue_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.cb.currentElement.setValueVisible$Z(!this.cb.currentElement.valueVisible);
this.cb.circanvas.redraw$();
});

Clazz.newMeth(C$, 'elemlabel_ActionPerformed$java_awt_event_ActionEvent', function (event) {
Clazz.new_($I$(3).c$$S$circuitsimulator_CircuitBuilder$java_awt_Component,[this.cb.cirProp.getProperty$S("elemlabel_title"), this.cb, this.getAnchorPoint$()]);
});

Clazz.newMeth(C$, 'getAnchorPoint$', function () {
var c=this.getParent$();
while (c != null  && !(Clazz.instanceOf(c, "java.awt.Frame"))  && !(Clazz.instanceOf(c, "java.applet.Applet")) )c=(c).getParent$();

return c;
});

Clazz.newMeth(C$, 'getvoltage_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

var oscdiag=Clazz.new_($I$(5).c$$java_awt_Frame$circuitsimulator_CircuitBuilder,[anchorpoint, this.cb]);
this.cb.scopeList.addElement$TE(oscdiag);
oscdiag.setVisible$Z(true);
});

Clazz.newMeth(C$, 'voltmeter_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

var voltMeter=Clazz.new_($I$(6).c$$S$circuitsimulator_CircuitBuilder$java_awt_Frame,["V", this.cb, anchorpoint]);
this.cb.meterList.addElement$TE(voltMeter);
voltMeter.setVisible$Z(true);
});

Clazz.newMeth(C$, 'ammeter_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

var ampMeter=Clazz.new_($I$(6).c$$S$circuitsimulator_CircuitBuilder$java_awt_Frame,["A", this.cb, anchorpoint]);
this.cb.meterList.addElement$TE(ampMeter);
ampMeter.setVisible$Z(true);
});

Clazz.newMeth(C$, 'vgraph_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

var graphdialog=Clazz.new_($I$(7).c$$java_awt_Frame$circuitsimulator_CircuitBuilder$S,[anchorpoint, this.cb, "v"]);
this.cb.graphList.addElement$TE(graphdialog);
graphdialog.setVisible$Z(true);
});

Clazz.newMeth(C$, 'igraph_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

var graphdialog=Clazz.new_($I$(7).c$$java_awt_Frame$circuitsimulator_CircuitBuilder$S,[anchorpoint, this.cb, "i"]);
this.cb.graphList.addElement$TE(graphdialog);
graphdialog.setVisible$Z(true);
});

Clazz.newMeth(C$, 'changeswitch_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

(this.cb.currentElement).change$();
this.cb.cirgrid.buildEquations$();
this.cb.calculateCircuit$();
this.cb.circanvas.redraw$();
this.cb.repaintMeters$();
});

Clazz.newMeth(C$, 'changepolarity_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

(this.cb.currentElement).changePolarity$();
this.cb.parse$();
this.cb.circanvas.redraw$();
this.cb.repaintMeters$();
});
;
(function(){var C$=Clazz.newClass(P$.PopupOnElement, "SymAction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (event) {
var object=event.getSource$();
if (object === this.this$0.$delete ) this.this$0.delete_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.changevalue ) this.this$0.changevalue_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.knobvalue ) this.this$0.knobvalue_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.knobfrequency ) this.this$0.knobfrequency_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.showvalue ) this.this$0.showvalue_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.elemlabel ) this.this$0.elemlabel_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.getvoltage ) this.this$0.getvoltage_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.voltmeter ) this.this$0.voltmeter_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.ammeter ) this.this$0.ammeter_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.vgraph ) this.this$0.vgraph_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.igraph ) this.this$0.igraph_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.changeswitch ) this.this$0.changeswitch_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.changepolarity ) this.this$0.changepolarity_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:49 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
