(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'java.awt.Label','symantec.itools.awt.util.spinner.ListSpinner','java.awt.Color','java.awt.Font','edu.davidson.display.Format',['circuitsimulator.Meter','.SymWindow'],['circuitsimulator.Meter','.SymAction']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Meter", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.Dialog');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.cb=null;
this.elementID=0;
this.ce=null;
this.format=null;
this.$type=null;
this.fComponentsAdjusted=false;
this.numeric=null;
this.scale=null;
this.mode=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.cb=null;
this.$type="";
this.fComponentsAdjusted=false;
this.numeric=Clazz.new_(Clazz.load('java.awt.Label'));
this.scale=Clazz.new_($I$(1));
this.mode=Clazz.new_(Clazz.load('symantec.itools.awt.util.spinner.ListSpinner'));
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame', function (parent) {
C$.superclazz.c$$java_awt_Frame.apply(this, [parent]);
C$.$init$.apply(this);
this.setLayout$java_awt_LayoutManager(null);
this.setSize$I$I(192, 77);
this.setVisible$Z(false);
this.numeric.setText$S("0.0");
this.numeric.setAlignment$I(2);
this.add$java_awt_Component(this.numeric);
this.numeric.setBackground$java_awt_Color(Clazz.load('java.awt.Color').black);
this.numeric.setForeground$java_awt_Color($I$(3).yellow);
this.numeric.setFont$java_awt_Font(Clazz.new_(Clazz.load('java.awt.Font').c$$S$I$I,["MonoSpaced", 1, 12]));
this.numeric.setBounds$I$I$I$I(12, 12, 144, 24);
this.scale.setText$S("V");
this.scale.setAlignment$I(2);
this.add$java_awt_Component(this.scale);
this.scale.setBackground$java_awt_Color($I$(3).black);
this.scale.setForeground$java_awt_Color($I$(3).yellow);
this.scale.setFont$java_awt_Font(Clazz.new_($I$(4).c$$S$I$I,["MonoSpaced", 1, 12]));
this.scale.setBounds$I$I$I$I(156, 12, 24, 24);
try {
{
var tempString=Clazz.array(String, [2]);
tempString[0]="DC";
tempString[1]="AC";
this.mode.setListItems$SA(tempString);
}} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.add$java_awt_Component(this.mode);
this.mode.setBounds$I$I$I$I(68, 46, 61, 22);
this.setTitle$S("Meter");
this.format=Clazz.new_(Clazz.load('edu.davidson.display.Format').c$$S,["%6.4f"]);
var aSymWindow=Clazz.new_(Clazz.load(['circuitsimulator.Meter','.SymWindow']), [this, null]);
this.addWindowListener$java_awt_event_WindowListener(aSymWindow);
var lSymAction=Clazz.new_(Clazz.load(['circuitsimulator.Meter','.SymAction']), [this, null]);
this.mode.addActionListener$java_awt_event_ActionListener(lSymAction);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame$Z', function (parent, modal) {
C$.c$$java_awt_Frame.apply(this, [parent]);
this.setModal$Z(modal);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Frame$S$Z', function (parent, title, modal) {
C$.c$$java_awt_Frame$Z.apply(this, [parent, modal]);
this.setTitle$S(title);
}, 1);

Clazz.newMeth(C$, 'c$$S$circuitsimulator_CircuitBuilder$java_awt_Frame', function (t, cirbuilder, parent) {
C$.c$$java_awt_Frame.apply(this, [parent]);
this.cb=cirbuilder;
this.elementID=this.cb.currentElement.hashCode$();
this.ce=this.cb.currentElement;
this.$type += t;
this.recalc$();
this.setTitle$S(this.cb.cirProp.getProperty$S(this.ce.getMyName$()) + " " + this.ce.getlabel$() );
this.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'addNotify$', function () {
var d=this.getSize$();
C$.superclazz.prototype.addNotify$.apply(this, []);
if (this.fComponentsAdjusted) return;
var ins=this.getInsets$();
this.setSize$I$I(ins.left + ins.right + d.width , ins.top + ins.bottom + d.height );
var components=this.getComponents$();
for (var i=0; i < components.length; i++) {
var p=components[i].getLocation$();
p.translate$I$I(ins.left, ins.top);
components[i].setLocation$java_awt_Point(p);
}
this.fComponentsAdjusted=true;
});

Clazz.newMeth(C$, 'setVisible$Z', function (b) {
if (b) {
var bounds=this.getParent$().getBounds$();
var abounds=this.getBounds$();
this.setLocation$I$I(bounds.x + ((bounds.width - abounds.width)/2|0), bounds.y + ((bounds.height - abounds.height)/2|0));
}C$.superclazz.prototype.setVisible$Z.apply(this, [b]);
});

Clazz.newMeth(C$, 'Meter_WindowClosing$java_awt_event_WindowEvent', function (event) {
this.cb.meterList.removeElement$O(this);
this.dispose$();
});

Clazz.newMeth(C$, 'setDisplay$D', function (v) {
if (Math.abs(v) < 1.0E-8 ) {
this.scale.setText$S("n" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 1.0E9));
} else if (Math.abs(v) < 1.0E-4 ) {
this.scale.setText$S("ï¿½" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 1000000.0));
} else if (Math.abs(v) < 0.1 ) {
this.scale.setText$S("m" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 1000.0));
} else if (Math.abs(v) < 1000.0 ) {
this.scale.setText$S(this.$type);
this.numeric.setText$S(this.format.form$D(v));
} else if (Math.abs(v) < 1000000.0 ) {
this.scale.setText$S("k" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 0.001));
} else {
this.scale.setText$S("M" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 1.0E-6));
}});

Clazz.newMeth(C$, 'recalc$', function () {
var v=0.0;
if (this.mode.getCurrentText$().equals$O("AC")) {
if (this.$type.equals$O("V")) v=this.cb.getVrms$I(this.elementID);
 else if (this.$type.equals$O("A")) v=this.cb.getIrms$I(this.elementID);
} else {
if (this.$type.equals$O("V")) v=this.ce.getV$();
 else if (this.$type.equals$O("A")) v=this.ce.getI$();
v=v * ((this.ce.direction == this.ce.vequation.direction) ? 1 : -1);
}this.setDisplay$D(v);
});

Clazz.newMeth(C$, 'mode_actionPerformed$java_awt_event_ActionEvent', function (event) {
this.recalc$();
});
;
(function(){var C$=Clazz.newClass(P$.Meter, "SymWindow", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.WindowAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0 ) this.this$0.Meter_WindowClosing$java_awt_event_WindowEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.Meter, "SymAction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (event) {
var object=event.getSource$();
if (object === this.this$0.mode ) this.this$0.mode_actionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:16 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
