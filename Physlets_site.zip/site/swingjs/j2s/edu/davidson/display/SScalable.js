(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[];
var C$=Clazz.newInterface(P$, "SScalable");
})();
//Created 2018-02-24 16:21:11
