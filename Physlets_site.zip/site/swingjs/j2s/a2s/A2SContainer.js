(function(){var P$=Clazz.newPackage("a2s"),I$=[];
var C$=Clazz.newInterface(P$, "A2SContainer");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:43 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
