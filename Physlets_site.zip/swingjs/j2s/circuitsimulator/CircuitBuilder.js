(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['circuitsimulator.BorderPanel','circuitsimulator.BuilderPanel','java.util.Vector','java.awt.Color',['circuitsimulator.CircuitBuilder','.SymMouse'],'circuitsimulator.PopupOnElement','Thread','java.awt.Cursor','circuitsimulator.Circuit','java.awt.Point','edu.davidson.tools.SUtil','java.net.URL','java.io.BufferedReader','java.io.InputStreamReader']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CircuitBuilder", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'circuitsimulator.Circuit');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.borderPanel = null;
this.builderPanel = null;
this.popupOnElement = null;
this.currentElement = null;
this.scopeList = null;
this.meterList = null;
this.graphList = null;
this.componentList = null;
this.oscdiag = null;
this.meter = null;
this.graph = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.borderPanel = Clazz.new_((I$[1]||$incl$(1)));
this.builderPanel = Clazz.new_((I$[2]||$incl$(2)));
this.currentElement = null;
this.scopeList = Clazz.new_((I$[3]||$incl$(3)));
this.meterList = Clazz.new_((I$[3]||$incl$(3)));
this.graphList = Clazz.new_((I$[3]||$incl$(3)));
this.componentList = "";
this.oscdiag = null;
this.meter = null;
this.graph = null;
}, 1);

Clazz.newMeth(C$, 'init', function () {
C$.superclazz.prototype.init.apply(this, []);
this.setLayout$java_awt_LayoutManager(null);
this.setBackground$java_awt_Color(Clazz.new_((I$[4]||$incl$(4)).c$$I$I$I,[0, 143, 213]));
this.setSize$I$I(514, 445);
try {
this.borderPanel.setBevelStyle$S((I$[1]||$incl$(1)).BEVEL_RAISED);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setIPadBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setIPadSides$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setIPadTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.borderPanel.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.borderPanel);
this.borderPanel.setBounds$I$I$I$I(0, 0, 514, 444);
try {
this.builderPanel.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setBevelStyle$S((I$[1]||$incl$(1)).BEVEL_LOWERED);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e, "java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.builderPanel.setLayout$java_awt_LayoutManager(null);
this.borderPanel.add$java_awt_Component(this.builderPanel);
this.builderPanel.setBackground$java_awt_Color(Clazz.new_((I$[4]||$incl$(4)).c$$I$I$I,[0, 143, 213]));
this.builderPanel.setBounds$I$I$I$I(313, 17, 195, 401);
var aSymMouse = Clazz.new_((I$[5]||$incl$(5)), [this, null]);
this.circanvas.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.builderPanel.setcircuitBuilder$circuitsimulator_CircuitBuilder(this);
this.builderPanel.loadImages();
});

Clazz.newMeth(C$, 'start', function () {
C$.superclazz.prototype.start.apply(this, []);
this.gridZone.width = this.builderPanel.getBounds().x;
this.popupOnElement = Clazz.new_((I$[6]||$incl$(6)).c$$circuitsimulator_CircuitBuilder,[this]);
this.loadList$S("/lists/default.txt");
this.parse();
this.calculateCircuit();
});

Clazz.newMeth(C$, 'run', function () {
while (this.runner === (I$[7]||$incl$(7)).currentThread() ){
if (this.parsed) {
this.circanvas.repaint();
}for (var e = this.meterList.elements(); e.hasMoreElements(); ) {
this.meter = e.nextElement();
this.meter.recalc();
}
try {
(I$[7]||$incl$(7)).sleep$J(100);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'circanvas_MousePressed$java_awt_event_MouseEvent', function (event) {
this.currentElement = this.getComponent$S(this.coordString$java_awt_Point$Z(event.getPoint(), false));
if (!!((event.isMetaDown() == true ) | (event.isControlDown() == true ))) {
this.popupOnElement.selectItems();
this.add$java_awt_PopupMenu(this.popupOnElement);
this.popupOnElement.show$java_awt_Component$I$I(event.getComponent(), event.getX(), event.getY());
} else {
this.circanvas.setCursor$java_awt_Cursor((I$[8]||$incl$(8)).getPredefinedCursor$I(12));
}if ((this.debugLevel & (I$[9]||$incl$(9)).DEBUG_IO) > 0) {
System.out.println$S(this.currentElement.name());
}});

Clazz.newMeth(C$, 'circanvas_mouseReleased$java_awt_event_MouseEvent', function (event) {
if (!!((event.isMetaDown() == false ) & (event.isControlDown() == false ))) {
this.moveComponent$circuitsimulator_CircuitElement$S(this.currentElement, this.coordString$java_awt_Point$Z(event.getPoint(), false));
this.circanvas.setCursor$java_awt_Cursor((I$[8]||$incl$(8)).getDefaultCursor());
this.parse();
this.repaintMeters();
}});

Clazz.newMeth(C$, 'step$D$D', function (dt, time) {
C$.superclazz.prototype.step$D$D.apply(this, [dt, time]);
if ((this.parsed) && !this.graphList.isEmpty() ) {
for (var e = this.graphList.elements(); e.hasMoreElements(); ) {
this.graph = e.nextElement();
this.graph.addData();
}
}});

Clazz.newMeth(C$, 'reset', function () {
C$.superclazz.prototype.reset.apply(this, []);
if ((this.parsed) && !this.graphList.isEmpty() ) {
for (var e = this.graphList.elements(); e.hasMoreElements(); ) {
this.graph = e.nextElement();
this.graph.clearGraph();
}
}});

Clazz.newMeth(C$, 'coordString$java_awt_Point$Z', function (absCoords, absolute) {
var circanvasP = Clazz.new_((I$[10]||$incl$(10)).c$$I$I,[0, 0]);
if (absolute) {
circanvasP.setLocation$java_awt_Point(this.circanvas.getLocation());
}var posString = "row=";
var diffx;
var diffy;
var x;
var y;
var row = -1;
var col = -1;
x = absCoords.x - circanvasP.x;
y = absCoords.y - circanvasP.y;
do {
col++;
diffx = (this.interGrid/2|0) + this.interGrid * col - x;
} while (diffx < 0);
do {
row++;
diffy = (this.interGrid/2|0) + this.interGrid * row - y;
} while (diffy < 0);
if (!!((diffx >= diffy) & (diffx + diffy >= this.interGrid))) {
posString += Integer.toString(row - 1) + ",col=" + Integer.toString(col - 1) + ",to=v" ;
} else if (!!((diffx >= diffy) & (diffx + diffy < this.interGrid))) {
posString += Integer.toString(row) + ",col=" + Integer.toString(col - 1) + ",to=h" ;
} else if (!!((diffx < diffy) & (diffy + diffx >= this.interGrid))) {
posString += Integer.toString(row - 1) + ",col=" + Integer.toString(col - 1) + ",to=h" ;
} else if (!!((diffx < diffy) & (diffy + diffx < this.interGrid))) {
posString += Integer.toString(row - 1) + ",col=" + Integer.toString(col) + ",to=v" ;
}if ((this.debugLevel & (I$[9]||$incl$(9)).DEBUG_IO) > 0) {
System.out.println$S(posString);
}return posString;
});

Clazz.newMeth(C$, 'repaintMeters', function () {
if (this.parsed) {
this.calculateCircuit();
for (var e = this.scopeList.elements(); e.hasMoreElements(); ) {
this.oscdiag = e.nextElement();
this.oscdiag.scopeCanvas.repaint();
}
for (var e = this.meterList.elements(); e.hasMoreElements(); ) {
this.meter = e.nextElement();
this.meter.recalc();
}
}});

Clazz.newMeth(C$, 'parseCommand$S', function (s) {
s = "" + (I$[11]||$incl$(11)).removeWhitespace$S(s);
if ((I$[11]||$incl$(11)).parameterExist$S$S(s, "setGrid")) {
var parameters =  String.instantialize(s.substring(9, s.length$() - 3));
var rows = ((I$[11]||$incl$(11)).getParam$S$S(parameters, "rows=")|0);
var cols = ((I$[11]||$incl$(11)).getParam$S$S(parameters, "cols=")|0);
this.setGrid$I$I(rows, cols);
} else if ((I$[11]||$incl$(11)).parameterExist$S$S(s, "setNumberOfDT")) {
var par = Integer.parseInt(s.substring(s.indexOf("(") + 1, s.indexOf(")")));
this.setNumberOfDT$I(par);
} else if ((I$[11]||$incl$(11)).parameterExist$S$S(s, "setDT")) {
var par = (Double.$valueOf(s.substring(s.indexOf("(") + 1, s.indexOf(")")))).doubleValue();
this.setDT$D(par);
} else if ((I$[11]||$incl$(11)).parameterExist$S$S(s, "setNOC")) {
var par = Integer.parseInt(s.substring(s.indexOf("(") + 1, s.indexOf(")")));
this.setNOC$I(par);
} else if ((I$[11]||$incl$(11)).parameterExist$S$S(s, "setFPS")) {
var par = (Double.$valueOf(s.substring(s.indexOf("(") + 1, s.indexOf(")")))).doubleValue();
this.setFPS$D(par);
} else if ((I$[11]||$incl$(11)).parameterExist$S$S(s, "addObject")) {
var name =  String.instantialize(s.substring(s.indexOf("(\"") + 2, s.indexOf("\",")));
var list =  String.instantialize(s.substring(s.indexOf(",\"") + 2, s.indexOf("\")")));
this.addObject$S$S(name, list);
}});

Clazz.newMeth(C$, 'loadList$S', function (inputfile) {
var trydoc = false;
var s = "";
try {
if ((I$[9]||$incl$(9)).DEBUG) {
System.out.println$S("loading from codebase:" + this.getCodeBase().toString() + inputfile );
}var url = Clazz.new_((I$[12]||$incl$(12)).c$$S,[this.getCodeBase().toString() + inputfile]);
var $in = url.openStream();
var br = Clazz.new_((I$[13]||$incl$(13)).c$$java_io_Reader,[Clazz.new_((I$[14]||$incl$(14)).c$$java_io_InputStream,[$in])]);
var line;
while ((line = br.readLine()) != null ){
s += line + "\n";
this.parseCommand$S(line);
}
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
trydoc = true;
if ((I$[9]||$incl$(9)).DEBUG) {
System.out.println$S("load failed from docbase: " + e.getMessage());
}} else {
throw e;
}
}
if (trydoc) {
s = "";
try {
var pathName = this.getDocumentBase().toString();
if (pathName.endsWith$S(".html") || pathName.endsWith$S(".htm") ) {
var index = pathName.lastIndexOf("/");
pathName = pathName.substring(0, index + 1);
}var url = Clazz.new_((I$[12]||$incl$(12)).c$$S,[pathName + inputfile]);
var $in = url.openStream();
var br = Clazz.new_((I$[13]||$incl$(13)).c$$java_io_Reader,[Clazz.new_((I$[14]||$incl$(14)).c$$java_io_InputStream,[$in])]);
var line;
while ((line = br.readLine()) != null ){
s += line + "\n";
this.parseCommand$S(line);
}
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("load failed: " + e.getMessage());
this.setGrid$S("rows=8,cols=5");
} else {
throw e;
}
}
}});
;
(function(){var C$=Clazz.newClass(P$.CircuitBuilder, "SymMouse", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.MouseAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (event) {
var object = event.getSource();
if (object === this.this$0.circanvas ) {
this.this$0.circanvas_mouseReleased$java_awt_event_MouseEvent(event);
}});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (event) {
var object = event.getSource();
if (object === this.this$0.circanvas ) {
this.this$0.circanvas_MousePressed$java_awt_event_MouseEvent(event);
}});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-06 06:55:32
