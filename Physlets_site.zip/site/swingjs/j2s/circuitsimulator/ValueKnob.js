(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'java.awt.Label','symantec.itools.awt.util.spinner.ListSpinner','java.awt.Scrollbar','java.awt.Color','java.awt.Font','edu.davidson.display.Format',['circuitsimulator.ValueKnob','.SymWindow'],['circuitsimulator.ValueKnob','.SymAction'],['circuitsimulator.ValueKnob','.SymAdjustment']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ValueKnob", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.Dialog');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.cb=null;
this.elementID=0;
this.ce=null;
this.format=null;
this.$type=null;
this.initialv=0;
this.fComponentsAdjusted=false;
this.numeric=null;
this.scale=null;
this.mode=null;
this.scrollbar=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.cb=null;
this.$type="";
this.initialv=1.0;
this.fComponentsAdjusted=false;
this.numeric=Clazz.new_($I$(1));
this.scale=Clazz.new_($I$(1));
this.mode=Clazz.new_($I$(2));
this.scrollbar=Clazz.new_($I$(3).c$$I$I$I$I$I,[0, 50, 1, 1, 101]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component', function (parent) {
C$.superclazz.c$$java_awt_Frame.apply(this, [null]);
C$.$init$.apply(this);
this.setLayout$java_awt_LayoutManager(null);
this.setSize$I$I(180, 57);
this.setVisible$Z(false);
this.setLocationRelativeTo$java_awt_Component(parent);
this.numeric.setText$S("0.0");
this.numeric.setAlignment$I(2);
this.add$java_awt_Component(this.numeric);
this.numeric.setBackground$java_awt_Color($I$(4).black);
this.numeric.setForeground$java_awt_Color($I$(4).yellow);
this.numeric.setFont$java_awt_Font(Clazz.new_($I$(5).c$$S$I$I,["MonoSpaced", 1, 12]));
this.numeric.setBounds$I$I$I$I(6, 27, 133, 24);
this.add$java_awt_Component(this.scale);
this.scale.setBackground$java_awt_Color($I$(4).black);
this.scale.setForeground$java_awt_Color($I$(4).yellow);
this.scale.setFont$java_awt_Font(Clazz.new_($I$(5).c$$S$I$I,["MonoSpaced", 1, 12]));
this.scale.setBounds$I$I$I$I(139, 27, 35, 24);
try {
{
var tempString=Clazz.array(String, [2]);
tempString[0]="lin";
tempString[1]="log";
this.mode.setListItems$SA(tempString);
}} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.add$java_awt_Component(this.mode);
this.mode.setFont$java_awt_Font(Clazz.new_($I$(5).c$$S$I$I,["Dialog", 0, 10]));
this.mode.setBounds$I$I$I$I(4, 1, 54, 25);
this.add$java_awt_Component(this.scrollbar);
this.scrollbar.setBounds$I$I$I$I(60, 3, 117, 21);
this.setTitle$S("Meter");
this.format=Clazz.new_($I$(6).c$$S,["%6.4f"]);
var aSymWindow=Clazz.new_($I$(7), [this, null]);
this.addWindowListener$java_awt_event_WindowListener(aSymWindow);
var lSymAction=Clazz.new_($I$(8), [this, null]);
this.mode.addActionListener$java_awt_event_ActionListener(lSymAction);
var lSymAdjustment=Clazz.new_($I$(9), [this, null]);
this.scrollbar.addAdjustmentListener$java_awt_event_AdjustmentListener(lSymAdjustment);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$Z', function (parent, modal) {
C$.c$$java_awt_Component.apply(this, [parent]);
this.setModal$Z(modal);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Component$S$Z', function (parent, title, modal) {
C$.c$$java_awt_Component$Z.apply(this, [parent, modal]);
this.setTitle$S(title);
}, 1);

Clazz.newMeth(C$, 'c$$S$circuitsimulator_CircuitBuilder$java_awt_Component', function (t, cirbuilder, parent) {
C$.c$$java_awt_Component.apply(this, [parent]);
this.cb=cirbuilder;
this.elementID=this.cb.currentElement.hashCode$();
this.ce=this.cb.currentElement;
if (t.equals$O("Hz")) this.$type += t;
 else this.$type += this.ce.getunity$();
if (this.$type.equals$O("Hz")) this.initialv=this.ce.frequency;
 else this.initialv=Double.valueOf$S(this.ce.getvalue$()).doubleValue$();
this.recalc$();
this.setTitle$S(this.cb.cirProp.getProperty$S(this.ce.getMyName$()) + " " + this.ce.getlabel$() );
this.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'addNotify$', function () {
var d=this.getSize$();
C$.superclazz.prototype.addNotify$.apply(this, []);
if (this.fComponentsAdjusted) return;
var ins=this.getInsets$();
this.setSize$I$I(ins.left + ins.right + d.width , ins.top + ins.bottom + d.height );
var components=this.getComponents$();
for (var i=0; i < components.length; i++) {
var p=components[i].getLocation$();
p.translate$I$I(ins.left, ins.top);
components[i].setLocation$java_awt_Point(p);
}
this.fComponentsAdjusted=true;
});

Clazz.newMeth(C$, 'Meter_WindowClosing$java_awt_event_WindowEvent', function (event) {
this.dispose$();
});

Clazz.newMeth(C$, 'setDisplay$D', function (v) {
if (Math.abs(v) < 1.0E-8 ) {
this.scale.setText$S("n" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 1.0E9));
} else if (Math.abs(v) < 1.0E-4 ) {
this.scale.setText$S("ï¿½" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 1000000.0));
} else if (Math.abs(v) < 0.1 ) {
this.scale.setText$S("m" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 1000.0));
} else if (Math.abs(v) < 1000.0 ) {
this.scale.setText$S(this.$type);
this.numeric.setText$S(this.format.form$D(v));
} else if (Math.abs(v) < 1000000.0 ) {
this.scale.setText$S("k" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 0.001));
} else {
this.scale.setText$S("M" + this.$type);
this.numeric.setText$S(this.format.form$D(v * 1.0E-6));
}});

Clazz.newMeth(C$, 'recalc$', function () {
var v=0.0;
var scrollValue;
scrollValue=this.scrollbar.getValue$() * 2.0 / (this.scrollbar.getMaximum$() - 1);
if (this.mode.getCurrentText$().equals$O("lin")) {
v=this.initialv * scrollValue;
} else {
var initiallog=Math.rint(Math.log(this.initialv) / Math.log(10.0));
var basev=this.initialv / Math.exp(initiallog * Math.log(10.0));
var log10=initiallog + 5.0 * (scrollValue - 1.0);
v=basev * Math.exp(log10 * Math.log(10.0));
}if (this.$type.equals$O("Hz")) {
this.cb.setDT$D(0.001 / v);
this.cb.set$I$S(this.ce.hashCode$(), "freq=" + Double.toString$D(v));
this.cb.builderPanel.updateTextFields$();
} else this.cb.setValue$I$S(this.ce.hashCode$(), Double.toString$D(v));
this.cb.calculateCircuit$();
this.cb.repaintMeters$();
this.setDisplay$D(v);
});

Clazz.newMeth(C$, 'mode_actionPerformed$java_awt_event_ActionEvent', function (event) {
this.recalc$();
});

Clazz.newMeth(C$, 'scrollbar_AdjustmentValueChanged$java_awt_event_AdjustmentEvent', function (event) {
this.recalc$();
});
;
(function(){var C$=Clazz.newClass(P$.ValueKnob, "SymWindow", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.WindowAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0 ) this.this$0.Meter_WindowClosing$java_awt_event_WindowEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.ValueKnob, "SymAction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (event) {
var object=event.getSource$();
if (object === this.this$0.mode ) this.this$0.mode_actionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.ValueKnob, "SymAdjustment", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.AdjustmentListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['adjustmentValueChanged$java_awt_event_AdjustmentEvent','adjustmentValueChanged$'], function (event) {
var object=event.getSource$();
if (object === this.this$0.scrollbar ) this.this$0.scrollbar_AdjustmentValueChanged$java_awt_event_AdjustmentEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:49 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
