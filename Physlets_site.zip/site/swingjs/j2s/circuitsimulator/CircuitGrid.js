(function(){var P$=Clazz.newPackage("circuitsimulator"),p$1={},I$=[[0,'java.util.Vector','circuitsimulator.GridElement','circuitsimulator.Circuit','circuitsimulator.Constraints','circuitsimulator.VEquation','circuitsimulator.BranchPoint','circuitsimulator.Matrix']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "CircuitGrid");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.rows=0;
this.cols=0;
this.bpStartVEquation=0;
this.nextBranchPoint=0;
this.startIIndex=0;
this.currow=0;
this.curcol=0;
this.startVIndex=0;
this.curVIndex=0;
this.curIIndex=0;
this.numberOfI=0;
this.numberOfVE=0;
this.lastVIndex=0;
this.lastIIndex=0;
this.numberOfCirc=0;
this.numberOfV=0;
this.numberOfPars=0;
this.direction=0;
this.dirold=0;
this.circuit=null;
this.element=null;
this.vEquations=null;
this.branchPoints=null;
this.cirElemList=null;
this.sourceContainer=null;
this.constraints=null;
this.y=null;
this.a=null;
this.aInv=null;
this.b=null;
this.multip=null;
this.leftlinear=false;
this.rightlinear=false;
this.vEquationPtr=null;
this.branchPointPtr=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.bpStartVEquation=0;
this.nextBranchPoint=0;
this.startIIndex=0;
this.currow=0;
this.curcol=0;
this.startVIndex=0;
this.curVIndex=0;
this.curIIndex=0;
this.vEquations=Clazz.new_(Clazz.load('java.util.Vector'));
this.branchPoints=Clazz.new_($I$(1));
this.cirElemList=Clazz.new_($I$(1));
this.sourceContainer=Clazz.new_($I$(1));
this.constraints=Clazz.new_($I$(1));
this.leftlinear=true;
this.rightlinear=true;
}, 1);

Clazz.newMeth(C$, 'c$$I$I$circuitsimulator_Circuit', function (trows, tcols, circ) {
C$.$init$.apply(this);
this.circuit=circ;
this.rows=trows;
this.cols=tcols;
this.element=Clazz.array(Clazz.load('circuitsimulator.GridElement'), [this.rows, this.cols]);
for (var i=0; i < this.rows; i++) for (var j=0; j < this.cols; j++) this.element[i][j]=Clazz.new_($I$(2));


if ((this.circuit.debugLevel & Clazz.load('circuitsimulator.Circuit').DEBUG_IO) > 0) System.out.println$S(this.rows + "x" + this.cols + " elements made" );
}, 1);

Clazz.newMeth(C$, 'constructEquationBase$', function () {
if (p$1.initDefinition.apply(this, []) == false ) return false;
var firstx=this.currow;
var firsty=this.curcol;
var finished=true;
do {
do {
if (this.element[this.currow][this.curcol].defined == true ) {
if (this.element[this.currow][this.curcol].nOfUntreatedCons > 2) p$1.stopBranchCorrections.apply(this, []);
 else p$1.firstLoopCorrections.apply(this, []);
finished=p$1.startNextBranchPoint.apply(this, []);
} else {
p$1.findNextDirection.apply(this, []);
if (this.element[this.currow][this.curcol].nOfUntreatedCons > 2) p$1.addNewBranchPoint.apply(this, []);
p$1.addNewVEquation.apply(this, []);
p$1.changeCoords.apply(this, []);
finished=false;
}} while (!finished);
} while (p$1.findNextCircuit.apply(this, []));
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) System.out.println$S("end of construction: lastVIndex=" + this.lastVIndex + ", lastIIndex=" + this.lastIIndex );
this.numberOfV=this.lastVIndex + 1;
this.numberOfI=this.lastIIndex + 1;
this.numberOfPars=this.numberOfV + this.numberOfI;
this.reset$();
return true;
});

Clazz.newMeth(C$, 'reset$', function () {
this.y=Clazz.array(Double.TYPE, [this.numberOfPars + this.sourceContainer.size$() + 1 ]);
for (var i=0; i <= this.numberOfPars + this.sourceContainer.size$(); i++) this.y[i]=0.0;

});

Clazz.newMeth(C$, 'initDefinition', function () {
this.numberOfCirc=0;
this.startVIndex=0;
this.startIIndex=0;
if (this.cirElemList.isEmpty$()) {
System.out.println$S("No elements found !");
return false;
}if ((this.circuit.debugLevel & $I$(3).DEBUG_IO) > 0) System.out.println$S("Parse initialization started");
for (var i=0; i < this.rows; i++) for (var j=0; j < this.cols; j++) {
this.element[i][j].nOfUntreatedCons=this.element[i][j].numberOfCons$();
if (this.element[i][j].nOfUntreatedCons == 1) {
if ((this.circuit.debugLevel & $I$(3).DEBUG_IO) > 0) System.out.println$S("Open loop found !");
return false;
}this.element[i][j].defined=false;
}

if ((this.circuit.debugLevel & $I$(3).DEBUG_IO) > 0) System.out.println$S("Loop is closed, all grid points initialized");
this.currow=0;
this.curcol=0;
while (this.element[this.currow][this.curcol].numberOfCons$() == 0){
this.currow=0;
while (this.element[this.currow][this.curcol].numberOfCons$() == 0 && this.currow < this.rows - 1 )this.currow++;

if (this.element[this.currow][this.curcol].numberOfCons$() == 0) this.curcol++;
}
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) System.out.println$S("first element found: " + this.currow + "," + this.curcol );
this.direction=3;
this.constraints.removeAllElements$();
this.vEquations.removeAllElements$();
this.branchPoints.removeAllElements$();
this.lastVIndex=0;
this.lastIIndex=0;
this.curIIndex=0;
this.curVIndex=0;
this.numberOfCirc++;
return true;
}, p$1);

Clazz.newMeth(C$, 'findNextCircuit', function () {
this.currow=0;
this.curcol=0;
while ((this.element[this.currow][this.curcol].numberOfCons$() == 0) || this.element[this.currow][this.curcol].defined ){
this.currow=0;
while (((this.element[this.currow][this.curcol].numberOfCons$() == 0) || this.element[this.currow][this.curcol].defined ) && (this.currow < this.rows - 1) )this.currow++;

if ((this.element[this.currow][this.curcol].numberOfCons$() == 0) || this.element[this.currow][this.curcol].defined ) this.curcol++;
if (this.curcol == this.cols - 1) {
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) System.out.println$S("no additional circuits found: " + this.currow + "," + this.curcol );
return false;
}}
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) System.out.println$S("next circuit found: " + this.currow + "," + this.curcol );
this.direction=3;
this.lastVIndex++;
this.lastIIndex++;
this.startVIndex=this.lastVIndex;
this.startIIndex=this.lastIIndex;
this.numberOfCirc++;
this.constraints.addElement$TE(Clazz.new_(Clazz.load('circuitsimulator.Constraints').c$$I$I$I,[0, this.lastVIndex, 0]));
return true;
}, p$1);

Clazz.newMeth(C$, 'startNextBranchPoint', function () {
var thisBranchPoint;
var finished=true;
this.nextBranchPoint=0;
this.bpStartVEquation=this.vEquations.size$();
if (this.branchPoints.size$() > 0) {
while (this.nextBranchPoint < this.branchPoints.size$() && (this.branchPoints.elementAt$I(this.nextBranchPoint)).toDefine == 0 )this.nextBranchPoint++;

if (this.nextBranchPoint < this.branchPoints.size$()) {
thisBranchPoint=this.branchPoints.elementAt$I(this.nextBranchPoint);
this.currow=thisBranchPoint.xcoord;
this.curcol=thisBranchPoint.ycoord;
this.curVIndex=this.element[this.currow][this.curcol].getVIndex$();
this.direction=thisBranchPoint.start$circuitsimulator_GridElement$I(this.element[this.currow][this.curcol], this.lastIIndex);
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) System.out.println$S("next branch started at " + this.currow + "," + this.curcol + ", lastVIndex/lastIIndex: " + this.lastVIndex + "/" + this.lastIIndex );
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) thisBranchPoint.print$();
this.lastIIndex++;
p$1.addNewVEquation.apply(this, []);
p$1.changeCoords.apply(this, []);
finished=false;
}}return finished;
}, p$1);

Clazz.newMeth(C$, 'stopBranchCorrections', function () {
var prevVIndex=this.curVIndex;
this.branchPointPtr=this.branchPoints.elementAt$I(this.element[this.currow][this.curcol].bpIndex);
this.branchPointPtr.stop$I$I(this.direction, this.lastIIndex);
this.curVIndex=this.element[this.currow][this.curcol].getVIndex$();
if (this.lastVIndex > 0) {
var n=this.vEquations.size$() - 1;
var curVEquation=this.vEquations.elementAt$I(n);
curVEquation.indexV2=this.curVIndex;
while (curVEquation.indexV1 == this.lastVIndex){
curVEquation.indexV1=this.curVIndex;
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) curVEquation.print$();
curVEquation=this.vEquations.elementAt$I(--n);
curVEquation.indexV2=this.curVIndex;
}
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) curVEquation.print$();
}if ((this.vEquations.elementAt$I(this.bpStartVEquation)).indexV1 != prevVIndex) {
this.lastVIndex--;
} else {
this.constraints.addElement$TE(Clazz.new_($I$(4).c$$I$I$I,[prevVIndex, this.curVIndex, this.lastIIndex]));
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) System.out.println$S("Equality for V-indices: " + prevVIndex + "=" + this.curVIndex + ", with I-index=" + this.lastIIndex );
}if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) this.branchPointPtr.print$();
}, p$1);

Clazz.newMeth(C$, 'firstLoopCorrections', function () {
if (this.lastVIndex > 0) {
var curVEquation;
if (!this.branchPoints.isEmpty$()) {
this.branchPointPtr.iIndex[this.branchPointPtr.lastDirection]=this.startIIndex;
this.lastIIndex--;
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) System.out.println$S(this.bpStartVEquation + "/" + this.vEquations.size$() );
for (var n=this.bpStartVEquation; n < this.vEquations.size$(); n++) {
curVEquation=this.vEquations.elementAt$I(n);
curVEquation.indexI1=this.startIIndex;
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) curVEquation.print$();
}
}var n=this.vEquations.size$() - 1;
curVEquation=this.vEquations.elementAt$I(n);
curVEquation.indexV2=this.startVIndex;
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) curVEquation.print$();
while (curVEquation.indexV1 == this.lastVIndex){
curVEquation.indexV1=this.startVIndex;
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) curVEquation.print$();
curVEquation=this.vEquations.elementAt$I(--n);
curVEquation.indexV2=this.startVIndex;
}
this.lastVIndex--;
} else {
this.constraints.addElement$TE(Clazz.new_($I$(4).c$$I$I$I,[0, 0, 0]));
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) System.out.println$S("Equality for V-indices: 0=0, with I-index=0");
}}, p$1);

Clazz.newMeth(C$, 'addNewVEquation', function () {
if (this.element[this.currow][this.curcol].connection[this.direction].getMyName$().equals$O("wire") == false ) {
this.lastVIndex++;
this.vEquations.addElement$TE(Clazz.new_(Clazz.load('circuitsimulator.VEquation').c$$circuitsimulator_GridElement$I$I$I$I,[this.element[this.currow][this.curcol], this.direction, this.curVIndex, this.lastVIndex, this.lastIIndex]));
this.curVIndex=this.lastVIndex;
if (this.element[this.currow][this.curcol].connection[this.direction].leftlinear == false ) this.leftlinear=false;
if (this.element[this.currow][this.curcol].connection[this.direction].rightlinear == false ) this.rightlinear=false;
} else {
this.vEquations.addElement$TE(Clazz.new_($I$(5).c$$circuitsimulator_GridElement$I$I$I$I,[this.element[this.currow][this.curcol], this.direction, this.curVIndex, this.curVIndex, this.lastIIndex]));
}this.vEquationPtr=this.vEquations.lastElement$();
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) {
System.out.print$S("In direction " + this.direction + ": " );
this.vEquationPtr.print$();
}this.element[this.currow][this.curcol].connected$circuitsimulator_VEquation(this.vEquationPtr);
}, p$1);

Clazz.newMeth(C$, 'addNewBranchPoint', function () {
this.branchPoints.addElement$TE(Clazz.new_(Clazz.load('circuitsimulator.BranchPoint').c$$circuitsimulator_GridElement$I$I$I$I$I,[this.element[this.currow][this.curcol], this.currow, this.curcol, this.dirold, this.direction, this.lastIIndex]));
this.branchPointPtr=this.branchPoints.lastElement$();
this.element[this.currow][this.curcol].bpIndex=this.branchPoints.size$() - 1;
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) this.branchPointPtr.print$();
this.bpStartVEquation=this.vEquations.size$();
this.lastIIndex++;
}, p$1);

Clazz.newMeth(C$, 'findNextDirection', function () {
this.dirold=this.direction;
this.direction=(this.direction + 3) % 4;
while (this.element[this.currow][this.curcol].connection[this.direction] == null )this.direction=(this.direction + 1) % 4;

}, p$1);

Clazz.newMeth(C$, 'changeCoords', function () {
switch (this.direction) {
case 0:
this.curcol--;
break;
case 1:
this.currow++;
break;
case 2:
this.curcol++;
break;
case 3:
this.currow--;
}
}, p$1);

Clazz.newMeth(C$, 'buildEquations$', function () {
this.a=Clazz.new_(Clazz.load('circuitsimulator.Matrix').c$$I$I,[this.numberOfPars, this.numberOfPars]);
p$1.leftEquationMatrix$circuitsimulator_Matrix.apply(this, [this.a]);
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) {
System.out.println$S("Matrix a:");
this.a.print$();
}this.aInv=Clazz.new_($I$(7).c$$I$I,[this.numberOfPars, this.numberOfPars]);
this.aInv.matinv$circuitsimulator_Matrix(this.a);
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) {
System.out.println$S("Matrix a Inverted:");
this.aInv.print$();
}this.b=Clazz.new_($I$(7).c$$I$I,[this.numberOfPars, this.numberOfPars + this.sourceContainer.size$() + 1 ]);
p$1.rightEquationMatrix$circuitsimulator_Matrix.apply(this, [this.b]);
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) {
System.out.println$S("Matrix b:");
this.b.print$();
}this.multip=Clazz.new_($I$(7).c$$I$I,[this.numberOfPars, this.numberOfPars + this.sourceContainer.size$() + 1 ]);
this.multip.matmul$circuitsimulator_Matrix$circuitsimulator_Matrix(this.aInv, this.b);
if ((this.circuit.debugLevel & $I$(3).DEBUG_NUM) > 0) {
System.out.println$S("Matrix a Inverted . b:");
this.multip.print$();
}});

Clazz.newMeth(C$, 'leftEquationMatrix$circuitsimulator_Matrix', function (matrix) {
matrix.set_elem$I$I$D(0, 0, 1.0);
this.numberOfVE=0;
for (var i=0; i < this.vEquations.size$(); i++) {
this.vEquationPtr=this.vEquations.elementAt$I(i);
if (!this.vEquationPtr.z.getMyName$().equals$O("wire")) this.vEquationPtr.leftValue$I$circuitsimulator_Matrix$I(this.numberOfV, matrix, ++this.numberOfVE);
}
var constraintPtr;
var numberOfConstraints=this.constraints.size$();
for (var i=0; i < this.constraints.size$(); i++) {
constraintPtr=this.constraints.elementAt$I(i);
constraintPtr.leftValue$I$circuitsimulator_Matrix$I(this.numberOfVE, matrix, i);
}
var startint=this.numberOfVE + 1 + numberOfConstraints ;
if (!this.branchPoints.isEmpty$()) for (var i=startint; i < this.numberOfPars; i++) {
this.branchPointPtr=this.branchPoints.elementAt$I(i - startint);
for (var j=0; j < 4; j++) if (this.branchPointPtr.iSign[j] != 0) matrix.set_elem$I$I$D(i, this.numberOfV + this.branchPointPtr.iIndex[j], this.branchPointPtr.iSign[j]);

}
}, p$1);

Clazz.newMeth(C$, 'rightEquationMatrix$circuitsimulator_Matrix', function (matrix) {
var j=0;
var cirelem;
for (var i=0; i < this.vEquations.size$(); i++) {
this.vEquationPtr=this.vEquations.elementAt$I(i);
if (!this.vEquationPtr.z.getMyName$().equals$O("wire")) this.vEquationPtr.rightValue$I$I$circuitsimulator_Matrix$I(this.numberOfV, this.numberOfPars, matrix, ++j);
}
}, p$1);

Clazz.newMeth(C$, 'calculateStep$D', function (t) {
this.y[this.numberOfPars]=1;
for (var i=1; i <= this.sourceContainer.size$(); i++) this.y[this.numberOfPars + i]=(this.sourceContainer.elementAt$I(i - 1)).getV$D(t);

if (this.leftlinear == false ) {
p$1.leftEquationMatrix$circuitsimulator_Matrix.apply(this, [this.a]);
this.aInv.matinv$circuitsimulator_Matrix(this.a);
}if (this.rightlinear == false ) p$1.rightEquationMatrix$circuitsimulator_Matrix.apply(this, [this.b]);
if (this.leftlinear == false  || this.rightlinear == false  ) this.multip.matmul$circuitsimulator_Matrix$circuitsimulator_Matrix(this.aInv, this.b);
this.multip.resolve$DA(this.y);
});

Clazz.newMeth(C$, 'addCircuitElement$circuitsimulator_CircuitElement', function (cirelem) {
var fromcon;
var fromr;
var fromc;
var tocon;
var tor;
var toc;
if (cirelem.getMyName$().equals$O("probe")) {
this.cirElemList.addElement$TE(cirelem);
return cirelem.hashCode$();
}fromr=tor=cirelem.row;
fromc=toc=cirelem.col;
if (cirelem.to.equals$O("h")) {
fromcon=2;
tocon=0;
toc++;
} else {
fromcon=1;
tocon=3;
tor++;
}if (!!((tor < this.rows) & (fromr < this.rows) &((toc < this.cols))&((fromc < this.cols))&((tor >= 0))&((toc >= 0))&((fromr >= 0))&((fromr >= 0)))) {
if (this.element[tor][toc].connection[tocon] != null ) this.cirElemList.removeElement$O(this.element[tor][toc].connection[tocon]);
if (cirelem.getMyName$().equals$O("nothing") == false ) {
this.element[tor][toc].connection[tocon]=this.element[fromr][fromc].connection[fromcon]=cirelem;
this.cirElemList.addElement$TE(cirelem);
} else this.element[tor][toc].connection[tocon]=this.element[fromr][fromc].connection[fromcon]=null;
if (cirelem.numberOfNodes == 4) {
}return cirelem.hashCode$();
} else return -1;
});

Clazz.newMeth(C$, 'removeCircuitElement$I', function (id) {
var fromcon;
var tocon;
var tor;
var toc;
var fromr;
var fromc;
var cirelem=this.getCircuitElement$I(id);
if (cirelem == null ) return false;
fromr=tor=cirelem.row;
fromc=toc=cirelem.col;
if (cirelem.to.equals$O("h")) {
fromcon=2;
tocon=0;
toc++;
} else {
fromcon=1;
tocon=3;
tor++;
}this.element[tor][toc].connection[tocon]=this.element[fromr][fromc].connection[fromcon]=null;
this.cirElemList.removeElement$O(cirelem);
if ((this.circuit.debugLevel & $I$(3).DEBUG_IO) > 0) System.out.println$S("Element removed: " + cirelem.getMyName$());
return true;
});

Clazz.newMeth(C$, 'moveCircuitElement$I$I$I$S', function (id, newfromr, newfromc, to) {
var fromcon;
var tocon;
var tor;
var toc;
var fromr;
var fromc;
var newtor;
var newtoc;
var newfromcon;
var newtocon;
var cirelem=this.getCircuitElement$I(id);
if (cirelem == null ) return false;
fromr=tor=cirelem.row;
fromc=toc=cirelem.col;
if (cirelem.to.equals$O("h")) {
fromcon=2;
tocon=0;
toc++;
} else {
fromcon=1;
tocon=3;
tor++;
}newtor=newfromr;
newtoc=newfromc;
if (to.equals$O("h")) {
newfromcon=2;
newtocon=0;
newtoc++;
} else {
newfromcon=1;
newtocon=3;
newtor++;
}if (!!((newtor < this.rows) & (newfromr < this.rows) &((newtoc < this.cols))&((newfromc < this.cols))&((newtor >= 0))&((newtoc >= 0))&((newfromr >= 0))&((newfromr >= 0)))) {
this.element[tor][toc].connection[tocon]=this.element[fromr][fromc].connection[fromcon]=null;
if (this.element[newfromr][newfromc].connection[newfromcon] != null ) this.cirElemList.removeElement$O(this.element[newfromr][newfromc].connection[newfromcon]);
cirelem.move$I$I$S(newfromr, newfromc, to);
if ((this.circuit.debugLevel & $I$(3).DEBUG_IO) > 0) System.out.println$S(cirelem.getMyName$() + " moved to: " + newfromr + " " + newfromc + " " + to );
this.element[newtor][newtoc].connection[newtocon]=this.element[newfromr][newfromc].connection[newfromcon]=cirelem;
return true;
} else return false;
});

Clazz.newMeth(C$, 'getCircuitElement$I', function (id) {
var cirelem=null;
for (var e=this.cirElemList.elements$(); e.hasMoreElements$(); ) {
cirelem=e.nextElement$();
if (cirelem.hashCode$() == id) return cirelem;
}
if ($I$(3).DEBUG) System.out.println$S("getCircuitElement method: No element found");
return null;
});

Clazz.newMeth(C$, 'getCircuitElement$I$I$S', function (r, c, tostr) {
var cirelem=null;
for (var e=this.cirElemList.elements$(); e.hasMoreElements$(); ) {
cirelem=e.nextElement$();
if (!!(!!(cirelem.row == r & cirelem.col == c) & cirelem.to.equals$O(tostr))) return cirelem;
}
if ($I$(3).DEBUG) System.out.println$S("getCircuitElement method: No element found");
return null;
});

Clazz.newMeth(C$, 'getcomponentList$', function () {
var cirelem=null;
var s="setGrid(\"rows=" + this.rows + ",cols=" + this.cols + "\");\n" ;
s += "setNumberOfDT(" + this.circuit.numberofdt + ");\n" ;
s += "setDT(" + new Double(this.circuit.dt).toString() + ");\n" ;
s += "setNOC(" + this.circuit.noc + ");\n" ;
s += "setFPS(" + new Double(this.circuit.fps).toString() + ");\n" ;
for (var e=this.cirElemList.elements$(); e.hasMoreElements$(); ) {
cirelem=e.nextElement$();
s += cirelem.getAddObjectString$();
}
return s;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:15 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
