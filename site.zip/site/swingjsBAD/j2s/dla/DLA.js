(function(){var P$=Clazz.newPackage("dla"),I$=[['edu.davidson.display.SGraph','dla.Dlamodel','java.awt.BorderLayout','a2s.Panel','a2s.Button','a2s.Checkbox','edu.davidson.display.SGraphFrame','Boolean','dla.DLA$1','dla.DLA$2','dla.DLA$3','dla.DLA$4','java.awt.event.WindowAdapter']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DLA", null, 'edu.davidson.tools.SApplet');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.graph = null;
this.drawingPanel = null;
this.borderLayout1 = null;
this.controlPanel = null;
this.startBtn = null;
this.stopBtn = null;
this.resetBtn = null;
this.graphCheck = null;
this.graphFrame = null;
this.showControls = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.graph = Clazz.new_((I$[1]||$incl$(1)));
this.drawingPanel = Clazz.new_((I$[2]||$incl$(2)).c$$dla_DLA$edu_davidson_display_SGraph,[this, this.graph]);
this.borderLayout1 = Clazz.new_((I$[3]||$incl$(3)));
this.controlPanel = Clazz.new_((I$[4]||$incl$(4)));
this.startBtn = Clazz.new_((I$[5]||$incl$(5)));
this.stopBtn = Clazz.new_((I$[5]||$incl$(5)));
this.resetBtn = Clazz.new_((I$[5]||$incl$(5)));
this.graphCheck = Clazz.new_((I$[6]||$incl$(6)));
this.graphFrame = Clazz.new_((I$[7]||$incl$(7)).c$$edu_davidson_display_SGraph,[this.drawingPanel.graphPanel]);
this.showControls = true;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'init', function () {
try {
this.showControls=(I$[8]||$incl$(8)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.controlPanel.setVisible$Z(this.showControls);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.startBtn.setLabel$S("Start");
this.startBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DLA$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dla.DLA'].startBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[9]||$incl$(9)).$init$, [this, null])));
this.stopBtn.setLabel$S("Stop");
this.stopBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DLA$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dla.DLA'].stopBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[10]||$incl$(10)).$init$, [this, null])));
this.resetBtn.setLabel$S("Reset");
this.resetBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "DLA$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['dla.DLA'].resetBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[11]||$incl$(11)).$init$, [this, null])));
this.graphCheck.setLabel$S("Graph");
this.graphCheck.addItemListener$java_awt_event_ItemListener(((
(function(){var C$=Clazz.newClass(P$, "DLA$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['itemStateChanged$java_awt_event_ItemEvent','itemStateChanged'], function (e) {
this.b$['dla.DLA'].graphCheck_itemStateChanged$java_awt_event_ItemEvent(e);
});
})()
), Clazz.new_((I$[12]||$incl$(12)).$init$, [this, null])));
this.graphFrame.addWindowListener$java_awt_event_WindowListener(((
(function(){var C$=Clazz.newClass(P$, "DLA$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['windowClosing$java_awt_event_WindowEvent','windowClosing'], function (e) {
this.b$['dla.DLA'].graphFrame_windowClosing$java_awt_event_WindowEvent(e);
});
})()
), Clazz.new_((I$[13]||$incl$(13)), [this, null],P$.DLA$5)));
this.graphFrame.setTitle$S("Ln of Mass vs. Ln of Distance");
this.add$java_awt_Component$O(this.drawingPanel, "Center");
this.add$java_awt_Component$O(this.controlPanel, "South");
this.controlPanel.add$java_awt_Component$O(this.startBtn, null);
this.controlPanel.add$java_awt_Component$O(this.stopBtn, null);
this.controlPanel.add$java_awt_Component$O(this.resetBtn, null);
this.controlPanel.add$java_awt_Component$O(this.graphCheck, null);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Diffusion Limited Aggregation by A. Schoewe and W. Christian.  email:wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the control buttons at the bottom of the applet."])]);
return pinfo;
});

Clazz.newMeth(C$, ['setShowGraph$Z','setShowGraph'], function (show) {
if (show) {
this.graphCheck.setState$Z(show);
this.initFrame();
this.graphFrame.setVisible$Z(true);
this.drawingPanel.plotGraph();
} else {
this.graphCheck.setState$Z(show);
this.graphFrame.setVisible$Z(false);
}});

Clazz.newMeth(C$, 'getHistogramID', function () {
return this.drawingPanel.getHistogramID();
});

Clazz.newMeth(C$, 'startBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.forward();
});

Clazz.newMeth(C$, 'stopBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.pause();
});

Clazz.newMeth(C$, 'resetBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.reset();
});

Clazz.newMeth(C$, 'graphCheck_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (this.graphCheck.getState()) {
this.initFrame();
this.graphFrame.setVisible$Z(true);
this.drawingPanel.plotGraph();
}if (!this.graphCheck.getState()) {
this.graphFrame.setVisible$Z(false);
}});

Clazz.newMeth(C$, 'graphFrame_windowClosing$java_awt_event_WindowEvent', function (e) {
this.graphCheck.setState$Z(false);
});

Clazz.newMeth(C$, 'initFrame', function () {
this.graph.setAutoReplaceData$I$Z(1, true);
this.drawingPanel.setGraph$edu_davidson_display_SGraph(this.graph);
{
this.graphFrame.setSize$I$I(250, 300);
}});

Clazz.newMeth(C$, 'reset', function () {
this.drawingPanel.reset();
this.drawingPanel.paint();
});

Clazz.newMeth(C$, 'stepForward', function () {
});

Clazz.newMeth(C$, 'forward', function () {
this.drawingPanel.start();
});

Clazz.newMeth(C$, 'pause', function () {
this.drawingPanel.stop();
});

Clazz.newMeth(C$, 'setDefault', function () {
C$.superclazz.prototype.setDefault.apply(this, []);
this.drawingPanel.reset();
});

Clazz.newMeth(C$, 'destroy', function () {
this.drawingPanel.destroy();
if (this.graph != null ) this.graph.destroy();
C$.superclazz.prototype.destroy.apply(this, []);
});
})();
//Created 2018-07-23 12:59:36 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
