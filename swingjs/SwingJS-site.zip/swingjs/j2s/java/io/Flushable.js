(function(){var P$=java.io,I$=[];
var C$=Clazz.newInterface(P$, "Flushable");
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-08-29 07:33:29 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
