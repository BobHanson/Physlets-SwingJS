(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[['edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SDataConnection");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.series = 0;
this.ds = null;
this.dl = null;
this.xStr = null;
this.yStr = null;
this.x = null;
this.y = null;
this.xparser = null;
this.yparser = null;
this.vars = null;
this.smooth = 0;
this.stride = 0;
this.strideCounter = 0;
this.tempX = null;
this.tempY = null;
this.lastX = 0;
this.lastY = 0;
this.block = false;
this.xmin = 0;
this.xmax = 0;
this.windowX = false;
this.ymin = 0;
this.ymax = 0;
this.windowY = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.ds = null;
this.dl = null;
this.x = null;
this.y = null;
this.xparser = null;
this.yparser = null;
this.vars = null;
this.smooth = 1;
this.stride = 1;
this.strideCounter = 1;
this.tempX = Clazz.array(Double.TYPE, [this.smooth]);
this.tempY = Clazz.array(Double.TYPE, [this.smooth]);
this.lastX = 0;
this.lastY = 0;
this.block = false;
this.xmin = 0;
this.xmax = 0;
this.windowX = false;
this.ymin = 0;
this.ymax = 0;
this.windowY = false;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SDataSource$edu_davidson_tools_SDataListener$I$S$S', function (ds, dl, series, xStr, yStr) {
C$.$init$.apply(this);
this.series = series;
this.ds = ds;
this.dl = dl;
this.xStr = xStr;
this.yStr = yStr;
this.vars = ds.getVarStrings();
if (this.vars == null ) {
System.out.println$S("Error:Data source variables have not been initialized.");
} else {
this.setXStr$S(xStr);
this.setYStr$S(yStr);
}dl.clearSeries$I(series);
}, 1);

Clazz.newMeth(C$, 'setWindowX$D$D', function (xmin, xmax) {
if (xmax < xmin ) {
var temp = xmax;
xmax = xmin;
xmin = temp;
}this.xmin = xmin;
this.xmax = xmax;
this.windowX = true;
});

Clazz.newMeth(C$, 'setWindowY$D$D', function (ymin, ymax) {
if (ymax < ymin ) {
var temp = ymax;
ymax = ymin;
ymin = temp;
}this.ymin = ymin;
this.ymax = ymax;
this.windowY = true;
});

Clazz.newMeth(C$, 'setSmooth$I', function (s) {
if (s < 2) {
this.smooth = 1;
this.tempX = null;
this.tempY = null;
return;
}this.smooth = s;
this.tempX = Clazz.array(Double.TYPE, [this.smooth]);
this.tempY = Clazz.array(Double.TYPE, [this.smooth]);
for (var i = 0; i < this.smooth; i++) {
this.tempX[i] = this.lastX;
this.tempY[i] = this.lastY;
}
});

Clazz.newMeth(C$, 'setStride$I', function (s) {
this.stride = Math.max(1, s);
this.strideCounter = 1;
});

Clazz.newMeth(C$, 'setXStr$S', function (s) {
this.xStr = s.trim();
if (this.xStr.equals$O("") || this.xStr.equals$O("0") ) {
this.xparser = null;
return true;
}this.xparser = Clazz.new_((I$[1]||$incl$(1)).c$$I,[this.vars.length]);
for (var i = 0; i < this.vars.length; i++) {
this.xparser.defineVariable$I$S(i + 1, this.vars[i]);
}
this.xparser.define$S(this.xStr);
this.xparser.parse();
if (this.xparser.getErrorCode() != 0) {
System.out.println$S("Failed to parse horizontal datasource): " + this.xStr);
System.out.println$S("Parse error: " + this.xparser.getErrorString() + " at function 1, position " + this.xparser.getErrorPosition() );
for (var i = 0; i < this.vars.length; i++) {
System.out.println$S("vars " + this.vars[i]);
}
return false;
} else {
return true;
}});

Clazz.newMeth(C$, 'setYStr$S', function (s) {
this.yStr = s.trim();
if (this.yStr.equals$O("") || this.yStr.equals$O("0") ) {
this.yparser = null;
return true;
}this.yparser = Clazz.new_((I$[1]||$incl$(1)).c$$I,[this.vars.length]);
for (var i = 0; i < this.vars.length; i++) {
this.yparser.defineVariable$I$S(i + 1, this.vars[i]);
}
this.yparser.define$S(this.yStr);
this.yparser.parse();
if (this.yparser.getErrorCode() != 0) {
System.out.println$S("Failed to parse vertical datasource: " + this.yStr);
System.out.println$S("Parse error: " + this.yparser.getErrorString() + " at function 1, position " + this.yparser.getErrorPosition() );
for (var i = 0; i < this.vars.length; i++) {
System.out.println$S("vars " + this.vars[i]);
}
return false;
} else {
return true;
}});

Clazz.newMeth(C$, 'registerDatum', function () {
if (this.block) return;
this.strideCounter--;
if (this.strideCounter > 0) return;
this.strideCounter = this.stride;
var v = this.ds.getVariables();
if (v == null  || this.ds.getVarStrings() == null  ) return;
if (this.ds.getVarStrings()[0].equals$O("blocked")) return;
if (this.ds.getVarStrings()[0].equals$O("surfacedata") && v.length > 1 ) {
this.dl.addData$edu_davidson_tools_SDataSource$I$DA$DA(this.ds, this.series, null, null);
}var numPts = v.length;
if (numPts == 1) {
if (this.xparser != null ) this.lastX = this.xparser.evaluate$DA(v[0]);
 else this.lastX = 0;
if (this.yparser != null ) this.lastY = this.yparser.evaluate$DA(v[0]);
 else this.lastY = 0;
if (this.windowX && (this.lastX < this.xmin  || this.lastX > this.xmax  ) ) return;
if (this.windowY && (this.lastY < this.ymin  || this.lastY > this.ymax  ) ) return;
if (this.smooth > 1) {
var sumx = 0;
var sumy = 0;
for (var i = 1; i < this.smooth; i++) {
this.tempX[i - 1] = this.tempX[i];
this.tempY[i - 1] = this.tempY[i];
sumx += this.tempX[i];
sumy += this.tempY[i];
}
this.tempX[this.smooth - 1] = this.lastX;
this.tempY[this.smooth - 1] = this.lastY;
sumx += this.lastX;
sumy += this.lastY;
this.dl.addDatum$edu_davidson_tools_SDataSource$I$D$D(this.ds, this.series, sumx / this.smooth, sumy / this.smooth);
} else this.dl.addDatum$edu_davidson_tools_SDataSource$I$D$D(this.ds, this.series, this.lastX, this.lastY);
return;
}if (this.x == null  || this.x.length != numPts ) this.x = Clazz.array(Double.TYPE, [numPts]);
if (this.y == null  || this.y.length != numPts ) this.y = Clazz.array(Double.TYPE, [numPts]);
for (var i = 0; i < numPts; i++) {
if (this.xparser != null ) this.x[i] = this.xparser.evaluate$DA(v[i]);
 else this.x[i] = 0;
if (this.yparser != null ) this.y[i] = this.yparser.evaluate$DA(v[i]);
 else this.y[i] = 0;
}
if (this.windowX) {
var newData = p$.windowx$DA$DA.apply(this, [this.x, this.y]);
this.x = newData[0];
this.y = newData[1];
}if (this.windowY) {
var newData = p$.windowy$DA$DA.apply(this, [this.x, this.y]);
this.x = newData[0];
this.y = newData[1];
}if (this.smooth > 2) {
this.x = p$.smoothData$DA.apply(this, [this.x]);
this.y = p$.smoothData$DA.apply(this, [this.y]);
}this.dl.addData$edu_davidson_tools_SDataSource$I$DA$DA(this.ds, this.series, this.x, this.y);
});

Clazz.newMeth(C$, 'windowx$DA$DA', function (x, y) {
var numPts = x.length;
for (var i = 0; i < numPts; i++) {
if ((x[i] < this.xmin ) || (x[i] > this.xmax ) ) {
System.arraycopy(x, i + 1, x, i, numPts - i - 1 );
System.arraycopy(y, i + 1, y, i, numPts - i - 1 );
numPts--;
i--;
}}
var newData = Clazz.array(Double.TYPE, [2, numPts]);
System.arraycopy(x, 0, newData[0], 0, numPts);
System.arraycopy(y, 0, newData[1], 0, numPts);
return newData;
});

Clazz.newMeth(C$, 'windowy$DA$DA', function (x, y) {
var numPts = x.length;
for (var i = 0; i < numPts; i++) {
if ((y[i] < this.ymin ) || (y[i] > this.ymax ) ) {
System.arraycopy(x, i + 1, x, i, numPts - i - 1 );
System.arraycopy(y, i + 1, y, i, numPts - i - 1 );
numPts--;
i--;
}}
var newData = Clazz.array(Double.TYPE, [2, numPts]);
System.arraycopy(x, 0, newData[0], 0, numPts);
System.arraycopy(y, 0, newData[1], 0, numPts);
return newData;
});

Clazz.newMeth(C$, 'smoothData$DA', function (x) {
var numPts = x.length;
var delta = (this.smooth/2|0);
var newX = Clazz.array(Double.TYPE, [numPts]);
for (var i = delta; i < numPts - delta; i++) {
var sum = 0;
for (var j = -delta; j <= delta; j++) {
sum += x[i + j];
}
newX[i] = sum / (2 * delta + 1);
}
return newX;
});

Clazz.newMeth(C$, 'clearData', function () {
this.dl.clearSeries$I(this.series);
});

Clazz.newMeth(C$, 'deleteData', function () {
this.dl.deleteSeries$I(this.series);
});

Clazz.newMeth(C$, 'getDataSource', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getDataListener', function () {
return this.dl;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:25
