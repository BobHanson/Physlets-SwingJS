(function(){var P$=Clazz.newPackage("dla"),I$=[['edu.davidson.tools.SApplet','java.awt.Color','java.lang.Thread','Thread','edu.davidson.graph.SpecialFunction',['dla.Dlamodel','.MassHistogram']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Dlamodel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'java.awt.Panel', 'Runnable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.histogram = null;
this.osi = null;
this.control = null;
this.startPressed = false;
this.graphPanel = null;
this.bin = null;
this.logDistance = null;
this.logMass = null;
this.calcThread = null;
this.r = null;
this.grid = null;
this.$height = 0;
this.$width = 0;
this.x0 = 0;
this.y0 = 0;
this.attached = false;
this.radius = 0;
this.seedX = 0;
this.seedY = 0;
this.counter = 0;
this.tempWidth = 0;
this.tempHeight = 0;
this.particlesAttached = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.histogram = null;
this.osi = null;
this.control = null;
this.startPressed = false;
this.graphPanel = null;
this.bin = null;
this.logDistance = null;
this.logMass = null;
this.calcThread = null;
this.r = Clazz.array(Double.TYPE, [10]);
this.grid = null;
this.$height = 0;
this.$width = 0;
this.x0 = 0;
this.y0 = 0;
this.attached = false;
this.radius = 0;
this.seedX = 0;
this.seedY = 0;
this.counter = 0;
this.tempWidth = 0;
this.tempHeight = 0;
this.particlesAttached = 1;
}, 1);

Clazz.newMeth(C$, 'c$$dla_DLA$edu_davidson_display_SGraph', function (control, graph) {
Clazz.super_(C$, this,1);
this.graphPanel = graph;
this.control = control;
this.graphPanel.setEnableMouse$Z(true);
this.graphPanel.setSeriesStyle$I$Z$I(1, true, 3);
this.graphPanel.setAutoReplaceData$I$Z(1, true);
graph.setMinYRange$Z$D$D(true, 2, 4);
graph.setMinXRange$Z$D$D(true, 1, 2);
this.graphPanel.setMarkerSize$I$D(1, 0.5);
this.graphPanel.setLabelX$S("Log_{10} of Distance");
this.graphPanel.setLabelY$S("Log_{10} of Mass");
}, 1);

Clazz.newMeth(C$, 'step', function () {
switch (((Math.random() * 4)|0)) {
case 0:
this.x0 = this.x0 + 1;
break;
case 1:
this.y0 = this.y0 + 1;
break;
case 2:
this.x0 = this.x0 - 1;
break;
case 3:
this.y0 = this.y0 - 1;
break;
default:
System.out.println$S("Switch Error");
break;
}
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.osi != null ) {
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
} else {
g.setColor$java_awt_Color((I$[2]||$incl$(2)).black);
g.fillRect$I$I$I$I(0, 0, this.getBounds().width, this.getBounds().height);
}if (this.calcThread != null ) {
g.setColor$java_awt_Color((I$[2]||$incl$(2)).yellow);
g.drawString$S$I$I("running", 12, 15);
}});

Clazz.newMeth(C$, 'paint', function () {
var g = this.getGraphics();
this.paint$java_awt_Graphics(g);
g.dispose();
});

Clazz.newMeth(C$, 'startPosition', function () {
var tempX = 0;
var tempY = 0;
var angle = 0;
angle = 6.283185307179586 * (Math.random());
tempX = ((Math.cos(angle) * this.radius)|0);
tempY = ((Math.sin(angle) * this.radius)|0);
if (tempX <= 0) {
this.x0 = this.seedX + (tempX - 2);
} else {
this.x0 = this.seedX + (tempX + 2);
}if (tempY <= 0) {
this.y0 = this.seedY + (tempY - 2);
} else {
this.y0 = this.seedY + (tempY + 2);
}});

Clazz.newMeth(C$, 'checkNeighbors', function () {
if (this.grid[this.x0][this.y0 + 1] == true  || this.grid[this.x0 - 1][this.y0] == true   || this.grid[this.x0][this.y0 - 1] == true   || this.grid[this.x0 + 1][this.y0] == true  ) {
var num = 0;
var g = this.osi.getGraphics();
this.grid[this.x0][this.y0] = true;
this.attached = true;
this.particlesAttached++;
num = ((((this.particlesAttached % 3000)/1000|0))|0);
switch (num) {
case 0:
g.setColor$java_awt_Color((I$[2]||$incl$(2)).red);
break;
case 1:
g.setColor$java_awt_Color((I$[2]||$incl$(2)).blue);
break;
case 2:
g.setColor$java_awt_Color((I$[2]||$incl$(2)).green);
break;
}
g.fillRect$I$I$I$I(this.x0, this.y0, 1, 1);
g.setColor$java_awt_Color((I$[2]||$incl$(2)).white);
g.dispose();
this.paint();
this.checkRadius();
this.control.updateDataConnections();
}});

Clazz.newMeth(C$, 'start', function () {
if (this.calcThread == null ) {
this.startPressed = true;
this.create();
this.calcThread = Clazz.new_((I$[3]||$incl$(3)).c$$Runnable,[this]);
this.calcThread.start();
}});

Clazz.newMeth(C$, 'findDistance', function () {
var distance = Math.sqrt((this.x0 - this.seedX) * (this.x0 - this.seedX) + (this.y0 - this.seedY) * (this.y0 - this.seedY));
return distance;
});

Clazz.newMeth(C$, 'run', function () {
var outOfBounds = false;
var currentDistance = 0;
while (this.calcThread != null ){
if (this.attached = true) {
this.fillBins$D(currentDistance);
if (this.particlesAttached % 10 == 1) this.plotGraph();
this.attached = false;
}this.startPosition();
currentDistance = this.findDistance();
outOfBounds = false;
while (this.attached == false  && currentDistance < 2 * this.radius + 1   && outOfBounds == false  ){
if (currentDistance > this.radius + 2 ) this.bigStep$D(currentDistance);
 else this.step();
if (this.x0 < this.$width - 1 && this.y0 < this.$height - 1  && this.x0 > 0  && this.y0 > 0 ) this.checkNeighbors();
 else outOfBounds = true;
currentDistance = this.findDistance();
}
try {
(I$[4]||$incl$(4)).sleep$J(10);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
}
this.repaint();
});

Clazz.newMeth(C$, 'stop', function () {
this.calcThread = null;
});

Clazz.newMeth(C$, 'destroy', function () {
var temp = this.calcThread;
this.calcThread = null;
if (temp != null ) try {
temp.join$J(5000);
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
} else {
throw ie;
}
}
});

Clazz.newMeth(C$, 'create', function () {
this.$width = this.getBounds().width;
this.$height = this.getBounds().height;
this.seedX = ((this.$width/2|0));
this.seedY = ((this.$height/2|0));
this.logDistance = Clazz.array(Double.TYPE, [10]);
this.logMass = Clazz.array(Double.TYPE, [10]);
this.tempWidth = this.$width;
this.tempHeight = this.$height;
this.radius = 10;
this.grid = Clazz.array(Boolean.TYPE, [this.$width, this.$height]);
this.osi = this.createImage$I$I(this.$width, this.$height);
this.bin = Clazz.array(Double.TYPE, [10]);
this.x0 = this.seedX;
this.y0 = this.seedY;
this.grid[this.seedX][this.seedY] = true;
var g = this.osi.getGraphics();
g.setColor$java_awt_Color((I$[2]||$incl$(2)).black);
g.fillRect$I$I$I$I(0, 0, this.$width, this.$height);
g.setColor$java_awt_Color((I$[2]||$incl$(2)).red);
g.fillRect$I$I$I$I(this.seedX, this.seedY, 1, 1);
g.setColor$java_awt_Color((I$[2]||$incl$(2)).white);
g.dispose();
this.paint();
for (var i = 0; i < 10; i++) {
this.r[i] = Math.sqrt(((this.$height/2|0)) * ((this.$height/2|0)) + ((this.$width/2|0)) * ((this.$width/2|0))) * ((i + 0.5) / 10.0);
this.logMass[i] = 0;
this.logDistance[i] = (I$[5]||$incl$(5)).log10$D(this.r[i]);
;this.bin[i] = 0;
}
this.bin[0] = 1;
this.counter++;
if (this.tempWidth != this.$width && this.tempHeight != this.$height ) {
this.tempWidth = this.$width;
this.tempHeight = this.$height;
this.grid = Clazz.array(Boolean.TYPE, [this.$width, this.$height]);
for (var i = 0; i < 10; i++) {
this.r[i] = Math.sqrt(((this.$height/2|0)) * ((this.$height/2|0)) + ((this.$width/2|0)) * ((this.$width/2|0))) * ((i + 1) / 10);
this.logMass[i] = 0;
this.logDistance[i] = 0;
this.bin[i] = 0;
}
this.osi = this.createImage$I$I(this.$width, this.$height);
}});

Clazz.newMeth(C$, 'checkRadius', function () {
var tempDistance = Math.sqrt((this.x0 - this.seedX) * (this.x0 - this.seedX) + (this.y0 - this.seedY) * (this.y0 - this.seedY));
if (tempDistance > this.radius ) this.radius = tempDistance;
});

Clazz.newMeth(C$, 'bigStep$D', function (r) {
var stepSize = Math.max(1, ((r - this.radius)|0) - 1);
switch (((Math.random() * 4)|0)) {
case 0:
this.x0 = this.x0 + stepSize;
break;
case 1:
this.y0 = this.y0 + stepSize;
break;
case 2:
this.x0 = this.x0 - stepSize;
break;
case 3:
this.y0 = this.y0 - stepSize;
break;
default:
System.out.println$S("Switch Error");
break;
}
});

Clazz.newMeth(C$, 'setGraph$edu_davidson_display_SGraph', function (gr) {
this.graphPanel = gr;
if (this.calcThread == null ) this.plotGraph();
});

Clazz.newMeth(C$, 'plotGraph', function () {
if (!this.control.graphFrame.isVisible()) return;
if (this.logDistance == null  || this.logMass == null   || this.r == null   || this.bin == null  ) return;
var insideMass = this.bin[0];
if (insideMass <= 0 ) return;
this.logMass[0] = (I$[5]||$incl$(5)).log10$D(insideMass);
for (var i = 1; i < 10; i++) {
insideMass = insideMass + this.bin[i];
this.logMass[i] = (I$[5]||$incl$(5)).log10$D(insideMass);
}
this.graphPanel.addData$I$DA$DA(1, this.logDistance, this.logMass);
});

Clazz.newMeth(C$, 'fillBins$D', function (particleDist) {
if ((particleDist|0) < this.r[0] ) this.bin[0]++;
if ((particleDist|0) >= this.r[0]  && (particleDist|0) < this.r[1]  ) this.bin[1]++;
if ((particleDist|0) >= this.r[1]  && (particleDist|0) < this.r[2]  ) this.bin[2]++;
if ((particleDist|0) >= this.r[2]  && (particleDist|0) < this.r[3]  ) this.bin[3]++;
if ((particleDist|0) >= this.r[3]  && (particleDist|0) < this.r[4]  ) this.bin[4]++;
if ((particleDist|0) >= this.r[4]  && (particleDist|0) < this.r[5]  ) this.bin[5]++;
if ((particleDist|0) >= this.r[5]  && (particleDist|0) < this.r[6]  ) this.bin[6]++;
if ((particleDist|0) >= this.r[6]  && (particleDist|0) < this.r[7]  ) this.bin[7]++;
if ((particleDist|0) >= this.r[7]  && (particleDist|0) < this.r[8]  ) this.bin[8]++;
if ((particleDist|0) >= this.r[8]  && (particleDist|0) < this.r[9]  ) this.bin[9]++;
});

Clazz.newMeth(C$, 'reset', function () {
if (this.calcThread != null ) this.calcThread = null;
this.create();
var g = this.osi.getGraphics();
g.setColor$java_awt_Color((I$[2]||$incl$(2)).black);
if (this.$width > 0 && this.$height > 0 ) g.fillRect$I$I$I$I(0, 0, this.$width, this.$height);
g.dispose();
this.paint();
this.particlesAttached = 1;
this.graphPanel.setAutoReplaceData$I$Z(1, false);
this.graphPanel.clearSeriesData$I(1);
this.graphPanel.setAutoRefresh$Z(true);
this.graphPanel.setAutoReplaceData$I$Z(1, true);
this.counter = 0;
this.control.updateDataConnections();
});

Clazz.newMeth(C$, 'getHistogramID', function () {
if (this.histogram == null ) this.histogram = Clazz.new_((I$[6]||$incl$(6)), [this, null]);
return this.histogram.getID();
});
;
(function(){var C$=Clazz.newClass(P$.Dlamodel, "MassHistogram", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.ds = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["r", "m"]);
this.ds = Clazz.array(Double.TYPE, [1, 2]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
if (this.ds.length != this.this$0.bin.length) {
this.ds = Clazz.array(Double.TYPE, [this.this$0.bin.length, 2]);
for (var i = 0; i < this.this$0.bin.length; i++) this.ds[i][0] = this.this$0.r[i];

}var mass = 0;
for (var i = 0; i < this.this$0.bin.length; i++) {
mass += this.this$0.bin[i];
this.ds[i][1] = mass;
}
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0.control;
});
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:41:53
