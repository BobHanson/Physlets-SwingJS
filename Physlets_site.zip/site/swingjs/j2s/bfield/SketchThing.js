(function(){var P$=Clazz.newPackage("bfield"),I$=[];
var C$=Clazz.newClass(P$, "SketchThing", null, 'edu.davidson.display.TrailThing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fieldPanel = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$bfield_FieldPanel$I', function (owner, fp, s) {
C$.superclazz.c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I.apply(this, [owner, fp, s]);
C$.$init$.apply(this);
this.fieldPanel = fp;
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "bx", "by"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.applet.clock.getTime();
this.ds[0][1] = this.x;
this.ds[0][2] = this.y;
this.ds[0][3] = this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, null);
this.ds[0][4] = this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, null);
;return this.ds;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:06:53
