(function(){var P$=Clazz.newPackage("diatomic"),p$1={},I$=[[0,'java.awt.BorderLayout','edu.davidson.graphics.EtchedBorder','java.awt.Panel','java.awt.Button','diatomic.PhysletPanel','Boolean','java.awt.Color','edu.davidson.tools.SUtil','edu.davidson.tools.SApplet']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Diatomic", null, 'edu.davidson.tools.SApplet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.button_start=null;
this.button_stop=null;
this.button_step=null;
this.label_time=null;
this.showControls=false;
this.numDiatomic=0;
this.numAtom=0;
this.fps=0;
this.dt=0;
this.borderLayout1=null;
this.etchedBorder1=null;
this.controlPanel=null;
this.panel1=null;
this.panel2=null;
this.runBtn=null;
this.physletPanel=null;
this.stepBtn=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.button_start="Run ";
this.button_stop="Stop";
this.button_step="Step";
this.label_time="Time:";
this.borderLayout1=Clazz.new_(Clazz.load('java.awt.BorderLayout'));
this.etchedBorder1=Clazz.new_(Clazz.load('edu.davidson.graphics.EtchedBorder'));
this.controlPanel=Clazz.new_($I$(2));
this.panel1=Clazz.new_(Clazz.load('java.awt.Panel'));
this.panel2=Clazz.new_($I$(3));
this.runBtn=Clazz.new_(Clazz.load('java.awt.Button'));
this.physletPanel=Clazz.new_(Clazz.load('diatomic.PhysletPanel').c$$diatomic_Diatomic,[this]);
this.stepBtn=Clazz.new_($I$(4));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'setResources$', function () {
this.button_start=this.localProperties.getProperty$S$S("button.start", this.button_start);
this.button_stop=this.localProperties.getProperty$S$S("button.stop", this.button_stop);
this.button_step=this.localProperties.getProperty$S$S("button.step", this.button_step);
this.label_time=this.localProperties.getProperty$S$S("label.time", this.label_time);
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.initResources$S(null);
try {
this.showControls=Clazz.load('Boolean').valueOf$S(this.getParameter$S$S("ShowControls", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.numDiatomic=Integer.parseInt$S(this.getParameter$S$S("NumMol", "16"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.numAtom=Integer.parseInt$S(this.getParameter$S$S("NumAtom", "16"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.fps=Integer.parseInt$S(this.getParameter$S$S("FPS", "10"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.dt=Double.valueOf$S(this.getParameter$S$S("Dt", "0.1")).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.clock.setDt$D(this.dt);
this.clock.setFPS$D(this.fps);
this.clock.addClockListener$edu_davidson_tools_SStepable(this.physletPanel);
this.controlPanel.setVisible$Z(this.showControls);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.runBtn.setLabel$S(this.button_start);
this.runBtn.addActionListener$java_awt_event_ActionListener(((P$.Diatomic$1||
(function(){var C$=Clazz.newClass(P$, "Diatomic$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (e) {
this.b$['diatomic.Diatomic'].runBtn_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['diatomic.Diatomic'], [e]);
});
})()
), Clazz.new_(P$.Diatomic$1.$init$, [this, null])));
this.stepBtn.setLabel$S(this.button_step);
this.stepBtn.addActionListener$java_awt_event_ActionListener(((P$.Diatomic$2||
(function(){var C$=Clazz.newClass(P$, "Diatomic$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (e) {
this.b$['diatomic.Diatomic'].stepBtn_actionPerformed$java_awt_event_ActionEvent.apply(this.b$['diatomic.Diatomic'], [e]);
});
})()
), Clazz.new_(P$.Diatomic$2.$init$, [this, null])));
this.controlPanel.setBackground$java_awt_Color(Clazz.load('java.awt.Color').lightGray);
this.add$java_awt_Component$O(this.etchedBorder1, "Center");
this.etchedBorder1.add$java_awt_Component$O(this.physletPanel, "Center");
this.add$java_awt_Component$O(this.controlPanel, "South");
this.controlPanel.add$java_awt_Component$O(this.panel2, "West");
this.panel2.add$java_awt_Component$O(this.runBtn, null);
this.panel2.add$java_awt_Component$O(this.stepBtn, null);
this.controlPanel.add$java_awt_Component$O(this.panel1, "Center");
}, p$1);

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'], function () {
return "Applet Information";
});

Clazz.newMeth(C$, ['getParameterInfo$','getParameterInfo'], function () {
var pinfo=Clazz.array(String, -2, [Clazz.array(String, -1, ["ShowControls", "boolean", "Show the user interface"]), Clazz.array(String, -1, ["NumMol", "int", "Number of diatomic molecules"]), Clazz.array(String, -1, ["NumAtom", "int", "Number of atoms"]), Clazz.array(String, -1, ["FPS", "int", "Frames per second"]), Clazz.array(String, -1, ["Dt", "double", "Time step"])]);
return pinfo;
});

Clazz.newMeth(C$, 'runBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.clock.isRunning$()) {
this.runBtn.setLabel$S(this.button_start);
this.clock.stopClock$();
} else {
this.runBtn.setLabel$S(this.button_stop);
this.clock.startClock$();
}});

Clazz.newMeth(C$, ['getAppletCount$','getAppletCount'], function () {
if (this.firstTime) {
return 0;
} else {
return C$.superclazz.prototype.getAppletCount$.apply(this, []);
}});

Clazz.newMeth(C$, ['start$','start'], function () {
if (this.firstTime) {
this.firstTime=false;
this.physletPanel.createOSI$();
this.physletPanel.initialize$();
this.physletPanel.setAtomNum$I(this.numAtom);
this.physletPanel.setMolNum$I(this.numDiatomic);
this.physletPanel.paintOSI$();
}C$.superclazz.prototype.start$.apply(this, []);
});

Clazz.newMeth(C$, 'stepBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.clock.isRunning$()) {
this.runBtn_actionPerformed$java_awt_event_ActionEvent(null);
} else {
this.clock.doStep$();
}});

Clazz.newMeth(C$, ['addObject$S$S','addObject'], function (name, parList) {
var n=1;
name=name.toLowerCase$().trim$();
name=Clazz.load('edu.davidson.tools.SUtil').removeWhitespace$S(name);
parList=$I$(8).removeWhitespace$S(parList);
if (name.equals$O("atom")) {
if ($I$(8).parameterExist$S$S(parList, "n=")) {
n=($I$(8).getParam$S$S(parList, "n=")|0);
}n=Math.max(0, n);
n=Math.min(n, 99);
p$1.createAtoms$I.apply(this, [n]);
if ($I$(8).parameterExist$S$S(parList, "m=")) {
this.physletPanel.mM=$I$(8).getParam$S$S(parList, "m=");
}if ($I$(8).parameterExist$S$S(parList, "r=")) {
var r=($I$(8).getParam$S$S(parList, "r=")|0);
this.physletPanel.setAtomRad$I(r);
}return this.physletPanel.getID$();
} else if (name.equals$O("diatomic") || name.equals$O("diatom") || name.equals$O("molecule")  ) {
if ($I$(8).parameterExist$S$S(parList, "n=")) {
n=($I$(8).getParam$S$S(parList, "n=")|0);
}n=Math.max(0, n);
n=Math.min(n, 99);
p$1.createDiatomics$I.apply(this, [n]);
if ($I$(8).parameterExist$S$S(parList, "m=")) {
this.physletPanel.mD=$I$(8).getParam$S$S(parList, "m=");
}if ($I$(8).parameterExist$S$S(parList, "r=")) {
var r=($I$(8).getParam$S$S(parList, "r=")|0);
this.physletPanel.setMolRad$I(r);
}if ($I$(8).parameterExist$S$S(parList, "d=")) {
var sep=$I$(8).getParam$S$S(parList, "d=");
this.physletPanel.setMolSeparation$D(sep);
}return this.physletPanel.getID$();
}return 0;
});

Clazz.newMeth(C$, 'createAtoms$I', function (n) {
var runAgain=false;
if (this.clock.isRunning$()) {
runAgain=true;
this.pause$();
}this.physletPanel.setAtomNum$I(n);
if (runAgain) {
runAgain=false;
this.forward$();
} else {
this.physletPanel.paintOSI$();
if (this.autoRefresh) {
this.physletPanel.repaint$();
}}}, p$1);

Clazz.newMeth(C$, 'createDiatomics$I', function (n) {
var runAgain=false;
if (this.clock.isRunning$()) {
runAgain=true;
this.pause$();
}this.physletPanel.setMolNum$I(n);
if (runAgain) {
runAgain=false;
this.forward$();
} else {
this.physletPanel.paintOSI$();
if (this.autoRefresh) {
this.physletPanel.repaint$();
}}}, p$1);

Clazz.newMeth(C$, ['setDefault$','setDefault'], function () {
this.clock.stopClock$();
this.clock.setTime$D(0);
this.deleteDataConnections$();
this.physletPanel.setDefault$();
this.physletPanel.paintOSI$();
});

Clazz.newMeth(C$, ['addAtomDataSource$I','addAtomDataSource'], function (i) {
return this.physletPanel.addAtomDataSource$I(i);
});

Clazz.newMeth(C$, ['addDiatomicDataSource$I','addDiatomicDataSource'], function (i) {
return this.physletPanel.addDiatomicDataSource$I(i);
});

Clazz.newMeth(C$, ['set$I$S$S','set'], function (id, name, parList) {
var shouldRun=false;
if (this.clock.isRunning$()) {
this.clock.stopClock$();
shouldRun=true;
}name=name.toLowerCase$().trim$();
name=$I$(8).removeWhitespace$S(name);
parList=$I$(8).removeWhitespace$S(parList);
var i=0;
var scale=this.physletPanel.scale;
if (name.equals$O("atom")) {
if ($I$(8).parameterExist$S$S(parList, "i=")) {
i=($I$(8).getParam$S$S(parList, "i=")|0);
if (i < 1) {
System.out.println$S("Atom index <1.");
return false;
}if (i > this.physletPanel.anMax) {
System.out.println$S("Atom index out of range. Number of atoms=" + this.physletPanel.anMax);
return false;
}if ($I$(8).parameterExist$S$S(parList, "x=")) {
this.physletPanel.ax[i]=$I$(8).getParam$S$S(parList, "x=") * scale;
}if ($I$(8).parameterExist$S$S(parList, "y=")) {
this.physletPanel.ay[i]=this.physletPanel.iheight - $I$(8).getParam$S$S(parList, "y=") * scale;
}if ($I$(8).parameterExist$S$S(parList, "vx=")) {
this.physletPanel.avx[i]=$I$(8).getParam$S$S(parList, "vx=") * scale;
}if ($I$(8).parameterExist$S$S(parList, "vy=")) {
this.physletPanel.avy[i]=-$I$(8).getParam$S$S(parList, "vy=") * scale;
}if ($I$(8).parameterExist$S$S(parList, "fixed=")) {
if ($I$(8).getParamStr$S$S(parList, "fixed=").equalsIgnoreCase$S("true")) {
this.physletPanel.setAtomFixed$I$Z(i, true);
} else {
this.physletPanel.setAtomFixed$I$Z(i, false);
}}}} else if (name.equals$O("diatomic") || name.equals$O("molecule") ) {
if ($I$(8).parameterExist$S$S(parList, "i=")) {
i=($I$(8).getParam$S$S(parList, "i=")|0);
if (i < 1) {
System.out.println$S("Diatomic index <1.");
return false;
}if (i > this.physletPanel.mnMax) {
System.out.println$S("Diatomic index out of range. Number of atoms=" + this.physletPanel.mnMax);
return false;
}if ($I$(8).parameterExist$S$S(parList, "x=")) {
this.physletPanel.xcm[i]=$I$(8).getParam$S$S(parList, "x=") * scale;
}if ($I$(8).parameterExist$S$S(parList, "y=")) {
this.physletPanel.ycm[i]=this.physletPanel.iheight - $I$(8).getParam$S$S(parList, "y=") * scale;
}if ($I$(8).parameterExist$S$S(parList, "vx=")) {
this.physletPanel.vxcm[i]=$I$(8).getParam$S$S(parList, "vx=") * scale;
}if ($I$(8).parameterExist$S$S(parList, "vy=")) {
this.physletPanel.vycm[i]=-$I$(8).getParam$S$S(parList, "vy=") * scale;
}if ($I$(8).parameterExist$S$S(parList, "theta=")) {
this.physletPanel.teta[i]=$I$(8).getParam$S$S(parList, "theta=");
}if ($I$(8).parameterExist$S$S(parList, "w=")) {
this.physletPanel.w[i]=$I$(8).getParam$S$S(parList, "w=");
}this.physletPanel.BallDValues$I(i);
}} else if (name.equals$O("ensemble")) {
if ($I$(8).parameterExist$S$S(parList, "steps=")) {
this.physletPanel.numSteps=Math.max(1, ($I$(8).getParam$S$S(parList, "steps=")|0));
}if ($I$(8).parameterExist$S$S(parList, "mass_atom=")) {
this.physletPanel.mM=$I$(8).getParam$S$S(parList, "mass_atom=");
}if ($I$(8).parameterExist$S$S(parList, "mass_mol=")) {
this.physletPanel.mD=$I$(8).getParam$S$S(parList, "mass_mol=");
} else if ($I$(8).parameterExist$S$S(parList, "mass_diatomic=")) {
this.physletPanel.mD=$I$(8).getParam$S$S(parList, "mass_diatomic=");
}if ($I$(8).parameterExist$S$S(parList, "r_atom=")) {
var r=($I$(8).getParam$S$S(parList, "r_atom=")|0);
this.physletPanel.setAtomRad$I(r);
}if ($I$(8).parameterExist$S$S(parList, "r_mol=")) {
var r=($I$(8).getParam$S$S(parList, "r_mol=")|0);
this.physletPanel.setMolRad$I(r);
} else if ($I$(8).parameterExist$S$S(parList, "r_diatomic=")) {
var r=($I$(8).getParam$S$S(parList, "r_diatomic=")|0);
this.physletPanel.setMolRad$I(r);
}if ($I$(8).parameterExist$S$S(parList, "separation=")) {
var sep=$I$(8).getParam$S$S(parList, "separation=");
this.physletPanel.setMolSeparation$D(sep);
}if ($I$(8).parameterExist$S$S(parList, "scale=")) {
this.physletPanel.scale=$I$(8).getParam$S$S(parList, "scale=");
} else if ($I$(8).parameterExist$S$S(parList, "ppu=")) {
this.physletPanel.scale=$I$(8).getParam$S$S(parList, "ppu=");
}} else {
return false;
}this.physletPanel.KinEnTotal$();
if (shouldRun) {
this.clock.startClock$();
} else if (this.autoRefresh) {
this.physletPanel.paintOSI$();
this.physletPanel.repaint$();
}return true;
});

Clazz.newMeth(C$, 'repaintOSI', function () {
if (this.destroyed) {
return;
}if (this.autoRefresh && !this.clock.isRunning$() ) {
this.physletPanel.paintOSI$();
this.physletPanel.repaint$();
}}, p$1);

Clazz.newMeth(C$, ['setRGB$I$I$I$I','setRGB'], function (id, r, g, b) {
var c=Clazz.new_($I$(7).c$$I$I$I,[r, g, b]);
if ((id == 0) || (id == this.physletPanel.hashCode$()) ) {
this.physletPanel.backgroundColor=c;
p$1.repaintOSI.apply(this, []);
return true;
}var ds=Clazz.load('edu.davidson.tools.SApplet').getDataSource$I(id);
if ((ds != null ) && (Clazz.instanceOf(ds, "diatomic.PhysletPanel.AtomSource")) ) {
var i=(ds).index;
if (i < this.physletPanel.atomColor.length) {
this.physletPanel.atomColor[i]=c;
}p$1.repaintOSI.apply(this, []);
return true;
}if ((ds != null ) && (Clazz.instanceOf(ds, "diatomic.PhysletPanel.DiatomicSource")) ) {
var i=(ds).index;
if (i < this.physletPanel.molColor.length) {
this.physletPanel.molColor[i]=c;
}p$1.repaintOSI.apply(this, []);
return true;
}return false;
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (auto) {
this.autoRefresh=auto;
if (this.autoRefresh) {
this.physletPanel.paintOSI$();
this.physletPanel.repaint$();
}});

Clazz.newMeth(C$, ['getEnsembleID$','getEnsembleID'], function () {
return this.physletPanel.hashCode$();
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:18 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
