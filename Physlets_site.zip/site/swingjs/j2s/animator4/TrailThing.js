(function(){var P$=Clazz.newPackage("animator4"),I$=[['edu.davidson.graph.DataSet','java.awt.Polygon']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TrailThing", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.dataset = null;
this.point = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.dataset = Clazz.new_((I$[1]||$incl$(1)));
this.point = Clazz.array(Double.TYPE, [2]);
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I', function (o, s) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, "0", "0"]);
C$.$init$.apply(this);
this.s = s;
}, 1);

Clazz.newMeth(C$, 'incTrail$D$D', function (x, y) {
this.vars[1] = x;
this.vars[2] = y;
this.point[0] = x;
this.point[1] = y;
try {
this.dataset.append$DA$I(this.point, 1);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Error appending Data!");
} else {
throw e;
}
}
if (this.trail == null  || this.trailSize < 1 ) return;
var xpix = this.canvas.pixFromX$D(x);
var ypix = this.canvas.pixFromY$D(y);
if (this.trail.npoints < this.trailSize) {
this.trail.addPoint$I$I(xpix, ypix);
} else {
System.arraycopy(this.trail.xpoints, 1, this.trail.xpoints, 0, this.trailSize - 1);
System.arraycopy(this.trail.ypoints, 1, this.trail.ypoints, 0, this.trailSize - 1);
this.trail.xpoints[this.trailSize - 1] = xpix;
this.trail.ypoints[this.trailSize - 1] = ypix;
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color(this.color);
if (this.trailSize > 1 && this.trail.npoints > 1 ) {
g.drawPolyline$IA$IA$I(this.trail.xpoints, this.trail.ypoints, this.trail.npoints);
}});

Clazz.newMeth(C$, 'clearTrail', function () {
if (this.trail != null  && this.trail.npoints == 0 ) {
;} else {
this.trail = Clazz.new_((I$[2]||$incl$(2)));
this.dataset = Clazz.new_((I$[1]||$incl$(1)));
}});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:05:24
