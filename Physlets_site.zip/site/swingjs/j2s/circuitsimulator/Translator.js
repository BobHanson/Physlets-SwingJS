(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'java.util.Vector','java.net.URL','java.io.BufferedReader','java.io.InputStreamReader',['circuitsimulator.Translator','.LanguageItem']]],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Translator", function(){
Clazz.newInstance(this, arguments,0,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.languageString=null;
this.stringList=null;
this.applet=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.languageString="";
this.stringList=Clazz.new_(Clazz.load('java.util.Vector'));
}, 1);

Clazz.newMeth(C$, 'c$$java_applet_Applet', function (app) {
C$.$init$.apply(this);
this.applet=app;
}, 1);

Clazz.newMeth(C$, 'loadLanguage$S', function (inputfile) {
System.out.println$S("PropertyHandler is loading Properties...");
var trydoc=false;
this.languageString="";
try {
var url=Clazz.new_(Clazz.load('java.net.URL').c$$S,[this.applet.getCodeBase$().toString() + inputfile]);
var $in=url.openStream$();
var br=Clazz.new_(Clazz.load('java.io.BufferedReader').c$$java_io_Reader,[Clazz.new_(Clazz.load('java.io.InputStreamReader').c$$java_io_InputStream,[$in])]);
var line;
while ((line=br.readLine$()) != null ){
var sepInd=line.indexOf$S("=");
this.stringList.addElement$TE(Clazz.new_(Clazz.load(['circuitsimulator.Translator','.LanguageItem']).c$$S$S, [this, null, line.substring$I(sepInd + 1), line.substring$I$I(0, sepInd)]));
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
trydoc=true;
} else {
throw e;
}
}
if (trydoc) {
this.languageString="";
try {
var url=Clazz.new_($I$(2).c$$S,[this.applet.getDocumentBase$().toString() + inputfile]);
var $in=url.openStream$();
var br=Clazz.new_($I$(3).c$$java_io_Reader,[Clazz.new_($I$(4).c$$java_io_InputStream,[$in])]);
var line;
while ((line=br.readLine$()) != null ){
var sepInd=line.indexOf$S("=");
this.stringList.addElement$TE(Clazz.new_($I$(5).c$$S$S, [this, null, line.substring$I(sepInd + 1), line.substring$I$I(0, sepInd)]));
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("load failed: " + e.getMessage$());
} else {
throw e;
}
}
}System.out.println$S("Language file loaded.");
this.printList$();
});

Clazz.newMeth(C$, 'translate$S$S', function (from, dir) {
if (this.languageString.equals$O("")) return from;
var langItem=null;
if (dir.equals$O("->")) {
for (var e=this.stringList.elements$(); e.hasMoreElements$(); ) {
langItem=e.nextElement$();
if (langItem.english.equals$O(from)) return langItem.foreign;
}
} else {
for (var e=this.stringList.elements$(); e.hasMoreElements$(); ) {
langItem=e.nextElement$();
if (langItem.foreign.equals$O(from)) return langItem.english;
}
}System.out.println$S(from + ": not in list");
return from;
});

Clazz.newMeth(C$, 'printList$', function () {
var langItem=null;
for (var e=this.stringList.elements$(); e.hasMoreElements$(); ) {
langItem=e.nextElement$();
System.out.println$S(langItem.toString());
}
});
;
(function(){var C$=Clazz.newClass(P$.Translator, "LanguageItem", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.english=null;
this.foreign=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$S', function (e, f) {
C$.$init$.apply(this);
this.english="" + e;
this.foreign="" + f;
}, 1);

Clazz.newMeth(C$, 'toString', function () {
return this.english + "=" + this.foreign ;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:16 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
