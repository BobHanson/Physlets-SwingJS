(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),p$1={};
var C$=Clazz.newClass(P$, "SRK45pd", null, 'edu.davidson.numerics.SODE');
C$.b=null;
C$.ch=null;
C$.ct=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.b=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0.2]), Clazz.array(Double.TYPE, -1, [0.075, 0.225]), Clazz.array(Double.TYPE, -1, [0.3, -0.9, 1.2]), Clazz.array(Double.TYPE, -1, [0.3100137174211248, -0.9259259259259259, 1.2071330589849107, 0.07544581618655692]), Clazz.array(Double.TYPE, -1, [-0.6703703703703704, 2.5, -0.8956228956228957, -3.3703703703703702, 3.4363636363636365])]);
C$.ch=Clazz.array(Double.TYPE, -1, [0.08796296296296297, 0.0, 0.481000481000481, -0.5787037037037037, 0.9204545454545454, 0.08928571428571429]);
C$.ct=Clazz.array(Double.TYPE, -1, [-0.030555555555555558, 0.0, 0.15873015873015872, -0.7638888888888888, 0.675, -0.039285714285714285]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.h=0;
this.numEqu=0;
this.dydx=null;
this.xTemp=null;
this.f=null;
this.truncErr=null;
this.equations=null;
this.err=0;
this.tol=0;
this.hmin=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.h=0.01;
this.numEqu=0;
this.tol=1.0E-7;
this.hmin=1.0E-6;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'getTol$', function () {
return this.tol;
});

Clazz.newMeth(C$, 'setTol$D', function (t) {
this.tol=t;
this.hmin=this.tol * 10;
});

Clazz.newMeth(C$, 'getH$', function () {
return this.h;
});

Clazz.newMeth(C$, 'setH$D', function (h) {
this.h=h;
});

Clazz.newMeth(C$, 'stepBack$D$DA', function (dx, x) {
var count=0;
var oldH;
this.h=-Math.abs(this.h);
while (dx < 0 ){
if (this.h < dx ) {
oldH=this.h;
this.h=dx;
dx=dx - p$1.stepRK45pd$DA.apply(this, [x]);
this.h=oldH;
count++;
} else {
dx=dx - p$1.stepRK45pd$DA.apply(this, [x]);
count++;
}}
System.out.println$S("count:" + count + "  h:" + new Double(this.h).toString() );
this.h=+Math.abs(this.h);
return count;
}, p$1);

Clazz.newMeth(C$, 'step$D$DA', function (dx, x) {
if (dx == 0 ) return 0;
if (x.length < this.numEqu) {
this.numEqu=x.length;
this.xTemp=Clazz.array(Double.TYPE, [this.numEqu]);
this.dydx=Clazz.array(Double.TYPE, [this.numEqu]);
this.truncErr=Clazz.array(Double.TYPE, [this.numEqu]);
this.f=Clazz.array(Double.TYPE, [6, this.numEqu]);
System.out.println$S("Warning:  Temporary arrays reset.");
}if (dx < 0 ) {
return p$1.stepBack$D$DA.apply(this, [dx, x]);
}var count=0;
var oldH;
while (dx > 0 ){
if (this.h > dx ) {
oldH=this.h;
this.h=dx;
dx=dx - p$1.stepRK45pd$DA.apply(this, [x]);
this.h=oldH;
count++;
} else {
dx=dx - p$1.stepRK45pd$DA.apply(this, [x]);
count++;
}}
System.out.println$S("count:" + count + "  h:" + new Double(this.h).toString() );
return count;
});

Clazz.newMeth(C$, 'stepODE$D$DA', function (dx, x) {
if (x.length < this.numEqu) {
System.out.println$S("Error:  The temporary arrays are not large enough.");
return 0;
}this.h=dx;
return p$1.stepRK45pd$DA.apply(this, [x]);
});

Clazz.newMeth(C$, 'stepRK45pd$DA', function (x) {
var i;
var j;
var k;
var h_did=this.h;
this.dydx=this.equations.rate$DA(x);
for (i=0; i < this.numEqu; i++) {
this.f[0][i]=this.dydx[i];
this.xTemp[i]=x[i];
}
this.err=2 * this.tol;
if (this.h >= 0  && this.h <= this.hmin  ) this.h=1.1 * this.hmin;
 else if (this.h < 0  && -this.h <= this.hmin  ) this.h=-1.1 * this.hmin;
while (this.err > this.tol  && Math.abs(this.h) > this.hmin  ){
for (k=1; k < 6; k++) {
for (i=0; i < this.numEqu; i++) {
x[i]=this.xTemp[i];
for (j=0; j < k; j++) x[i]=x[i] + this.h * C$.b[k - 1][j] * this.f[j][i] ;

}
this.dydx=this.equations.rate$DA(x);
for (i=0; i < this.numEqu; i++) this.f[k][i]=this.dydx[i];

}
for (i=0; i < this.numEqu; i++) {
x[i]=this.xTemp[i];
this.truncErr[i]=0;
for (k=0; k < 6; k++) {
x[i]=x[i] + this.h * C$.ch[k] * this.f[k][i] ;
this.truncErr[i]=this.truncErr[i] + this.h * C$.ct[k] * this.f[k][i] ;
}
this.truncErr[i]=Math.abs(this.truncErr[i]);
}
this.err=0;
for (i=0; i < this.numEqu; i++) {
if (this.err < this.truncErr[i] ) this.err=this.truncErr[i];
}
h_did=this.h;
if (this.err == 0.0 ) this.err=this.tol / 100000.0;
if (this.err > this.tol ) this.h=0.9 * this.h * Math.pow(this.tol / this.err, 0.25) ;
 else this.h=0.9 * this.h * Math.pow(this.tol / this.err, 0.2) ;
if (this.h >= 0  && this.h < this.hmin  ) this.h=this.hmin;
 else if (this.h < 0  && -this.h < this.hmin  ) this.h=-this.hmin;
}
return h_did;
}, p$1);

Clazz.newMeth(C$, 'setDifferentials$edu_davidson_numerics_SDifferentiable', function (d) {
this.equations=d;
this.numEqu=this.equations.getNumEqu$();
this.xTemp=Clazz.array(Double.TYPE, [this.numEqu]);
this.dydx=Clazz.array(Double.TYPE, [this.numEqu]);
this.truncErr=Clazz.array(Double.TYPE, [this.numEqu]);
this.f=Clazz.array(Double.TYPE, [6, this.numEqu]);
});

Clazz.newMeth(C$, 'getDiffernetials$', function () {
return this.equations;
});

Clazz.newMeth(C$, 'setNumberOfEquations$I', function (n) {
this.numEqu=n;
this.xTemp=Clazz.array(Double.TYPE, [this.numEqu]);
this.dydx=Clazz.array(Double.TYPE, [this.numEqu]);
this.truncErr=Clazz.array(Double.TYPE, [this.numEqu]);
this.f=Clazz.array(Double.TYPE, [6, this.numEqu]);
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:31 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
