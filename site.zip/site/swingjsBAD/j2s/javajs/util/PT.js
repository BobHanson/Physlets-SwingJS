(function(){var P$=Clazz.newPackage("javajs.util"),I$=[['javajs.util.DF','javajs.util.SB','javajs.util.AU','java.lang.reflect.Array']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PT");
C$.tensScale = null;
C$.decimalScale = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.tensScale = Clazz.array(Float.TYPE, -1, [10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0]);
C$.decimalScale = Clazz.array(Float.TYPE, -1, [0.1, 0.01, 0.001, 1.0E-4, 1.0E-5, 1.0E-6, 1.0E-7, 1.0E-8, 1.0E-9]);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'parseInt$S', function (str) {
return C$.parseIntNext$S$IA(str, Clazz.array(Integer.TYPE, -1, [0]));
}, 1);

Clazz.newMeth(C$, 'parseIntNext$S$IA', function (str, next) {
var cch = str.length$();
if (next[0] < 0 || next[0] >= cch ) return -2147483648;
return C$.parseIntChecked$S$I$IA(str, cch, next);
}, 1);

Clazz.newMeth(C$, 'parseIntChecked$S$I$IA', function (str, ichMax, next) {
var digitSeen = false;
var value = 0;
var ich = next[0];
if (ich < 0) return -2147483648;
var ch;
while (ich < ichMax && C$.isWhiteSpace$S$I(str, ich) )++ich;

var negative = false;
if (ich < ichMax && (str.charCodeAt(ich)) == 45  ) {
negative=true;
++ich;
}while (ich < ichMax && (ch=str.charAt(ich).$c()) >= 48  && ch <= 57 ){
value=value * 10 + (ch - 48);
digitSeen=true;
++ich;
}
if (!digitSeen) value=-2147483648;
 else if (negative) value=-value;
next[0]=ich;
return value;
}, 1);

Clazz.newMeth(C$, 'isWhiteSpace$S$I', function (str, ich) {
var ch;
return (ich >= 0 && ((ch=str.charAt(ich)) == " " || ch == "\u0009"  || ch == "\u000a" ) );
}, 1);

Clazz.newMeth(C$, 'parseFloatChecked$S$I$IA$Z', function (str, ichMax, next, isStrict) {
var digitSeen = false;
var ich = next[0];
if (isStrict && str.indexOf("\u000a") != str.lastIndexOf("\u000a") ) return NaN;
while (ich < ichMax && C$.isWhiteSpace$S$I(str, ich) )++ich;

var negative = false;
if (ich < ichMax && str.charAt(ich) == "-" ) {
++ich;
negative=true;
}var ch = 0;
var ival = 0.0;
var ival2 = 0.0;
while (ich < ichMax && (ch=str.charAt(ich).$c()) >= 48  && ch <= 57 ){
ival=(ival * 10.0) + (ch - 48) * 1.0;
++ich;
digitSeen=true;
}
var isDecimal = false;
var iscale = 0;
var nzero = (ival == 0  ? -1 : 0);
if (ch == 46 ) {
isDecimal=true;
while (++ich < ichMax && (ch=str.charAt(ich).$c()) >= 48  && ch <= 57 ){
digitSeen=true;
if (nzero < 0) {
if (ch == 48) {
nzero--;
continue;
}nzero=-nzero;
}if (iscale < C$.decimalScale.length) {
ival2=(ival2 * 10.0) + (ch - 48) * 1.0;
iscale++;
}}
}var value;
if (!digitSeen) {
value=NaN;
} else if (ival2 > 0 ) {
value=ival2 * C$.decimalScale[iscale - 1];
if (nzero > 1) {
if (nzero - 2 < C$.decimalScale.length) {
value *= C$.decimalScale[nzero - 2];
} else {
value *= Math.pow(10, 1 - nzero);
}} else {
value += ival;
}} else {
value=ival;
}var isExponent = false;
if (ich < ichMax && (ch == 69 || ch == 101  || ch == 68 ) ) {
isExponent=true;
if (++ich >= ichMax) return NaN;
ch=str.charAt(ich).$c();
if ((ch == 43 ) && (++ich >= ichMax) ) return NaN;
next[0]=ich;
var exponent = C$.parseIntChecked$S$I$IA(str, ichMax, next);
if (exponent == -2147483648) return NaN;
if (exponent > 0 && exponent <= C$.tensScale.length ) value *= C$.tensScale[exponent - 1];
 else if (exponent < 0 && -exponent <= C$.decimalScale.length ) value *= C$.decimalScale[-exponent - 1];
 else if (exponent != 0) value *= Math.pow(10, exponent);
} else {
next[0]=ich;
}if (negative) value=-value;
if (value == Infinity ) value=3.4028235E38;
return (!isStrict || (!isExponent || isDecimal ) && C$.checkTrailingText$S$I$I(str, next[0], ichMax)   ? value : NaN);
}, 1);

Clazz.newMeth(C$, 'checkTrailingText$S$I$I', function (str, ich, ichMax) {
var ch;
while (ich < ichMax && (C$.isWhitespace$C(ch=str.charAt(ich)) || ch == ";" ) )++ich;

return (ich == ichMax);
}, 1);

Clazz.newMeth(C$, 'parseFloatArray$S', function (str) {
return C$.parseFloatArrayNext$S$IA$FA$S$S(str, Clazz.array(Integer.TYPE, [1]), null, null, null);
}, 1);

Clazz.newMeth(C$, 'parseFloatArrayInfested$SA$FA', function (tokens, data) {
var len = data.length;
var nTokens = tokens.length;
var n = 0;
var max = 0;
for (var i = 0; i >= 0 && i < len  && n < nTokens ; i++) {
var f;
while (Float.isNaN(f=C$.parseFloat$S(tokens[n++])) && n < nTokens ){
}
if (!Float.isNaN(f)) data[(max=i)]=f;
if (n == nTokens) break;
}
return max + 1;
}, 1);

Clazz.newMeth(C$, 'parseFloatArrayNext$S$IA$FA$S$S', function (str, next, f, strStart, strEnd) {
var n = 0;
var pt = next[0];
if (pt >= 0) {
if (strStart != null ) {
var p = str.indexOf(strStart, pt);
if (p >= 0) next[0]=p + strStart.length$();
}str=str.substring(next[0]);
pt=(strEnd == null  ? -1 : str.indexOf(strEnd));
if (pt < 0) pt=str.length$();
 else str=str.substring(0, pt);
next[0]+=pt + 1;
var tokens = C$.getTokens$S(str);
if (f == null ) f=Clazz.array(Float.TYPE, [tokens.length]);
n=C$.parseFloatArrayInfested$SA$FA(tokens, f);
}if (f == null ) return Clazz.array(Float.TYPE, [0]);
for (var i = n; i < f.length; i++) f[i]=NaN;

return f;
}, 1);

Clazz.newMeth(C$, 'parseFloatRange$S$I$IA', function (str, ichMax, next) {
var cch = str.length$();
if (ichMax > cch) ichMax=cch;
if (next[0] < 0 || next[0] >= ichMax ) return NaN;
return C$.parseFloatChecked$S$I$IA$Z(str, ichMax, next, false);
}, 1);

Clazz.newMeth(C$, 'parseFloatNext$S$IA', function (str, next) {
var cch = (str == null  ? -1 : str.length$());
return (next[0] < 0 || next[0] >= cch  ? NaN : C$.parseFloatChecked$S$I$IA$Z(str, cch, next, false));
}, 1);

Clazz.newMeth(C$, 'parseFloatStrict$S', function (str) {
var cch = str.length$();
if (cch == 0) return NaN;
return C$.parseFloatChecked$S$I$IA$Z(str, cch, Clazz.array(Integer.TYPE, -1, [0]), true);
}, 1);

Clazz.newMeth(C$, 'parseFloat$S', function (str) {
return C$.parseFloatNext$S$IA(str, Clazz.array(Integer.TYPE, -1, [0]));
}, 1);

Clazz.newMeth(C$, 'parseIntRadix$S$I', function (s, i) {
{
return Integer.parseIntRadix(s, i);
}
}, 1);

Clazz.newMeth(C$, 'getTokens$S', function (line) {
return C$.getTokensAt$S$I(line, 0);
}, 1);

Clazz.newMeth(C$, 'parseToken$S', function (str) {
return C$.parseTokenNext$S$IA(str, Clazz.array(Integer.TYPE, -1, [0]));
}, 1);

Clazz.newMeth(C$, 'parseTrimmed$S', function (str) {
return C$.parseTrimmedRange$S$I$I(str, 0, str.length$());
}, 1);

Clazz.newMeth(C$, 'parseTrimmedAt$S$I', function (str, ichStart) {
return C$.parseTrimmedRange$S$I$I(str, ichStart, str.length$());
}, 1);

Clazz.newMeth(C$, 'parseTrimmedRange$S$I$I', function (str, ichStart, ichMax) {
var cch = str.length$();
if (ichMax < cch) cch=ichMax;
if (cch < ichStart) return "";
return C$.parseTrimmedChecked$S$I$I(str, ichStart, cch);
}, 1);

Clazz.newMeth(C$, 'getTokensAt$S$I', function (line, ich) {
if (line == null ) return null;
var cchLine = line.length$();
if (ich < 0 || ich > cchLine ) return null;
var tokenCount = C$.countTokens$S$I(line, ich);
var tokens = Clazz.array(java.lang.String, [tokenCount]);
var next = Clazz.array(Integer.TYPE, [1]);
next[0]=ich;
for (var i = 0; i < tokenCount; ++i) tokens[i]=C$.parseTokenChecked$S$I$IA(line, cchLine, next);

return tokens;
}, 1);

Clazz.newMeth(C$, 'countChar$S$C', function (line, c) {
var n = 0;
for (var i = line.lastIndexOf(c) + 1; --i >= 0; ) if (line.charAt(i) == c) n++;

return n;
}, 1);

Clazz.newMeth(C$, 'countTokens$S$I', function (line, ich) {
var tokenCount = 0;
if (line != null ) {
var ichMax = line.length$();
while (true){
while (ich < ichMax && C$.isWhiteSpace$S$I(line, ich) )++ich;

if (ich == ichMax) break;
++tokenCount;
do {
++ich;
} while (ich < ichMax && !C$.isWhiteSpace$S$I(line, ich) );
}
}return tokenCount;
}, 1);

Clazz.newMeth(C$, 'parseTokenNext$S$IA', function (str, next) {
var cch = str.length$();
return (next[0] < 0 || next[0] >= cch  ? null : C$.parseTokenChecked$S$I$IA(str, cch, next));
}, 1);

Clazz.newMeth(C$, 'parseTokenRange$S$I$IA', function (str, ichMax, next) {
var cch = str.length$();
if (ichMax > cch) ichMax=cch;
return (next[0] < 0 || next[0] >= ichMax  ? null : C$.parseTokenChecked$S$I$IA(str, ichMax, next));
}, 1);

Clazz.newMeth(C$, 'parseTokenChecked$S$I$IA', function (str, ichMax, next) {
var ich = next[0];
while (ich < ichMax && C$.isWhiteSpace$S$I(str, ich) )++ich;

var ichNonWhite = ich;
while (ich < ichMax && !C$.isWhiteSpace$S$I(str, ich) )++ich;

next[0]=ich;
return (ichNonWhite == ich ? null : str.substring(ichNonWhite, ich));
}, 1);

Clazz.newMeth(C$, 'parseTrimmedChecked$S$I$I', function (str, ich, ichMax) {
while (ich < ichMax && C$.isWhiteSpace$S$I(str, ich) )++ich;

var ichLast = ichMax - 1;
while (ichLast >= ich && C$.isWhiteSpace$S$I(str, ichLast) )--ichLast;

return (ichLast < ich ? "" : str.substring(ich, ichLast + 1));
}, 1);

Clazz.newMeth(C$, 'parseIntRange$S$I$IA', function (str, ichMax, next) {
var cch = str.length$();
if (ichMax > cch) ichMax=cch;
return (next[0] < 0 || next[0] >= ichMax  ? -2147483648 : C$.parseIntChecked$S$I$IA(str, ichMax, next));
}, 1);

Clazz.newMeth(C$, 'parseFloatArrayData$SA$FA', function (tokens, data) {
C$.parseFloatArrayDataN$SA$FA$I(tokens, data, data.length);
}, 1);

Clazz.newMeth(C$, 'parseFloatArrayDataN$SA$FA$I', function (tokens, data, nData) {
for (var i = nData; --i >= 0; ) data[i]=(i >= tokens.length ? NaN : C$.parseFloat$S(tokens[i]));

}, 1);

Clazz.newMeth(C$, 'split$S$S', function (text, run) {
if (text.length$() == 0) return Clazz.array(java.lang.String, [0]);
var n = 1;
var i = text.indexOf(run);
var lines;
var runLen = run.length$();
if (i < 0 || runLen == 0 ) {
lines=Clazz.array(java.lang.String, [1]);
lines[0]=text;
return lines;
}var len = text.length$() - runLen;
for (; i >= 0 && i < len ; n++) i=text.indexOf(run, i + runLen);

lines=Clazz.array(java.lang.String, [n]);
i=0;
var ipt = 0;
var pt = 0;
for (; (ipt=text.indexOf(run, i)) >= 0 && pt + 1 < n ; ) {
lines[pt++]=text.substring(i, ipt);
i=ipt + runLen;
}
if (text.indexOf(run, len) != len) len+=runLen;
lines[pt]=text.substring(i, len);
return lines;
}, 1);

Clazz.newMeth(C$, 'getQuotedStringAt$S$I', function (line, ipt0) {
var next = Clazz.array(Integer.TYPE, -1, [ipt0]);
return C$.getQuotedStringNext$S$IA(line, next);
}, 1);

Clazz.newMeth(C$, 'getQuotedStringNext$S$IA', function (line, next) {
var i = next[0];
if (i < 0 || (i=line.indexOf("\"", i)) < 0 ) return "";
var pt = i + 1;
var len = line.length$();
while (++i < len && line.charAt(i) != "\"" )if (line.charAt(i) == "\\") i++;

next[0]=i + 1;
return line.substring(pt, i);
}, 1);

Clazz.newMeth(C$, 'getQuotedOrUnquotedAttribute$S$S', function (line, key) {
if (line == null  || key == null  ) return null;
var pt = line.toLowerCase().indexOf(key.toLowerCase() + "=");
if (pt < 0 || (pt=pt + key.length$() + 1 ) >= line.length$() ) return "";
var c = line.charAt(pt);
switch (c.$c()) {
case 39:
case 34:
pt++;
break;
default:
c=" ";
line += " ";
}
var pt1 = line.indexOf(c, pt);
return (pt1 < 0 ? null : line.substring(pt, pt1));
}, 1);

Clazz.newMeth(C$, 'getCSVString$S$IA', function (line, next) {
var i = next[1];
if (i < 0 || (i=line.indexOf("\"", i)) < 0 ) return null;
var pt = next[0]=i;
var len = line.length$();
var escaped = false;
var haveEscape = false;
while (++i < len && (line.charAt(i) != "\"" || (escaped=(i + 1 < len && line.charAt(i + 1) == "\"" )) ) )if (escaped) {
escaped=false;
haveEscape=true;
i++;
}
if (i >= len) {
next[1]=-1;
return null;
}next[1]=i + 1;
var s = line.substring(pt + 1, i);
return (haveEscape ? C$.rep$S$S$S(C$.rep$S$S$S(s, "\"\"", "\u0000"), "\u0000", "\"") : s);
}, 1);

Clazz.newMeth(C$, 'isOneOf$S$S', function (key, semiList) {
if (semiList.length$() == 0) return false;
if (semiList.charAt(0) != ";") semiList=";" + semiList + ";" ;
return key.indexOf(";") < 0 && semiList.indexOf(';' + key + ';' ) >= 0 ;
}, 1);

Clazz.newMeth(C$, 'getQuotedAttribute$S$S', function (info, name) {
var i = info.indexOf(name + "=");
return (i < 0 ? null : C$.getQuotedStringAt$S$I(info, i));
}, 1);

Clazz.newMeth(C$, 'approx$F$F', function (f, n) {
return Math.round(f * n) / n;
}, 1);

Clazz.newMeth(C$, 'rep$S$S$S', function (str, strFrom, strTo) {
if (str == null  || strFrom.length$() == 0  || str.indexOf(strFrom) < 0 ) return str;
var isOnce = (strTo.indexOf(strFrom) >= 0);
do {
str=str.$replace(strFrom, strTo);
} while (!isOnce && str.indexOf(strFrom) >= 0 );
return str;
}, 1);

Clazz.newMeth(C$, 'formatF$F$I$I$Z$Z', function (value, width, precision, alignLeft, zeroPad) {
return C$.formatS$S$I$I$Z$Z((I$[1]||$incl$(1)).formatDecimal$F$I(value, precision), width, 0, alignLeft, zeroPad);
}, 1);

Clazz.newMeth(C$, 'formatD$D$I$I$Z$Z$Z', function (value, width, precision, alignLeft, zeroPad, allowOverflow) {
return C$.formatS$S$I$I$Z$Z((I$[1]||$incl$(1)).formatDecimal$F$I(value, -1 - precision), width, 0, alignLeft, zeroPad);
}, 1);

Clazz.newMeth(C$, 'formatS$S$I$I$Z$Z', function (value, width, precision, alignLeft, zeroPad) {
if (value == null ) return "";
var len = value.length$();
if (precision != 2147483647 && precision > 0  && precision < len ) value=value.substring(0, precision);
 else if (precision < 0 && len + precision >= 0 ) value=value.substring(len + precision + 1 );
var padLength = width - value.length$();
if (padLength <= 0) return value;
var isNeg = (zeroPad && !alignLeft && value.charAt(0) == "-"  );
var padChar = (zeroPad ? "0" : " ");
var padChar0 = (isNeg ? "-" : padChar);
var sb = Clazz.new_((I$[2]||$incl$(2)));
if (alignLeft) sb.append$S(value);
sb.appendC$C(padChar0);
for (var i = padLength; --i > 0; ) sb.appendC$C(padChar);

if (!alignLeft) sb.append$S(isNeg ? padChar + value.substring(1) : value);
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'replaceWithCharacter$S$S$C', function (str, strFrom, chTo) {
if (str == null ) return null;
for (var i = strFrom.length$(); --i >= 0; ) str=str.$replace(strFrom.charAt(i), chTo);

return str;
}, 1);

Clazz.newMeth(C$, 'replaceAllCharacters$S$S$S', function (str, strFrom, strTo) {
for (var i = strFrom.length$(); --i >= 0; ) {
var chFrom = strFrom.substring(i, i + 1);
str=C$.rep$S$S$S(str, chFrom, strTo);
}
return str;
}, 1);

Clazz.newMeth(C$, 'trim$S$S', function (str, chars) {
if (str == null  || str.length$() == 0 ) return str;
if (chars.length$() == 0) return str.trim();
var len = str.length$();
var k = 0;
while (k < len && chars.indexOf(str.charAt(k)) >= 0 )k++;

var m = str.length$() - 1;
while (m > k && chars.indexOf(str.charAt(m)) >= 0 )m--;

return str.substring(k, m + 1);
}, 1);

Clazz.newMeth(C$, 'trimQuotes$S', function (value) {
return (value != null  && value.length$() > 1  && value.startsWith$S("\"")  && value.endsWith$S("\"")  ? value.substring(1, value.length$() - 1) : value);
}, 1);

Clazz.newMeth(C$, 'isNonStringPrimitive$O', function (info) {
return Clazz.instanceOf(info, "java.lang.Number") || Clazz.instanceOf(info, "java.lang.Boolean") ;
}, 1);

Clazz.newMeth(C$, 'toJSON$S$O', function (infoType, info) {
if (info == null ) return C$.packageJSON$S$S(infoType, null);
if (C$.isNonStringPrimitive$O(info)) return C$.packageJSON$S$S(infoType, info.toString());
var s = null;
var sb = null;
while (true){
if (Clazz.instanceOf(info, "java.lang.String")) {
s=info;
{
if (typeof s == "undefined") s = "null"
}
if (s.indexOf("{\"") != 0) {
s=C$.esc$S(s);
}break;
}if (Clazz.instanceOf(info, "javajs.api.JSONEncodable")) {
if ((s=(info).toJSON()) == null ) s="null";
break;
}sb=Clazz.new_((I$[2]||$incl$(2)));
if (Clazz.instanceOf(info, "java.util.Map")) {
sb.append$S("{ ");
var sep = "";
for (var key, $key = (info).keySet().iterator(); $key.hasNext()&&((key=($key.next())),1);) {
sb.append$S(sep).append$S(C$.packageJSON$S$S(key, C$.toJSON$S$O(null, (info).get$O(key))));
sep=",";
}
sb.append$S(" }");
break;
}if (Clazz.instanceOf(info, "javajs.util.Lst")) {
sb.append$S("[ ");
var n = (info).size();
for (var i = 0; i < n; i++) {
if (i > 0) sb.appendC$C(",");
sb.append$S(C$.toJSON$S$O(null, (info).get$I(i)));
}
sb.append$S(" ]");
break;
}if (Clazz.instanceOf(info, "javajs.util.M34")) {
var len = (Clazz.instanceOf(info, "javajs.util.M4") ? 4 : 3);
var x = Clazz.array(Float.TYPE, [len]);
var m = info;
sb.appendC$C("[");
for (var i = 0; i < len; i++) {
if (i > 0) sb.appendC$C(",");
m.getRow$I$FA(i, x);
sb.append$S(C$.toJSON$S$O(null, x));
}
sb.appendC$C("]");
break;
}s=C$.nonArrayString$O(info);
if (s == null ) {
sb.append$S("[");
var n = (I$[3]||$incl$(3)).getLength$O(info);
for (var i = 0; i < n; i++) {
if (i > 0) sb.appendC$C(",");
sb.append$S(C$.toJSON$S$O(null, (I$[4]||$incl$(4)).get(info, i)));
}
sb.append$S("]");
break;
}info=info.toString();
}
return C$.packageJSON$S$S(infoType, (s == null  ? sb.toString() : s));
}, 1);

Clazz.newMeth(C$, 'nonArrayString$O', function (x) {
{
return (x.constructor == Array || x.BYTES_PER_ELEMENT ? null : x.toString());
}
}, 1);

Clazz.newMeth(C$, 'byteArrayToJSON$BA', function (data) {
var sb = Clazz.new_((I$[2]||$incl$(2)));
sb.append$S("[");
var n = data.length;
for (var i = 0; i < n; i++) {
if (i > 0) sb.appendC$C(",");
sb.appendI$I(data[i] & 255);
}
sb.append$S("]");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'packageJSON$S$S', function (infoType, info) {
return (infoType == null  ? info : "\"" + infoType + "\": " + info );
}, 1);

Clazz.newMeth(C$, 'escapeUrl$S', function (url) {
url=C$.rep$S$S$S(url, "\u000a", "");
url=C$.rep$S$S$S(url, "%", "%25");
url=C$.rep$S$S$S(url, "#", "%23");
url=C$.rep$S$S$S(url, "[", "%5B");
url=C$.rep$S$S$S(url, "\\", "%5C");
url=C$.rep$S$S$S(url, "]", "%5D");
url=C$.rep$S$S$S(url, " ", "%20");
return url;
}, 1);

Clazz.newMeth(C$, 'esc$S', function (str) {
if (str == null  || str.length$() == 0 ) return "\"\"";
var haveEscape = false;
var i = 0;
for (; i < "\\\\\u0009t\u000dr\u000an\"\"".length$(); i+=2) if (str.indexOf("\\\\\u0009t\u000dr\u000an\"\"".charAt(i)) >= 0) {
haveEscape=true;
break;
}
if (haveEscape) while (i < "\\\\\u0009t\u000dr\u000an\"\"".length$()){
var pt = -1;
var ch = "\\\\\u0009t\u000dr\u000an\"\"".charAt(i++);
var ch2 = "\\\\\u0009t\u000dr\u000an\"\"".charAt(i++);
var sb = Clazz.new_((I$[2]||$incl$(2)));
var pt0 = 0;
while ((pt=str.indexOf(ch, pt + 1)) >= 0){
sb.append$S(str.substring(pt0, pt)).appendC$C("\\").appendC$C(ch2);
pt0=pt + 1;
}
sb.append$S(str.substring(pt0, str.length$()));
str=sb.toString();
}
return "\"" + C$.escUnicode$S(str) + "\"" ;
}, 1);

Clazz.newMeth(C$, 'escUnicode$S', function (str) {
for (var i = str.length$(); --i >= 0; ) if ((str.charCodeAt(i)) > 127 ) {
var s = "0000" + Integer.toHexString(str.charAt(i).$c());
str=str.substring(0, i) + "\\u" + s.substring(s.length$() - 4) + str.substring(i + 1) ;
}
return str;
}, 1);

Clazz.newMeth(C$, 'escF$F', function (f) {
var sf = "" + new Float(f).toString();
{
if (sf.indexOf(".") < 0 && sf.indexOf("e") < 0) sf += ".0";
}
return sf;
}, 1);

Clazz.newMeth(C$, 'join$SA$C$I', function (s, c, i0) {
if (s.length < i0) return null;
var sb = Clazz.new_((I$[2]||$incl$(2)));
sb.append$S(s[i0++]);
for (var i = i0; i < s.length; i++) sb.appendC$C(c).append$S(s[i]);

return sb.toString();
}, 1);

Clazz.newMeth(C$, 'isLike$S$S', function (a, b) {
var areEqual = a.equals$O(b);
if (areEqual) return true;
var isStart = b.startsWith$S("*");
var isEnd = b.endsWith$S("*");
return (!isStart && !isEnd ) ? areEqual : isStart && isEnd  ? b.length$() == 1 || a.contains$CharSequence(b.substring(1, b.length$() - 1))  : isStart ? a.endsWith$S(b.substring(1)) : a.startsWith$S(b.substring(0, b.length$() - 1));
}, 1);

Clazz.newMeth(C$, 'getMapValueNoCase$java_util_Map$S', function (h, key) {
if ("this".equals$O(key)) return h;
var val = h.get$O(key);
if (val == null ) for (var e, $e = h.entrySet().iterator(); $e.hasNext()&&((e=($e.next())),1);) if (e.getKey().equalsIgnoreCase$S(key)) return e.getValue();

return val;
}, 1);

Clazz.newMeth(C$, 'clean$S', function (s) {
return C$.rep$S$S$S(C$.replaceAllCharacters$S$S$S(s, " \u0009\u000a\u000d", " "), "  ", " ").trim();
}, 1);

Clazz.newMeth(C$, 'fdup$S$I$I', function (f, pt, n) {
var ch;
var count = 0;
for (var i = pt; --i >= 1; ) {
if (C$.isDigit$C(ch=f.charAt(i))) continue;
switch (ch.$c()) {
case 46:
if (count++ != 0) return f;
continue;
case 45:
if (i != 1 && f.charAt(i - 1) != "." ) return f;
continue;
default:
return f;
}
}
var s = f.substring(0, pt + 1);
var sb = Clazz.new_((I$[2]||$incl$(2)));
for (var i = 0; i < n; i++) sb.append$S(s);

sb.append$S(f.substring(pt + 1));
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'formatString$S$S$S$F$D$Z', function (strFormat, key, strT, floatT, doubleT, doOne) {
if (strFormat == null ) return null;
if ("".equals$O(strFormat)) return "";
var len = key.length$();
if (strFormat.indexOf("%") < 0 || len == 0  || strFormat.indexOf(key) < 0 ) return strFormat;
var strLabel = "";
var ich;
var ichPercent;
var ichKey;
for (ich=0; (ichPercent=strFormat.indexOf("%", ich)) >= 0 && (ichKey=strFormat.indexOf(key, ichPercent + 1)) >= 0 ; ) {
if (ich != ichPercent) strLabel += strFormat.substring(ich, ichPercent);
ich=ichPercent + 1;
if (ichKey > ichPercent + 6) {
strLabel += "%";
continue;
}try {
var alignLeft = false;
if (strFormat.charAt(ich) == "-") {
alignLeft=true;
++ich;
}var zeroPad = false;
if (strFormat.charAt(ich) == "0") {
zeroPad=true;
++ich;
}var ch;
var width = 0;
while ((ch=strFormat.charAt(ich)) >= "0" && (ch <= "9") ){
width=(10 * width) + (ch.$c() - 48);
++ich;
}
var precision = 2147483647;
var isExponential = false;
if (strFormat.charAt(ich) == ".") {
++ich;
if ((ch=strFormat.charAt(ich)) == "-") {
isExponential=(strT == null );
++ich;
}if ((ch=strFormat.charAt(ich)) >= "0" && ch <= "9" ) {
precision=ch.$c() - 48;
++ich;
}if (isExponential) precision=-precision;
}var st = strFormat.substring(ich, ich + len);
if (!st.equals$O(key)) {
ich=ichPercent + 1;
strLabel += "%";
continue;
}ich+=len;
if (!Float.isNaN(floatT)) strLabel += C$.formatF$F$I$I$Z$Z(floatT, width, precision, alignLeft, zeroPad);
 else if (strT != null ) strLabel += C$.formatS$S$I$I$Z$Z(strT, width, precision, alignLeft, zeroPad);
 else if (!Double.isNaN(doubleT)) strLabel += C$.formatD$D$I$I$Z$Z$Z(doubleT, width, precision - 1, alignLeft, zeroPad, true);
if (doOne) break;
} catch (ioobe) {
if (Clazz.exceptionOf(ioobe, "java.lang.IndexOutOfBoundsException")){
ich=ichPercent;
break;
} else {
throw ioobe;
}
}
}
strLabel += strFormat.substring(ich);
return strLabel;
}, 1);

Clazz.newMeth(C$, 'formatStringS$S$S$S', function (strFormat, key, strT) {
return C$.formatString$S$S$S$F$D$Z(strFormat, key, strT, NaN, NaN, false);
}, 1);

Clazz.newMeth(C$, 'formatStringF$S$S$F', function (strFormat, key, floatT) {
return C$.formatString$S$S$S$F$D$Z(strFormat, key, null, floatT, NaN, false);
}, 1);

Clazz.newMeth(C$, 'formatStringI$S$S$I', function (strFormat, key, intT) {
return C$.formatString$S$S$S$F$D$Z(strFormat, key, "" + intT, NaN, NaN, false);
}, 1);

Clazz.newMeth(C$, 'sprintf$S$S$OA', function (strFormat, list, values) {
if (values == null ) return strFormat;
var n = list.length$();
if (n == values.length) try {
for (var o = 0; o < n; o++) {
if (values[o] == null ) continue;
switch ((list.charCodeAt(o))) {
case 115:
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "s", values[o], NaN, NaN, true);
break;
case 102:
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "f", null, (values[o]).floatValue(), NaN, true);
break;
case 105:
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "d", "" + values[o], NaN, NaN, true);
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "i", "" + values[o], NaN, NaN, true);
break;
case 100:
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "e", null, NaN, (values[o]).doubleValue(), true);
break;
case 112:
var pVal = values[o];
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "p", null, pVal.x, NaN, true);
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "p", null, pVal.y, NaN, true);
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "p", null, pVal.z, NaN, true);
break;
case 113:
var qVal = values[o];
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "q", null, qVal.x, NaN, true);
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "q", null, qVal.y, NaN, true);
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "q", null, qVal.z, NaN, true);
strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "q", null, qVal.w, NaN, true);
break;
case 83:
var sVal = values[o];
for (var i = 0; i < sVal.length; i++) strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "s", sVal[i], NaN, NaN, true);

break;
case 70:
var fVal = values[o];
for (var i = 0; i < fVal.length; i++) strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "f", null, fVal[i], NaN, true);

break;
case 73:
var iVal = values[o];
for (var i = 0; i < iVal.length; i++) strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "d", "" + iVal[i], NaN, NaN, true);

for (var i = 0; i < iVal.length; i++) strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "i", "" + iVal[i], NaN, NaN, true);

break;
case 68:
var dVal = values[o];
for (var i = 0; i < dVal.length; i++) strFormat=C$.formatString$S$S$S$F$D$Z(strFormat, "e", null, NaN, dVal[i], true);

}
}
return C$.rep$S$S$S(strFormat, "%%", "%");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
System.out.println$S("TextFormat.sprintf error " + list + " " + strFormat );
return C$.rep$S$S$S(strFormat, "%", "?");
}, 1);

Clazz.newMeth(C$, 'formatCheck$S', function (strFormat) {
if (strFormat == null  || strFormat.indexOf("p") < 0 && strFormat.indexOf("q") < 0  ) return strFormat;
strFormat=C$.rep$S$S$S(strFormat, "%%", "\u0001");
strFormat=C$.rep$S$S$S(strFormat, "%p", "%6.2p");
strFormat=C$.rep$S$S$S(strFormat, "%q", "%6.2q");
var format = C$.split$S$S(strFormat, "%");
var sb = Clazz.new_((I$[2]||$incl$(2)));
sb.append$S(format[0]);
for (var i = 1; i < format.length; i++) {
var f = "%" + format[i];
var pt;
if (f.length$() >= 3) {
if ((pt=f.indexOf("p")) >= 0) f=C$.fdup$S$I$I(f, pt, 3);
if ((pt=f.indexOf("q")) >= 0) f=C$.fdup$S$I$I(f, pt, 4);
}sb.append$S(f);
}
return sb.toString().$replace("\u0001", "%");
}, 1);

Clazz.newMeth(C$, 'leftJustify$javajs_util_SB$S$S', function (s, s1, s2) {
s.append$S(s2);
var n = s1.length$() - s2.length$();
if (n > 0) s.append$S(s1.substring(0, n));
}, 1);

Clazz.newMeth(C$, 'rightJustify$javajs_util_SB$S$S', function (s, s1, s2) {
var n = s1.length$() - s2.length$();
if (n > 0) s.append$S(s1.substring(0, n));
s.append$S(s2);
}, 1);

Clazz.newMeth(C$, 'safeTruncate$F$I', function (f, n) {
if (f > -0.001  && f < 0.001  ) f=0;
return (new Float(f).toString() + "         ").substring(0, n);
}, 1);

Clazz.newMeth(C$, 'isWild$S', function (s) {
return s != null  && (s.indexOf("*") >= 0 || s.indexOf("?") >= 0 ) ;
}, 1);

Clazz.newMeth(C$, 'isMatch$S$S$Z$Z', function (search, match, checkStar, allowInitialStar) {
if (search.equals$O(match)) return true;
var mLen = match.length$();
if (mLen == 0) return false;
var isStar0 = (checkStar && allowInitialStar  ? match.charAt(0) == "*" : false);
if (mLen == 1 && isStar0 ) return true;
var isStar1 = (checkStar && match.endsWith$S("*") );
var haveQ = (match.indexOf("?") >= 0);
if (!haveQ) {
if (isStar0) return (isStar1 ? (mLen < 3 || search.indexOf(match.substring(1, mLen - 1)) >= 0 ) : search.endsWith$S(match.substring(1)));
 else if (isStar1) return search.startsWith$S(match.substring(0, mLen - 1));
}var sLen = search.length$();
var qqqq = "????";
var nq = 4;
while (nq < sLen){
qqqq += qqqq;
nq+=4;
}
if (checkStar) {
if (isStar0) {
match=qqqq + match.substring(1);
mLen+=nq - 1;
}if (isStar1) {
match=match.substring(0, mLen - 1) + qqqq;
mLen+=nq - 1;
}}if (mLen < sLen) return false;
var ich = 0;
while (mLen > sLen){
if (allowInitialStar && match.charAt(ich) == "?" ) {
++ich;
} else if (match.charAt(ich + mLen - 1) != "?") {
return false;
}--mLen;
}
for (var i = sLen; --i >= 0; ) {
var chm = match.charAt(ich + i);
if (chm == "?") continue;
var chs = search.charAt(i);
if (chm != chs && (chm != "\u0001" || chs != "?" ) ) return false;
}
return true;
}, 1);

Clazz.newMeth(C$, 'replaceQuotedStrings$S$javajs_util_Lst$javajs_util_Lst', function (s, list, newList) {
var n = list.size();
for (var i = 0; i < n; i++) {
var name = list.get$I(i);
var newName = newList.get$I(i);
if (!newName.equals$O(name)) s=C$.rep$S$S$S(s, "\"" + name + "\"" , "\"" + newName + "\"" );
}
return s;
}, 1);

Clazz.newMeth(C$, 'replaceStrings$S$javajs_util_Lst$javajs_util_Lst', function (s, list, newList) {
var n = list.size();
for (var i = 0; i < n; i++) {
var name = list.get$I(i);
var newName = newList.get$I(i);
if (!newName.equals$O(name)) s=C$.rep$S$S$S(s, name, newName);
}
return s;
}, 1);

Clazz.newMeth(C$, 'isDigit$C', function (ch) {
var c = ch.$c();
return (48 <= c && c <= 57 );
}, 1);

Clazz.newMeth(C$, 'isUpperCase$C', function (ch) {
var c = ch.$c();
return (65 <= c && c <= 90 );
}, 1);

Clazz.newMeth(C$, 'isLowerCase$C', function (ch) {
var c = ch.$c();
return (97 <= c && c <= 122 );
}, 1);

Clazz.newMeth(C$, 'isLetter$C', function (ch) {
var c = ch.$c();
return (65 <= c && c <= 90  || 97 <= c && c <= 122  );
}, 1);

Clazz.newMeth(C$, 'isLetterOrDigit$C', function (ch) {
var c = ch.$c();
return (65 <= c && c <= 90  || 97 <= c && c <= 122   || 48 <= c && c <= 57  );
}, 1);

Clazz.newMeth(C$, 'isWhitespace$C', function (ch) {
var c = ch.$c();
return (c >= 28 && c <= 32  || c >= 9 && c <= 13  );
}, 1);

Clazz.newMeth(C$, 'fixPtFloats$javajs_util_T3$F', function (pt, f) {
pt.x=Math.round(pt.x * f) / f;
pt.y=Math.round(pt.y * f) / f;
pt.z=Math.round(pt.z * f) / f;
}, 1);

Clazz.newMeth(C$, 'fixDouble$D$D', function (d, f) {
return Math.round(d * f) / f;
}, 1);

Clazz.newMeth(C$, 'parseFloatFraction$S', function (s) {
var pt = s.indexOf("/");
return (pt < 0 ? C$.parseFloat$S(s) : C$.parseFloat$S(s.substring(0, pt)) / C$.parseFloat$S(s.substring(pt + 1)));
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-07-22 16:19:55 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
