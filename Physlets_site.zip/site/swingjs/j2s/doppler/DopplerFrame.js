(function(){var P$=Clazz.newPackage("doppler"),I$=[];
var C$=Clazz.newClass(P$, "DopplerFrame", null, 'a2s.Frame');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (str) {
C$.superclazz.c$$S.apply(this, [str]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'handleEvent$java_awt_Event', function (evt) {
switch (evt.id) {
case 201:
this.dispose();
System.exit(0);
return true;
default:
return C$.superclazz.prototype.handleEvent$java_awt_Event.apply(this, [evt]);
}
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:06:35
