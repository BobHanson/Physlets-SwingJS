(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['java.util.Vector','edu.davidson.graph.MarkerStyle','edu.davidson.graph.MarkerVertex','edu.davidson.graph.Markers']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "MarkerStyle");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.size = 0;
this.type = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.size = 4;
this.type = (I$[4]||$incl$(4)).TYPE_CIRCLE;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:11
