(function(){var P$=Clazz.newPackage("energyEigenvalue"),I$=[['edu.davidson.graphics.EtchedBorder','energyEigenvalue.EnergyGraph','java.awt.Panel','java.awt.Label','java.awt.TextField','java.awt.BorderLayout','java.awt.Button','edu.davidson.display.SNumber','edu.davidson.graphics.ThreadButton','edu.davidson.display.SInteger','java.awt.FlowLayout','Boolean','java.awt.SystemColor','java.awt.Dimension','energyEigenvalue.EnergyEigenvalue$1','java.awt.event.MouseAdapter','energyEigenvalue.EnergyEigenvalue$3','energyEigenvalue.EnergyEigenvalue$5','energyEigenvalue.EnergyEigenvalue$7','energyEigenvalue.EnergyEigenvalue$9','energyEigenvalue.EnergyEigenvalue$10','energyEigenvalue.EnergyEigenvalue$11','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "EnergyEigenvalue", null, 'edu.davidson.tools.SApplet');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.button_update = null;
this.button_find = null;
this.label_potential = null;
this.label_energy = null;
this.label_levels = null;
this.autoscalePotential = false;
this.sa = false;
this.sf = false;
this.noscale = false;
this.energy = 0;
this.hBar = 0;
this.xmin = 0;
this.xmax = 0;
this.breakvalue = 0;
this.ymin = 0;
this.ymax = 0;
this.tolerance = 0;
this.iterations = 0;
this.potentialStr = null;
this.nump = 0;
this.lower = 0;
this.higher = 0;
this.showControls = false;
this.ss = false;
this.sc = false;
this.sp = false;
this.controlpanel = null;
this.etchedBorder2 = null;
this.energyGraph = null;
this.panel1 = null;
this.potentialpanel = null;
this.label1 = null;
this.potentialFcn = null;
this.borderLayout1 = null;
this.borderLayout4 = null;
this.$update = null;
this.panel3 = null;
this.panel4 = null;
this.evalue = null;
this.label2 = null;
this.$forward = null;
this.rewind = null;
this.frewind = null;
this.fforward = null;
this.elevel = null;
this.find = null;
this.label3 = null;
this.borderLayout2 = null;
this.flowLayout1 = null;
this.flowLayout2 = null;
this.borderLayout5 = null;
this.borderLayout3 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.button_update = "Update";
this.button_find = "Find";
this.label_potential = "Potential";
this.label_energy = "Energy";
this.label_levels = "Energy Levels";
this.autoscalePotential = false;
this.noscale = false;
this.controlpanel = Clazz.new_((I$[1]||$incl$(1)));
this.etchedBorder2 = Clazz.new_((I$[1]||$incl$(1)));
this.energyGraph = Clazz.new_((I$[2]||$incl$(2)).c$$energyEigenvalue_EnergyEigenvalue,[this]);
this.panel1 = Clazz.new_((I$[3]||$incl$(3)));
this.potentialpanel = Clazz.new_((I$[3]||$incl$(3)));
this.label1 = Clazz.new_((I$[4]||$incl$(4)));
this.potentialFcn = Clazz.new_((I$[5]||$incl$(5)));
this.borderLayout1 = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout4 = Clazz.new_((I$[6]||$incl$(6)));
this.$update = Clazz.new_((I$[7]||$incl$(7)));
this.panel3 = Clazz.new_((I$[3]||$incl$(3)));
this.panel4 = Clazz.new_((I$[3]||$incl$(3)));
this.evalue = Clazz.new_((I$[8]||$incl$(8)));
this.label2 = Clazz.new_((I$[4]||$incl$(4)));
this.$forward = Clazz.new_((I$[9]||$incl$(9)));
this.rewind = Clazz.new_((I$[9]||$incl$(9)));
this.frewind = Clazz.new_((I$[9]||$incl$(9)));
this.fforward = Clazz.new_((I$[9]||$incl$(9)));
this.elevel = Clazz.new_((I$[10]||$incl$(10)));
this.find = Clazz.new_((I$[7]||$incl$(7)));
this.label3 = Clazz.new_((I$[4]||$incl$(4)));
this.borderLayout2 = Clazz.new_((I$[6]||$incl$(6)));
this.flowLayout1 = Clazz.new_((I$[11]||$incl$(11)));
this.flowLayout2 = Clazz.new_((I$[11]||$incl$(11)));
this.borderLayout5 = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout3 = Clazz.new_((I$[6]||$incl$(6)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'setResources', function () {
this.button_update = this.localProperties.getProperty$S$S("button.update", this.button_update);
this.button_find = this.localProperties.getProperty$S$S("button.find", this.button_find);
this.label_potential = this.localProperties.getProperty$S$S("label.potential", this.label_potential);
this.label_energy = this.localProperties.getProperty$S$S("label.energy", this.label_energy);
this.label_levels = this.localProperties.getProperty$S$S("label.levels", this.label_levels);
});

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
try {
this.xmin = Double.$valueOf(this.getParameter$S$S("XMin", "-5")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xmax = Double.$valueOf(this.getParameter$S$S("XMax", "5")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ymin = Double.$valueOf(this.getParameter$S$S("YMin", "0")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ymax = Double.$valueOf(this.getParameter$S$S("YMax", "25")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.hBar = Double.$valueOf(this.getParameter$S$S("HBarTwoM", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.energy = Double.$valueOf(this.getParameter$S$S("Energy", "1.0")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.potentialStr = this.getParameter$S$S("Potential", "x*x");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.autoscalePotential = (I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("AutoScaleY", "false")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.sc = (I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ss = (I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("ShowSpectrum", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.sp = (I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("ShowPotential", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.sf = (I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("ShowFunctions", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.nump = Integer.$valueOf(this.getParameter$S$S("NumPts", "200")).intValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.lower = Integer.$valueOf(this.getParameter$S$S("Lowest", "1")).intValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.higher = Integer.$valueOf(this.getParameter$S$S("Highest", "1")).intValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.tolerance = Double.$valueOf(this.getParameter$S$S("Tolerance", "1e-8")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.iterations = Integer.$valueOf(this.getParameter$S$S("MaxIterations", "40")).intValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.breakvalue = Double.$valueOf(this.getParameter$S$S("BreakValue", "1e12")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.sa = (I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("ScaleToArea", "false")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.energyGraph.setShowWavefunction$Z(this.sf);
this.energyGraph.setAutoscalePotential$Z(this.autoscalePotential);
this.energyGraph.setNumpts$I(this.nump);
this.energyGraph.setIterations$I(this.iterations);
this.energyGraph.setTolerance$D(this.tolerance);
this.energyGraph.setBreakValue$D(this.breakvalue);
this.energyGraph.showSpectrum$Z(this.ss);
this.setShowControls$Z(this.sc);
this.setShowPotential$Z(this.sp);
this.energyGraph.scaleToArea$Z(this.sa);
this.energyGraph.sethBar$D(this.hBar);
this.energyGraph.setEnergy$D(this.energy);
this.energyGraph.setMinMaxX$D$D(this.xmin, this.xmax);
this.potentialFcn.setText$S(this.potentialStr);
this.energyGraph.setPotential$S(this.potentialStr);
this.energyGraph.setMinMaxY$D$D(this.ymin, this.ymax);
this.energyGraph.setGraphBackground$java_awt_Color((I$[13]||$incl$(13)).control);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.panel1.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.potentialpanel.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.energyGraph.setLabelY$S(this.label_energy);
this.energyGraph.setEnableMouse$Z(false);
this.setSize$java_awt_Dimension(Clazz.new_((I$[14]||$incl$(14)).c$$I$I,[387, 342]));
this.etchedBorder2.setLayout$java_awt_LayoutManager(this.borderLayout5);
this.energyGraph.setBackground$java_awt_Color((I$[13]||$incl$(13)).control);
this.energyGraph.setSampleData$Z(false);
this.energyGraph.setBorders$S("0,10,100,0");
this.energyGraph.setAutoscaleX$Z(false);
this.energyGraph.setAutoscaleY$Z(false);
this.energyGraph.setLabelX$S("X");
this.label1.setAlignment$I(1);
this.label1.setText$S(this.label_potential);
this.potentialFcn.setText$S("x*x");
this.$update.setLabel$S(this.button_update);
this.panel3.setLayout$java_awt_LayoutManager(this.flowLayout2);
this.panel4.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.evalue.setColumns$I(8);
this.evalue.setValue$D(1.0);
this.evalue.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].evalue_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[15]||$incl$(15)).$init$, [this, null])));
this.label2.setAlignment$I(2);
this.label2.setText$S(this.label_energy);
this.$forward.setLabel$S(">");
this.$forward.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['mouseReleased$java_awt_event_MouseEvent','mouseReleased'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].forward_mouseReleased$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[16]||$incl$(16)), [this, null],P$.EnergyEigenvalue$2)));
this.$forward.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].forward_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[17]||$incl$(17)).$init$, [this, null])));
this.rewind.setLabel$S("<");
this.rewind.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['mouseReleased$java_awt_event_MouseEvent','mouseReleased'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].rewind_mouseReleased$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[16]||$incl$(16)), [this, null],P$.EnergyEigenvalue$4)));
this.rewind.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].rewind_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[18]||$incl$(18)).$init$, [this, null])));
this.frewind.setLabel$S("<<");
this.frewind.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['mouseReleased$java_awt_event_MouseEvent','mouseReleased'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].frewind_mouseReleased$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[16]||$incl$(16)), [this, null],P$.EnergyEigenvalue$6)));
this.frewind.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].frewind_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[19]||$incl$(19)).$init$, [this, null])));
this.fforward.setLabel$S(">>");
this.fforward.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['mouseReleased$java_awt_event_MouseEvent','mouseReleased'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].fforward_mouseReleased$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[16]||$incl$(16)), [this, null],P$.EnergyEigenvalue$8)));
this.fforward.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].fforward_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[20]||$incl$(20)).$init$, [this, null])));
this.elevel.setValue$I(1);
this.find.setLabel$S(this.button_find);
this.label3.setAlignment$I(2);
this.label3.setText$S("n =");
this.borderLayout2.setHgap$I(20);
this.flowLayout1.setHgap$I(1);
this.flowLayout1.setAlignment$I(0);
this.flowLayout2.setHgap$I(0);
this.flowLayout2.setAlignment$I(2);
this.find.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$10", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].find_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[21]||$incl$(21)).$init$, [this, null])));
this.$update.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "EnergyEigenvalue$11", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['energyEigenvalue.EnergyEigenvalue'].update_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[22]||$incl$(22)).$init$, [this, null])));
this.controlpanel.setLayout$java_awt_LayoutManager(this.borderLayout4);
this.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.controlpanel.setBackground$java_awt_Color((I$[23]||$incl$(23)).lightGray);
this.add$java_awt_Component$O(this.etchedBorder2, "Center");
this.etchedBorder2.add$java_awt_Component$O(this.energyGraph, "Center");
this.add$java_awt_Component$O(this.controlpanel, "South");
this.controlpanel.add$java_awt_Component$O(this.potentialpanel, "North");
this.potentialpanel.add$java_awt_Component$O(this.potentialFcn, "Center");
this.potentialpanel.add$java_awt_Component$O(this.label1, "West");
this.potentialpanel.add$java_awt_Component$O(this.$update, "East");
this.controlpanel.add$java_awt_Component$O(this.panel1, "Center");
this.panel1.add$java_awt_Component$O(this.panel4, "Center");
this.panel4.add$java_awt_Component$O(this.label2, null);
this.panel4.add$java_awt_Component$O(this.evalue, null);
this.panel4.add$java_awt_Component$O(this.frewind, null);
this.panel4.add$java_awt_Component$O(this.rewind, null);
this.panel4.add$java_awt_Component$O(this.$forward, null);
this.panel4.add$java_awt_Component$O(this.fforward, null);
this.panel1.add$java_awt_Component$O(this.panel3, "East");
this.panel3.add$java_awt_Component$O(this.find, null);
this.panel3.add$java_awt_Component$O(this.label3, null);
this.panel3.add$java_awt_Component$O(this.elevel, null);
});

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.firstTime) {
return 0;
} else {
return C$.superclazz.prototype.getAppletCount.apply(this, []);
}});

Clazz.newMeth(C$, 'start', function () {
C$.superclazz.prototype.start.apply(this, []);
if (this.firstTime) {
this.firstTime = false;
C$.superclazz.prototype.start.apply(this, []);
this.energyGraph.setOwner$edu_davidson_tools_SApplet(this);
this.energyGraph.updated = true;
this.energyGraph.setTitle$S(null);
this.energyGraph.purgeHashtable();
this.energyGraph.setPotential$S(this.potentialStr);
this.energyGraph.updated = false;
this.findEnergyLevel$I(this.lower);
this.findEnergyLevels$I$I(this.lower, this.higher);
}});

Clazz.newMeth(C$, 'destroy', function () {
this.energyGraph.destroy();
this.$forward.destroy();
this.rewind.destroy();
this.frewind.destroy();
this.fforward.destroy();
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Applet Information";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Energy", "double", "Initial energy"]), Clazz.array(java.lang.String, -1, ["Potential", "String", "Potential Energy"]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show user controls"]), Clazz.array(java.lang.String, -1, ["HBar", "double", "hBar value"]), Clazz.array(java.lang.String, -1, ["AutoscalePotential", "boolean", "autoscales the ys axis based on potential."]), Clazz.array(java.lang.String, -1, ["ShowPotential", "boolean", "shows or hides potential panel"]), Clazz.array(java.lang.String, -1, ["Lower", "int", "lowest e level to find"]), Clazz.array(java.lang.String, -1, ["Higher", "int", "highest e level to find"]), Clazz.array(java.lang.String, -1, ["NumPts", "int", "number of points to graph"]), Clazz.array(java.lang.String, -1, ["MaxIterations", "int", "number of iterations for binary search to perform"]), Clazz.array(java.lang.String, -1, ["BreakValue", "double", "max divergent value allowed value before Psi algorithm quits"])]);
return pinfo;
});

Clazz.newMeth(C$, ['getWavefunctionID$I','getWavefunctionID'], function (n) {
return this.energyGraph.getWavefunctionID$I(n);
});

Clazz.newMeth(C$, 'getActiveWavefunctionID', function () {
return this.energyGraph.getActiveWavefunctionID();
});

Clazz.newMeth(C$, 'getActiveStateID', function () {
return this.energyGraph.getActiveStateID();
});

Clazz.newMeth(C$, 'getActiveEnergy', function () {
return this.energyGraph.getActiveEnergy();
});

Clazz.newMeth(C$, 'getActiveQuantumNumber', function () {
return this.energyGraph.getActiveQuantumNumber();
});

Clazz.newMeth(C$, 'update_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.energyGraph.updated = true;
this.energyGraph.setTitle$S(null);
this.energyGraph.purgeHashtable();
this.energyGraph.setPotential$S(this.potentialFcn.getText());
this.energyGraph.updated = false;
});

Clazz.newMeth(C$, 'find_actionPerformed$java_awt_event_ActionEvent', function (e) {
var n = this.elevel.getValue();
if (n < 1) {
this.elevel.setBackground$java_awt_Color((I$[23]||$incl$(23)).red);
} else {
this.energyGraph.updated = true;
this.energyGraph.setPotential$S(this.potentialFcn.getText());
this.energyGraph.updated = false;
this.energyGraph.resetE = true;
var en = this.energyGraph.findElevel$I$Z(n, true);
if (this.noscale) {
} else {
this.energyGraph.scaleData$D$Z(en, true);
}this.evalue.setValue$D(en);
}});

Clazz.newMeth(C$, 'fforward_actionPerformed$java_awt_event_ActionEvent', function (e) {
var ene = this.evalue.getValue();
this.setPsi$D(ene);
ene = ene + 0.1;
this.evalue.setValue$D(ene);
});

Clazz.newMeth(C$, 'frewind_actionPerformed$java_awt_event_ActionEvent', function (e) {
var ene = this.evalue.getValue();
this.setPsi$D(ene);
ene = ene - 0.1;
this.evalue.setValue$D(ene);
});

Clazz.newMeth(C$, 'forward_actionPerformed$java_awt_event_ActionEvent', function (e) {
var ene = this.evalue.getValue();
this.setPsi$D(ene);
ene = ene + 0.005;
this.evalue.setValue$D(ene);
});

Clazz.newMeth(C$, 'rewind_actionPerformed$java_awt_event_ActionEvent', function (e) {
var ene = this.evalue.getValue();
this.setPsi$D(ene);
ene = ene - 0.005;
this.evalue.setValue$D(ene);
});

Clazz.newMeth(C$, ['setAutoscaleY$Z','setAutoscaleY'], function (as) {
this.autoscalePotential = as;
this.energyGraph.setAutoscalePotential$Z(as);
});

Clazz.newMeth(C$, ['setScaleToArea$Z','setScaleToArea'], function (scale) {
this.energyGraph.scaleToArea$Z(scale);
});

Clazz.newMeth(C$, ['setShowControls$Z','setShowControls'], function (sc) {
this.controlpanel.setVisible$Z(sc);
this.invalidate();
this.validate();
});

Clazz.newMeth(C$, ['setPsi$D','setPsi'], function (energy) {
this.energyGraph.setEnergy$D(energy);
this.energyGraph.calculatePsi$D(energy);
this.energyGraph.scaleData$D$Z(energy, true);
this.energyGraph.drawEnergyLine$I(this.energyGraph.pixFromY$D(energy));
});

Clazz.newMeth(C$, ['setPotential$S$D$D','setPotential'], function (str, xmin, xmax) {
this.potentialStr = str;
this.potentialFcn.setText$S(str);
this.energyGraph.setMinMaxX$D$D(xmin, xmax);
this.energyGraph.updated = true;
this.energyGraph.setTitle$S(null);
this.energyGraph.purgeHashtable();
this.energyGraph.setPotential$S(str);
this.energyGraph.updated = false;
});

Clazz.newMeth(C$, ['setShowPotential$Z','setShowPotential'], function (sp) {
this.potentialpanel.setVisible$Z(sp);
this.invalidate();
this.validate();
});

Clazz.newMeth(C$, ['setMinMaxX$D$D','setMinMaxX'], function (xmin, xmax) {
var pot = this.energyGraph.potFunc.getFunctionString();
this.setPotential$S$D$D(pot, xmin, xmax);
});

Clazz.newMeth(C$, ['setMinMaxY$D$D','setMinMaxY'], function (ymin, ymax) {
this.energyGraph.setMinMaxY$D$D(ymin, ymax);
});

Clazz.newMeth(C$, ['findEnergyLevels$I$I','findEnergyLevels'], function (lowest, highest) {
this.energyGraph.calculateLevels$I$I(lowest, highest);
});

Clazz.newMeth(C$, ['findEnergyLevel$I','findEnergyLevel'], function (n) {
this.elevel.setValue$I(n);
this.energyGraph.updated = false;
this.energyGraph.resetE = true;
var en = this.energyGraph.findElevel$I$Z(n, true);
if (this.noscale) {
} else {
this.energyGraph.scaleData$D$Z(en, true);
}this.evalue.setValue$D(en);
});

Clazz.newMeth(C$, 'frewind_mouseReleased$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'rewind_mouseReleased$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'forward_mouseReleased$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'fforward_mouseReleased$java_awt_event_MouseEvent', function (e) {
});

Clazz.newMeth(C$, 'evalue_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.setPsi$D(this.evalue.getValue());
});
})();
//Created 2018-02-08 13:28:04
