(function(){var P$=Clazz.newPackage("doppler"),p$1={},I$=[[0,'Boolean','doppler.DopplerFrame','java.awt.BorderLayout','java.awt.Panel','java.awt.Color','java.awt.CheckboxGroup','java.awt.GridLayout','java.awt.Checkbox','doppler.VarScrollBar','edu.davidson.graphics.EtchedBorder','doppler.SizedButton','doppler.DopplerCanvas','javax.swing.Timer','Thread','java.net.URL','java.util.Vector','java.awt.Font','doppler.DopplerWaveCrest','edu.davidson.display.Format']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Doppler", null, 'edu.davidson.tools.SApplet', ['Runnable', 'java.awt.event.ActionListener']);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.label_speed=null;
this.label_classical=null;
this.label_relativistic=null;
this.label_time=null;
this.label_position=null;
this.label_caption=null;
this.button_start=null;
this.button_stop=null;
this.m_Doppler=null;
this.speedBar=null;
this.dc=null;
this.sleepTime=0;
this.cCheck=null;
this.rCheck=null;
this.runBtn=null;
this.runOnStart=false;
this.m_fStandAlone=false;
this.m_speed=0;
this.m_fps=0;
this.m_relativistic=false;
this.m_helpFile=null;
this.m_showControls=false;
this.m_showButtons=false;
this.PARAM_speed=null;
this.PARAM_fps=null;
this.PARAM_relativistic=null;
this.PARAM_helpFile=null;
this.PARAM_showControls=null;
this.PARAM_showButtons=null;
this.keepRunning=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.label_speed="speed = ";
this.label_classical="classical";
this.label_relativistic="relativistic";
this.label_time="time: ";
this.label_position="source x: ";
this.label_caption="Doppler";
this.button_start="Run ";
this.button_stop="Stop";
this.m_Doppler=null;
this.sleepTime=50;
this.runOnStart=false;
this.m_fStandAlone=false;
this.m_speed=0.5;
this.m_fps=20;
this.m_relativistic=false;
this.m_helpFile=null;
this.m_showControls=true;
this.m_showButtons=true;
this.PARAM_speed="Speed";
this.PARAM_fps="FPS";
this.PARAM_relativistic="Relativistic";
this.PARAM_helpFile="helpFile";
this.PARAM_showControls="ShowControls";
this.PARAM_showButtons="ShowButtons";
this.keepRunning=true;
}, 1);

Clazz.newMeth(C$, 'GetParameter$S$SA', function (strName, args) {
if (args == null ) {
return this.getParameter$S(strName);
}var i;
var strArg=strName + "=";
var strValue=null;
var nLength=strArg.length$();
try {
for (i=0; i < args.length; i++) {
var strParam=args[i].substring$I$I(0, nLength);
if (strArg.equalsIgnoreCase$S(strParam)) {
strValue=args[i].substring$I(nLength);
if (strValue.startsWith$S("\"")) {
strValue=strValue.substring$I(1);
if (strValue.endsWith$S("\"")) {
strValue=strValue.substring$I$I(0, strValue.length$() - 1);
}}break;
}}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
return strValue;
});

Clazz.newMeth(C$, 'GetParameters$SA', function (args) {
var param;
param=this.GetParameter$S$SA("Speed", args);
if (param != null ) {
this.m_speed=Double.valueOf$S(param).doubleValue$();
}param=this.GetParameter$S$SA("FPS", args);
if (param != null ) {
this.m_fps=Integer.parseInt$S(param);
}param=this.GetParameter$S$SA("Relativistic", args);
if (param != null ) {
this.m_relativistic=Clazz.load('Boolean').valueOf$S(param).booleanValue$();
}param=this.GetParameter$S$SA("ShowControls", args);
if (param != null ) {
this.m_showControls=$I$(1).valueOf$S(param).booleanValue$();
}param=this.GetParameter$S$SA("ShowButtons", args);
if (param != null ) {
this.m_showButtons=$I$(1).valueOf$S(param).booleanValue$();
}param=this.GetParameter$S$SA("helpFile", args);
if (param != null ) {
this.m_helpFile=param;
}});

Clazz.newMeth(C$, 'main$SA', function (args) {
var frame=Clazz.new_(Clazz.load('doppler.DopplerFrame').c$$S,["Doppler"]);
frame.show$();
frame.hide$();
frame.resize$I$I(frame.insets$().left + frame.insets$().right + 320 , frame.insets$().top + frame.insets$().bottom + 340 );
var applet_Doppler=Clazz.new_(C$);
frame.add$S$java_awt_Component("Center", applet_Doppler);
applet_Doppler.m_fStandAlone=true;
applet_Doppler.GetParameters$SA(args);
applet_Doppler.init$();
applet_Doppler.start$();
frame.show$();
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'], function () {
return "Name: Doppler ver 1.2\r\nAuthor: Wolfgang Christian\r\nemail: wochristian@davidson.edu\r\n";
});

Clazz.newMeth(C$, ['getParameterInfo$','getParameterInfo'], function () {
var info=Clazz.array(String, -2, [Clazz.array(String, -1, ["Speed", "double", "Source speed"]), Clazz.array(String, -1, ["FPS", "int", "Frames per second"]), Clazz.array(String, -1, ["Relativistic", "boolean", "Relativistic effects."]), Clazz.array(String, -1, ["ShowControls", "boolean", "Show controls and buttons."]), Clazz.array(String, -1, ["ShowButtons", "boolean", "Show classical/relativistic options."]), Clazz.array(String, -1, ["helpFile", "String", "Applet help file URL."])]);
return info;
});

Clazz.newMeth(C$, ['init$','init'], function () {
this.initResources$S(null);
this.runOnStart=false;
if (!this.m_fStandAlone) {
this.GetParameters$SA(null);
}{
this.resize$I$I(320, 340);
}var f=1;

this.f = 5;
this.sleepTime=(1000/f / this.m_fps |0);
this.setLayout$java_awt_LayoutManager(Clazz.new_(Clazz.load('java.awt.BorderLayout')));
var p1=Clazz.new_(Clazz.load('java.awt.Panel'));
p1.setBackground$java_awt_Color(Clazz.load('java.awt.Color').lightGray);
p1.setLayout$java_awt_LayoutManager(Clazz.new_($I$(3)));
var g=Clazz.new_(Clazz.load('java.awt.CheckboxGroup'));
var p3=Clazz.new_($I$(4));
p3.setBackground$java_awt_Color($I$(5).lightGray);
p3.setLayout$java_awt_LayoutManager(Clazz.new_(Clazz.load('java.awt.GridLayout').c$$I$I$I$I,[1, 2, 4, 4]));
p3.add$java_awt_Component(this.cCheck=Clazz.new_(Clazz.load('java.awt.Checkbox').c$$S$java_awt_CheckboxGroup$Z,[this.label_classical, g, true]));
p3.add$java_awt_Component(this.rCheck=Clazz.new_($I$(8).c$$S$java_awt_CheckboxGroup$Z,[this.label_relativistic, g, false]));
if (this.m_showButtons) {
p1.add$S$java_awt_Component("North", p3);
}if (this.m_relativistic) {
if (this.m_speed > 0.99 ) {
this.m_speed=0.99;
}this.speedBar=Clazz.new_(Clazz.load('doppler.VarScrollBar').c$$S$D$D$D,[this.label_speed, this.m_speed, 0, 0.99]);
} else {
if (this.m_speed > 2.0 ) {
this.m_speed=2.0;
}this.speedBar=Clazz.new_($I$(9).c$$S$D$D$D,[this.label_speed, this.m_speed, 0, 2.0]);
}p1.add$S$java_awt_Component("Center", Clazz.new_(Clazz.load('edu.davidson.graphics.EtchedBorder').c$$java_awt_Component,[this.speedBar]));
p1.add$S$java_awt_Component("West", this.runBtn=Clazz.new_(Clazz.load('doppler.SizedButton').c$$S,[this.button_start]));
if (this.m_showControls) {
this.add$S$java_awt_Component("South", p1);
}this.dc=Clazz.new_(Clazz.load('doppler.DopplerCanvas').c$$doppler_Doppler,[this]);
this.dc.setBackground$java_awt_Color($I$(5).white);
this.add$S$java_awt_Component("Center", this.dc);
this.dc.setSpeed$D$D(this.m_speed, 0);
this.dc.setRelativistic$Z(this.m_relativistic);
this.invalidate$();
});

Clazz.newMeth(C$, 'setResources$', function () {
this.label_caption=this.localProperties.getProperty$S$S("label.caption", this.label_caption);
this.label_speed=this.localProperties.getProperty$S$S("label.speed", this.label_speed);
this.label_classical=this.localProperties.getProperty$S$S("label.classical", this.label_classical);
this.label_relativistic=this.localProperties.getProperty$S$S("label.relativistic", this.label_relativistic);
this.label_time=this.localProperties.getProperty$S$S("label.time", this.label_time);
this.label_position=this.localProperties.getProperty$S$S("label.position", this.label_position);
this.button_start=this.localProperties.getProperty$S$S("button.start", this.button_start);
this.button_stop=this.localProperties.getProperty$S$S("button.stop", this.button_stop);
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (this.m_Doppler != null ) {
this.m_Doppler.stop$();
this.m_Doppler=null;
}C$.superclazz.prototype.destroy$.apply(this, []);
});

Clazz.newMeth(C$, ['reset$','reset'], function () {
this.dc.reset$();
this.dc.repaint$();
});

Clazz.newMeth(C$, ['getAppletCount$','getAppletCount'], function () {
if (this.firstTime) {
return 0;
} else {
return C$.superclazz.prototype.getAppletCount$.apply(this, []);
}});

Clazz.newMeth(C$, ['start$','start'], function () {
C$.superclazz.prototype.start$.apply(this, []);
if (this.firstTime) {
this.firstTime=false;
}this.setRunningID$O(this);
this.keepRunning=true;
if (this.m_Doppler == null ) {
this.m_Doppler=Clazz.new_(Clazz.load('javax.swing.Timer').c$$I$java_awt_event_ActionListener,[this.sleepTime, this]);
this.m_Doppler.setRepeats$Z(true);
this.m_Doppler.start$();
}});

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (e) {
if (this.runOnStart && this.keepRunning && (this.getRunningID$() === this )  ) {
this.m_Doppler.setDelay$I(this.sleepTime);
this.dc.incTime$D(this.m_speed);
return;
}this.stop$();
this.m_Doppler=null;
});

Clazz.newMeth(C$, ['stop$','stop'], function () {
if (this.m_Doppler != null ) {
this.m_Doppler.stop$();
this.m_Doppler=null;
}C$.superclazz.prototype.stop$.apply(this, []);
});

Clazz.newMeth(C$, ['forward$','forward'], function () {
this.runOnStart=true;
this.runBtn.setLabel$S(this.button_stop);
this.start$();
});

Clazz.newMeth(C$, 'pausingClock$', function () {
this.pause$();
});

Clazz.newMeth(C$, ['pause$','pause'], function () {
this.runOnStart=false;
this.runBtn.setLabel$S(this.button_start);
this.stop$();
});

Clazz.newMeth(C$, ['step$','step'], function () {
if (this.m_Doppler == null ) {
this.dc.incTime$D(this.m_speed);
}});

Clazz.newMeth(C$, ['run$','run'], function () {
var keepRunning=true;
while (this.runOnStart && keepRunning && (this.getRunningID$() === this )  ){
try {
this.dc.incTime$D(this.m_speed);
Clazz.load('Thread').sleep$J(this.sleepTime);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
this.stop$();
} else {
throw e;
}
}
}
this.m_Doppler=null;
});

Clazz.newMeth(C$, ['handleEvent$java_awt_Event','handleEvent'], function (evt) {
if (evt.target.equals$O(this.speedBar)) {
this.m_speed=this.speedBar.getValue$();
this.dc.setSpeed$D$D(this.m_speed, 0);
return true;
} else {
return C$.superclazz.prototype.handleEvent$java_awt_Event.apply(this, [evt]);
}});

Clazz.newMeth(C$, ['mouseDown$java_awt_Event$I$I','mouseDown'], function (evt, x, y) {
if (((evt.modifiers & 4) != 0) || ((evt.modifiers & 8) != 0) ) {
var mfile=this.m_helpFile;
if (mfile != null ) {
try {
var textURL=Clazz.new_(Clazz.load('java.net.URL').c$$java_net_URL$S,[this.getDocumentBase$(), mfile]);
this.getAppletContext$().showDocument$java_net_URL$S(textURL, "_blank");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("Failed to load help file!");
} else {
throw e;
}
}
}return true;
}return false;
});

Clazz.newMeth(C$, ['action$java_awt_Event$O','action'], function (ev, arg) {
if (ev.target.equals$O(this.runBtn)) {
if (this.runOnStart) {
this.runOnStart=false;
this.runBtn.setLabel$S(this.button_stop);
this.pause$();
} else {
this.runOnStart=false;
this.runBtn.setLabel$S(this.button_start);
this.forward$();
}return true;
} else if (ev.target.equals$O(this.rCheck)) {
this.m_relativistic=true;
if (this.m_speed > 1.0 ) {
this.m_speed=0.99;
}this.speedBar.setMinMax$D$D(0, 0.99);
this.speedBar.setValue$D(this.m_speed);
this.dc.setSpeed$D$D(this.m_speed, 0);
this.dc.setRelativistic$Z(this.m_relativistic);
return true;
} else if (ev.target.equals$O(this.cCheck)) {
this.m_relativistic=false;
this.speedBar.setMinMax$D$D(0, 2.0);
this.speedBar.setValue$D(this.m_speed);
this.dc.setRelativistic$Z(this.m_relativistic);
return true;
}return false;
});

Clazz.newMeth(C$, ['setSpeed$D','setSpeed'], function (v) {
if (v < 0 ) {
v=0;
}if (this.m_relativistic) {
if (v > 0.99 ) {
this.m_speed=0.99;
} else {
this.m_speed=v;
}} else {
if (v > 2.0 ) {
this.m_speed=2.0;
} else {
this.m_speed=v;
}}this.speedBar.setValue$D(this.m_speed);
this.dc.setSpeed$D$D(this.m_speed, 0);
});

Clazz.newMeth(C$, ['setSourceX$D','setSourceX'], function (x) {
this.dc.setX$I((x|0));
});

Clazz.newMeth(C$, ['setClassical$','setClassical'], function () {
if (this.m_relativistic) {
this.m_relativistic=false;
this.speedBar.setMinMax$D$D(0, 2.0);
this.speedBar.setValue$D(this.m_speed);
this.dc.setRelativistic$Z(this.m_relativistic);
this.cCheck.setState$Z(true);
} else {
return;
}});

Clazz.newMeth(C$, ['setRelativistic$','setRelativistic'], function () {
if (this.m_relativistic) {
return;
} else {
this.m_relativistic=true;
if (this.m_speed > 1.0 ) {
this.m_speed=0.99;
}this.speedBar.setMinMax$D$D(0, 0.99);
this.speedBar.setValue$D(this.m_speed);
this.dc.setSpeed$D$D(this.m_speed, 0);
this.dc.setRelativistic$Z(this.m_relativistic);
this.rCheck.setState$Z(true);
}});

Clazz.newMeth(C$, ['setCaption$S','setCaption'], function (s) {
this.label_caption=s;
this.dc.repaint$();
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:18 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
