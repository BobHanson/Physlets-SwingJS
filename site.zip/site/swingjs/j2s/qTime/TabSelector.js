(function(){var P$=Clazz.newPackage("qTime"),I$=[['java.awt.Color','java.awt.BorderLayout','qTime.TabSelector','qTime.TabbedDisplayPanel','java.awt.CardLayout','java.util.Vector','java.awt.Font','java.awt.Dimension','java.awt.Insets']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TabSelector", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.hi = null;
this.lo = null;
this.$name = null;
this.chosen = 0;
this.$font = null;
this.chfont = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$name = Clazz.new_((I$[6]||$incl$(6)));
this.chosen = 0;
this.$font = Clazz.new_((I$[7]||$incl$(7)).c$$S$I$I,["timesRoman", 0, 12]);
this.chfont = Clazz.new_((I$[7]||$incl$(7)).c$$S$I$I,[this.$font.getName(), 1, 13]);
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Color$java_awt_Color', function (h, l) {
Clazz.super_(C$, this,1);
this.hi=h;
this.lo=l;
}, 1);

Clazz.newMeth(C$, 'addItem$S', function (n) {
this.$name.addElement$TE(n);
this.paint$java_awt_Graphics(this.getGraphics());
});

Clazz.newMeth(C$, 'choose$S', function (n) {
for (var i = 0; i < this.$name.size(); i++) if ((this.$name.elementAt$I(i)).equals$O(n)) {
this.chosen=i;
this.paint$java_awt_Graphics(this.getGraphics());
}
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (g == null  || this.$name.size() == 0 ) return;
g.setColor$java_awt_Color((I$[1]||$incl$(1)).lightGray);
g.fillRect$I$I$I$I(0, 0, this.getSize().width, this.getSize().height);
var tw = (this.getSize().width/this.$name.size()|0);
var th = this.getSize().height;
for (var i = 0; i < this.$name.size(); i++) {
var x = tw * i;
if (i == this.chosen) {
g.setColor$java_awt_Color(this.lo);
g.drawLine$I$I$I$I(x + tw - 3, 1, x + tw - 3, th - 1);
g.drawLine$I$I$I$I(x + tw - 4, 2, x + tw - 4, th - 1);
g.setColor$java_awt_Color(this.hi);
g.drawLine$I$I$I$I(x, 0, x, th - 1);
g.drawLine$I$I$I$I(x + 1, 0, x + 1, th - 1);
g.drawLine$I$I$I$I(x, 0, x + tw - 4, 0);
g.drawLine$I$I$I$I(x, 1, x + tw - 5, 1);
g.drawLine$I$I$I$I(x + tw - 3, th - 1, x + tw - 1, th - 1);
g.drawLine$I$I$I$I(x + tw - 3, th - 2, x + tw - 1, th - 2);
} else {
g.setColor$java_awt_Color(this.lo);
g.drawLine$I$I$I$I(x + tw - 3, 6, x + tw - 3, th - 1);
g.drawLine$I$I$I$I(x + tw - 4, 7, x + tw - 4, th - 1);
g.setColor$java_awt_Color(this.hi);
g.drawLine$I$I$I$I(x, 5, x, th - 1);
g.drawLine$I$I$I$I(x + 1, 5, x + 1, th - 1);
g.drawLine$I$I$I$I(x, 5, x + tw - 4, 5);
g.drawLine$I$I$I$I(x, 6, x + tw - 5, 6);
g.drawLine$I$I$I$I(x, th - 1, x + tw - 1, th - 1);
g.drawLine$I$I$I$I(x, th - 2, x + tw - 1, th - 2);
}g.setColor$java_awt_Color(this.lo);
if (i == this.chosen) g.setFont$java_awt_Font(this.chfont);
 else g.setFont$java_awt_Font(this.$font);
var str = this.$name.elementAt$I(i);
var textw = g.getFontMetrics().stringWidth$S(str);
var texth = g.getFontMetrics().getHeight();
if (textw < tw - 5) g.drawString$S$I$I(str, x + ((tw - textw)/2|0), ((th - texth)/2|0) + texth);
}
});

Clazz.newMeth(C$, 'mouseDown$java_awt_Event$I$I', function (evt, x, y) {
if (this.$name.size() == 0) return false;
this.chosen=(x/((this.getSize().width/this.$name.size()|0))|0);
this.paint$java_awt_Graphics(this.getGraphics());
(this.getParent()).chose$S(this.$name.elementAt$I(this.chosen));
return true;
});

Clazz.newMeth(C$, 'minimumSize', function () {
return Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[50, 25]);
});

Clazz.newMeth(C$, 'preferredSize', function () {
return this.minimumSize();
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:38
