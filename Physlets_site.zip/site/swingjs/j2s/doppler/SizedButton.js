(function(){var P$=Clazz.newPackage("doppler"),I$=[];
var C$=Clazz.newClass(P$, "SizedButton", null, 'java.awt.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.button=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S', function (str) {
Clazz.super_(C$, this,1);
this.button=Clazz.new_(Clazz.load('java.awt.Button').c$$S,[str]);
this.setLayout$java_awt_LayoutManager(Clazz.new_(Clazz.load('java.awt.BorderLayout')));
this.add$S$java_awt_Component("Center", this.button);
}, 1);

Clazz.newMeth(C$, 'insets$', function () {
var inH=((this.size$().height - 26)/2|0);
if (inH < 0) inH=0;
return Clazz.new_(Clazz.load('java.awt.Insets').c$$I$I$I$I,[inH, 2, inH, 2]);
});

Clazz.newMeth(C$, 'action$java_awt_Event$O', function (evt, arg) {
if (evt.target.equals$O(this.button)) {
evt.target=this;
return false;
} else return false;
});

Clazz.newMeth(C$, 'setLabel$S', function (label) {
this.button.setLabel$S(label);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:18 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
