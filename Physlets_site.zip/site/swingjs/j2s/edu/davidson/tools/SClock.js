(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[['java.util.Vector','edu.davidson.tools.SApplet','java.awt.event.ActionEvent','java.lang.Thread','javax.swing.Timer','edu.davidson.tools.SClock$1',['edu.davidson.tools.SClock','.Tester']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SClock", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, ['Runnable', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.clockListeners = null;
this.varStrings = null;
this.ds = null;
this.runLock = null;
this.shouldRun = false;
this.running = false;
this.time = 0;
this.delay = 0;
this.maxTime = 0;
this.minTime = 0;
this.dt = 0;
this.oneShot = false;
this.cycle = false;
this.owner = null;
this.swingTimer = null;
this.thread = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.clockListeners = Clazz.new_((I$[1]||$incl$(1)));
this.varStrings = Clazz.array(java.lang.String, -1, ["t"]);
this.ds = Clazz.array(Double.TYPE, [1, 1]);
this.runLock =  Clazz.new_();
this.shouldRun = true;
this.running = false;
this.time = 0.0;
this.delay = 100;
this.maxTime = 100;
this.minTime = 0;
this.dt = 0.1;
this.oneShot = false;
this.cycle = false;
this.owner = null;
this.thread = null;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
p$.newThread$Z$Z.apply(this, [true, true]);
try {
(I$[2]||$incl$(2)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
{

}
Clazz.new_((I$[3]||$incl$(3)).c$$O$I$S,[null, 0, null]);
p$.createSwingTimer.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet', function (owner) {
C$.c$.apply(this, []);
this.owner = owner;
}, 1);

Clazz.newMeth(C$, 'addClockListener$edu_davidson_tools_SStepable', function (cl) {
if (this.thread == null ) {
{
p$.newThread$Z$Z.apply(this, [false, true]);
}}if (this.clockListeners.contains$O(cl)) {
return;
} else {
this.clockListeners.addElement$TE(cl);
}});

Clazz.newMeth(C$, 'newThread$Z$Z', function (asDaemon, startWaiting) {
this.shouldRun = true;
this.running = !startWaiting;

return this.run();
this.thread = Clazz.new_((I$[4]||$incl$(4)).c$$Runnable,[this]);
if (asDaemon) this.thread.setDaemon$Z(true);
this.thread.start();
});

Clazz.newMeth(C$, 'removeClockListener$edu_davidson_tools_SStepable', function (cl) {
{
if (!this.clockListeners.contains$O(cl)) {
return;
}this.clockListeners.removeElement$O(cl);
}});

Clazz.newMeth(C$, 'removeAllClockListeners', function () {
{
this.clockListeners.removeAllElements();
}});

Clazz.newMeth(C$, 'doStep', function () {
if (this.running) {
this.stopClock();
return;
}var didCycle = false;
if (this.isRunning() || (this.oneShot && (this.dt > 0 ) && (this.time + 0.49 * this.dt >= this.maxTime )  ) || (this.oneShot && (this.dt < 0 ) && (this.time + 0.49 * this.dt <= this.minTime )  ) || (this.cycle && (this.dt < 0 ) && (this.time + this.dt < this.minTime )  )  ) {
return;
}if (this.cycle && (this.time >= this.maxTime ) && (this.dt > 0 )  ) {
this.time = this.minTime;
didCycle = true;
}if (this.cycle && (this.time < this.minTime ) && (this.dt < 0 )  ) {
this.time = this.maxTime;
didCycle = true;
}for (var e = this.clockListeners.elements(); e.hasMoreElements(); ) {
var clockListener = e.nextElement();
if (this.shouldRun) {
clockListener.step$D$D(this.dt, this.time);
}}
if ((this.owner != null ) && didCycle ) {
this.owner.cyclingClock();
}if ((this.owner != null ) && this.shouldRun ) {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}this.time += this.dt;
});

Clazz.newMeth(C$, 'runningStep', function () {
var didCycle = false;
if (this.cycle && (this.time + 0.49 * this.dt >= this.maxTime ) && (this.dt > 0 )  ) {
this.time = this.minTime;
didCycle = true;
}if (this.shouldRun) for (var e = this.clockListeners.elements(); e.hasMoreElements(); ) {
e.nextElement().step$D$D(this.dt, this.time);
}
if ((this.owner != null ) && this.shouldRun ) {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}this.time += this.dt;
if ((this.owner != null ) && ((I$[2]||$incl$(2)).runningID != null ) && (this.owner !== (I$[2]||$incl$(2)).runningID )  ) {
this.running = false;
this.owner.pausingClock();
}if ((this.cycle && (this.dt < 0 ) && (this.time + 0.49 * this.dt < this.minTime )  ) || (this.oneShot && (this.dt < 0 ) && (this.time + 0.49 * this.dt <= this.minTime )  ) || (this.oneShot && (this.dt > 0 ) && (this.time + 0.49 * this.dt >= this.maxTime )  )  ) {
this.running = false;
this.owner.stoppingClock();
}if ((this.owner != null ) && didCycle ) {
this.owner.cyclingClock();
}});

Clazz.newMeth(C$, 'getTime', function () {
return this.time;
});

Clazz.newMeth(C$, 'getMinTime', function () {
return this.minTime;
});

Clazz.newMeth(C$, 'getMaxTime', function () {
return this.maxTime;
});

Clazz.newMeth(C$, 'setTime$D', function (t) {
var oldRunning = this.running;
this.running = false;
{
this.time = t;
for (var e = this.clockListeners.elements(); e.hasMoreElements(); ) {
e.nextElement().step$D$D(0, this.time);
}
}if (oldRunning) {
this.startClock();
} else {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}});

Clazz.newMeth(C$, 'getDt', function () {
return this.dt;
});

Clazz.newMeth(C$, 'setDt$D', function (newDt) {
var oldRunning = this.running;
this.running = false;
{
this.dt = newDt;
}if (oldRunning) {
this.startClock();
}});

Clazz.newMeth(C$, 'getTimeStep', function () {
return this.getDt();
});

Clazz.newMeth(C$, 'setTimeStep$D', function (newDt) {
this.setDt$D(newDt);
});

Clazz.newMeth(C$, 'setContinuous', function () {
this.cycle = false;
this.oneShot = false;
});

Clazz.newMeth(C$, 'setCycle$D$D', function (min, max) {
var oldRunning = this.running;
var oldTime = this.time;
this.running = false;
{
this.minTime = Math.min(min, max);
this.maxTime = Math.max(min, max);
this.time = Math.max(this.time, this.minTime);
this.time = Math.min(this.time, this.maxTime);
this.oneShot = false;
this.cycle = true;
}if (oldRunning) {
this.startClock();
} else if (oldTime != this.time ) {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}});

Clazz.newMeth(C$, 'setOneShot$D$D', function (min, max) {
var oldRunning = this.running;
var oldTime = this.time;
this.running = false;
{
this.minTime = Math.min(min, max);
this.maxTime = Math.max(min, max);
this.time = Math.max(this.time, this.minTime);
this.time = Math.min(this.time, this.maxTime);
this.oneShot = true;
this.cycle = false;
}if (oldRunning) {
this.startClock();
} else if (oldTime != this.time ) {
if (this.owner.destroyed) return;
this.owner.updateDataConnection$I(this.hashCode());
}});

Clazz.newMeth(C$, 'startClock', function () {
if (this.owner != null ) {
(I$[2]||$incl$(2)).runningID = this.owner;
}if (this.running && (this.thread != null ) ) {
return;
}if (this.oneShot && (this.dt > 0 ) && (this.time + 0.49 * this.dt >= this.maxTime )  ) {
this.running = false;
this.owner.stoppingClock();
return;
}if ((this.oneShot || this.cycle ) && (this.dt < 0 ) && (this.time + 0.49 * this.dt <= this.minTime )  ) {
this.running = false;
this.owner.stoppingClock();
return;
}if (this.thread != null ) {

this.thread.stop(); this.thread = null;
}if (this.thread == null ) {
p$.newThread$Z$Z.apply(this, [false, false]);
} else {
{
this.running = true;
this.runLock.notifyAll();
}}});

Clazz.newMeth(C$, 'panicStopClock', function () {
this.shouldRun = false;
if (this.swingTimer == null  && this.thread == null  ) return;

this.swingTimer.stop();
return;
this.startClock();
var tempThread = this.thread;
if (tempThread != null ) {
try {
tempThread.interrupt();
tempThread.join$J(1000);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
tempThread.stop();
} else {
throw e;
}
}
}this.thread = null;
});

Clazz.newMeth(C$, 'stopClock', function () {
if (this.swingTimer != null ) this.swingTimer.stop();
this.swingTimer = null;
if (!this.running) {
return;
}this.running = false;
{
;}});

Clazz.newMeth(C$, 'getFPS', function () {
return 1000.0 / this.delay;
});

Clazz.newMeth(C$, 'setFPS$D', function (fps) {
this.delay = Math.max(0, ((1000 / fps)|0));
});

Clazz.newMeth(C$, 'isCycle', function () {
return this.cycle;
});

Clazz.newMeth(C$, 'isOneShot', function () {
return this.oneShot;
});

Clazz.newMeth(C$, 'isContinous', function () {
return !(this.oneShot || this.cycle );
});

Clazz.newMeth(C$, 'isRunning', function () {
return this.running;
});

Clazz.newMeth(C$, 'run', function () {
while (this.shouldRun){
{
while (this.running == false ){
{
return;
}
}
p$.notified.apply(this, []);
}if (!p$.doDelay.apply(this, [])) return;

break;
}
});

Clazz.newMeth(C$, 'notified', function () {
if (this.shouldRun) {
p$.runningStep.apply(this, []);
}});

Clazz.newMeth(C$, 'doDelay', function () {
if (!this.shouldRun) return true;
{

}
p$.createSwingTimer.apply(this, []);
this.swingTimer.start();
return true;
});

Clazz.newMeth(C$, 'createSwingTimer', function () {
this.swingTimer = Clazz.new_((I$[5]||$incl$(5)).c$$I$java_awt_event_ActionListener,[this.delay, ((
(function(){var C$=Clazz.newClass(P$, "SClock$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent', function (e) {
this.b$['edu.davidson.tools.SClock'].swingTimer = null;
if (this.b$['edu.davidson.tools.SClock'].thread != null ) this.b$['edu.davidson.tools.SClock'].thread.stop();
this.b$['edu.davidson.tools.SClock'].thread = null;
if (this.b$['edu.davidson.tools.SClock'].shouldRun) this.b$['edu.davidson.tools.SClock'].run();
});
})()
), Clazz.new_((I$[6]||$incl$(6)).$init$, [this, null]))]);
this.swingTimer.setRepeats$Z(false);
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.time;
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
this.owner = owner;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'main', function (args) {
var sc = Clazz.new_(C$);
var tester = Clazz.new_((I$[7]||$incl$(7)), [sc, null]);
sc.addClockListener$edu_davidson_tools_SStepable(tester);
sc.setContinuous();
sc.setDt$D(0.5);
sc.startClock();
{

}
}, 1);
;
(function(){var C$=Clazz.newClass(P$.SClock, "Tester", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SStepable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'step$D$D', function (dt, time) {
System.out.println$S("SClock.Tester.step(" + new Double(dt).toString() + "," + new Double(time).toString() + ")" );
if (time >= 5 ) {
System.out.println$S("done");
System.out.flush();
System.exit(0);
}});

Clazz.newMeth(C$);
})()
})();
//Created 2018-02-25 19:20:28
