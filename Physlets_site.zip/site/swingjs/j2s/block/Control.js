(function(){var P$=Clazz.newPackage("block"),I$=[[0,'java.awt.Button','java.awt.TextField']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Control", null, 'java.awt.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.mouseP=null;
this.anim=null;
this.cg=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$block_Animation', function (an) {
Clazz.super_(C$, this,1);
this.anim=an;
this.add$java_awt_Component(this.cg=Clazz.new_(Clazz.load('java.awt.Button').c$$S,["Show c.g."]));
this.add$java_awt_Component(this.mouseP=Clazz.new_(Clazz.load('java.awt.TextField').c$$S$I,["0 , 0", 10]));
this.add$java_awt_Component(Clazz.new_($I$(1).c$$S,["Reset"]));
}, 1);

Clazz.newMeth(C$, 'action$java_awt_Event$O', function (ev, arg) {
var label=arg;
if (Clazz.instanceOf(ev.target, "java.awt.Button")) {
if (label.equals$O("Reset")) {
this.anim.reset$Z(true);
} else if (label.equals$O("Hide c.g.")) {
this.anim.cgState$Z(false);
this.cg.setLabel$S("Show c.g.");
} else if (label.equals$O("Show c.g.")) {
this.anim.cgState$Z(true);
this.cg.setLabel$S("Hide c.g.");
}return true;
}return false;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:11 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
