(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'edu.davidson.tools.SUtil','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Bulb", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.volt=0;
this.watt=0;
this.colorR=0;
this.colorG=0;
this.colorB=0;
this.ri=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.ri=0;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$D$D$I$I$S', function (circuit, v, w, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$S.apply(this, [circuit, r, c, t]);
C$.$init$.apply(this);
this.variableImage=true;
this.setValueVisible$Z(false);
this.volt=v;
this.watt=w;
this.value=this.volt * this.volt / this.watt;
this.maxCurrentValue=this.watt / this.volt + 1.0;
this.colorB=this.colorG=this.colorR=0;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit', function (circuit) {
C$.superclazz.c$$circuitsimulator_Circuit.apply(this, [circuit]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'impedance$', function () {
return this.value;
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",v=" + Double.toString$D(this.volt) + ",w=" + Double.toString$D(this.watt) ;
});

Clazz.newMeth(C$, 'set$S', function (list) {
var ret=C$.superclazz.prototype.set$S.apply(this, [list]);
if ($I$(1).parameterExist$S$S(list, "v=")) this.volt=$I$(1).getParam$S$S(list, "v=");
if ($I$(1).parameterExist$S$S(list, "w=")) this.watt=$I$(1).getParam$S$S(list, "w=");
this.value=this.volt * this.volt / this.watt;
this.maxCurrentValue=this.watt / this.volt + 1.0;
return ret;
});

Clazz.newMeth(C$, 'paintImage$java_awt_Graphics', function (g) {
});

Clazz.newMeth(C$, 'valueStr$', function () {
return Double.toString$D(this.volt) + "V," + Double.toString$D(this.watt) + "W" ;
});

Clazz.newMeth(C$, 'repaintImage$java_awt_Graphics', function (g) {
C$.superclazz.prototype.repaintImage$java_awt_Graphics.apply(this, [g]);
var cig=(this.circuit.interGrid/2|0);
this.colorG=(this.circuit.parsed ? Math.min(255, ((255.0 * Math.abs(this.getI$() * this.volt / this.watt))|0)) : 0);
this.colorR=(this.colorG < 128) ? this.colorG * 2 : 255;
this.colorB=(this.colorG < 128) ? 0 : 2 * (this.colorG - 128);
g.setColor$java_awt_Color(Clazz.new_($I$(2).c$$I$I$I,[this.colorR, this.colorG, this.colorB]));
if (this.to.equals$O("h")) {
g.fillOval$I$I$I$I(this.$x + cig - 7, this.$y - 6, 13, 13);
g.setColor$java_awt_Color($I$(2).red);
g.drawOval$I$I$I$I(this.$x + cig - 7, this.$y - 6, 13, 13);
g.drawLine$I$I$I$I(this.$x + cig - 5, this.$y - 4, this.$x + cig + 4 , this.$y + 5);
g.drawLine$I$I$I$I(this.$x + cig + 4 , this.$y - 4, this.$x + cig - 5, this.$y + 5);
} else {
g.fillOval$I$I$I$I(this.$x - 6, this.$y + cig - 7, 13, 13);
g.setColor$java_awt_Color($I$(2).red);
g.drawOval$I$I$I$I(this.$x - 6, this.$y + cig - 7, 13, 13);
g.drawLine$I$I$I$I(this.$x - 4, this.$y + cig - 5, this.$x + 5, this.$y + cig + 4 );
g.drawLine$I$I$I$I(this.$x - 4, this.$y + cig + 4 , this.$x + 5, this.$y + cig - 5);
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
g.setColor$java_awt_Color($I$(2).red);
var cig=(this.circuit.interGrid/2|0);
if (this.to.equals$O("h")) {
g.drawLine$I$I$I$I(this.$x + 3, this.$y, this.$x + cig - 7, this.$y);
g.drawLine$I$I$I$I(this.$x + cig + 6 , this.$y, this.$x + this.circuit.interGrid - 4, this.$y);
} else {
g.drawLine$I$I$I$I(this.$x, this.$y + 3, this.$x, this.$y + cig - 7);
g.drawLine$I$I$I$I(this.$x, this.$y + cig + 6 , this.$x, this.$y + this.circuit.interGrid - 4);
}if (this.circuit.parsed && this.canvasElement ) this.repaintImage$java_awt_Graphics(g);
 else {
if (this.to.equals$O("h")) {
g.drawOval$I$I$I$I(this.$x + cig - 7, this.$y - 6, 13, 13);
g.drawLine$I$I$I$I(this.$x + cig - 5, this.$y - 4, this.$x + cig + 4 , this.$y + 5);
g.drawLine$I$I$I$I(this.$x + cig + 4 , this.$y - 4, this.$x + cig - 5, this.$y + 5);
} else {
g.drawOval$I$I$I$I(this.$x - 6, this.$y + cig - 7, 13, 13);
g.drawLine$I$I$I$I(this.$x - 4, this.$y + cig - 5, this.$x + 5, this.$y + cig + 4 );
g.drawLine$I$I$I$I(this.$x - 4, this.$y + cig + 4 , this.$x + 5, this.$y + cig - 5);
}}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:48 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
