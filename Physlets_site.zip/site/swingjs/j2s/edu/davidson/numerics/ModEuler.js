(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newClass(P$, "ModEuler", null, 'edu.davidson.numerics.SODE');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.dydx = null;
this.equations = null;
this.h = 0;
this.numEqu = 0;
this.tol = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.h = 0.01;
this.numEqu = 0;
this.tol = this.h * 1.0E-6;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'step$D$DA', function (dx, x) {
if (x.length < this.numEqu) {
this.numEqu = x.length;
this.dydx = Clazz.array(Double.TYPE, [this.numEqu]);
System.out.println$S("Warning:  Temporary arrays reset.");
}var numSteps = (Math.abs(dx / this.h)|0);
for (var i = 0; i < numSteps; i++) p$.modEulerStep$D$DA.apply(this, [this.h, x]);

if (dx - numSteps * this.h > this.tol ) {
p$.modEulerStep$D$DA.apply(this, [dx - numSteps * this.h, x]);
numSteps++;
}return numSteps;
});

Clazz.newMeth(C$, 'stepODE$D$DA', function (dx, x) {
if (x.length < this.numEqu) {
System.out.println$S("Error:  The temporary arrays are not large enough.");
return 0;
}p$.modEulerStep$D$DA.apply(this, [dx, x]);
return dx;
});

Clazz.newMeth(C$, 'modEulerStep$D$DA', function (stepSize, x) {
this.dydx = this.equations.rate$DA(x);
for (var i = 0; i < this.numEqu; i++) {
x[i] = x[i] + stepSize * this.dydx[i];
this.dydx = this.equations.rate$DA(x);
}
});

Clazz.newMeth(C$, 'setTol$D', function (t) {
this.tol = t;
});

Clazz.newMeth(C$, 'getTol', function () {
return this.tol;
});

Clazz.newMeth(C$, 'setDifferentials$edu_davidson_numerics_SDifferentiable', function (diff) {
this.equations = diff;
this.numEqu = this.equations.getNumEqu();
this.dydx = Clazz.array(Double.TYPE, [this.numEqu]);
});

Clazz.newMeth(C$, 'getH', function () {
return this.h;
});

Clazz.newMeth(C$, 'setH$D', function (h) {
this.h = h;
this.tol = h * 1.0E-6;
});

Clazz.newMeth(C$, 'setNumberOfEquations$I', function (n) {
this.numEqu = n;
this.dydx = Clazz.array(Double.TYPE, [this.numEqu]);
});
})();
//Created 2018-02-24 16:21:12
