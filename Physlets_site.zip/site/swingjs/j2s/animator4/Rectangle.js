(function(){var P$=Clazz.newPackage("animator4"),I$=[];
var C$=Clazz.newClass(P$, "Rectangle", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$I$S$S', function (o, width, height, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.s = 1;
this.w = width;
this.h = height;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-03-16 05:18:58
