(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'java.awt.Color','edu.davidson.display.Format','circuitsimulator.Circuit']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "ScopeCanvas", null, 'java.awt.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.bgColor=null;
this.gridColor=null;
this.g0=null;
this.grid=null;
this.$width=0;
this.$height=0;
this.cb=null;
this.oscilloDialog=null;
this.elementID=0;
this.ce=null;
this.format=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.bgColor=Clazz.new_($I$(1).c$$I$I$I,[77, 57, 7]);
this.gridColor=Clazz.new_($I$(1).c$$I$I$I,[162, 145, 117]);
this.$width=351;
this.$height=281;
this.format=Clazz.new_($I$(2).c$$S,["%6.4f"]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.setBackground$java_awt_Color(this.bgColor);
this.setBounds$I$I$I$I(20, 20, this.$width, this.$height);
this.setSize$I$I(0, 0);
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_CircuitBuilder$circuitsimulator_OscilloDialog', function (cirbuilder, oscdiag) {
C$.c$.apply(this, []);
this.cb=cirbuilder;
this.oscilloDialog=oscdiag;
this.elementID=this.cb.currentElement.hashCode$();
this.ce=this.cb.currentElement;
}, 1);

Clazz.newMeth(C$, 'setCircuit$circuitsimulator_CircuitBuilder$circuitsimulator_OscilloDialog', function (cirbuilder, oscdiag) {
this.cb=cirbuilder;
this.oscilloDialog=oscdiag;
this.elementID=this.cb.currentElement.hashCode$();
this.ce=this.cb.currentElement;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var Y;
Y=Clazz.array(Double.TYPE, [this.cb.numberofdt]);
Y=this.cb.getVoltage$I(this.elementID);
var int1;
var int2;
var int3;
var sign=(this.ce.direction != this.ce.vequation.direction) ? -1 : 1;
if ((this.cb.debugLevel & $I$(3).DEBUG_IO) > 0) System.out.println$S(sign + " " + this.ce.direction + " " + this.ce.vequation.direction );
g.setColor$java_awt_Color(this.gridColor);
int3=0;
int1=0;
do {
g.drawLine$I$I$I$I(0, int3, 350, int3);
int3+=35;
} while (++int1 < 9);
int2=0;
int1=0;
do {
g.drawLine$I$I$I$I(int2, 0, int2, 280);
int2+=35;
} while (++int1 < 11);
int3=7;
int1=1;
do {
g.drawLine$I$I$I$I(173, int3, 178, int3);
int3+=7;
} while (++int1 < 40);
int2=7;
int1=1;
do {
g.drawLine$I$I$I$I(int2, 138, int2, 143);
int2+=7;
} while (++int1 < 50);
var vertScale=this.$height / (8 * this.oscilloDialog.voltageScaling);
var horScale=this.$width * this.cb.dt / (10 * this.oscilloDialog.timeScaling);
var v=(this.oscilloDialog.verOffset|0);
var h=(this.oscilloDialog.horOffset|0);
var dc=0.0;
g.setColor$java_awt_Color($I$(1).yellow);
var m=1;
if (this.oscilloDialog.mode.equals$O("Ground")) {
g.drawLine$I$I$I$I(h, (this.$height/2|0) - v, h + this.$width, (this.$height/2|0) - v);
} else {
if (this.oscilloDialog.mode.equals$O("AC")) dc=this.cb.getDCLevel$I(this.elementID) * sign;
if ((this.cb.debugLevel & $I$(3).DEBUG_IO) > 0) System.out.println$S("DC Level = " + new Double(dc).toString());
for (var n=1; n < this.cb.numberofdt; n++) g.drawLine$I$I$I$I(h + (((n - 1) * horScale)|0), (this.$height/2|0) - v - (((Y[n - 1] * sign - dc) * vertScale)|0), h + ((n * horScale)|0), (this.$height/2|0) - v - (((Y[n] * sign - dc) * vertScale)|0));

while (m * this.cb.dt * this.cb.numberofdt  < 10 * this.oscilloDialog.timeScaling ){
var lastpt=Y[this.cb.numberofdt - 1] * sign - dc;
var os=m * this.cb.numberofdt;
m++;
this.cb.calculateCircuit$();
Y=this.cb.getVoltage$I(this.elementID);
if (this.oscilloDialog.mode.equals$O("AC")) dc=this.cb.getDCLevel$I(this.elementID) * sign;
g.drawLine$I$I$I$I(h + (((os - 1) * horScale)|0), (this.$height/2|0) - v - ((lastpt * vertScale)|0), h + (((os) * horScale)|0), (this.$height/2|0) - v - (((Y[0] * sign - dc) * vertScale)|0));
for (var n=1; n < this.cb.numberofdt; n++) g.drawLine$I$I$I$I(h + (((os + n - 1) * horScale)|0), (this.$height/2|0) - v - (((Y[n - 1] * sign - dc) * vertScale)|0), h + (((os + n) * horScale)|0), (this.$height/2|0) - v - (((Y[n] * sign - dc) * vertScale)|0));

}
}});

Clazz.newMeth(C$, 'getCoords$java_awt_Point', function (p) {
var vertScale=(this.$height - 1) / (8 * this.oscilloDialog.voltageScaling);
var horScale=(this.$width - 1) / (10 * this.oscilloDialog.timeScaling);
var pt=(p.x - this.oscilloDialog.horOffset) / horScale;
var pv=((this.$height/2|0) - p.y - this.oscilloDialog.verOffset) / vertScale;
return this.scaled$D$S(pt, "s") + ", " + this.scaled$D$S(pv, "V") ;
});

Clazz.newMeth(C$, 'scaled$D$S', function (v, type) {
if (Math.abs(v) < 1.0E-8 ) {
return this.format.form$D(v * 1.0E9) + " n" + type ;
} else if (Math.abs(v) < 1.0E-4 ) {
return this.format.form$D(v * 1000000.0) + " ï¿½" + type ;
} else if (Math.abs(v) < 0.1 ) {
return this.format.form$D(v * 1000.0) + " m" + type ;
} else if (Math.abs(v) < 1000.0 ) {
return this.format.form$D(v) + " " + type ;
} else if (Math.abs(v) < 1000000.0 ) {
return this.format.form$D(v * 0.001) + " k" + type ;
} else {
return this.format.form$D(v * 1.0E-6) + " M" + type ;
}});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:49 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
