(function(){var P$=Clazz.newPackage("circuit"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Capacitor", null, 'circuit.Part');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I', function (o, c, i1, j1, i2, j2) {
C$.superclazz.c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I.apply(this, [o, c, i1, j1, i2, j2]);
C$.$init$.apply(this);
this.label = "C";
this.voltRMS = 0;
this.showC = true;
this.showV = true;
this.showR = false;
this.showZ = false;
this.showL = false;
}, 1);

Clazz.newMeth(C$, 'drawLabel$java_awt_Graphics$I$I$I$I', function (g, x, y, xOff, yOff) {
if (this.label == null ) return;
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawString$S$I$I(this.label, x - 4, y + 5);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'drawSymbol$java_awt_Graphics$I$I$I$I$I', function (g, x1, y1, x2, y2, s) {
g.setColor$java_awt_Color(this.color);
var x = x2 - x1;
var y = -(y2 - y1);
var h = Math.sqrt(x * x + y * y);
if (h < 2 ) return;
var w = (h / 2.0 - 6);
var base_x1 = ((x1 + (x * w) / h)|0);
var base_y1 = ((y1 - (y * w) / h)|0);
var base_x2 = ((x2 - (x * w) / h)|0);
var base_y2 = ((y2 + (y * w) / h)|0);
g.drawLine$I$I$I$I(x1, y1, base_x1, base_y1);
g.drawLine$I$I$I$I(x2, y2, base_x2, base_y2);
w = s / 8.0;
var u = (w * x / h);
var v = -(w * y / h);
g.drawLine$I$I$I$I(((base_x1 - v)|0), ((base_y1 + u)|0), ((base_x1 + v)|0), ((base_y1 - u)|0));
g.drawLine$I$I$I$I(((base_x2 - v)|0), ((base_y2 + u)|0), ((base_x2 + v)|0), ((base_y2 - u)|0));
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:22:57
