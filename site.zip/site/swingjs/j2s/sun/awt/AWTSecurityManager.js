(function(){var P$=Clazz.newPackage("sun.awt"),I$=[];
var C$=Clazz.newClass(P$, "AWTSecurityManager", null, 'SecurityManager');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'getAppContext', function () {
return null;
});

Clazz.newMeth(C$);
})();
//Created 2018-05-24 08:47:21
