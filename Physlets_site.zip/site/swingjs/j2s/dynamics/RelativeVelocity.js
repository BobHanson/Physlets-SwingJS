(function(){var P$=Clazz.newPackage("dynamics"),I$=[[0,'java.awt.Panel','java.awt.Label','java.awt.Color','java.awt.Button','java.awt.Checkbox','javax.swing.Timer']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "RelativeVelocity", null, 'java.applet.Applet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.yOffset=0;
this.time=0;
this.ts=0;
this.area=null;
this.bgImage=null;
this.fgImage=null;
this.gb=null;
this.g=null;
this.bgColor=null;
this.names=null;
this.frameLabel=null;
this.cbShow=null;
this.cb2D=null;
this.show2D=false;
this.rts=null;
this.STR=null;
this.show=false;
this.xx=0;
this.yy=0;
this.c=null;
this.X=null;
this.V=null;
this.V4=0;
this.X4=0;
this.V5=0;
this.X5=0;
this.ID=0;
this.dx=null;
this.Y=null;
this.dv=null;
this.VYman=0;
this.running=false;
this.animThread=null;
this.startTime=0;
this.lastTime=0;
this.delay=0;
this.delta=0;
this.xmax=0;
this.yman=0;
this.rightClick=false;
this.dragging=0;
this.manMoving=false;
this.fm=null;
this.chy=0;
this.ya=0;
this.yb=0;
this.h1=0;
this.w1=0;
this.w2=0;
this.y02=0;
this.y22=0;
this.yball=0;
this.size=0;
this.size2=0;
this.dy=0;
this.dx0=0;
this.size3=0;
this.Y4=0;
this.w4=0;
this.x5max=0;
this.x4max=0;
this.manH=0;
this.dx1=0;
this.tu=0;
this.tu2=0;
this.tb=0;
this.tb0=0;
this.gravity=0;
this.gravity2=0;
this.X0=0;
this.V0=0;
this.x3=0;
this.dx4=0;
this.dv4=0;
this.dv5=0;
this.y4=0;
this.y5=0;
this.tmp=0;
this.dirty=false;
this.arrow=0;
this.Vscale=0;
this.timer=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
for (var i=0; i < this.STR.length; ++i) {
if ((this.rts=this.getParameter$S(this.STR[i])) != null ) {
this.STR[i]= String.instantialize(this.rts);
}}
for (var j=0; j < this.names.length; ++j) {
if ((this.rts=this.getParameter$S(this.names[j])) != null ) {
this.names[j]= String.instantialize(this.rts);
}}
this.setBackground$java_awt_Color(this.bgColor);
var panel=Clazz.new_(Clazz.load('java.awt.Panel'));
panel.add$java_awt_Component(Clazz.new_(Clazz.load('java.awt.Label').c$$S,[this.STR[6]]));
panel.add$java_awt_Component(this.frameLabel=Clazz.new_($I$(2).c$$S,[this.names[0]]));
this.frameLabel.setForeground$java_awt_Color(Clazz.load('java.awt.Color').blue);
panel.add$java_awt_Component(Clazz.new_(Clazz.load('java.awt.Button').c$$S,[this.STR[0]]));
panel.add$java_awt_Component(Clazz.new_($I$(4).c$$S,[this.STR[1]]));
panel.add$java_awt_Component(Clazz.new_($I$(4).c$$S,[this.STR[3]]));
panel.add$java_awt_Component(this.cbShow=Clazz.new_(Clazz.load('java.awt.Checkbox').c$$S,[this.STR[4]]));
panel.add$java_awt_Component(this.cb2D=Clazz.new_($I$(5).c$$S,[this.STR[5]]));
this.add$S$java_awt_Component("North", panel);
this.area=this.size$();
var area=this.area;
area.height-=this.yOffset;
this.reset$Z(true);
});

Clazz.newMeth(C$, ['action$java_awt_Event$O','action'], function (event, o) {
if (Clazz.instanceOf(event.target, "java.awt.Button")) {
var s=o;
if (s.equals$O(this.STR[0])) {
this.stop$();
this.reset$Z(true);
} else if (s.equals$O(this.STR[1])) {
this.start$();
this.timer.start$();
this.running=true;
} else if (s.equals$O(this.STR[3])) {
this.clear$();
}} else if (event.target === this.cbShow ) {
this.show=this.cbShow.getState$();
} else if (event.target === this.cb2D ) {
if (!(this.show2D=this.cb2D.getState$())) {
this.clear$();
}this.tb0=this.time - this.tu;
}return true;
});

Clazz.newMeth(C$, ['reset$Z','reset'], function (b) {
this.V[0]=0.0;
this.V[3]=5.0;
this.V[2]=10.0;
this.V[1]=30.0;
this.V4=10.0;
this.X4=0.0;
this.V5=5.0;
this.X5=this.w4 / 2.0;
var x=this.X;
var n=1;
var x2=this.X;
var n2=2;
var x3=this.X;
var n3=0;
var n4=0.0;
x3[0]=0.0;
x[1]=(x2[2]=0.0);
this.X[3]=(this.area.width/2|0);
this.ID=0;
this.VYman=0.0;
this.show=this.cbShow.getState$();
this.manMoving=false;
this.frameLabel.setText$S(this.names[this.ID]);
this.clear$();
if (b) {
var n5=0.0;
this.time=0.0;
this.ts=0.0;
}this.tb0=this.time - this.tu;
this.show2D=this.cb2D.getState$();
this.g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.bgImage, 0, 0, this);
this.repaint$();
});

Clazz.newMeth(C$, ['start$','start'], function () {
this.delta=100;
if (this.timer == null ) this.timer=Clazz.new_(Clazz.load('javax.swing.Timer').c$$I$java_awt_event_ActionListener,[(this.delta|0), ((P$.RelativeVelocity$1||
(function(){var C$=Clazz.newClass(P$, "RelativeVelocity$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (ae) {
this.b$['dynamics.RelativeVelocity'].run$.apply(this.b$['dynamics.RelativeVelocity'], []);
});
})()
), Clazz.new_(P$.RelativeVelocity$1.$init$, [this, null]))]);
this.timer.setRepeats$Z(true);
});

Clazz.newMeth(C$, ['stop$','stop'], function () {
this.timer.stop$();
this.running=false;
});

Clazz.newMeth(C$, ['run$','run'], function () {
if (this.running) {
this.advanced$D(this.delta / 1000.0);
}});

Clazz.newMeth(C$, 'advanced$D', function (n) {
this.yman += this.VYman * n;
this.Y[3]=this.mode$D$I(this.yman, this.area.height);
if (this.Y[3] > this.ya && this.Y[3] < this.yb ) {
if (this.ID == 3) {
this.ID=2;
}var x=this.X;
var n2=3;
x[3] += this.V[2] * n;
}this.V0=this.V[this.ID];
for (var i=0; i < this.X.length; ++i) {
var x2=this.X;
var n3=i;
x2[n3] += (this.V[i] - this.V0) * n;
}
this.X4 += (this.V4 - this.V0) * n;
this.X5 += this.V5 * n;
if (this.X5 > this.x5max ) {
this.X5=2 * this.x5max - this.X5;
this.V5 *= -1.0;
} else if (this.X5 < 0.0 ) {
this.X5=-this.X5;
this.V5 *= -1.0;
}this.time += n;
this.ts += n;
if (this.ts > 0.25 ) {
this.ts -= 0.25;
if (this.time > 100.0 ) {
this.time -= 100.0;
for (var j=0; j < this.X.length; ++j) {
this.X[j] %= this.area.width;
this.yman %= this.area.height;
}
}}this.repaint$();
});

Clazz.newMeth(C$, ['mouseDown$java_awt_Event$I$I','mouseDown'], function (event, n, n2) {
if ((n2-=this.yOffset) < 0) {
return false;
}if (event.modifiers == 4) {
this.rightClick=true;
}this.dragging=-1;
for (var i=0; i < this.X.length - 1; ++i) {
if (i != this.ID && Math.abs(n2 - this.Y[i]) < this.arrow  && Math.abs(n - this.w2 - this.dv[i] ) < this.arrow ) {
this.dragging=i;
break;
}}
if (this.dragging == -1) {
if (Math.abs(n2 - this.Y[3]) < this.arrow && Math.abs(n - this.dx[3] - this.dv[3] ) < this.arrow ) {
this.dragging=3;
} else if (Math.abs(n2 - this.Y[3] - this.VYman * this.Vscale ) < this.arrow  && Math.abs(n - this.dx[3]) < this.arrow ) {
this.dragging=4;
} else if (Math.sqrt((n - this.dv4) * (n - this.dv4) + (n2 - this.y4) * (n2 - this.y4)) < this.size ) {
this.dragging=5;
} else if (Math.sqrt((n - this.dv5) * (n - this.dv5) + (n2 - this.y5) * (n2 - this.y5)) < this.size ) {
this.dragging=6;
} else {
this.running=!this.running;
}}return true;
});

Clazz.newMeth(C$, ['mouseMove$java_awt_Event$I$I','mouseMove'], function (event, n, n2) {
if (!this.running) {
return true;
}n2-=this.yOffset;
if (n2 > this.ya && n2 < this.yb ) {
if (n2 > this.Y[1] && n2 < this.Y[1] + this.h1  && (((n-=this.dx[1]) > 0 && n < this.w1 ) || ((n-=this.w2) > 0 && n < this.w1 ) ) ) {
this.ID=1;
} else {
this.ID=2;
}} else if (n2 < this.Y[3] && n2 > this.Y[3] - this.manH  && (n-=this.dx[3] + this.size) > 0  && n < 2 * this.size2 ) {
this.ID=3;
} else {
this.ID=0;
}this.frameLabel.setForeground$java_awt_Color(this.c[this.ID]);
return true;
});

Clazz.newMeth(C$, ['mouseDrag$java_awt_Event$I$I','mouseDrag'], function (event, n, n2) {
if ((n2-=this.yOffset) < 0) {
return false;
}if (!this.running && this.dragging != -1 ) {
if (this.dragging == 5) {
this.V5=(n - this.dx4) / this.Vscale;
} else if (this.dragging == 6) {
this.V4=(n - this.dx4) / this.Vscale + this.V0 - this.V5;
} else if (this.dragging == 4) {
this.VYman=(n2 - this.Y[3]) / this.Vscale;
} else if (this.dragging == 3) {
this.V[3]=(n - this.dx[3]) / this.Vscale;
if (n2 < this.ya || n2 > this.yb ) {
var v=this.V;
var n3=3;
v[3] += this.V0;
}} else {
this.V[this.dragging]=(n - this.w2) / this.Vscale + this.V0;
}this.repaint$();
}return true;
});

Clazz.newMeth(C$, ['mouseUp$java_awt_Event$I$I','mouseUp'], function (event, n, n2) {
if ((n2-=this.yOffset) < 0) {
return false;
}if (this.rightClick) {
this.rightClick=false;
} else if (this.dragging == -1) {
this.running=!this.running;
}this.repaint$();
return true;
});

Clazz.newMeth(C$, 'clear$', function () {
if (this.g == null ) {
this.bgImage=this.createImage$I$I(this.area.width, this.area.height);
this.gb=this.bgImage.getGraphics$();
this.fgImage=this.createImage$I$I(this.area.width, this.area.height);
this.g=this.fgImage.getGraphics$();
this.fm=this.gb.getFontMetrics$();
this.chy=this.fm.getHeight$();
this.Y[1]=((this.area.height - this.h1)/3|0);
this.Y4=this.Y[1] * 2 + 30;
this.x4max=this.area.width - this.w4;
this.w2=(this.area.width/2|0);
this.x3=this.w2 - this.w1;
this.xmax=this.area.width;
this.ya=50;
this.Y[0]=this.dy - this.size;
this.Y[2]=this.Y[0] + this.ya;
this.yb=this.area.height - this.ya;
this.y02=this.area.height - this.dy - this.size ;
this.y22=this.y02 - this.ya;
this.manH=7 * this.size;
this.yball=this.Y4 - 100;
this.tu=Math.sqrt(2.0 * (this.Y4 - this.yball) / this.gravity);
this.tu2=2.0 * this.tu;
}this.Y[3]=((this.ya + this.manH)/2|0);
this.yman=this.Y[3];
this.gb.setColor$java_awt_Color(this.bgColor);
this.gb.fillRect$I$I$I$I(0, 0, this.area.width, this.area.height);
this.gb.setColor$java_awt_Color(Clazz.new_($I$(3).c$$I$I$I,[150, 220, 180]));
this.gb.fillRect$I$I$I$I(0, this.ya, this.area.width, this.yb - this.ya);
this.gb.setColor$java_awt_Color($I$(3).black);
this.gb.drawRect$I$I$I$I(0, 0, this.area.width - 1, this.area.height - 1);
this.gb.drawLine$I$I$I$I(0, this.ya, this.area.width, this.ya);
this.gb.drawLine$I$I$I$I(0, this.yb, this.area.width, this.yb);
this.gb.setColor$java_awt_Color($I$(3).white);
});

Clazz.newMeth(C$, 'd2String$D', function (n) {
var s=String.valueOf$F((((n * 100.0)|0) / 100.0));
if (s.indexOf$S(".") == -1) {
s += ".0";
}return s;
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
this.updateScreen$java_awt_Graphics(g);
});

Clazz.newMeth(C$, ['updateScreen$java_awt_Graphics','updateScreen'], function (graphics) {
this.frameLabel.setText$S(this.names[this.ID]);
this.g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.bgImage, 0, 0, this);
this.g.setColor$java_awt_Color($I$(3).black);
this.g.drawString$S$I$I(this.STR[2] + this.d2String$D(this.time), 5, this.area.height - 15);
this.X0=this.X[this.ID];
this.V0=this.V[this.ID];
this.dx[1]=this.mode$D$I(this.X[1], this.w2);
this.g.setColor$java_awt_Color(this.c[1]);
this.g.fillOval$I$I$I$I(this.xx=this.dx[1], this.Y[1], this.w1, this.h1);
this.g.fillOval$I$I$I$I(this.xx+=this.w2, this.Y[1], this.w1, this.h1);
this.xx=this.mode$D$I(this.X4, this.area.width);
if (this.show2D) {
if (this.dirty && this.xx < 2 ) {
this.clear$();
this.dirty=false;
}this.tb=(this.time - this.tb0) % this.tu2;
if (this.tb > this.tu ) {
this.tb=this.tu2 - this.tb;
} else {
this.dirty=true;
}this.yy=this.yball + ((this.gravity2 * this.tb * this.tb )|0);
this.g.setColor$java_awt_Color($I$(3).blue);
this.g.drawOval$I$I$I$I(this.xx, this.yy, this.size2, this.size2);
this.gb.drawLine$I$I$I$I(this.xx, this.yy+=this.size, this.xx, this.yy);
if (this.show) {
this.g.drawString$S$I$I(String.valueOf$I(this.Y4 - this.yy), this.xx, this.yy);
}}this.g.setColor$java_awt_Color(this.c[this.ID]);
this.g.fillRect$I$I$I$I(this.xx, this.Y4, this.w4, this.size2);
this.dx4=this.xx + (this.w4/2|0);
if (this.show) {
var g=this.g;
var string="X=" + String.valueOf$I(this.xx);
g.drawString$S$I$I(string, this.xx - this.fm.stringWidth$S(string), this.Y4);
var g2=this.g;
var string2="V=" + String.valueOf$D(this.V4 - this.V0);
g2.drawString$S$I$I(string2, this.xx - this.fm.stringWidth$S(string2), this.yy=this.Y4 + this.size2 + this.chy );
}if (this.xx > this.x4max) {
this.g.fillRect$I$I$I$I(0, this.Y4, this.xx - this.x4max, this.size2);
}this.g.setColor$java_awt_Color($I$(3).cyan);
if ((this.xx+=(this.X5|0)) > this.area.width) {
this.g.fillOval$I$I$I$I(this.xx-=this.area.width, this.Y4, this.size2, this.size2);
} else {
this.g.fillOval$I$I$I$I(this.xx, this.Y4, this.size2, this.size2);
}this.g.setColor$java_awt_Color($I$(3).black);
this.g.drawOval$I$I$I$I(this.xx, this.Y4, this.size2, this.size2);
this.g.setColor$java_awt_Color($I$(3).cyan);
if (this.show) {
this.g.drawString$S$I$I("dx=" + String.valueOf$I((this.X5|0)), this.xx, this.Y4);
this.g.drawString$S$I$I("dV=" + String.valueOf$D(this.V5), this.xx, this.yy);
this.g.setColor$java_awt_Color(this.c[this.ID]);
this.g.drawString$S$I$I(" X=" + String.valueOf$I(this.xx), this.xx, this.Y4 - this.chy);
var n;
this.g.drawString$S$I$I(" V=" + String.valueOf$D(n=this.V4 + this.V5 - this.V0), this.xx, this.yy+=this.chy);
if (!this.running) {
this.g.drawLine$I$I$I$I(this.dx4, this.yy, this.dv5=this.dx4 + ((this.Vscale * n)|0), this.y5=this.yy);
if (n > 0.0 ) {
this.tmp=-this.arrow;
} else {
this.tmp=this.arrow;
}this.g.drawLine$I$I$I$I(this.dv5, this.yy, this.xx=this.dv5 + this.tmp, this.yy - this.size);
this.g.drawLine$I$I$I$I(this.dv5, this.yy, this.xx, this.yy + this.size);
this.g.setColor$java_awt_Color($I$(3).green);
this.g.drawLine$I$I$I$I(this.dx4, this.yy-=this.chy, this.dv4=this.dx4 + ((this.Vscale * this.V5)|0), this.y4=this.yy);
if (this.V5 > 0.0 ) {
this.tmp=-this.arrow;
} else {
this.tmp=this.arrow;
}this.g.drawLine$I$I$I$I(this.dv4, this.yy, this.xx=this.dv4 + this.tmp, this.yy - this.size);
this.g.drawLine$I$I$I$I(this.dv4, this.yy, this.xx, this.yy + this.size);
}}this.dx[3]=this.mode$D$I(this.X[3], this.area.width);
this.g.setColor$java_awt_Color(this.c[3]);
this.g.drawOval$I$I$I$I(this.xx=this.dx[3], this.yy=this.Y[3] - this.manH, this.size2, this.size2);
this.g.drawLine$I$I$I$I(this.xx+=this.size, this.yy+=this.size2, this.xx - this.size2, this.yy + this.size2);
this.g.drawLine$I$I$I$I(this.xx, this.yy, this.xx + this.size2, this.yy + this.size2);
this.g.drawLine$I$I$I$I(this.xx-=this.size, this.yy+=this.size, this.xx, this.yy + this.size3);
this.g.drawLine$I$I$I$I(this.xx+=this.size2, this.yy, this.xx, this.yy + this.size3);
this.dx[0]=this.mode$D$I(this.X[0], this.dx0);
this.dx[2]=this.mode$D$I(this.X[2], this.dx0);
var n2=(this.mode$D$I(this.X[0], this.dx1)/this.dx0|0);
var n3=(this.mode$D$I(this.X[2], this.dx1)/this.dx0|0);
var n4=0;
var n5=0;
while (this.xx < this.area.width){
this.g.setColor$java_awt_Color(this.c[0]);
if (n5 % 5 == n2) {
this.g.fillOval$I$I$I$I(this.xx=n4 + this.dx[0], this.Y[0], this.size2, this.size2);
this.g.fillOval$I$I$I$I(this.xx, this.y02, this.size2, this.size2);
} else {
this.g.drawOval$I$I$I$I(this.xx=n4 + this.dx[0], this.Y[0], this.size2, this.size2);
this.g.drawOval$I$I$I$I(this.xx, this.y02, this.size2, this.size2);
}this.g.setColor$java_awt_Color(this.c[2]);
if (n5 % 5 == n3) {
this.g.fillOval$I$I$I$I(this.xx=n4 + this.dx[2], this.Y[2], this.size2, this.size2);
this.g.fillOval$I$I$I$I(this.xx, this.y22, this.size2, this.size2);
} else {
this.g.drawOval$I$I$I$I(this.xx=n4 + this.dx[2], this.Y[2], this.size2, this.size2);
this.g.drawOval$I$I$I$I(this.xx, this.y22, this.size2, this.size2);
}n4+=this.dx0;
++n5;
}
if (this.show) {
for (var i=0; i < this.X.length; ++i) {
this.g.setColor$java_awt_Color(this.c[this.ID]);
if (i == 3) {
var g3=this.g;
var xx=this.dx[3];
this.xx=xx;
var n6=this.Y[3];
var n7;
g3.drawLine$I$I$I$I(xx, n6, this.xx, n7=n6 + ((this.VYman * this.Vscale)|0));
if (this.VYman != 0.0 ) {
if (this.VYman > 0.0 ) {
this.tmp=-this.arrow;
} else {
this.tmp=this.arrow;
}this.g.drawLine$I$I$I$I(this.xx, n7, this.xx + this.arrow, n7 + this.tmp);
this.g.drawLine$I$I$I$I(this.xx, n7, this.xx - this.arrow, n7 + this.tmp);
}this.g.drawString$S$I$I(String.valueOf$D(this.VYman), this.xx, n7 + this.chy);
this.g.drawLine$I$I$I$I(this.xx, this.yy=this.Y[3], this.xx + this.dv[3], n7);
if (this.Y[3] > this.ya && this.Y[3] < this.yb ) {
this.dv[3]=((this.Vscale * (this.V[3] - this.V0 + this.V[2]))|0);
} else {
this.dv[3]=((this.Vscale * (this.V[3] - this.V0))|0);
}this.g.drawLine$I$I$I$I(this.xx, this.yy, this.xx+=this.dv[3], this.yy);
}if (i != this.ID) {
if (i != 3) {
this.dv[i]=((this.Vscale * (this.V[i] - this.V0))|0);
this.g.drawLine$I$I$I$I(this.xx=this.w2, this.yy=this.Y[i], this.xx+=this.dv[i], this.yy);
}if (this.dv[i] > 0) {
this.tmp=-this.arrow;
} else {
this.tmp=this.arrow;
}this.g.drawLine$I$I$I$I(this.xx, this.yy, this.xx + this.tmp, this.yy - this.arrow);
this.g.drawLine$I$I$I$I(this.xx, this.yy, this.xx + this.tmp, this.yy + this.arrow);
this.g.drawString$S$I$I(String.valueOf$D(this.dv[i] / this.Vscale), this.xx, this.Y[i] + this.chy);
}this.g.setColor$java_awt_Color(this.c[i]);
this.g.drawString$S$I$I(String.valueOf$I((this.X[i]|0)), 0, this.Y[i] + this.chy);
}
}graphics.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.fgImage, 0, this.yOffset, this);
});

Clazz.newMeth(C$, 'mode$D$I', function (n, n2) {
var n3=n % n2;
if (n3 < 0.0 ) {
n3 += n2;
}return (n3|0);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.yOffset=40;
this.time=0.0;
this.ts=0.0;
this.bgColor=$I$(3).lightGray;
this.names=Clazz.array(String, -1, ["Ground", "Boat", "River", "Man"]);
this.show2D=false;
this.STR=Clazz.array(String, -1, ["Reset", "Start", "Time", "Clear", "Info", "Ball", "Reference"]);
this.show=false;
this.c=Clazz.array($I$(3), -1, [$I$(3).black, $I$(3).red, $I$(3).yellow, $I$(3).blue]);
this.X=Clazz.array(Double.TYPE, [4]);
this.V=Clazz.array(Double.TYPE, [this.X.length]);
this.ID=0;
this.dx=Clazz.array(Integer.TYPE, [this.X.length]);
this.Y=Clazz.array(Integer.TYPE, [this.X.length]);
this.dv=Clazz.array(Integer.TYPE, [this.X.length]);
this.running=true;
this.startTime=0;
this.delay=50;
this.rightClick=false;
this.dragging=-1;
this.manMoving=false;
this.h1=10;
this.w1=50;
this.size=2;
this.size2=2 * this.size;
this.dy=5;
this.dx0=50;
this.size3=2 * this.size2;
this.w4=150;
this.x5max=this.w4 - this.size2;
this.dx1=5 * this.dx0;
this.gravity=9.8;
this.gravity2=this.gravity / 2.0;
this.dirty=false;
this.arrow=5;
this.Vscale=4.0;
}, 1);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:12 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
