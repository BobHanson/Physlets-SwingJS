(function(){var P$=Clazz.newPackage("sun.awt"),I$=[];
var C$=Clazz.newInterface(P$, "DisplayChangedListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-05-24 08:47:21
