(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TangentThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.rise = 0;
this.run = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.rise = 1;
this.run = 1;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$D$D', function (owner, sc, x, y, run, rise) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, x, y]);
C$.$init$.apply(this);
this.s = 1;
this.rise = rise;
this.run = run;
this.applet = owner;
this.resizable = true;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX1 = this.canvas.pixFromX$D(this.x) + this.xDisplayOff + (this.run|0) ;
var ptY1 = this.canvas.pixFromY$D(this.y) - this.yDisplayOff - (this.rise|0) ;
var ptX2 = this.canvas.pixFromX$D(this.x) + this.xDisplayOff - (this.run|0);
var ptY2 = this.canvas.pixFromY$D(this.y) - this.yDisplayOff + (this.rise|0);
g.setColor$java_awt_Color(this.color);
g.drawLine$I$I$I$I(ptX1, ptY1, ptX2, ptY2);
if (!this.noDrag) {
g.drawOval$I$I$I$I(((ptX1 + ptX2)/2|0) - 1, ((ptY1 + ptY2)/2|0) - 1, 3, 3);
}if (this.resizable) {
g.drawOval$I$I$I$I(ptX1 - 1, ptY1 - 1, 3, 3);
g.drawOval$I$I$I$I(ptX2 - 1, ptY2 - 1, 3, 3);
}var f = g.getFont();
g.setFont$java_awt_Font(this.font);
if (this.run == 0 ) g.drawString$S$I$I("m=infinite", ((ptX1 + ptX2)/2|0), ((ptY1 + ptY2)/2|0));
 else g.drawString$S$I$I("m=" + this.format.form$D(this.rise / this.run), ((ptX1 + ptX2)/2|0), ((ptY1 + ptY2)/2|0));
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX1 = this.canvas.pixFromX$D(this.x) + this.xDisplayOff + (this.run|0) ;
var ptY1 = this.canvas.pixFromY$D(this.y) - this.yDisplayOff - (this.rise|0) ;
var ptX2 = this.canvas.pixFromX$D(this.x) + this.xDisplayOff - (this.run|0);
var ptY2 = this.canvas.pixFromY$D(this.y) - this.yDisplayOff + (this.rise|0);
g.setColor$java_awt_Color(this.color);
g.drawLine$I$I$I$I(ptX1, ptY1, ptX2, ptY2);
if (!this.noDrag) {
g.drawOval$I$I$I$I(((ptX1 + ptX2)/2|0) - 1, ((ptY1 + ptY2)/2|0) - 1, 3, 3);
}if (this.resizable) {
g.drawOval$I$I$I$I(ptX1 - 1, ptY1 - 1, 3, 3);
g.drawOval$I$I$I$I(ptX2 - 1, ptY2 - 1, 3, 3);
}var f = g.getFont();
g.setFont$java_awt_Font(this.font);
if (this.run == 0 ) g.drawString$S$I$I("m=infinite", ((ptX1 + ptX2)/2|0), ((ptY1 + ptY2)/2|0));
 else g.drawString$S$I$I("m=" + this.format.form$D(this.rise / this.run), ((ptX1 + ptX2)/2|0), ((ptY1 + ptY2)/2|0));
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX1 = this.canvas.pixFromX$D(this.x) + this.xDisplayOff + (this.run|0) ;
var ptY1 = this.canvas.pixFromY$D(this.y) - this.yDisplayOff - (this.rise|0) ;
var ptX2 = this.canvas.pixFromX$D(this.x) + this.xDisplayOff - (this.run|0);
var ptY2 = this.canvas.pixFromY$D(this.y) - this.yDisplayOff + (this.rise|0);
var ptX = ((ptX1 + ptX2)/2|0);
var ptY = ((ptY1 + ptY2)/2|0);
if (!this.noDrag && (Math.abs(xPix - ptX) < 3) && (Math.abs(yPix - ptY) < 3)  ) {
this.hotSpot = 0;
return true;
}if (this.resizable && (Math.abs(xPix - ptX1) < 3) && (Math.abs(yPix - ptY1) < 3)  ) {
this.hotSpot = 1;
return true;
}if (this.resizable && (Math.abs(xPix - ptX2) < 3) && (Math.abs(yPix - ptY2) < 3)  ) {
this.hotSpot = 2;
return true;
}return false;
});

Clazz.newMeth(C$, 'dragMe$D$D', function (xnew, ynew) {
if (this.hotSpot == 0) this.setXY$D$D(xnew, ynew);
 else if (this.hotSpot == 1) {
this.run = this.canvas.pixFromX$D(xnew) - this.canvas.pixFromX$D(this.x);
this.rise = -this.canvas.pixFromY$D(ynew) + this.canvas.pixFromY$D(this.y);
} else if (this.hotSpot == 2) {
this.run = -this.canvas.pixFromX$D(xnew) + this.canvas.pixFromX$D(this.x);
this.rise = +this.canvas.pixFromY$D(ynew) - this.canvas.pixFromY$D(this.y);
}});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:37:10
