(function(){var P$=Clazz.newPackage("sun.awt.geom"),I$=[];
var C$=Clazz.newInterface(P$, "PathConsumer2D");
})();
//Created 2018-07-22 16:20:24 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
