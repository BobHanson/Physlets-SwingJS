(function(){var P$=Clazz.newPackage("eField4"),I$=[[0,'edu.davidson.graph.DataSet','java.awt.Polygon']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "TrailThing", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.dataset=null;
this.point=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.dataset=Clazz.new_($I$(1));
this.point=Clazz.array(Double.TYPE, [2]);
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$I', function (p, s) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [p, 0, 0, 0, 0]);
C$.$init$.apply(this);
this.s=s;
this.varStrings=Clazz.array(String, -1, ["t", "x", "y", "fx", "fy", "p"]);
this.ds=Clazz.array(Double.TYPE, [1, 6]);
}, 1);

Clazz.newMeth(C$, 'incTrail$D$D', function (x, y) {
this.vars[1]=x;
this.vars[2]=y;
this.point[0]=x;
this.point[1]=y;
try {
this.dataset.append$DA$I(this.point, 1);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("Error appending Data!");
} else {
throw e;
}
}
if (this.trail == null  || this.trailSize < 1 ) return;
var xpix=this.p.pixFromX$D(x);
var ypix=this.p.pixFromY$D(y);
if (this.trail.npoints < this.trailSize) {
this.trail.addPoint$I$I(xpix, ypix);
} else {
System.arraycopy$O$I$O$I$I(this.trail.xpoints, 1, this.trail.xpoints, 0, this.trailSize - 1);
System.arraycopy$O$I$O$I$I(this.trail.ypoints, 1, this.trail.ypoints, 0, this.trailSize - 1);
this.trail.xpoints[this.trailSize - 1]=xpix;
this.trail.ypoints[this.trailSize - 1]=ypix;
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color(this.color);
if (this.trailSize > 1 && this.trail.npoints > 1 ) {
g.drawPolyline$IA$IA$I(this.trail.xpoints, this.trail.ypoints, this.trail.npoints);
}});

Clazz.newMeth(C$, 'clearTrail$', function () {
if (this.trail != null  && this.trail.npoints == 0 ) {
;} else {
this.trail=Clazz.new_($I$(2));
this.dataset=Clazz.new_($I$(1));
}});

Clazz.newMeth(C$, 'getVariables$', function () {
this.ds[0][0]=this.vars[0];
this.ds[0][1]=this.vars[1];
this.ds[0][2]=this.vars[2];
this.ds[0][3]=-this.p.dudx$D$D(this.vars[1], this.vars[2]) + this.p.getPoleFx$D$D$eField4_Charge(this.vars[1], this.vars[2], null);
this.ds[0][4]=-this.p.dudy$D$D(this.vars[1], this.vars[2]) + this.p.getPoleFy$D$D$eField4_Charge(this.vars[1], this.vars[2], null);
if (this.p.parser != null ) this.ds[0][5]=this.p.parser.evaluate$D$D(this.vars[1], this.vars[2]) + this.p.getPoleU$D$D(this.vars[1], this.vars[2]);
 else this.ds[0][5]=this.p.getPoleU$D$D(this.vars[1], this.vars[2]);
return this.ds;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:52 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
