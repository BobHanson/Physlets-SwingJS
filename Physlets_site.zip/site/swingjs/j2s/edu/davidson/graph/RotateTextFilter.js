(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[];
var C$=Clazz.newClass(P$, "RotateTextFilter", null, 'java.awt.image.ImageFilter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.angle = 0;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.width = 0;
this.height = 0;
this.cos = 0;
this.sin = 0;
this.ipixels = null;
this.bpixels = null;
this.colorModel = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.angle = 0;
this.xmin = 0;
this.xmax = 0;
this.ymin = 0;
this.ymax = 0;
this.cos = 1.0;
this.sin = 0.0;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (angle) {
Clazz.super_(C$, this,1);
this.angle = (((angle % 360)/90|0)) * 90;
this.cos = Math.cos(angle * 3.141592653589793 / 180.0);
this.sin = Math.sin(angle * 3.141592653589793 / 180.0);
}, 1);

Clazz.newMeth(C$, 'setProperties$java_util_Hashtable', function (props) {
props = props.clone();
props.put$TK$TV("rotAngle",  new Integer(this.angle));
C$.superclazz.prototype.setProperties$java_util_Hashtable.apply(this, [props]);
});

Clazz.newMeth(C$, 'setDimensions$I$I', function (w, h) {
var x = Clazz.array(Integer.TYPE, -1, [0, w - 1, w - 1, 0]);
var y = Clazz.array(Integer.TYPE, -1, [0, 0, h - 1, h - 1]);
var xx;
var yy;
for (var i = 0; i < 4; i++) {
xx = (Math.round(x[i] * this.cos + y[i] * this.sin)|0);
yy = (Math.round(-x[i] * this.sin + y[i] * this.cos)|0);
this.xmin = Math.min(this.xmin, xx);
this.xmax = Math.max(this.xmax, xx);
this.ymin = Math.min(this.ymin, yy);
this.ymax = Math.max(this.ymax, yy);
}
this.width = this.xmax - this.xmin + 1;
this.height = this.ymax - this.ymin + 1;
this.consumer.setDimensions$I$I(this.width, this.height);
});

Clazz.newMeth(C$, 'setPixels$I$I$I$I$java_awt_image_ColorModel$BA$I$I', function (x, y, w, h, model, pixels, off, scan) {
var i;
var j;
var k;
var ir;
var jr;
if (this.bpixels == null ) {
this.colorModel = model;
this.bpixels = Clazz.array(Byte.TYPE, [this.width * this.height]);
}j = y;
for (var n = 0; n < h; n++, j++) {
i = x;
for (var m = 0; m < w; m++, i++) {
ir = (Math.round(i * this.cos + j * this.sin)|0) - this.xmin;
jr = (Math.round(-i * this.sin + j * this.cos)|0) - this.ymin;
k = ir + jr * this.width;
this.bpixels[k] = (pixels[(j - y) * scan + (i - x) + off]|0);
}
}
});

Clazz.newMeth(C$, 'setPixels$I$I$I$I$java_awt_image_ColorModel$IA$I$I', function (x, y, w, h, model, pixels, off, scan) {
var i;
var j;
var k;
var ir;
var jr;
if (this.ipixels == null ) {
this.colorModel = model;
this.ipixels = Clazz.array(Integer.TYPE, [this.width * this.height]);
}j = y;
for (var n = 0; n < h; n++, j++) {
i = x;
for (var m = 0; m < w; m++, i++) {
ir = (Math.round(i * this.cos + j * this.sin)|0) - this.xmin;
jr = (Math.round(-i * this.sin + j * this.cos)|0) - this.ymin;
k = ir + jr * this.width;
this.ipixels[k] = pixels[(j - y) * scan + (i - x) + off];
}
}
});

Clazz.newMeth(C$, 'imageComplete$I', function (status) {
if (status == 4 || status == 1 ) {
this.consumer.imageComplete$I(status);
this.ipixels = null;
this.bpixels = null;
return;
}if (this.bpixels != null ) {
for (var j = 0; j < this.height; j++) this.consumer.setPixels$I$I$I$I$java_awt_image_ColorModel$BA$I$I(0, j, this.width, 1, this.colorModel, this.bpixels, j * this.width, this.width);

this.consumer.imageComplete$I(status);
} else if (this.ipixels != null ) {
for (var j = 0; j < this.height; j++) this.consumer.setPixels$I$I$I$I$java_awt_image_ColorModel$IA$I$I(0, j, this.width, 1, this.colorModel, this.ipixels, j * this.width, this.width);

this.consumer.imageComplete$I(status);
} else this.consumer.imageComplete$I(4);
this.ipixels = null;
this.bpixels = null;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:07:15
