(function(){var P$=Clazz.newPackage("faraday"),I$=[];
var C$=Clazz.newInterface(P$, "Fluxable");
})();
//Created 2018-02-25 19:20:21
