(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['edu.davidson.display.SGraph','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhaseThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I', function (owner, sc, x, y, radius) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, x, y]);
C$.$init$.apply(this);
this.s = 1;
this.w = radius;
this.h = radius;
this.applet = owner;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.x) - this.w + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.w - this.yDisplayOff ;
for (var theta = 0; theta < 357; theta = theta + 4) {
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).colorFromDegrees$I(theta));
osg.fillArc$I$I$I$I$I$I(ptX, ptY, 2 * this.w + 1, 2 * this.w + 1, theta, 4);
}
osg.setColor$java_awt_Color((I$[2]||$incl$(2)).black);
osg.fillOval$I$I$I$I(ptX + this.w - 2, ptY + this.w - 2, 5, 5);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
if (!this.visible) return;
this.paint$java_awt_Graphics(osg);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < this.w + 1) && (Math.abs(yPix - ptY) < this.w + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:24
