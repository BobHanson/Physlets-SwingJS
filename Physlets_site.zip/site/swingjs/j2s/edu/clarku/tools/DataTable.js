(function(){var P$=Clazz.newPackage("edu.clarku.tools"),I$=[['edu.clarku.tools.MalformedVariableList','edu.clarku.tools.NotInCyclicMode','edu.clarku.tools.InvalidTableIndex','edu.clarku.tools.WrongNumberOfVariables','edu.clarku.tools.TooManyRows','java.lang.StringBuffer','java.io.StreamTokenizer','java.io.StringReader','java.util.Vector']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DataTable");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.names = null;
this.values = null;
this.cyclic = false;
this.numEntries = 0;
this.numVariables = 0;
this.blockSize = 0;
this.insertion = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.names = null;
this.values = null;
this.cyclic = false;
this.numEntries = 0;
this.numVariables = 0;
this.blockSize = 50;
this.insertion = 0;
}, 1);

Clazz.newMeth(C$, 'main', function (args) {
var dt = Clazz.new_(C$.c$$S,["x, y, z"]);
dt.addRowEntry$DA(Clazz.array(Double.TYPE, -1, [1.0, 2.0, 3.0]));
dt.addRowEntry$DA(Clazz.array(Double.TYPE, -1, [4.0, 5.0, 6.0]));
dt.addRowEntry$DA(Clazz.array(Double.TYPE, -1, [7.0, 8.0, 9.0]));
dt.addRowEntry$DA(Clazz.array(Double.TYPE, -1, [10.0, 11.0, 12.0]));
dt.addColumnVariable$S$DA("q", Clazz.array(Double.TYPE, -1, [1.1, 2.2, 3.3, 4.4]));
System.out.println$S("" + dt);
dt.setCyclic$Z(true);
dt.addRowEntry$DA(Clazz.array(Double.TYPE, -1, [5.0, 5.0, 5.0, 5.0]));
var sixes = Clazz.array(Double.TYPE, -1, [6.0, 6.0, 6.0, 6.0]);
dt.addRowEntry$DA(dt.getRowEntry$I(dt.getInsertionPoint()));
dt.addRowEntries$DAA(Clazz.array(Double.TYPE, -2, [sixes, sixes]));
System.out.println$S("" + dt);
}, 1);

Clazz.newMeth(C$, 'c$$S', function (variables) {
C$.$init$.apply(this);
this.names = p$.scanVariableList$S.apply(this, [variables]);
if (this.names == null ) throw Clazz.new_((I$[1]||$incl$(1)).c$$S,["String contains no identifiers."]);
this.numVariables = this.names.length;
this.values = null;
}, 1);

Clazz.newMeth(C$, 'c$$S$I', function (variables, initialRowEntries) {
C$.c$$S.apply(this, [variables]);
if (initialRowEntries < 0) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Atemp to reinitialize with negative amount of initial entries."]);
 else if (initialRowEntries > 0) this.values = Clazz.array(Double.TYPE, [initialRowEntries, this.numVariables]);
this.numEntries = initialRowEntries;
}, 1);

Clazz.newMeth(C$, 'c$$S$I$I', function (variables, initialRowEntries, blockSize) {
C$.c$$S$I.apply(this, [variables, initialRowEntries]);
this.blockSize = blockSize;
}, 1);

Clazz.newMeth(C$, 'reinitialize$S', function (variables) {
this.reinitialize$S$I(variables, 0);
});

Clazz.newMeth(C$, 'reinitialize$S$I', function (variables, initialRowEntries) {
if (initialRowEntries < 0) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Atemp to reinitialize with negative amount of initial entries."]);
this.names = p$.scanVariableList$S.apply(this, [variables]);
if (this.names == null ) throw Clazz.new_((I$[1]||$incl$(1)).c$$S,["String contains no identifiers."]);
this.numVariables = this.names.length;
this.values = null;
if (initialRowEntries > 0) p$.ensureNewEntries$I.apply(this, [initialRowEntries]);
this.numEntries = initialRowEntries;
this.setCyclic$Z(false);
});

Clazz.newMeth(C$, 'setCyclic$Z', function (becomeCyclic) {
if (becomeCyclic) this.insertion = 0;
this.cyclic = becomeCyclic;
});

Clazz.newMeth(C$, 'isCyclic', function () {
return this.cyclic;
});

Clazz.newMeth(C$, 'getInsertionPoint', function () {
if (!this.isCyclic()) throw Clazz.new_((I$[2]||$incl$(2)).c$$S,["No insertion point in non-cyclic mode."]);
return this.insertion;
});

Clazz.newMeth(C$, 'setInsertionPoint$I', function (newPoint) {
if (newPoint < 0) throw Clazz.new_((I$[3]||$incl$(3)).c$$S,["Negative entry index given."]);
 else if (newPoint >= this.numEntries) throw Clazz.new_((I$[3]||$incl$(3)).c$$S,["Table size smaller than index."]);
if (!this.isCyclic()) throw Clazz.new_((I$[2]||$incl$(2)).c$$S,["No insertion point in non-cyclic mode."]);
this.insertion = newPoint;
});

Clazz.newMeth(C$, 'setBlockSize$I', function (newSize) {
if (newSize < 1) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Non-positive block size!"]);
this.blockSize = newSize;
});

Clazz.newMeth(C$, 'getBlockSize', function () {
return this.blockSize;
});

Clazz.newMeth(C$, 'getNumColumnVariables', function () {
return this.numVariables;
});

Clazz.newMeth(C$, 'getNumRowEntries', function () {
return this.numEntries;
});

Clazz.newMeth(C$, 'isEmpty', function () {
return this.numEntries == 0;
});

Clazz.newMeth(C$, 'setRowEntry$I$DA', function (entry, ds) {
if (ds.length != this.numVariables) throw Clazz.new_((I$[4]||$incl$(4)).c$$S,["Entry length does not match the number of columns."]);
entry = p$.checkEntryIndex$I.apply(this, [entry]);
System.arraycopy(ds, 0, this.values[entry], 0, ds.length);
});

Clazz.newMeth(C$, 'getRowEntry$I', function (entry) {
entry = p$.checkEntryIndex$I.apply(this, [entry]);
var result = Clazz.array(Double.TYPE, [this.numVariables]);
System.arraycopy(this.values[entry], 0, result, 0, this.numVariables);
return result;
});

Clazz.newMeth(C$, 'addEmptyRowEntry', function () {
p$.ensureNewEntries$I.apply(this, [1]);
return this.numEntries++;
});

Clazz.newMeth(C$, 'addEmptyRowEntries$I', function (n) {
if (n < 1) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["Cannot add " + n + " empty rows." ]);
p$.ensureNewEntries$I.apply(this, [n]);
this.numEntries = this.numEntries+(n);
});

Clazz.newMeth(C$, 'addRowEntry$DA', function (ds) {
var dest;
if (this.isCyclic()) {
dest = this.insertion++;
if (this.insertion >= this.numEntries) this.insertion = 0;
} else {
p$.ensureNewEntries$I.apply(this, [1]);
dest = this.numEntries++;
}this.setRowEntry$I$DA(dest, ds);
return dest;
});

Clazz.newMeth(C$, 'addRowEntries$DAA', function (dds) {
if (dds != null  && dds.length > 0 ) {
if (!this.isCyclic()) p$.ensureNewEntries$I.apply(this, [dds.length]);
for (var i = 0; i < dds.length; i++) this.addRowEntry$DA(dds[i]);

}});

Clazz.newMeth(C$, 'addColumnVariable$S$DA', function (name, ds) {
var strings = p$.scanVariableList$S.apply(this, [name]);
if (strings == null ) throw Clazz.new_((I$[1]||$incl$(1)).c$$S,["String contains no valid identifiers."]);
if (strings.length != 1) throw Clazz.new_((I$[1]||$incl$(1)).c$$S,["Too many identifiers specified."]);
if (ds.length > this.numEntries) throw Clazz.new_((I$[5]||$incl$(5)));
for (var i = 0; i < this.numEntries; i++) {
var newEntry = Clazz.array(Double.TYPE, [this.numVariables + 1]);
System.arraycopy(this.values[i], 0, newEntry, 0, this.numVariables);
newEntry[this.numVariables] = (i >= ds.length) ? 0.0 : ds[i];
this.values[i] = newEntry;
}
this.numVariables++;
var newNames = Clazz.array(java.lang.String, [this.names.length + 1]);
System.arraycopy(this.names, 0, newNames, 0, this.names.length);
newNames[newNames.length - 1] = strings[0];
this.names = newNames;
});

Clazz.newMeth(C$, 'getColumn$I', function (n) {
if (n < 0 || n >= this.getNumColumnVariables() ) throw Clazz.new_((I$[3]||$incl$(3)).c$$S,["Column " + n + " does not exist." ]);
var result = Clazz.array(Double.TYPE, [this.numEntries]);
for (var i = 0; i < this.numEntries; i++) result[i] = this.values[i][n];

return result;
});

Clazz.newMeth(C$, 'getRowEntries', function () {
return this.values;
});

Clazz.newMeth(C$, 'getColumnIndex$S', function (variable) {
for (var i = 0; i < this.names.length; i++) if (variable.equals$O(this.names[i])) return i;

throw Clazz.new_((I$[3]||$incl$(3)).c$$S,["No column is named \'" + variable + "\'." ]);
});

Clazz.newMeth(C$, 'contains$S', function (variable) {
for (var i = 0; i < this.names.length; i++) if (variable.equals$O(this.names[i])) return true;

return false;
});

Clazz.newMeth(C$, 'getColumnName$I', function (i) {
if (i >= this.numVariables) throw Clazz.new_((I$[3]||$incl$(3)).c$$S,["Column does not exist."]);
if (i < 0) throw Clazz.new_((I$[3]||$incl$(3)).c$$S,["Negative column index given."]);
return this.names[i];
});

Clazz.newMeth(C$, 'getColumnNames', function () {
return this.names;
});

Clazz.newMeth(C$, 'get$I$I', function (i, j) {
p$.checkDatum$I$I.apply(this, [i, j]);
return this.values[i][j];
});

Clazz.newMeth(C$, 'set$I$I$D', function (i, j, d) {
p$.checkDatum$I$I.apply(this, [i, j]);
this.values[i][j] = d;
});

Clazz.newMeth(C$, 'increment$I$I$D', function (i, j, d) {
p$.checkDatum$I$I.apply(this, [i, j]);
this.values[i][j] += d;
});

Clazz.newMeth(C$, 'toString', function () {
var buff = Clazz.new_((I$[6]||$incl$(6)));
for (var i = 0; i < this.names.length; i++) {
buff.append$S("\u0009");
buff.append$S(this.names[i]);
}
buff.append$S("\u000a");
for (var r = 0; r < this.numEntries; r++) {
buff.append$S(r + ": ");
for (var c = 0; c < this.numVariables; c++) {
buff.append$S("\u0009");
buff.append$D(this.values[r][c]);
}
buff.append$S("\u000a");
}
return buff.toString();
});

Clazz.newMeth(C$, 'checkEntryIndex$I', function (i) {
var result = i;
if (i < 0) throw Clazz.new_((I$[3]||$incl$(3)).c$$S,["Negative entry index given."]);
if (this.isEmpty()) throw Clazz.new_((I$[3]||$incl$(3)).c$$S,["Table is empty, cannot set entry."]);
if (i >= this.numEntries) if (this.isCyclic()) result = i % this.numEntries;
 else throw Clazz.new_((I$[3]||$incl$(3)).c$$S,["Entry index too large."]);
return result;
});

Clazz.newMeth(C$, 'checkDatum$I$I', function (i, j) {
if (i > this.numEntries || i < 0 ) throw Clazz.new_(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["Row Entry " + i + " does not exist." ]);
if (j > this.numVariables || j < 0 ) throw Clazz.new_(Clazz.load('java.lang.IndexOutOfBoundsException').c$$S,["Column Variable " + j + " does not exist." ]);
});

Clazz.newMeth(C$, 'ensureNewEntries$I', function (n) {
if (this.values == null ) this.values = Clazz.array(Double.TYPE, [n, this.numVariables]);
 else if (n > this.values.length - this.numEntries) {
var newSize = this.values.length + Math.max(n, this.blockSize);
var newValues = Clazz.array(Double.TYPE, [newSize, null]);
System.arraycopy(this.values, 0, newValues, 0, this.numEntries);
this.values = newValues;
for (var i = this.numEntries; i < newSize; i++) this.values[i] = Clazz.array(Double.TYPE, [this.numVariables]);

}});

Clazz.newMeth(C$, 'scanVariableList$S', function (variables) {
var st = Clazz.new_((I$[7]||$incl$(7)).c$$java_io_Reader,[Clazz.new_((I$[8]||$incl$(8)).c$$S,[variables])]);
var list = Clazz.new_((I$[9]||$incl$(9)));
try {
var token = st.nextToken();
while (token != -1){
if (token == -3) list.addElement$TE(st.sval);
token = st.nextToken();
}
} catch (ioe) {
if (Clazz.exceptionOf(ioe, "java.io.IOException")){
} else {
throw ioe;
}
}
if (list.isEmpty()) return null;
var result = Clazz.array(java.lang.String, [list.size()]);
for (var i = 0; i < list.size(); i++) result[i] = list.elementAt$I(i);

return result;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:07:12
