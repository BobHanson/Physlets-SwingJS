(function(){var P$=Clazz.newPackage("eField4"),I$=[];
var C$=Clazz.newClass(P$, "ShapeThing", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.horz = null;
this.vert = null;
this.horz2 = null;
this.vert2 = null;
this.num = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$I$IA$IA$D$D', function (o, n, h, v, x, y) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [o, x, y, 0.0, 0.0]);
C$.$init$.apply(this);
this.s = 1;
this.horz = Clazz.array(Integer.TYPE, [n]);
this.vert = Clazz.array(Integer.TYPE, [n]);
this.horz2 = Clazz.array(Integer.TYPE, [n]);
this.vert2 = Clazz.array(Integer.TYPE, [n]);
this.num = n;
for (var i = 0; i < n; i++) {
this.horz[i] = h[i];
this.vert[i] = -v[i];
}
}, 1);

Clazz.newMeth(C$, 'getHorz$I', function (off) {
for (var i = 0; i < this.num; i++) {
this.horz2[i] = this.horz[i] + off;
}
return this.horz2;
});

Clazz.newMeth(C$, 'getVert$I', function (off) {
for (var i = 0; i < this.num; i++) {
this.vert2[i] = this.vert[i] + off;
}
return this.vert2;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.hideThing) return;
var ptX = Math.round(this.p.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.p.pixFromY$D(this.vars[2])) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.fillPolygon$IA$IA$I(this.getHorz$I(ptX), this.getVert$I(ptY), this.num);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:20
