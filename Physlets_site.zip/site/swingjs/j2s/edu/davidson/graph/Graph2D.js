(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['java.util.Vector','java.awt.Color','java.awt.Rectangle','edu.davidson.graph.DataSet','edu.davidson.graph.Axis','edu.davidson.graph.LoadMessage','java.awt.Font','java.awt.Dimension']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Graph2D", null, 'a2s.Canvas');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.showAxis = false;
this.DefaultBackground = null;
this.axis = null;
this.dataset = null;
this.markers = null;
this.load_thread = null;
this.DataBackground = null;
this.loadingData = 0;
this.borderTop = 0;
this.borderBottom = 0;
this.borderLeft = 0;
this.borderRight = 0;
this.frame = false;
this.framecolor = null;
this.drawgrid = false;
this.gridcolor = null;
this.drawzero = false;
this.zerocolor = null;
this.datarect = null;
this.clearAll = false;
this.$paintAll = false;
this.square = false;
this.lastText = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.showAxis = true;
this.DefaultBackground = null;
this.axis = Clazz.new_((I$[1]||$incl$(1)).c$$I,[4]);
this.dataset = Clazz.new_((I$[1]||$incl$(1)).c$$I,[10]);
this.markers = null;
this.load_thread = null;
this.DataBackground = null;
this.loadingData = 0;
this.borderTop = 20;
this.borderBottom = 20;
this.borderLeft = 20;
this.borderRight = 20;
this.frame = true;
this.drawgrid = true;
this.gridcolor = (I$[2]||$incl$(2)).pink;
this.drawzero = true;
this.zerocolor = (I$[2]||$incl$(2)).orange;
this.datarect = Clazz.new_((I$[3]||$incl$(3)));
this.clearAll = true;
this.$paintAll = true;
this.square = false;
this.lastText = null;
}, 1);

Clazz.newMeth(C$, 'isShowAxis', function () {
return this.showAxis;
});

Clazz.newMeth(C$, 'setShowAxis$Z', function (sa) {
this.showAxis = sa;
return;
});

Clazz.newMeth(C$, 'loadFile$java_net_URL', function (file) {
var b = Clazz.array(Byte.TYPE, [50]);
var nbytes = 0;
var max = 100;
var inc = 100;
var n = 0;
var data = Clazz.array(Double.TYPE, [max]);
var is = null;
var comment = false;
var c;
try {
is = file.openStream();
while ((c = is.read()) > -1){
switch (c) {
case 35:
comment = true;
break;
case 13:
case 10:
comment = false;
case 32:
case 9:
if (nbytes > 0) {
var s =  String.instantialize(b, 0, nbytes);
data[n] = Double.$valueOf(s).doubleValue();
n++;
if (n >= max) {
max = max+(inc);
var d = Clazz.array(Double.TYPE, [max]);
System.arraycopy(data, 0, d, 0, n);
data = d;
}nbytes = 0;
}break;
default:
if (!comment) {
b[nbytes] = ((c|0)|0);
nbytes++;
}break;
}
}
if (is != null ) is.close();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Mouse Released.");
e.printStackTrace();
if (is != null ) try {
is.close();
} catch (ev) {
if (Clazz.exceptionOf(ev, "java.lang.Exception")){
} else {
throw ev;
}
}
return null;
} else {
throw e;
}
}
return this.loadDataSet$DA$I(data, (n/2|0));
});

Clazz.newMeth(C$, 'loadDataSet$DA$I', function (data, n) {
var d;
try {
d = Clazz.new_((I$[4]||$incl$(4)).c$$DA$I,[data, n]);
this.dataset.addElement$TE(d);
d.g2d = this;
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Failed to load Data set ");
e.printStackTrace();
return null;
} else {
throw e;
}
}
return d;
});

Clazz.newMeth(C$, 'attachDataSet$edu_davidson_graph_DataSet', function (d) {
if (d != null ) {
this.dataset.addElement$TE(d);
d.g2d = this;
}});

Clazz.newMeth(C$, 'detachDataSet$edu_davidson_graph_DataSet', function (d) {
if (d != null ) {
if (d.xaxis != null ) d.xaxis.detachDataSet$edu_davidson_graph_DataSet(d);
if (d.yaxis != null ) d.yaxis.detachDataSet$edu_davidson_graph_DataSet(d);
this.dataset.removeElement$O(d);
}});

Clazz.newMeth(C$, 'detachDataSets', function () {
var d;
var i;
if (this.dataset == null  || this.dataset.isEmpty() ) return;
for (i = 0; i < this.dataset.size(); i++) {
d = (this.dataset.elementAt$I(i));
if (d.xaxis != null ) d.xaxis.detachDataSet$edu_davidson_graph_DataSet(d);
if (d.yaxis != null ) d.yaxis.detachDataSet$edu_davidson_graph_DataSet(d);
}
this.dataset.removeAllElements();
});

Clazz.newMeth(C$, 'createAxis$I', function (position) {
var a;
try {
a = Clazz.new_((I$[5]||$incl$(5)).c$$I,[position]);
a.g2d = this;
this.axis.addElement$TE(a);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Failed to create Axis");
e.printStackTrace();
return null;
} else {
throw e;
}
}
return a;
});

Clazz.newMeth(C$, 'attachAxis$edu_davidson_graph_Axis', function (a) {
if (a == null ) return;
try {
this.axis.addElement$TE(a);
a.g2d = this;
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
System.out.println$S("Failed to attach Axis");
e.printStackTrace();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'detachAxis$edu_davidson_graph_Axis', function (a) {
if (a != null ) {
a.detachAll();
a.g2d = null;
this.axis.removeElement$O(a);
}});

Clazz.newMeth(C$, 'detachAxes', function () {
var i;
if (this.axis == null  || this.axis.isEmpty() ) return;
for (i = 0; i < this.axis.size(); i++) {
(this.axis.elementAt$I(i)).detachAll();
(this.axis.elementAt$I(i)).g2d = null;
}
this.axis.removeAllElements();
});

Clazz.newMeth(C$, 'getXmax', function () {
var d;
var max = 0.0;
if (this.dataset == null  || this.dataset.isEmpty() ) return 1.0;
for (var i = 0; i < this.dataset.size(); i++) {
d = (this.dataset.elementAt$I(i));
if (i == 0) max = d.getXmax();
 else max = Math.max(max, d.getXmax());
}
return max;
});

Clazz.newMeth(C$, 'getYmax', function () {
var d;
var max = 0.0;
if (this.dataset == null  || this.dataset.isEmpty() ) return 1.0;
for (var i = 0; i < this.dataset.size(); i++) {
d = (this.dataset.elementAt$I(i));
if (i == 0) max = d.getYmax();
 else max = Math.max(max, d.getYmax());
}
return max;
});

Clazz.newMeth(C$, 'getXmin', function () {
var d;
var min = 0.0;
if (this.dataset == null  || this.dataset.isEmpty() ) return min;
for (var i = 0; i < this.dataset.size(); i++) {
d = (this.dataset.elementAt$I(i));
if (i == 0) min = d.getXmin();
 else min = Math.min(min, d.getXmin());
}
return min;
});

Clazz.newMeth(C$, 'getYmin', function () {
var d;
var min = 0.0;
if (this.dataset == null  || this.dataset.isEmpty() ) return min;
for (var i = 0; i < this.dataset.size(); i++) {
d = (this.dataset.elementAt$I(i));
if (i == 0) min = d.getYmin();
 else min = Math.min(min, d.getYmin());
}
return min;
});

Clazz.newMeth(C$, 'setMarkers$edu_davidson_graph_Markers', function (m) {
this.markers = m;
});

Clazz.newMeth(C$, 'getMarkers', function () {
return this.markers;
});

Clazz.newMeth(C$, 'setGraphBackground$java_awt_Color', function (c) {
if (c == null ) return;
this.setBackground$java_awt_Color(c);
});

Clazz.newMeth(C$, 'setDataBackground$java_awt_Color', function (c) {
if (c == null ) return;
this.DataBackground = c;
});

Clazz.newMeth(C$, 'getDataBackground', function () {
if (this.DataBackground == null ) return this.DataBackground = this.getBackground();
 else return this.DataBackground;
});

Clazz.newMeth(C$, 'adjustScale', function () {
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var r = this.getBounds();
this.paint$java_awt_Graphics$java_awt_Rectangle(g, r);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
this.adjustScale();
var i;
var lg = g.create();
r.x = 0;
r.y = 0;
if (this.DefaultBackground == null ) this.DefaultBackground = this.getBackground();
if (this.DataBackground == null ) this.DataBackground = this.getBackground();
if (!this.$paintAll) return;
r.x = r.x+(this.borderLeft);
r.y = r.y+(this.borderTop);
r.width = r.width-(this.borderLeft + this.borderRight);
r.height = r.height-(this.borderBottom + this.borderTop);
this.paintFirst$java_awt_Graphics$java_awt_Rectangle(lg, r);
if (!this.axis.isEmpty()) r = this.drawAxis$java_awt_Graphics$java_awt_Rectangle(lg, r);
 else {
if (this.clearAll) {
var c = g.getColor();
g.setColor$java_awt_Color(this.DataBackground);
g.fillRect$I$I$I$I(r.x, r.y, r.width, r.height);
g.setColor$java_awt_Color(c);
}this.drawFrame$java_awt_Graphics$I$I$I$I(lg, r.x, r.y, r.width, r.height);
}this.paintBeforeData$java_awt_Graphics$java_awt_Rectangle(lg, r);
this.paintFunctions$java_awt_Graphics$java_awt_Rectangle(lg, r);
this.datarect.x = r.x;
this.datarect.y = r.y;
this.datarect.width = r.width;
this.datarect.height = r.height;
if (!this.dataset.isEmpty()) {
for (i = 0; i < this.dataset.size(); i++) {
(this.dataset.elementAt$I(i)).draw_data$java_awt_Graphics$java_awt_Rectangle(lg, r);
}
}this.paintLast$java_awt_Graphics$java_awt_Rectangle(lg, r);
lg.dispose();
});

Clazz.newMeth(C$, 'paintFirst$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
});

Clazz.newMeth(C$, 'paintBeforeData$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
});

Clazz.newMeth(C$, 'paintFunctions$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
});

Clazz.newMeth(C$, 'paintLast$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
if (this.lastText != null ) {
this.lastText.draw$java_awt_Graphics$I$I$I(g, (r.width/2|0), (r.height/2|0), 0);
}});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
if (this.clearAll) {
var c = g.getColor();
var r = this.getBounds();
r.x = 0;
r.y = 0;
g.setColor$java_awt_Color(this.getBackground());
g.fillRect$I$I$I$I(r.x, r.y, r.width, r.height);
g.setColor$java_awt_Color(c);
}if (this.$paintAll) this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'startedloading', function () {
this.loadingData++;
if (this.loadingData != 1) return;
if (this.load_thread == null ) this.load_thread = Clazz.new_((I$[6]||$incl$(6)).c$$edu_davidson_graph_Graph2D,[this]);
this.load_thread.setFont$java_awt_Font(Clazz.new_((I$[7]||$incl$(7)).c$$S$I$I,["Helvetica", 0, 25]));
this.load_thread.begin();
});

Clazz.newMeth(C$, 'finishedloading', function () {
this.loadingData--;
if (this.loadingData > 0) return;
if (this.load_thread != null ) this.load_thread.end();
this.load_thread = null;
});

Clazz.newMeth(C$, 'loadmessage$S', function (s) {
if (this.load_thread == null ) this.load_thread = Clazz.new_((I$[6]||$incl$(6)).c$$edu_davidson_graph_Graph2D,[this]);
this.load_thread.setMessage$S(s);
});

Clazz.newMeth(C$, 'ForceSquare$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var a;
var dr;
var x = r.x;
var y = r.y;
var width = r.width;
var height = r.height;
var xmin;
var xmax;
var ymin;
var ymax;
var xrange = 0.0;
var yrange = 0.0;
var range;
var aspect;
if (this.dataset == null  || this.dataset.isEmpty() ) return r;
for (var i = 0; i < this.axis.size(); i++) {
a = this.axis.elementAt$I(i);
range = a.maximum - a.minimum;
if (a.isVertical()) {
yrange = Math.max(range, yrange);
} else {
xrange = Math.max(range, xrange);
}}
if (xrange <= 0  || yrange <= 0  ) return r;
if (xrange > yrange ) range = xrange;
 else range = yrange;
for (var i = 0; i < this.axis.size(); i++) {
a = this.axis.elementAt$I(i);
a.maximum = a.minimum + range;
}
dr = this.getDataRectangle$java_awt_Graphics$java_awt_Rectangle(g, r);
if (dr.width > dr.height) {
x = x+((((dr.width - dr.height) / 2.0)|0));
width = width-(dr.width - dr.height);
} else {
y = y+((((dr.height - dr.width) / 2.0)|0));
height = height-(dr.height - dr.width);
}return Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I$I,[x, y, width, height]);
});

Clazz.newMeth(C$, 'getDataRectangle$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var a;
var waxis;
var x = r.x;
var y = r.y;
var width = r.width;
var height = r.height;
for (var i = 0; i < this.axis.size(); i++) {
a = (this.axis.elementAt$I(i));
waxis = a.getAxisWidth$java_awt_Graphics(g);
switch (a.getAxisPos()) {
case 2:
x = x+(waxis);
width = width-(waxis);
break;
case 3:
width = width-(waxis);
break;
case 4:
y = y+(waxis);
height = height-(waxis);
break;
case 5:
height = height-(waxis);
break;
}
}
return Clazz.new_((I$[3]||$incl$(3)).c$$I$I$I$I,[x, y, width, height]);
});

Clazz.newMeth(C$, 'drawAxis$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
try {
var a;
var waxis;
var dr;
var x;
var y;
var width;
var height;
if (this.square) r = this.ForceSquare$java_awt_Graphics$java_awt_Rectangle(g, r);
if (!this.showAxis) dr = r;
 else dr = this.getDataRectangle$java_awt_Graphics$java_awt_Rectangle(g, r);
x = dr.x;
y = dr.y;
width = dr.width;
height = dr.height;
if (this.clearAll) {
var c = g.getColor();
g.setColor$java_awt_Color(this.DataBackground);
g.fillRect$I$I$I$I(x, y, width, height);
g.setColor$java_awt_Color(c);
}if (this.frame || !this.showAxis ) this.drawFrame$java_awt_Graphics$I$I$I$I(g, x, y, width, height);
for (var i = 0; i < this.axis.size(); i++) {
a = (this.axis.elementAt$I(i));
a.data_window = Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[width, height]);
switch (a.getAxisPos()) {
case 2:
if (this.showAxis) r.x = r.x+(a.width);
if (this.showAxis) r.width = r.width-(a.width);
a.positionAxis$I$I$I$I(r.x, r.x, y, y + height);
if (r.x == x) {
a.gridcolor = this.gridcolor;
a.drawgrid = this.drawgrid;
a.zerocolor = this.zerocolor;
a.drawzero = this.drawzero;
}a.drawAxis$java_awt_Graphics(g);
a.drawgrid = false;
a.drawzero = false;
break;
case 3:
if (this.showAxis) r.width = r.width-(a.width);
a.positionAxis$I$I$I$I(r.x + r.width, r.x + r.width, y, y + height);
if (r.x + r.width == x + width) {
a.gridcolor = this.gridcolor;
a.drawgrid = this.drawgrid;
a.zerocolor = this.zerocolor;
a.drawzero = this.drawzero;
}a.drawAxis$java_awt_Graphics(g);
a.drawgrid = false;
a.drawzero = false;
break;
case 4:
if (this.showAxis) r.y = r.y+(a.width);
if (this.showAxis) r.height = r.height-(a.width);
a.positionAxis$I$I$I$I(x, x + width, r.y, r.y);
if (r.y == y) {
a.gridcolor = this.gridcolor;
a.drawgrid = this.drawgrid;
a.zerocolor = this.zerocolor;
a.drawzero = this.drawzero;
}a.drawAxis$java_awt_Graphics(g);
a.drawgrid = false;
a.drawzero = false;
break;
case 5:
if (this.showAxis) r.height = r.height-(a.width);
a.positionAxis$I$I$I$I(x, x + width, r.y + r.height, r.y + r.height);
if (r.y + r.height == y + height) {
a.gridcolor = this.gridcolor;
a.drawgrid = this.drawgrid;
a.zerocolor = this.zerocolor;
a.drawzero = this.drawzero;
}a.drawAxis$java_awt_Graphics(g);
a.drawgrid = false;
a.drawzero = false;
break;
}
}
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
;} else {
throw e;
}
}
return r;
});

Clazz.newMeth(C$, 'drawFrame$java_awt_Graphics$I$I$I$I', function (g, x, y, width, height) {
var c = (I$[2]||$incl$(2)).black;
if (this.framecolor != null ) g.setColor$java_awt_Color(this.framecolor);
if (this.showAxis) g.drawRect$I$I$I$I(x, y, width, height);
 else g.drawRect$I$I$I$I(x, y, width - 1, height - 1);
g.setColor$java_awt_Color(c);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:26
