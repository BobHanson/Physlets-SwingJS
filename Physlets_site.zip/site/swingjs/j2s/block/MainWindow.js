(function(){var P$=Clazz.newPackage("block"),I$=[];
var C$=Clazz.newClass(P$, "MainWindow", null, 'java.awt.Frame');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.is_applet=false;
this.anim=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
this.anim.reset$Z(false);
});

Clazz.newMeth(C$, 'c$$S$Z', function (title, isapp) {
C$.superclazz.c$$S.apply(this, [title]);
C$.$init$.apply(this);
this.is_applet=isapp;
this.add$S$java_awt_Component("Center", this.anim=Clazz.new_(Clazz.load('block.Animation').c$$block_MainWindow,[this]));
}, 1);

Clazz.newMeth(C$, 'start$', function () {
this.anim.reset$Z(true);
});

Clazz.newMeth(C$, 'handleEvent$java_awt_Event', function (e) {
if (e.id == 201) {
this.hide$();
this.removeAll$();
this.dispose$();
if (!this.is_applet) {
System.exit$I(0);
}}return C$.superclazz.prototype.handleEvent$java_awt_Event.apply(this, [e]);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:11 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
