(function(){var P$=Clazz.newPackage("dynamics"),I$=[];
var C$=Clazz.newClass(P$, "buoyantBlock", null, 'dynamics.rk4');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.aCst = 0;
this.y0 = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'init$I$I', function (n, n2) {
this.y0=n2;
this.y[0]=n;
this.y[1]=0.0;
this.aCst=1.0;
});

Clazz.newMeth(C$, 'derivs$D$DA$DA', function (n, array, array2) {
array2[0]=this.y[1];
array2[1]=this.aCst * (this.y0 - this.y[0]);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.aCst=1.0;
this.init$I$Z(2, true);
}, 1);
})();
//Created 2018-07-20 18:09:32
