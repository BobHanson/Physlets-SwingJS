(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['edu.davidson.display.SGraph','java.awt.Color','java.awt.Polygon']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ComplexThing", null, 'edu.davidson.display.Thing');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.xvec = null;
this.revec = null;
this.imvec = null;
this.centered = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.centered = true;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable', function (owner, sc) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, 0, 0]);
C$.$init$.apply(this);
this.s = 1;
this.w = 0;
this.h = 0;
this.applet = owner;
}, 1);

Clazz.newMeth(C$, 'setCentered$Z', function (c) {
this.centered = c;
});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (ds, sid, x, y) {
System.out.println$S("Single data points not supported.  The data connection must provide a compelete data set.");
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (ds, sid, x, y) {
if (x == null  || y == null  ) return;
var length = x.length;
if (this.xvec == null  || this.xvec.length != length ) {
this.xvec = Clazz.array(Double.TYPE, [length]);
this.revec = Clazz.array(Double.TYPE, [length]);
this.imvec = Clazz.array(Double.TYPE, [length]);
System.arraycopy(x, 0, this.xvec, 0, length);
}if (sid == 1) {
System.arraycopy(x, 0, this.xvec, 0, length);
} else {
System.arraycopy(y, 0, this.imvec, 0, length);
System.arraycopy(x, 0, this.revec, 0, length);
if (Clazz.instanceOf(this.canvas, "java.awt.Canvas")) (this.canvas).repaint();
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (this.xvec == null ) return;
var left = this.canvas.pixFromX$D(this.xvec[0]);
var right = this.canvas.pixFromX$D(this.xvec[this.xvec.length - 1]);
if (this.canvas.getPixWidth() <= Math.abs(right - left)) p$.paint1$java_awt_Graphics.apply(this, [osg]);
 else p$.paint2$java_awt_Graphics.apply(this, [osg]);
});

Clazz.newMeth(C$, 'paint1$java_awt_Graphics', function (osg) {
var x;
var re;
var im;
x = this.xvec;
re = this.revec;
im = this.imvec;
if (!this.visible || x == null   || re == null   || im == null  ) return;
var length = x.length;
if (length != re.length || length != im.length ) return;
var y1Bottom = 0;
var y1Top = 0;
var origin = this.canvas.pixFromY$D(0);
for (var i = 0; i < length; i++) {
if (Clazz.instanceOf(this.canvas, "edu.davidson.display.SGraph")) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).colorFromRadians$D(Math.atan2(im[i], re[i])));
 else osg.setColor$java_awt_Color((I$[2]||$incl$(2)).getHSBColor$F$F$F((1 + Math.atan2(im[i], re[i]) / 3.141592653589793) / 2, 1.0, 1.0));
var amp = Math.sqrt(re[i] * re[i] + im[i] * im[i]);
if (this.centered) {
y1Bottom = this.canvas.pixFromY$D(-amp / 2);
y1Top = this.canvas.pixFromY$D(amp / 2);
} else {
y1Bottom = origin;
y1Top = this.canvas.pixFromY$D(amp);
}var xpix = this.canvas.pixFromX$D(x[i]);
osg.drawLine$I$I$I$I(xpix, y1Bottom, xpix, y1Top);
}
});

Clazz.newMeth(C$, 'paint2$java_awt_Graphics', function (osg) {
var x;
var re;
var im;
x = this.xvec;
re = this.revec;
im = this.imvec;
if (!this.visible || x == null   || re == null   || im == null  ) return;
var length = x.length;
if (length != re.length || length != im.length ) return;
var xpts = Clazz.array(Integer.TYPE, [5]);
var ypts = Clazz.array(Integer.TYPE, [5]);
var shape = Clazz.new_((I$[3]||$incl$(3)).c$$IA$IA$I,[xpts, ypts, 5]);
var x0;
var x1;
var y0Top;
var y1Top;
var y0Bottom;
var y1Bottom;
var offset = 0;
var amp = Math.sqrt(re[0] * re[0] + im[0] * im[0]);
var origin = this.canvas.pixFromY$D(0);
x0 = this.canvas.pixFromX$D(x[0]);
if (this.centered) {
y0Bottom = this.canvas.pixFromY$D(-amp / 2);
y0Top = this.canvas.pixFromY$D(amp / 2);
} else {
y0Bottom = origin;
y0Top = this.canvas.pixFromY$D(amp);
}for (var i = 1; i < length; i++) {
x1 = this.canvas.pixFromX$D(x[i]);
amp = Math.sqrt(re[i] * re[i] + im[i] * im[i]);
if (Clazz.instanceOf(this.canvas, "edu.davidson.display.SGraph")) osg.setColor$java_awt_Color((I$[1]||$incl$(1)).colorFromRadians$D(Math.atan2(im[i], re[i])));
 else osg.setColor$java_awt_Color((I$[2]||$incl$(2)).getHSBColor$F$F$F((1 + Math.atan2(im[i], re[i]) / 3.141592653589793) / 2, 1.0, 1.0));
if (this.centered) {
y1Bottom = this.canvas.pixFromY$D(-amp / 2);
y1Top = this.canvas.pixFromY$D(amp / 2);
} else {
y1Bottom = origin;
y1Top = this.canvas.pixFromY$D(amp);
}shape.xpoints[0] = x0;
shape.ypoints[0] = y0Top;
shape.xpoints[1] = x1;
shape.ypoints[1] = y1Top;
shape.xpoints[2] = x1;
shape.ypoints[2] = y1Bottom;
shape.xpoints[3] = x0;
shape.ypoints[3] = y0Bottom;
shape.xpoints[4] = x0;
shape.ypoints[4] = y0Top;
osg.fillPolygon$java_awt_Polygon(shape);
x0 = x1;
y0Top = y1Top;
y0Bottom = y1Bottom;
}
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
if (!this.visible) return;
this.paint$java_awt_Graphics(osg);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
return false;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-08 01:51:41
