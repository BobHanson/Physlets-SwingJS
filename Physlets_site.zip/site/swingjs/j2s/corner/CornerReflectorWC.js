(function(){var P$=Clazz.newPackage("corner"),I$=[[0,'java.awt.Color','java.awt.Point']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "CornerReflectorWC", null, 'java.applet.Applet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.area=null;
this.bgImage=null;
this.fgImage=null;
this.gb=null;
this.g=null;
this.bgColor=null;
this.rts=null;
this.STR=null;
this.xx=0;
this.yy=0;
this.xs2=0;
this.ys2=0;
this.startTime=0;
this.lastTime=0;
this.delay=0;
this.delta=0;
this.c=0;
this.cnt=0;
this.ns=0;
this.xt=0;
this.yt=0;
this.bt=0;
this.rightClick=false;
this.dragm=false;
this.dragd=false;
this.dragd2=false;
this.down=false;
this.xs=0;
this.ys=0;
this.cta1=0;
this.cta2=0;
this.ctaa=0;
this.dd=0;
this.PI2=0;
this.m=0;
this.ni=0;
this.nf=0;
this.n=0;
this.V=0;
this.dc2=0;
this.fm=null;
this.chy=0;
this.xc=0;
this.yc=0;
this.size=0;
this.size2=0;
this.xm=0;
this.ym=0;
this.ym2=0;
this.Nmax=0;
this.NR=0;
this.Nmax1=0;
this.cta=0;
this.rm=0;
this.dc=0;
this.CR=null;
this.X=null;
this.Y=null;
this.VX=null;
this.VY=null;
this.cst=0;
this.NI=0;
this.PXA=null;
this.PYA=null;
this.PXB=null;
this.PYB=null;
this.na=null;
this.nb=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
for (var i=0; i < this.STR.length; ++i) {
if ((this.rts=this.getParameter$S(this.STR[i])) != null ) {
this.STR[i]= String.instantialize(this.rts);
}}
this.setBackground$java_awt_Color(this.bgColor);
this.area=this.size$();
this.reset$();
});

Clazz.newMeth(C$, ['reset$','reset'], function () {
this.xs=(this.xc/2|0);
this.ys=this.yc;
this.xs2=this.xs - 15;
this.ys2=this.ys;
this.clear$();
this.setupRay$();
});

Clazz.newMeth(C$, ['start$','start'], function () {
this.clear$();
this.repaint$();
System.out.println$S("start");
});

Clazz.newMeth(C$, 'advanced$D', function (n) {
this.gb.setColor$java_awt_Color(Clazz.load('java.awt.Color').yellow);
if (this.cnt < this.n) {
for (var i=0; i < this.ns; ++i) {
this.xx=(this.X[i]|0);
this.yy=(this.Y[i]|0);
var x=this.X;
var n2=i;
x[n2] += this.VX[i] * n;
var y=this.Y;
var n3=i;
y[n3] += this.VY[i] * n;
if (this.X[i] > this.xm ) {
if (this.Y[i] < this.yc ) {
if (this.Y[i] > this.ym  && (this.Y[i] - this.ym) / (this.X[i] - this.xm) < this.m  ) {
var x2=this.X;
var n4=i;
x2[n4] -= this.VX[i] * n;
var y2=this.Y;
var n5=i;
y2[n5] -= this.VY[i] * n;
this.c=2.0 * this.cta - this.CR[i];
this.VX[i]=this.V * Math.cos(this.c);
this.VY[i]=this.V * Math.sin(this.c);
if (this.n < this.Nmax1) {
this.X[this.n]=this.X[i];
this.Y[this.n]=this.Y[i];
this.VX[this.n]=-this.VX[i];
this.VY[this.n]=-this.VY[i];
++this.n;
}this.CR[i]=this.c;
}} else if (this.Y[i] > this.yc ) {
if (this.ym2 > this.Y[i]  && (this.ym2 - this.Y[i]) / (this.X[i] - this.xm) < this.m  ) {
var x3=this.X;
var n6=i;
x3[n6] -= this.VX[i] * n;
var y3=this.Y;
var n7=i;
y3[n7] -= this.VY[i] * n;
this.c=-2.0 * this.cta - this.CR[i];
this.VX[i]=this.V * Math.cos(this.c);
this.VY[i]=this.V * Math.sin(this.c);
if (this.n < this.Nmax1) {
this.X[this.n]=this.X[i];
this.Y[this.n]=this.Y[i];
this.VX[this.n]=-this.VX[i];
this.VY[this.n]=-this.VY[i];
++this.n;
}this.CR[i]=this.c;
}} else if (this.X[i] > this.xc ) {
this.X[i]=2 * this.xc - this.X[i];
this.VX[i]=-this.VX[i];
}}this.gb.drawLine$I$I$I$I(this.xx, this.yy, this.xx, this.yy);
if (this.Y[i] < 0.0  || this.Y[i] > this.area.height   || this.X[i] < 0.0  ) {
this.Y[i]=0.0;
this.X[i]=0.0;
this.VX[i]=0.0;
this.VY[i]=0.0;
++this.cnt;
}}
this.gb.setColor$java_awt_Color($I$(1).gray);
for (var j=this.ns; j < this.n; ++j) {
var x4=this.X;
var n8=j;
x4[n8] += this.VX[j] * n;
var y4=this.Y;
var n9=j;
y4[n9] += this.VY[j] * n;
if (this.X[j] > this.area.width  || this.Y[j] < 0.0   || this.Y[j] > this.area.height  ) {
++this.cnt;
this.X[j]=0.0;
this.Y[j]=0.0;
this.VX[j]=0.0;
this.VY[j]=0.0;
}this.gb.drawLine$I$I$I$I(this.xx=(this.X[j]|0), this.yy=(this.Y[j]|0), this.xx, this.yy);
}
}this.repaint$();
});

Clazz.newMeth(C$, ['mouseDown$java_awt_Event$I$I','mouseDown'], function (event, n, n2) {
this.down=true;
if (event.modifiers == 4) {
this.rightClick=true;
} else {
this.rightClick=false;
}if (Math.sqrt((n - this.xm) * (n - this.xm) + (n2 - this.ym) * (n2 - this.ym)) < this.size2 ) {
this.dragm=true;
} else if (Math.sqrt((n - this.xs) * (n - this.xs) + (n2 - this.ys) * (n2 - this.ys)) < this.size2 ) {
this.dragd=true;
this.clear$();
} else if (Math.sqrt((n - this.xs2) * (n - this.xs2) + (n2 - this.ys2) * (n2 - this.ys2)) < this.size2 ) {
this.dragd2=true;
this.clear$();
}this.repaint$();
return true;
});

Clazz.newMeth(C$, ['mouseDrag$java_awt_Event$I$I','mouseDrag'], function (event, n, n2) {
if (this.dragm && n2 < this.yc - 10  && n <= this.xc ) {
var m=(this.yc - n2) / (this.xc - n + this.dd);
this.m=m;
this.ctaa=Math.atan(m);
if (this.m < Math.abs((this.yc - this.ys) / (this.xc - this.xs + this.dd))  || this.m < Math.abs((this.yc - this.ys2) / (this.xc - this.xs2 + this.dd))  ) {
return true;
}this.cta=this.ctaa;
this.clear$();
} else if (this.dragd && n2 > this.ym  && n2 < this.ym2  && n < this.xc - 10 ) {
this.cta1=Math.atan((n2 - this.ym) / (this.xm - n + this.dd));
if (n > this.xm && this.cta1 < 0.0  ) {
if (this.cta + this.cta1 > 0.0 ) {
return true;
}this.cta1 += 3.141592653589793;
}this.cta2=Math.atan((n2 - this.ym2) / (this.xm - n + this.dd));
if (n > this.xm && this.cta2 > 0.0  ) {
if (this.cta2 - this.cta < 0.0 ) {
return true;
}this.cta2 -= 3.141592653589793;
}this.xs=n;
this.ys=n2;
} else if (this.dragd2 && n2 > this.ym  && n2 < this.ym2  && n < this.xc - 10 ) {
this.cta1=Math.atan((n2 - this.ym) / (this.xm - n + this.dd));
if (n > this.xm && this.cta1 < 0.0  ) {
if (this.cta + this.cta1 > 0.0 ) {
return true;
}this.cta1 += 3.141592653589793;
}this.cta2=Math.atan((n2 - this.ym2) / (this.xm - n + this.dd));
if (n > this.xm && this.cta2 > 0.0  ) {
if (this.cta2 - this.cta < 0.0 ) {
return true;
}this.cta2 -= 3.141592653589793;
}this.xs2=n;
this.ys2=n2;
}this.repaint$();
return true;
});

Clazz.newMeth(C$, 'setupRay$', function () {
this.m=(this.yc - this.ym) / (this.xc - this.xm + this.dd);
this.cta1=Math.atan((this.ys - this.ym) / (this.xm - this.xs + this.dd));
if (this.xs > this.xm && this.cta1 < 0.0  ) {
this.cta1 += 3.141592653589793;
}this.cta2=Math.atan((this.ys - this.ym2) / (this.xm - this.xs + this.dd));
if (this.xs > this.xm && this.cta2 > 0.0  ) {
this.cta2 -= 3.141592653589793;
}this.ni=(this.NR/2|0) + ((this.cta2 / this.dc)|0);
this.nf=(this.NR/2|0) + ((this.cta1 / this.dc)|0);
var n=this.nf - this.ni + 1;
this.n=n;
this.ns=n;
for (var i=0; i < this.n; ++i) {
this.CR[i]=(this.ni + i) * this.dc - 3.141592653589793;
this.X[i]=this.xs;
this.Y[i]=this.ys;
this.VX[i]=this.V * Math.cos(this.CR[i]);
this.VY[i]=this.V * Math.sin(this.CR[i]);
}
this.cnt=0;
this.repaint$();
});

Clazz.newMeth(C$, ['mouseUp$java_awt_Event$I$I','mouseUp'], function (event, n, n2) {
if (this.dragd || this.dragd2 ) {
this.clear$();
this.setupRay$();
}this.dragm=false;
this.dragd=false;
this.dragd2=false;
this.down=false;
if (!this.rightClick) {
this.repaint$();
}return true;
});

Clazz.newMeth(C$, 'clear$', function () {
if (this.g == null ) {
this.bgImage=this.createImage$I$I(this.area.width, this.area.height);
this.gb=this.bgImage.getGraphics$();
this.fgImage=this.createImage$I$I(this.area.width, this.area.height);
this.g=this.fgImage.getGraphics$();
this.fm=this.gb.getFontMetrics$();
this.chy=this.fm.getHeight$();
this.xc=(this.area.width/2|0);
this.yc=(this.area.height/2|0);
this.rm=this.xc / 1.5;
this.xs=(this.xc/2|0);
this.ys=this.yc;
this.xs2=this.xs - 15;
this.ys2=this.ys;
}this.gb.setColor$java_awt_Color(this.bgColor);
this.gb.fillRect$I$I$I$I(0, 0, this.area.width, this.area.height);
this.gb.setColor$java_awt_Color($I$(1).black);
this.gb.drawLine$I$I$I$I(this.xc, this.yc, this.xm=this.xc - ((this.rm * Math.cos(this.cta))|0), this.ym=this.yc - ((this.rm * Math.sin(this.cta))|0));
this.gb.drawLine$I$I$I$I(this.xc, this.yc, this.xm, this.ym2=this.area.height - this.ym);
this.gb.setColor$java_awt_Color($I$(1).gray);
this.gb.fillOval$I$I$I$I(this.xc - this.size, this.yc - this.size, this.size2, this.size2);
this.gb.setColor$java_awt_Color($I$(1).green);
this.gb.drawOval$I$I$I$I(this.xm - this.size, this.ym - this.size, this.size2, this.size2);
this.setupRay$();
this.gb.setColor$java_awt_Color($I$(1).black);
this.gb.drawString$S$I$I(this.STR[0] + " =" + ((this.cta * 2.0 * this.cst  + 0.5)|0) , this.xc + 5, this.yc + (this.chy/3|0));
this.repaint$();
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
this.updateScreen$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'imgs$D$D$DA$DA$java_awt_Point', function (n, n2, array, array2, point) {
var n3=3.141592653589793 - this.cta - this.dd ;
var n4=-n3;
var n5=n;
var n6=n2;
var sqrt=Math.sqrt(n5 * n5 + n6 * n6);
point.x=0;
var n7;
do {
var atan=Math.atan(n6 / n5);
if (n5 < 0.0 ) {
if (n6 > 0.0 ) {
atan += 3.141592653589793;
} else {
atan -= 3.141592653589793;
}}if (atan < this.cta ) {
n7=2.0 * this.cta - atan;
} else {
n7=-2.0 * this.cta - atan;
}n5=sqrt * Math.cos(n7);
n6=sqrt * Math.sin(n7);
array[point.x]=this.xc - (n5|0);
array2[point.x]=this.yc - (n6|0);
++point.x;
} while (n7 < n3  && n7 > n4  );
var n8=n;
var n9=n2;
point.y=point.x;
var n10;
do {
var atan2=Math.atan(n9 / n8);
if (n8 < 0.0 ) {
if (n9 > 0.0 ) {
atan2 += 3.141592653589793;
} else {
atan2 -= 3.141592653589793;
}}if (atan2 > -this.cta ) {
n10=-2.0 * this.cta - atan2;
} else {
n10=2.0 * this.cta - atan2;
}n8=sqrt * Math.cos(n10);
n9=sqrt * Math.sin(n10);
array[point.y]=this.xc - (n8|0);
array2[point.y]=this.yc - (n9|0);
++point.y;
} while (n10 < n3  && n10 > n4  );
});

Clazz.newMeth(C$, ['updateScreen$java_awt_Graphics','updateScreen'], function (graphics) {
this.g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.bgImage, 0, 0, this);
this.g.setColor$java_awt_Color($I$(1).yellow);
this.g.fillOval$I$I$I$I(this.xs - this.size, this.ys - this.size, this.size2, this.size2);
this.imgs$D$D$DA$DA$java_awt_Point(this.xc - this.xs, this.yc - this.ys, this.PXA, this.PYA, this.na);
this.imgs$D$D$DA$DA$java_awt_Point(this.xc - this.xs2, this.yc - this.ys2, this.PXB, this.PYB, this.nb);
for (var i=0; i < this.na.y; ++i) {
this.g.drawOval$I$I$I$I((this.PXA[i]|0) - this.size, (this.PYA[i]|0) - this.size, this.size2, this.size2);
}
var n=0;
var n2=0;
var n3=0;
var n4=0;
if (this.na.x > this.nb.x) {
n=this.nb.x;
var y=this.na.y;
n2=1;
n4=1;
} else if (this.na.x != this.nb.x) {
n=this.na.x;
var y2=this.nb.y;
n3=1;
n4=1;
}this.g.setColor$java_awt_Color($I$(1).blue);
this.g.drawLine$I$I$I$I(this.xs, this.ys, this.xs2, this.ys2);
for (var j=0; j < n; ++j) {
this.g.drawLine$I$I$I$I((this.PXA[j]|0), (this.PYA[j]|0), (this.PXB[j]|0), (this.PYB[j]|0));
}
for (var k=n; k < this.na.y - n4; ++k) {
if (this.PXB[k + n3] > 0.0 ) {
this.g.drawLine$I$I$I$I((this.PXA[k + n2]|0), (this.PYA[k + n2]|0), (this.PXB[k + n3]|0), (this.PYB[k + n3]|0));
}}
this.g.setColor$java_awt_Color($I$(1).white);
if (this.cnt < this.n) {
for (var l=0; l < this.n; ++l) {
this.g.drawOval$I$I$I$I(this.xx=(this.X[l]|0) - 1, this.yy=(this.Y[l]|0) - 1, 2, 2);
}
}this.g.setColor$java_awt_Color($I$(1).red);
this.g.drawOval$I$I$I$I(this.xs - this.size, this.ys - this.size, this.size2, this.size2);
if (this.down) {
this.g.setColor$java_awt_Color($I$(1).darkGray);
this.g.drawLine$I$I$I$I(this.xc, this.yc, 2 * this.xc - this.xm, 2 * this.yc - this.ym);
this.g.drawLine$I$I$I$I(this.xc, this.yc, 2 * this.xc - this.xm, this.ym);
this.g.setColor$java_awt_Color($I$(1).orange);
this.g.drawLine$I$I$I$I(this.xs, this.ys, (this.PXA[0]|0), (this.PYA[0]|0));
for (var n5=1; n5 < this.na.x; ++n5) {
this.g.drawLine$I$I$I$I((this.PXA[n5 - 1]|0), (this.PYA[n5 - 1]|0), (this.PXA[n5]|0), (this.PYA[n5]|0));
}
this.g.setColor$java_awt_Color($I$(1).pink);
this.g.drawLine$I$I$I$I(this.xs, this.ys, (this.PXA[this.na.x]|0), (this.PYA[this.na.x]|0));
for (var n6=this.na.x + 1; n6 < this.na.y; ++n6) {
this.g.drawLine$I$I$I$I((this.PXA[n6 - 1]|0), (this.PYA[n6 - 1]|0), (this.PXA[n6]|0), (this.PYA[n6]|0));
}
}graphics.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.fgImage, 0, 0, this);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.bgColor=$I$(1).lightGray;
this.STR=Clazz.array(String, -1, ["angle", "Start", "Time"]);
this.startTime=0;
this.delay=50;
this.rightClick=false;
this.dragm=false;
this.dragd=false;
this.dragd2=false;
this.down=false;
this.dd=0.001;
this.PI2=1.5707963267948966;
this.V=20.0;
this.size=4;
this.size2=2 * this.size;
this.Nmax=200;
this.NR=44;
this.Nmax1=this.Nmax - 1;
this.cta=this.PI2 * 2.0 / 3.0;
this.dc=6.283185307179586 / this.NR;
this.CR=Clazz.array(Double.TYPE, [this.Nmax]);
this.X=Clazz.array(Double.TYPE, [this.Nmax]);
this.Y=Clazz.array(Double.TYPE, [this.Nmax]);
this.VX=Clazz.array(Double.TYPE, [this.Nmax]);
this.VY=Clazz.array(Double.TYPE, [this.Nmax]);
this.cst=57.29577951308232;
this.NI=20;
this.PXA=Clazz.array(Double.TYPE, [this.NI]);
this.PYA=Clazz.array(Double.TYPE, [this.NI]);
this.PXB=Clazz.array(Double.TYPE, [this.NI]);
this.PYB=Clazz.array(Double.TYPE, [this.NI]);
this.na=Clazz.new_(Clazz.load('java.awt.Point').c$$I$I,[0, 0]);
this.nb=Clazz.new_($I$(2).c$$I$I,[0, 0]);
}, 1);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:12 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
