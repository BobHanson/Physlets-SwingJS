(function(){var P$=Clazz.newPackage("filters"),I$=[['edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Differentiator", null, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataListener', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fStr = null;
this.fun = null;
this.save = 0;
this.varStrings = null;
this.variables = null;
this.$x = null;
this.$y = null;
this.n = 0;
this.$isStandalone = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.fun = null;
this.save = 5;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "d", "dd"]);
this.variables = Clazz.array(Double.TYPE, [1, 4]);
this.$x = Clazz.array(Double.TYPE, [this.save]);
this.$y = Clazz.array(Double.TYPE, [this.save]);
this.n = 0;
this.$isStandalone = false;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.varStrings[0]=this.getParameter$S$S("Independent", "x");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.varStrings[1]=this.getParameter$S$S("Dependent", "y");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.fStr=this.getParameter$S$S("Function", this.varStrings[1]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
edu.davidson.tools.SApplet.addDataListener$O(this);
edu.davidson.tools.SApplet.addDataSource$O(this);
});

Clazz.newMeth(C$, 'parseFunction$edu_davidson_tools_SDataSource', function (s) {
this.fStr=this.fStr.trim();
this.fStr=this.fStr.toLowerCase();
var num = s.getVarStrings().length;
this.fun=Clazz.new_((I$[1]||$incl$(1)).c$$I,[num]);
for (var i = 0; i < num; i++) {
this.fun.defineVariable$I$S(1 + i, s.getVarStrings()[i]);
}
this.fun.define$S(this.fStr);
this.fun.parse();
if (this.fun.getErrorCode() != 0) {
System.out.println$S("Failed to parse the derivative function in filters.Differentiator: " + this.fStr);
System.out.println$S("Parse error: " + this.fun.getErrorString() + " at function 1, position " + this.fun.getErrorPosition() );
this.fun=null;
return false;
}return true;
});

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Differentiator Physlets";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Integrand", "String", "Integrand"]), Clazz.array(java.lang.String, -1, ["Differential", "String", "Differential"])]);
return pinfo;
});

Clazz.newMeth(C$, 'getVariables', function () {
if (this.n < 3) {
this.variables[0][0]=this.$x[0];
this.variables[0][1]=this.$y[0];
this.variables[0][2]=0;
this.variables[0][3]=0;
return this.variables;
}this.variables[0][0]=this.$x[1];
this.variables[0][1]=this.$y[1];
var v1;
if ((this.$x[0] - this.$x[1]) != 0 ) v1=(this.$y[0] - this.$y[1]) / (this.$x[0] - this.$x[1]);
 else if ((this.$y[0] - this.$y[1]) != 0  && (this.$x[0] - this.$x[1]) != 0  ) v1=1.0E20 * (this.$y[0] - this.$y[1]) / Math.abs(this.$y[0] - this.$y[1]);
 else v1=0;
var v2;
if ((this.$x[1] - this.$x[2]) != 0 ) v2=(this.$y[1] - this.$y[2]) / (this.$x[1] - this.$x[2]);
 else if ((this.$y[1] - this.$y[2]) != 0  && (this.$x[1] - this.$x[2]) != 0  ) v2=1.0E20 * (this.$y[1] - this.$y[2]) / Math.abs(this.$y[1] - this.$y[2]);
 else v2=0;
this.variables[0][2]=(v1 + v2) / 2;
if ((this.$x[0] - this.$x[2]) != 0 ) this.variables[0][3]=2 * (v1 - v2) / ((this.$x[0] - this.$x[2]));
 else this.variables[0][3]=0;
return this.variables;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, 'reset', function () {
this.n=0;
for (var i = 0; i < this.save; i++) {
this.$x[i]=0;
this.$y[i]=0;
}
this.updateDataConnections();
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, xx, yy) {
if (xx == this.$x[0] ) return;
var tmp = 0;
if (this.fun == null  && this.fStr != null  ) p$.parseFunction$edu_davidson_tools_SDataSource.apply(this, [s]);
for (var i = this.save - 1; i > 0; i--) {
this.$x[i]=this.$x[i - 1];
this.$y[i]=this.$y[i - 1];
}
this.$x[0]=xx;
this.$y[0]=this.fun.evaluate$DA(s.getVariables()[0]);
this.n++;
if (this.n < 3) {
return;
}this.updateDataConnections();
});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
;});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.reset();
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
this.reset();
});
})();
//Created 2018-07-23 12:59:28 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
