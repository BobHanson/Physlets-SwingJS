(function(){var P$=Clazz.newPackage("mathapps"),I$=[['edu.davidson.tools.SApplet','java.lang.Thread',['mathapps.FFT2DTransformer','.ArrayFunction'],'Thread','jnt.fft.RealFloat2DFFT_Even']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FFT2DTransformer", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, ['Runnable', 'edu.davidson.tools.SDataSource', 'edu.davidson.tools.SDataListener']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.transformThread = null;
this.runLock = null;
this.tempData = null;
this.dataArray = null;
this.running = false;
this.data = null;
this.newdata = null;
this.fftRowPts = 0;
this.fftColPts = 0;
this.outRowPts = 0;
this.outColPts = 0;
this.showDC = false;
this.fft = null;
this.evenArray = null;
this.oddArray = null;
this.minVal = 0;
this.maxVal = 0;
this.outScale = 0;
this.gutterPts = 0;
this.newGutterPts = 0;
this.varStrings = null;
this.ds = null;
this.ds2 = null;
this.owner = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.runLock =  Clazz.new_();
this.tempData = null;
this.dataArray = null;
this.running = false;
this.data = null;
this.newdata = null;
this.showDC = true;
this.fft = null;
this.evenArray = null;
this.oddArray = null;
this.outScale = 0;
this.gutterPts = 0;
this.newGutterPts = 0;
this.varStrings = Clazz.array(java.lang.String, -1, ["surfacedata"]);
this.ds = null;
this.ds2 = null;
this.owner = null;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet', function (o) {
C$.$init$.apply(this);
this.owner=o;
this.transformThread=Clazz.new_((I$[2]||$incl$(2)).c$$Runnable,[this]);
this.transformThread.start();
(I$[1]||$incl$(1)).addDataSource$O(this);
(I$[1]||$incl$(1)).addDataListener$O(this);
}, 1);

Clazz.newMeth(C$, 'destroy', function () {
{
this.transformThread=null;
this.running=true;
this.runLock.notify();
}});

Clazz.newMeth(C$, 'setDefault', function () {
this.evenArray=null;
this.oddArray=null;
this.gutterPts=0;
this.outScale=0;
});

Clazz.newMeth(C$, 'setFFTScale$D', function (scale) {
scale=Math.max(0, scale);
this.outScale=scale;
});

Clazz.newMeth(C$, 'setGutter$I', function (pts) {
this.newGutterPts=pts;
});

Clazz.newMeth(C$, 'getGutter', function () {
return this.gutterPts;
});

Clazz.newMeth(C$, 'getEvenID', function () {
if (this.evenArray != null ) return this.evenArray.getID();
this.evenArray=Clazz.new_((I$[3]||$incl$(3)).c$$I$I, [this, null, this.fftRowPts + 1, this.fftColPts + 1]);
return this.evenArray.getID();
});

Clazz.newMeth(C$, 'getOddID', function () {
if (this.oddArray != null ) return this.oddArray.getID();
this.oddArray=Clazz.new_((I$[3]||$incl$(3)).c$$I$I, [this, null, this.fftRowPts + 1, this.fftColPts + 1]);
return this.oddArray.getID();
});

Clazz.newMeth(C$, 'run', function () {
while (this.transformThread != null ){
{
while (!this.running)try {
this.runLock.wait();
} catch (ie) {
if (Clazz.exceptionOf(ie, "java.lang.InterruptedException")){
} else {
throw ie;
}
}

}this.running=false;
p$.doTransform.apply(this, []);
try {
(I$[4]||$incl$(4)).sleep$J(20);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'setDataArray$DAA', function (d) {
{
this.dataArray=d;
this.running=true;
this.runLock.notify();
}});

Clazz.newMeth(C$, 'doTransform', function () {
if (p$.checkArrays.apply(this, [])) {
p$.packData.apply(this, []);
this.transform();
p$.unpackData.apply(this, []);
this.owner.updateDataConnections();
}});

Clazz.newMeth(C$, 'checkArrays', function () {
this.tempData=this.dataArray;
if (this.tempData == null ) return false;
var rowPts = this.tempData.length;
var colPts = this.tempData[0].length;
this.gutterPts=this.newGutterPts;
this.fftRowPts=rowPts - rowPts % 2;
this.fftColPts=colPts - colPts % 2;
if (this.fft == null  || this.fft.getNRows() != this.fftRowPts  || this.fft.getNCols() != this.fftColPts ) this.fft=Clazz.new_((I$[5]||$incl$(5)).c$$I$I,[this.fftRowPts, this.fftColPts]);
if (this.data == null  || this.fftRowPts * (this.fftColPts + 2) != this.data.length ) this.data=Clazz.array(Float.TYPE, [this.fftRowPts * (this.fftColPts + 2)]);
this.outRowPts=this.fftRowPts - 2 * this.gutterPts + 1;
this.outColPts=this.fftColPts - 2 * this.gutterPts + 1;
if (this.outRowPts <= 1 || this.outColPts <= 1 ) {
System.out.println$S("Gutter is too large.");
return false;
}if (this.ds == null  || this.ds.length != this.outRowPts  || this.ds[0].length != this.outColPts ) {
this.ds=Clazz.array(Double.TYPE, [this.outRowPts, this.outColPts]);
if (this.evenArray != null ) this.evenArray.setNum$I$I(this.outRowPts, this.outColPts);
if (this.oddArray != null ) this.oddArray.setNum$I$I(this.outRowPts, this.outColPts);
}if (this.ds2 == null  || this.ds2.length != this.fftRowPts  || this.ds2[0].length != 2 * this.fftColPts ) {
this.ds2=Clazz.array(Double.TYPE, [this.fftRowPts, 2 * this.fftColPts]);
}if (this.newdata == null  || this.newdata.length != 2 * this.fftRowPts * this.fftColPts  ) this.newdata=Clazz.array(Float.TYPE, [2 * this.fftRowPts * this.fftColPts ]);
return true;
});

Clazz.newMeth(C$, 'transform', function () {
var rowSpan = this.fftColPts + 2;
this.fft.transform$FA(this.data);
this.data=this.fft.toWraparoundOrder$FA$I$FA(this.data, rowSpan, this.newdata);
var norm = 1;
var nrows = this.fftRowPts;
var ncols = this.fftColPts;
var im = (nrows/2|0);
var jm = ncols;
if (this.outScale > 0 ) {
this.minVal=0;
this.maxVal=0;
for (var i = 1; i < this.data.length; i++) {
this.minVal=Math.min(this.minVal, this.data[i]);
this.maxVal=Math.max(this.maxVal, this.data[i]);
}
norm=this.outScale * Math.max(Math.abs(this.minVal), Math.abs(this.maxVal));
if (norm == 0 ) norm=1;
} else norm=(this.fftRowPts * this.fftColPts/2|0);
this.minVal=0;
this.maxVal=0;
for (var i = 0; i < (nrows/2|0); i++) {
for (var j = 0; j < ncols; j++) {
this.ds2[i][j]=this.data[2 * ncols * (im + i)  + (jm + j)] / norm;
this.ds2[i + im][j + jm]=this.data[2 * ncols * (i)  + j] / norm;
this.ds2[i + im][j]=this.data[2 * ncols * (i)  + (jm + j)] / norm;
this.ds2[i][j + jm]=this.data[2 * ncols * (im + i)  + j] / norm;
}
}
});

Clazz.newMeth(C$, 'packData', function () {
var offset;
var rowSpan = this.fftColPts + 2;
for (var i = 0; i < this.fftRowPts; i++) {
offset=i * rowSpan;
for (var j = 0; j < this.fftColPts; j++) {
this.data[offset + j]=this.tempData[i][j];
}
this.data[offset + this.fftColPts]=0;
this.data[offset + this.fftColPts + 1 ]=0;
}
});

Clazz.newMeth(C$, 'unpackData', function () {
var nrows = this.fftRowPts + 1;
var ncols = this.fftColPts + 1;
for (var i = 1; i < this.fftRowPts - 2 * this.gutterPts; i++) {
for (var j = 1; j < this.fftColPts - 2 * this.gutterPts; j++) {
this.ds[i][j]=Math.sqrt(this.ds2[i + this.gutterPts][2 * (j + this.gutterPts)] * this.ds2[i + this.gutterPts][2 * (j + this.gutterPts)] + this.ds2[i + this.gutterPts][2 * (j + this.gutterPts) + 1] * this.ds2[i + this.gutterPts][2 * (j + this.gutterPts) + 1]);
if (this.evenArray != null ) this.evenArray.v[i][j]=this.ds2[i + this.gutterPts][2 * (j + this.gutterPts)];
if (this.oddArray != null ) this.oddArray.v[i][j]=this.ds2[i + this.gutterPts][2 * (j + this.gutterPts) + 1];
}
}
if (!this.showDC) this.ds[(nrows/2|0)][(ncols/2|0)]=(this.ds[(nrows/2|0) - 1][(ncols/2|0)] + this.ds[(nrows/2|0) + 1][(ncols/2|0)] + this.ds[(nrows/2|0)][(ncols/2|0) - 1] + this.ds[(nrows/2|0) - 1][(ncols/2|0) + 1] ) / 4;
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (o) {
this.owner=o;
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (s, id, x, y) {
System.out.println$S("addDatum Series not supported.");
System.out.println$S("x=" + new Double(x).toString() + "    y=" + new Double(y).toString() );
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (s, id, x, y) {
var varStrings;
var dataArray = null;
varStrings=s.getVarStrings();
if (varStrings == null  || varStrings[0] == null   || varStrings[0].equals$O("surfacedata") ) {
dataArray=s.getVariables();
if (dataArray == null ) {
System.out.println$S("Data array not found in FFT2D");
return;
}this.setDataArray$DAA(dataArray);
}});

Clazz.newMeth(C$, 'deleteSeries$I', function (id) {
});

Clazz.newMeth(C$, 'clearSeries$I', function (id) {
});
;
(function(){var C$=Clazz.newClass(P$.FFT2DTransformer, "ArrayFunction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.v = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["surfacedata"]);
this.v = null;
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (row, col) {
C$.$init$.apply(this);
this.v=Clazz.array(Double.TYPE, [row, col]);
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'setNum$I$I', function (row, col) {
if (this.v != null  && this.v.length == row  && this.v[0].length == col ) return;
this.v=Clazz.array(Double.TYPE, [row, col]);
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0.owner;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.v;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:37
