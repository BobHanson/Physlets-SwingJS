(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['java.awt.event.MouseAdapter','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TreadButton", null, 'a2s.Button');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'jbInit', function () {
this.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "TreadButton$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.b$['edu.davidson.graphics.TreadButton'].this_mousePressed$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.b$['edu.davidson.graphics.TreadButton'].this_mouseReleased$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[1]||$incl$(1)), [this, null],P$.TreadButton$1)));
});

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
this.setBackground$java_awt_Color((I$[2]||$incl$(2)).green);
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.setBackground$java_awt_Color((I$[2]||$incl$(2)).gray);
});
})();
//Created 2018-07-20 18:09:40
