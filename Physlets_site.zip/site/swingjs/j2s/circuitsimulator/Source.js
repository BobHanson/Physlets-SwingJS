(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[['edu.davidson.numerics.Parser','edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Source", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.amplitude = 0;
this.phase = 0;
this.sourcetype = 0;
this.parser = null;
this.pvars = null;
this.internalResistance = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.amplitude = 0.0;
this.phase = 0.0;
this.sourcetype = -1;
this.parser = Clazz.new_((I$[1]||$incl$(1)).c$$I,[3]);
this.pvars = Clazz.array(Double.TYPE, [3]);
this.internalResistance = 1.0E-9;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$I$S', function (circ, pol, r, c, to) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circ, pol, r, c, to]);
C$.$init$.apply(this);
this.frequency = 1.0;
this.inputIndex = this.circuit.cirgrid.sourceContainer.size() + 1;
this.circuit.cirgrid.sourceContainer.addElement$TE(this);
this.setValueVisible$Z(false);
this.unity = "V";
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$I$S$S', function (circ, pol, r, c, to, func) {
C$.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circ, pol, r, c, to]);
this.$function = "" + func;
this.parsefunction();
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$I$S$S$D', function (circ, pol, r, c, to, func, freq) {
C$.c$$circuitsimulator_Circuit$I$I$I$S$S.apply(this, [circ, pol, r, c, to, func]);
this.frequency = freq;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$I$S$I$D$D$D', function (circ, pol, r, c, to, st, amp, ph, freq) {
C$.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circ, pol, r, c, to]);
this.frequency = freq;
this.amplitude = amp;
this.phase = ph;
this.sourcetype = st;
this.setfunction();
this.parsefunction();
}, 1);

Clazz.newMeth(C$, 'parsefunction', function () {
this.parser.defineVariable$I$S(1, "t");
this.parser.defineVariable$I$S(2, "f");
this.parser.defineVariable$I$S(3, "p");
this.parser.define$S(this.$function.toLowerCase());
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
System.out.println$S("Failed to parse function: " + this.$function);
System.out.println$S("Parse error: " + this.parser.getErrorString() + " function position " + this.parser.getErrorPosition() );
}});

Clazz.newMeth(C$, 'valueStr', function () {
return this.$function;
});

Clazz.newMeth(C$, 'setfunction', function () {
switch (this.sourcetype) {
case 0:
this.$function = Double.toString(this.amplitude);
break;
case 1:
this.$function = Double.toString(this.amplitude) + "*round(1-t*" + Double.toString(this.frequency) + ")+floor(t*" + Double.toString(this.frequency) + "))" ;
break;
case 2:
this.$function = Double.toString(this.amplitude) + "*sin(2*pi*" + Double.toString(this.frequency) + "*(t+" + Double.toString(this.phase) + "))" ;
break;
case 3:
this.$function = Double.toString(this.amplitude) + "*cos(2*pi*" + Double.toString(this.frequency) + "*(t+" + Double.toString(this.phase) + "))" ;
}
});

Clazz.newMeth(C$, 'getV$D', function (t) {
this.pvars[0] = t;
this.pvars[1] = this.frequency;
this.pvars[2] = 1 / this.frequency;
return this.parser.evaluate$DA(this.pvars);
});

Clazz.newMeth(C$, 'set$S', function (s) {
var ret = C$.superclazz.prototype.set$S.apply(this, [s]);
if ((I$[2]||$incl$(2)).parameterExist$S$S(s, "r=")) this.internalResistance = (I$[2]||$incl$(2)).getParam$S$S(s, "r=");
this.parsefunction();
return ret;
});

Clazz.newMeth(C$, 'setvalue$S', function (s) {
this.$function = "" + s;
this.parsefunction();
});

Clazz.newMeth(C$, 'getvalue', function () {
return this.$function;
});

Clazz.newMeth(C$, 'input$D', function (sign) {
return sign;
});

Clazz.newMeth(C$, 'impedance', function () {
return this.internalResistance;
});

Clazz.newMeth(C$, 'getStringAdditions', function () {
return ",func=" + this.$function + ",freq=" + new Double(this.frequency).toString() + ",r=" + new Double(this.internalResistance).toString() ;
});
})();
//Created 2018-02-06 06:55:34
