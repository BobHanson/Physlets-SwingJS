(function(){var P$=Clazz.newPackage("emwave4"),I$=[[0,'emwave4.Figure']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Circle", null, 'emwave4.Figure');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$D$java_awt_Color', function (z1, r, clr) {
Clazz.super_(C$, this,1);
this.pts=Clazz.array(Double.TYPE, [5, 3]);
this.pts[0][0]=-r;
this.pts[0][1]=r;
this.pts[0][2]=z1;
this.pts[1][0]=r / 2;
this.pts[1][1]=0;
this.pts[1][2]=z1;
this.pts[2][0]=-r / 2;
this.pts[2][1]=0;
this.pts[2][2]=z1;
this.pts[3][0]=0;
this.pts[3][1]=r / 2;
this.pts[3][2]=z1;
this.pts[4][0]=0;
this.pts[4][1]=-r / 2;
this.pts[4][2]=z1;
this.numLines=2;
$I$(1).xOrigin=350;
$I$(1).yOrigin=175;
this.figType="oval";
this.c=clr;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:52 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
