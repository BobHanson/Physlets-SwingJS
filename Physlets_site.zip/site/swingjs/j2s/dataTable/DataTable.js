(function(){var P$=Clazz.newPackage("dataTable"),p$1={},I$=[[0,'java.awt.BorderLayout','Boolean','edu.davidson.views.SGridPanel','edu.davidson.tools.SApplet']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "DataTable", null, 'edu.davidson.tools.SApplet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.dataFile=null;
this.numRows=0;
this.numCols=0;
this.cellWidth=0;
this.showControls=false;
this.showRowHeader=false;
this.showColHeader=false;
this.showScrollBars=false;
this.lastOnTop=false;
this.sizeToFitFlag=false;
this.grid=null;
this.borderLayout1=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.dataFile="";
this.showScrollBars=true;
this.borderLayout1=Clazz.new_(Clazz.load('java.awt.BorderLayout'));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
this.initResources$S(null);
try {
this.numRows=Integer.parseInt$S(this.getParameter$S$S("NumRows", "10"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.cellWidth=Integer.parseInt$S(this.getParameter$S$S("CellWidth", "40"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.numCols=Integer.parseInt$S(this.getParameter$S$S("NumCols", "2"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.showControls=Clazz.load('Boolean').valueOf$S(this.getParameter$S$S("ShowControls", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.showRowHeader=$I$(2).valueOf$S(this.getParameter$S$S("ShowRowHeader", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.showColHeader=$I$(2).valueOf$S(this.getParameter$S$S("ShowColHeader", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.lastOnTop=$I$(2).valueOf$S(this.getParameter$S$S("LastOnTop", "false")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.showScrollBars=$I$(2).valueOf$S(this.getParameter$S$S("ShowScrollBars", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.sizeToFitFlag=$I$(2).valueOf$S(this.getParameter$S$S("SizeToFit", "false")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.dataFile=this.getParameter$S$S("DataFile", "");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.grid=Clazz.new_(Clazz.load('edu.davidson.views.SGridPanel').c$$edu_davidson_tools_SApplet$Z,[this, this.showScrollBars]);
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.grid.setDefaultCellWidth$I(this.cellWidth);
this.grid.setLastOnTop$Z(this.lastOnTop);
this.grid.setShowRowHeader$Z(this.showRowHeader);
this.grid.setShowColHeader$Z(this.showColHeader);
this.grid.initCells$I$I(this.numRows, this.numCols);
this.grid.setShowControls$Z(this.showControls);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.add$java_awt_Component$O(this.grid, "Center");
}, p$1);

Clazz.newMeth(C$, ['getAppletCount$','getAppletCount'], function () {
if (this.firstTime) return 0;
 else return C$.superclazz.prototype.getAppletCount$.apply(this, []);
});

Clazz.newMeth(C$, ['start$','start'], function () {
this.validate$();
if (this.sizeToFitFlag) this.sizeToFit$Z(true);
if (this.firstTime) {
this.firstTime=false;
if (this.dataFile != null  && !this.dataFile.equals$O("") ) this.grid.loadFile$I$S(1, this.dataFile);
}C$.superclazz.prototype.start$.apply(this, []);
});

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'], function () {
return "Data Table Applet by W. Christian";
});

Clazz.newMeth(C$, ['getParameterInfo$','getParameterInfo'], function () {
var pinfo=Clazz.array(String, -2, [Clazz.array(String, -1, ["NumRows", "int", "Number of rows"]), Clazz.array(String, -1, ["NumCols", "int", "Number of cols."]), Clazz.array(String, -1, ["ShowControls", "boolean", "Show controls at start up."]), Clazz.array(String, -1, ["ShowRowHeader", "boolean", "Show the fixed row header"]), Clazz.array(String, -1, ["ShowColHeader", "boolean", "Show the fixed col header"]), Clazz.array(String, -1, ["SizeToFit", "boolean", "Fit the table to size of the panel."])]);
return pinfo;
});

Clazz.newMeth(C$, ['loadDataFile$I$S','loadDataFile'], function (sid, fileName) {
this.grid.loadFile$I$S(sid, fileName);
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (s) {
this.grid.clearSeries$I(s);
});

Clazz.newMeth(C$, ['clearAllSeries$','clearAllSeries'], function () {
this.grid.clearAllSeries$();
});

Clazz.newMeth(C$, ['addDatum$I$D','addDatum'], function (sid, x) {
this.grid.addDatum$I$D$D(sid, x, 0);
});

Clazz.newMeth(C$, ['getTableID$','getTableID'], function () {
return this.grid.hashCode$();
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (autoRefresh) {
this.grid.setAutoRefresh$Z(autoRefresh);
});

Clazz.newMeth(C$, ['sizeToFit$Z','sizeToFit'], function (stf) {
this.grid.sizeToFit$Z(stf);
});

Clazz.newMeth(C$, ['setDefault$','setDefault'], function () {
this.grid.setDefault$();
});

Clazz.newMeth(C$, ['setDataStride$I$I','setDataStride'], function (sid, stride) {
this.grid.setDataStride$I$I(sid, stride);
});

Clazz.newMeth(C$, ['getSeriesID$I','getSeriesID'], function (sid) {
return this.grid.getSeriesID$I(sid);
});

Clazz.newMeth(C$, ['getSeriesWidth$I','getSeriesWidth'], function (sid) {
return this.grid.getSeriesWidth$I(sid);
});

Clazz.newMeth(C$, ['setSeriesWidth$I$I','setSeriesWidth'], function (id, width) {
this.grid.setSeriesWidth$I$I(id, width);
});

Clazz.newMeth(C$, ['setSeriesLabel$I$S','setSeriesLabel'], function (sid, str) {
return this.grid.setSeriesLabel$I$S(sid, str);
});

Clazz.newMeth(C$, ['setNumericFormat$I$S','setNumericFormat'], function (sid, str) {
this.grid.setNumericFormat$I$S(sid, str);
});

Clazz.newMeth(C$, ['setFormat$I$S','setFormat'], function (id, str) {
var ds=Clazz.load('edu.davidson.tools.SApplet').getDataSource$I(id);
if (ds == null  && id == 0 ) {
return this.grid.setFormat$S(str);
}return this.grid.setFormat$edu_davidson_tools_SDataSource$S(ds, str);
});

Clazz.newMeth(C$, ['setShowActiveCell$Z','setShowActiveCell'], function (show) {
this.grid.setShowActiveCell$Z(show);
});

Clazz.newMeth(C$, ['getActiveCellValue$','getActiveCellValue'], function () {
return this.grid.getActiveCellValue$();
});

Clazz.newMeth(C$, ['getActiveCellRow$','getActiveCellRow'], function () {
return this.grid.getActiveCellRow$();
});

Clazz.newMeth(C$, ['getActiveCellCol$','getActiveCellCol'], function () {
return this.grid.getActiveCellCol$();
});

Clazz.newMeth(C$, ['setActiveCellValue$D','setActiveCellValue'], function (val) {
return this.grid.setActiveCellValue$D(val);
});

Clazz.newMeth(C$, ['setActiveCell$I$I','setActiveCell'], function (row, col) {
return this.grid.setActiveCell$I$I(row, col);
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:18 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
