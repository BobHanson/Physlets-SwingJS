(function(){var P$=Clazz.newPackage("doppler"),I$=[];
var C$=Clazz.newClass(P$, "DopplerWaveCrest");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x0 = 0;
this.y0 = 0;
this.t0 = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$D$I$I', function (t0_, x0_, y0_) {
C$.$init$.apply(this);
this.x0 = x0_;
this.y0 = y0_;
this.t0 = t0_;
}, 1);

Clazz.newMeth(C$, 'c$$D$I$I$D$D', function (t0_, x0_, y0_, vx_, vy_) {
C$.$init$.apply(this);
this.x0 = x0_;
this.y0 = y0_;
this.t0 = t0_;
}, 1);

Clazz.newMeth(C$, 'translate$I', function (x) {
this.x0 = this.x0 + x;
});

Clazz.newMeth(C$, 'draw$D$java_awt_Graphics', function (t, g) {
var dt = (Math.round(t - this.t0)|0);
var rad = dt;
var xc = this.x0 - rad;
var yc = this.y0 - rad;
g.drawOval$I$I$I$I(xc, yc, rad * 2, rad * 2);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:36:43
