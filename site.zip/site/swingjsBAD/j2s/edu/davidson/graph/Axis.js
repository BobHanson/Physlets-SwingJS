(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['edu.davidson.display.Format','java.awt.Dimension','edu.davidson.graph.RTextLine','java.util.Vector','java.awt.Point','edu.davidson.graph.SpecialFunction']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Axis");
var p$=C$.prototype;

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.labelFormat = null;
this.rangeMinimum = 0;
this.rangeMaximum = 0;
this.rangeBounded = false;
this.drawgrid = false;
this.drawzero = false;
this.gridcolor = null;
this.zerocolor = null;
this.redraw = false;
this.force_end_labels = false;
this.major_tic_size = 0;
this.minor_tic_size = 0;
this.minor_tic_count = 0;
this.axiscolor = null;
this.minimum = 0;
this.maximum = 0;
this.data_window = null;
this.g2d = null;
this.amin = null;
this.amax = null;
this.orientation = 0;
this.position = 0;
this.width = 0;
this.title = null;
this.label = null;
this.exponent = null;
this.max_label_width = 0;
this.dataset = null;
this.label_string = null;
this.label_value = null;
this.label_start = 0;
this.label_step = 0;
this.label_exponent = 0;
this.label_count = 0;
this.guess_label_number = 0;
this.manualRange = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.labelFormat = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%5.2f"]);
this.rangeMinimum = 0;
this.rangeMaximum = 0;
this.rangeBounded = false;
this.drawgrid = false;
this.drawzero = false;
this.gridcolor = null;
this.zerocolor = null;
this.redraw = true;
this.force_end_labels = false;
this.major_tic_size = 10;
this.minor_tic_size = 5;
this.minor_tic_count = 1;
this.data_window = Clazz.new_((I$[2]||$incl$(2)).c$$I$I,[0, 0]);
this.g2d = null;
this.width = 0;
this.title = Clazz.new_((I$[3]||$incl$(3)));
this.label = Clazz.new_((I$[3]||$incl$(3)).c$$S,["0"]);
this.exponent = Clazz.new_((I$[3]||$incl$(3)));
this.max_label_width = 0;
this.dataset = Clazz.new_((I$[4]||$incl$(4)));
this.label_string = null;
this.label_value = null;
this.label_start = 0.0;
this.label_step = 0.0;
this.label_exponent = 0;
this.label_count = 0;
this.guess_label_number = 4;
this.manualRange = false;
}, 1);

Clazz.newMeth(C$, 'setMinRange$Z$D$D', function (rangeBounded, min, max) {
this.rangeBounded=rangeBounded;
this.rangeMinimum=min;
this.rangeMaximum=max;
if (rangeBounded) {
this.resetRange();
}});

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.orientation=0;
this.position=5;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (p) {
C$.$init$.apply(this);
this.setPosition$I(p);
switch (this.position) {
case 2:
case 1:
this.title.setRotation$I(90);
break;
case 3:
this.title.setRotation$I(-90);
break;
default:
this.title.setRotation$I(0);
break;
}
}, 1);

Clazz.newMeth(C$, 'setPosition$I', function (p) {
this.position=p;
switch (this.position) {
case 2:
this.orientation=1;
break;
case 3:
this.orientation=1;
break;
case 4:
this.orientation=0;
break;
case 5:
this.orientation=0;
break;
case 0:
this.orientation=0;
this.position=5;
break;
case 1:
this.orientation=1;
this.position=2;
break;
default:
this.orientation=0;
this.position=5;
break;
}
});

Clazz.newMeth(C$, 'attachDataSet$edu_davidson_graph_DataSet', function (d) {
if (this.orientation == 0) this.attachXdata$edu_davidson_graph_DataSet(d);
 else this.attachYdata$edu_davidson_graph_DataSet(d);
});

Clazz.newMeth(C$, 'detachDataSet$edu_davidson_graph_DataSet', function (d) {
var i = 0;
if (d == null ) return;
if (this.orientation == 0) {
d.xaxis=null;
} else {
d.yaxis=null;
}this.dataset.removeElement$O(d);
if (!this.manualRange && !this.dataset.isEmpty() ) this.resetRange();
});

Clazz.newMeth(C$, 'detachAll', function () {
var i;
var d;
if (this.dataset.isEmpty()) {
if (!this.manualRange) {
this.minimum=0.0;
this.maximum=1.0;
}return;
}if (this.orientation == 0) {
for (i=0; i < this.dataset.size(); i++) {
d=(this.dataset.elementAt$I(i));
d.xaxis=null;
}
} else {
for (i=0; i < this.dataset.size(); i++) {
d=(this.dataset.elementAt$I(i));
d.yaxis=null;
}
}this.dataset.removeAllElements();
if (!this.manualRange) {
this.minimum=0.0;
this.maximum=1.0;
}});

Clazz.newMeth(C$, 'getDataMin', function () {
var m;
var e;
var d;
if (this.dataset.isEmpty()) return 0.0;
m=1.7976931348623157E308;
if (this.orientation == 0) {
for (e=this.dataset.elements(); e.hasMoreElements(); ) {
d=e.nextElement();
if (d.length > 0) m=Math.min(d.getXmin(), m);
}
} else {
for (e=this.dataset.elements(); e.hasMoreElements(); ) {
d=e.nextElement();
if (d.length > 0) m=Math.min(d.getYmin(), m);
}
}return m;
});

Clazz.newMeth(C$, 'getDataMax', function () {
var m;
var e;
var d;
if (this.dataset.isEmpty()) return 1.0;
m=-1.7976931348623157E308;
if (this.orientation == 0) {
for (e=this.dataset.elements(); e.hasMoreElements(); ) {
d=e.nextElement();
if (d.length > 0) m=Math.max(d.getXmax(), m);
}
} else {
for (e=this.dataset.elements(); e.hasMoreElements(); ) {
d=e.nextElement();
if (d.length > 0) m=Math.max(d.getYmax(), m);
}
}return m;
});

Clazz.newMeth(C$, 'getInteger$D', function (v) {
var scale;
var pix = 0;
if (this.amax == null  || this.amin == null  ) return 0;
if (this.maximum == this.minimum ) return ((this.amax.x - this.amin.x)/2|0);
if (this.orientation == 0) {
scale=(this.amax.x - this.amin.x) / (this.maximum - this.minimum);
pix=(((v - this.minimum) * scale)|0);
pix=Math.max(pix, -100000);
pix=Math.min(pix, 100000);
return this.amin.x + pix;
} else {
scale=(this.amax.y - this.amin.y) / (this.maximum - this.minimum);
pix=(((v - this.minimum) * scale)|0);
pix=Math.max(pix, -100000);
pix=Math.min(pix, 100000);
return this.amax.y - pix;
}});

Clazz.newMeth(C$, 'getDouble$I', function (i) {
var scale;
if (this.amax == null  || this.amin == null  ) return (this.maximum + this.minimum) / 2.0;
if (this.orientation == 0) {
scale=(this.maximum - this.minimum) / (this.amax.x - this.amin.x);
return this.minimum + (i - this.amin.x) * scale;
} else {
scale=(this.maximum - this.minimum) / (this.amax.y - this.amin.y);
return this.maximum - (i - this.amin.y) * scale;
}});

Clazz.newMeth(C$, 'resetRange', function () {
if (this.manualRange || this.dataset.isEmpty() ) {
if (this.rangeBounded) {
if (this.minimum > this.rangeMinimum ) this.minimum=this.rangeMinimum;
if (this.maximum < this.rangeMaximum ) this.maximum=this.rangeMaximum;
}if (this.minimum >= this.maximum ) this.maximum=this.minimum + 1.0;
return;
}this.minimum=this.getDataMin();
this.maximum=this.getDataMax();
if (this.minimum == 1.7976931348623157E308  || this.maximum == 4.9E-324  ) {
this.minimum=0;
this.maximum=1;
}if (this.minimum == this.maximum ) {
if (this.dataset.isEmpty()) {
this.minimum=0.0;
this.maximum=1.0;
} else if (this.maximum < 20 ) {
this.minimum -= 1.0;
this.maximum += 1.0;
} else {
this.minimum -= 0.1 * this.maximum;
this.maximum += 0.1 * this.maximum;
}}var range = this.maximum - this.minimum;
var absMax = Math.max(Math.abs(this.maximum), Math.abs(this.minimum));
if ((absMax > 0.1 ) && (range / absMax < 1.0E-4 ) ) range=1.0E-4;
if (this.rangeBounded) {
if (this.minimum > this.rangeMinimum ) this.minimum=this.rangeMinimum;
if (this.maximum < this.rangeMaximum ) this.maximum=this.rangeMaximum;
this.minimum=this.minimum - 0.05 * (this.rangeMaximum - this.rangeMinimum);
this.maximum=this.maximum + 0.05 * (this.rangeMaximum - this.rangeMinimum);
} else {
this.minimum=this.minimum - 0.05 * range;
this.maximum=this.maximum + 0.05 * range;
}});

Clazz.newMeth(C$, 'getAxisPos', function () {
return this.position;
});

Clazz.newMeth(C$, 'isVertical', function () {
if (this.orientation == 0) return false;
 else return true;
});

Clazz.newMeth(C$, 'getAxisWidth$java_awt_Graphics', function (g) {
var i;
this.width=0;
if (this.minimum == this.maximum ) this.resetRange();
if (this.minimum == this.maximum ) return 0;
this.calculateGridLabels();
this.exponent.setText$S(null);
if (this.label_exponent != 0) {
this.exponent.copyState$edu_davidson_graph_RTextLine(this.label);
this.exponent.setText$S("x10^" + String.valueOf(this.label_exponent));
}if (this.orientation == 0) {
this.width=this.label.getRHeight$java_awt_Graphics(g) + this.label.getLeading$java_awt_Graphics(g);
this.width+=Math.max(this.title.getRHeight$java_awt_Graphics(g), this.exponent.getRHeight$java_awt_Graphics(g));
} else {
for (i=0; i < this.label_string.length; i++) {
this.label.setText$S(" " + this.label_string[i]);
this.width=Math.max(this.label.getRWidth$java_awt_Graphics(g), this.width);
}
this.max_label_width=this.width;
this.width=0;
if (!this.title.isNull()) {
this.width=Math.max(this.width, this.title.getRWidth$java_awt_Graphics(g) + this.title.charWidth$java_awt_Graphics$C(g, " "));
}if (!this.exponent.isNull()) {
this.width=Math.max(this.width, this.exponent.getRWidth$java_awt_Graphics(g) + this.exponent.charWidth$java_awt_Graphics$C(g, " "));
}this.width+=this.max_label_width;
}return this.width;
});

Clazz.newMeth(C$, 'positionAxis$I$I$I$I', function (xmin, xmax, ymin, ymax) {
this.amin=null;
this.amax=null;
if (this.orientation == 0 && ymin != ymax ) return false;
if (this.orientation == 1 && xmin != xmax ) return false;
this.amin=Clazz.new_((I$[5]||$incl$(5)).c$$I$I,[xmin, ymin]);
this.amax=Clazz.new_((I$[5]||$incl$(5)).c$$I$I,[xmax, ymax]);
return true;
});

Clazz.newMeth(C$, 'drawAxis$java_awt_Graphics', function (g) {
try {
var lg;
if (!this.redraw) return;
if (this.minimum == this.maximum ) {
this.resetRange();
if (this.minimum == this.maximum ) {
return;
}}if (this.amin.equals$O(this.amax)) return;
if (this.width == 0) this.width=this.getAxisWidth$java_awt_Graphics(g);
lg=g.create();
if ((this.force_end_labels) && (!this.manualRange) ) {
this.minimum=this.label_start;
this.maximum=this.minimum + (this.label_count - 1) * this.label_step;
}if (this.title != null ) this.title.setDrawingComponent$java_awt_Component(this.g2d);
if (this.label != null ) this.label.setDrawingComponent$java_awt_Component(this.g2d);
if (this.exponent != null ) this.exponent.setDrawingComponent$java_awt_Component(this.g2d);
if (this.orientation == 0) {
this.drawHAxis$java_awt_Graphics(lg);
} else {
this.drawVAxis$java_awt_Graphics(lg);
}lg.dispose();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
;} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'setTitleText$S', function (s) {
this.title.setText$S(s);
});

Clazz.newMeth(C$, 'setTitleBackground$java_awt_Color', function (c) {
this.title.setBackground$java_awt_Color(c);
});

Clazz.newMeth(C$, 'setTitleColor$java_awt_Color', function (c) {
this.title.setColor$java_awt_Color(c);
});

Clazz.newMeth(C$, 'setTitleFont$java_awt_Font', function (f) {
this.title.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$, 'setTitleRotation$I', function (a) {
this.title.setRotation$I(a);
});

Clazz.newMeth(C$, 'setLabelColor$java_awt_Color', function (c) {
this.label.setColor$java_awt_Color(c);
});

Clazz.newMeth(C$, 'setLabelFont$java_awt_Font', function (f) {
this.label.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$, 'setExponentColor$java_awt_Color', function (c) {
this.exponent.setColor$java_awt_Color(c);
});

Clazz.newMeth(C$, 'setExponentFont$java_awt_Font', function (f) {
this.exponent.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$, 'isManualRange', function () {
return this.manualRange;
});

Clazz.newMeth(C$, 'setManualRange$Z', function (b) {
this.manualRange=b;
this.resetRange();
if (this.manualRange && this.maximum == this.minimum  ) {
this.maximum=this.minimum + 1.0E-6;
}this.calculateGridLabels();
});

Clazz.newMeth(C$, 'setManualRange$Z$D$D', function (b, min, max) {
this.manualRange=b;
this.minimum=min;
this.maximum=max;
this.resetRange();
this.calculateGridLabels();
});

Clazz.newMeth(C$, 'drawHAxis$java_awt_Graphics', function (g) {
var lg;
var i;
var j;
var x0;
var y0;
var x1;
var y1;
var direction;
var offset;
var minor_step;
var c;
var range = this.maximum - this.minimum;
var vmin = this.minimum - range * 1.0E-4;
var vmax = this.maximum + range * 1.0E-4;
var scale = (this.amax.x - this.amin.x) / (this.maximum - this.minimum);
var val;
var minor;
if (this.axiscolor != null ) g.setColor$java_awt_Color(this.axiscolor);
if (this.g2d.showAxis) g.drawLine$I$I$I$I(this.amin.x, this.amin.y, this.amax.x, this.amax.y);
if (this.position == 4) direction=1;
 else direction=-1;
minor_step=this.label_step / (this.minor_tic_count + 1);
val=this.label_start;
for (i=0; i < this.label_count; i++) {
if (val >= vmin  && val <= vmax  ) {
y0=this.amin.y;
x0=this.amin.x + (((val - this.minimum) * scale)|0);
if (Math.abs(this.label_value[i]) <= 1.0E-4  && this.drawzero ) {
c=g.getColor();
if (this.zerocolor != null ) g.setColor$java_awt_Color(this.zerocolor);
if (this.g2d.showAxis) g.drawLine$I$I$I$I(x0, y0, x0, y0 + this.data_window.height * direction);
g.setColor$java_awt_Color(c);
} else if (this.drawgrid) {
c=g.getColor();
if (this.gridcolor != null ) g.setColor$java_awt_Color(this.gridcolor);
g.drawLine$I$I$I$I(x0, y0, x0, y0 + this.data_window.height * direction);
g.setColor$java_awt_Color(c);
}x1=x0;
y1=y0 + this.major_tic_size * direction;
if (this.g2d.showAxis) g.drawLine$I$I$I$I(x0, y0, x1, y1);
}minor=val + minor_step;
for (j=0; j < this.minor_tic_count; j++) {
if (minor >= vmin  && minor <= vmax  ) {
y0=this.amin.y;
x0=this.amin.x + (((minor - this.minimum) * scale)|0);
if (this.drawgrid) {
c=g.getColor();
if (this.gridcolor != null ) g.setColor$java_awt_Color(this.gridcolor);
if (this.g2d.showAxis) g.drawLine$I$I$I$I(x0, y0, x0, y0 + this.data_window.height * direction);
g.setColor$java_awt_Color(c);
}x1=x0;
y1=y0 + this.minor_tic_size * direction;
if (this.g2d.showAxis) g.drawLine$I$I$I$I(x0, y0, x1, y1);
}minor += minor_step;
}
val += this.label_step;
}
if (this.position == 4) {
offset=-this.label.getLeading$java_awt_Graphics(g) - this.label.getDescent$java_awt_Graphics(g);
} else {
offset=+this.label.getLeading$java_awt_Graphics(g) + this.label.getAscent$java_awt_Graphics(g);
}val=this.label_start;
for (i=0; i < this.label_count; i++) {
if (val >= vmin  && val <= vmax  ) {
y0=this.amin.y + offset;
x0=this.amin.x + (((val - this.minimum) * scale)|0);
this.label.setText$S(this.label_string[i]);
this.label.draw$java_awt_Graphics$I$I$I(g, x0, y0, 0);
}val += this.label_step;
}
if (!this.exponent.isNull()) {
x0=this.amax.x;
if (this.position == 4) {
y0=this.amin.y - this.label.getLeading$java_awt_Graphics(g) - this.label.getDescent$java_awt_Graphics(g) - this.exponent.getLeading$java_awt_Graphics(g) - this.exponent.getDescent$java_awt_Graphics(g) ;
} else {
y0=this.amax.y + this.label.getLeading$java_awt_Graphics(g) + this.label.getAscent$java_awt_Graphics(g) + this.exponent.getLeading$java_awt_Graphics(g) + this.exponent.getAscent$java_awt_Graphics(g) ;
x0=x0 - 25;
}this.exponent.draw$java_awt_Graphics$I$I$I(g, x0, y0, 1);
}if (!this.title.isNull()) {
if (this.position == 4) {
y0=this.amin.y - this.label.getLeading$java_awt_Graphics(g) - this.label.getDescent$java_awt_Graphics(g) - this.title.getLeading$java_awt_Graphics(g) - this.title.getDescent$java_awt_Graphics(g) ;
} else {
y0=this.amax.y + this.label.getLeading$java_awt_Graphics(g) + this.label.getAscent$java_awt_Graphics(g) + this.title.getLeading$java_awt_Graphics(g) + this.title.getAscent$java_awt_Graphics(g) ;
}x0=this.amin.x + ((this.amax.x - this.amin.x)/2|0);
this.title.draw$java_awt_Graphics$I$I$I(g, x0, y0, 0);
}});

Clazz.newMeth(C$, 'drawVAxis$java_awt_Graphics', function (g) {
var lg;
var i;
var j;
var x0;
var y0;
var x1;
var y1;
var direction;
var offset = 0;
var minor_step;
var minor;
var c;
var fm;
var gc = g.getColor();
var gf = g.getFont();
var range = this.maximum - this.minimum;
var vmin = this.minimum - range * 1.0E-4;
var vmax = this.maximum + range * 1.0E-4;
var scale = (this.amax.y - this.amin.y) / (this.maximum - this.minimum);
var val;
if (this.axiscolor != null ) g.setColor$java_awt_Color(this.axiscolor);
if (this.g2d.showAxis) g.drawLine$I$I$I$I(this.amin.x, this.amin.y, this.amax.x, this.amax.y);
if (this.position == 3) direction=-1;
 else direction=1;
minor_step=this.label_step / (this.minor_tic_count + 1);
val=this.label_start;
for (i=0; i < this.label_count; i++) {
if (val >= vmin  && val <= vmax  ) {
x0=this.amin.x;
y0=this.amax.y - (((val - this.minimum) * scale)|0);
if (Math.abs(this.label_value[i]) <= 1.0E-4  && this.drawzero ) {
c=g.getColor();
if (this.zerocolor != null ) g.setColor$java_awt_Color(this.zerocolor);
if (this.g2d.showAxis) g.drawLine$I$I$I$I(x0, y0, x0 + this.data_window.width * direction, y0);
g.setColor$java_awt_Color(c);
} else if (this.drawgrid) {
c=g.getColor();
if (this.gridcolor != null ) g.setColor$java_awt_Color(this.gridcolor);
g.drawLine$I$I$I$I(x0, y0, x0 + this.data_window.width * direction, y0);
g.setColor$java_awt_Color(c);
}x1=x0 + this.major_tic_size * direction;
y1=y0;
if (this.g2d.showAxis) g.drawLine$I$I$I$I(x0, y0, x1, y1);
}minor=val + minor_step;
for (j=0; j < this.minor_tic_count; j++) {
if (minor >= vmin  && minor <= vmax  ) {
x0=this.amin.x;
y0=this.amax.y - (((minor - this.minimum) * scale)|0);
if (this.drawgrid) {
c=g.getColor();
if (this.gridcolor != null ) g.setColor$java_awt_Color(this.gridcolor);
if (this.g2d.showAxis) g.drawLine$I$I$I$I(x0, y0, x0 + this.data_window.width * direction, y0);
g.setColor$java_awt_Color(c);
}x1=x0 + this.minor_tic_size * direction;
y1=y0;
if (this.g2d.showAxis) g.drawLine$I$I$I$I(x0, y0, x1, y1);
}minor += minor_step;
}
val += this.label_step;
}
val=this.label_start;
for (i=0; i < this.label_count; i++) {
if (val >= vmin  && val <= vmax  ) {
x0=this.amin.x + offset;
y0=this.amax.y - (((val - this.minimum) * scale)|0) + (this.label.getAscent$java_awt_Graphics(g)/2|0);
if (this.position == 3) {
this.label.setText$S(" " + this.label_string[i]);
this.label.draw$java_awt_Graphics$I$I$I(g, x0, y0, 1);
} else {
this.label.setText$S(this.label_string[i] + " ");
this.label.draw$java_awt_Graphics$I$I$I(g, x0, y0, 2);
}}val += this.label_step;
}
if (!this.exponent.isNull()) {
y0=this.amin.y;
if (this.position == 3) {
x0=this.amin.x + this.max_label_width + this.exponent.charWidth$java_awt_Graphics$C(g, " ") ;
this.exponent.draw$java_awt_Graphics$I$I$I(g, x0, y0, 1);
} else {
x0=this.amin.x - this.max_label_width - this.exponent.charWidth$java_awt_Graphics$C(g, " ") ;
y0=y0 + 5;
x0=x0 + 3;
this.exponent.draw$java_awt_Graphics$I$I$I(g, x0, y0, 2);
}}if (!this.title.isNull()) {
y0=this.amin.y + ((this.amax.y - this.amin.y)/2|0);
if (this.title.getRotation() == 0 || this.title.getRotation() == 180 ) {
if (this.position == 3) {
x0=this.amin.x + this.max_label_width + this.title.charWidth$java_awt_Graphics$C(g, " ") ;
this.title.draw$java_awt_Graphics$I$I$I(g, x0, y0, 1);
} else {
x0=this.amin.x - this.max_label_width - this.title.charWidth$java_awt_Graphics$C(g, " ") ;
this.title.draw$java_awt_Graphics$I$I$I(g, x0, y0, 2);
}} else {
this.title.setJustification$I(0);
if (this.position == 3) {
x0=this.amin.x + this.max_label_width - this.title.getLeftEdge$java_awt_Graphics(g) + +this.title.charWidth$java_awt_Graphics$C(g, " ");
} else {
x0=this.amin.x - this.max_label_width - this.title.getRightEdge$java_awt_Graphics(g) - this.title.charWidth$java_awt_Graphics$C(g, " ") ;
}this.title.draw$java_awt_Graphics$I$I(g, x0, y0);
}}});

Clazz.newMeth(C$, 'attachXdata$edu_davidson_graph_DataSet', function (d) {
this.dataset.addElement$TE(d);
d.xaxis=this;
if (this.manualRange) return;
if (this.dataset.size() == 1) {
this.minimum=d.dxmin;
this.maximum=d.dxmax;
} else {
if (this.minimum > d.dxmin ) this.minimum=d.dxmin;
if (this.maximum < d.dxmax ) this.maximum=d.dxmax;
}});

Clazz.newMeth(C$, 'attachYdata$edu_davidson_graph_DataSet', function (d) {
this.dataset.addElement$TE(d);
d.yaxis=this;
if (this.manualRange) return;
if (this.dataset.size() == 1) {
this.minimum=d.dymin;
this.maximum=d.dymax;
} else {
if (this.minimum > d.dymin ) this.minimum=d.dymin;
if (this.maximum < d.dymax ) this.maximum=d.dymax;
}});

Clazz.newMeth(C$, 'calculateGridLabels', function () {
var val;
var i;
var j;
if (Math.abs(this.minimum) == 0  && Math.abs(this.maximum) == 0  ) {
this.maximum=this.minimum + 1.0E-6;
}if (Math.abs(this.minimum) > Math.abs(this.maximum) ) this.label_exponent=((Math.floor((I$[6]||$incl$(6)).log10$D(Math.abs(this.minimum)) / 3.0)|0)) * 3;
 else this.label_exponent=((Math.floor((I$[6]||$incl$(6)).log10$D(Math.abs(this.maximum)) / 3.0)|0)) * 3;
this.label_step=p$.RoundUp$D.apply(this, [(this.maximum - this.minimum) / this.guess_label_number]);
this.label_start=Math.floor(this.minimum / this.label_step) * this.label_step;
val=this.label_start;
this.label_count=1;
while (val < this.maximum ){
val += this.label_step;
this.label_count++;
}
this.label_string=Clazz.array(java.lang.String, [this.label_count]);
this.label_value=Clazz.array(Float.TYPE, [this.label_count]);
for (i=0; i < this.label_count; i++) {
val=this.label_start + i * this.label_step;
if (this.label_exponent < 0) {
for (j=this.label_exponent; j < 0; j++) {
val *= 10;
}
} else {
for (j=0; j < this.label_exponent; j++) {
val /= 10;
}
}this.label_string[i]=this.labelFormat.form$D(val);
this.label_value[i]=val;
}
});

Clazz.newMeth(C$, 'RoundUp$D', function (val) {
var exponent;
var i;
exponent=((Math.floor((I$[6]||$incl$(6)).log10$D(val)))|0);
if (exponent < 0) {
for (i=exponent; i < 0; i++) {
val *= 10.0;
}
} else {
for (i=0; i < exponent; i++) {
val /= 10.0;
}
}if (val > 5.0 ) val=10.0;
 else if (val > 2.0 ) val=5.0;
 else if (val > 1.0 ) val=2.0;
 else val=1.0;
if (exponent < 0) {
for (i=exponent; i < 0; i++) {
val /= 10.0;
}
} else {
for (i=0; i < exponent; i++) {
val *= 10.0;
}
}return val;
});
})();
//Created 2018-07-23 12:59:46 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
