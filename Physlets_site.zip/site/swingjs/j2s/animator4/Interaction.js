(function(){var P$=Clazz.newPackage("animator4"),I$=[['edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Interaction");
C$.XMODE = 0;
C$.YMODE = 0;
C$.RMODE = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.XMODE = 0;
C$.YMODE = 1;
C$.RMODE = 2;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.thing1 = null;
this.thing2 = null;
this.fStr = null;
this.force = null;
this.v = null;
this.zero = null;
this.mode = 0;
this.parserVars = null;
this.oldDx = 0;
this.oldDy = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.force = null;
this.v = Clazz.array(Double.TYPE, [2]);
this.zero = Clazz.array(Double.TYPE, [2]);
this.mode = C$.RMODE;
this.parserVars = Clazz.array(Double.TYPE, [5]);
this.oldDx = 0;
this.oldDy = 0;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_Thing$animator4_Thing$S$I', function (me, t2, str, m) {
C$.$init$.apply(this);
this.mode = m;
this.thing1 = me;
this.thing2 = t2;
this.fStr = str;
this.force = Clazz.new_((I$[1]||$incl$(1)).c$$I,[5]);
this.force.defineVariable$I$S(1, "t");
this.force.defineVariable$I$S(2, "x");
this.force.defineVariable$I$S(3, "y");
this.force.defineVariable$I$S(4, "r");
this.force.defineVariable$I$S(5, "v");
this.force.define$S(this.fStr);
this.force.parse();
if (this.force.getErrorCode() != 0) {
System.out.println$S("Failed to parse interaction force(): " + str);
System.out.println$S("Parse error: " + this.force.getErrorString() + " in Interaction at position " + this.force.getErrorPosition() );
this.force = null;
}}, 1);

Clazz.newMeth(C$, 'getF', function () {
if (this.force == null ) {
return this.zero;
}var dx = this.thing1.vars[1] - this.thing2.vars[1];
var dy = this.thing1.vars[2] - this.thing2.vars[2];
var dvx = this.thing1.vars[3] - this.thing2.vars[3];
var dvy = this.thing1.vars[4] - this.thing2.vars[4];
var r = Math.sqrt(dx * dx + dy * dy);
var vel = Math.sqrt(dvx * dvx + dvy * dvy);
var dot = (dx * dvx + dy * dvy);
if (dot != 0 ) vel = vel * dot / Math.abs(dot);
 else vel = 0;
if (r == 0  || (dx == 0  && this.mode == C$.XMODE )  || (dy == 0  && this.mode == C$.YMODE ) ) {
this.parserVars[0] = this.thing1.vars[0];
this.parserVars[1] = Math.abs(dx);
this.parserVars[2] = Math.abs(dy);
this.parserVars[3] = r;
this.parserVars[4] = vel;
this.oldDx = dx;
this.oldDy = dy;
return this.zero;
}if (this.oldDx == dx  && this.oldDy == dy   && this.parserVars[3] == r   && this.parserVars[4] == vel   && this.parserVars[0] == this.thing1.vars[0]  ) return this.v;
this.parserVars[0] = this.thing1.vars[0];
this.oldDx = dx;
this.oldDy = dy;
this.parserVars[1] = Math.abs(dx);
this.parserVars[2] = Math.abs(dy);
this.parserVars[3] = r;
this.parserVars[4] = vel;
var f = this.force.evaluate$DA(this.parserVars);
if (this.mode == C$.XMODE) {
this.v[0] = f * dx / Math.abs(dx);
this.v[1] = 0;
} else if (this.mode == C$.YMODE) {
this.v[0] = 0;
this.v[1] = f * dy / Math.abs(dy);
} else {
this.v[0] = f * dx / r;
this.v[1] = f * dy / r;
}return this.v;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:10
