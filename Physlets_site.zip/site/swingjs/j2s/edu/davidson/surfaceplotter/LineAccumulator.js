(function(){var P$=Clazz.newPackage("edu.davidson.surfaceplotter"),I$=[['java.util.Vector','edu.davidson.surfaceplotter.LineRecord']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "LineAccumulator");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.accumulator = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.accumulator = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'addLine$I$I$I$I', function (x1, y1, x2, y2) {
this.accumulator.addElement$TE(Clazz.new_((I$[2]||$incl$(2)).c$$I$I$I$I,[x1, y1, x2, y2]));
});

Clazz.newMeth(C$, 'clearAccumulator', function () {
this.accumulator.removeAllElements();
});

Clazz.newMeth(C$, 'drawAll$java_awt_Graphics', function (g) {
var enumeration = this.accumulator.elements();
while (enumeration.hasMoreElements()){
var line = (enumeration.nextElement());
g.drawLine$I$I$I$I(line.x1, line.y1, line.x2, line.y2);
}
});
})();
//Created 2018-02-06 13:05:27
