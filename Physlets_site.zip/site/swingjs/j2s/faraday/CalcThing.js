(function(){var P$=Clazz.newPackage("faraday"),I$=[['java.awt.Font','edu.davidson.numerics.Parser','edu.davidson.tools.SUtil','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CalcThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.tempVars = null;
this.calcStr = null;
this.calcFunc = null;
this.schematic = null;
this.text = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.tempVars = Clazz.array(Double.TYPE, [5]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$faraday_Schematic$S$S$D$D', function (owner, panel, txt, cs, x, y) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [panel, x, y]);
C$.$init$.apply(this);
this.schematic = panel;
this.applet = owner;
this.font = Clazz.new_((I$[1]||$incl$(1)).c$$S$I$I,["Helvetica", 1, 14]);
this.text = txt;
this.calcStr = cs;
if (this.calcStr == null ) return;
this.calcFunc = Clazz.new_((I$[2]||$incl$(2)).c$$I,[5]);
this.calcFunc.defineVariable$I$S(1, "t");
this.calcFunc.defineVariable$I$S(2, "x");
this.calcFunc.defineVariable$I$S(3, "y");
this.calcFunc.defineVariable$I$S(4, "flux");
this.calcFunc.defineVariable$I$S(5, "v");
this.calcFunc.define$S(this.calcStr);
this.calcFunc.parse();
if (this.calcFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse calc-text: " + this.calcStr);
System.out.println$S("Parse error: " + this.calcFunc.getErrorString() + " at function 1, position " + this.calcFunc.getErrorPosition() );
return;
}}, 1);

Clazz.newMeth(C$, 'getText', function () {
var val = 0;
var myMaster = this.getMaster();
if (this.calcStr == null  || this.calcFunc == null  ) return this.text;
if (myMaster != null ) {
this.tempVars[0] = this.schematic.time;
this.tempVars[1] = myMaster.getX();
this.tempVars[2] = myMaster.getY();
if (Clazz.instanceOf(myMaster, "faraday.Fluxable")) {
this.tempVars[3] = (myMaster).getFlux();
this.tempVars[4] = (myMaster).getVolt();
}} else {
this.tempVars[0] = this.schematic.time;
this.tempVars[1] = this.x;
this.tempVars[2] = this.y;
this.tempVars[3] = 0;
this.tempVars[4] = 0;
}try {
val = this.calcFunc.evaluate$DA(this.tempVars);
val = (I$[3]||$incl$(3)).chop$D$D(val, 1.0E-8);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return this.text + " " + this.format.form$D(val) ;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var f = g.getFont();
g.setFont$java_awt_Font(this.font);
var ptX = Math.round(this.canvas.pixFromX$D(this.x)) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.y)) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.drawString$S$I$I(this.getText(), ptX, ptY);
g.setColor$java_awt_Color((I$[4]||$incl$(4)).black);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:17
