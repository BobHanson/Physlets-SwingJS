(function(){var P$=Clazz.newPackage("circuit"),p$1={},I$=[[0,'java.awt.Color','edu.davidson.numerics.Parser','edu.davidson.graphics.EtchedBorder','edu.davidson.display.SSlider','edu.davidson.display.SNumber','circuit.Circuit',['circuit.IZApplet','.IZGraph'],'java.awt.BorderLayout','java.awt.Panel','java.awt.Label','java.awt.Checkbox','circuit.Common','Boolean','java.awt.Dimension','circuit.IZApplet_fNumber_actionAdapter','circuit.IZApplet_fSlider_adjustmentAdapter','circuit.IZApplet_checkbox1_itemAdapter','java.net.URL']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "IZApplet", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SStepable');
C$.sqrt2=0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.sqrt2=Math.sqrt(2);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.ivFunc=null;
this.phaseFunc=null;
this.labelY=null;
this.fmin=0;
this.fmax=0;
this.imax=0;
this.freqVal=0;
this.tmax=0;
this.showControls=false;
this.showCheckBox=false;
this.showGraph=false;
this.showVoltage=false;
this.showCurrent=false;
this.customCircuit=false;
this.$autoRefresh=false;
this.defaultCircuit=false;
this.showIF=false;
this.volt=0;
this.preferredPixPerCell=0;
this.showAmmeterPhase=false;
this.currentStr=null;
this.phaseStr=null;
this.etchedBorder1=null;
this.etchedBorder2=null;
this.fSlider=null;
this.fNumber=null;
this.circuit=null;
this.graph=null;
this.borderLayout1=null;
this.borderLayout2=null;
this.borderLayout3=null;
this.xold=0;
this.yold=0;
this.bat=null;
this.voltmeter=null;
this.ammeter=null;
this.part=null;
this.panel1=null;
this.label1=null;
this.checkbox1=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.ivFunc=Clazz.new_($I$(2).c$$I,[2]);
this.phaseFunc=Clazz.new_($I$(2).c$$I,[1]);
this.labelY=null;
this.imax=10;
this.freqVal=60.0;
this.tmax=0.1;
this.showControls=true;
this.showCheckBox=true;
this.showGraph=true;
this.showVoltage=true;
this.showCurrent=true;
this.customCircuit=false;
this.$autoRefresh=true;
this.defaultCircuit=true;
this.showIF=false;
this.volt=10;
this.preferredPixPerCell=60;
this.showAmmeterPhase=false;
this.currentStr="V";
this.phaseStr="0";
this.etchedBorder1=Clazz.new_($I$(3));
this.etchedBorder2=Clazz.new_($I$(3));
this.fSlider=Clazz.new_($I$(4));
this.fNumber=Clazz.new_($I$(5));
this.circuit=Clazz.new_($I$(6).c$$edu_davidson_tools_SApplet,[this]);
this.graph=Clazz.new_($I$(7), [this, null]);
this.borderLayout1=Clazz.new_($I$(8));
this.borderLayout2=Clazz.new_($I$(8));
this.borderLayout3=Clazz.new_($I$(8));
this.panel1=Clazz.new_($I$(9));
this.label1=Clazz.new_($I$(10));
this.checkbox1=Clazz.new_($I$(11));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'parseIVFunction$', function () {
this.ivFunc.defineVariable$I$S(1, "v");
this.ivFunc.defineVariable$I$S(2, "f");
this.ivFunc.define$S(this.currentStr.toLowerCase$());
this.ivFunc.parse$();
if (this.ivFunc.getErrorCode$() != 0) {
System.out.println$S("Failed to parse I(V,f): " + this.currentStr);
System.out.println$S("Parse error: " + this.ivFunc.getErrorString$() + " at IV function, position " + this.ivFunc.getErrorPosition$() );
return false;
}p$1.setCircuitValues.apply(this, []);
this.calcCurrentIMax$();
return true;
});

Clazz.newMeth(C$, 'parsePhaseFunction$', function () {
this.phaseFunc.defineVariable$I$S(1, "f");
this.phaseFunc.define$S(this.phaseStr.toLowerCase$());
this.phaseFunc.parse$();
if (this.phaseFunc.getErrorCode$() != 0) {
System.out.println$S("Failed to parse phase(f): " + this.phaseStr);
System.out.println$S("Parse error: " + this.phaseFunc.getErrorString$() + " at phase function, position " + this.phaseFunc.getErrorPosition$() );
return false;
}p$1.setCircuitValues.apply(this, []);
this.calcCurrentIMax$();
return true;
});

Clazz.newMeth(C$, 'firstTime', function () {
this.graph.setBorders$S("0,10,10,5");
this.graph.setMinMaxX$D$D(this.fmin, this.fmax);
this.graph.setMinMaxY$D$D(-1, 1);
this.graph.setEnableMouse$Z(true);
this.graph.setBackground$java_awt_Color($I$(1).white);
if (this.showIF) {
this.fSlider.setDMinMaxAndValue$D$D$D(this.fmin, this.fmax, this.freqVal);
this.graph.setAutoscaleY$Z(true);
if (this.labelY == null ) this.graph.setLabelY$S($I$(12).CURRENT);
 else this.graph.setLabelY$S(this.labelY);
this.graph.setLabelX$S($I$(12).FREQUENCY);
this.graph.setMinMaxX$D$D(this.fmin, this.fmax);
} else {
this.volt=Math.abs(this.volt);
this.fSlider.setDMinMaxAndValue$D$D$D(this.fmin, this.fmax, this.freqVal);
this.graph.setAutoscaleY$Z(false);
if (this.labelY == null ) this.graph.setLabelY$S($I$(12).VOLTAGE_CURRENT);
 else this.graph.setLabelY$S(this.labelY);
this.graph.setLabelX$S($I$(12).TIME);
this.graph.setMinMaxX$D$D(0, this.tmax);
this.graph.setMinMaxY$D$D(Math.min(1.1 * this.findYMin$(), 0.9 * this.findYMin$()), Math.max(1.2 * this.findYMax$(), 0.8 * this.findYMax$()));
}if (this.defaultCircuit) {
p$1.createCircuit.apply(this, []);
p$1.setCircuitValues.apply(this, []);
this.plotFunction$();
this.graph.setVisible$Z(this.showGraph);
} else {
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
this.circuit.setGridSize$I$I(3, 2);
this.showGraph=false;
this.graph.setVisible$Z(false);
}this.graph.setOwner$edu_davidson_tools_SApplet(this);
this.graph.repaint$();
}, p$1);

Clazz.newMeth(C$, ['init$','init'], function () {
this.initResources$S(null);
var dt=0.1;
var fps=10;
var resourceFile="";
try {
resourceFile=this.getParameter$S$S("Resources", "");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
if (resourceFile != null  && !resourceFile.equals$O("") ) this.loadResources$S(resourceFile);
try {
fps=Double.valueOf$S(this.getParameter$S$S("FPS", "10")).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
dt=Double.valueOf$S(this.getParameter$S$S("dt", "0.1")).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.defaultCircuit=$I$(13).valueOf$S(this.getParameter$S$S("DefaultCircuit", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.currentStr=this.getParameter$S$S("Current", "2*V");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.phaseStr=this.getParameter$S$S("Phase", "0");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.fmin=Double.valueOf$S(this.getParameter$S$S("Fmin", "10")).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.fmax=Double.valueOf$S(this.getParameter$S$S("Fmax", "500")).doubleValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.showControls=$I$(13).valueOf$S(this.getParameter$S$S("ShowControls", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.showGraph=$I$(13).valueOf$S(this.getParameter$S$S("ShowGraph", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
if (this.showGraph) this.preferredPixPerCell=60;
 else this.preferredPixPerCell=200;
try {
this.showCheckBox=$I$(13).valueOf$S(this.getParameter$S$S("ShowCheckBox", "true")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.showIF=$I$(13).valueOf$S(this.getParameter$S$S("ImpedanceGraphType", "false")).booleanValue$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
this.preferredPixPerCell=Integer.parseInt$S(this.getParameter$S$S("PixPerCell", "" + this.preferredPixPerCell));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.clock.setDt$D(dt);
this.clock.setFPS$D((fps|0));
this.fSlider.setDMax$D(this.fmax);
this.fSlider.setDMin$D(this.fmin);
this.freqVal=(this.fmax + this.fmin) / 2;
this.fNumber.setValue$D(this.freqVal);
this.fSlider.setDValue$D(this.freqVal);
this.tmax=10.0 / this.fmax;
this.parseIVFunction$();
this.parsePhaseFunction$();
this.checkbox1.setState$Z(!this.showIF);
this.checkbox1.setVisible$Z(this.showCheckBox);
this.etchedBorder2.setVisible$Z(this.showControls);
this.fNumber.addPropertyChangeListener$java_beans_PropertyChangeListener(this.fSlider);
this.fSlider.addPropertyChangeListener$java_beans_PropertyChangeListener(this.fNumber);
if (this.fmax < 100 ) this.fNumber.setFormat$S("%6.1f");
 else this.fNumber.setFormat$S("%6.0f");
if (this.freqVal != 0 ) this.tmax=3.0 / this.freqVal;
 else this.tmax=1.0;
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setBackground$java_awt_Color($I$(1).lightGray);
{
this.setSize$java_awt_Dimension(Clazz.new_($I$(14).c$$I$I,[740, 390]));
}this.fSlider.setDMax$D(10.0);
this.fNumber.addActionListener$java_awt_event_ActionListener(Clazz.new_($I$(15).c$$circuit_IZApplet,[this]));
this.fSlider.addAdjustmentListener$java_awt_event_AdjustmentListener(Clazz.new_($I$(16).c$$circuit_IZApplet,[this]));
this.panel1.setBackground$java_awt_Color($I$(1).lightGray);
this.graph.setLabelY$S($I$(12).CURRENT);
this.label1.setAlignment$I(2);
this.label1.setText$S($I$(12).FREQUENCY);
this.checkbox1.setLabel$S($I$(12).LEGEND_VTIME);
this.checkbox1.addItemListener$java_awt_event_ItemListener(Clazz.new_($I$(17).c$$circuit_IZApplet,[this]));
this.graph.setSampleData$Z(false);
this.graph.setAutoscaleX$Z(false);
this.graph.setAutoscaleY$Z(false);
this.graph.setLabelX$S($I$(12).FREQUENCY);
this.etchedBorder2.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.add$java_awt_Component$O(this.etchedBorder1, "Center");
this.etchedBorder1.add$java_awt_Component$O(this.circuit, "West");
this.etchedBorder1.add$java_awt_Component$O(this.graph, "Center");
this.add$java_awt_Component$O(this.etchedBorder2, "South");
this.etchedBorder2.add$java_awt_Component$O(this.fSlider, "Center");
this.etchedBorder2.add$java_awt_Component$O(this.fNumber, "East");
this.etchedBorder2.add$java_awt_Component$O(this.panel1, "West");
this.panel1.add$java_awt_Component$O(this.checkbox1, null);
this.panel1.add$java_awt_Component$O(this.label1, null);
}, p$1);

Clazz.newMeth(C$, 'loadResources$S', function (rc) {
if (rc == null ) return;
try {
$I$(12).initResources$java_io_InputStream(Clazz.new_($I$(18).c$$java_net_URL$S,[this.getCodeBase$(), rc]).openStream$());
$I$(12).setResources$();
return;
} catch (x) {
if (Clazz.exceptionOf(x,"Exception")){
} else {
throw x;
}
}
try {
$I$(12).initResources$java_io_InputStream(Clazz.new_($I$(18).c$$java_net_URL$S,[this.getDocumentBase$(), rc]).openStream$());
$I$(12).setResources$();
} catch (x) {
if (Clazz.exceptionOf(x,"Exception")){
System.out.println$S("Can't load resources! : " + x.getMessage$());
return;
} else {
throw x;
}
}
});

Clazz.newMeth(C$, ['destroy$','destroy'], function () {
if (this.debugLevel > 127) System.out.println$S("begin IZApplet destroy");
this.circuit.forceBubbleHelp$S(null);
this.circuit.destroyHint$();
this.graph.destroy$();
C$.superclazz.prototype.destroy$.apply(this, []);
if (this.debugLevel > 127) System.out.println$S("end IZApplet destroy");
});

Clazz.newMeth(C$, ['start$','start'], function () {
if (this.debugLevel > 127) System.out.println$S("begin IZApplet start");
if (this.firstTime) {
this.firstTime=false;
p$1.firstTime.apply(this, []);
} else this.graph.repaint$();
C$.superclazz.prototype.start$.apply(this, []);
if (this.debugLevel > 127) System.out.println$S("end IZApplet start");
});

Clazz.newMeth(C$, ['stop$','stop'], function () {
this.oneShotMsg=null;
this.circuit.forceBubbleHelp$S(null);
C$.superclazz.prototype.stop$.apply(this, []);
});

Clazz.newMeth(C$, ['forward$','forward'], function () {
this.circuit.forceBubbleHelp$S(null);
C$.superclazz.prototype.forward$.apply(this, []);
});

Clazz.newMeth(C$, 'stoppingClock$', function () {
this.circuit.forceBubbleHelp$S(this.oneShotMsg);
});

Clazz.newMeth(C$, 'cyclingClock$', function () {
this.clock.setTime$D(0);
this.part.setTime$D(0);
this.clearAllData$();
});

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'], function () {
return "IZApplet by Wolfgang Christian, wochristian@davidson.edu";
});

Clazz.newMeth(C$, ['getParameterInfo$','getParameterInfo'], function () {
var pinfo=Clazz.array(String, -2, [Clazz.array(String, -1, ["Current", "String", "Current: I(V,f)"]), Clazz.array(String, -1, ["Phase", "String", "Phase: P(f)"]), Clazz.array(String, -1, ["Vmin", "double", "Minimum frequency"]), Clazz.array(String, -1, ["VMax", "double", "Maximum frequency."]), Clazz.array(String, -1, ["ShowControls", "boolean", "Show the slider."]), Clazz.array(String, -1, ["ShowCheckBox", "boolean", "Show the check box."]), Clazz.array(String, -1, ["ImpedanceGraphType", "boolean", "Plot I(f) graph instead of I(t) and V(t)."])]);
return pinfo;
});

Clazz.newMeth(C$, ['getUnknownID$','getUnknownID'], function () {
return this.part.getID$();
});

Clazz.newMeth(C$, 'createCustomCircuit', function () {
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
}, p$1);

Clazz.newMeth(C$, 'createCircuit', function () {
if (this.customCircuit) {
p$1.createCustomCircuit.apply(this, []);
return;
}this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
this.circuit.setGridSize$I$I(3, 2);
this.bat=this.circuit.addSineWave$I$I$I$I(0, 0, 0, 1);
this.bat.setVoltRMS$D(this.volt);
this.bat.showPhase=false;
this.bat.showF=true;
this.bat.showV=false;
this.part=this.circuit.addPart$I$I$I$I(1, 0, 1, 1);
this.part.setLabel$S("  ?");
this.part.showR=false;
this.part.showV=false;
this.part.showZ=false;
this.part.showPhase=false;
this.circuit.addWire$I$I$I$I(0, 0, 1, 0);
this.ammeter=this.circuit.addAmmeter$I$I$I$I(0, 1, 1, 1);
if (this.showAmmeterPhase) this.ammeter.showPhase=true;
this.circuit.addWire$I$I$I$I(1, 0, 2, 0);
this.circuit.addWire$I$I$I$I(1, 1, 2, 1);
this.voltmeter=this.circuit.addVoltmeter$I$I$I$I(2, 0, 2, 1);
if (this.freqVal == 0 ) {
this.bat.setLabel$S(" V");
this.ammeter.setLabel$S("A");
this.voltmeter.setLabel$S("V");
this.bat.showF=false;
} else {
this.bat.setLabel$S("Vac");
this.ammeter.setLabel$S("A");
this.voltmeter.setLabel$S("V");
this.bat.showF=true;
}}, p$1);

Clazz.newMeth(C$, 'setCircuitValues', function () {
if (this.customCircuit) {
return;
}if (this.bat == null ) return;
this.bat.setVoltRMS$D(this.volt);
this.bat.setF$D(this.freqVal);
this.voltmeter.setVoltRMS$D(this.volt);
this.ammeter.setCurrentRMS$D(this.calcCurrentRMS$());
this.part.setVoltRMS$D(this.volt);
var w=6.283185307179586 * this.freqVal;
var t=this.clock.getTime$();
var rad=this.phaseFunc.evaluate$D(this.freqVal);
var v=this.volt * C$.sqrt2 * Math.sin(w * t - rad) ;
var i=this.ivFunc.evaluate$D$D(this.volt * Math.sin(w * t), this.freqVal);
this.part.setVoltInstantaneous$D(v);
this.part.setCurrentInstantaneous$D(i);
this.part.setPhaseRadian$D(rad);
this.part.setF$D(this.freqVal);
if (this.showAmmeterPhase) this.ammeter.setPhaseRadian$D(this.phaseFunc.evaluate$D(this.freqVal));
}, p$1);

Clazz.newMeth(C$, 'calcCurrentIMax$', function () {
var np=200;
var df=(this.fmax - this.fmin) / (np - 1);
var f=this.fmin;
this.imax=this.ivFunc.evaluate$D$D(this.volt, this.fmin);
for (var i=0; i < np; i++) {
f += df;
this.imax=Math.max(this.imax, this.ivFunc.evaluate$D$D(this.volt, f));
}
});

Clazz.newMeth(C$, 'calcCurrentRMS$', function () {
if (this.freqVal == 0 ) return this.ivFunc.evaluate$D$D(this.volt, this.freqVal);
var np=32;
var dt=1.0 / (np - 1.0);
var t=0;
var v=0;
var c=this.ivFunc.evaluate$D$D(v, this.freqVal);
var sum=c;
for (var i=0; i < np - 2; i++) {
t += dt;
v=this.volt * Math.sin(6.283185307179586 * t);
c=this.ivFunc.evaluate$D$D(v, this.freqVal);
sum += c * c;
}
sum=Math.sqrt(sum / (np - 1));
return sum;
});

Clazz.newMeth(C$, ['step$D$D','step','step$'], function (dt, t) {
if (this.part == null ) return;
var w=6.283185307179586 * this.freqVal;
var rad=this.part.getPhaseRadian$();
var v=C$.sqrt2 * this.volt * Math.sin(w * t - rad) ;
var i=this.ivFunc.evaluate$D$D(C$.sqrt2 * this.volt * Math.sin(w * t) , this.freqVal);
this.part.setTime$D(t);
this.part.setVoltInstantaneous$D(v);
this.part.setCurrentInstantaneous$D(i);
this.updateDataConnections$();
});

Clazz.newMeth(C$, 'plotFunction$', function () {
if (this.showIF) {
this.plotIF$();
} else {
this.plotIT$();
}});

Clazz.newMeth(C$, 'plotIT$', function () {
var np=200;
var dt=this.tmax / (np - 1);
var x=Clazz.array(Double.TYPE, [np]);
var y1=Clazz.array(Double.TYPE, [np]);
var y2=Clazz.array(Double.TYPE, [np]);
var w=6.283185307179586 * this.freqVal;
var phase=this.phaseFunc.evaluate$D(this.freqVal);
for (var i=0; i < np; i++) {
x[i]=i * dt;
y1[i]=this.volt * C$.sqrt2 * Math.sin(w * x[i] - phase) ;
y2[i]=this.ivFunc.evaluate$D$D(C$.sqrt2 * this.volt * Math.sin(w * x[i]) , this.freqVal);
}
this.graph.setAutoReplaceData$I$Z(1, true);
this.graph.setAutoReplaceData$I$Z(2, true);
this.graph.clearSeriesData$I(1);
this.graph.clearSeriesData$I(2);
if (this.showVoltage) {
this.graph.addData$I$DA$DA(1, x, y1);
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(1, $I$(1).black, true, 0);
if (this.labelY == null ) this.graph.setSeriesLegend$I$java_awt_Color$I$I$S(1, $I$(1).black, 75, 20, $I$(12).LEGEND_V);
}if (this.showCurrent) {
this.graph.addData$I$DA$DA(2, x, y2);
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(2, $I$(1).red, true, 0);
if (this.labelY == null ) this.graph.setSeriesLegend$I$java_awt_Color$I$I$S(2, $I$(1).red, 125, 20, $I$(12).LEGEND_I);
}});

Clazz.newMeth(C$, 'findYMax$', function () {
var ymax=Math.abs(this.imax);
return Math.max(ymax * C$.sqrt2, this.volt * C$.sqrt2);
});

Clazz.newMeth(C$, 'findYMin$', function () {
var ymin=-Math.abs(this.imax);
return Math.min(ymin * C$.sqrt2, -this.volt * C$.sqrt2);
});

Clazz.newMeth(C$, 'plotIF$', function () {
var np=200;
var df=(this.fmax - this.fmin) / (np - 1);
var x=Clazz.array(Double.TYPE, [np]);
var y=Clazz.array(Double.TYPE, [np]);
for (var i=0; i < np; i++) {
x[i]=this.fmin + i * df;
y[i]=this.ivFunc.evaluate$D$D(this.volt, x[i]);
}
this.graph.clearSeriesData$I(1);
this.graph.clearSeriesData$I(2);
this.graph.addData$I$DA$DA(1, x, y);
this.graph.setSeriesStyle$I$java_awt_Color$Z$I(1, $I$(1).red, true, 0);
this.xold=-100;
this.yold=-100;
});

Clazz.newMeth(C$, 'adjustFreq$D', function (f) {
this.freqVal=f;
if (this.freqVal < this.fmin ) {
this.freqVal=this.fmin;
this.fSlider.setDValue$D(this.freqVal);
}if (this.freqVal > this.fmax ) {
this.freqVal=this.fmax;
this.fSlider.setDValue$D(this.freqVal);
}this.clock.setTime$D(0);
this.clearAllData$();
p$1.setCircuitValues.apply(this, []);
if (!this.showIF) {
this.plotIT$();
return;
}var xpix=this.graph.pixFromX$D(this.freqVal);
var ypix=this.graph.pixFromY$D(this.ivFunc.evaluate$D$D(this.volt, this.freqVal));
;var g=this.graph.getGraphics$();
g.setColor$java_awt_Color($I$(1).green);
g.setXORMode$java_awt_Color($I$(1).red);
g.fillOval$I$I$I$I(this.xold - 5, this.yold - 5, 10, 10);
g.fillOval$I$I$I$I(xpix - 5, ypix - 5, 10, 10);
this.xold=xpix;
this.yold=ypix;
g.setPaintMode$();
g.dispose$();
});

Clazz.newMeth(C$, 'fSlider_adjustmentValueChanged$java_awt_event_AdjustmentEvent', function (e) {
this.adjustFreq$D(this.fSlider.getDValue$());
});

Clazz.newMeth(C$, 'fNumber_actionPerformed$java_awt_event_ActionEvent', function (e) {
if (this.fNumber.isValid$()) this.adjustFreq$D(this.fNumber.getValue$());
});

Clazz.newMeth(C$, ['setSourceVoltage$D$Z','setSourceVoltage'], function (v, showV) {
this.volt=v;
this.bat.showV=showV;
this.adjustFreq$D(this.freqVal);
});

Clazz.newMeth(C$, ['setCustomCircuit$I','setCustomCircuit'], function (ppc) {
this.$autoRefresh=false;
this.customCircuit=true;
this.setPixPerCell$I(ppc);
this.setDefault$();
return;
});

Clazz.newMeth(C$, ['setDefault$','setDefault'], function () {
this.oneShotMsg=null;
this.deleteDataConnections$();
this.clock.stopClock$();
this.clock.setTime$D(0);
this.labelY=null;
this.showCurrent=true;
this.showVoltage=true;
this.phaseStr="0";
this.parsePhaseFunction$();
this.currentStr="0";
this.parseIVFunction$();
this.circuit.setDefault$I(this.preferredPixPerCell);
p$1.createCircuit.apply(this, []);
p$1.setCircuitValues.apply(this, []);
this.graph.setTitle$S(null);
if (this.graph.isVisible$() != this.showGraph ) this.graph.setVisible$Z(this.showGraph);
if (this.$autoRefresh) this.setShowIF$Z(this.showIF);
});

Clazz.newMeth(C$, ['setCurrentFunction$S','setCurrentFunction'], function (str) {
this.currentStr=str;
this.parseIVFunction$();
if (this.$autoRefresh) this.setShowIF$Z(this.showIF);
});

Clazz.newMeth(C$, ['setPhaseFunction$S','setPhaseFunction'], function (str) {
this.phaseStr=str;
this.parsePhaseFunction$();
if (this.$autoRefresh) this.setShowIF$Z(this.showIF);
});

Clazz.newMeth(C$, ['setVoltage$D','setVoltage'], function (v) {
this.volt=v;
this.calcCurrentIMax$();
this.adjustFreq$D(this.freqVal);
});

Clazz.newMeth(C$, ['setFrequency$D','setFrequency'], function (f) {
this.freqVal=f;
this.fSlider.setDValue$D(f);
if (this.customCircuit || this.ammeter == null  ) {
this.adjustFreq$D(f);
if (this.$autoRefresh) this.setShowIF$Z(this.showIF);
return;
}if (this.freqVal == 0 ) {
this.bat.setLabel$S(" V");
this.ammeter.setLabel$S("A");
this.voltmeter.setLabel$S("V");
this.bat.showF=false;
} else {
this.bat.setLabel$S("Vac");
this.ammeter.setLabel$S("A");
this.voltmeter.setLabel$S("V");
this.bat.showF=true;
}this.adjustFreq$D(f);
if (this.$autoRefresh) this.setShowIF$Z(this.showIF);
});

Clazz.newMeth(C$, ['setTitle$S','setTitle'], function (str) {
this.graph.setTitle$S(str);
});

Clazz.newMeth(C$, ['setTMax$D','setTMax'], function (tm) {
this.tmax=tm;
if (this.$autoRefresh) this.setShowIF$Z(this.showIF);
});

Clazz.newMeth(C$, ['setShowControls$Z','setShowControls'], function (sc) {
this.etchedBorder2.setVisible$Z(sc);
});

Clazz.newMeth(C$, ['setShowCheckBox$Z','setShowCheckBox'], function (scb) {
this.checkbox1.setVisible$Z(scb);
});

Clazz.newMeth(C$, ['setShowGraph$Z','setShowGraph'], function (sg) {
if (this.graph.isVisible$() == sg ) return;
this.showGraph=sg;
this.graph.setVisible$Z(sg);
this.invalidate$();
this.validate$();
});

Clazz.newMeth(C$, ['setPartLabel$S','setPartLabel'], function (str) {
this.part.setLabel$S(str);
});

Clazz.newMeth(C$, ['setPartHint$S','setPartHint'], function (str) {
this.part.setCustomHint$S(str);
});

Clazz.newMeth(C$, ['setShowAmmeterPhase$Z','setShowAmmeterPhase'], function (sp) {
this.showAmmeterPhase=sp;
if (this.ammeter != null ) this.ammeter.showPhase=sp;
});

Clazz.newMeth(C$, ['setPixPerCell$I','setPixPerCell'], function (ppc) {
if (this.preferredPixPerCell == ppc) return;
this.preferredPixPerCell=ppc;
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
});

Clazz.newMeth(C$, ['setShowCurrent$Z','setShowCurrent'], function (sc) {
this.showCurrent=sc;
this.plotFunction$();
});

Clazz.newMeth(C$, ['setShowVoltage$Z','setShowVoltage'], function (sv) {
this.showVoltage=sv;
this.plotFunction$();
});

Clazz.newMeth(C$, ['setImpedanceGraphType$Z','setImpedanceGraphType'], function (igt) {
this.showIF=igt;
if (this.$autoRefresh) this.setShowIF$Z(this.showIF);
});

Clazz.newMeth(C$, 'setShowIF$Z', function (si) {
this.showIF=si;
this.graph.setAutoRefresh$Z(false);
this.graph.deleteSeries$I(1);
this.graph.deleteSeries$I(2);
if (this.showIF) {
this.fSlider.setDMinMaxAndValue$D$D$D(this.fmin, this.fmax, this.freqVal);
this.graph.setAutoscaleY$Z(true);
this.xold=-100;
this.yold=-100;
if (this.labelY == null ) this.graph.setLabelY$S($I$(12).CURRENT);
 else this.graph.setLabelY$S(this.labelY);
this.graph.setLabelX$S($I$(12).FREQUENCY);
this.graph.setMinMaxX$D$D(this.fmin, this.fmax);
this.graph.setMinMaxY$D$D(0, this.volt);
} else {
this.volt=Math.abs(this.volt);
this.fSlider.setDMinMaxAndValue$D$D$D(this.fmin, this.fmax, this.freqVal);
this.graph.setAutoscaleY$Z(false);
if (this.labelY == null ) this.graph.setLabelY$S($I$(12).VOLTAGE_CURRENT);
 else this.graph.setLabelY$S(this.labelY);
this.graph.setLabelX$S($I$(12).TIME);
this.graph.setMinMaxX$D$D(0, this.tmax);
this.graph.setMinMaxY$D$D(Math.min(1.1 * this.findYMin$(), 0.9 * this.findYMin$()), Math.max(1.2 * this.findYMax$(), 0.8 * this.findYMax$()));
}p$1.setCircuitValues.apply(this, []);
this.plotFunction$();
this.graph.setAutoRefresh$Z(this.$autoRefresh);
this.graph.repaint$();
});

Clazz.newMeth(C$, 'checkbox1_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (e.getStateChange$() == 1) {
this.setShowIF$Z(false);
} else {
this.setShowIF$Z(true);
}});

Clazz.newMeth(C$, ['setGridSize$I$I','setGridSize'], function (i, j) {
this.circuit.setGridSize$I$I(i, j);
});

Clazz.newMeth(C$, ['addCapacitor$I$I$I$I','addCapacitor'], function (i1, j1, i2, j2) {
var c=this.circuit.addCapacitor$I$I$I$I(i1, j1, i2, j2);
return c.getID$();
});

Clazz.newMeth(C$, ['setCapacitance$I$D$Z$Z$Z','setCapacitance'], function (id, c, showC, showV, showPhase) {
return this.circuit.setCapacitance$I$D$Z$Z$Z(id, c, showC, showV, showPhase);
});

Clazz.newMeth(C$, ['addInductor$I$I$I$I','addInductor'], function (i1, j1, i2, j2) {
var l=this.circuit.addInductor$I$I$I$I(i1, j1, i2, j2);
return l.getID$();
});

Clazz.newMeth(C$, ['setInductance$I$D$Z$Z$Z','setInductance'], function (id, l, showC, showV, showPhase) {
return this.circuit.setInductance$I$D$Z$Z$Z(id, l, showC, showV, showPhase);
});

Clazz.newMeth(C$, ['addResistor$I$I$I$I','addResistor'], function (i1, j1, i2, j2) {
var r=this.circuit.addResistor$I$I$I$I(i1, j1, i2, j2);
return r.getID$();
});

Clazz.newMeth(C$, ['setResistance$I$D$Z$Z$Z','setResistance'], function (id, r, showR, showV, showPhase) {
return this.circuit.setResistance$I$D$Z$Z$Z(id, r, showR, showV, showPhase);
});

Clazz.newMeth(C$, ['addPart$I$I$I$I','addPart'], function (i1, j1, i2, j2) {
var p=this.circuit.addPart$I$I$I$I(i1, j1, i2, j2);
return p.getID$();
});

Clazz.newMeth(C$, ['addBattery$I$I$I$I','addBattery'], function (i1, j1, i2, j2) {
var b=this.circuit.addBattery$I$I$I$I(i1, j1, i2, j2);
return b.getID$();
});

Clazz.newMeth(C$, ['setBatteryEMF$I$D$Z','setBatteryEMF'], function (id, emf, showV) {
return this.circuit.setBatteryEMF$I$D$Z(id, emf, showV);
});

Clazz.newMeth(C$, ['addTransformer$I$I$I$I$Z','addTransformer'], function (i1, j1, i2, j2, vert) {
var t=this.circuit.addTransformer$I$I$I$I$Z(i1, j1, i2, j2, vert);
return t.getID$();
});

Clazz.newMeth(C$, ['addAmmeter$I$I$I$I','addAmmeter'], function (i1, j1, i2, j2) {
var am=this.circuit.addAmmeter$I$I$I$I(i1, j1, i2, j2);
return am.getID$();
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (ar) {
if (this.$autoRefresh == ar ) return;
this.$autoRefresh=ar;
this.graph.setAutoRefresh$Z(ar);
if (this.$autoRefresh) this.setShowIF$Z(this.showIF);
});

Clazz.newMeth(C$, ['setAmmeter$I$D$Z','setAmmeter'], function (id, current, showCurrent) {
return this.circuit.setAmmeter$I$D$Z(id, current, showCurrent);
});

Clazz.newMeth(C$, ['addVoltmeter$I$I$I$I','addVoltmeter'], function (i1, j1, i2, j2) {
var vm=this.circuit.addVoltmeter$I$I$I$I(i1, j1, i2, j2);
return vm.getID$();
});

Clazz.newMeth(C$, ['addACSource$I$I$I$I','addACSource'], function (i1, j1, i2, j2) {
var sw=this.circuit.addSineWave$I$I$I$I(i1, j1, i2, j2);
return sw.getID$();
});

Clazz.newMeth(C$, ['setVoltmeter$I$D$Z','setVoltmeter'], function (id, voltage, showV) {
this.circuit.setShowV$I$Z(id, true);
return this.circuit.setVoltmeter$I$D$Z(id, voltage, showV);
});

Clazz.newMeth(C$, ['setVolt$I$D','setVolt'], function (id, v) {
this.circuit.setShowV$I$Z(id, true);
return this.circuit.setVolt$I$D(id, v);
});

Clazz.newMeth(C$, ['setPhaseDegree$I$D','setPhaseDegree'], function (id, p) {
this.circuit.setShowPhase$I$Z(id, true);
return this.circuit.setPhaseDegree$I$D(id, p);
});

Clazz.newMeth(C$, ['setCurrent$I$D','setCurrent'], function (id, c) {
this.circuit.setShowCurrent$I$Z(id, true);
return this.circuit.setCurrent$I$D(id, c);
});

Clazz.newMeth(C$, ['setLabel$I$S','setLabel'], function (id, str) {
return this.circuit.setLabel$I$S(id, str);
});

Clazz.newMeth(C$, ['setHint$I$S','setHint'], function (id, str) {
return this.circuit.setHint$I$S(id, str);
});

Clazz.newMeth(C$, ['setGraphLabelY$S','setGraphLabelY'], function (str) {
if (str.equals$O(this.labelY)) return;
if (str.trim$().equals$O("") && (this.labelY == null ) ) return;
if (str.trim$().equals$O("")) this.labelY=null;
 else this.labelY=str;
if (this.$autoRefresh) this.setShowIF$Z(this.showIF);
});

Clazz.newMeth(C$, ['setMilliAmp$I$Z','setMilliAmp'], function (id, showMilliAmp) {
return this.circuit.setMilliAmp$I$Z(id, showMilliAmp);
});

Clazz.newMeth(C$, ['addOnOffSwitch$I$I$I$I','addOnOffSwitch'], function (i1, j1, i2, j2) {
var s=this.circuit.addOnOffSwitch$I$I$I$I(i1, j1, i2, j2);
return s.getID$();
});

Clazz.newMeth(C$, ['setSwitchOn$I$Z','setSwitchOn'], function (id, on) {
return this.circuit.setSwitchOn$I$Z(id, on);
});

Clazz.newMeth(C$, ['addWire$I$I$I$I','addWire'], function (i1, j1, i2, j2) {
var w=this.circuit.addWire$I$I$I$I(i1, j1, i2, j2);
return w.getID$();
});
;
(function(){var C$=Clazz.newClass(P$.IZApplet, "IZGraph", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'edu.davidson.display.SGraph');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'paintLast$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
C$.superclazz.prototype.paintLast$java_awt_Graphics$java_awt_Rectangle.apply(this, [g, r]);
if (!this.this$0.showIF) return;
g.clipRect$I$I$I$I(r.x, r.y, r.width, r.height);
g.setColor$java_awt_Color($I$(1).green);
g.setXORMode$java_awt_Color($I$(1).red);
var xx=this.this$0.fSlider.getDValue$();
this.this$0.xold=this.this$0.graph.pixFromX$D(xx);
this.this$0.yold=this.this$0.graph.pixFromY$D(this.this$0.ivFunc.evaluate$D$D(this.this$0.volt, xx));
g.fillOval$I$I$I$I(this.this$0.xold - 5, this.this$0.yold - 5, 10, 10);
g.setPaintMode$();
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:47 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
