(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[];
var C$=Clazz.newClass(P$, "Etching");
C$.OUT = null;
C$.IN = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.OUT = Clazz.new_(C$);
C$.IN = Clazz.new_(C$);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'toString', function () {
if (this === C$.OUT ) return this.getClass().getName() + "=OUT";
 else return this.getClass().getName() + "=IN";
});

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);
})();
//Created 2018-07-23 12:59:46 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
