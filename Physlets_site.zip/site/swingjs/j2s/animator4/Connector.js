(function(){var P$=Clazz.newPackage("animator4"),I$=[];
var C$=Clazz.newClass(P$, "Connector", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.thing1 = null;
this.thing2 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$animator4_Thing$animator4_Thing', function (o, t1, t2) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, "0", "0"]);
C$.$init$.apply(this);
this.thing1 = t1;
this.thing2 = t2;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:13
