(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[[0,'javax.swing.Timer','java.awt.event.ActionEvent','java.awt.Dimension','java.net.URL','java.awt.Image','javax.imageio.ImageIO','java.io.BufferedReader','java.io.InputStreamReader','java.util.stream.Collectors']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "SwingJSUtils", function(){
Clazz.newInstance(this, arguments,0,C$);
});

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'setDim$I$I', function (w, h) {
var baseURI=(document.body.baseURI ||null);
var isTest=(baseURI == null  || baseURI.indexOf$S("_applet.html") >= 0 );
if (!isTest) return null;

J2S.thisApplet.__Info.width = w; J2S.thisApplet.__Info.height = h;
return Clazz.new_($I$(3).c$$I$I,[w, h]);
}, 1);

Clazz.newMeth(C$, 'getResource$Class$S$Class', function (baseClass, filename, cl) {
var is;
try {
is=(filename.indexOf$S(":/") >= 0 ? Clazz.new_($I$(4).c$$S,[filename]).openStream$() : baseClass.getResourceAsStream$S(filename));
} catch (e1) {
if (Clazz.exceptionOf(e1,"java.io.IOException")){
e1.printStackTrace$();
return null;
} else {
throw e1;
}
}
if (cl === Clazz.getClass($I$(5)) ) {
try {
return $I$(6).read$java_io_InputStream(is);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$();
} else {
throw e;
}
}
} else if (cl === Clazz.getClass(String) ) {
return Clazz.new_($I$(7).c$$java_io_Reader,[Clazz.new_($I$(8).c$$java_io_InputStream,[is])]).lines$().collect$java_util_stream_Collector($I$(9).joining$CharSequence("\n"));
}return is;
}, 1);

Clazz.newMeth(C$, 'loadImagesStatic$Class$java_awt_ImageA$S$S$I', function (cl, images, root, ext, nImages) {
for (var i=nImages; --i >= 0; ) {
images[i]=C$.getResource$Class$S$Class(cl, root + i + "." + ext , Clazz.getClass($I$(5)));
}
}, 1);

Clazz.newMeth(C$, 'getImage$java_awt_Component$S', function (c, fileName) {
return C$.getResource$Class$S$Class(c.getClass$(), fileName, Clazz.getClass($I$(5)));
}, 1);

Clazz.newMeth(C$, 'clearComponent$java_awt_Component', function (c) {
var gc=c.getGraphics$();
gc.clearRect$I$I$I$I(0, 0, c.getWidth$(), c.getHeight$());
gc.dispose$();
}, 1);
;
(function(){var C$=Clazz.newInterface(P$.SwingJSUtils, "StateMachine", function(){
});
})()
;
(function(){var C$=Clazz.newClass(P$.SwingJSUtils, "StateHelper", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.machine=null;
this.state=0;
this.level=0;
this.interrupted=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SwingJSUtils_StateMachine', function (machine) {
C$.$init$.apply(this);
this.machine=machine;
}, 1);

Clazz.newMeth(C$, 'interrupt$', function () {
this.interrupted=true;
});

Clazz.newMeth(C$, 'isInterrupted$', function () {
return this.interrupted;
});

Clazz.newMeth(C$, 'isAlive$', function () {
return !this.interrupted;
});

Clazz.newMeth(C$, 'restart$', function () {
this.interrupted=false;
});

Clazz.newMeth(C$, 'setState$I', function (state) {
this.state=state;
});

Clazz.newMeth(C$, 'getState$', function () {
return this.state;
});

Clazz.newMeth(C$, 'setLevel$I', function (level) {
this.level=level;
});

Clazz.newMeth(C$, 'getLevel$', function () {
return this.level;
});

Clazz.newMeth(C$, 'next$I', function (state) {
return this.next$I$I(state, 0);
});

Clazz.newMeth(C$, 'next$I$I', function (state, level) {
if (this.interrupted) return false;
this.level=level;
this.state=state;
return this.machine.stateLoop$();
});

Clazz.newMeth(C$, 'delayedState$I$I', function (ms, stateNext) {
return this.delayedState$I$I$I(ms, stateNext, this.level);
});

Clazz.newMeth(C$, 'delayedState$I$I$I', function (ms, stateNext, levelNext) {
if (this.interrupted) return false;
if (ms == 0) return this.next$I$I(stateNext, levelNext);
var timer=Clazz.new_($I$(1).c$$I$java_awt_event_ActionListener,[ms, ((P$.SwingJSUtils$StateHelper$1||
(function(){var C$=Clazz.newClass(P$, "SwingJSUtils$StateHelper$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (e) {
this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].next$I$I.apply(this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'], [this.$finals$.stateNext, this.$finals$.levelNext]);
});
})()
), Clazz.new_(P$.SwingJSUtils$StateHelper$1.$init$, [this, {stateNext: stateNext, levelNext: levelNext}]))]);
timer.setRepeats$Z(false);
timer.start$();
return true;
});

Clazz.newMeth(C$, 'delayedAction$I$I$S$java_awt_event_ActionListener', function (ms, id, command, listener) {
return this.delayedAction$I$I$S$java_awt_event_ActionListener$I$I(ms, id, command, listener, -2147483648, -2147483648);
});

Clazz.newMeth(C$, 'delayedAction$I$I$S$java_awt_event_ActionListener$I', function (ms, id, command, listener, state) {
return this.delayedAction$I$I$S$java_awt_event_ActionListener$I$I(ms, id, command, listener, state, -2147483648);
});

Clazz.newMeth(C$, 'delayedAction$I$I$S$java_awt_event_ActionListener$I$I', function (ms, id, command, listener, stateNext, levelNext) {
if (this.interrupted) return false;
var event=Clazz.new_($I$(2).c$$O$I$S,[this, id, command]);
if (ms == 0) {
listener.actionPerformed$(event);
return (stateNext == -2147483648 && levelNext == -2147483648  || this.next$I$I(stateNext == -2147483648 ? this.state : stateNext, levelNext == -2147483648 ? this.level : levelNext) );
}var timer=Clazz.new_($I$(1).c$$I$java_awt_event_ActionListener,[ms, id == 1001 ? listener : ((P$.SwingJSUtils$StateHelper$2||
(function(){var C$=Clazz.newClass(P$, "SwingJSUtils$StateHelper$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (e) {
if (!this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].interrupted) this.$finals$.listener.actionPerformed$(this.$finals$.event);
if (!this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].interrupted && (this.$finals$.stateNext != -2147483648 || this.$finals$.levelNext != -2147483648 ) ) this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].next$I$I.apply(this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'], [this.$finals$.stateNext == -2147483648 ? this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].state : this.$finals$.stateNext, this.$finals$.levelNext == -2147483648 ? this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].level : this.$finals$.levelNext]);
});
})()
), Clazz.new_(P$.SwingJSUtils$StateHelper$2.$init$, [this, {listener: listener, event: event, stateNext: stateNext, levelNext: levelNext}]))]);
timer.setRepeats$Z(false);
timer.start$();
return true;
});

Clazz.newMeth(C$, 'delayedRun$I$Runnable$I$I', function (ms, runnable, stateNext, levelNext) {
if (this.interrupted) return false;
if (ms == 0) {
runnable.run$();
return (stateNext == -2147483648 && levelNext == -2147483648  || this.next$I$I(stateNext == -2147483648 ? this.state : stateNext, levelNext == -2147483648 ? this.level : levelNext) );
}var timer=Clazz.new_($I$(1).c$$I$java_awt_event_ActionListener,[ms, ((P$.SwingJSUtils$StateHelper$3||
(function(){var C$=Clazz.newClass(P$, "SwingJSUtils$StateHelper$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (e) {
if (!this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].interrupted) this.$finals$.runnable.run$();
if (!this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].interrupted && (this.$finals$.stateNext != -2147483648 || this.$finals$.levelNext != -2147483648 ) ) this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].next$I$I.apply(this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'], [this.$finals$.stateNext == -2147483648 ? this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].state : this.$finals$.stateNext, this.$finals$.levelNext == -2147483648 ? this.b$['edu.davidson.tools.SwingJSUtils.StateHelper'].level : this.$finals$.levelNext]);
});
})()
), Clazz.new_(P$.SwingJSUtils$StateHelper$3.$init$, [this, {runnable: runnable, stateNext: stateNext, levelNext: levelNext}]))]);
timer.setRepeats$Z(false);
timer.start$();
return true;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:05 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
