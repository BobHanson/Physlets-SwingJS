(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[];
var C$=Clazz.newClass(P$, "SSlider", null, 'java.awt.Scrollbar', 'java.beans.PropertyChangeListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.boundSupport=null;
this.dValue=0;
this.dMin=0;
this.dMax=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$D$D$D.apply(this, [0.0, 0.0, 1.0]);
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D', function (v, min, max) {
C$.superclazz.c$$I$I$I$I$I.apply(this, [0, 0, 3, 0, 100]);
C$.$init$.apply(this);
this.boundSupport=Clazz.new_(Clazz.load('java.beans.PropertyChangeSupport').c$$O,[this]);
this.dValue=v;
this.dMin=min;
this.dMax=max;
this.enableEvents$J(256);
}, 1);

Clazz.newMeth(C$, 'processAdjustmentEvent$java_awt_event_AdjustmentEvent', function (evt) {
var oldVal=this.dValue;
var val=evt.getValue$();
this.dValue=this.dMin + (this.dMax - this.dMin) * (val - this.getMinimum$()) / (this.getMaximum$() - this.getMinimum$() - this.getVisibleAmount$() );
if (!evt.getValueIsAdjusting$()) this.dValue=oldVal;
if (this.dValue > this.dMax ) this.dValue=this.dMax;
if (this.dValue < this.dMin ) this.dValue=this.dMin;
this.boundSupport.firePropertyChange$S$O$O("DValue",  new Double(oldVal),  new Double(this.dValue));
C$.superclazz.prototype.processAdjustmentEvent$java_awt_event_AdjustmentEvent.apply(this, [evt]);
});

Clazz.newMeth(C$, 'setDValue$D', function (d) {
if (this.dValue == d ) return;
var oldVal=this.dValue;
this.dValue=d;
var val=this.getMinimum$() + (this.getMaximum$() - this.getMinimum$() - this.getVisibleAmount$() ) * (d - this.dMin) / (this.dMax - this.dMin);
this.setValue$I((val|0));
this.boundSupport.firePropertyChange$S$O$O("DValue",  new Double(oldVal),  new Double(this.dValue));
});

Clazz.newMeth(C$, 'setDMinMaxAndValue$D$D$D', function (dmin, dmax, dval) {
var oldVal=this.dValue;
this.dMax=dmax;
this.dMin=dmin;
this.dValue=dval;
if (this.dValue < dmin ) this.dValue=this.dMin;
if (this.dValue > dmax ) this.dValue=this.dMax;
var ival=this.getMinimum$() + (this.getMaximum$() - this.getMinimum$() - this.getVisibleAmount$() ) * (this.dValue - this.dMin) / (this.dMax - this.dMin);
this.setValue$I((ival|0));
if (oldVal != this.dValue ) this.boundSupport.firePropertyChange$S$O$O("DValue",  new Double(oldVal),  new Double(this.dValue));
});

Clazz.newMeth(C$, 'getDValue$', function () {
return this.dValue;
});

Clazz.newMeth(C$, 'setDMinMax$D$D', function (dmin, dmax) {
this.dMax=dmax;
this.dMin=dmin;
if (this.dValue < dmin ) this.dValue=this.dMin;
if (this.dValue > dmax ) this.dValue=this.dMax;
var ival=this.getMinimum$() + (this.getMaximum$() - this.getMinimum$() - this.getVisibleAmount$() ) * (this.dValue - this.dMin) / (this.dMax - this.dMin);
this.setValue$I((ival|0));
});

Clazz.newMeth(C$, 'setDMin$D', function (dmin) {
this.dMin=dmin;
if (this.dValue < dmin ) this.dValue=this.dMin;
var ival=this.getMinimum$() + (this.getMaximum$() - this.getMinimum$() - this.getVisibleAmount$() ) * (this.dValue - this.dMin) / (this.dMax - this.dMin);
this.setValue$I((ival|0));
});

Clazz.newMeth(C$, 'getDMin$', function () {
return this.dMin;
});

Clazz.newMeth(C$, 'setDMax$D', function (dmax) {
this.dMax=dmax;
if (this.dValue > dmax ) this.dValue=this.dMax;
var ival=this.getMinimum$() + (this.getMaximum$() - this.getMinimum$() - this.getVisibleAmount$() ) * (this.dValue - this.dMin) / (this.dMax - this.dMin);
this.setValue$I((ival|0));
});

Clazz.newMeth(C$, 'getDMax$', function () {
return this.dMax;
});

Clazz.newMeth(C$, 'addPropertyChangeListener$java_beans_PropertyChangeListener', function (l) {
if (this.boundSupport == null ) C$.superclazz.prototype.addPropertyChangeListener$java_beans_PropertyChangeListener.apply(this, [l]);
 else this.boundSupport.addPropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, 'removePropertyChangeListener$java_beans_PropertyChangeListener', function (l) {
this.boundSupport.removePropertyChangeListener$java_beans_PropertyChangeListener(l);
});

Clazz.newMeth(C$, ['propertyChange$java_beans_PropertyChangeEvent','propertyChange$'], function (evt) {
if (evt.getPropertyName$().equals$O("DValue")) {
this.dValue=(evt.getNewValue$()).doubleValue$();
try {
var val=(this.getMaximum$() - this.getMinimum$() - this.getVisibleAmount$() ) * (this.dValue - this.dMin) / (this.dMax - this.dMin);
this.setValue$I((val|0));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:30 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
