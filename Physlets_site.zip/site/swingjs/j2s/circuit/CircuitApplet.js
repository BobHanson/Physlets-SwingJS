(function(){var P$=Clazz.newPackage("circuit"),I$=[['circuit.Circuit','edu.davidson.graphics.Box','circuit.Common','java.awt.BorderLayout','Boolean','java.awt.Dimension']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CircuitApplet", null, 'edu.davidson.tools.SApplet');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.showControls = false;
this.gridSize = 0;
this.preferredPixPerCell = 0;
this.circuit = null;
this.circuitBox = null;
this.borderLayout1 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.preferredPixPerCell = 80;
this.circuit = Clazz.new_((I$[1]||$incl$(1)).c$$edu_davidson_tools_SApplet,[this]);
this.circuitBox = Clazz.new_((I$[2]||$incl$(2)).c$$java_awt_Component$S,[this.circuit, (I$[3]||$incl$(3)).CIRCUIT]);
this.borderLayout1 = Clazz.new_((I$[4]||$incl$(4)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'destroy', function () {
this.circuit.forceBubbleHelp$S(null);
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'stop', function () {
this.oneShotMsg = null;
this.circuit.forceBubbleHelp$S(null);
C$.superclazz.prototype.stop.apply(this, []);
});

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
try {
this.showControls = (I$[5]||$incl$(5)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.gridSize = Integer.parseInt(this.getParameter$S$S("GridSize", "3"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.preferredPixPerCell = Integer.parseInt(this.getParameter$S$S("PixPerCell", "30"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.circuitBox.setHint$S((I$[3]||$incl$(3)).LEGEND_SELECT);
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
this.circuit.setGridSize$I$I(this.gridSize, this.gridSize);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setSize$java_awt_Dimension(Clazz.new_((I$[6]||$incl$(6)).c$$I$I,[293, 262]));
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.circuitBox.setTitle$S((I$[3]||$incl$(3)).CIRCUIT);
this.add$java_awt_Component$O(this.circuitBox, "Center");
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "CircuitApplet by Wolfgang Christian, wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["showControls", "boolean", "Show onscreen controls"]), Clazz.array(java.lang.String, -1, ["gridSize", "int", "Number of X-Y Nodes"]), Clazz.array(java.lang.String, -1, ["elementSize", "int", "Size in pix of one circuit element"])]);
return pinfo;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.oneShotMsg = null;
this.circuit.setDefault();
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
this.circuit.setGridSize$I$I(this.gridSize, this.gridSize);
});

Clazz.newMeth(C$, ['setGridSize$I$I','setGridSize'], function (i, j) {
this.circuit.setGridSize$I$I(i, j);
});

Clazz.newMeth(C$, ['setTitle$S','setTitle'], function (t) {
this.circuitBox.setTitle$S(t);
this.repaint();
});

Clazz.newMeth(C$, ['addCapacitor$I$I$I$I','addCapacitor'], function (i1, j1, i2, j2) {
var c = this.circuit.addCapacitor$I$I$I$I(i1, j1, i2, j2);
return c.getID();
});

Clazz.newMeth(C$, ['setCapacitance$I$D$Z$Z$Z','setCapacitance'], function (id, c, showC, showV, showPhase) {
return this.circuit.setCapacitance$I$D$Z$Z$Z(id, c, showC, showV, showPhase);
});

Clazz.newMeth(C$, ['addInductor$I$I$I$I','addInductor'], function (i1, j1, i2, j2) {
var l = this.circuit.addInductor$I$I$I$I(i1, j1, i2, j2);
return l.getID();
});

Clazz.newMeth(C$, ['setInductance$I$D$Z$Z$Z','setInductance'], function (id, l, showL, showV, showPhase) {
return this.circuit.setInductance$I$D$Z$Z$Z(id, l, showL, showV, showPhase);
});

Clazz.newMeth(C$, ['addResistor$I$I$I$I','addResistor'], function (i1, j1, i2, j2) {
var r = this.circuit.addResistor$I$I$I$I(i1, j1, i2, j2);
return r.getID();
});

Clazz.newMeth(C$, ['addPart$I$I$I$I','addPart'], function (i1, j1, i2, j2) {
var p = this.circuit.addPart$I$I$I$I(i1, j1, i2, j2);
return p.getID();
});

Clazz.newMeth(C$, ['setResistance$I$D$Z$Z$Z','setResistance'], function (id, r, showR, showV, showPhase) {
return this.circuit.setResistance$I$D$Z$Z$Z(id, r, showR, showV, showPhase);
});

Clazz.newMeth(C$, ['addBattery$I$I$I$I','addBattery'], function (i1, j1, i2, j2) {
var b = this.circuit.addBattery$I$I$I$I(i1, j1, i2, j2);
return b.getID();
});

Clazz.newMeth(C$, ['setBatteryEMF$I$D$Z','setBatteryEMF'], function (id, emf, showV) {
return this.circuit.setBatteryEMF$I$D$Z(id, emf, showV);
});

Clazz.newMeth(C$, ['addAmmeter$I$I$I$I','addAmmeter'], function (i1, j1, i2, j2) {
var am = this.circuit.addAmmeter$I$I$I$I(i1, j1, i2, j2);
return am.getID();
});

Clazz.newMeth(C$, ['setAmmeter$I$D$Z','setAmmeter'], function (id, current, showCurrent) {
return this.circuit.setAmmeter$I$D$Z(id, current, showCurrent);
});

Clazz.newMeth(C$, ['addVoltmeter$I$I$I$I','addVoltmeter'], function (i1, j1, i2, j2) {
var vm = this.circuit.addVoltmeter$I$I$I$I(i1, j1, i2, j2);
return vm.getID();
});

Clazz.newMeth(C$, ['setVoltmeter$I$D$Z','setVoltmeter'], function (id, voltage, showV) {
return this.circuit.setVoltmeter$I$D$Z(id, voltage, showV);
});

Clazz.newMeth(C$, ['setVolt$I$D','setVolt'], function (id, v) {
this.circuit.setShowV$I$Z(id, true);
return this.circuit.setVolt$I$D(id, v);
});

Clazz.newMeth(C$, ['setCurrent$I$D','setCurrent'], function (id, c) {
this.circuit.setShowCurrent$I$Z(id, true);
return this.circuit.setCurrent$I$D(id, c);
});

Clazz.newMeth(C$, ['setPhaseDegree$I$D','setPhaseDegree'], function (id, p) {
this.circuit.setShowPhase$I$Z(id, true);
return this.circuit.setPhaseDegree$I$D(id, p);
});

Clazz.newMeth(C$, ['setLabel$I$S','setLabel'], function (id, str) {
return this.circuit.setLabel$I$S(id, str);
});

Clazz.newMeth(C$, ['setHint$I$S','setHint'], function (id, str) {
return this.circuit.setHint$I$S(id, str);
});

Clazz.newMeth(C$, ['setMilliAmp$I$Z','setMilliAmp'], function (id, showMilliAmp) {
return this.circuit.setMilliAmp$I$Z(id, showMilliAmp);
});

Clazz.newMeth(C$, ['addOnOffSwitch$I$I$I$I','addOnOffSwitch'], function (i1, j1, i2, j2) {
var s = this.circuit.addOnOffSwitch$I$I$I$I(i1, j1, i2, j2);
return s.getID();
});

Clazz.newMeth(C$, ['setSwitchOn$I$Z','setSwitchOn'], function (id, on) {
return this.circuit.setSwitchOn$I$Z(id, on);
});

Clazz.newMeth(C$, ['addTransformer$I$I$I$I$Z','addTransformer'], function (i1, j1, i2, j2, horz) {
var t = this.circuit.addTransformer$I$I$I$I$Z(i1, j1, i2, j2, horz);
return t.getID();
});

Clazz.newMeth(C$, ['addWire$I$I$I$I','addWire'], function (i1, j1, i2, j2) {
var w = this.circuit.addWire$I$I$I$I(i1, j1, i2, j2);
return w.getID();
});

Clazz.newMeth(C$, ['addACSource$I$I$I$I','addACSource'], function (i1, j1, i2, j2) {
var sw = this.circuit.addSineWave$I$I$I$I(i1, j1, i2, j2);
return sw.getID();
});

Clazz.newMeth(C$, ['setPixPerCell$I','setPixPerCell'], function (ppc) {
this.preferredPixPerCell = ppc;
this.circuit.setPreferredPixPerCell$I(this.preferredPixPerCell);
});
})();
//Created 2018-02-22 01:06:39
