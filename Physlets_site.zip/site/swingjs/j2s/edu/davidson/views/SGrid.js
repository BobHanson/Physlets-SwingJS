(function(){var P$=Clazz.newPackage("edu.davidson.views"),I$=[['java.awt.Color','java.awt.Font','edu.davidson.display.Format',['edu.davidson.views.SGrid','.Cell'],'Thread','java.awt.Dimension','java.awt.event.MouseAdapter']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "SGrid", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'a2s.Panel');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.gridpanel = null;
this.nRows = 0;
this.nCols = 0;
this.preferredWidth = 0;
this.preferredHeight = 0;
this.currentWidth = 0;
this.currentHeight = 0;
this.defaultCellWidth = 0;
this.defaultCellHeight = 0;
this.cells = null;
this.osi = null;
this.$font = null;
this.hlFont = null;
this.silver = null;
this.hlCell = null;
this.showColHeader = false;
this.showRowHeader = false;
this.autoscaleRows = false;
this.autoscaleCols = false;
this.autoRefresh = false;
this.lastOnTop = false;
this.showHLCell = false;
this.maxRow = 0;
this.defaultFormat = null;
this.colLabels = null;
this.stride = null;
this.skipCounter = null;
this.nextRow = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.gridpanel = null;
this.nRows = 50;
this.nCols = 3;
this.preferredWidth = 20;
this.preferredHeight = 20;
this.currentWidth = 0;
this.currentHeight = 0;
this.defaultCellWidth = 40;
this.defaultCellHeight = 20;
this.cells = null;
this.osi = null;
this.$font = Clazz.new_((I$[2]||$incl$(2)).c$$S$I$I,["TimesRoman", 0, 12]);
this.hlFont = Clazz.new_((I$[2]||$incl$(2)).c$$S$I$I,["TimesRoman", 1, 12]);
this.silver = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[224, 224, 224]);
this.hlCell = null;
this.showColHeader = true;
this.showRowHeader = true;
this.autoscaleRows = false;
this.autoscaleCols = false;
this.autoRefresh = true;
this.lastOnTop = false;
this.showHLCell = false;
this.maxRow = 1;
this.defaultFormat = Clazz.new_((I$[3]||$incl$(3)).c$$S,["%-+6.2f"]);
this.colLabels = null;
this.stride = null;
this.skipCounter = null;
this.nextRow = null;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_views_SGridPanel', function (gp) {
C$.c$.apply(this, []);
this.gridpanel = gp;
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (nr, nc) {
Clazz.super_(C$, this,1);
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.setBackground$java_awt_Color(this.silver);
this.nRows = nr + 1;
this.nCols = nc + 1;
this.initCells$I$I(this.nRows, this.nCols);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.setBackground$java_awt_Color(this.silver);
this.initCells$I$I(this.nRows, this.nCols);
}, 1);

Clazz.newMeth(C$, 'addDatum$I$D', function (id, x) {
if (id >= this.nCols) {
System.out.println$S("Error: Data table initialized with insufficient number of rows.");
return;
}if (this.lastOnTop) {
this.addOnTop$I$D(id, x);
return;
}this.skipCounter[id]--;
if (this.skipCounter[id] > 0) return;
this.skipCounter[id] = this.stride[id];
if (this.nextRow[id] == this.nRows) return;
this.cells[this.nextRow[id]][id].setValue$D(x);
if (this.nextRow[id] < this.nRows) this.nextRow[id]++;
if (this.autoRefresh) this.paintOsi();
});

Clazz.newMeth(C$, 'addData$I$DA', function (id, x) {
this.clearSeries$I(id);
for (var i = 1; i < Math.min(x.length + 1, this.maxRow); i = i+(this.stride[id])) {
this.cells[i][id].setValue$D(x[i - 1]);
}
if (this.autoRefresh) this.paintOsi();
});

Clazz.newMeth(C$, 'addOnTop$I$D', function (id, x) {
this.skipCounter[id]--;
if (this.skipCounter[id] > 0) return;
this.skipCounter[id] = this.stride[id];
if (this.nextRow[id] < this.maxRow - 1) this.nextRow[id]++;
for (var i = this.nextRow[id]; i > 1; i--) this.cells[i][id].setValue$S(this.cells[i - 1][id].str);

this.cells[1][id].setValue$D(x);
});

Clazz.newMeth(C$, 'setDefaultCellWidth$I', function (dcw) {
this.defaultCellWidth = dcw;
});

Clazz.newMeth(C$, 'setDefault', function () {
for (var i = 1; i < this.nRows; i++) for (var j = 1; j < this.nCols; j++) {
this.cells[i][j].str = "";
this.cells[i][j].value = 0;
}

for (var j = 1; j < this.nCols; j++) {
this.nextRow[j] = 1;
this.skipCounter[j] = 1;
this.stride[j] = 1;
}
this.setGridSize();
});

Clazz.newMeth(C$, 'sizeToFit', function () {
if (this.nCols < 2 || this.nRows < 2 ) return;
var gridWidth = this.getSize().width;
var gridHeight = this.getSize().height;
var xGutter = this.cells[0][0].width;
var yGutter = this.cells[0][0].height;
if (!this.showRowHeader) xGutter = 0;
if (!this.showColHeader) yGutter = 0;
var newWidth = ((gridWidth - xGutter)/(this.nCols - 1)|0);
var newHeight = ((gridHeight - yGutter)/(this.nRows - 1)|0);
this.currentWidth = 0;
this.currentHeight = 0;
for (var i = 0; i < this.maxRow; i++) {
this.currentWidth = 0;
for (var j = 0; j < this.nCols; j++) {
if (j == 0) this.cells[i][j].width = xGutter;
 else this.cells[i][j].width = newWidth;
if (i == 0) this.cells[i][j].height = yGutter;
 else this.cells[i][j].height = newHeight;
this.currentWidth = this.currentWidth+(this.cells[0][j].width);
}
this.currentHeight = this.currentHeight+(this.cells[i][0].height);
}
this.osi = null;
this.invalidate();
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setGridSize', function () {
this.currentWidth = 0;
this.currentHeight = 0;
for (var i = 0; i < this.maxRow; i++) {
this.currentWidth = 0;
for (var j = 0; j < this.nCols; j++) {
if (i == 0) this.cells[i][j].width = 40;
 else this.cells[i][j].width = this.defaultCellWidth;
if (j == 0) this.cells[i][j].height = 20;
 else this.cells[i][j].height = this.defaultCellHeight;
this.currentWidth = this.currentWidth+(this.cells[0][j].width);
}
this.currentHeight = this.currentHeight+(this.cells[i][0].height);
}
this.osi = null;
this.invalidate();
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'clearSeries$I', function (id) {
if (id < 1 || id >= this.nCols ) return false;
for (var i = 1; i < this.nRows; i++) {
this.cells[i][id].str = "";
this.cells[i][id].paintOSI();
if (this.autoRefresh) this.cells[i][id].paint();
}
this.nextRow[id] = 1;
this.skipCounter[id] = 1;
return true;
});

Clazz.newMeth(C$, 'clearAllSeries', function () {
for (var j = 1; j < this.nCols; j++) {
for (var i = 1; i < this.nRows; i++) {
this.cells[i][j].str = "";
this.cells[i][j].paintOSI();
if (this.autoRefresh) this.cells[i][j].paint();
}
this.nextRow[j] = 1;
this.skipCounter[j] = 1;
}
return true;
});

Clazz.newMeth(C$, 'getColWidth$I', function (id) {
if (id < 0 || id >= this.nCols  || this.nRows < 1 ) return 0;
return this.cells[0][id].width;
});

Clazz.newMeth(C$, 'setColWidth$I$I', function (id, newWidth) {
if (id < 0 || id >= this.nCols ) return false;
this.currentWidth = this.currentWidth - this.cells[0][id].width + newWidth;
for (var i = 0; i < this.nRows; i++) {
this.cells[i][id].width = newWidth;
}
this.osi = null;
this.invalidate();
if (this.autoRefresh) this.repaint();
return true;
});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
try {
this.defaultFormat = Clazz.new_((I$[3]||$incl$(3)).c$$S,[str]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.IllegalArgumentException")){
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'setNumericFormat$I$S', function (id, str) {
if (id < 1 || id >= this.nCols  || this.nRows < 2 ) return false;
try {
this.cells[1][id].format = Clazz.new_((I$[3]||$incl$(3)).c$$S,[str]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.IllegalArgumentException")){
return false;
} else {
throw e;
}
}
this.cells[1][id].paintOSI();
if (this.autoRefresh) this.cells[1][id].paint();
for (var i = 2; i < this.nRows; i++) {
this.cells[i][id].format = this.cells[1][id].format;
this.cells[i][id].paintOSI();
if (this.autoRefresh) this.cells[i][id].paint();
}
return true;
});

Clazz.newMeth(C$, 'initCells$I$I', function (r, c) {
var clabel = "A";
clabel = String.fromCharCode(clabel.$c()-1);
this.nRows = r;
this.nCols = c;
if (this.autoscaleRows) this.maxRow = this.nRows + 10;
 else this.maxRow = this.nRows;
this.skipCounter = Clazz.array(Integer.TYPE, [this.nCols]);
this.stride = Clazz.array(Integer.TYPE, [this.nCols]);
this.colLabels = Clazz.array(java.lang.String, [this.nCols]);
this.nextRow = Clazz.array(Integer.TYPE, [this.nCols]);
this.cells = Clazz.array((I$[4]||$incl$(4)), [this.maxRow, this.nCols]);
this.currentWidth = 0;
this.currentHeight = 0;
for (var i = 0; i < this.maxRow; i++) {
this.currentWidth = 0;
for (var j = 0; j < this.nCols; j++) {
this.cells[i][j] = Clazz.new_((I$[4]||$incl$(4)).c$$I$I, [this, null, i, j]);
this.currentWidth = this.currentWidth+(this.cells[0][j].width);
if (i == 0) {
this.cells[0][j].str = (Clazz.new_(java.lang.Character,[clabel])).toString();
this.cells[0][j].bgColor = (I$[1]||$incl$(1)).lightGray;
this.cells[0][j].centered = true;
this.colLabels[j] = this.cells[0][j].str;
this.skipCounter[j] = 1;
this.stride[j] = 1;
this.nextRow[j] = 1;
clabel = String.fromCharCode(clabel.$c()+1);
}}
this.cells[i][0].str = "" + i;
this.cells[i][0].bgColor = (I$[1]||$incl$(1)).lightGray;
this.currentHeight = this.currentHeight+(this.cells[i][0].height);
}
this.cells[0][0].str = "";
if (this.gridpanel != null ) this.gridpanel.validate();
});

Clazz.newMeth(C$, 'getCellFromPix$I$I', function (xpix, ypix) {
var x = 0;
var y = 0;
var startRow = 0;
var startCol = 0;
if (!this.showRowHeader) startCol = 1;
if (!this.showColHeader) startRow = 1;
if (xpix >= this.currentWidth || ypix >= this.currentHeight ) return null;
var row = -1;
var col = -1;
for (var i = startRow; i < this.nRows; i++) {
y = y+(this.cells[i][0].height);
if (y >= ypix) {
row = i;
break;
}}
for (var j = startCol; j < this.nCols; j++) {
x = x+(this.cells[0][j].width);
if (x >= xpix) {
col = j;
break;
}}
if (row >= 0 && col >= 0 ) return this.cells[row][col];
 else return null;
});

Clazz.newMeth(C$, 'getCol$S', function (str) {
for (var j = 0; j < this.nCols; j++) {
if (this.colLabels[j].equals$O(str)) return j;
}
return -1;
});

Clazz.newMeth(C$, 'highlightRow$I$Z', function (i, hl) {
if (i >= this.nRows) return;
for (var j = 0; j < this.nCols; j++) {
this.cells[i][j].highlight = hl;
this.cells[i][j].paintOSI();
if (this.autoRefresh) this.cells[i][j].paint();
}
});

Clazz.newMeth(C$, 'setDataStride$I$I', function (id, s) {
this.stride[id] = Math.max(1, s);
this.skipCounter[id] = 1;
});

Clazz.newMeth(C$, 'setColLabel$I$S', function (j, str) {
if (j < 0 || j >= this.nCols ) return false;
this.colLabels[j] = str;
this.cells[0][j].str = str;
this.cells[0][j].paintOSI();
if (this.autoRefresh) this.cells[0][j].paint();
return true;
});

Clazz.newMeth(C$, 'setAutoRefresh$Z', function (auto) {
this.autoRefresh = auto;
if (this.autoRefresh) {
this.paintOsi();
}});

Clazz.newMeth(C$, 'setBounds$I$I$I$I', function (x, y, width, height) {
C$.superclazz.prototype.setBounds$I$I$I$I.apply(this, [x, y, width, height]);
if (width > 2 && height > 2 ) {
{
this.osi = null;
}}});

Clazz.newMeth(C$, 'setBounds$java_awt_Rectangle', function (r) {
C$.superclazz.prototype.setBounds$java_awt_Rectangle.apply(this, [r]);
if (r.width > 2 && r.height > 2 ) {
{
this.osi = null;
}}});

Clazz.newMeth(C$, 'setCell$I$I$S', function (i, j, s) {
if (i < 0 || j < 0  || i > this.nRows  || j > this.nCols ) return false;
if (i == 0 && j == 0 ) return false;
this.cells[i][j].setValue$S(s);
return true;
});

Clazz.newMeth(C$, 'getCellValue$I$I', function (i, j) {
if (i < 0 || j < 0  || i > this.nRows  || j > this.nCols ) return NaN;
if (i == 0 && j == 0 ) return NaN;
return this.cells[i][j].getValue();
});

Clazz.newMeth(C$, 'getActiveCellValue', function () {
if (this.hlCell == null ) return NaN;
return this.hlCell.getValue();
});

Clazz.newMeth(C$, 'setActiveCellValue$D', function (val) {
if (this.hlCell == null ) return false;
this.hlCell.setValue$D(val);
return true;
});

Clazz.newMeth(C$, 'getActiveCellRow', function () {
if (this.hlCell == null ) return -1;
return this.hlCell.row;
});

Clazz.newMeth(C$, 'getActiveCellCol', function () {
if (this.hlCell == null ) return -1;
return this.hlCell.col;
});

Clazz.newMeth(C$, 'getNextRow$I', function (sid) {
return this.nextRow[sid];
});

Clazz.newMeth(C$, 'setHighlight$I$I', function (i, j) {
if (this.hlCell != null ) {
if (this.hlCell.row == 0) this.highlightCol$I$Z(this.hlCell.col, false);
 else if (this.hlCell.col == 0) this.highlightRow$I$Z(this.hlCell.row, false);
 else {
this.hlCell.highlight = false;
this.hlCell.paint();
this.hlCell.paintOSI();
}}this.hlCell = null;
if (i < 0 || j < 0  || i > this.nRows  || j > this.nCols ) return;
if (i == 0 && j == 0 ) return;
this.hlCell = this.cells[i][j];
if (this.hlCell.row == 0) this.highlightCol$I$Z(this.hlCell.col, true);
 else if (this.hlCell.col == 0) this.highlightRow$I$Z(this.hlCell.row, true);
 else {
this.hlCell.highlight = true;
this.hlCell.paint();
this.hlCell.paintOSI();
}});

Clazz.newMeth(C$, 'highlightCol$I$Z', function (j, hl) {
if (j >= this.nCols) return;
for (var i = 0; i < this.nRows; i++) {
this.cells[i][j].highlight = hl;
this.cells[i][j].paintOSI();
if (this.autoRefresh) this.cells[i][j].paint();
}
});

Clazz.newMeth(C$, 'paintNEW$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
var r = this.getBounds();
if (r.width == 0 || r.height == 0 ) return;
if (this.nCols == 0 || this.nRows == 0 ) {
g.fillRect$I$I$I$I(r.x, r.y, r.width, r.height);
return;
}var w = this.currentWidth;
var h = this.currentHeight;
if (w <= 1 || h <= 1 ) return;
if (!this.showRowHeader) w = w-(this.cells[0][0].width);
if (!this.showColHeader) h = h-(this.cells[0][0].height);
var count = 0;
{
this.osi = this.createImage$I$I(w, h);
if (this.osi == null ) return;
var osg = this.osi.getGraphics();
if (osg == null ) return;
this.paintOsi$java_awt_Graphics(osg);
osg.dispose();
osg = null;
g.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, w, h, this);
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var r = this.getBounds();
if (r.width == 0 || r.height == 0 ) return;
if (this.nCols == 0 || this.nRows == 0 ) {
g.fillRect$I$I$I$I(r.x, r.y, r.width, r.height);
return;
}var w = this.currentWidth;
var h = this.currentHeight;
if (w <= 1 || h <= 1 ) return;
if (!this.showRowHeader) w = w-(this.cells[0][0].width);
if (!this.showColHeader) h = h-(this.cells[0][0].height);
var count = 0;
{
if (this.osi == null ) {
this.osi = this.createImage$I$I(w, h);
if (this.osi == null ) return;
while (!this.prepareImage$java_awt_Image$java_awt_image_ImageObserver(this.osi, this) && count < 10 )try {
count++;
(I$[5]||$incl$(5)).sleep$J(20);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
;} else {
throw e;
}
}

var osg = this.osi.getGraphics();
if (osg == null ) return;
this.paintOsi$java_awt_Graphics(osg);
osg.dispose();
osg = null;
}g.drawImage$java_awt_Image$I$I$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, w, h, this);
}});

Clazz.newMeth(C$, 'paintOsi', function () {
var g = this.getGraphics();
if (g == null ) return;
this.paintOsi$java_awt_Graphics(g);
g.dispose();
});

Clazz.newMeth(C$, 'paintOsi$java_awt_Graphics', function (g) {
var x = 0;
var y = 0;
var startRow = 0;
var startCol = 0;
if (!this.showRowHeader) startCol = 1;
if (!this.showColHeader) startRow = 1;
for (var i = startRow; i < this.nRows; i++) {
x = 0;
for (var j = startCol; j < this.nCols; j++) {
this.cells[i][j].paint$java_awt_Graphics$I$I(g, x, y);
x = x+(this.cells[0][j].width);
}
y = y+(this.cells[i][0].height);
}
});

Clazz.newMeth(C$, 'getPreferredSize', function () {
var w = this.currentWidth;
var h = this.currentHeight;
if (!this.showRowHeader) w = w-(this.cells[0][0].width);
if (!this.showColHeader) h = h-(this.cells[0][0].height);
return Clazz.new_((I$[6]||$incl$(6)).c$$I$I,[w, h]);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "SGrid$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
this.b$['edu.davidson.views.SGrid'].this_mouseClicked$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[7]||$incl$(7)), [this, null],P$.SGrid$1)));
});

Clazz.newMeth(C$, 'this_mouseClicked$java_awt_event_MouseEvent', function (e) {
if (!this.showHLCell) return;
if (this.hlCell != null ) {
if (this.hlCell.row == 0) this.highlightCol$I$Z(this.hlCell.col, false);
 else if (this.hlCell.col == 0) this.highlightRow$I$Z(this.hlCell.row, false);
 else {
this.hlCell.highlight = false;
this.hlCell.paint();
this.hlCell.paintOSI();
}}var xpix = e.getX();
var ypix = e.getY();
this.hlCell = this.getCellFromPix$I$I(xpix, ypix);
if (this.hlCell == null ) return;
if (this.hlCell.col == 0 && this.hlCell.row == 0 ) this.hlCell = null;
if (this.hlCell != null ) {
if (this.hlCell.row == 0) this.highlightCol$I$Z(this.hlCell.col, true);
 else if (this.hlCell.col == 0) this.highlightRow$I$Z(this.hlCell.row, true);
 else {
this.hlCell.highlight = true;
this.hlCell.paint();
this.hlCell.paintOSI();
}if (this.gridpanel != null ) {
this.gridpanel.rowField.setText$S(this.cells[this.hlCell.row][0].str);
this.gridpanel.colField.setText$S(this.cells[0][this.hlCell.col].str);
this.gridpanel.cellField.setText$S(this.cells[this.hlCell.row][this.hlCell.col].str);
this.gridpanel.rowField.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.gridpanel.colField.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.gridpanel.cellField.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
}}});

Clazz.newMeth(C$, 'setActiveCell$I$I', function (i, j) {
if (this.hlCell != null ) {
if (this.hlCell.row == 0) this.highlightCol$I$Z(this.hlCell.col, false);
 else if (this.hlCell.col == 0) this.highlightRow$I$Z(this.hlCell.row, false);
 else {
this.hlCell.highlight = false;
this.hlCell.paint();
this.hlCell.paintOSI();
}}if (i < 0 || j < 0  || i > this.nRows  || j > this.nCols ) return false;
if (i == 0 && j == 0 ) return false;
this.hlCell = this.cells[i][j];
if (this.hlCell.col == 0 && this.hlCell.row == 0 ) this.hlCell = null;
if (this.hlCell != null ) {
if (this.hlCell.row == 0) this.highlightCol$I$Z(this.hlCell.col, true);
 else if (this.hlCell.col == 0) this.highlightRow$I$Z(this.hlCell.row, true);
 else {
this.hlCell.highlight = true;
this.hlCell.paint();
this.hlCell.paintOSI();
}if (this.gridpanel != null ) {
this.gridpanel.rowField.setText$S(this.cells[this.hlCell.row][0].str);
this.gridpanel.colField.setText$S(this.cells[0][this.hlCell.col].str);
this.gridpanel.cellField.setText$S(this.cells[this.hlCell.row][this.hlCell.col].str);
this.gridpanel.rowField.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.gridpanel.colField.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
this.gridpanel.cellField.setBackground$java_awt_Color((I$[1]||$incl$(1)).white);
}}return true;
});

Clazz.newMeth(C$, 'setShowActiveCell$Z', function (show) {
this.showHLCell = show;
if (show || this.hlCell == null  ) return;
if (this.hlCell.row == 0) this.highlightCol$I$Z(this.hlCell.col, false);
 else if (this.hlCell.col == 0) this.highlightRow$I$Z(this.hlCell.row, false);
 else {
this.hlCell.highlight = false;
this.hlCell.paint();
this.hlCell.paintOSI();
}this.hlCell = null;
});

Clazz.newMeth(C$, 'setShowColHeader$Z', function (show) {
if (this.showColHeader == show ) return;
this.showColHeader = show;
this.osi = null;
this.invalidate();
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setShowRowHeader$Z', function (show) {
if (this.showRowHeader == show ) return;
this.showRowHeader = show;
this.osi = null;
this.invalidate();
if (this.autoRefresh) this.repaint();
});

Clazz.newMeth(C$, 'setLastOnTop$Z', function (lot) {
this.lastOnTop = lot;
});
;
(function(){var C$=Clazz.newClass(P$.SGrid, "Cell", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.centered = false;
this.row = 0;
this.col = 0;
this.x = 0;
this.y = 0;
this.width = 0;
this.height = 0;
this.str = null;
this.highlight = false;
this.hlFontColor = null;
this.hlBGColor = null;
this.bgColor = null;
this.format = null;
this.value = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.centered = false;
this.row = 0;
this.col = 0;
this.x = 0;
this.y = 0;
this.width = this.this$0.defaultCellWidth;
this.height = this.this$0.defaultCellHeight;
this.str = "";
this.highlight = false;
this.hlFontColor = (I$[1]||$incl$(1)).red;
this.hlBGColor = this.this$0.silver;
this.bgColor = (I$[1]||$incl$(1)).white;
this.format = this.this$0.defaultFormat;
this.value = 0;
}, 1);

Clazz.newMeth(C$, 'c$$I$I', function (r, c) {
C$.$init$.apply(this);
this.row = r;
this.col = c;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics$I$I', function (g, x, y) {
this.x = x;
this.y = y;
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint', function () {
var g = this.this$0.getGraphics();
if (g == null ) return;
this.paint$java_awt_Graphics(g);
g.dispose();
});

Clazz.newMeth(C$, 'paintOSI', function () {
var g = null;
try {
if (this.this$0.osi == null ) return;
g = this.this$0.osi.getGraphics();
if (g == null ) return;
this.paint$java_awt_Graphics(g);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
} finally {
if (g != null ) g.dispose();
}
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.highlight) {
g.setColor$java_awt_Color(this.hlBGColor);
} else {
g.setColor$java_awt_Color(this.bgColor);
}g.fillRect$I$I$I$I(this.x, this.y, this.width - 1, this.height - 1);
if (this.highlight) {
g.setColor$java_awt_Color(this.hlFontColor);
g.setFont$java_awt_Font(this.this$0.hlFont);
} else {
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
if (this.row == 0 || this.col == 0 ) g.setFont$java_awt_Font(this.this$0.hlFont);
 else g.setFont$java_awt_Font(this.this$0.$font);
}g.drawRect$I$I$I$I(this.x, this.y, this.width - 1, this.height - 1);
var xoff = 4;
if (this.centered) {
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
xoff = ((this.width - fm.stringWidth$S(this.str))/2|0);
}g.drawString$S$I$I(this.str, this.x + xoff, this.y + this.height - 5);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
});

Clazz.newMeth(C$, 'setValue$D', function (v) {
this.value = v;
if (this.value > 1.0E127 ) this.str = "NaN";
 else this.str = this.format.form$D(v);
this.paintOSI();
if (this.this$0.autoRefresh) this.paint();
});

Clazz.newMeth(C$, 'setValue$S', function (s) {
try {
this.value = Double.$valueOf(this.str).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.NumberFormatException")){
this.value = 0;
} else {
throw e;
}
}
if (this.value > 1.0E127 ) this.str = "NaN";
 else this.str = s;
this.paintOSI();
if (this.this$0.autoRefresh) this.paint();
});

Clazz.newMeth(C$, 'getValue', function () {
return this.value;
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-02-22 01:07:18
