(function(){var P$=Clazz.newPackage("bfield"),I$=[];
var C$=Clazz.newClass(P$, "FieldImage", null, 'edu.davidson.display.ImageThing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fieldPanel=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$bfield_FieldPanel$java_awt_Image$D$D', function (owner, fp, im, x, y) {
C$.superclazz.c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$java_awt_Image$D$D.apply(this, [owner, fp, im, x, y]);
C$.$init$.apply(this);
this.fieldPanel=fp;
this.varStrings=Clazz.array(String, -1, ["x", "y", "bx", "by"]);
this.ds=Clazz.array(Double.TYPE, [1, 4]);
}, 1);

Clazz.newMeth(C$, 'getVariables$', function () {
this.ds[0][0]=this.x;
this.ds[0][1]=this.y;
this.ds[0][2]=this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, null);
this.ds[0][3]=this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, null);
return this.ds;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:46 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
