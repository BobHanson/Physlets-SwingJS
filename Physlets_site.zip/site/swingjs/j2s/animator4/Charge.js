(function(){var P$=Clazz.newPackage("animator4"),I$=[];
var C$=Clazz.newClass(P$, "Charge", null, 'animator4.Circle');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.q = 0;
this.range = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.q = 1;
this.range = 1.0E-4;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$S$S$D', function (o, diameter, xStr, yStr, q) {
C$.superclazz.c$$animator4_AnimatorCanvas$I$S$S.apply(this, [o, diameter, xStr, yStr]);
C$.$init$.apply(this);
this.s = 1;
this.w = diameter;
this.h = diameter;
this.q = q;
this.range = diameter / 2.0 / this.canvas.pixPerUnit ;
this.setForce$S$S$D$D$D$D("0", "0", this.getX(), this.getY(), 0, 0);
this.canvas.dynamics.addRateEquation$animator4_Thing(this);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-08 01:51:30
