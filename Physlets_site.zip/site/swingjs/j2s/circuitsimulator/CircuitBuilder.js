(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'symantec.itools.awt.BorderPanel','circuitsimulator.BuilderPanel','java.util.Vector','circuitsimulator.Circuit','java.awt.Color',['circuitsimulator.CircuitBuilder','.SymMouse'],'circuitsimulator.PopupOnElement','javax.swing.Timer','Thread','java.awt.Cursor','java.awt.Point','edu.davidson.tools.SUtil','java.net.URL','java.io.BufferedReader','java.io.InputStreamReader']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "CircuitBuilder", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'circuitsimulator.Circuit');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.borderPanel=null;
this.builderPanel=null;
this.popupOnElement=null;
this.currentElement=null;
this.scopeList=null;
this.meterList=null;
this.graphList=null;
this.componentList=null;
this.oscdiag=null;
this.meter=null;
this.graph=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.borderPanel=Clazz.new_(Clazz.load('symantec.itools.awt.BorderPanel'));
this.builderPanel=Clazz.new_(Clazz.load('circuitsimulator.BuilderPanel'));
this.currentElement=null;
this.scopeList=Clazz.new_(Clazz.load('java.util.Vector'));
this.meterList=Clazz.new_($I$(3));
this.graphList=Clazz.new_($I$(3));
this.componentList="";
this.oscdiag=null;
this.meter=null;
this.graph=null;
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
C$.superclazz.prototype.init$.apply(this, []);
this.setLayout$java_awt_LayoutManager(null);
if (!Clazz.load('circuitsimulator.Circuit').isJS) this.setBackground$java_awt_Color(Clazz.new_(Clazz.load('java.awt.Color').c$$I$I$I,[0, 143, 213]));
this.setSize$I$I(514, 445);
try {
this.borderPanel.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setIPadBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setIPadSides$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setIPadTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.borderPanel.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.borderPanel.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.borderPanel);
this.borderPanel.setBounds$I$I$I$I(0, 0, 514, 444);
try {
this.builderPanel.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setBevelStyle$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.builderPanel.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.builderPanel.setLayout$java_awt_LayoutManager(null);
this.borderPanel.add$java_awt_Component(this.builderPanel);
if (!$I$(4).isJS) this.builderPanel.setBackground$java_awt_Color(Clazz.new_($I$(5).c$$I$I$I,[0, 143, 213]));
this.builderPanel.setBounds$I$I$I$I(313, 17, 195, 401);
var aSymMouse=Clazz.new_(Clazz.load(['circuitsimulator.CircuitBuilder','.SymMouse']), [this, null]);
this.circanvas.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.builderPanel.setcircuitBuilder$circuitsimulator_CircuitBuilder(this);
this.builderPanel.loadImages$();
});

Clazz.newMeth(C$, ['start$','start'], function () {
C$.superclazz.prototype.start$.apply(this, []);
this.gridZone.width=this.builderPanel.getBounds$().x;
this.popupOnElement=Clazz.new_(Clazz.load('circuitsimulator.PopupOnElement').c$$circuitsimulator_CircuitBuilder,[this]);
this.loadList$S("/lists/default.txt");
this.parse$();
this.calculateCircuit$();
});

Clazz.newMeth(C$, ['runTimer$','runTimer'], function () {
this.timer=Clazz.new_(Clazz.load('javax.swing.Timer').c$$I$java_awt_event_ActionListener,[this.sleepTime, ((P$.CircuitBuilder$1||
(function(){var C$=Clazz.newClass(P$, "CircuitBuilder$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed','actionPerformed$'], function (e) {
for (var enu=this.b$['circuitsimulator.CircuitBuilder'].meterList.elements$(); enu.hasMoreElements$(); ) {
this.b$['circuitsimulator.CircuitBuilder'].meter=enu.nextElement$();
this.b$['circuitsimulator.CircuitBuilder'].meter.recalc$();
}
this.b$['circuitsimulator.CircuitBuilder'].circanvas.repaint$();
if (this.b$['circuitsimulator.CircuitBuilder'].runner != null ) this.b$['circuitsimulator.CircuitBuilder'].runTimer$.apply(this.b$['circuitsimulator.CircuitBuilder'], []);
});
})()
), Clazz.new_(P$.CircuitBuilder$1.$init$, [this, null]))]);
this.timer.setRepeats$Z(false);
this.timer.start$();
});

Clazz.newMeth(C$, ['run$','run'], function () {
if ($I$(4).isJS) {
System.err.println$S("Error.  Thread should not start when using JavaScript.");
return;
}while (this.runner === Clazz.load('Thread').currentThread$() ){
if (this.parsed) {
this.circanvas.repaint$();
}for (var enu=this.meterList.elements$(); enu.hasMoreElements$(); ) {
this.meter=enu.nextElement$();
this.meter.recalc$();
}
try {
$I$(9).sleep$J(100);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}
}
});

Clazz.newMeth(C$, 'circanvas_MousePressed$java_awt_event_MouseEvent', function (event) {
this.currentElement=this.getComponent$S(this.coordString$java_awt_Point$Z(event.getPoint$(), false));
if (!!((event.isMetaDown$() == true ) | (event.isControlDown$() == true ))) {
this.popupOnElement.selectItems$();
this.add$java_awt_PopupMenu(this.popupOnElement);
this.popupOnElement.show$java_awt_Component$I$I(event.getComponent$(), event.getX$(), event.getY$());
} else {
this.circanvas.setCursor$java_awt_Cursor(Clazz.load('java.awt.Cursor').getPredefinedCursor$I(12));
}if ((this.debugLevel & $I$(4).DEBUG_IO) > 0) {
System.out.println$S(this.currentElement.getMyName$());
}});

Clazz.newMeth(C$, 'circanvas_mouseReleased$java_awt_event_MouseEvent', function (event) {
if (!!((event.isMetaDown$() == false ) & (event.isControlDown$() == false ))) {
this.moveComponent$circuitsimulator_CircuitElement$S(this.currentElement, this.coordString$java_awt_Point$Z(event.getPoint$(), false));
this.circanvas.setCursor$java_awt_Cursor($I$(10).getDefaultCursor$());
this.parse$();
this.repaintMeters$();
}});

Clazz.newMeth(C$, ['step$D$D','step','step$'], function (dt, time) {
C$.superclazz.prototype.step$D$D.apply(this, [dt, time]);
if ((this.parsed) && !this.graphList.isEmpty$() ) {
for (var e=this.graphList.elements$(); e.hasMoreElements$(); ) {
this.graph=e.nextElement$();
this.graph.addData$();
}
}});

Clazz.newMeth(C$, ['reset$','reset'], function () {
C$.superclazz.prototype.reset$.apply(this, []);
if ((this.parsed) && !this.graphList.isEmpty$() ) {
for (var e=this.graphList.elements$(); e.hasMoreElements$(); ) {
this.graph=e.nextElement$();
this.graph.clearGraph$();
}
}});

Clazz.newMeth(C$, ['coordString$java_awt_Point$Z','coordString'], function (absCoords, absolute) {
var circanvasP=Clazz.new_(Clazz.load('java.awt.Point').c$$I$I,[0, 0]);
if (absolute) {
circanvasP.setLocation$java_awt_Point(this.circanvas.getLocation$());
}var posString="row=";
var diffx;
var diffy;
var x;
var y;
var row=-1;
var col=-1;
x=absCoords.x - circanvasP.x;
y=absCoords.y - circanvasP.y;
do {
col++;
diffx=(this.interGrid/2|0) + this.interGrid * col - x;
} while (diffx < 0);
do {
row++;
diffy=(this.interGrid/2|0) + this.interGrid * row - y;
} while (diffy < 0);
if (!!((diffx >= diffy) & (diffx + diffy >= this.interGrid))) {
posString += Integer.toString$I(row - 1) + ",col=" + Integer.toString$I(col - 1) + ",to=v" ;
} else if (!!((diffx >= diffy) & (diffx + diffy < this.interGrid))) {
posString += Integer.toString$I(row) + ",col=" + Integer.toString$I(col - 1) + ",to=h" ;
} else if (!!((diffx < diffy) & (diffy + diffx >= this.interGrid))) {
posString += Integer.toString$I(row - 1) + ",col=" + Integer.toString$I(col - 1) + ",to=h" ;
} else if (!!((diffx < diffy) & (diffy + diffx < this.interGrid))) {
posString += Integer.toString$I(row - 1) + ",col=" + Integer.toString$I(col) + ",to=v" ;
}if ((this.debugLevel & $I$(4).DEBUG_IO) > 0) {
System.out.println$S(posString);
}return posString;
});

Clazz.newMeth(C$, ['repaintMeters$','repaintMeters'], function () {
if (this.parsed) {
this.calculateCircuit$();
for (var e=this.scopeList.elements$(); e.hasMoreElements$(); ) {
this.oscdiag=e.nextElement$();
this.oscdiag.scopeCanvas.repaint$();
}
for (var e=this.meterList.elements$(); e.hasMoreElements$(); ) {
this.meter=e.nextElement$();
this.meter.recalc$();
}
}});

Clazz.newMeth(C$, ['parseCommand$S','parseCommand'], function (s) {
s="" + Clazz.load('edu.davidson.tools.SUtil').removeWhitespace$S(s);
if ($I$(12).parameterExist$S$S(s, "setGrid")) {
var parameters= String.instantialize(s.substring$I$I(9, s.length$() - 3));
var rows=($I$(12).getParam$S$S(parameters, "rows=")|0);
var cols=($I$(12).getParam$S$S(parameters, "cols=")|0);
this.setGrid$I$I(rows, cols);
} else if ($I$(12).parameterExist$S$S(s, "setNumberOfDT")) {
var par=Integer.parseInt$S(s.substring$I$I(s.indexOf$S("(") + 1, s.indexOf$S(")")));
this.setNumberOfDT$I(par);
} else if ($I$(12).parameterExist$S$S(s, "setDT")) {
var par=(Double.valueOf$S(s.substring$I$I(s.indexOf$S("(") + 1, s.indexOf$S(")")))).doubleValue$();
this.setDT$D(par);
} else if ($I$(12).parameterExist$S$S(s, "setNOC")) {
var par=Integer.parseInt$S(s.substring$I$I(s.indexOf$S("(") + 1, s.indexOf$S(")")));
this.setNOC$I(par);
} else if ($I$(12).parameterExist$S$S(s, "setFPS")) {
var par=(Double.valueOf$S(s.substring$I$I(s.indexOf$S("(") + 1, s.indexOf$S(")")))).doubleValue$();
this.setFPS$D(par);
} else if ($I$(12).parameterExist$S$S(s, "addObject")) {
var name= String.instantialize(s.substring$I$I(s.indexOf$S("(\"") + 2, s.indexOf$S("\",")));
var list= String.instantialize(s.substring$I$I(s.indexOf$S(",\"") + 2, s.indexOf$S("\")")));
this.addObject$S$S(name, list);
}});

Clazz.newMeth(C$, 'loadList$S', function (inputfile) {
var trydoc=false;
var s="";
try {
if ($I$(4).DEBUG) {
System.out.println$S("loading from codebase:" + this.getCodeBase$().toString() + inputfile );
}var url=Clazz.new_(Clazz.load('java.net.URL').c$$S,[this.getCodeBase$().toString() + inputfile]);
var $in=url.openStream$();
var br=Clazz.new_(Clazz.load('java.io.BufferedReader').c$$java_io_Reader,[Clazz.new_(Clazz.load('java.io.InputStreamReader').c$$java_io_InputStream,[$in])]);
var line;
while ((line=br.readLine$()) != null ){
s += line + "\n";
this.parseCommand$S(line);
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
trydoc=true;
if ($I$(4).DEBUG) {
System.out.println$S("load failed from docbase: " + e.getMessage$());
}} else {
throw e;
}
}
if (trydoc) {
s="";
try {
var pathName=this.getDocumentBase$().toString();
if (pathName.endsWith$S(".html") || pathName.endsWith$S(".htm") ) {
var index=pathName.lastIndexOf$S("/");
pathName=pathName.substring$I$I(0, index + 1);
}var url=Clazz.new_($I$(13).c$$S,[pathName + inputfile]);
var $in=url.openStream$();
var br=Clazz.new_($I$(14).c$$java_io_Reader,[Clazz.new_($I$(15).c$$java_io_InputStream,[$in])]);
var line;
while ((line=br.readLine$()) != null ){
s += line + "\n";
this.parseCommand$S(line);
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S("load failed: " + e.getMessage$());
this.setGrid$S("rows=8,cols=5");
} else {
throw e;
}
}
}});
;
(function(){var C$=Clazz.newClass(P$.CircuitBuilder, "SymMouse", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.MouseAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0.circanvas ) {
this.this$0.circanvas_mouseReleased$java_awt_event_MouseEvent.apply(this.this$0, [event]);
}});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
if (object === this.this$0.circanvas ) {
this.this$0.circanvas_MousePressed$java_awt_event_MouseEvent.apply(this.this$0, [event]);
}});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:15 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
