(function(){var P$=Clazz.newPackage("animator4"),I$=[['animator4.Thing','edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Box", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$I$S$S', function (o, width, height, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.s = 1;
this.w = width;
this.h = height;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.vars[1]) - (this.w/2|0) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.vars[2]) - (this.h/2|0) - this.yDisplayOff;
this.paintGhosts$java_awt_Graphics(g);
g.setColor$java_awt_Color(this.color);
for (var i = 0; i <= this.s; i++) g.drawRect$I$I$I$I(ptX + i, ptY + i, this.w - 2 * i, this.h - 2 * i);

this.paintTrail$java_awt_Graphics(g);
this.paintLabel$java_awt_Graphics$I$I(g, ptX + (this.w/2|0), ptY + (this.h/2|0));
if (this.showCoordinates) this.paintCoordinates$java_awt_Graphics$I$I(g, ptX + (this.w/2|0), ptY + (this.h/2|0));
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.vars[1]) - (this.w/2|0) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.vars[2]) - (this.h/2|0) - this.yDisplayOff;
this.paintGhosts$java_awt_Graphics(g);
if (this.color === this.highlightColor ) g.setColor$java_awt_Color((I$[1]||$incl$(1)).lightBlue);
 else g.setColor$java_awt_Color(this.highlightColor);
g.drawRect$I$I$I$I(ptX, ptY, this.w, this.h);
g.drawRect$I$I$I$I(ptX - 1, ptY - 1, this.w + 2, this.h + 2);
C$.superclazz.prototype.paintHighlight$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.canvas.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.vars[2]) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < (this.w/2|0) + 1) && (Math.abs(yPix - ptY) < (this.h/2|0) + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'paintGhosts$java_awt_Graphics', function (g) {
if (!this.visible) return;
if (this.ghost && this.footPrints > 0  && this.trailSize > 1  && this.trail.npoints > 1 ) {
g.setColor$java_awt_Color((I$[2]||$incl$(2)).veryPaleColor$java_awt_Color(this.color));
for (var i = 0; i < this.trail.npoints; i = i+(this.footPrints)) for (var j = 0; j <= this.s; j++) g.drawRect$I$I$I$I(this.trail.xpoints[i] - (this.w/2|0) + j + this.xDisplayOff, this.trail.ypoints[i] - (this.h/2|0) + j - this.yDisplayOff, this.w - 2 * j, this.h - 2 * j);


}});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:20:58
