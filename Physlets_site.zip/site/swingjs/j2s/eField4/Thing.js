(function(){var P$=Clazz.newPackage("eField4"),I$=[['edu.davidson.display.Format','java.awt.Color','java.awt.Polygon','java.awt.Font','java.util.Vector','edu.davidson.tools.SApplet','edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Thing", null, null, 'edu.davidson.tools.SDataSource');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.format = null;
this.darkGreen = null;
this.lightGreen = null;
this.p = null;
this.s = 0;
this.w = 0;
this.h = 0;
this.color = null;
this.highlightColor = null;
this.vars = null;
this.initVars = null;
this.varStrings = null;
this.ds = null;
this.mag = 0;
this.pe = 0;
this.flux = 0;
this.sticky = false;
this.ghost = false;
this.showFOnDrag = false;
this.showVVector = false;
this.showAVector = false;
this.showFVector = false;
this.showFComponents = false;
this.showVComponents = false;
this.trail = null;
this.trailSize = 0;
this.damping = 0;
this.label = null;
this.noDrag = false;
this.hideThing = false;
this.disabled = false;
this.footPrints = 0;
this.mass = 0;
this.dynamic = false;
this.font = null;
this.xStr = null;
this.yStr = null;
this.xFunc = null;
this.yFunc = null;
this.constraint = null;
this.constraintStr = null;
this.constraintMin = 0;
this.constraintMax = 0;
this.showConstraintPath = false;
this.constrainX = false;
this.constrainY = false;
this.constrainR = false;
this.hasConstraint = false;
this.constantX = 0;
this.constantY = 0;
this.constantRx = 0;
this.constantRy = 0;
this.constantR = 0;
this.xDisplayOff = 0;
this.yDisplayOff = 0;
this.myMaster = null;
this.mySlaves = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.format = Clazz.new_((I$[1]||$incl$(1)).c$$S,["%-+6.3g"]);
this.darkGreen = Clazz.new_((I$[2]||$incl$(2)).c$$I$I$I,[0, 128, 0]);
this.lightGreen = Clazz.new_((I$[2]||$incl$(2)).c$$I$I$I,[128, 255, 128]);
this.s = 5;
this.w = 5;
this.h = 5;
this.color = (I$[2]||$incl$(2)).black;
this.highlightColor = (I$[2]||$incl$(2)).gray;
this.vars = Clazz.array(Double.TYPE, [7]);
this.initVars = Clazz.array(Double.TYPE, [7]);
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "vx", "vy", "ax", "ay"]);
this.ds = Clazz.array(Double.TYPE, [1, 7]);
this.mag = 1;
this.pe = 0;
this.flux = 0;
this.sticky = false;
this.ghost = false;
this.showFOnDrag = false;
this.showVVector = false;
this.showAVector = false;
this.showFVector = false;
this.showFComponents = false;
this.showVComponents = false;
this.trail = Clazz.new_((I$[3]||$incl$(3)));
this.trailSize = 0;
this.damping = 0;
this.label = null;
this.noDrag = true;
this.hideThing = false;
this.disabled = false;
this.footPrints = 0;
this.mass = 1.0;
this.dynamic = false;
this.font = Clazz.new_((I$[4]||$incl$(4)).c$$S$I$I,["Monospaced", 0, 14]);
this.xFunc = null;
this.yFunc = null;
this.constraint = null;
this.constraintStr = null;
this.constraintMin = 0;
this.constraintMax = 0;
this.showConstraintPath = true;
this.constrainX = false;
this.constrainY = false;
this.constrainR = false;
this.hasConstraint = false;
this.constantX = 0;
this.constantY = 0;
this.constantRx = 0;
this.constantRy = 0;
this.constantR = 0;
this.xDisplayOff = 0;
this.yDisplayOff = 0;
this.myMaster = null;
this.mySlaves = Clazz.new_((I$[5]||$incl$(5)));
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$D$D', function (p, x, y, vx, vy) {
C$.c$$eField4_OdeCanvas$D$D$D$D$D.apply(this, [p, x, y, vx, vy, 1.0]);
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$D$D$D', function (p, x, y, vx, vy, m) {
C$.$init$.apply(this);
this.p = p;
this.vars[0] = 0;
this.vars[1] = x;
this.vars[2] = y;
this.vars[3] = vx;
this.vars[4] = vy;
this.vars[5] = 0;
this.vars[6] = 0;
this.initVars[0] = 0;
this.initVars[1] = x;
this.initVars[2] = y;
this.initVars[3] = vx;
this.initVars[4] = vy;
this.initVars[5] = 0;
this.initVars[6] = 0;
this.mag = m;
try {
(I$[6]||$incl$(6)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'isNoDrag', function () {
return this.noDrag;
});

Clazz.newMeth(C$, 'setNoDrag$Z', function (nd) {
this.noDrag = nd;
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.p.getOwner();
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (i, j) {
return false;
});

Clazz.newMeth(C$, 'isShowFVector', function () {
return this.showFVector;
});

Clazz.newMeth(C$, 'setShowFVector$Z', function (sf) {
this.showFVector = sf;
});

Clazz.newMeth(C$, 'getSize', function () {
return this.s;
});

Clazz.newMeth(C$, 'setSize$I', function (sz) {
this.s = sz;
});

Clazz.newMeth(C$, 'getColor', function () {
return this.color;
});

Clazz.newMeth(C$, 'setColor$java_awt_Color', function (c) {
this.color = c;
});

Clazz.newMeth(C$, 'isHideThing', function () {
return this.hideThing;
});

Clazz.newMeth(C$, 'setHideThing$Z', function (hide) {
this.hideThing = hide;
});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
try {
this.format = Clazz.new_((I$[1]||$incl$(1)).c$$S,[str]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.IllegalArgumentException")){
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'getLabel', function () {
return this.label;
});

Clazz.newMeth(C$, 'setLabel$S', function (l) {
if (l == null  || l.trim().equals$O("") ) this.label = null;
 else this.label =  String.instantialize(Clazz.array(Character.TYPE, -1, [l.charAt(0)]));
});

Clazz.newMeth(C$, 'isShowV', function () {
return this.showVVector;
});

Clazz.newMeth(C$, 'setShowV$Z', function (sv) {
this.showVVector = sv;
});

Clazz.newMeth(C$, 'enclosedCharge', function () {
var pole;
var sum = 0;
var xpix;
var ypix;
var n = this.p.poles.size();
for (var i = 0; i < n; i++) {
pole = this.p.poles.elementAt$I(i);
xpix = this.p.pixFromX$D(pole.vars[1]);
ypix = this.p.pixFromY$D(pole.vars[2]);
if (this.isInsideThing$I$I(xpix, ypix)) {
sum += pole.mag;
}}
return sum;
});

Clazz.newMeth(C$, 'calculateState', function () {
});

Clazz.newMeth(C$, 'enforceConstraintOnX', function () {
var speed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
if (this.vars[4] == 0 ) this.vars[4] = speed;
 else this.vars[4] = speed * this.vars[4] / Math.abs(this.vars[4]);
this.vars[3] = 0;
if (this.constraintMin < this.constraintMax ) {
if (this.vars[2] < this.constraintMin ) {
this.vars[2] = this.constraintMin;
if (this.vars[4] < 0 ) {
this.vars[4] = -this.vars[4];
}} else if (this.vars[2] > this.constraintMax ) {
this.vars[2] = this.constraintMax;
if (this.vars[4] > 0 ) {
this.vars[4] = -this.vars[4];
}}}this.vars[1] = this.constantX;
return;
});

Clazz.newMeth(C$, 'enforceConstraintOnY', function () {
var speed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
if (this.vars[3] == 0 ) this.vars[3] = speed;
 else this.vars[3] = speed * this.vars[3] / Math.abs(this.vars[3]);
this.vars[4] = 0;
if (this.constraintMin < this.constraintMax ) {
if (this.vars[1] < this.constraintMin ) {
this.vars[1] = this.constraintMin;
if (this.vars[3] < 0 ) {
this.vars[3] = -this.vars[3];
}} else if (this.vars[1] > this.constraintMax ) {
this.vars[1] = this.constraintMax;
if (this.vars[3] > 0 ) {
this.vars[3] = -this.vars[3];
}}}this.vars[2] = this.constantY;
return;
});

Clazz.newMeth(C$, 'enforceConstraintOnR', function () {
var speed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
var rad = Math.sqrt((this.vars[1] - this.constantRx) * (this.vars[1] - this.constantRx) + (this.vars[2] - this.constantRy) * (this.vars[2] - this.constantRy));
if (rad == 0 ) {
this.vars[1] = this.constantRx + this.constantR;
this.vars[2] = this.constantRy;
this.vars[3] = 0;
this.vars[4] = speed;
return;
}var u = (this.vars[1] - this.constantRx) / rad;
var v = (this.vars[2] - this.constantRy) / rad;
this.vars[1] = this.constantR * u;
this.vars[2] = this.constantR * v;
if ((-this.vars[3] * v + this.vars[4] * u) > 0 ) {
this.vars[3] = -speed * v;
this.vars[4] = speed * u;
} else {
this.vars[3] = speed * v;
this.vars[4] = -speed * u;
}return;
});

Clazz.newMeth(C$, 'enforceConstraintOnXY', function () {
if (!this.hasConstraint || this.xFunc != null   || this.yFunc != null  ) return;
 else if (this.constrainX) {
p$.enforceConstraintOnX.apply(this, []);
return;
}if (this.constrainY) {
p$.enforceConstraintOnY.apply(this, []);
return;
} else if (this.constrainR) {
this.enforceConstraintOnR();
return;
}if (this.constraint == null ) return;
var speed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
if (this.constraintMin < this.constraintMax ) {
if (this.vars[1] < this.constraintMin ) {
if (this.vars[3] < 0 ) {
this.vars[3] = -this.vars[3];
this.vars[4] = -this.vars[4];
}p$.adjustPosition$D$D.apply(this, [this.constraintMin, speed]);
return;
} else if (this.vars[1] > this.constraintMax ) {
if (this.vars[3] > 0 ) {
this.vars[3] = -this.vars[3];
this.vars[4] = -this.vars[4];
}p$.adjustPosition$D$D.apply(this, [this.constraintMax, speed]);
return;
}}this.vars[2] = this.constraint.evaluate$D(this.vars[1]);
var m = this.getConstraintSlope$D$D(this.vars[1], Math.abs(this.vars[1]) * 1.0E-5 + 1.0E-6);
var cos = 1 / Math.sqrt(1 + m * m);
if (this.vars[3] > 0 ) {
this.vars[3] = speed * cos;
this.vars[4] = speed * m * cos ;
} else {
this.vars[3] = -speed * cos;
this.vars[4] = -speed * m * cos ;
}return;
});

Clazz.newMeth(C$, 'adjustPosition$D$D', function (x1, v1) {
var u1 = 0;
var u2 = 0;
if (Clazz.instanceOf(this, "eField4.TestCharge")) u1 = this.p.getPE$eField4_Charge(this);
this.vars[1] = x1;
this.vars[2] = this.constraint.evaluate$D(x1);
if (Clazz.instanceOf(this, "eField4.TestCharge")) u2 = this.p.getPE$eField4_Charge(this);
if (u2 - u1 == 0 ) return;
var speed;
var disc = -2 * (u2 - u1) / this.mass + v1 * v1;
if (disc > 0 ) speed = Math.sqrt(disc);
 else speed = 0;
var m = this.getConstraintSlope$D$D(this.vars[1], Math.abs(this.vars[1]) * 1.0E-5 + 1.0E-6);
var cos = 1 / Math.sqrt(1 + m * m);
if (this.vars[3] > 0 ) {
this.vars[3] = speed * cos;
this.vars[4] = speed * m * cos ;
} else {
this.vars[3] = -speed * cos;
this.vars[4] = -speed * m * cos ;
}});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
if (this.myMaster != null ) {
this.vars[1] = this.myMaster.vars[1];
this.vars[2] = this.myMaster.vars[2];
return;
}if (!this.constrainX) this.vars[1] = x;
 else this.vars[2] = y;
if (this.constraint == null  && !this.constrainX  && !this.constrainY  && !this.constrainR ) {
this.vars[2] = y;
return;
}if (this.constrainR) {
this.vars[2] = y;
this.enforceConstraintOnR();
} else this.enforceConstraintOnXY();
});

Clazz.newMeth(C$, 'getX', function () {
return this.vars[1];
});

Clazz.newMeth(C$, 'setX$D', function (x) {
if (this.myMaster != null ) {
this.vars[1] = this.myMaster.vars[1];
return;
}this.vars[1] = x;
if (this.constraint == null  && !this.constrainX  && !this.constrainY  && !this.constrainR ) return;
 else this.enforceConstraintOnXY();
});

Clazz.newMeth(C$, 'getY', function () {
return this.vars[2];
});

Clazz.newMeth(C$, 'setY$D', function (y) {
if (this.myMaster != null ) {
this.vars[2] = this.myMaster.vars[2];
return;
}if (this.constraint != null  || this.constrainY  || this.constrainR ) return;
this.vars[2] = y;
return;
});

Clazz.newMeth(C$, 'setAcceleration', function () {
});

Clazz.newMeth(C$, 'getVX', function () {
return this.vars[3];
});

Clazz.newMeth(C$, 'setVX$D', function (vx) {
if (this.constrainX) return;
this.vars[3] = vx;
return;
});

Clazz.newMeth(C$, 'getVY', function () {
return this.vars[4];
});

Clazz.newMeth(C$, 'setVY$D', function (vy) {
if (this.constrainY) return;
this.vars[4] = vy;
return;
});

Clazz.newMeth(C$, 'getVars', function () {
return this.vars;
});

Clazz.newMeth(C$, 'setSpeed$D', function (newSpeed) {
newSpeed = Math.abs(newSpeed);
if (this.constraint != null  || this.constrainX  || this.constrainY ) {
p$.setConstrainedSpeed$D.apply(this, [newSpeed]);
return;
}var speed = Math.sqrt(this.vars[3] * this.vars[3] + this.vars[4] * this.vars[4]);
if (speed == 0 ) {
this.vars[3] = newSpeed;
this.vars[4] = 0;
return;
}this.vars[3] = newSpeed * this.vars[3] / speed;
this.vars[4] = newSpeed * this.vars[4] / speed;
});

Clazz.newMeth(C$, 'getConstraintSlope$D$D', function (x, dx) {
var f1;
var f2;
var f4;
var f5;
f1 = this.constraint.evaluate$D(x + 2 * dx);
f2 = this.constraint.evaluate$D(x + dx);
f4 = this.constraint.evaluate$D(x - dx);
f5 = this.constraint.evaluate$D(x - 2 * dx);
return (-f1 + 8 * f2 - 8 * f4 + f5) / 12 / dx ;
});

Clazz.newMeth(C$, 'getConstraintSecondDeriv$D$D', function (x, dx) {
var f1;
var f2;
var f3;
f1 = this.constraint.evaluate$D(x + dx);
f2 = this.constraint.evaluate$D(x);
f3 = this.constraint.evaluate$D(x - dx);
return (f1 - 2 * f2 + f3) / dx / dx ;
});

Clazz.newMeth(C$, 'setConstrainedSpeed$D', function (newSpeed) {
if (this.constrainX) {
this.vars[3] = 0;
this.vars[4] = newSpeed;
return;
} else if (this.constrainY) {
this.vars[3] = newSpeed;
this.vars[4] = 0;
return;
}var m = this.getConstraintSlope$D$D(this.vars[1], Math.abs(this.vars[1]) * 1.0E-4 + 1.0E-6);
var cos = 1 / Math.sqrt(1 + m * m);
if (this.vars[3] > 0 ) {
this.vars[3] = newSpeed * cos;
this.vars[4] = newSpeed * m * cos ;
} else {
this.vars[3] = -newSpeed * cos;
this.vars[4] = -newSpeed * m * cos ;
}});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.vars[0];
this.ds[0][1] = this.vars[1];
this.ds[0][2] = this.vars[2];
this.ds[0][3] = this.vars[3];
this.ds[0][4] = this.vars[4];
return this.ds;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
;});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paintTrail$java_awt_Graphics', function (osg) {
osg.setColor$java_awt_Color(this.color);
if (this.trailSize > 1 && this.trail.npoints > 1 ) {
if (this.footPrints == 0) osg.drawPolyline$IA$IA$I(this.trail.xpoints, this.trail.ypoints, this.trail.npoints);
 else {
for (var i = 0; i < this.trail.npoints; i = i+(this.footPrints)) {
osg.drawLine$I$I$I$I(this.trail.xpoints[i] - 2, this.trail.ypoints[i], this.trail.xpoints[i] + 2, this.trail.ypoints[i]);
osg.drawLine$I$I$I$I(this.trail.xpoints[i], this.trail.ypoints[i] - 2, this.trail.xpoints[i], this.trail.ypoints[i] + 2);
}
}}});

Clazz.newMeth(C$, 'getTime', function () {
return this.vars[0];
});

Clazz.newMeth(C$, 'setTrailSize$I', function (n) {
this.trailSize = n;
this.clearTrail();
});

Clazz.newMeth(C$, 'clearTrail', function () {
if (this.trail != null  && this.trail.npoints == 0 ) {
;} else this.trail = Clazz.new_((I$[3]||$incl$(3)));
this.incTrail();
});

Clazz.newMeth(C$, 'incTrail', function () {
});

Clazz.newMeth(C$, 'setTime$D$D', function (t, dt) {
if (this.myMaster != null  || this.dynamic ) return;
this.vars[0] = t;
this.vars[5] = 0;
this.vars[6] = 0;
if (this.xFunc == null  || this.yFunc == null  ) return;
var x0 = 0;
var x1 = 0;
var x2 = 0;
var x3 = 0;
var x4 = 0;
var y0 = 0;
var y1 = 0;
var y2 = 0;
var y3 = 0;
var y4 = 0;
try {
x0 = this.xFunc.evaluate$D(t - 2 * dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y0 = this.yFunc.evaluate$D(t - 2 * dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
x1 = this.xFunc.evaluate$D(t - dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y1 = this.yFunc.evaluate$D(t - dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
x2 = this.xFunc.evaluate$D(t);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y2 = this.yFunc.evaluate$D(t);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
x3 = this.xFunc.evaluate$D(t + dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y3 = this.yFunc.evaluate$D(t + dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
x4 = this.xFunc.evaluate$D(t + 2 * dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
try {
y4 = this.yFunc.evaluate$D(t + 2 * dt);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
this.vars[1] = x2;
this.vars[2] = y2;
this.vars[3] = (x3 - x1) / dt / 2 ;
this.vars[4] = (y3 - y1) / dt / 2 ;
this.vars[5] = (-x4 + 16 * x3 - 30 * x2 + 16 * x1 - x0) / dt / dt / 12 ;
this.vars[6] = (-y4 + 16 * y3 - 30 * y2 + 16 * y1 - y0) / dt / dt / 12 ;
return;
});

Clazz.newMeth(C$, 'hasTrajectory', function () {
if (this.xFunc == null  || this.yFunc == null  ) return false;
return true;
});

Clazz.newMeth(C$, 'setTrajectory$S$S', function (xStr, yStr) {
this.vars[0] = this.p.time;
this.vars[1] = 0;
this.vars[2] = 0;
this.vars[3] = 0;
this.vars[4] = 0;
this.vars[5] = 0;
this.vars[6] = 0;
if (xStr == null  || yStr == null  ) {
this.xStr = xStr;
this.yStr = yStr;
this.xFunc = null;
this.yFunc = null;
return true;
}this.xStr = xStr;
this.yStr = yStr;
this.xFunc = Clazz.new_((I$[7]||$incl$(7)).c$$I,[1]);
this.xFunc.defineVariable$I$S(1, "t");
this.xFunc.define$S(xStr);
this.xFunc.parse();
if (this.xFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse trajectory x(t): " + xStr);
System.out.println$S("Parse error: " + this.xFunc.getErrorString() + " at function 1, position " + this.xFunc.getErrorPosition() );
return false;
}this.yFunc = Clazz.new_((I$[7]||$incl$(7)).c$$I,[1]);
this.yFunc.defineVariable$I$S(1, "t");
this.yFunc.define$S(yStr);
this.yFunc.parse();
if (this.yFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse trajectory y(t): " + yStr);
System.out.println$S("Parse error: " + this.yFunc.getErrorString() + " at function 1, position " + this.yFunc.getErrorPosition() );
return false;
}this.setTime$D$D(this.p.time, 0.001);
this.clearTrail();
this.dynamic = false;
if (this.p.autoRefresh) this.p.repaint();
return true;
});

Clazz.newMeth(C$, 'setConstraintStr$S$D$D', function (s, min, max) {
this.constrainX = false;
this.constrainY = false;
this.constrainR = false;
if (s == null  || s.equals$O("") ) {
this.constraintMin = 0;
this.constraintMax = 0;
this.constraintStr = null;
this.constraint = null;
return true;
}this.constraintMin = min;
this.constraintMax = max;
this.constraintStr = s.trim();
this.constraint = Clazz.new_((I$[7]||$incl$(7)).c$$I,[1]);
this.constraint.defineVariable$I$S(1, "x");
this.constraint.define$S(this.constraintStr);
this.constraint.parse();
if (this.constraint.getErrorCode() != 0) {
System.out.println$S("Failed to parse constraint: " + this.constraint.getFunctionString());
System.out.println$S("Parse error: " + this.constraint.getErrorString() + " at position " + this.constraint.getErrorPosition() );
this.constraint = null;
return false;
}this.hasConstraint = true;
this.enforceConstraintOnXY();
if (this.p.autoRefresh) this.p.repaint();
return true;
});

Clazz.newMeth(C$, 'setConstrainR$D$D$D', function (r, x, y) {
this.hasConstraint = true;
this.constraint = null;
this.constrainX = false;
this.constrainY = false;
this.constrainR = true;
this.constantRx = x;
this.constantRy = x;
this.constantR = r;
this.enforceConstraintOnXY();
if (this.p.autoRefresh) this.p.repaint();
return true;
});

Clazz.newMeth(C$, 'setConstrainX$D$D$D', function (x, min, max) {
this.hasConstraint = true;
this.constraint = null;
this.constrainX = true;
this.constrainY = false;
this.constrainR = false;
this.constraintMin = min;
this.constraintMax = max;
this.constantX = x;
this.enforceConstraintOnXY();
if (this.p.autoRefresh) this.p.repaint();
return true;
});

Clazz.newMeth(C$, 'setConstrainY$D$D$D', function (y, min, max) {
this.hasConstraint = true;
this.constraint = null;
this.constrainX = false;
this.constrainY = true;
this.constrainR = false;
this.constraintMin = min;
this.constraintMax = max;
this.constantY = y;
this.enforceConstraintOnXY();
if (this.p.autoRefresh) this.p.repaint();
return true;
});

Clazz.newMeth(C$, 'paintConstraintR$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var xpix = this.p.pixFromX$D(this.constantRx);
var ypix = this.p.pixFromY$D(this.constantRy);
var rpix = this.p.pixFromX$D(this.constantRx + this.constantR) - xpix;
xpix = xpix - rpix + this.xDisplayOff;
ypix = ypix - rpix - this.yDisplayOff ;
g.drawOval$I$I$I$I(xpix, ypix, 2 * rpix + 1, 2 * rpix + 1);
});

Clazz.newMeth(C$, 'paintConstraintX$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var bottom;
var top;
var xpix = this.p.pixFromX$D(this.constantX);
if (this.constraintMin < this.constraintMax ) {
bottom = this.p.pixFromY$D(this.constraintMin);
top = this.p.pixFromY$D(this.constraintMax);
} else {
top = r.y;
bottom = r.y + r.height - 1;
}g.drawLine$I$I$I$I(xpix, top, xpix, bottom);
});

Clazz.newMeth(C$, 'paintConstraintY$java_awt_Graphics$java_awt_Rectangle', function (g, r) {
var left;
var right;
var ypix = this.p.pixFromY$D(this.constantY);
if (this.constraintMin < this.constraintMax ) {
left = this.p.pixFromX$D(this.constraintMin);
right = this.p.pixFromX$D(this.constraintMax);
} else {
left = r.x;
right = r.x + r.width - 1;
}g.drawLine$I$I$I$I(left, ypix, right, ypix);
});

Clazz.newMeth(C$, 'paintConstraint$java_awt_Graphics', function (g) {
if (!this.showConstraintPath) return;
if (this.constraint == null  && !this.constrainX  && !this.constrainY  && !this.constrainR ) return;
var r = this.p.getBounds();
r.x = 0;
r.y = 0;
g.setColor$java_awt_Color((I$[2]||$incl$(2)).black);
if (this.constrainX) {
this.paintConstraintX$java_awt_Graphics$java_awt_Rectangle(g, r);
return;
} else if (this.constrainY) {
this.paintConstraintY$java_awt_Graphics$java_awt_Rectangle(g, r);
return;
}if (this.constrainR) {
this.paintConstraintR$java_awt_Graphics$java_awt_Rectangle(g, r);
return;
}if (this.constraint == null ) return;
var left = 0;
var right = 0;
var numPts = 0;
var xmin = 0;
var xmax = 0;
var y1Pix = 0;
var y2Pix = 0;
var x = 0;
var y = 0;
var dx;
if (this.constraintMin < this.constraintMax ) {
left = this.p.pixFromX$D(this.constraintMin);
left = Math.max(left, r.x);
right = this.p.pixFromX$D(this.constraintMax);
right = Math.min(right, r.x + r.width - 1);
xmin = this.constraintMin;
xmax = this.constraintMax;
} else {
left = r.x;
right = r.x + r.width - 1;
xmin = this.p.xFromPix$I(left);
xmax = this.p.xFromPix$I(right);
}numPts = right - left;
dx = (xmax - xmin) / (numPts - 1);
x = xmin;
y = this.constraint.evaluate$D(x);
y1Pix = this.p.pixFromY$D(y);
for (var i = 0; i < numPts - 1; i++) {
x = x + dx;
y = this.constraint.evaluate$D(x);
y2Pix = this.p.pixFromY$D(y);
g.drawLine$I$I$I$I(left + i, y1Pix, left + i + 1 , y2Pix);
y1Pix = y2Pix;
}
});

Clazz.newMeth(C$, 'setVarsFromMaster', function () {
if (this.myMaster == null ) return;
if (Clazz.instanceOf(this, "eField4.TextThing")) this.myMaster.calculateState();
this.vars[0] = this.myMaster.vars[0];
this.vars[1] = this.myMaster.vars[1];
this.vars[2] = this.myMaster.vars[2];
this.vars[3] = this.myMaster.vars[3];
this.vars[4] = this.myMaster.vars[4];
this.vars[5] = this.myMaster.vars[5];
this.vars[6] = this.myMaster.vars[6];
this.mag = this.myMaster.mag;
this.mass = this.myMaster.mass;
this.flux = this.myMaster.flux;
this.pe = this.myMaster.pe;
var t = null;
for (var e = this.mySlaves.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (t !== this  && t.myMaster === this  ) t.setVarsFromMaster();
}
});

Clazz.newMeth(C$, 'updateMySlaves', function () {
var slave = null;
for (var e = this.mySlaves.elements(); e.hasMoreElements(); ) {
slave = e.nextElement();
slave.setVarsFromMaster();
}
});

Clazz.newMeth(C$, 'paintMySlaves$java_awt_Graphics', function (g) {
var slave = null;
for (var e = this.mySlaves.elements(); e.hasMoreElements(); ) {
slave = e.nextElement();
slave.paint$java_awt_Graphics(g);
}
});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:41:49
