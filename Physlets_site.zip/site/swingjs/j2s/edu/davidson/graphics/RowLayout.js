(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[[0,'edu.davidson.graphics.Orientation','java.awt.Dimension']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "RowLayout", null, null, 'java.awt.LayoutManager');
C$._defaultGap=0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$._defaultGap=5;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.gap=0;
this.verticalOrientation=null;
this.horizontalOrientation=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation$I.apply(this, [Clazz.load('edu.davidson.graphics.Orientation').CENTER, $I$(1).CENTER, C$._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (gap) {
C$.c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation$I.apply(this, [$I$(1).CENTER, $I$(1).CENTER, gap]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation', function (horizontalOrient, verticalOrient) {
C$.c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation$I.apply(this, [horizontalOrient, verticalOrient, C$._defaultGap]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_graphics_Orientation$edu_davidson_graphics_Orientation$I', function (horizontalOrient, verticalOrient, gap) {
C$.$init$.apply(this);
if (gap < 0 || (horizontalOrient !== $I$(1).LEFT  && horizontalOrient !== $I$(1).CENTER   && horizontalOrient !== $I$(1).RIGHT  )  || (verticalOrient !== $I$(1).TOP  && verticalOrient !== $I$(1).CENTER   && verticalOrient !== $I$(1).BOTTOM  ) ) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["bad gap or orientation"]);
}this.gap=gap;
this.verticalOrientation=verticalOrient;
this.horizontalOrientation=horizontalOrient;
}, 1);

Clazz.newMeth(C$, 'addLayoutComponent$S$java_awt_Component', function (name, comp) {
});

Clazz.newMeth(C$, 'removeLayoutComponent$java_awt_Component', function (comp) {
});

Clazz.newMeth(C$, 'preferredLayoutSize$java_awt_Container', function (target) {
var insets=target.getInsets$();
var dim=Clazz.new_(Clazz.load('java.awt.Dimension').c$$I$I,[0, 0]);
var ncomponents=target.getComponentCount$();
var comp;
var d;
for (var i=0; i < ncomponents; i++) {
comp=target.getComponent$I(i);
if (comp.isVisible$()) {
d=comp.getPreferredSize$();
dim.width+=d.width;
dim.height=Math.max(d.height, dim.height);
if (i > 0) dim.width+=this.gap;
}}
dim.width+=insets.left + insets.right;
dim.height+=insets.top + insets.bottom;
return dim;
});

Clazz.newMeth(C$, 'minimumLayoutSize$java_awt_Container', function (target) {
var insets=target.getInsets$();
var dim=Clazz.new_($I$(2).c$$I$I,[0, 0]);
var ncomponents=target.getComponentCount$();
var comp;
var d;
for (var i=0; i < ncomponents; i++) {
comp=target.getComponent$I(i);
if (comp.isVisible$()) {
d=comp.getMinimumSize$();
dim.width+=d.width;
dim.height=Math.max(d.height, dim.height);
if (i > 0) dim.width+=this.gap;
}}
dim.width+=insets.left + insets.right;
dim.height+=insets.top + insets.bottom;
return dim;
});

Clazz.newMeth(C$, 'layoutContainer$java_awt_Container', function (target) {
var insets=target.getInsets$();
var ncomponents=target.getComponentCount$();
var top=0;
var left=insets.left;
var tps=target.getPreferredSize$();
var targetSize=target.getSize$();
var comp;
var ps;
if (this.horizontalOrientation === $I$(1).CENTER ) left=left + ((targetSize.width/2|0)) - ((tps.width/2|0));
if (this.horizontalOrientation === $I$(1).RIGHT ) left=left + targetSize.width - tps.width;
for (var i=0; i < ncomponents; i++) {
comp=target.getComponent$I(i);
if (comp.isVisible$()) {
ps=comp.getPreferredSize$();
if (this.verticalOrientation === $I$(1).CENTER ) top=((targetSize.height/2|0)) - ((ps.height/2|0));
 else if (this.verticalOrientation === $I$(1).TOP ) top=insets.top;
 else if (this.verticalOrientation === $I$(1).BOTTOM ) top=targetSize.height - ps.height - insets.bottom ;
comp.setBounds$I$I$I$I(left, top, ps.width, ps.height);
left+=ps.width + this.gap;
}}
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:31 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
