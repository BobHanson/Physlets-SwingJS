(function(){var P$=Clazz.newPackage("animator4"),I$=[['java.util.StringTokenizer','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "AnimatorProperties", null, 'java.util.Properties');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.defaultProperties();
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorProperties', function (defaults) {
C$.superclazz.c$$java_util_Properties.apply(this, [defaults]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getBoolean$S$Z', function (key, def) {
var val = this.getProperty$S(key);
if (val != null ) {
if ("true".equalsIgnoreCase$S(val.trim())) return true;
 else if ("false".equalsIgnoreCase$S(val.trim())) return false;
}return def;
});

Clazz.newMeth(C$, 'getColor$S$java_awt_Color', function (key, def) {
var val = this.getProperty$S(key);
if (val != null ) {
var tkn = Clazz.new_((I$[1]||$incl$(1)).c$$S,[val]);
try {
var r = Integer.parseInt(tkn.nextToken());
var g = Integer.parseInt(tkn.nextToken());
var b = Integer.parseInt(tkn.nextToken());
return Clazz.new_((I$[2]||$incl$(2)).c$$I$I$I,[r, g, b]);
} catch (x) {
if (Clazz.exceptionOf(x, "java.lang.NumberFormatException")){
return def;
} else {
throw x;
}
}
}return def;
});

Clazz.newMeth(C$, 'getDouble$S$D', function (key, def) {
var val = this.getProperty$S(key);
var i = def;
if (val != null ) {
try {
i = Double.$valueOf(val.trim()).doubleValue();
} catch (x) {
if (Clazz.exceptionOf(x, "java.lang.NumberFormatException")){
} else {
throw x;
}
}
}return i;
});

Clazz.newMeth(C$, 'getInt$S$I', function (key, def) {
var val = this.getProperty$S(key);
var i = def;
if (val != null ) {
try {
i = Integer.parseInt(val.trim());
} catch (x) {
if (Clazz.exceptionOf(x, "java.lang.NumberFormatException")){
} else {
throw x;
}
}
}return i;
});

Clazz.newMeth(C$, 'getString$S$S', function (key, def) {
var val = this.getProperty$S(key);
if (val != null ) {
var len = val.length$();
var st = 0;
while ((st < len) && (val.charAt(st) != "\"") ){
st++;
}
st++;
while ((st < len) && (val.charAt(len - 1) != "\"") ){
len--;
}
len--;
if (st < len) return val.substring(st, len);
}return def;
});

Clazz.newMeth(C$, 'getkey$S', function (value) {
var key = "";
for (var e = this.propertyNames(); e.hasMoreElements(); ) {
key = e.nextElement();
if (this.getProperty$S(key).equals$O(value)) return key;
}
return value;
});

Clazz.newMeth(C$, 'defaultProperties', function () {
this.put$TK$TV("time", "Time");
this.put$TK$TV("collision", "Collision");
this.put$TK$TV("play_btn", "Play");
this.put$TK$TV("pause_btn", "Pause");
this.put$TK$TV("reset_btn", "Reset");
this.put$TK$TV("step_forward_btn", ">>");
this.put$TK$TV("step_back_btn", "<<");
});
})();
//Created 2018-02-19 20:23:09
