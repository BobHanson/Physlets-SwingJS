(function(){var P$=Clazz.newPackage("emwave4"),I$=[['emwave4.Wave','edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ParsedWave", null, 'emwave4.Wave');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.parser = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$S$D$D$D$D$java_awt_Color', function (str, z1, z2, pix, p, clr) {
Clazz.super_(C$, this,1);
this.zPropagate = z1;
this.zTerminate = z2;
this.pixPerUnit = pix;
this.polarization = p;
this.length = this.zTerminate - this.zPropagate;
this.numLines = (Math.round(this.length / (I$[1]||$incl$(1)).lineDensity)|0);
this.pts = Clazz.array(Double.TYPE, [2 * this.numLines, 3]);
this.h = this.length / this.pixPerUnit / this.numLines ;
this.c = clr;
this.parser = Clazz.new_((I$[2]||$incl$(2)).c$$I,[1]);
this.parser.defineVariable$I$S(1, "z");
this.parser.define$S(str);
this.parser.parse();
if (this.parser.getErrorCode() != 0) {
return;
}for (var i = 1, j = 0; i < 2 * this.numLines; i = i+(2), j++) {
this.pts[i][0] = this.pixPerUnit * Math.cos(this.polarization) * this.parser.evaluate$D(j * this.h + this.zPropagate / this.pixPerUnit) ;
this.pts[i][1] = this.pixPerUnit * Math.sin(this.polarization) * this.parser.evaluate$D(j * this.h + this.zPropagate / this.pixPerUnit) ;
this.pts[i][2] = j * (I$[1]||$incl$(1)).lineDensity + this.zPropagate;
}
for (var i = 0, j = 0; i < 2 * this.numLines; i = i+(2), j++) {
this.pts[i][0] = 0;
this.pts[i][1] = 0;
this.pts[i][2] = j * (I$[1]||$incl$(1)).lineDensity + this.zPropagate;
}
}, 1);

Clazz.newMeth(C$, 'setFirstStick$I$I', function (incrementer, offset) {
this.pts[0][0] = 0;
this.pts[0][1] = 0;
this.pts[0][2] = this.zPropagate + offset;
this.pts[1][0] = this.pixPerUnit * Math.cos(this.polarization) * this.parser.evaluate$D(incrementer * this.h + ((this.zPropagate / this.pixPerUnit)|0)) ;
this.pts[1][1] = this.pixPerUnit * Math.sin(this.polarization) * this.parser.evaluate$D(incrementer * this.h + ((this.zPropagate / this.pixPerUnit)|0)) ;
this.pts[1][2] = this.zPropagate + offset;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:06
