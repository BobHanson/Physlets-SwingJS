(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[['java.awt.event.MouseAdapter','edu.davidson.graphics.HintThread','java.awt.Color','Thread']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "HintPanel", null, 'a2s.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.text = null;
this.hintVisible = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.text = "";
this.hintVisible = false;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "HintPanel$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (event) {
this.b$['edu.davidson.graphics.HintPanel'].hintVisible = true;
this.b$['edu.davidson.graphics.HintPanel'].repaint();
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (event) {
this.b$['edu.davidson.graphics.HintPanel'].hintVisible = false;
this.b$['edu.davidson.graphics.HintPanel'].repaint();
});
})()
), Clazz.new_((I$[1]||$incl$(1)), [this, null],P$.HintPanel$1)));
}, 1);

Clazz.newMeth(C$, 'setBubbleHelp$S', function (txt) {
if (txt == null ) this.text = "";
 else this.text = txt;
if (this.text.equals$O("")) this.hintVisible = false;
});

Clazz.newMeth(C$, 'updateBubbleHelp$S', function (txt) {
if (true) return;
if (txt == null ) this.text = "";
 else this.text = txt;
if (this.text.equals$O("")) {
this.hintVisible = false;
this.repaint();
} else {
if (!this.hintVisible) Clazz.new_((I$[2]||$incl$(2)).c$$edu_davidson_graphics_HintPanel,[this]);
}});

Clazz.newMeth(C$, 'forceBubbleHelp$S', function (txt) {
if (txt == null ) this.text = "";
 else this.text = txt;
if (this.text.equals$O("")) this.hintVisible = false;
this.repaint();
});

Clazz.newMeth(C$, 'destroyHint', function () {
this.hintVisible = false;
});

Clazz.newMeth(C$, 'paintHint$java_awt_Graphics', function (g) {
if (!this.hintVisible) return;
g.setColor$java_awt_Color((I$[3]||$incl$(3)).yellow);
g.fillRect$I$I$I$I(0, this.getBounds().height - 20, this.getBounds().width - 1, 19);
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
g.drawRect$I$I$I$I(0, this.getBounds().height - 20, this.getBounds().width - 1, 19);
var fm = g.getFontMetrics();
g.drawString$S$I$I(this.text, 2, -fm.getDescent() + this.getBounds().height - 2);
});
})();
//Created 2018-02-06 13:24:17
