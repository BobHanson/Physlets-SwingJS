(function(){var P$=Clazz.newPackage("edu.davidson.graph"),I$=[['java.util.Vector','edu.davidson.graph.MarkerStyle','edu.davidson.graph.MarkerVertex','edu.davidson.graph.Markers']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Markers");
C$.TYPE_DEFAULT = 0;
C$.TYPE_CIRCLE = 0;
C$.TYPE_SQUARE = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.TYPE_DEFAULT = 0;
C$.TYPE_CIRCLE = 1;
C$.TYPE_SQUARE = 2;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.last = 0;
this.max = 0;
this.vert = null;
this.styles = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.max = 10;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.last = 0;
this.vert = Clazz.array((I$[1]||$incl$(1)), [this.max]);
this.styles = Clazz.array((I$[2]||$incl$(2)), [this.max]);
}, 1);

Clazz.newMeth(C$, 'AddMarker$I$I$I', function (m, size, type) {
this.AddMarker$I$I$ZA$IA$IA(m, 1, Clazz.array(Boolean.TYPE, -1, [false]), Clazz.array(Integer.TYPE, -1, [0]), Clazz.array(Integer.TYPE, -1, [0]));
this.styles[m - 1].type = type;
this.styles[m - 1].size = size;
});

Clazz.newMeth(C$, 'getMarkerSize$I', function (m) {
return this.styles[m - 1].size;
});

Clazz.newMeth(C$, 'AddMarker$I$I$ZA$IA$IA', function (m, n, draw, x, y) {
var v;
var i;
if (m < 1 || m > this.max ) return;
if (n <= 0) return;
m--;
this.last = m;
this.vert[m] = Clazz.new_((I$[1]||$incl$(1)));
for (i = 0; i < n; i++) {
v = Clazz.new_((I$[3]||$incl$(3)));
v.draw = draw[i];
v.x = x[i];
v.y = y[i];
this.vert[m].addElement$TE(v);
}
this.styles[m] = Clazz.new_((I$[2]||$incl$(2)));
this.styles[m].type = 0;
});

Clazz.newMeth(C$, 'AddMarker$I$ZA$IA$IA', function (n, draw, x, y) {
this.AddMarker$I$I$ZA$IA$IA(this.last + 1, n, draw, x, y);
});

Clazz.newMeth(C$, 'DeleteMarker$I', function (n) {
if (n < 1 || n > this.max ) return;
this.vert[n - 1] = null;
this.styles[n - 1] = null;
});

Clazz.newMeth(C$, 'ClearMarkers', function () {
var i;
if (this.last == 0) return;
for (i = 0; i < this.max; i++) {
this.vert[i] = null;
this.styles[i] = null;
}
this.last = 0;
});

Clazz.newMeth(C$, 'drawCircle$java_awt_Graphics$D$I$I', function (g, scale, x, y) {
var s = (Math.round(4 * scale)|0);
g.fillOval$I$I$I$I(x - s, y - s, 2 * s + 1, 2 * s + 1);
});

Clazz.newMeth(C$, 'drawSquare$java_awt_Graphics$D$I$I', function (g, scale, x, y) {
var s = (Math.round(4 * scale)|0);
g.fillRect$I$I$I$I(x - s, y - s, 2 * s + 1, 2 * s + 1);
});

Clazz.newMeth(C$, 'draw$java_awt_Graphics$I$D$I$I', function (g, m, scale, x, y) {
var i;
var mv;
var x0 = x;
var x1 = x;
var y0 = y;
var y1 = y;
var v;
if (m < 1 || m > this.max ) return;
if (scale <= 0 ) return;
v = this.vert[m - 1];
if (v == null ) return;
if (this.styles[m - 1].type == C$.TYPE_CIRCLE) {
this.drawCircle$java_awt_Graphics$D$I$I(g, scale, x, y);
return;
} else if (this.styles[m - 1].type == C$.TYPE_SQUARE) {
this.drawSquare$java_awt_Graphics$D$I$I(g, scale, x, y);
return;
}for (i = 0; i < v.size(); i++) {
mv = v.elementAt$I(i);
if (mv.draw) {
x1 = x + ((mv.x * scale)|0);
y1 = y + ((mv.y * scale)|0);
g.drawLine$I$I$I$I(x0, y0, x1, y1);
x0 = x1;
y0 = y1;
} else {
x0 = x + ((mv.x * scale)|0);
y0 = y + ((mv.y * scale)|0);
}}
});
})();
//Created 2018-03-16 05:19:12
