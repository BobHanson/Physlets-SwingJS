(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[];
var C$=Clazz.newClass(P$, "GraphThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable', function (owner, sc) {
C$.superclazz.c$$edu_davidson_display_SScalable.apply(this, [sc]);
C$.$init$.apply(this);
this.applet=owner;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
return;
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
return;
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:39
