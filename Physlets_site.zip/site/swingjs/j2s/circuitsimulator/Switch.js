(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[];
var C$=Clazz.newClass(P$, "Switch", null, 'circuitsimulator.CircuitElement');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.open=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.open=true;
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$Z$I$I$S', function (circuit, o, r, c, t) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$S.apply(this, [circuit, r, c, t]);
C$.$init$.apply(this);
this.setValueVisible$Z(false);
this.open=o;
this.value=this.open ? 1.0E10 : 0.0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'loadImage$java_awt_Graphics', function (g) {
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
g.setColor$java_awt_Color(Clazz.load('java.awt.Color').red);
var cig=(this.circuit.interGrid/2|0);
var p=this.open ? 5 : 0;
if (this.to.equals$O("h")) {
g.drawLine$I$I$I$I(this.$x + 3, this.$y, this.$x + cig - 5, this.$y);
g.drawLine$I$I$I$I(this.$x + cig + 6 , this.$y, this.$x + this.circuit.interGrid - 4, this.$y);
g.fillOval$I$I$I$I(this.$x + cig - 7, this.$y - 2, 4, 4);
g.fillOval$I$I$I$I(this.$x + cig + 6 , this.$y - 2, 4, 4);
g.drawLine$I$I$I$I(this.$x + cig - 5, this.$y, this.$x + cig + 5 , this.$y - p);
} else {
g.drawLine$I$I$I$I(this.$x, this.$y + 3, this.$x, this.$y + cig - 5);
g.drawLine$I$I$I$I(this.$x, this.$y + cig + 6 , this.$x, this.$y + this.circuit.interGrid - 4);
g.fillOval$I$I$I$I(this.$x - 2, this.$y + cig - 7, 4, 4);
g.fillOval$I$I$I$I(this.$x - 2, this.$y + cig + 6 , 4, 4);
g.drawLine$I$I$I$I(this.$x, this.$y + cig - 5, this.$x + p, this.$y + cig + 5 );
}});

Clazz.newMeth(C$, 'impedance$', function () {
return this.value;
});

Clazz.newMeth(C$, 'change$', function () {
this.open=this.open ? false : true;
this.value=this.open ? 1.0E10 : 0.0;
});

Clazz.newMeth(C$, 'setvalue$S', function (s) {
if (s.toLowerCase$().equals$O("open")) {
this.open=true;
this.value=1.0E10;
} else if (s.toLowerCase$().equals$O("close")) {
this.open=false;
this.value=0.0;
} else this.change$();
});

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",open=" + (this.open ? "1" : "0");
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:16 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
