(function(){var P$=Clazz.newPackage("bfield"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Wire", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.noOptionDrag = false;
this.showInfo = false;
this.showF = false;
this.showFComponents = false;
this.xo = 0;
this.yo = 0;
this.p = null;
this.current = 0;
this.radius = 0;
this.xPix = 0;
this.yPix = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.noOptionDrag = true;
this.showInfo = false;
this.showF = true;
this.showFComponents = false;
this.xo = 0;
this.yo = 0;
this.current = 1.0;
this.radius = 0;
this.xPix = 0;
this.yPix = 0;
}, 1);

Clazz.newMeth(C$, 'c$$bfield_FieldPanel$D$D$D', function (p, x, y, c) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [p, x, y]);
C$.$init$.apply(this);
this.s = 10;
this.p = p;
this.current = c;
if (c < 0 ) this.color = (I$[1]||$incl$(1)).blue;
 else if (c > 0 ) this.color = (I$[1]||$incl$(1)).red;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "bx", "by", "i"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
}, 1);

Clazz.newMeth(C$, 'setDisplayOff$I$I', function (xOff, yOff) {
this.xDisplayOff = xOff;
this.yDisplayOff = yOff;
this.xo = this.p.xFromPix$I(0) - this.p.xFromPix$I(xOff);
this.yo = this.p.yFromPix$I(0) - this.p.yFromPix$I(-yOff);
});

Clazz.newMeth(C$, 'getB$DA', function (r) {
var xx = this.x - this.xo;
var yy = this.y - this.yo;
var r2 = ((xx - r[0]) * (xx - r[0]) + (yy - r[1]) * (yy - r[1]));
var bx = -this.current * (r[1] - yy) / r2;
var by = this.current * (r[0] - xx) / r2;
r[0] = bx;
r[1] = by;
return r;
});

Clazz.newMeth(C$, 'getWireBx$D$D', function (x1, y1) {
var xx = this.x - this.xo;
var yy = this.y - this.yo;
return -this.current * (y1 - yy) / ((xx - x1) * (xx - x1) + (yy - y1) * (yy - y1));
});

Clazz.newMeth(C$, 'getWireBy$D$D', function (x1, y1) {
var xx = this.x - this.xo;
var yy = this.y - this.yo;
return this.current * (x1 - xx) / ((xx - x1) * (xx - x1) + (yy - y1) * (yy - y1));
});

Clazz.newMeth(C$, 'getCurrent', function () {
return this.current;
});

Clazz.newMeth(C$, 'setCurrent$D', function (c) {
this.current = c;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'getOwner', function () {
return this.p.getOwner();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
;});

Clazz.newMeth(C$, 'getRadius', function () {
return this.radius;
});

Clazz.newMeth(C$, 'setRadius$D', function (r) {
this.radius = r;
});

Clazz.newMeth(C$, 'setShowF$Z', function (sf) {
this.showF = sf;
});

Clazz.newMeth(C$, 'isShowF', function () {
return this.showF;
});

Clazz.newMeth(C$, 'setShowFComponents$Z', function (sfc) {
this.showFComponents = sfc;
});

Clazz.newMeth(C$, 'isShowFComponents', function () {
return this.showFComponents;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.x;
this.ds[0][1] = this.y;
this.ds[0][2] = this.p.getBx$D$D$bfield_Wire(this.x, this.y, this);
this.ds[0][3] = this.p.getBy$D$D$bfield_Wire(this.x, this.y, this);
;this.ds[0][4] = this.current;
return this.ds;
});

Clazz.newMeth(C$, 'getMaxB', function () {
var x0 = this.p.xFromPix$I(0);
var x1 = this.p.xFromPix$I(this.s);
var dx = x0 - x1;
if (dx != 0 ) return Math.abs(this.current / dx);
 else return 0;
});

Clazz.newMeth(C$, 'isInsidePix$I$I', function (x, y) {
if (this.noDrag) return false;
if ((Math.abs(this.xPix - x) < this.s + 1) && (Math.abs(this.yPix - y) < this.s + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (i, j) {
return this.isInsidePix$I$I(i, j);
});

Clazz.newMeth(C$, 'getHotSpot$I$I', function (x, y) {
return 0;
});

Clazz.newMeth(C$, 'isInsideWire$D$D$I', function (x, y, hs) {
if (hs != 0) return false;
return this.isInsidePix$I$I(this.p.pixFromX$D(x), this.p.pixFromY$D(y));
});

Clazz.newMeth(C$, 'isInsideWire$D$D', function (x, y) {
return this.isInsidePix$I$I(this.p.pixFromX$D(x), this.p.pixFromY$D(y));
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.isVisible()) return;
this.xPix = this.p.pixFromX$D(this.x) + this.xDisplayOff;
this.yPix = this.p.pixFromY$D(this.y) - this.yDisplayOff;
osg.setColor$java_awt_Color(this.color);
osg.fillOval$I$I$I$I((this.xPix - (this.s/2|0)), (this.yPix - (this.s/2|0)), this.s, this.s);
if (this.label != null ) {
var oldFont = osg.getFont();
osg.setFont$java_awt_Font(this.font);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).white);
osg.drawString$S$I$I(this.label, this.xPix - 4, this.yPix + 5);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
osg.setFont$java_awt_Font(oldFont);
}});

Clazz.newMeth(C$, 'paintInfo$java_awt_Graphics$I', function (osg, hotSpot) {
if (!this.showInfo && hotSpot == 0 ) return;
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).yellow);
osg.fillRect$I$I$I$I(this.xPix + 15, this.yPix - 8, 60, 15);
osg.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
if (!this.noOptionDrag && Math.abs(hotSpot) == 1 ) osg.drawString$S$I$I("R =" + this.format.form$D(this.radius), this.xPix + 20, this.yPix + 5);
if (Math.abs(hotSpot) == 0) osg.drawString$S$I$I("I =" + this.format.form$D(this.current), this.xPix + 20, this.yPix + 5);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:08
