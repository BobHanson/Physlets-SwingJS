(function(){var P$=Clazz.newPackage("sun.applet"),I$=[];
var C$=Clazz.newInterface(P$, "AppletListener", null, null, 'java.util.EventListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}
})();
//Created 2018-05-24 08:47:19
