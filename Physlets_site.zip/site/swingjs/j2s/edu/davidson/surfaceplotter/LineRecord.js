(function(){var P$=Clazz.newPackage("edu.davidson.surfaceplotter"),I$=[];
var C$=Clazz.newClass(P$, "LineRecord");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x1 = 0;
this.y1 = 0;
this.x2 = 0;
this.y2 = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I', function (x1, y1, x2, y2) {
C$.$init$.apply(this);
this.x1 = x1;
this.y1 = y1;
this.x2 = x2;
this.y2 = y2;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:02
