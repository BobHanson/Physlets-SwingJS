(function(){var P$=Clazz.newPackage("diatomic"),I$=[['edu.davidson.tools.SApplet','edu.davidson.display.Format','java.awt.Color','java.awt.Font','java.awt.event.MouseMotionAdapter','java.awt.event.MouseAdapter','edu.davidson.tools.SUtil',['diatomic.PhysletPanel','.AtomSource'],['diatomic.PhysletPanel','.DiatomicSource'],'java.awt.Cursor']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "PhysletPanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'diatomic.EnsemblePanel', ['edu.davidson.tools.SStepable', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.boxWidth = 0;
this.mouseFormat = null;
this.mouseX = 0;
this.mouseY = 0;
this.scale = 0;
this.numSteps = 0;
this.backgroundColor = null;
this.$mouseDown = false;
this.osi = null;
this.owner = null;
this.boldFont = null;
this.timeDisplay = false;
this.varStrings = null;
this.ds = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.boxWidth = 0;
this.mouseFormat = Clazz.new_((I$[2]||$incl$(2)).c$$S,["%-+6.3g"]);
this.mouseX = 0;
this.mouseY = 0;
this.scale = 10.0;
this.numSteps = 1;
this.backgroundColor = (I$[3]||$incl$(3)).lightGray;
this.$mouseDown = false;
this.owner = null;
this.boldFont = Clazz.new_((I$[4]||$incl$(4)).c$$S$I$I,["Helvetica", 1, 14]);
this.timeDisplay = true;
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "ke", "ke_atom", "ke_mol", "ke_mol_rot", "ke_mol_trans", "n_atom", "n_mol"]);
this.ds = Clazz.array(Double.TYPE, [1, 8]);
}, 1);

Clazz.newMeth(C$, 'c$$diatomic_Diatomic', function (o) {
C$.c$.apply(this, []);
this.owner=o;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'jbInit', function () {
this.addMouseMotionListener$java_awt_event_MouseMotionListener(((
(function(){var C$=Clazz.newClass(P$, "PhysletPanel$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseMotionAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
this.b$['diatomic.PhysletPanel'].this_mouseDragged$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[5]||$incl$(5)), [this, null],P$.PhysletPanel$1)));
this.addMouseListener$java_awt_event_MouseListener(((
(function(){var C$=Clazz.newClass(P$, "PhysletPanel$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.MouseAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
this.b$['diatomic.PhysletPanel'].this_mousePressed$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.b$['diatomic.PhysletPanel'].this_mouseReleased$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
this.b$['diatomic.PhysletPanel'].this_mouseEntered$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
this.b$['diatomic.PhysletPanel'].this_mouseExited$java_awt_event_MouseEvent(e);
});
})()
), Clazz.new_((I$[6]||$incl$(6)), [this, null],P$.PhysletPanel$2)));
});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
var mySteps = this.numSteps;
this.dt=dt / mySteps;
for (var ii = 0; ii < mySteps; ii++) this.monodiLoop();

this.theTime=time + dt;
this.paintOSI();
var g = this.getGraphics();
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
g.dispose();
this.KinEnTotal();
this.owner.updateDataConnections();
});

Clazz.newMeth(C$, 'createOSI', function () {
if (this.iwidth <= 0 || this.iheight <= 0 ) {
return;
}this.iwidth=this.getSize().width;
this.iheight=this.getSize().height;
this.osi=this.createImage$I$I(this.iwidth, this.iheight);
});

Clazz.newMeth(C$, 'paintOSI', function () {
if (this.owner != null  && (this.owner.destroyed || !this.owner.isAutoRefresh() ) ) return;
if (this.osi == null  || this.iwidth <= 0  || this.iheight <= 0 ) {
return;
}{
var g = this.osi.getGraphics();
g.setColor$java_awt_Color(this.backgroundColor);
g.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
this.paintMonoat$java_awt_Graphics(g);
this.paintDiat$java_awt_Graphics(g);
this.paintTime$java_awt_Graphics(g);
if (this.$mouseDown) this.paintCoords$java_awt_Graphics$I$I(g, this.mouseX, this.mouseY);
g.dispose();
}});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.owner != null  && (this.owner.destroyed || !this.owner.isAutoRefresh() ) ) return;
if ((this.getSize().width == 0) || (this.getSize().height == 0) ) {
return;
}if ((this.osi == null ) || (this.iwidth != this.getSize().width) || (this.iheight != this.getSize().height)  ) {
this.iwidth=this.getSize().width;
this.iheight=this.getSize().height;
this.osi=this.createImage$I$I(this.iwidth, this.iheight);
this.paintOSI();
}if (this.owner.isClockRunning()) {
return;
}if (this.osi == null ) {
return;
}{
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
}});

Clazz.newMeth(C$, 'paintDiat$java_awt_Graphics', function (g) {
if (this.owner != null  && (this.owner.destroyed || !this.owner.isAutoRefresh() ) ) return;
var dia = 2 * this.radiusD;
for (var i = 1; i <= this.mnMax; i++) {
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
g.drawLine$I$I$I$I(((this.$x[i][1])|0), ((this.$y[i][1])|0), ((this.$x[i][2])|0), ((this.$y[i][2])|0));
if (this.molColor[i] === (I$[3]||$incl$(3)).green ) {
g.setColor$java_awt_Color((I$[3]||$incl$(3)).green);
g.fillOval$I$I$I$I(((this.$x[i][1] - this.radiusD)|0), ((this.$y[i][1] - this.radiusD)|0), dia, dia);
g.setColor$java_awt_Color((I$[3]||$incl$(3)).yellow);
g.fillOval$I$I$I$I(((this.$x[i][2] - this.radiusD)|0), ((this.$y[i][2] - this.radiusD)|0), dia, dia);
} else {
g.setColor$java_awt_Color(this.molColor[i]);
g.fillOval$I$I$I$I(((this.$x[i][1] - this.radiusD)|0), ((this.$y[i][1] - this.radiusD)|0), dia, dia);
g.fillOval$I$I$I$I(((this.$x[i][2] - this.radiusD)|0), ((this.$y[i][2] - this.radiusD)|0), dia, dia);
}}
});

Clazz.newMeth(C$, 'paintMonoat$java_awt_Graphics', function (g) {
if (this.owner != null  && (this.owner.destroyed || !this.owner.isAutoRefresh() ) ) return;
var dia = 2 * this.radiusM;
for (var i = 1; i <= this.anMax; i++) {
if (this.atomFixed[i]) g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
 else g.setColor$java_awt_Color(this.atomColor[i]);
g.fillOval$I$I$I$I(((this.ax[i] - this.radiusM)|0), ((this.ay[i] - this.radiusM)|0), dia, dia);
}
});

Clazz.newMeth(C$, 'paintTime$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
var f = g.getFont();
g.setFont$java_awt_Font(this.boldFont);
var tStr = Clazz.new_((I$[2]||$incl$(2)).c$$S,["%7.4g"]).form$D((I$[7]||$incl$(7)).chop$D$D(this.theTime, 1.0E-12));
if (this.timeDisplay) {
if (this.iwidth > 150) {
g.drawString$S$I$I(this.owner.label_time + " " + tStr , 10, 15);
} else {
g.drawString$S$I$I(this.owner.label_time + " " + tStr , 10, this.iheight - 40);
}}g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$, 'getVariables', function () {
var scale2 = this.scale * this.scale;
this.ds[0][0]=this.theTime;
this.ds[0][1]=this.KinEnTotalMD / scale2;
this.ds[0][2]=this.KinEnMonoat / scale2;
this.ds[0][3]=this.KinEnDiat / scale2;
this.ds[0][4]=this.KinEnDiatRot / scale2;
this.ds[0][5]=this.KinEnDiatTrans / scale2;
this.ds[0][6]=this.anMax;
this.ds[0][7]=this.mnMax;
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (app) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.owner;
});

Clazz.newMeth(C$, 'addAtomDataSource$I', function (i) {
var ds = Clazz.new_((I$[8]||$incl$(8)).c$$I, [this, null, i]);
return ds.hashCode();
});

Clazz.newMeth(C$, 'addDiatomicDataSource$I', function (i) {
var ds = Clazz.new_((I$[9]||$incl$(9)).c$$I, [this, null, i]);
return ds.hashCode();
});

Clazz.newMeth(C$, 'paintCoords$java_awt_Graphics', function (g) {
this.paintCoords$java_awt_Graphics$I$I(g, this.mouseX, this.mouseY);
});

Clazz.newMeth(C$, 'paintCoords$I$I', function (xPix, yPix) {
var g = this.getGraphics();
this.paintCoords$java_awt_Graphics$I$I(g, xPix, yPix);
g.dispose();
});

Clazz.newMeth(C$, 'paintCoords$java_awt_Graphics$I$I', function (g, xPix, yPix) {
var msg = "" + this.mouseFormat.form$D(xPix / this.scale) + " , " + this.mouseFormat.form$D((this.iheight - yPix) / this.scale) ;
var r = this.getBounds();
g.setColor$java_awt_Color((I$[3]||$incl$(3)).yellow);
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
this.boxWidth=Math.max(20 + fm.stringWidth$S(msg), this.boxWidth);
g.fillRect$I$I$I$I(0, r.height - 20, this.boxWidth, 20);
g.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
g.drawString$S$I$I(msg, 10, r.height - 5);
g.drawRect$I$I$I$I(0, r.height - 20, this.boxWidth - 1, 20);
});

Clazz.newMeth(C$, 'this_mousePressed$java_awt_event_MouseEvent', function (e) {
if ((e.getModifiers() & 4) != 0) {
} else {
this.mouseX=e.getX();
this.mouseY=e.getY();
this.$mouseDown=true;
if (!this.owner.clock.isRunning()) this.paintCoords$I$I(this.mouseX, this.mouseY);
}});

Clazz.newMeth(C$, 'this_mouseDragged$java_awt_event_MouseEvent', function (e) {
this.mouseX=e.getX();
this.mouseY=e.getY();
if (!this.owner.clock.isRunning()) this.paintCoords$I$I(this.mouseX, this.mouseY);
});

Clazz.newMeth(C$, 'this_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.$mouseDown=false;
this.mouseX=e.getX();
this.mouseY=e.getY();
var r = this.getBounds();
if (!this.owner.clock.isRunning()) this.repaint$I$I$I$I(0, r.height - 20, this.boxWidth, 20);
this.boxWidth=0;
});

Clazz.newMeth(C$, 'this_mouseEntered$java_awt_event_MouseEvent', function (e) {
this.owner.setCursor$java_awt_Cursor((I$[10]||$incl$(10)).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$, 'this_mouseExited$java_awt_event_MouseEvent', function (e) {
this.owner.setCursor$java_awt_Cursor((I$[10]||$incl$(10)).getPredefinedCursor$I(0));
});
;
(function(){var C$=Clazz.newClass(P$.PhysletPanel, "AtomSource", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.ds = null;
this.index = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "vx", "vy", "m"]);
this.ds = Clazz.array(Double.TYPE, [1, 6]);
this.index = 0;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (i) {
C$.$init$.apply(this);
this.index=i;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0]=this.this$0.theTime;
if ((this.index > this.this$0.anMax) || (this.index < 1) ) {
System.out.println$S("ERROR: Atom index is out of range .");
this.ds[0][1]=0;
this.ds[0][2]=0;
this.ds[0][3]=0;
this.ds[0][4]=0;
this.ds[0][5]=0;
return this.ds;
} else {
this.ds[0][1]=this.this$0.ax[this.index] / this.this$0.scale;
this.ds[0][2]=(this.this$0.iheight - this.this$0.ay[this.index]) / this.this$0.scale;
this.ds[0][3]=this.this$0.avx[this.index] / this.this$0.scale;
this.ds[0][4]=-this.this$0.avy[this.index] / this.this$0.scale;
this.ds[0][5]=this.this$0.mM;
}return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0.owner;
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.PhysletPanel, "DiatomicSource", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataSource');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.varStrings = null;
this.ds = null;
this.index = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "vx", "vy", "m", "theta", "w", "inertia"]);
this.ds = Clazz.array(Double.TYPE, [1, 9]);
this.index = 0;
}, 1);

Clazz.newMeth(C$, 'c$$I', function (i) {
C$.$init$.apply(this);
this.index=i;
try {
(I$[1]||$incl$(1)).addDataSource$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0]=this.this$0.theTime;
if ((this.index > this.this$0.mnMax) || (this.index < 1) ) {
System.out.println$S("ERROR: Atom index is out of range .");
this.ds[0][1]=0;
this.ds[0][2]=0;
this.ds[0][3]=0;
this.ds[0][4]=0;
this.ds[0][5]=0;
this.ds[0][6]=0;
this.ds[0][7]=0;
this.ds[0][8]=0;
return this.ds;
} else {
this.ds[0][1]=this.this$0.xcm[this.index] / this.this$0.scale;
this.ds[0][2]=(this.this$0.iheight - this.this$0.ycm[this.index]) / this.this$0.scale;
this.ds[0][3]=this.this$0.vxcm[this.index] / this.this$0.scale;
this.ds[0][4]=-this.this$0.vycm[this.index] / this.this$0.scale;
this.ds[0][5]=this.this$0.mD;
this.ds[0][6]=this.this$0.teta[this.index];
this.ds[0][7]=this.this$0.w[this.index];
this.ds[0][8]=this.this$0.IM / this.this$0.scale / this.this$0.scale ;
}return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (applet) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0.owner;
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-07-23 12:59:36 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
