(function(){var P$=Clazz.newPackage("filters"),I$=[['edu.davidson.graphics.EtchedBorder','java.awt.BorderLayout','java.awt.Button','java.awt.FlowLayout','java.awt.Label','java.awt.Panel','edu.davidson.display.SInteger','edu.davidson.display.SNumber','Boolean','filters.Moments$1','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Moments", null, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataListener', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.showControls = false;
this.autoReplace = false;
this.varStrings = null;
this.ds = null;
this.sumX = 0;
this.sumXX = 0;
this.numPts = 0;
this.controlPanel = null;
this.borderLayout1 = null;
this.resetBtn = null;
this.flowLayout1 = null;
this.numLabel = null;
this.panel1 = null;
this.numField = null;
this.stdField = null;
this.panel4 = null;
this.minLabel3 = null;
this.aveField = null;
this.panel5 = null;
this.minLabel4 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.autoReplace = true;
this.varStrings = Clazz.array(java.lang.String, -1, ["ave", "std", "n"]);
this.ds = Clazz.array(Double.TYPE, [1, 3]);
this.sumX = 0;
this.sumXX = 0;
this.numPts = 0;
this.controlPanel = Clazz.new_((I$[1]||$incl$(1)));
this.borderLayout1 = Clazz.new_((I$[2]||$incl$(2)));
this.resetBtn = Clazz.new_((I$[3]||$incl$(3)));
this.flowLayout1 = Clazz.new_((I$[4]||$incl$(4)));
this.numLabel = Clazz.new_((I$[5]||$incl$(5)));
this.panel1 = Clazz.new_((I$[6]||$incl$(6)));
this.numField = Clazz.new_((I$[7]||$incl$(7)));
this.stdField = Clazz.new_((I$[8]||$incl$(8)));
this.panel4 = Clazz.new_((I$[6]||$incl$(6)));
this.minLabel3 = Clazz.new_((I$[5]||$incl$(5)));
this.aveField = Clazz.new_((I$[8]||$incl$(8)));
this.panel5 = Clazz.new_((I$[6]||$incl$(6)));
this.minLabel4 = Clazz.new_((I$[5]||$incl$(5)));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.showControls=(I$[9]||$incl$(9)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls=(I$[9]||$incl$(9)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.controlPanel.setVisible$Z(this.showControls);
edu.davidson.tools.SApplet.addDataListener$O(this);
edu.davidson.tools.SApplet.addDataSource$O(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.resetBtn.setLabel$S("Reset");
this.resetBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Moments$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['filters.Moments'].resetBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[10]||$incl$(10)).$init$, [this, null])));
this.controlPanel.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.stdField.setEditable$Z(false);
this.stdField.setColumns$I(8);
this.stdField.setText$S("??");
this.minLabel3.setText$S("Std");
this.minLabel3.setAlignment$I(2);
this.aveField.setEditable$Z(false);
this.aveField.setColumns$I(8);
this.aveField.setText$S("??");
this.minLabel4.setText$S("Ave");
this.minLabel4.setAlignment$I(2);
this.numField.setEditable$Z(false);
this.controlPanel.setBackground$java_awt_Color((I$[11]||$incl$(11)).lightGray);
this.controlPanel.setFillColor$java_awt_Color((I$[11]||$incl$(11)).lightGray);
this.setBackground$java_awt_Color((I$[11]||$incl$(11)).lightGray);
this.add$java_awt_Component$O(this.controlPanel, "Center");
this.controlPanel.add$java_awt_Component$O(this.resetBtn, null);
this.controlPanel.add$java_awt_Component$O(this.panel5, null);
this.panel5.add$java_awt_Component$O(this.minLabel4, null);
this.panel5.add$java_awt_Component$O(this.aveField, null);
this.controlPanel.add$java_awt_Component$O(this.panel4, null);
this.panel4.add$java_awt_Component$O(this.minLabel3, null);
this.panel4.add$java_awt_Component$O(this.stdField, null);
this.controlPanel.add$java_awt_Component$O(this.panel1, null);
this.panel1.add$java_awt_Component$O(this.numLabel, null);
this.panel1.add$java_awt_Component$O(this.numField, null);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Moments Physlet written by W. Christian.  Calculates the moments of a distribution.";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the user interface."])]);
return pinfo;
});

Clazz.newMeth(C$, 'getAve', function () {
if (this.numPts < 1) {
return 0;
}return this.sumX / this.numPts;
});

Clazz.newMeth(C$, 'getNumPts', function () {
return this.numPts;
});

Clazz.newMeth(C$, 'getStd', function () {
if (this.numPts < 2) {
return 0;
}return Math.sqrt((this.sumXX - this.sumX * this.sumX / this.numPts) / (this.numPts - 1));
});

Clazz.newMeth(C$, 'getVariables', function () {
if (this.numPts < 1) {
this.ds[0][0]=0;
this.ds[0][1]=0;
this.ds[0][2]=0;
return this.ds;
} else if (this.numPts < 2) {
this.ds[0][0]=this.sumX / this.numPts;
;this.ds[0][1]=0;
this.ds[0][2]=this.numPts;
return this.ds;
}var ave = this.sumX / this.numPts;
this.ds[0][0]=ave;
this.ds[0][1]=Math.sqrt((this.sumXX - ave * ave * this.numPts ) / (this.numPts - 1));
this.ds[0][2]=this.numPts;
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, x, y) {
this.sumX += x;
this.sumXX += x * x;
this.numPts++;
if (this.showControls && this.getBounds().width > 50 ) {
this.numField.setValue$I(this.numPts);
this.aveField.setValue$D(this.getAve());
this.stdField.setValue$D(this.getStd());
}this.updateDataConnections();
});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
if (this.autoReplace) {
this.sumX=0;
this.sumXX=0;
this.numPts=0;
}var n = x.length;
for (var i = 0; i < n; i++) {
this.sumX += x[i];
this.sumXX += x[i] * x[i];
this.numPts++;
}
if (this.showControls && this.getBounds().width > 50 ) {
this.numField.setValue$I(this.numPts);
this.aveField.setValue$D(this.getAve());
this.stdField.setValue$D(this.getStd());
}this.updateDataConnections();
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.reset();
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
if (this.autoReplace) this.reset();
});

Clazz.newMeth(C$, 'reset', function () {
this.sumX=0;
this.sumXX=0;
this.numPts=0;
if (this.showControls && this.getBounds().width > 50 ) {
this.numField.setValue$I(0);
this.aveField.setValue$D(0);
this.stdField.setValue$D(0);
}this.updateDataConnections();
});

Clazz.newMeth(C$, ['setAutoReplaceData$I$Z','setAutoReplaceData'], function (id, replace) {
this.autoReplace=replace;
if (this.autoReplace) this.reset();
});

Clazz.newMeth(C$, 'resetBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.reset();
});
})();
//Created 2018-07-23 12:59:29 Jav2ScriptVisitor version 3.2.1.01 net.sf.j2s.core.jar version 3.2.1.02
