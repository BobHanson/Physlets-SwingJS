(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newClass(P$, "Crypt");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.key = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.key = Clazz.array(Integer.TYPE, -1, [52, 81, 92, 27, 26, 12, 5, 68]);
}, 1);

Clazz.newMeth(C$, 'encrypt$S', function (plaintext) {
var ciphertext =  String.instantialize();
var length = plaintext.length$();
var byteArr = plaintext.getBytes();
var charArr = Clazz.array(Character.TYPE, [length]);
var intArr = Clazz.array(Integer.TYPE, [length]);
var byteArrCiph = Clazz.array(Byte.TYPE, [2 * length]);
var charArrCiph = Clazz.array(Character.TYPE, [2 * length]);
var intArrCiph = Clazz.array(Integer.TYPE, [2 * length]);
for (var i = 0; i < length; i++) {
intArr[i] = (byteArr[i]|0) - 32;
}
for (var i = 0; i < length; i++) {
intArr[i] = (((intArr[i] + this.key[i % 8])) % 94);
}
for (var i = 0; i < length; i++) {
if (intArr[i] < 0) {
intArr[i] = intArr[i] + 94;
}}
for (var i = 0; i < length; i++) {
intArrCiph[2 * i] = ((intArr[i]/4|0)) + 65;
intArrCiph[2 * i + 1] = (intArr[i] % 4) + 48;
}
for (var i = 0; i < 2 * length; i++) {
byteArrCiph[i] = ((intArrCiph[i]|0)|0);
}
for (var i = 0; i < 2 * length; i++) {
charArrCiph[i] = String.fromCharCode(byteArrCiph[i]);
}
ciphertext = String.copyValueOf$CA(charArrCiph);
return ciphertext;
});

Clazz.newMeth(C$, 'decrypt$S', function (ciphertext) {
var plaintext =  String.instantialize();
var length = ciphertext.length$();
length = ((length/2|0));
var byteArr = ciphertext.getBytes();
var charArr = Clazz.array(Character.TYPE, [2 * length]);
var intArr = Clazz.array(Integer.TYPE, [2 * length]);
var byteArrDC = Clazz.array(Byte.TYPE, [length]);
var charArrDC = Clazz.array(Character.TYPE, [length]);
var intArrDC = Clazz.array(Integer.TYPE, [length]);
for (var i = 0; i < 2 * length; i++) {
intArr[i] = (byteArr[i]|0);
}
for (var i = 0; i < length; i++) {
intArrDC[i] = (intArr[2 * i] - 65) * 4;
intArrDC[i] = intArrDC[i] + intArr[2 * i + 1] - 48;
}
for (var i = 0; i < length; i++) {
intArrDC[i] = (((intArrDC[i] - this.key[i % 8])) % 94) + 32;
}
for (var i = 0; i < length; i++) {
if (intArrDC[i] < 32) intArrDC[i] = intArrDC[i] + 94;
}
for (var i = 0; i < length; i++) {
byteArrDC[i] = ((intArrDC[i]|0)|0);
}
for (var i = 0; i < length; i++) {
charArrDC[i] = String.fromCharCode(byteArrDC[i]);
}
plaintext = String.copyValueOf$CA(charArrDC);
return plaintext;
});

Clazz.newMeth(C$, 'setKey$IA', function (inKey) {
this.key = inKey;
for (var i = 0; i < 8; i++) {
if (i < inKey.length) {
this.key[i] = inKey[i] % 94;
} else this.key[i] = 0;
}
});

Clazz.newMeth(C$, 'setKey$S', function (str) {
for (var i = 0; i < 8; i++) {
if (i < str.length$()) {
var c = str.charAt(i);
this.key[i] = (c.$c()) % 94;
} else this.key[i] = 0;
}
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:13
