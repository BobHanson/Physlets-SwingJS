(function(){var P$=Clazz.newPackage("animator4"),I$=[['edu.davidson.numerics.Parser','edu.davidson.tools.SUtil','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Arrow", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.arrowVars = null;
this.arrow = null;
this.hStr = null;
this.vStr = null;
this.filled = false;
this.hFunc = null;
this.vFunc = null;
this.thickness = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.arrowVars = Clazz.array(Double.TYPE, [12]);
this.arrow = Clazz.array(Double.TYPE, [2]);
this.filled = false;
this.thickness = 1;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$S$S$S$S', function (o, s, h, v, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "vx", "vy", "ax", "ay", "m", "horz", "vert", "w", "h"]);
this.ds = Clazz.array(Double.TYPE, [1, 12]);
this.s = s;
this.hStr = h;
this.vStr = v;
this.hFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[12]);
this.hFunc.defineVariable$I$S(1, "t");
this.hFunc.defineVariable$I$S(2, "x");
this.hFunc.defineVariable$I$S(3, "y");
this.hFunc.defineVariable$I$S(4, "vx");
this.hFunc.defineVariable$I$S(5, "vy");
this.hFunc.defineVariable$I$S(6, "ax");
this.hFunc.defineVariable$I$S(7, "ay");
this.hFunc.defineVariable$I$S(8, "m");
this.hFunc.defineVariable$I$S(9, "fx");
this.hFunc.defineVariable$I$S(10, "fy");
this.hFunc.defineVariable$I$S(11, "w");
this.hFunc.defineVariable$I$S(12, "h");
this.hFunc.define$S(this.hStr);
this.hFunc.parse();
if (this.hFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse horzizontal component of vector: " + this.hStr);
System.out.println$S("Parse error: " + this.hFunc.getErrorString() + " at function 1, position " + this.hFunc.getErrorPosition() );
return;
}this.vFunc = Clazz.new_((I$[1]||$incl$(1)).c$$I,[12]);
this.vFunc.defineVariable$I$S(1, "t");
this.vFunc.defineVariable$I$S(2, "x");
this.vFunc.defineVariable$I$S(3, "y");
this.vFunc.defineVariable$I$S(4, "vx");
this.vFunc.defineVariable$I$S(5, "vy");
this.vFunc.defineVariable$I$S(6, "ax");
this.vFunc.defineVariable$I$S(7, "ay");
this.vFunc.defineVariable$I$S(8, "m");
this.vFunc.defineVariable$I$S(9, "fx");
this.vFunc.defineVariable$I$S(10, "fy");
this.vFunc.defineVariable$I$S(11, "w");
this.vFunc.defineVariable$I$S(12, "h");
this.vFunc.define$S(this.vStr);
this.vFunc.parse();
if (this.vFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse vertical component of vector: " + this.vStr);
System.out.println$S("Parse error: " + this.vFunc.getErrorString() + " at function 1, position " + this.vFunc.getErrorPosition() );
return;
}}, 1);

Clazz.newMeth(C$, 'setArrow', function () {
for (var i = 0; i < 8; i++) {
this.arrowVars[i] = this.vars[i];
}
if ((this.myMaster != null ) && !this.dynamic ) {
this.arrowVars[8] = this.myMaster.getTotalFx();
this.arrowVars[9] = this.myMaster.getTotalFy();
} else {
this.arrowVars[8] = this.getTotalFx();
this.arrowVars[9] = this.getTotalFy();
}try {
this.arrow[0] = this.hFunc.evaluate$DA(this.arrowVars);
this.arrow[1] = this.vFunc.evaluate$DA(this.arrowVars);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
this.arrow[0] = 0;
this.arrow[1] = 0;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getHorz', function () {
var h = 0;
for (var i = 0; i < 8; i++) {
this.arrowVars[i] = this.vars[i];
}
if ((this.myMaster != null ) && !this.dynamic ) {
this.arrowVars[8] = this.myMaster.getTotalFx();
this.arrowVars[9] = this.myMaster.getTotalFy();
} else {
this.arrowVars[8] = this.getTotalFx();
this.arrowVars[9] = this.getTotalFy();
}try {
h = this.hFunc.evaluate$DA(this.arrowVars);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return h;
});

Clazz.newMeth(C$, 'getVert', function () {
var v = 0;
for (var i = 0; i < 8; i++) {
this.arrowVars[i] = this.vars[i];
}
if ((this.myMaster != null ) && !this.dynamic ) {
this.arrowVars[8] = this.myMaster.getTotalFx();
this.arrowVars[9] = this.myMaster.getTotalFy();
} else {
this.arrowVars[8] = this.getTotalFx();
this.arrowVars[9] = this.getTotalFy();
}try {
v = this.vFunc.evaluate$DA(this.arrowVars);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return v;
});

Clazz.newMeth(C$, 'setFilled$Z', function (f) {
this.filled = f;
});

Clazz.newMeth(C$, 'getH', function () {
return this.getVert();
});

Clazz.newMeth(C$, 'setH$D', function (vert) {
System.out.println$S("Error:  Cannot set the vertial component of a dynamic arrow.");
});

Clazz.newMeth(C$, 'getW', function () {
return this.getHorz();
});

Clazz.newMeth(C$, 'setW$D', function (horz) {
System.out.println$S("Error:  Cannot set the horizontal component of a dynamic arrow.");
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.canvas.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.vars[2]) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < this.s + 1) && (Math.abs(yPix - ptY) < this.s + 1) ) {
return true;
} else {
return false;
}});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) {
return;
}var ptX = Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
var x = 0;
var y = 0;
if (this.showVVector) {
x = this.canvas.pixPerUnit * this.vars[3];
y = this.canvas.pixPerUnit * this.vars[4];
} else if (this.showAVector) {
x = this.canvas.pixPerUnit * this.vars[5];
y = this.canvas.pixPerUnit * this.vars[6];
} else if (this.dynamic && this.showFVector ) {
x = this.canvas.pixPerUnit * this.getTotalFx();
y = this.canvas.pixPerUnit * this.getTotalFy();
} else if (!this.dynamic && this.showFVector ) {
x = this.canvas.pixPerUnit * this.vars[5] * this.mass ;
y = this.canvas.pixPerUnit * this.vars[6] * this.mass ;
} else {
this.setArrow();
x = this.canvas.pixPerUnit * this.arrow[0];
y = this.canvas.pixPerUnit * this.arrow[1];
}osg.setColor$java_awt_Color(this.color);
var x2 = ((ptX + x)|0);
var y2 = ((ptY - y)|0);
var h = Math.sqrt(x * x + y * y);
var w;
if (h < 2 ) {
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
return;
}if (h > 3 * this.s ) {
w = this.s;
} else {
w = h / 3;
}if (this.thickness > 1) {
(I$[2]||$incl$(2)).drawThickArrow$java_awt_Graphics$I$I$I$I$I$I(osg, ptX, ptY, x2, y2, (w|0), this.thickness);
} else if (this.filled) {
(I$[2]||$incl$(2)).drawSolidArrow$java_awt_Graphics$I$I$I$I$I(osg, ptX, ptY, x2, y2, (w|0));
} else {
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
if (h > 1 ) {
var u = (w * x / h);
var v = -(w * y / h);
var base_x = x2 - 3 * u;
var base_y = y2 - 3 * v;
osg.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x2, y2);
osg.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x2, y2);
}}if (!this.noDrag) {
if (this.color !== (I$[3]||$incl$(3)).lightGray ) osg.setColor$java_awt_Color((I$[3]||$incl$(3)).lightGray);
 else this.setColor$java_awt_Color((I$[3]||$incl$(3)).red);
osg.fillOval$I$I$I$I(ptX - 2, ptY - 2, 5, 5);
osg.setColor$java_awt_Color(this.color);
osg.drawOval$I$I$I$I(ptX - 2, ptY - 2, 5, 5);
}if (this.label != null ) {
osg.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
var f = osg.getFont();
osg.setFont$java_awt_Font(this.font);
var fm = osg.getFontMetrics$java_awt_Font(this.font);
var off1 = 4 + (((8 + fm.stringWidth$S(this.label)) * (-1.0 + x / h) / 2.0)|0);
var off2 = ((-4 * (y / h) + fm.getHeight() * (1.0 - y / h) / 4.0)|0);
osg.drawString$S$I$I(this.label, x2 + off1, y2 + off2);
osg.setFont$java_awt_Font(f);
}});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
if (!this.visible) {
return;
}var ptX = Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
var x = 0;
var y = 0;
if (this.showVVector) {
x = this.canvas.pixPerUnit * this.vars[3];
y = this.canvas.pixPerUnit * this.vars[4];
} else if (this.showAVector) {
x = this.canvas.pixPerUnit * this.vars[5];
y = this.canvas.pixPerUnit * this.vars[6];
} else if (this.dynamic && this.showFVector ) {
x = this.canvas.pixPerUnit * this.getTotalFx();
y = this.canvas.pixPerUnit * this.getTotalFy();
} else if (!this.dynamic && this.showFVector ) {
x = this.canvas.pixPerUnit * this.vars[5];
y = this.canvas.pixPerUnit * this.vars[6];
} else {
this.setArrow();
x = this.canvas.pixPerUnit * this.arrow[0];
y = this.canvas.pixPerUnit * this.arrow[1];
}osg.setColor$java_awt_Color(this.highlightColor);
var x2 = ((ptX + x)|0);
var y2 = ((ptY - y)|0);
var h = Math.sqrt(x * x + y * y);
var w;
if (h < 2 ) {
osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
return;
}if (h > 3 * this.s ) {
w = this.s;
} else {
w = h / 3;
}if (this.filled) {
(I$[2]||$incl$(2)).drawSolidArrow$java_awt_Graphics$I$I$I$I$I(osg, ptX, ptY, x2, y2, (w|0));
return;
}osg.drawLine$I$I$I$I((ptX), (ptY), x2, y2);
if (h > 1 ) {
var u = (w * x / h);
var v = -(w * y / h);
var base_x = x2 - 3 * u;
var base_y = y2 - 3 * v;
osg.drawLine$I$I$I$I(((base_x - v)|0), ((base_y + u)|0), x2, y2);
osg.drawLine$I$I$I$I(((base_x + v)|0), ((base_y - u)|0), x2, y2);
}if (this.label != null ) {
osg.setColor$java_awt_Color((I$[3]||$incl$(3)).black);
var f = osg.getFont();
osg.setFont$java_awt_Font(this.font);
var fm = osg.getFontMetrics$java_awt_Font(this.font);
var off1 = 4 + (((8 + fm.stringWidth$S(this.label)) * (-1.0 + x / h) / 2.0)|0);
var off2 = ((-4 * (y / h) + fm.getHeight() * (1.0 - y / h) / 4.0)|0);
osg.drawString$S$I$I(this.label, x2 + off1, y2 + off2);
osg.setFont$java_awt_Font(f);
}});

Clazz.newMeth(C$, 'getVariables', function () {
var horz = 0;
var vert = 0;
if (this.showVVector) {
horz = this.vars[3];
vert = this.vars[4];
} else if (this.showAVector) {
horz = this.canvas.pixPerUnit * this.vars[5];
vert = this.canvas.pixPerUnit * this.vars[6];
} else if (this.dynamic && this.showFVector ) {
horz = this.getTotalFx();
vert = this.getTotalFy();
} else if (!this.dynamic && this.showFVector ) {
horz = this.vars[5];
vert = this.vars[6];
} else {
this.setArrow();
horz = this.arrow[0];
vert = this.arrow[1];
}this.ds[0][0] = this.vars[0];
this.ds[0][1] = this.vars[1];
this.ds[0][2] = this.vars[2];
this.ds[0][3] = this.vars[3];
this.ds[0][4] = this.vars[4];
this.ds[0][5] = this.vars[5];
this.ds[0][6] = this.vars[6];
this.ds[0][7] = this.mass;
this.ds[0][8] = horz;
this.ds[0][9] = vert;
this.ds[0][10] = horz;
this.ds[0][11] = vert;
return this.ds;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:13
