(function(){var P$=Clazz.newPackage("bfield"),I$=[];
var C$=Clazz.newClass(P$, "FieldCursor", null, 'edu.davidson.display.MarkerThing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fieldPanel = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I', function (owner, fp, x, y, diameter) {
C$.superclazz.c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D.apply(this, [owner, fp, diameter, x, y]);
C$.$init$.apply(this);
this.fieldPanel = fp;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "bx", "by", "curl"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
}, 1);

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.x;
this.ds[0][1] = this.y;
this.ds[0][2] = this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, null);
this.ds[0][3] = this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, null);
this.ds[0][4] = this.fieldPanel.getCurl$D$D$bfield_Wire(this.x, this.y, null);
return this.ds;
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:20:55
