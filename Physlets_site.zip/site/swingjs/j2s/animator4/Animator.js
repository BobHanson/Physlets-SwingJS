(function(){var P$=Clazz.newPackage("animator4"),I$=[['edu.davidson.graphics.EtchedBorder','a2s.Button','java.awt.FlowLayout','java.awt.BorderLayout','animator4.AnimatorCanvas','Boolean','java.awt.Color','animator4.Animator$1','animator4.Animator$2','animator4.Animator$3','animator4.Animator$4','animator4.Animator$5','java.awt.Font','edu.davidson.tools.SUtil','animator4.ConnectorLine','animator4.ConnectorSpring','java.util.StringTokenizer','edu.davidson.display.Format','java.net.URL','edu.davidson.graphics.SFrame','java.awt.Toolkit']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Animator", null, 'edu.davidson.tools.SApplet');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.label_time = null;
this.label_collision = null;
this.button_start = null;
this.button_stop = null;
this.button_reset = null;
this.button_forward = null;
this.button_back = null;
this.message = null;
this.fps = 0;
this.ppu = 0;
this.gridUnit = 0;
this.showControls = false;
this.dt = 0;
this.controlPanel = null;
this.etchedBorder2 = null;
this.playBtn = null;
this.pauseBtn = null;
this.flowLayout2 = null;
this.stepBackBtn = null;
this.stepForwardBtn = null;
this.resetBtn = null;
this.borderLayout1 = null;
this.borderLayout2 = null;
this.animatorCanvas = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.label_time = "Time";
this.label_collision = "collision";
this.button_start = "Play";
this.button_stop = "Pause";
this.button_reset = "Reset";
this.button_forward = ">>";
this.button_back = "<<";
this.message = null;
this.fps = 10;
this.ppu = 10;
this.gridUnit = 1.0;
this.controlPanel = Clazz.new_((I$[1]||$incl$(1)));
this.etchedBorder2 = Clazz.new_((I$[1]||$incl$(1)));
this.playBtn = Clazz.new_((I$[2]||$incl$(2)));
this.pauseBtn = Clazz.new_((I$[2]||$incl$(2)));
this.flowLayout2 = Clazz.new_((I$[3]||$incl$(3)));
this.stepBackBtn = Clazz.new_((I$[2]||$incl$(2)));
this.stepForwardBtn = Clazz.new_((I$[2]||$incl$(2)));
this.resetBtn = Clazz.new_((I$[2]||$incl$(2)));
this.borderLayout1 = Clazz.new_((I$[4]||$incl$(4)));
this.borderLayout2 = Clazz.new_((I$[4]||$incl$(4)));
this.animatorCanvas = Clazz.new_((I$[5]||$incl$(5)).c$$animator4_Animator,[this]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'setResources', function () {
this.label_time = this.localProperties.getProperty$S$S("label.time", this.label_time);
this.label_collision = this.localProperties.getProperty$S$S("label.collision", this.label_collision);
this.button_start = this.localProperties.getProperty$S$S("button.start", this.button_start);
this.button_stop = this.localProperties.getProperty$S$S("button.stop", this.button_stop);
this.button_reset = this.localProperties.getProperty$S$S("button.reset", this.button_reset);
this.button_forward = this.localProperties.getProperty$S$S("button.forward", this.button_forward);
this.button_back = this.localProperties.getProperty$S$S("button.back", this.button_back);
});

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
try {
var defFPS = "10";
this.fps = Integer.parseInt(this.getParameter$S$S("FPS", defFPS));

fps *= 2;
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ppu = Integer.parseInt(this.getParameter$S$S("PixPerUnit", "10"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls = (I$[6]||$incl$(6)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.dt = Double.$valueOf(this.getParameter$S$S("dt", "0.1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.gridUnit = Double.$valueOf(this.getParameter$S$S("GridUnit", "1.0")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.controlPanel.setVisible$Z(this.showControls);
this.animatorCanvas.pixPerUnit = this.ppu;
this.animatorCanvas.gridUnit = this.gridUnit;
this.clock.addClockListener$edu_davidson_tools_SStepable(this.animatorCanvas);
this.clock.setDt$D(this.dt);
this.clock.setFPS$D(this.fps);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.controlPanel.setLayout$java_awt_LayoutManager(this.flowLayout2);
this.etchedBorder2.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.setBackground$java_awt_Color((I$[7]||$incl$(7)).lightGray);
this.playBtn.setLabel$S(this.button_start);
this.playBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Animator$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['animator4.Animator'].playBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[8]||$incl$(8)).$init$, [this, null])));
this.pauseBtn.setLabel$S(this.button_stop);
this.pauseBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Animator$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['animator4.Animator'].pauseBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[9]||$incl$(9)).$init$, [this, null])));
this.stepBackBtn.setLabel$S(this.button_back);
this.stepBackBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Animator$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['animator4.Animator'].stepBackBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[10]||$incl$(10)).$init$, [this, null])));
this.stepForwardBtn.setLabel$S(this.button_forward);
this.stepForwardBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Animator$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['animator4.Animator'].stepForwardBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[11]||$incl$(11)).$init$, [this, null])));
this.resetBtn.setLabel$S(this.button_reset);
this.resetBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "Animator$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['animator4.Animator'].resetBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[12]||$incl$(12)).$init$, [this, null])));
this.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.add$java_awt_Component$O(this.controlPanel, "South");
this.controlPanel.add$java_awt_Component$O(this.stepBackBtn, null);
this.controlPanel.add$java_awt_Component$O(this.playBtn, null);
this.controlPanel.add$java_awt_Component$O(this.stepForwardBtn, null);
this.controlPanel.add$java_awt_Component$O(this.pauseBtn, null);
this.controlPanel.add$java_awt_Component$O(this.resetBtn, null);
this.add$java_awt_Component$O(this.etchedBorder2, "Center");
this.etchedBorder2.add$java_awt_Component$O(this.animatorCanvas, "Center");
});

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.firstTime) {
return 0;
} else {
return C$.superclazz.prototype.getAppletCount.apply(this, []);
}});

Clazz.newMeth(C$, 'start', function () {
if (this.firstTime) {
this.firstTime = false;
this.animatorCanvas.clearTrails();
}C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'stop', function () {
C$.superclazz.prototype.stop.apply(this, []);
});

Clazz.newMeth(C$, 'stoppingClock', function () {
this.animatorCanvas.setMessage$S(this.message);
});

Clazz.newMeth(C$, 'cyclingClock', function () {
this.setAnimationTime$D(this.clock.getMinTime());
this.clearAllData();
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (auto) {
if (this.destroyed) {
this.animatorCanvas.autoRefresh = false;
this.autoRefresh = false;
return;
}this.autoRefresh = auto;
this.animatorCanvas.autoRefresh = auto;
this.animatorCanvas.dynamics.resetDynamicsVariables();
if (auto) {
this.animatorCanvas.repaint();
}});

Clazz.newMeth(C$, ['setCaption$S','setCaption'], function (s) {
return this.animatorCanvas.setCaption$S(s);
});

Clazz.newMeth(C$, ['setDragable$I$Z','setDragable'], function (id, canDrag) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.noDrag = !canDrag;
return true;
});

Clazz.newMeth(C$, ['setResizable$I$Z','setResizable'], function (id, isResizable) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setResizable$Z(isResizable);
return true;
});

Clazz.newMeth(C$, ['setVisibility$I$Z','setVisibility'], function (id, show) {
if (id == this.getClockID()) {
this.animatorCanvas.timeDisplay = show;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
}var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setVisible$Z(show);
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.pause();
this.deleteDataConnections();
this.animatorCanvas.setMessage$S(null);
this.message = null;
this.animatorCanvas.timeDisplay = true;
this.clock.setTime$D(0);
this.animatorCanvas.setTime();
this.animatorCanvas.pixPerUnit = this.ppu;
this.animatorCanvas.gridUnit = this.gridUnit;
this.clock.setDt$D(this.dt);
this.clock.setFPS$D(this.fps);
this.clock.setContinuous();
this.animatorCanvas.setDefault();
});

Clazz.newMeth(C$, ['setMass$I$D','setMass'], function (id, m) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setMass$D(m);
return true;
});

Clazz.newMeth(C$, ['setCollisionMessage$S','setCollisionMessage'], function (msg) {
this.label_collision = msg;
});

Clazz.newMeth(C$, ['setMessage$S','setMessage'], function (msg) {
this.animatorCanvas.setMessage$S(msg);
this.message = msg;
});

Clazz.newMeth(C$, ['setAnimationSlave$I$I','setAnimationSlave'], function (masterID, slaveID) {
var master = this.animatorCanvas.getThing$I(masterID);
var slave = this.animatorCanvas.getThing$I(slaveID);
if ((master == null ) || (slave == null ) ) {
return false;
}if (master.myMaster === slave ) {
master.myMaster = null;
}master.mySlaves.addElement$TE(slave);
slave.myMaster = master;
slave.setVarsFromMaster();
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setShapeRGB$I$I$I','setShapeRGB'], function (r, g, b) {
this.animatorCanvas.defaultColor = Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I,[r, g, b]);
});

Clazz.newMeth(C$, ['setRGB$I$I$I$I','setRGB'], function (id, r, g, b) {
if (id == this.animatorCanvas.hashCode()) {
this.animatorCanvas.setBackground$java_awt_Color(Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I,[r, g, b]));
return true;
}var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.color = Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I,[r, g, b]);
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setOneShot$D$D$S','setOneShot'], function (min, max, msg) {
this.clock.setOneShot$D$D(min, max);
this.animatorCanvas.setMessage$S(null);
this.setAnimationTime$D(min);
this.message = msg;
});

Clazz.newMeth(C$, ['setOnScreenSize$I$I','setOnScreenSize'], function (id, size) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setSize$I(size);
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setTimeCycle$D','setTimeCycle'], function (max) {
this.setTimeInterval$D$D(0, max);
});

Clazz.newMeth(C$, ['setTimeInterval$D$D','setTimeInterval'], function (min, max) {
this.clock.setCycle$D$D(min, max);
this.setAnimationTime$D(min);
this.message = null;
this.animatorCanvas.setMessage$S(null);
});

Clazz.newMeth(C$, 'setTimeContinuous', function () {
this.clock.setContinuous();
this.message = null;
this.animatorCanvas.setMessage$S(null);
});

Clazz.newMeth(C$, ['setTimeOneShot$D$S','setTimeOneShot'], function (max, msg) {
this.setOneShot$D$D$S(0, max, msg);
});

Clazz.newMeth(C$, ['setFootPrints$I$I','setFootPrints'], function (id, n) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.footPrints = n;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setGhost$I$Z','setGhost'], function (id, ghost) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.ghost = ghost;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setLabel$I$S','setLabel'], function (id, label) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setLabel$S(label);
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setTolerance$D','setTolerance'], function (tol) {
this.animatorCanvas.dynamics.setTolerance$D(tol);
});

Clazz.newMeth(C$, ['setTrail$I$I','setTrail'], function (id, n) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setTrailSize$I(n);
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setTrail$I$I$I','setTrail'], function (id, n, offset) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setTrailSize$I$I(n, offset);
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setTrajectory$I$S$S','setTrajectory'], function (id, xStr, yStr) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}return t.setTrajectory$S$S(xStr, yStr);
});

Clazz.newMeth(C$, ['setForce$I$S$S$D$D$D$D','setForce'], function (id, fxStr, fyStr, x0, y0, vx0, vy0) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}if (t.setForce$S$S$D$D$D$D(fxStr, fyStr, x0, y0, vx0, vy0)) {
this.animatorCanvas.dynamics.addRateEquation$animator4_Thing(t);
}if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setPaintBeforeGrid$I$Z','setPaintBeforeGrid'], function (id, before) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.paintBeforeGrid = before;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setTimeDisplay$Z','setTimeDisplay'], function (show) {
this.animatorCanvas.timeDisplay = show;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}});

Clazz.newMeth(C$, ['setShowTime$Z','setShowTime'], function (show) {
this.setTimeDisplay$Z(show);
});

Clazz.newMeth(C$, ['setTimeVisibility$Z','setTimeVisibility'], function (visible) {
this.setTimeDisplay$Z(visible);
});

Clazz.newMeth(C$, ['setShowConstraintPath$I$Z','setShowConstraintPath'], function (id, sc) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.showConstraintPath = sc;
return true;
});

Clazz.newMeth(C$, ['setShowCoordinates$I$Z','setShowCoordinates'], function (id, show) {
if (id == this.animatorCanvas.hashCode()) {
this.animatorCanvas.coordDisplay = show;
return true;
}var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.showCoordinates = show;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setShowVComponents$I$Z','setShowVComponents'], function (id, show) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.showVComponents = show;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setShowFComponents$I$Z','setShowFComponents'], function (id, show) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.showFComponents = show;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setShowAComponents$I$Z','setShowAComponents'], function (id, show) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.showAComponents = show;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setShowVVector$I$Z','setShowVVector'], function (id, show) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.showVVector = show;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setShowAVector$I$Z','setShowAVector'], function (id, show) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.showAVector = show;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setShowFVector$I$Z','setShowFVector'], function (id, show) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.showFVector = show;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setSticky$I$Z','setSticky'], function (id, sticky) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setSticky$Z(sticky);
return true;
});

Clazz.newMeth(C$, ['setBouncy$I$Z','setBouncy'], function (id, bounce) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setBouncy$Z(bounce);
return true;
});

Clazz.newMeth(C$, ['setConstrainR$I$D$D$D','setConstrainR'], function (id, r, x, y) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}return t.setConstrainR$D$D$D(r, x, y);
});

Clazz.newMeth(C$, ['setConstrainX$I$D$D$D','setConstrainX'], function (id, x, min, max) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}return t.setConstrainX$D$D$D(x, min, max);
});

Clazz.newMeth(C$, ['setConstrainY$I$D$D$D','setConstrainY'], function (id, y, min, max) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}return t.setConstrainY$D$D$D(y, min, max);
});

Clazz.newMeth(C$, ['setCoordinateOffset$I$I$I','setCoordinateOffset'], function (id, xOff, yOff) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.xCoordOff = xOff;
t.yCoordOff = yOff;
if (Clazz.instanceOf(t, "animator4.CaptionThing")) {
t.xDisplayOff = xOff;
t.yDisplayOff = yOff;
}if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setDampOnMousePressed$Z','setDampOnMousePressed'], function (damp) {
this.animatorCanvas.dampOnMousePressed = damp;
});

Clazz.newMeth(C$, ['setFont$I$S$I$I','setFont'], function (id, family, style, size) {
var font = Clazz.new_((I$[13]||$incl$(13)).c$$S$I$I,[family, style, size]);
var t = this.animatorCanvas.getThing$I(id);
if ((t == null ) || (font == null ) ) {
return false;
}t.font = font;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setObjectFont$I$S$I$I','setObjectFont'], function (id, family, style, size) {
return this.setFont$I$S$I$I(id, family, style, size);
});

Clazz.newMeth(C$, ['setFormat$I$S','setFormat'], function (id, fstr) {
var t = this.animatorCanvas.getThing$I(id);
if ((t == null ) && ((id == 0) || (id == this.animatorCanvas.hashCode()) ) ) {
return this.animatorCanvas.setFormat$S(fstr);
}var result = t.setFormat$S(fstr);
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return result;
});

Clazz.newMeth(C$, ['setDisplayOffset$I$I$I','setDisplayOffset'], function (id, xOff, yOff) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.xDisplayOff = xOff;
t.yDisplayOff = yOff;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setGridUnit$D','setGridUnit'], function (gu) {
this.animatorCanvas.gridUnit = gu;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}});

Clazz.newMeth(C$, ['setSketchMode$Z','setSketchMode'], function (sketch) {
return this.animatorCanvas.setSketchMode$Z(sketch);
});

Clazz.newMeth(C$, ['setPixPerUnit$I','setPixPerUnit'], function (pu) {
this.animatorCanvas.pixPerUnit = pu;
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}});

Clazz.newMeth(C$, ['shiftPixOrigin$I$I','shiftPixOrigin'], function (xo, yo) {
this.animatorCanvas.xOffset = -xo;
this.animatorCanvas.yOffset = -yo;
});

Clazz.newMeth(C$, 'reset', function () {
this.clearAllData();
this.setAnimationTime$D(0.0);
});

Clazz.newMeth(C$, ['setAnimationTime$D','setAnimationTime'], function (time) {
var shouldRun = false;
if (this.clock.isRunning()) {
shouldRun = true;
this.stopClock();
}this.clock.setTime$D(time);
this.animatorCanvas.setTime();
if (shouldRun) {
this.startClock();
} else if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}});

Clazz.newMeth(C$, 'stepTimeForward', function () {
this.animatorCanvas.setMessage$S(null);
if (this.clock.isRunning()) {
this.pause();
return;
}var isNegative = (this.clock.getDt() < 0 );
this.clock.setDt$D(Math.abs(this.clock.getDt()));
this.clock.doStep();
if (this.clock.isCycle() && (this.clock.getTime() <= this.clock.getMinTime() ) ) {
this.animatorCanvas.clearTrails();
}if (isNegative) {
this.clock.setDt$D(-Math.abs(this.clock.getDt()));
}});

Clazz.newMeth(C$, 'stepForward', function () {
this.stepTimeForward();
});

Clazz.newMeth(C$, 'stepTimeBack', function () {
this.animatorCanvas.setMessage$S(null);
if (this.clock.isRunning()) {
this.pause();
return;
}var isNegative = (this.clock.getDt() < 0 );
this.clock.setDt$D(-Math.abs(this.clock.getDt()));
this.clock.doStep();
if (this.clock.isCycle() && (this.clock.getTime() <= this.clock.getMinTime() ) ) {
this.animatorCanvas.clearTrails();
}if (!isNegative) {
this.clock.setDt$D(Math.abs(this.clock.getDt()));
}});

Clazz.newMeth(C$, 'stepBack', function () {
this.stepTimeBack();
});

Clazz.newMeth(C$, ['addObject$S$S','addObject'], function (name, parList) {
if (this.destroyed) {
return 0;
}var t = null;
var xStr = "0";
var yStr = "0";
var width = 20;
var height = 20;
var s = 1;
var r = 5;
var m = 1;
var id = 0;
if (parList == null ) {
parList = " ";
}name = name.toLowerCase().trim();
name = (I$[14]||$incl$(14)).removeWhitespace$S(name);
var parList2 = parList.trim();
parList = (I$[14]||$incl$(14)).removeWhitespace$S(parList);
if (name.equals$O("mouse")) {
var mouseDataSource = this.animatorCanvas.addMouseThing();
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "drag")) {
mouseDataSource.setTrackDrag$Z(true);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "move")) {
mouseDataSource.setTrackMove$Z(true);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "click")) {
mouseDataSource.setTrackClick$Z(true);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "release")) {
mouseDataSource.setTrackRelease$Z(true);
}return mouseDataSource.getID();
} else if (name.equals$O("box")) {
s = 1;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "w=")) {
width = ((I$[14]||$incl$(14)).getParam$S$S(parList, "w=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "h=")) {
height = ((I$[14]||$incl$(14)).getParam$S$S(parList, "h=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "s=")) {
s = ((I$[14]||$incl$(14)).getParam$S$S(parList, "s=")|0);
}id = this.animatorCanvas.addBox$I$I$S$S(width, height, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}if (s != 1) {
this.animatorCanvas.getThing$I(id).setSize$I(s);
}return id;
} else if (name.equals$O("rectangle")) {
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "w=")) {
width = ((I$[14]||$incl$(14)).getParam$S$S(parList, "w=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "h=")) {
height = ((I$[14]||$incl$(14)).getParam$S$S(parList, "h=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}id = this.animatorCanvas.addRectangle$I$I$S$S(width, height, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}return id;
} else if (name.equals$O("circle")) {
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "r=")) {
r = ((I$[14]||$incl$(14)).getParam$S$S(parList, "r=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}id = this.animatorCanvas.addCircle$I$S$S(2 * r + 1, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}return id;
} else if (name.equals$O("doppler")) {
var numCrests = 10;
var period = 1.0;
var c = 1.0;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "r=")) {
r = ((I$[14]||$incl$(14)).getParam$S$S(parList, "r=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "n=")) {
numCrests = ((I$[14]||$incl$(14)).getParam$S$S(parList, "n=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "period=")) {
period = (I$[14]||$incl$(14)).getParam$S$S(parList, "period=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "c=")) {
c = (I$[14]||$incl$(14)).getParam$S$S(parList, "c=");
}numCrests = Math.max(1, numCrests);
period = Math.max(this.dt, period);
if (c <= 0 ) {
c = 1;
}id = this.animatorCanvas.addDoppler$I$S$S$I$D$D(2 * r + 1, xStr, yStr, numCrests, period, c);
if (m != 1 ) {
this.setMass$I$D(id, m);
}return id;
} else if (name.equals$O("charge")) {
var q = 1;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "r=")) {
r = ((I$[14]||$incl$(14)).getParam$S$S(parList, "r=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "q=")) {
q = (I$[14]||$incl$(14)).getParam$S$S(parList, "q=");
}id = this.animatorCanvas.addCharge$I$S$S$D(2 * r + 1, xStr, yStr, q);
if (m != 1 ) {
this.setMass$I$D(id, m);
}return id;
} else if (name.equals$O("shell")) {
s = 1;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "r=")) {
r = ((I$[14]||$incl$(14)).getParam$S$S(parList, "r=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "s=")) {
s = ((I$[14]||$incl$(14)).getParam$S$S(parList, "s=")|0);
}id = this.animatorCanvas.addShell$I$S$S(2 * r + 1, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}if (s != 1) {
this.animatorCanvas.getThing$I(id).setSize$I(s);
}return id;
} else if (name.equals$O("exshell")) {
var rStr = "10";
s = 2;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "r=")) {
rStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "r=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "s=")) {
s = ((I$[14]||$incl$(14)).getParam$S$S(parList, "s=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}id = this.animatorCanvas.addExShell$I$S$S$S(s, rStr, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}return id;
} else if (name.equals$O("image")) {
var file = " ";
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "gif=")) {
file = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "gif=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "file=")) {
file = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "file=");
}if (file == null ) {
return 0;
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}id = this.addImage$S$S$S(file, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}return id;
} else if (name.equals$O("protractor")) {
s = 40;
var theta = 0;
var theta0 = 0;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "theta=")) {
theta = (I$[14]||$incl$(14)).getParam$S$S(parList, "theta=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "theta0=")) {
theta0 = (I$[14]||$incl$(14)).getParam$S$S(parList, "theta0=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "s=")) {
s = ((I$[14]||$incl$(14)).getParam$S$S(parList, "s=")|0);
}id = this.animatorCanvas.addProtractor$I$D$D$S$S(s, theta, theta0, xStr, yStr);
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "fixedbase")) {
var p = this.animatorCanvas.getThing$I(id);
p.fixedBase = true;
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "fixedlength")) {
var p = this.animatorCanvas.getThing$I(id);
p.fixedlength = true;
}return id;
} else if (name.equals$O("arrow")) {
var horz = "1";
var vert = "1";
s = 4;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "h=")) {
horz = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "h=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "v=")) {
vert = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "v=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "s=")) {
s = ((I$[14]||$incl$(14)).getParam$S$S(parList, "s=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}id = this.animatorCanvas.addArrow$I$S$S$S$S(s, horz, vert, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "thickness=")) {
var a = this.animatorCanvas.getThing$I(id);
a.thickness = Math.max(((I$[14]||$incl$(14)).getParam$S$S(parList, "thickness=")|0), 1);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "filled")) {
var a = this.animatorCanvas.getThing$I(id);
a.setFilled$Z(true);
}return id;
} else if (name.equals$O("arrow2")) {
var horz = 1;
var vert = 1;
s = 5;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "h=")) {
horz = (I$[14]||$incl$(14)).getParam$S$S(parList, "h=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "v=")) {
vert = (I$[14]||$incl$(14)).getParam$S$S(parList, "v=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "s=")) {
s = ((I$[14]||$incl$(14)).getParam$S$S(parList, "s=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}id = this.animatorCanvas.addArrowStatic$I$D$D$S$S(s, horz, vert, xStr, yStr);
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "thickness=")) {
var a = this.animatorCanvas.getThing$I(id);
a.thickness = Math.max(((I$[14]||$incl$(14)).getParam$S$S(parList, "thickness=")|0), 1);
}if (m != 1 ) {
this.setMass$I$D(id, m);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "filled")) {
var a = this.animatorCanvas.getThing$I(id);
a.setFilled$Z(true);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "fixedlength")) {
var a = this.animatorCanvas.getThing$I(id);
a.setFixedLength$Z(true);
}return id;
} else if (name.equals$O("piston")) {
var horz = "1";
var vert = "1";
s = 4;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "h=")) {
horz = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "h=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "v=")) {
vert = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "v=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "s=")) {
s = ((I$[14]||$incl$(14)).getParam$S$S(parList, "s=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}id = this.animatorCanvas.addPiston$I$S$S$S$S(s, horz, vert, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}return id;
} else if (name.equals$O("line")) {
var horz = "1";
var vert = "1";
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "h=")) {
horz = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "h=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "v=")) {
vert = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "v=");
}id = this.animatorCanvas.addArrow$I$S$S$S$S(0, horz, vert, xStr, yStr);
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "thickness=")) {
var a = this.animatorCanvas.getThing$I(id);
a.thickness = Math.max(((I$[14]||$incl$(14)).getParam$S$S(parList, "thickness=")|0), 1);
}return id;
} else if (name.equals$O("calculation")) {
var txt = "";
var chop = 1.0E-12;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "txt=")) {
txt = (I$[14]||$incl$(14)).getParamStr$S$S(parList2, "txt=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "text=")) {
txt = (I$[14]||$incl$(14)).getParamStr$S$S(parList2, "text=");
}id = this.animatorCanvas.addCalcThing$S$S$S(txt, xStr, yStr);
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "chop=")) {
chop = (I$[14]||$incl$(14)).getParam$S$S(parList, "chop=");
var ct = this.animatorCanvas.getThing$I(id);
ct.setChop$D(chop);
}return id;
} else if (name.equals$O("text")) {
var txt = "";
var calc = null;
var chop = 1.0E-12;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "txt=")) {
txt = (I$[14]||$incl$(14)).getParamStr$S$S(parList2, "txt=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "text=")) {
txt = (I$[14]||$incl$(14)).getParamStr$S$S(parList2, "text=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "calc=")) {
calc = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "calc=");
}id = this.animatorCanvas.addText$S$S$S$S(txt, calc, xStr, yStr);
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "chop=")) {
chop = (I$[14]||$incl$(14)).getParam$S$S(parList, "chop=");
var tt = this.animatorCanvas.getThing$I(id);
tt.setChop$D(chop);
}return id;
} else if (name.equals$O("caption")) {
var txt = "";
var calc = null;
var chop = 1.0E-12;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "txt=")) {
txt = (I$[14]||$incl$(14)).getParamStr$S$S(parList2, "txt=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "text=")) {
txt = (I$[14]||$incl$(14)).getParamStr$S$S(parList2, "text=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "calc=")) {
calc = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "calc=");
}id = this.animatorCanvas.addCaption$S$S$S$S(txt, calc, "0", "0");
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "chop=")) {
chop = (I$[14]||$incl$(14)).getParam$S$S(parList, "chop=");
var cap = this.animatorCanvas.getThing$I(id);
cap.setChop$D(chop);
}return id;
} else if (name.equals$O("connectorline")) {
var id1 = 0;
var id2 = 0;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "id1=")) {
id1 = ((I$[14]||$incl$(14)).getParam$S$S(parList, "id1=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "id2=")) {
id2 = ((I$[14]||$incl$(14)).getParam$S$S(parList, "id2=")|0);
}return this.addConnectorLine$I$I(id1, id2);
} else if (name.equals$O("connectorspring")) {
var id1 = 0;
var id2 = 0;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "id1=")) {
id1 = ((I$[14]||$incl$(14)).getParam$S$S(parList, "id1=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "id2=")) {
id2 = ((I$[14]||$incl$(14)).getParam$S$S(parList, "id2=")|0);
}return this.addConnectorSpring$I$I(id1, id2);
} else if (name.equals$O("cursor")) {
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "r=")) {
r = ((I$[14]||$incl$(14)).getParam$S$S(parList, "r=")|0);
}return this.animatorCanvas.addCursor$I$S$S(2 * r + 1, xStr, yStr);
} else if (name.equals$O("interaction")) {
var id1 = 0;
var id2 = 0;
var fStr = "0";
var mode = "r";
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "id1=")) {
id1 = ((I$[14]||$incl$(14)).getParam$S$S(parList, "id1=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "id2=")) {
id2 = ((I$[14]||$incl$(14)).getParam$S$S(parList, "id2=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "force=")) {
fStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "force=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "mode=")) {
mode = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "mode=");
}if (!this.animatorCanvas.addInteraction$I$I$S$S(id1, id2, fStr, mode)) {
System.out.println$S("Error in add interaction. force=" + fStr);
}return 0;
} else if (name.equals$O("curve")) {
var n = 100;
var start = -1;
var stop = 1;
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "n=")) {
n = ((I$[14]||$incl$(14)).getParam$S$S(parList, "n=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "start=")) {
start = (I$[14]||$incl$(14)).getParam$S$S(parList, "start=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "stop=")) {
stop = (I$[14]||$incl$(14)).getParam$S$S(parList, "stop=");
}return this.animatorCanvas.addParametricCurve$I$D$D$S$S(n, start, stop, xStr, yStr);
} else if (name.equals$O("polyshape")) {
var n = 0;
var hStr = " ";
var vStr = " ";
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "n=")) {
n = ((I$[14]||$incl$(14)).getParam$S$S(parList, "n=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "h=")) {
hStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "h=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "v=")) {
vStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "v=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}id = this.addPolyShape$I$S$S$S$S(n, hStr, vStr, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}return id;
} else if (name.equals$O("relshape")) {
var n = 0;
var hStr = " ";
var vStr = " ";
if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "n=")) {
n = ((I$[14]||$incl$(14)).getParam$S$S(parList, "n=")|0);
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "x=")) {
xStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "x=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "y=")) {
yStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "y=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "h=")) {
hStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "h=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "v=")) {
vStr = (I$[14]||$incl$(14)).getParamStr$S$S(parList, "v=");
}if ((I$[14]||$incl$(14)).parameterExist$S$S(parList, "m=")) {
m = (I$[14]||$incl$(14)).getParam$S$S(parList, "m=");
}id = this.addRelPolyShape$I$S$S$S$S(n, hStr, vStr, xStr, yStr);
if (m != 1 ) {
this.setMass$I$D(id, m);
}return id;
}if (t == null ) {
System.out.println$S("Object not created. name:" + name + "parameter list:" + parList );
}return 0;
});

Clazz.newMeth(C$, ['addCircle$I$S$S','addCircle'], function (diameter, xStr, yStr) {
return this.animatorCanvas.addCircle$I$S$S(diameter, xStr, yStr);
});

Clazz.newMeth(C$, ['addShell$I$S$S','addShell'], function (diameter, xStr, yStr) {
return this.animatorCanvas.addShell$I$S$S(diameter, xStr, yStr);
});

Clazz.newMeth(C$, ['addExShell$I$S$S$S','addExShell'], function (tickness, rStr, xStr, yStr) {
return this.animatorCanvas.addExShell$I$S$S$S(tickness, rStr, xStr, yStr);
});

Clazz.newMeth(C$, ['addPiston$I$S$S$S$S','addPiston'], function (s, hStr, vStr, xStr, yStr) {
return this.animatorCanvas.addPiston$I$S$S$S$S(s, hStr, vStr, xStr, yStr);
});

Clazz.newMeth(C$, ['addSpring$S$S$S$S','addSpring'], function (hStr, vStr, xStr, yStr) {
return this.animatorCanvas.addSpring$I$S$S$S$S(4, hStr, vStr, xStr, yStr);
});

Clazz.newMeth(C$, ['addArrow$S$S$S$S','addArrow'], function (hStr, vStr, xStr, yStr) {
return this.animatorCanvas.addArrow$I$S$S$S$S(4, hStr, vStr, xStr, yStr);
});

Clazz.newMeth(C$, ['addInteraction$I$I$S$S','addInteraction'], function (id1, id2, force, mode) {
return this.animatorCanvas.addInteraction$I$I$S$S(id1, id2, force, mode);
});

Clazz.newMeth(C$, ['addCalculation$S$S$S$S','addCalculation'], function (text, calc, xStr, yStr) {
return this.animatorCanvas.addText$S$S$S$S(text, calc, xStr, yStr);
});

Clazz.newMeth(C$, ['addCaption$S$S','addCaption'], function (text, calc) {
return this.animatorCanvas.addCaption$S$S$S$S(text, calc, "0", "0");
});

Clazz.newMeth(C$, ['addCursor$I$S$S','addCursor'], function (diameter, xStr, yStr) {
return this.animatorCanvas.addCursor$I$S$S(diameter, xStr, yStr);
});

Clazz.newMeth(C$, ['addText$S$S$S','addText'], function (text, xStr, yStr) {
return this.animatorCanvas.addText$S$S$S$S(text, null, xStr, yStr);
});

Clazz.newMeth(C$, ['addLine$S$S$S$S','addLine'], function (hStr, vStr, xStr, yStr) {
return this.animatorCanvas.addArrow$I$S$S$S$S(0, hStr, vStr, xStr, yStr);
});

Clazz.newMeth(C$, ['addConnectorLine$I$I','addConnectorLine'], function (id1, id2) {
var t1 = this.animatorCanvas.getThing$I(id1);
var t2 = this.animatorCanvas.getThing$I(id2);
var c = Clazz.new_((I$[15]||$incl$(15)).c$$animator4_AnimatorCanvas$animator4_Thing$animator4_Thing,[this.animatorCanvas, t1, t2]);
this.animatorCanvas.things.addElement$TE(c);
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return c.hashCode();
});

Clazz.newMeth(C$, ['addConnectorSpring$I$I','addConnectorSpring'], function (id1, id2) {
var t1 = this.animatorCanvas.getThing$I(id1);
var t2 = this.animatorCanvas.getThing$I(id2);
var c = Clazz.new_((I$[16]||$incl$(16)).c$$animator4_AnimatorCanvas$animator4_Thing$animator4_Thing,[this.animatorCanvas, t1, t2]);
this.animatorCanvas.things.addElement$TE(c);
if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return c.hashCode();
});

Clazz.newMeth(C$, ['swapZOrder$I$I','swapZOrder'], function (id1, id2) {
return this.animatorCanvas.swapZOrder$I$I(id1, id2);
});

Clazz.newMeth(C$, ['deleteObject$I','deleteObject'], function (id) {
this.animatorCanvas.deleteObject$I(id);
});

Clazz.newMeth(C$, ['addBox$I$I$S$S','addBox'], function (w, h, xStr, yStr) {
return this.animatorCanvas.addBox$I$I$S$S(w, h, xStr, yStr);
});

Clazz.newMeth(C$, ['addRectangle$I$I$S$S','addRectangle'], function (w, h, xStr, yStr) {
return this.animatorCanvas.addRectangle$I$I$S$S(w, h, xStr, yStr);
});

Clazz.newMeth(C$, ['addParametricCurve$I$D$D$S$S','addParametricCurve'], function (n, start, stop, xStr, yStr) {
return this.animatorCanvas.addParametricCurve$I$D$D$S$S(n, start, stop, xStr, yStr);
});

Clazz.newMeth(C$, ['addPolyShape$I$S$S$S$S','addPolyShape'], function (n, hStr, vStr, xStr, yStr) {
var htokens = Clazz.new_((I$[17]||$incl$(17)).c$$S$S,[hStr, ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
var vtokens = Clazz.new_((I$[17]||$incl$(17)).c$$S$S,[vStr, ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
if ((htokens.countTokens() != n) || (htokens.countTokens() != n) ) {
return 0;
}var h = Clazz.array(Integer.TYPE, [n]);
var v = Clazz.array(Integer.TYPE, [n]);
for (var i = 0; i < n; i++) {
h[i] = (I$[18]||$incl$(18)).atoi$S(htokens.nextToken());
v[i] = (I$[18]||$incl$(18)).atoi$S(vtokens.nextToken());
}
return this.animatorCanvas.addPolyShape$I$IA$IA$S$S(n, h, v, xStr, yStr);
});

Clazz.newMeth(C$, ['addRelPolyShape$I$S$S$S$S','addRelPolyShape'], function (n, hStr, vStr, xStr, yStr) {
var htokens = Clazz.new_((I$[17]||$incl$(17)).c$$S$S,[hStr, ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
var vtokens = Clazz.new_((I$[17]||$incl$(17)).c$$S$S,[vStr, ", ; / \\ ( { [ ) } ] \u0009 \u000a \u000d"]);
if ((htokens.countTokens() != n) || (htokens.countTokens() != n) ) {
return 0;
}var h = Clazz.array(Integer.TYPE, [n]);
var v = Clazz.array(Integer.TYPE, [n]);
for (var i = 0; i < n; i++) {
h[i] = (I$[18]||$incl$(18)).atoi$S(htokens.nextToken());
v[i] = (I$[18]||$incl$(18)).atoi$S(vtokens.nextToken());
}
for (var i = 1; i < n; i++) {
h[i] = h[i - 1] + h[i];
v[i] = v[i - 1] + v[i];
}
return this.animatorCanvas.addPolyShape$I$IA$IA$S$S(n, h, v, xStr, yStr);
});

Clazz.newMeth(C$, ['addImage$S$S$S','addImage'], function (file, xStr, yStr) {
var id = 0;
var im;
try {
im = this.getImage$java_net_URL$S(this.getCodeBase(), file);
id = this.animatorCanvas.addImage$java_awt_Image$S$S(im, xStr, yStr);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
id = 0;
} else {
throw e;
}
}
if (id == 0) {
try {
im = this.getImage$java_net_URL$S(this.getDocumentBase(), file);
id = this.animatorCanvas.addImage$java_awt_Image$S$S(im, xStr, yStr);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
id = 0;
} else {
throw e;
}
}
}if (id == 0) {
try {
var url = Clazz.new_((I$[19]||$incl$(19)).c$$S,[file]);
im = this.getImage$java_net_URL(url);
id = this.animatorCanvas.addImage$java_awt_Image$S$S(im, xStr, yStr);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
id = 0;
} else {
throw e;
}
}
}if (id == 0) {
System.out.println$S("Failed to load image file.");
}return id;
});

Clazz.newMeth(C$, ['addImageFromDocumentBase$S$S$S','addImageFromDocumentBase'], function (file, xStr, yStr) {
var id = 0;
try {
id = this.animatorCanvas.addImage$java_awt_Image$S$S(this.getImage$java_net_URL$S(this.getDocumentBase(), file), xStr, yStr);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
id = 0;
System.out.println$S("Failed to load image file from Document Base");
} else {
throw e;
}
}
return id;
});

Clazz.newMeth(C$, ['addImageFromCodeBase$S$S$S','addImageFromCodeBase'], function (file, xStr, yStr) {
var id = 0;
try {
id = this.animatorCanvas.addImage$java_awt_Image$S$S(this.getImage$java_net_URL$S(this.getCodeBase(), file), xStr, yStr);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
id = 0;
System.out.println$S("Failed to load image file from Code base!");
} else {
throw e;
}
}
return id;
});

Clazz.newMeth(C$, 'getPhysletCanvas', function () {
return this.animatorCanvas;
});

Clazz.newMeth(C$, 'getEnsembleID', function () {
return this.animatorCanvas.hashCode();
});

Clazz.newMeth(C$, 'getCollisionID', function () {
return this.animatorCanvas.getCollisionThing().hashCode();
});

Clazz.newMeth(C$, 'reverse', function () {
this.clock.setDt$D(-this.clock.getDt());
});

Clazz.newMeth(C$, 'forward', function () {
this.animatorCanvas.setMessage$S(null);
this.clock.startClock();
});

Clazz.newMeth(C$, 'pause', function () {
this.animatorCanvas.setMessage$S(null);
if (this.clock.isRunning()) {
this.clock.stopClock();
}});

Clazz.newMeth(C$, 'getAnimationTime', function () {
return this.animatorCanvas.time;
});

Clazz.newMeth(C$, ['getX$I','getX'], function (id) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return 0;
}return t.getX();
});

Clazz.newMeth(C$, ['setX$I$D','setX'], function (id, x) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setX$D(x);
this.animatorCanvas.dynamics.resetDynamicsVariables();
if (t === this.animatorCanvas.dragThing ) {
this.animatorCanvas.this_mouseReleased$java_awt_event_MouseEvent(null);
}if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setXPos$I$D','setXPos'], function (id, x) {
return this.setX$I$D(id, x);
});

Clazz.newMeth(C$, ['getXPos$I','getXPos'], function (id) {
return this.getX$I(id);
});

Clazz.newMeth(C$, ['getYPos$I','getYPos'], function (id) {
return this.getY$I(id);
});

Clazz.newMeth(C$, ['setXY$I$D$D','setXY'], function (id, x, y) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setXY$D$D(x, y);
this.animatorCanvas.dynamics.resetDynamicsVariables();
if (t === this.animatorCanvas.dragThing ) {
this.animatorCanvas.this_mouseReleased$java_awt_event_MouseEvent(null);
}if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['getH$I','getH'], function (id) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return 0;
}return t.getH();
});

Clazz.newMeth(C$, ['setH$I$D','setH'], function (id, h) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setH$D(h);
this.animatorCanvas.dynamics.resetDynamicsVariables();
if (t === this.animatorCanvas.dragThing ) {
this.animatorCanvas.this_mouseReleased$java_awt_event_MouseEvent(null);
}if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['getW$I','getW'], function (id) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return 0;
}return t.getW();
});

Clazz.newMeth(C$, ['setW$I$D','setW'], function (id, w) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setW$D(w);
this.animatorCanvas.dynamics.resetDynamicsVariables();
if (t === this.animatorCanvas.dragThing ) {
this.animatorCanvas.this_mouseReleased$java_awt_event_MouseEvent(null);
}if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['getY$I','getY'], function (id) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return 0;
}return t.getY();
});

Clazz.newMeth(C$, ['setY$I$D','setY'], function (id, y) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setY$D(y);
this.animatorCanvas.dynamics.resetDynamicsVariables();
if (t === this.animatorCanvas.dragThing ) {
this.animatorCanvas.this_mouseReleased$java_awt_event_MouseEvent(null);
}if (this.animatorCanvas.autoRefresh) {
this.animatorCanvas.repaint();
}return true;
});

Clazz.newMeth(C$, ['setYPos$I$D','setYPos'], function (id, y) {
return this.setY$I$D(id, y);
});

Clazz.newMeth(C$, ['getVX$I','getVX'], function (id) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return 0;
}return t.getVX();
});

Clazz.newMeth(C$, ['setVX$I$D','setVX'], function (id, vx) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setVX$D(vx);
this.animatorCanvas.dynamics.resetDynamicsVariables();
return true;
});

Clazz.newMeth(C$, ['getVY$I','getVY'], function (id) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return 0;
}return t.getVY();
});

Clazz.newMeth(C$, ['setVY$I$D','setVY'], function (id, vy) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setVY$D(vy);
this.animatorCanvas.dynamics.resetDynamicsVariables();
return true;
});

Clazz.newMeth(C$, ['setSpeed$I$D','setSpeed'], function (id, speed) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}t.setSpeed$D(speed);
this.animatorCanvas.dynamics.resetDynamicsVariables();
return true;
});

Clazz.newMeth(C$, ['setCharge$I$D','setCharge'], function (id, q) {
var t = this.animatorCanvas.getThing$I(id);
if (Clazz.instanceOf(t, "animator4.Charge")) {
(t).q = q;
this.animatorCanvas.dynamics.resetDynamicsVariables();
return true;
}return false;
});

Clazz.newMeth(C$, ['getFx$I','getFx'], function (id) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return 0;
}return t.getFx();
});

Clazz.newMeth(C$, ['setReferenceFrame$I','setReferenceFrame'], function (id) {
this.animatorCanvas.clearTrails();
if ((id == 0) || (id == this.animatorCanvas.hashCode()) ) {
this.animatorCanvas.setReferenceObject$animator4_Thing(null);
return true;
}var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return false;
}this.animatorCanvas.setReferenceObject$animator4_Thing(t);
return true;
});

Clazz.newMeth(C$, ['getFy$I','getFy'], function (id) {
var t = this.animatorCanvas.getThing$I(id);
if (t == null ) {
return 0;
}return t.getFy();
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Animator4 Physlet by W. Christian. Email:wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["FPS", "int", "Frames per sconds"]), Clazz.array(java.lang.String, -1, ["PixPerUnit", "int", "Pixels for screen unit"]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the control buttons"]), Clazz.array(java.lang.String, -1, ["dt", "double", "Animation time step per frame."])]);
return pinfo;
});

Clazz.newMeth(C$, 'playBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.forward();
});

Clazz.newMeth(C$, 'pauseBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.pause();
});

Clazz.newMeth(C$, 'stepForwardBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.stepForward();
});

Clazz.newMeth(C$, 'stepBackBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.stepBack();
});

Clazz.newMeth(C$, 'resetBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.setAnimationTime$D(0);
});

Clazz.newMeth(C$, 'main', function (args) {
var applet = Clazz.new_(C$);
applet.isStandalone = true;
var frame = Clazz.new_((I$[20]||$incl$(20)).c$$S,["Animator Physlet"]);
frame.setTitle$S("Applet Frame");
frame.add$java_awt_Component$O(applet, "Center");
applet.init();
applet.start();
applet.setSize$I$I(400, 320);
frame.setSize$I$I(400, 320);
var d = (I$[21]||$incl$(21)).getDefaultToolkit().getScreenSize();
frame.setLocation$I$I(((d.width - frame.getSize().width)/2|0), ((d.height - frame.getSize().height)/2|0));
frame.setVisible$Z(true);
applet.test();
}, 1);

Clazz.newMeth(C$, 'test', function () {
this.setAutoRefresh$Z(false);
this.setDefault();
this.shiftPixOrigin$I$I(20, 0);
this.setPixPerUnit$I(10);
this.setGridUnit$D(0);
var id = this.addObject$S$S("circle", "r=12");
this.setTrajectory$I$S$S(id, "step(8-t)*(-22+5*t)+step(t-8)*(-22+5*8-2*(t-8))", "step(8-t)*(-12+2*t)+step(t-8)*(-12+2*8+1*(t-8))");
this.setRGB$I$I$I$I(id, 0, 0, 0);
id = this.addObject$S$S("circle", "r=11");
this.setTrajectory$I$S$S(id, "step(8-t)*(-22+5*t)+step(t-8)*(-22+5*8-2*(t-8))", "step(8-t)*(-12+2*t)+step(t-8)*(-12+2*8+1*(t-8))");
this.setRGB$I$I$I$I(id, 255, 0, 0);
this.setAutoRefresh$Z(true);
this.setOneShot$D$D$S(0, 16, "End of Animation");
this.updateDataConnections();
this.setAnimationTime$D(0);
});
})();
//Created 2018-02-22 01:06:56
