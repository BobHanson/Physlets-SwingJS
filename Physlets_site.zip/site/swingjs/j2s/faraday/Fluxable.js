(function(){var P$=Clazz.newPackage("faraday"),I$=[];
var C$=Clazz.newInterface(P$, "Fluxable");
})();
//Created 2018-03-17 21:37:06
