(function(){var P$=Clazz.newPackage("eField4"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Pole", null, 'eField4.Charge');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$D', function (p, x, y, m) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D$D.apply(this, [p, x, y, 0, 0, m]);
C$.$init$.apply(this);
this.p = p;
this.s = 9;
this.vars[0] = 0;
this.vars[1] = x;
this.vars[2] = y;
this.vars[3] = 0;
this.vars[4] = 0;
this.initVars[0] = 0;
this.initVars[1] = x;
this.initVars[2] = y;
this.initVars[3] = 0;
this.initVars[4] = 0;
this.showVVector = false;
this.showFVector = false;
this.trailSize = 0;
if (this.mag < 0 ) this.color = (I$[1]||$incl$(1)).blue;
 else this.color = (I$[1]||$incl$(1)).red;
this.sticky = true;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-19 20:23:30
