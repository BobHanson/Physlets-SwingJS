(function(){var P$=Clazz.newPackage("block"),I$=[[0,'java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Block");
C$.width=0;
C$.height=0;
C$.g=null;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x=0;
this.y=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'init$I$I', function (x, y) {
this.x=x;
this.y=y;
});

Clazz.newMeth(C$, 'changeY$I', function (y) {
this.y=y;
});

Clazz.newMeth(C$, 'inside$I$I', function (n, n2) {
return n > this.x && n < this.x + C$.width  && n2 > this.y  && n2 < this.y + C$.height ;
});

Clazz.newMeth(C$, 'moveX$I', function (n) {
if (this.x + n < 0) {
return false;
}this.x+=n;
return true;
});

Clazz.newMeth(C$, 'draw$java_awt_Color', function (color) {
var n=-2;
C$.g.setColor$java_awt_Color($I$(1).black);
C$.g.drawRect$I$I$I$I(this.x, this.y, C$.width, C$.height);
C$.g.setColor$java_awt_Color($I$(1).red);
C$.g.drawString$S$I$I(String.valueOf$I(this.x), this.x, this.y + -2);
C$.g.setColor$java_awt_Color(color);
C$.g.fillRect$I$I$I$I(this.x + 1, this.y + 1, C$.width - 1, C$.height - 1);
C$.g.setColor$java_awt_Color($I$(1).blue);
C$.g.fillOval$I$I$I$I(this.x + (C$.width/2|0) - 2, this.y + (C$.height/2|0) - 2, 4, 4);
C$.g.drawString$S$I$I(String.valueOf$I(this.x + (C$.width/2|0)), this.x + (C$.width/2|0), this.y + (C$.height/2|0) + -2);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:43 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
