(function(){var P$=Clazz.newPackage("edu.davidson.physlets.emwave4"),I$=[];
var C$=Clazz.newClass(P$, "Plane", null, 'edu.davidson.physlets.emwave4.Figure');
C$.lineDensity = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.lineDensity = 2;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.polarization = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.polarization = 0;
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D$D$java_awt_Color', function (z1, length, width, p, clr) {
Clazz.super_(C$, this,1);
this.numLines = (Math.round(width / C$.lineDensity)|0);
var zPosition = z1;
this.c = clr;
this.pts = Clazz.array(Double.TYPE, [2 * this.numLines, 3]);
this.polarization = p;
for (var i = 1, j = (-this.numLines/2|0); i < 2 * this.numLines; i = i+(2), j++) {
this.pts[i][0] = Math.cos(this.polarization) * j * C$.lineDensity  - Math.sin(this.polarization) * length / 2;
this.pts[i][1] = Math.sin(this.polarization) * j * C$.lineDensity  + Math.cos(this.polarization) * length / 2;
this.pts[i][2] = zPosition;
}
for (var i = 0, j = (-this.numLines/2|0); i < 2 * this.numLines; i = i+(2), j++) {
this.pts[i][0] = Math.cos(this.polarization) * j * C$.lineDensity  + Math.sin(this.polarization) * length / 2;
this.pts[i][1] = Math.sin(this.polarization) * j * C$.lineDensity  - Math.cos(this.polarization) * length / 2;
this.pts[i][2] = zPosition;
}
}, 1);

Clazz.newMeth(C$, 'setLineDensity$I', function (d) {
C$.lineDensity = d;
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:07:17
