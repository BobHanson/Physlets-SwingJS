(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[['java.lang.Thread','Thread']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "STimer", null, null, 'Runnable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.thread = null;
this.running = false;
this.oneShot = false;
this.client = null;
this.interval = 0;
this.keepRunning = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.thread = null;
this.running = false;
this.oneShot = false;
this.client = null;
this.keepRunning = false;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.interval = 100;
}, 1);

Clazz.newMeth(C$, 'start$I', function (i) {
this.interval = i;
this.start();
});

Clazz.newMeth(C$, 'start', function () {
if (this.thread == null ) {
this.thread = Clazz.new_((I$[1]||$incl$(1)).c$$Runnable,[this]);
this.thread.start();
this.running = true;
}});

Clazz.newMeth(C$, 'stop', function () {
this.keepRunning = false;
});

Clazz.newMeth(C$, 'stopThread', function () {
var mythread = this.thread;
if (mythread != null ) {
this.keepRunning = false;
try {
mythread.join();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
this.thread = null;
}this.keepRunning = false;
});

Clazz.newMeth(C$, 'resume', function () {
if (this.thread != null  && this.thread.isAlive() ) {
this.thread.resume();
this.running = true;
} else this.start();
});

Clazz.newMeth(C$, 'resume$I', function (i) {
this.interval = i;
this.resume();
});

Clazz.newMeth(C$, 'pause', function () {
if (this.thread != null ) {
this.thread.suspend();
this.running = false;
}});

Clazz.newMeth(C$, 'destroy', function () {
this.stopThread();
});

Clazz.newMeth(C$, 'run', function () {
this.keepRunning = true;
while (this.keepRunning && this.client != null  ){
try {
(I$[2]||$incl$(2)).sleep$J(this.interval);
this.client.tick();
if (this.oneShot) {
this.keepRunning = false;
}} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.InterruptedException")){
} else {
throw e;
}
}
}
this.thread = null;
this.running = false;
});

Clazz.newMeth(C$, 'doOneShot', function () {
this.doOneShot$I(this.interval);
});

Clazz.newMeth(C$, 'doOneShot$I', function (i) {
this.setOneShot$Z(true);
this.start();
});

Clazz.newMeth(C$, 'setOneShot$Z', function (o) {
this.oneShot = o;
});

Clazz.newMeth(C$, 'isOneShot', function () {
return this.oneShot;
});

Clazz.newMeth(C$, 'setRunning$Z', function (r) {
this.running = r;
});

Clazz.newMeth(C$, 'isRunning', function () {
return this.running;
});

Clazz.newMeth(C$, 'setInterval$I', function (i) {
this.interval = i;
});

Clazz.newMeth(C$, 'getInterval', function () {
return this.interval;
});

Clazz.newMeth(C$, 'setClient$edu_davidson_tools_TimerClient', function (c) {
this.client = c;
});

Clazz.newMeth(C$, 'getClient', function () {
return this.client;
});
})();
//Created 2018-02-08 01:51:46
