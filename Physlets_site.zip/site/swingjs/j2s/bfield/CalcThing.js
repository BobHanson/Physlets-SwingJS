(function(){var P$=Clazz.newPackage("bfield"),I$=[['java.awt.Font','edu.davidson.numerics.Parser','edu.davidson.tools.SUtil','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CalcThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.tempVars = null;
this.calcStr = null;
this.calcFunc = null;
this.fieldPanel = null;
this.text = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.tempVars = Clazz.array(Double.TYPE, [7]);
this.fieldPanel = null;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$bfield_FieldPanel$S$S$D$D', function (owner, panel, txt, cs, x, y) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [panel, x, y]);
C$.$init$.apply(this);
this.fieldPanel = panel;
this.applet = owner;
this.font = Clazz.new_((I$[1]||$incl$(1)).c$$S$I$I,["Helvetica", 1, 14]);
this.text = txt;
this.calcStr = cs;
if (this.calcStr == null ) return;
this.calcFunc = Clazz.new_((I$[2]||$incl$(2)).c$$I,[7]);
this.calcFunc.defineVariable$I$S(1, "x");
this.calcFunc.defineVariable$I$S(2, "y");
this.calcFunc.defineVariable$I$S(3, "bx");
this.calcFunc.defineVariable$I$S(4, "by");
this.calcFunc.defineVariable$I$S(5, "i");
this.calcFunc.defineVariable$I$S(6, "curl");
this.calcFunc.defineVariable$I$S(7, "path");
this.calcFunc.define$S(this.calcStr);
this.calcFunc.parse();
if (this.calcFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse calc-text: " + this.calcStr);
System.out.println$S("Parse error: " + this.calcFunc.getErrorString() + " at function 1, position " + this.calcFunc.getErrorPosition() );
return;
}}, 1);

Clazz.newMeth(C$, 'getText', function () {
var val = 0;
var current = 0;
var bvec = Clazz.array(Double.TYPE, [2]);
var curl = 0;
var path = 0;
var wire;
if (this.calcStr == null  || this.calcFunc == null  ) return this.text;
if (this.getMaster() != null  && Clazz.instanceOf(this.getMaster(), "bfield.Wire") ) {
wire = this.getMaster();
current = wire.getCurrent();
bvec = this.fieldPanel.getB$D$D$bfield_Wire(this.x, this.y, wire);
curl = this.fieldPanel.getCurl$D$D$bfield_Wire(this.x, this.y, wire);
} else if (this.getMaster() != null  && Clazz.instanceOf(this.getMaster(), "bfield.FieldRectangle") ) {
var frect = this.getMaster();
path = frect.doLineIntegral();
bvec = this.fieldPanel.getB$D$D$bfield_Wire(this.x, this.y, null);
} else if (this.getMaster() != null  && Clazz.instanceOf(this.getMaster(), "bfield.FieldCircle") ) {
var fcircle = this.getMaster();
path = fcircle.doLineIntegral();
bvec = this.fieldPanel.getB$D$D$bfield_Wire(this.x, this.y, null);
} else if (this.getMaster() != null  && Clazz.instanceOf(this.getMaster(), "bfield.FieldBox") ) {
var fbox = this.getMaster();
path = fbox.doLineIntegral();
bvec = this.fieldPanel.getB$D$D$bfield_Wire(this.x, this.y, null);
} else if (this.getMaster() != null  && Clazz.instanceOf(this.getMaster(), "bfield.FieldShell") ) {
var fshell = this.getMaster();
path = fshell.doLineIntegral();
bvec = this.fieldPanel.getB$D$D$bfield_Wire(this.x, this.y, null);
} else {
bvec = this.fieldPanel.getB$D$D$bfield_Wire(this.x, this.y, null);
curl = this.fieldPanel.getCurl$D$D$bfield_Wire(this.x, this.y, null);
;}this.tempVars[0] = this.x;
this.tempVars[1] = this.y;
this.tempVars[2] = bvec[0];
this.tempVars[3] = bvec[1];
this.tempVars[4] = current;
this.tempVars[5] = curl;
this.tempVars[6] = path;
try {
val = this.calcFunc.evaluate$DA(this.tempVars);
val = (I$[3]||$incl$(3)).chop$D$D(val, 1.0E-8);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return this.text + " " + this.format.form$D(val) ;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
if (!this.visible) return;
var f = g.getFont();
g.setFont$java_awt_Font(this.font);
var ptX = Math.round(this.canvas.pixFromX$D(this.x)) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.y)) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.drawString$S$I$I(this.getText(), ptX, ptY);
g.setColor$java_awt_Color((I$[4]||$incl$(4)).black);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:36:54
