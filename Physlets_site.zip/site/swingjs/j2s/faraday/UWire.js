(function(){var P$=Clazz.newPackage("faraday"),I$=[['java.awt.Color','java.awt.Font',['faraday.UWire','.Meter']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "UWire", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.display.Thing', 'faraday.Fluxable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.schematic = null;
this.meter = null;
this.area = 0;
this.measurementTime = 0;
this.flux = 0;
this.volt = 0;
this.lastTime = 0;
this.lastFlux = 0;
this.firstDatum = false;
this.secondDatum = false;
this.showCurrentArrow = false;
this.showMeter = false;
this.np = 0;
this.readings = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.meter = null;
this.area = 0;
this.measurementTime = 0;
this.flux = 0;
this.volt = 0;
this.lastTime = 0;
this.lastFlux = 0;
this.firstDatum = true;
this.secondDatum = false;
this.showCurrentArrow = true;
this.showMeter = true;
this.np = 12;
this.readings = Clazz.array(Double.TYPE, [this.np]);
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$faraday_Schematic$D', function (owner, sp, x) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sp, x, 0]);
C$.$init$.apply(this);
this.schematic = sp;
this.meter = Clazz.new_((I$[3]||$incl$(3)), [this, null]);
this.color = Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[64, 64, 64]);
this.w = 3;
this.h = 30;
var x1 = ((this.schematic.iwidth * 0.1)|0) + this.xDisplayOff;
var x2 = this.canvas.pixFromX$D(x) + this.xDisplayOff;
this.area = Math.abs(x2 - x1) * (this.schematic.iheight * 0.8) / this.schematic.pixPerUnit / this.schematic.pixPerUnit;
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "y", "flux", "v"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
this.doFluxIntegral();
}, 1);

Clazz.newMeth(C$, 'setShowCurrentArrow$Z', function (show) {
this.showCurrentArrow = show;
});

Clazz.newMeth(C$, 'setShowMeter$Z', function (show) {
this.showMeter = show;
});

Clazz.newMeth(C$, 'paintCurrentArrow$java_awt_Graphics', function (g) {
if (!this.showCurrentArrow) return;
var yinset = ((this.schematic.iheight * 0.02)|0) - this.yDisplayOff;
if (this.volt == 0 ) return;
var ypix = yinset + 3;
var xpix1 = (this.schematic.iwidth/2|0) - 10;
var xpix2 = (this.schematic.iwidth/2|0) + 30;
g.drawLine$I$I$I$I(xpix1, ypix, xpix2, ypix);
g.drawLine$I$I$I$I(xpix1, ypix + 1, xpix2, ypix + 1);
if (this.volt < 0 ) {
g.drawLine$I$I$I$I(xpix2, ypix, xpix2 - 5, ypix - 5);
g.drawLine$I$I$I$I(xpix2, ypix, xpix2 - 5, ypix + 5);
g.drawLine$I$I$I$I(xpix2, ypix + 1, xpix2 - 5, ypix - 4);
g.drawLine$I$I$I$I(xpix2, ypix + 1, xpix2 - 5, ypix + 6);
} else {
g.drawLine$I$I$I$I(xpix1, ypix, xpix1 + 5, ypix - 5);
g.drawLine$I$I$I$I(xpix1, ypix, xpix1 + 5, ypix + 5);
g.drawLine$I$I$I$I(xpix1, ypix + 1, xpix1 + 5, ypix - 4);
g.drawLine$I$I$I$I(xpix1, ypix + 1, xpix1 + 5, ypix + 6);
}g.setColor$java_awt_Color((I$[1]||$incl$(1)).darkGray);
g.drawString$S$I$I(this.schematic.owner.label_current, (this.schematic.iwidth/2|0) - 10, ypix + 12);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
});

Clazz.newMeth(C$, 'paintWire$java_awt_Graphics', function (g) {
var x1 = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = (this.schematic.iheight/2|0) - this.yDisplayOff;
var y1 = ptY - (this.h/2|0);
var y2 = ptY + (this.h/2|0);
g.setColor$java_awt_Color(this.color);
for (var i = -this.w; i <= this.w; i++) g.drawLine$I$I$I$I(x1 + i, y1, x1 + i, y2);

g.setColor$java_awt_Color(Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[255, 128, 128]));
g.fillOval$I$I$I$I(x1 - this.w, y1 - (this.w/2|0), 2 * this.w, this.w);
g.fillOval$I$I$I$I(x1 - this.w, y2 - (this.w/2|0), 2 * this.w, this.w);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawOval$I$I$I$I(x1 - this.w, y1 - (this.w/2|0), 2 * this.w, this.w);
g.drawOval$I$I$I$I(x1 - this.w, y2 - (this.w/2|0), 2 * this.w, this.w);
});

Clazz.newMeth(C$, 'paintU$java_awt_Graphics', function (g) {
var x1 = ((this.schematic.iwidth * 0.1)|0) + this.xDisplayOff;
var x2 = ((this.schematic.iwidth * 0.9)|0) + this.xDisplayOff;
var ptY = (this.schematic.iheight/2|0) - this.yDisplayOff;
var y1 = ptY - (((this.schematic.iheight * 0.8)|0)/2|0);
;var y2 = ptY + (((this.schematic.iheight * 0.8)|0)/2|0);
;g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
for (var i = -this.w; i <= this.w; i++) g.drawLine$I$I$I$I(x1 + i, y1, x1 + i, y2);

for (var i = -this.w; i <= this.w; i++) {
g.drawLine$I$I$I$I(x1 - this.w, y1 + i, x2, y1 + i);
g.drawLine$I$I$I$I(x1 - this.w, y2 + i, x2, y2 + i);
}
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (!this.visible) return;
this.h = ((this.schematic.iheight * 0.9)|0);
this.paintU$java_awt_Graphics(osg);
this.paintWire$java_awt_Graphics(osg);
if (this.showMeter) this.meter.paint$java_awt_Graphics(osg);
this.paintCurrentArrow$java_awt_Graphics(osg);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < this.w + 1) && (Math.abs(yPix - ptY) < (this.h/2|0) + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$, 'setXY$D$D', function (x, y) {
var xmin = this.canvas.xFromPix$I(((this.schematic.iwidth * 0.1)|0) + this.xDisplayOff);
var xmax = this.canvas.xFromPix$I(((this.schematic.iwidth * 0.9)|0) + this.xDisplayOff);
x = Math.max(x, xmin);
x = Math.min(x, xmax);
C$.superclazz.prototype.setXY$D$D.apply(this, [x, y]);
});

Clazz.newMeth(C$, 'setX$D', function (x) {
if (this.schematic.iwidth != this.schematic.getSize().width) {
C$.superclazz.prototype.setX$D.apply(this, [x]);
return;
}var xmin = this.canvas.xFromPix$I(((this.schematic.iwidth * 0.1 + 2 * this.w)|0) + this.xDisplayOff);
var xmax = this.canvas.xFromPix$I(((this.schematic.iwidth * 0.9)|0) + this.xDisplayOff);
x = Math.max(x, xmin);
x = Math.min(x, xmax);
C$.superclazz.prototype.setX$D.apply(this, [x]);
});

Clazz.newMeth(C$, 'reset', function () {
this.measurementTime = this.schematic.time;
this.lastTime = this.schematic.time;
this.lastFlux = 0;
this.firstDatum = true;
this.volt = 0;
});

Clazz.newMeth(C$, 'getFlux', function () {
return this.flux;
});

Clazz.newMeth(C$, 'getVolt', function () {
return this.volt;
});

Clazz.newMeth(C$, 'average$D', function (v) {
if (this.firstDatum) {
this.lastTime = this.measurementTime;
this.lastFlux = this.flux;
this.firstDatum = false;
this.secondDatum = true;
return 0;
} else if (this.secondDatum) {
for (var i = 0; i < this.np; i++) this.readings[i] = v;

this.secondDatum = false;
return v;
} else {
for (var i = this.np - 1; i > 0; i--) this.readings[i] = this.readings[i - 1];

this.readings[0] = v;
}var avg = 0;
for (var i = 0; i < this.np; i++) {
avg += this.readings[i];
}
return avg / this.np;
});

Clazz.newMeth(C$, 'calcVoltage', function () {
if (this.measurementTime == this.lastTime ) {
this.lastFlux = this.flux;
return;
}var v = -(this.flux - this.lastFlux) / (this.measurementTime - this.lastTime);
this.lastTime = this.measurementTime;
this.lastFlux = this.flux;
this.volt = p$.average$D.apply(this, [v]);
return;
});

Clazz.newMeth(C$, 'doFluxIntegral', function () {
var numPts = Math.max(this.w, 200);
var x1 = ((this.schematic.iwidth * 0.1)|0);
var left = this.schematic.xFromPix$I(x1);
var dx = (this.x - left) / numPts;
var height = this.schematic.iheight * 0.8 / this.schematic.pixPerUnit;
this.flux = 0;
for (var i = 0; i < numPts; i++) {
this.flux += this.schematic.getFieldValue$D(left);
left += dx;
}
if (dx > 0 ) this.flux = this.flux * dx * height ;
 else this.flux = 0;
this.measurementTime = this.schematic.time;
p$.calcVoltage.apply(this, []);
return this.flux;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.measurementTime;
this.ds[0][1] = this.x;
this.ds[0][2] = this.y;
this.ds[0][3] = this.flux;
this.ds[0][4] = this.volt;
return this.ds;
});

Clazz.newMeth(C$, 'getFormat', function () {
return this.format;
});
;
(function(){var C$=Clazz.newClass(P$.UWire, "Meter", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.r = 0;
this.min = 0;
this.max = 0;
this.textOffset = 0;
this.sqrt2 = 0;
this.color = null;
this.bigFont = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.r = 20;
this.min = -200;
this.max = 200;
this.textOffset = 0;
this.sqrt2 = Math.sqrt(2);
this.color = (I$[1]||$incl$(1)).black;
this.bigFont = Clazz.new_((I$[2]||$incl$(2)).c$$S$I$I,["Dialog", 1, 18]);
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
this.min = this.this$0.schematic.metermin;
this.max = this.this$0.schematic.metermax;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
var x1 = ((this.this$0.schematic.iwidth * 0.1)|0);
var y1 = (this.this$0.schematic.iheight/2|0);
var yo = y1 + ((0.8 * this.r)|0);
var i = 0;
g.setColor$java_awt_Color(Clazz.new_((I$[1]||$incl$(1)).c$$I$I$I,[192, 255, 255]));
g.fillOval$I$I$I$I(x1 - this.r, y1 - this.r, 2 * this.r, 2 * this.r);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.drawOval$I$I$I$I(x1 - this.r, y1 - this.r, 2 * this.r, 2 * this.r);
var len = this.r - 1;
g.drawLine$I$I$I$I(x1, yo, x1 - len, yo - len);
g.drawLine$I$I$I$I(x1, yo, x1 + len, yo - len);
len = ((len * this.sqrt2 - 4)|0);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
var theta;
if (this.this$0.volt < this.min ) theta = -0.7853981633974483;
 else if (this.this$0.volt > this.max ) theta = 0.7853981633974483;
 else theta = -0.7853981633974483 + 1.5707963267948966 * (this.this$0.volt - this.min) / (this.max - this.min);
g.drawLine$I$I$I$I(x1, yo, x1 + ((len * Math.sin(theta))|0), yo - ((len * Math.cos(theta))|0));
g.drawLine$I$I$I$I(x1 - 1, yo, x1 + ((len * Math.sin(theta))|0) - 1, yo - ((len * Math.cos(theta))|0));
var format = this.this$0.getFormat();
var msg = "" + format.form$D(this.this$0.volt);
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
var w = (fm.stringWidth$S(msg)/2|0) + 5;
g.setColor$java_awt_Color((I$[1]||$incl$(1)).yellow);
g.fillRect$I$I$I$I(x1 - w + this.textOffset, yo + 12, 2 * w, 20);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
w = w-(5);
g.drawString$S$I$I(msg, x1 - w + this.textOffset, yo + 25);
var font = g.getFont();
g.setFont$java_awt_Font(this.bigFont);
g.drawString$S$I$I("+", x1 - 15, y1 - this.r);
g.setFont$java_awt_Font(font);
});
})()

Clazz.newMeth(C$);
})();
//Created 2018-02-22 01:07:09
