(function(){var P$=Clazz.newPackage("blackbody"),I$=[];
var C$=Clazz.newClass(P$, "BlackBody_slider_mouseAdapter", null, 'java.awt.event.MouseAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.adaptee = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$blackbody_BlackBody', function (adaptee) {
Clazz.super_(C$, this,1);
this.adaptee = adaptee;
}, 1);

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
this.adaptee.slider_mouseReleased$java_awt_event_MouseEvent(e);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-08 01:51:35
