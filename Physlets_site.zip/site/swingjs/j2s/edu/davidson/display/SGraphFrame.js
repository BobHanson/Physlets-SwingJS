(function(){var P$=Clazz.newPackage("edu.davidson.display"),p$1={},I$=[[0,'java.awt.BorderLayout','edu.davidson.display.SGraph','java.awt.event.WindowAdapter']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "SGraphFrame", null, 'java.awt.Frame');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.borderLayout1=null;
this.graph=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.borderLayout1=Clazz.new_($I$(1));
this.graph=null;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.graph=Clazz.new_($I$(2));
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.setSize$I$I(400, 300);
this.setLocation$I$I(((300 * Math.random())|0), ((300 * Math.random())|0));
this.setTitle$S(this.getClass$().getName$());
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_display_SGraph', function (g) {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
this.graph=g;
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.add$java_awt_Component$O(this.graph, "Center");
this.setSize$I$I(300, 200);
this.setLocation$I$I(((300 * Math.random())|0), ((300 * Math.random())|0));
this.setTitle$S(this.getClass$().getName$());
}, 1);

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.graph.setSampleData$Z(false);
this.addWindowListener$java_awt_event_WindowListener(((P$.SGraphFrame$1||
(function(){var C$=Clazz.newClass(P$, "SGraphFrame$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.event.WindowAdapter'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'windowOpened$java_awt_event_WindowEvent', function (e) {
this.b$['edu.davidson.display.SGraphFrame'].this_windowOpened$java_awt_event_WindowEvent.apply(this.b$['edu.davidson.display.SGraphFrame'], [e]);
});

Clazz.newMeth(C$, 'windowClosing$java_awt_event_WindowEvent', function (e) {
this.b$['edu.davidson.display.SGraphFrame'].this_windowClosing$java_awt_event_WindowEvent.apply(this.b$['edu.davidson.display.SGraphFrame'], [e]);
});

Clazz.newMeth(C$, 'windowActivated$java_awt_event_WindowEvent', function (e) {
this.b$['edu.davidson.display.SGraphFrame'].this_windowActivated$java_awt_event_WindowEvent.apply(this.b$['edu.davidson.display.SGraphFrame'], [e]);
});

Clazz.newMeth(C$, 'windowDeiconified$java_awt_event_WindowEvent', function (e) {
this.b$['edu.davidson.display.SGraphFrame'].this_windowDeiconified$java_awt_event_WindowEvent.apply(this.b$['edu.davidson.display.SGraphFrame'], [e]);
});
})()
), Clazz.new_($I$(3), [this, null],P$.SGraphFrame$1)));
this.add$java_awt_Component$O(this.graph, "Center");
}, p$1);

Clazz.newMeth(C$, 'this_windowOpened$java_awt_event_WindowEvent', function (e) {
if (this.graph != null ) this.graph.startPaintThread$();
});

Clazz.newMeth(C$, 'this_windowClosing$java_awt_event_WindowEvent', function (e) {
if (this.graph != null ) this.graph.destroy$();
this.setVisible$Z(false);
});

Clazz.newMeth(C$, 'this_windowActivated$java_awt_event_WindowEvent', function (e) {
if (this.graph != null ) this.graph.startPaintThread$();
});

Clazz.newMeth(C$, 'this_windowDeiconified$java_awt_event_WindowEvent', function (e) {
if (this.graph != null ) this.graph.startPaintThread$();
});
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:02:03 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
