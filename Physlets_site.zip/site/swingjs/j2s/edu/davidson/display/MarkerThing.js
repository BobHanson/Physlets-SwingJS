(function(){var P$=Clazz.newPackage("edu.davidson.display"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "MarkerThing", null, 'edu.davidson.display.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.longCross = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.longCross = false;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$I$D$D', function (owner, sc, diameter, x, y) {
C$.superclazz.c$$edu_davidson_display_SScalable$D$D.apply(this, [sc, x, y]);
C$.$init$.apply(this);
this.s = 1;
this.w = diameter;
this.h = diameter;
this.noDrag = false;
this.applet = owner;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.drawOval$I$I$I$I(ptX - (this.w/2|0), ptY - (this.h/2|0), this.w, this.h);
if (this.longCross) {
g.drawLine$I$I$I$I(0, ptY, ptX - 1, ptY);
g.drawLine$I$I$I$I(ptX + 1, ptY, this.canvas.getPixWidth(), ptY);
g.drawLine$I$I$I$I(ptX, 0, ptX, ptY - 1);
g.drawLine$I$I$I$I(ptX, ptY + 1, ptX, this.canvas.getPixHeight());
} else {
g.drawLine$I$I$I$I(ptX - (this.w/2|0), ptY, ptX - 1, ptY);
g.drawLine$I$I$I$I(ptX + 1, ptY, ptX + (this.w/2|0), ptY);
g.drawLine$I$I$I$I(ptX, ptY - (this.h/2|0), ptX, ptY - 1);
g.drawLine$I$I$I$I(ptX, ptY + 1, ptX, ptY + (this.h/2|0));
}});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (g) {
if (!this.visible) return;
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
if (this.color === (I$[1]||$incl$(1)).red ) g.setColor$java_awt_Color((I$[1]||$incl$(1)).blue);
 else g.setColor$java_awt_Color((I$[1]||$incl$(1)).red);
g.drawOval$I$I$I$I(ptX - (this.w/2|0), ptY - (this.h/2|0), this.w, this.h);
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX = this.canvas.pixFromX$D(this.x) + this.xDisplayOff;
var ptY = this.canvas.pixFromY$D(this.y) - this.yDisplayOff;
if ((Math.abs(xPix - ptX) < (this.w/2|0) + 1) && (Math.abs(yPix - ptY) < (this.h/2|0) + 1) ) return true;
 else return false;
});

Clazz.newMeth(C$);
})();
//Created 2018-03-16 05:19:10
