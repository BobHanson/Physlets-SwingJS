(function(){var P$=Clazz.newPackage("animator4"),I$=[['edu.davidson.tools.SUtil','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "CalcThing", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.chopValue = 0;
this.calcW = 0;
this.calcH = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.chopValue = 1.0E-12;
this.calcW = 0.0;
this.calcH = 0.0;
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$S$S$S', function (o, txt, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.label = txt;
}, 1);

Clazz.newMeth(C$, 'setChop$D', function (value) {
this.chopValue = value;
});

Clazz.newMeth(C$, 'getH', function () {
return this.calcH;
});

Clazz.newMeth(C$, 'setH$D', function (h) {
this.calcH = h;
});

Clazz.newMeth(C$, 'getW', function () {
return this.calcW;
});

Clazz.newMeth(C$, 'setW$D', function (w) {
this.calcW = w;
});

Clazz.newMeth(C$, 'getText', function () {
var val = 0;
try {
val = (I$[1]||$incl$(1)).chop$D$D(this.calcW, this.chopValue);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
} else {
throw e;
}
}
return this.label + " " + this.format.form$D(val) ;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
var f = g.getFont();
g.setFont$java_awt_Font(this.font);
var ptX = Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.drawString$S$I$I(this.getText(), ptX, ptY);
g.setColor$java_awt_Color((I$[2]||$incl$(2)).black);
g.setFont$java_awt_Font(f);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:13
