(function(){var P$=Clazz.newPackage("eField4"),I$=[];
var C$=Clazz.newClass(P$, "SpringAnchor", null, 'eField4.LineAnchor');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$eField4_Thing', function (p, x, y, t) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$eField4_Thing.apply(this, [p, x, y, t]);
C$.$init$.apply(this);
this.s = 2;
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (this.hideThing) return;
var x;
var y;
var ptX1 = this.p.pixFromX$D(this.vars[1]);
var ptY1 = this.p.pixFromY$D(this.vars[2]);
var ptX2 = this.p.pixFromX$D(this.thing.vars[1]);
var ptY2 = this.p.pixFromY$D(this.thing.vars[2]);
x = ptX2 - ptX1;
y = -ptY2 + ptY1;
osg.setColor$java_awt_Color(this.color);
var h = Math.sqrt(x * x + y * y);
if (h > 1 ) {
var u = (x / 16.0 / this.s );
var v = -(y / 16.0 / this.s );
var u0 = 8 * x / h;
var v0 = -8 * y / h;
var x1 = ptX1;
var y1 = ptY1;
var x2 = x1 + u;
var y2 = y1 + v;
var x3 = x1 + 2 * u;
var y3 = y1 + 2 * v;
for (var count = 0; count < 4 * this.s; count++) {
x2 = x2 - v0;
y2 = y2 + u0;
osg.drawLine$I$I$I$I(((x1)|0), ((y1)|0), ((x2)|0), ((y2)|0));
osg.drawLine$I$I$I$I(((x2)|0), ((y2)|0), ((x3)|0), ((y3)|0));
x1 = x3;
y1 = y3;
x2 = x1 + u;
y2 = y1 + v;
x3 = x1 + 2 * u;
y3 = y1 + 2 * v;
x2 = x2 + v0;
y2 = y2 - u0;
osg.drawLine$I$I$I$I(((x1)|0), ((y1)|0), ((x2)|0), ((y2)|0));
osg.drawLine$I$I$I$I(((x2)|0), ((y2)|0), ((x3)|0), ((y3)|0));
x1 = x3;
y1 = y3;
x2 = x1 + u;
y2 = y1 + v;
x3 = x1 + 2 * u;
y3 = y1 + 2 * v;
}
}});

Clazz.newMeth(C$);
})();
//Created 2018-02-06 13:05:45
