(function(){var P$=Clazz.newPackage("edu.davidson.graphics"),I$=[];
var C$=Clazz.newClass(P$, "Assert");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'notFalse$Z', function (b) {
if (b == false ) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["boolean expression false"]);
}, 1);

Clazz.newMeth(C$, 'isTrue$Z', function (b) {
C$.notFalse$Z(b);
}, 1);

Clazz.newMeth(C$, 'isFalse$Z', function (b) {
if (b != false ) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["boolean expression true"]);
}, 1);

Clazz.newMeth(C$, 'notNull$O', function (obj) {
if (obj == null ) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,["null argument"]);
}, 1);

Clazz.newMeth(C$, 'notFalse$Z$S', function (b, s) {
if (b == false ) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,[s]);
}, 1);

Clazz.newMeth(C$, 'isTrue$Z$S', function (b, msg) {
C$.notFalse$Z$S(b, msg);
}, 1);

Clazz.newMeth(C$, 'isFalse$Z$S', function (b, s) {
if (b != false ) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,[s]);
}, 1);

Clazz.newMeth(C$, 'notNull$O$S', function (obj, s) {
if (obj == null ) throw Clazz.new_(Clazz.load('java.lang.IllegalArgumentException').c$$S,[s]);
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:12
