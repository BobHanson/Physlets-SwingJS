(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'java.awt.Button','symantec.itools.awt.util.spinner.NumericSpinner','java.awt.Label','java.awt.TextField','symantec.itools.awt.BorderPanel','circuitsimulator.Wire','circuitsimulator.Resistor','circuitsimulator.Capacitor','circuitsimulator.Inductor','circuitsimulator.Switch','circuitsimulator.Bulb','circuitsimulator.TransformerCoil','circuitsimulator.Diode','circuitsimulator.Source','circuitsimulator.Battery','circuitsimulator.CurrentSource','circuitsimulator.SinWave','circuitsimulator.SquareWave','circuitsimulator.Vmeter','circuitsimulator.Ameter','circuitsimulator.Scope','java.awt.Color','java.awt.Font',['circuitsimulator.BuilderPanel','.SymAction'],['circuitsimulator.BuilderPanel','.SymMouse'],['circuitsimulator.BuilderPanel','.SymText'],'circuitsimulator.ValueInput','circuitsimulator.ListOutput','circuitsimulator.Circuit','java.awt.Point']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "BuilderPanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'symantec.itools.awt.BorderPanel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.circuitBuilder=null;
this.selectedComponent=null;
this.setGridButton=null;
this.rowSpin=null;
this.colSpin=null;
this.label1=null;
this.label3=null;
this.listButton=null;
this.calculateButton=null;
this.numberInput=null;
this.dtInput=null;
this.label9=null;
this.label10=null;
this.arrows=null;
this.loadButton=null;
this.inputfile=null;
this.forwarding=null;
this.resetting=null;
this.resistorBorder=null;
this.capacitorBorder=null;
this.inductorBorder=null;
this.wireBorder=null;
this.sourceBorder=null;
this.scopeBorder=null;
this.vmeterBorder=null;
this.ameterBorder=null;
this.switchBorder=null;
this.batteryBorder=null;
this.bulbBorder=null;
this.currentsourceBorder=null;
this.transformerBorder=null;
this.sinwaveBorder=null;
this.squarewaveBorder=null;
this.diodeBorder=null;
this.coordStr=null;
this.wire=null;
this.resistor=null;
this.capacitor=null;
this.inductor=null;
this.switch1=null;
this.bulb=null;
this.transformercoil=null;
this.diode=null;
this.source=null;
this.battery=null;
this.currentsource=null;
this.sinwave=null;
this.squarewave=null;
this.vmeter=null;
this.ameter=null;
this.scope=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.circuitBuilder=null;
this.selectedComponent="";
this.setGridButton=Clazz.new_(Clazz.load('java.awt.Button'));
this.rowSpin=Clazz.new_(Clazz.load('symantec.itools.awt.util.spinner.NumericSpinner'));
this.colSpin=Clazz.new_($I$(2));
this.label1=Clazz.new_(Clazz.load('java.awt.Label'));
this.label3=Clazz.new_($I$(3));
this.listButton=Clazz.new_($I$(1));
this.calculateButton=Clazz.new_($I$(1));
this.numberInput=Clazz.new_(Clazz.load('java.awt.TextField'));
this.dtInput=Clazz.new_($I$(4));
this.label9=Clazz.new_($I$(3));
this.label10=Clazz.new_($I$(3));
this.arrows=Clazz.new_($I$(1));
this.loadButton=Clazz.new_($I$(1));
this.inputfile=Clazz.new_($I$(4));
this.forwarding=Clazz.new_($I$(1));
this.resetting=Clazz.new_($I$(1));
this.resistorBorder=Clazz.new_(Clazz.load('symantec.itools.awt.BorderPanel'));
this.capacitorBorder=Clazz.new_($I$(5));
this.inductorBorder=Clazz.new_($I$(5));
this.wireBorder=Clazz.new_($I$(5));
this.sourceBorder=Clazz.new_($I$(5));
this.scopeBorder=Clazz.new_($I$(5));
this.vmeterBorder=Clazz.new_($I$(5));
this.ameterBorder=Clazz.new_($I$(5));
this.switchBorder=Clazz.new_($I$(5));
this.batteryBorder=Clazz.new_($I$(5));
this.bulbBorder=Clazz.new_($I$(5));
this.currentsourceBorder=Clazz.new_($I$(5));
this.transformerBorder=Clazz.new_($I$(5));
this.sinwaveBorder=Clazz.new_($I$(5));
this.squarewaveBorder=Clazz.new_($I$(5));
this.diodeBorder=Clazz.new_($I$(5));
this.wire=Clazz.new_(Clazz.load('circuitsimulator.Wire'));
this.resistor=Clazz.new_(Clazz.load('circuitsimulator.Resistor'));
this.capacitor=Clazz.new_(Clazz.load('circuitsimulator.Capacitor'));
this.inductor=Clazz.new_(Clazz.load('circuitsimulator.Inductor'));
this.switch1=Clazz.new_(Clazz.load('circuitsimulator.Switch'));
this.bulb=Clazz.new_(Clazz.load('circuitsimulator.Bulb'));
this.transformercoil=Clazz.new_(Clazz.load('circuitsimulator.TransformerCoil'));
this.diode=Clazz.new_(Clazz.load('circuitsimulator.Diode'));
this.source=Clazz.new_(Clazz.load('circuitsimulator.Source'));
this.battery=Clazz.new_(Clazz.load('circuitsimulator.Battery'));
this.currentsource=Clazz.new_(Clazz.load('circuitsimulator.CurrentSource'));
this.sinwave=Clazz.new_(Clazz.load('circuitsimulator.SinWave'));
this.squarewave=Clazz.new_(Clazz.load('circuitsimulator.SquareWave'));
this.vmeter=Clazz.new_(Clazz.load('circuitsimulator.Vmeter'));
this.ameter=Clazz.new_(Clazz.load('circuitsimulator.Ameter'));
this.scope=Clazz.new_(Clazz.load('circuitsimulator.Scope'));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
try {
this.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.setBevelStyle$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.setLayout$java_awt_LayoutManager(null);
this.setBackground$java_awt_Color(Clazz.new_(Clazz.load('java.awt.Color').c$$I$I$I,[0, 143, 213]));
this.setSize$I$I(195, 401);
this.setGridButton.setLabel$S("Set grid");
this.add$java_awt_Component(this.setGridButton);
this.setGridButton.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.setGridButton.setBounds$I$I$I$I(5, 32, 59, 48);
try {
this.rowSpin.setMin$I(2);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.rowSpin.setCurrent$I(2);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.rowSpin.setMax$I(8);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.add$java_awt_Component(this.rowSpin);
this.rowSpin.setBackground$java_awt_Color($I$(22).yellow);
this.rowSpin.setForeground$java_awt_Color($I$(22).black);
this.rowSpin.setBounds$I$I$I$I(64, 32, 28, 24);
try {
this.colSpin.setMin$I(2);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.colSpin.setCurrent$I(2);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.colSpin.setMax$I(5);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.add$java_awt_Component(this.colSpin);
this.colSpin.setBackground$java_awt_Color($I$(22).yellow);
this.colSpin.setBounds$I$I$I$I(64, 56, 28, 24);
this.label1.setText$S("rows");
this.add$java_awt_Component(this.label1);
this.label1.setFont$java_awt_Font(Clazz.new_(Clazz.load('java.awt.Font').c$$S$I$I,["Dialog", 0, 10]));
this.label1.setBounds$I$I$I$I(93, 32, 44, 24);
this.label3.setText$S("cols");
this.add$java_awt_Component(this.label3);
this.label3.setFont$java_awt_Font(Clazz.new_($I$(23).c$$S$I$I,["Dialog", 0, 10]));
this.label3.setBounds$I$I$I$I(93, 56, 44, 22);
try {
this.resistorBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.resistorBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.resistorBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.resistorBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.resistorBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.resistorBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.resistorBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.resistorBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.resistorBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.resistorBorder);
this.resistorBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.resistorBorder.setBounds$I$I$I$I(5, 99, 56, 28);
try {
this.capacitorBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.capacitorBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.capacitorBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.capacitorBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.capacitorBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.capacitorBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.capacitorBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.capacitorBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.capacitorBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.capacitorBorder);
this.capacitorBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.capacitorBorder.setBounds$I$I$I$I(5, 127, 56, 28);
try {
this.inductorBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.inductorBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.inductorBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.inductorBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.inductorBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.inductorBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.inductorBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.inductorBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.inductorBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.inductorBorder);
this.inductorBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.inductorBorder.setBounds$I$I$I$I(5, 155, 56, 28);
try {
this.wireBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.wireBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.wireBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.wireBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.wireBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.wireBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.wireBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.wireBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.wireBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.wireBorder);
this.wireBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.wireBorder.setBounds$I$I$I$I(69, 127, 56, 28);
try {
this.sourceBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sourceBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sourceBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sourceBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sourceBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sourceBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sourceBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sourceBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.sourceBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.sourceBorder);
this.sourceBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.sourceBorder.setBounds$I$I$I$I(5, 226, 56, 28);
this.listButton.setLabel$S("List");
this.add$java_awt_Component(this.listButton);
this.listButton.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.listButton.setBounds$I$I$I$I(138, 32, 51, 23);
this.calculateButton.setLabel$S("Calculate");
this.add$java_awt_Component(this.calculateButton);
this.calculateButton.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.calculateButton.setBounds$I$I$I$I(6, 372, 67, 24);
try {
this.scopeBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.scopeBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.scopeBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.scopeBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.scopeBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.scopeBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.scopeBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.scopeBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.scopeBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.scopeBorder);
this.scopeBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.scopeBorder.setBounds$I$I$I$I(133, 226, 56, 28);
try {
this.vmeterBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.vmeterBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.vmeterBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.vmeterBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.vmeterBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.vmeterBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.vmeterBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.vmeterBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.vmeterBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.vmeterBorder);
this.vmeterBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.vmeterBorder.setBounds$I$I$I$I(133, 254, 56, 28);
try {
this.ameterBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.ameterBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.ameterBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.ameterBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.ameterBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.ameterBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.ameterBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.ameterBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.ameterBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.ameterBorder);
this.ameterBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.ameterBorder.setBounds$I$I$I$I(133, 282, 56, 28);
try {
this.switchBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.switchBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.switchBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.switchBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.switchBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.switchBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.switchBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.switchBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.switchBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.switchBorder);
this.switchBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.switchBorder.setBounds$I$I$I$I(69, 155, 56, 28);
try {
this.batteryBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.batteryBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.batteryBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.batteryBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.batteryBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.batteryBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.batteryBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.batteryBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.batteryBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.batteryBorder);
this.batteryBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.batteryBorder.setBounds$I$I$I$I(5, 254, 56, 28);
this.numberInput.setText$S("1e3");
this.add$java_awt_Component(this.numberInput);
this.numberInput.setBackground$java_awt_Color($I$(22).white);
this.numberInput.setFont$java_awt_Font(Clazz.new_($I$(23).c$$S$I$I,["Dialog", 0, 10]));
this.numberInput.setBounds$I$I$I$I(141, 346, 47, 20);
this.dtInput.setText$S("1e-6");
this.add$java_awt_Component(this.dtInput);
this.dtInput.setBackground$java_awt_Color($I$(22).white);
this.dtInput.setFont$java_awt_Font(Clazz.new_($I$(23).c$$S$I$I,["Dialog", 0, 10]));
this.dtInput.setBounds$I$I$I$I(40, 347, 72, 19);
this.label9.setText$S("#:");
this.add$java_awt_Component(this.label9);
this.label9.setBounds$I$I$I$I(126, 343, 16, 23);
this.label10.setText$S("dt (s):");
this.add$java_awt_Component(this.label10);
this.label10.setBounds$I$I$I$I(5, 344, 34, 24);
this.arrows.setLabel$S("Show ->");
this.add$java_awt_Component(this.arrows);
this.arrows.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.arrows.setBounds$I$I$I$I(139, 58, 50, 23);
this.loadButton.setLabel$S("Load");
this.add$java_awt_Component(this.loadButton);
this.loadButton.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.loadButton.setBounds$I$I$I$I(6, 5, 52, 25);
this.inputfile.setText$S("lists/default.txt");
this.add$java_awt_Component(this.inputfile);
this.inputfile.setBackground$java_awt_Color($I$(22).white);
this.inputfile.setBounds$I$I$I$I(59, 5, 129, 24);
try {
this.bulbBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.bulbBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.bulbBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.bulbBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.bulbBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.bulbBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.bulbBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.bulbBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.bulbBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.bulbBorder);
this.bulbBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.bulbBorder.setBounds$I$I$I$I(69, 99, 56, 28);
this.forwarding.setLabel$S("Start");
this.add$java_awt_Component(this.forwarding);
this.forwarding.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.forwarding.setBounds$I$I$I$I(75, 371, 56, 25);
this.resetting.setLabel$S("Reset");
this.add$java_awt_Component(this.resetting);
this.resetting.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.resetting.setBounds$I$I$I$I(132, 371, 58, 25);
try {
this.currentsourceBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.currentsourceBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.currentsourceBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.currentsourceBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.currentsourceBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.currentsourceBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.currentsourceBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.currentsourceBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.currentsourceBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.currentsourceBorder);
this.currentsourceBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.currentsourceBorder.setBounds$I$I$I$I(5, 282, 56, 28);
try {
this.transformerBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.transformerBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.transformerBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.transformerBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.transformerBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.transformerBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.transformerBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.transformerBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.transformerBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.transformerBorder);
this.transformerBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.transformerBorder.setBounds$I$I$I$I(134, 99, 56, 42);
try {
this.sinwaveBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sinwaveBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sinwaveBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sinwaveBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sinwaveBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sinwaveBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sinwaveBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.sinwaveBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.sinwaveBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.sinwaveBorder);
this.sinwaveBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.sinwaveBorder.setBounds$I$I$I$I(69, 226, 56, 28);
try {
this.squarewaveBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.squarewaveBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.squarewaveBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.squarewaveBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.squarewaveBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.squarewaveBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.squarewaveBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.squarewaveBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.squarewaveBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.squarewaveBorder);
this.squarewaveBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.squarewaveBorder.setBounds$I$I$I$I(69, 254, 56, 28);
try {
this.diodeBorder.setPaddingRight$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.diodeBorder.setBevelStyle$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.diodeBorder.setPaddingLeft$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.diodeBorder.setIPadBottom$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.diodeBorder.setPaddingBottom$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.diodeBorder.setPaddingTop$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.diodeBorder.setIPadSides$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.diodeBorder.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.diodeBorder.setLayout$java_awt_LayoutManager(null);
this.add$java_awt_Component(this.diodeBorder);
this.diodeBorder.setBackground$java_awt_Color(Clazz.new_($I$(22).c$$I$I$I,[0, 169, 251]));
this.diodeBorder.setBounds$I$I$I$I(5, 191, 56, 28);
this.wireBorder.add$java_awt_Component(this.wire);
this.resistorBorder.add$java_awt_Component(this.resistor);
this.inductorBorder.add$java_awt_Component(this.inductor);
this.capacitorBorder.add$java_awt_Component(this.capacitor);
this.switchBorder.add$java_awt_Component(this.switch1);
this.bulbBorder.add$java_awt_Component(this.bulb);
this.transformerBorder.add$java_awt_Component(this.transformercoil);
this.diodeBorder.add$java_awt_Component(this.diode);
this.sourceBorder.add$java_awt_Component(this.source);
this.batteryBorder.add$java_awt_Component(this.battery);
this.currentsourceBorder.add$java_awt_Component(this.currentsource);
this.sinwaveBorder.add$java_awt_Component(this.sinwave);
this.squarewaveBorder.add$java_awt_Component(this.squarewave);
this.scopeBorder.add$java_awt_Component(this.scope);
this.vmeterBorder.add$java_awt_Component(this.vmeter);
this.ameterBorder.add$java_awt_Component(this.ameter);
var lSymAction=Clazz.new_(Clazz.load(['circuitsimulator.BuilderPanel','.SymAction']), [this, null]);
this.setGridButton.addActionListener$java_awt_event_ActionListener(lSymAction);
var aSymMouse=Clazz.new_(Clazz.load(['circuitsimulator.BuilderPanel','.SymMouse']), [this, null]);
this.listButton.addActionListener$java_awt_event_ActionListener(lSymAction);
this.calculateButton.addActionListener$java_awt_event_ActionListener(lSymAction);
var lSymText=Clazz.new_(Clazz.load(['circuitsimulator.BuilderPanel','.SymText']), [this, null]);
this.numberInput.addTextListener$java_awt_event_TextListener(lSymText);
this.dtInput.addTextListener$java_awt_event_TextListener(lSymText);
this.arrows.addActionListener$java_awt_event_ActionListener(lSymAction);
this.loadButton.addActionListener$java_awt_event_ActionListener(lSymAction);
this.inputfile.addActionListener$java_awt_event_ActionListener(lSymAction);
this.forwarding.addActionListener$java_awt_event_ActionListener(lSymAction);
this.resetting.addActionListener$java_awt_event_ActionListener(lSymAction);
this.resistor.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.wire.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.capacitor.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.inductor.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.switch1.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.bulb.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.transformercoil.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.diode.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.source.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.battery.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.currentsource.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.sinwave.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.squarewave.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.scope.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.vmeter.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.ameter.addMouseListener$java_awt_event_MouseListener(aSymMouse);
}, 1);

Clazz.newMeth(C$, 'setcircuitBuilder$circuitsimulator_CircuitBuilder', function (cb) {
this.circuitBuilder=cb;
this.label1.setText$S(cb.cirProp.getProperty$S("rows"));
this.label3.setText$S(cb.cirProp.getProperty$S("cols"));
this.loadButton.setLabel$S(cb.cirProp.getProperty$S("Load"));
this.setGridButton.setLabel$S(cb.cirProp.getProperty$S("setgrid"));
this.listButton.setLabel$S(cb.cirProp.getProperty$S("List"));
this.arrows.setLabel$S(cb.cirProp.getProperty$S("arrows"));
this.calculateButton.setLabel$S(cb.cirProp.getProperty$S("Calculate"));
this.forwarding.setLabel$S(cb.cirProp.getProperty$S("Start"));
this.resetting.setLabel$S(cb.cirProp.getProperty$S("Reset"));
this.dtInput.setText$S(Double.toString$D(this.circuitBuilder.dt));
this.numberInput.setText$S(Integer.toString$I(this.circuitBuilder.numberofdt));
});

Clazz.newMeth(C$, 'loadImages$', function () {
this.resistor.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.wire.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.capacitor.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.inductor.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.switch1.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.bulb.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.transformercoil.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.diode.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.source.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.battery.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.currentsource.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.sinwave.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.squarewave.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.scope.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.vmeter.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
this.ameter.setCircuit$circuitsimulator_Circuit(this.circuitBuilder);
});

Clazz.newMeth(C$, 'setGridButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var r=this.rowSpin.getCurrent$();
var c=this.colSpin.getCurrent$();
this.circuitBuilder.setGrid$I$I(r, c);
});

Clazz.newMeth(C$, 'resetButtons$', function () {
try {
this.resistorBorder.setBevelStyle$I(1);
this.capacitorBorder.setBevelStyle$I(1);
this.inductorBorder.setBevelStyle$I(1);
this.wireBorder.setBevelStyle$I(1);
this.switchBorder.setBevelStyle$I(1);
this.bulbBorder.setBevelStyle$I(1);
this.transformerBorder.setBevelStyle$I(1);
this.diodeBorder.setBevelStyle$I(1);
this.sourceBorder.setBevelStyle$I(1);
this.batteryBorder.setBevelStyle$I(1);
this.currentsourceBorder.setBevelStyle$I(1);
this.sinwaveBorder.setBevelStyle$I(1);
this.squarewaveBorder.setBevelStyle$I(1);
this.scopeBorder.setBevelStyle$I(1);
this.vmeterBorder.setBevelStyle$I(1);
this.ameterBorder.setBevelStyle$I(1);
this.dtInput.setText$S(Double.toString$D(this.circuitBuilder.dt));
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'changeProperties$', function () {
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

var title="" + this.circuitBuilder.cirProp.getProperty$S("changevalue_title");
var valueInput=Clazz.new_(Clazz.load('circuitsimulator.ValueInput').c$$S$circuitsimulator_CircuitBuilder$java_awt_Frame,[title, this.circuitBuilder, anchorpoint]);
});

Clazz.newMeth(C$, 'listButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var s=this.circuitBuilder.cirgrid.getcomponentList$();
var title=this.circuitBuilder.cirProp.getProperty$S("circuitlist");
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

var listOutput=Clazz.new_(Clazz.load('circuitsimulator.ListOutput').c$$S$S$java_awt_Frame$circuitsimulator_CircuitBuilder,[title, s, anchorpoint, this.circuitBuilder]);
});

Clazz.newMeth(C$, 'parseButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.circuitBuilder.parse$();
this.circuitBuilder.repaintMeters$();
});

Clazz.newMeth(C$, 'calculateButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.circuitBuilder.repaintMeters$();
if ((this.circuitBuilder.debugLevel & Clazz.load('circuitsimulator.Circuit').DEBUG_IO) > 0) System.out.println$S("Next period calculated");
});

Clazz.newMeth(C$, 'arrows_ActionPerformed$java_awt_event_ActionEvent', function (event) {
if (this.circuitBuilder.showCurrent) this.circuitBuilder.setShowCurrent$I(0);
 else this.circuitBuilder.setShowCurrent$I(1);
this.circuitBuilder.circanvas.redraw$();
});

Clazz.newMeth(C$, 'absoluteP$java_awt_Point$java_awt_Component', function (relativeP, anchor) {
var returnP=Clazz.new_(Clazz.load('java.awt.Point').c$$java_awt_Point,[relativeP]);
var p1;
var anchorpoint=anchor;
while (anchorpoint !== this ){
p1=(anchorpoint).getLocation$();
returnP.setLocation$I$I(returnP.x + p1.x, returnP.y + p1.y);
anchorpoint=(anchorpoint).getParent$();
}
returnP.setLocation$I$I(returnP.x + this.getLocation$().x, returnP.y + this.getLocation$().y);
if ((this.circuitBuilder.debugLevel & $I$(29).DEBUG_IO) > 0) System.out.println$S("coords : " + returnP.toString());
return returnP;
});

Clazz.newMeth(C$, 'updateTextFields$', function () {
this.dtInput.setText$S(Double.toString$D(this.circuitBuilder.dt));
this.numberInput.setText$S(Integer.toString$I(this.circuitBuilder.numberofdt));
});

Clazz.newMeth(C$, 'numberInput_TextValueChanged$java_awt_event_TextEvent', function (event) {
this.circuitBuilder.setNumberOfDT$I(Integer.parseInt$S(this.numberInput.getText$()));
this.circuitBuilder.repaintMeters$();
});

Clazz.newMeth(C$, 'dtInput_TextValueChanged$java_awt_event_TextEvent', function (event) {
this.circuitBuilder.setDT$D((Double.valueOf$S(this.dtInput.getText$())).doubleValue$());
this.circuitBuilder.setFPS$D(1.0 / (this.circuitBuilder.noc * this.circuitBuilder.dt));
this.circuitBuilder.repaintMeters$();
});

Clazz.newMeth(C$, 'loadButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.circuitBuilder.reset$();
this.forwarding.setLabel$S(this.circuitBuilder.cirProp.getProperty$S("Start"));
this.circuitBuilder.loadList$S(this.inputfile.getText$());
this.updateTextFields$();
this.circuitBuilder.parse$();
this.circuitBuilder.calculateCircuit$();
});

Clazz.newMeth(C$, 'forwarding_ActionPerformed$java_awt_event_ActionEvent', function (event) {
if (this.forwarding.getLabel$().equals$O(this.circuitBuilder.cirProp.getProperty$S("Start"))) {
this.circuitBuilder.forward$();
this.forwarding.setLabel$S(this.circuitBuilder.cirProp.getProperty$S("Pause"));
} else {
this.circuitBuilder.pause$();
this.forwarding.setLabel$S(this.circuitBuilder.cirProp.getProperty$S("Start"));
}});

Clazz.newMeth(C$, 'resetting_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.circuitBuilder.pause$();
this.circuitBuilder.reset$();
this.forwarding.setLabel$S(this.circuitBuilder.cirProp.getProperty$S("Start"));
});
;
(function(){var C$=Clazz.newClass(P$.BuilderPanel, "SymAction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (event) {
var object=event.getSource$();
if (object === this.this$0.setGridButton ) this.this$0.setGridButton_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.listButton ) this.this$0.listButton_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.calculateButton ) this.this$0.calculateButton_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.arrows ) this.this$0.arrows_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.loadButton ) this.this$0.loadButton_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.forwarding ) this.this$0.forwarding_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.resetting ) this.this$0.resetting_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.BuilderPanel, "SymMouse", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.MouseAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
try {
if (object === this.this$0.resistor ) this.this$0.resistorBorder.setBevelStyle$I(0);
 else if (object === this.this$0.capacitor ) this.this$0.capacitorBorder.setBevelStyle$I(0);
 else if (object === this.this$0.inductor ) this.this$0.inductorBorder.setBevelStyle$I(0);
 else if (object === this.this$0.wire ) this.this$0.wireBorder.setBevelStyle$I(0);
 else if (object === this.this$0.switch1 ) this.this$0.switchBorder.setBevelStyle$I(0);
 else if (object === this.this$0.bulb ) this.this$0.bulbBorder.setBevelStyle$I(0);
 else if (object === this.this$0.transformercoil ) this.this$0.transformerBorder.setBevelStyle$I(0);
 else if (object === this.this$0.diode ) this.this$0.diodeBorder.setBevelStyle$I(0);
 else if (object === this.this$0.source ) this.this$0.sourceBorder.setBevelStyle$I(0);
 else if (object === this.this$0.battery ) this.this$0.batteryBorder.setBevelStyle$I(0);
 else if (object === this.this$0.currentsource ) this.this$0.currentsourceBorder.setBevelStyle$I(0);
 else if (object === this.this$0.sinwave ) this.this$0.sinwaveBorder.setBevelStyle$I(0);
 else if (object === this.this$0.squarewave ) this.this$0.squarewaveBorder.setBevelStyle$I(0);
 else if (object === this.this$0.scope ) this.this$0.scopeBorder.setBevelStyle$I(0);
 else if (object === this.this$0.vmeter ) this.this$0.vmeterBorder.setBevelStyle$I(0);
 else if (object === this.this$0.ameter ) this.this$0.ameterBorder.setBevelStyle$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
var stat=-1;
this.this$0.coordStr=this.this$0.circuitBuilder.coordString$java_awt_Point$Z(this.this$0.absoluteP$java_awt_Point$java_awt_Component.apply(this.this$0, [event.getPoint$(), object]), true);
var name="" + (object).getMyName$();
if (name.equals$O("transformercoil")) stat=this.this$0.circuitBuilder.addObject$S$S("transformer", this.this$0.coordStr);
 else stat=this.this$0.circuitBuilder.addObject$S$S(name, this.this$0.coordStr);
if (stat != -1) {
this.this$0.circuitBuilder.currentElement=this.this$0.circuitBuilder.getComponent$S(this.this$0.coordStr);
if (!name.equals$O("wire") && !name.equals$O("scope") && !name.equals$O("ameter") && !name.equals$O("vmeter")  ) this.this$0.changeProperties$.apply(this.this$0, []);
this.this$0.circuitBuilder.reset$();
this.this$0.forwarding.setLabel$S(this.this$0.circuitBuilder.cirProp.getProperty$S("Start"));
this.this$0.circuitBuilder.parse$();
this.this$0.circuitBuilder.repaintMeters$();
}this.this$0.resetButtons$.apply(this.this$0, []);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.BuilderPanel, "SymText", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.TextListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['textValueChanged$java_awt_event_TextEvent','textValueChanged$'], function (event) {
var object=event.getSource$();
if (object === this.this$0.numberInput ) this.this$0.numberInput_TextValueChanged$java_awt_event_TextEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.dtInput ) this.this$0.dtInput_TextValueChanged$java_awt_event_TextEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:15 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
