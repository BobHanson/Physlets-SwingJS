(function(){var P$=Clazz.newPackage("edu.davidson.numerics"),I$=[];
var C$=Clazz.newClass(P$, "SRK45Old", null, 'edu.davidson.numerics.SODE');
C$.b = null;
C$.ch = null;
C$.ct = null;
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.b = Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0.2222222222222222]), Clazz.array(Double.TYPE, -1, [0.08333333333333333, 0.25]), Clazz.array(Double.TYPE, -1, [0.5390625, -1.8984375, 2.109375]), Clazz.array(Double.TYPE, -1, [-1.4166666666666667, 6.75, -5.4, 1.0666666666666667]), Clazz.array(Double.TYPE, -1, [0.15046296296296297, -0.3125, 0.8125, 0.14814814814814814, 0.034722222222222224])]);
C$.ch = Clazz.array(Double.TYPE, -1, [0.10444444444444445, 0.0, 0.48, 0.14222222222222222, 0.03333333333333333, 0.24]);
C$.ct = Clazz.array(Double.TYPE, -1, [-0.006666666666666667, 0.0, 0.03, -0.21333333333333335, -0.05, 0.24]);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.h = 0;
this.numEqu = 0;
this.dydx = null;
this.xTemp = null;
this.f = null;
this.truncErr = null;
this.equations = null;
this.err = 0;
this.tol = 0;
this.hmin = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.h = 0.01;
this.numEqu = 0;
this.tol = 1.0E-8;
this.hmin = 1.0E-7;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'getH', function () {
return this.h;
});

Clazz.newMeth(C$, 'setH$D', function (h) {
this.h = h;
});

Clazz.newMeth(C$, 'getTol', function () {
return this.tol;
});

Clazz.newMeth(C$, 'setTol$D', function (t) {
this.tol = t;
this.hmin = this.tol * 10;
});

Clazz.newMeth(C$, 'stepBack$D$DA', function (dx, x) {
var count = 0;
var oldH;
this.h = -Math.abs(this.h);
while (dx < 0 ){
if (this.h < dx ) {
oldH = this.h;
this.h = dx;
dx = dx - this.stepRK45$DA(x);
this.h = oldH;
count++;
} else {
dx = dx - this.stepRK45$DA(x);
count++;
}}
this.h = +Math.abs(this.h);
return count;
});

Clazz.newMeth(C$, 'step$D$DA', function (dx, x) {
if (x.length < this.numEqu) {
this.numEqu = x.length;
this.xTemp = Clazz.array(Double.TYPE, [this.numEqu]);
this.dydx = Clazz.array(Double.TYPE, [this.numEqu]);
this.truncErr = Clazz.array(Double.TYPE, [this.numEqu]);
this.f = Clazz.array(Double.TYPE, [6, this.numEqu]);
System.out.println$S("Warning:  Temporary arrays reset.");
}if (dx < 0 ) {
return p$.stepBack$D$DA.apply(this, [dx, x]);
}var count = 0;
var oldH;
while (dx > 0 ){
if (this.h > dx ) {
oldH = this.h;
this.h = dx;
dx = dx - this.stepRK45$DA(x);
this.h = oldH;
count++;
} else {
dx = dx - this.stepRK45$DA(x);
count++;
}}
return count;
});

Clazz.newMeth(C$, 'stepODE$D$DA', function (dx, x) {
if (x.length < this.numEqu) {
System.out.println$S("Error:  The temporary arrays are not large enough.");
return 0;
}this.h = dx;
return this.stepRK45$DA(x);
});

Clazz.newMeth(C$, 'stepRK45$DA', function (x) {
var i;
var j;
var k;
var h_did = this.h;
this.dydx = this.equations.rate$DA(x);
for (i = 0; i < this.numEqu; i++) {
this.f[0][i] = this.dydx[i];
this.xTemp[i] = x[i];
}
this.err = 2 * this.tol;
if (this.h >= 0  && this.h <= this.hmin  ) this.h = 1.1 * this.hmin;
 else if (this.h < 0  && -this.h <= this.hmin  ) this.h = -1.1 * this.hmin;
while (this.err > this.tol  && Math.abs(this.h) > this.hmin  ){
for (k = 1; k < 6; k++) {
for (i = 0; i < this.numEqu; i++) {
x[i] = this.xTemp[i];
for (j = 0; j < k; j++) {
x[i] = x[i] + this.h * C$.b[k - 1][j] * this.f[j][i] ;
}
}
this.dydx = this.equations.rate$DA(x);
for (i = 0; i < this.numEqu; i++) this.f[k][i] = this.dydx[i];

}
for (i = 0; i < this.numEqu; i++) {
x[i] = this.xTemp[i];
this.truncErr[i] = 0;
for (k = 0; k < 6; k++) {
x[i] = x[i] + this.h * C$.ch[k] * this.f[k][i] ;
this.truncErr[i] = this.truncErr[i] + this.h * C$.ct[k] * this.f[k][i] ;
}
this.truncErr[i] = Math.abs(this.truncErr[i]);
}
this.err = 0;
for (i = 0; i < this.numEqu; i++) {
if (this.err < this.truncErr[i] ) this.err = this.truncErr[i];
}
h_did = this.h;
if (this.err == 0.0 ) this.err = this.tol / 100000.0;
if (this.err > this.tol ) this.h = 0.9 * this.h * Math.pow(this.tol / this.err, 0.25) ;
 else this.h = 0.9 * this.h * Math.pow(this.tol / this.err, 0.2) ;
if (this.h >= 0  && this.h < this.hmin  ) this.h = this.hmin;
 else if (this.h < 0  && -this.h < this.hmin  ) this.h = -this.hmin;
}
return h_did;
});

Clazz.newMeth(C$, 'setDifferentials$edu_davidson_numerics_SDifferentiable', function (d) {
this.equations = d;
this.numEqu = this.equations.getNumEqu();
this.xTemp = Clazz.array(Double.TYPE, [this.numEqu]);
this.dydx = Clazz.array(Double.TYPE, [this.numEqu]);
this.truncErr = Clazz.array(Double.TYPE, [this.numEqu]);
this.f = Clazz.array(Double.TYPE, [6, this.numEqu]);
});

Clazz.newMeth(C$, 'getDiffernetials', function () {
return this.equations;
});

Clazz.newMeth(C$, 'setNumberOfEquations$I', function (n) {
this.numEqu = n;
this.xTemp = Clazz.array(Double.TYPE, [this.numEqu]);
this.dydx = Clazz.array(Double.TYPE, [this.numEqu]);
this.truncErr = Clazz.array(Double.TYPE, [this.numEqu]);
this.f = Clazz.array(Double.TYPE, [6, this.numEqu]);
});
})();
//Created 2018-02-06 13:05:39
