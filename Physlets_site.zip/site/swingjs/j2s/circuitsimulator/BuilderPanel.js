(function(){var P$=Clazz.newPackage("circuitsimulator"),p$1={},I$=[[0,'java.awt.Button','symantec.itools.awt.util.spinner.NumericSpinner','java.awt.Label','java.awt.TextField','symantec.itools.awt.BorderPanel','java.awt.Color','java.awt.Font',['circuitsimulator.BuilderPanel','.SymAction'],['circuitsimulator.BuilderPanel','.SymMouse'],['circuitsimulator.BuilderPanel','.SymText'],'circuitsimulator.Wire','circuitsimulator.Resistor','circuitsimulator.Capacitor','circuitsimulator.Inductor','circuitsimulator.Switch','circuitsimulator.Bulb','circuitsimulator.TransformerCoil','circuitsimulator.Diode','circuitsimulator.Source','circuitsimulator.Battery','circuitsimulator.CurrentSource','circuitsimulator.SinWave','circuitsimulator.SquareWave','circuitsimulator.Vmeter','circuitsimulator.Ameter','circuitsimulator.Scope','circuitsimulator.ValueInput','circuitsimulator.ListOutput','circuitsimulator.Circuit','java.awt.Point']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "BuilderPanel", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'symantec.itools.awt.BorderPanel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.circuitBuilder=null;
this.selectedComponent=null;
this.wire=null;
this.resistor=null;
this.capacitor=null;
this.inductor=null;
this.switch1=null;
this.bulb=null;
this.transformercoil=null;
this.diode=null;
this.source=null;
this.battery=null;
this.currentsource=null;
this.sinwave=null;
this.squarewave=null;
this.vmeter=null;
this.ameter=null;
this.scope=null;
this.setGridButton=null;
this.rowSpin=null;
this.colSpin=null;
this.label1=null;
this.label3=null;
this.listButton=null;
this.calculateButton=null;
this.numberInput=null;
this.dtInput=null;
this.label9=null;
this.label10=null;
this.arrows=null;
this.loadButton=null;
this.inputfile=null;
this.forwarding=null;
this.resetting=null;
this.resistorBorder=null;
this.capacitorBorder=null;
this.inductorBorder=null;
this.wireBorder=null;
this.sourceBorder=null;
this.scopeBorder=null;
this.vmeterBorder=null;
this.ameterBorder=null;
this.switchBorder=null;
this.batteryBorder=null;
this.bulbBorder=null;
this.currentsourceBorder=null;
this.transformerBorder=null;
this.sinwaveBorder=null;
this.squarewaveBorder=null;
this.diodeBorder=null;
this.coordStr=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.circuitBuilder=null;
this.selectedComponent="";
this.setGridButton=Clazz.new_($I$(1));
this.rowSpin=Clazz.new_($I$(2));
this.colSpin=Clazz.new_($I$(2));
this.label1=Clazz.new_($I$(3));
this.label3=Clazz.new_($I$(3));
this.listButton=Clazz.new_($I$(1));
this.calculateButton=Clazz.new_($I$(1));
this.numberInput=Clazz.new_($I$(4));
this.dtInput=Clazz.new_($I$(4));
this.label9=Clazz.new_($I$(3));
this.label10=Clazz.new_($I$(3));
this.arrows=Clazz.new_($I$(1));
this.loadButton=Clazz.new_($I$(1));
this.inputfile=Clazz.new_($I$(4));
this.forwarding=Clazz.new_($I$(1));
this.resetting=Clazz.new_($I$(1));
this.resistorBorder=Clazz.new_($I$(5));
this.capacitorBorder=Clazz.new_($I$(5));
this.inductorBorder=Clazz.new_($I$(5));
this.wireBorder=Clazz.new_($I$(5));
this.sourceBorder=Clazz.new_($I$(5));
this.scopeBorder=Clazz.new_($I$(5));
this.vmeterBorder=Clazz.new_($I$(5));
this.ameterBorder=Clazz.new_($I$(5));
this.switchBorder=Clazz.new_($I$(5));
this.batteryBorder=Clazz.new_($I$(5));
this.bulbBorder=Clazz.new_($I$(5));
this.currentsourceBorder=Clazz.new_($I$(5));
this.transformerBorder=Clazz.new_($I$(5));
this.sinwaveBorder=Clazz.new_($I$(5));
this.squarewaveBorder=Clazz.new_($I$(5));
this.diodeBorder=Clazz.new_($I$(5));
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit', function (circuit) {
Clazz.super_(C$, this,1);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this, false, 0, 0, 0, 0]);
this.setBackground$java_awt_Color(Clazz.new_($I$(6).c$$I$I$I,[0, 143, 213]));
this.setSize$I$I(195, 401);
this.circuitBuilder=circuit;
try {
this.rowSpin.setMin$I(2);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.rowSpin.setCurrent$I(2);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.rowSpin.setMax$I(8);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.add$java_awt_Component(this.rowSpin);
this.rowSpin.setBackground$java_awt_Color($I$(6).yellow);
this.rowSpin.setForeground$java_awt_Color($I$(6).black);
this.rowSpin.setBounds$I$I$I$I(64, 32, 28, 24);
try {
this.colSpin.setMin$I(2);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.colSpin.setCurrent$I(2);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
try {
this.colSpin.setMax$I(5);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
this.add$java_awt_Component(this.colSpin);
this.colSpin.setBackground$java_awt_Color($I$(6).yellow);
this.colSpin.setBounds$I$I$I$I(64, 56, 28, 24);
this.label1.setText$S("rows");
this.add$java_awt_Component(this.label1);
this.label1.setFont$java_awt_Font(Clazz.new_($I$(7).c$$S$I$I,["Dialog", 0, 10]));
this.label1.setBounds$I$I$I$I(93, 32, 44, 24);
this.label3.setText$S("cols");
this.add$java_awt_Component(this.label3);
this.label3.setFont$java_awt_Font(Clazz.new_($I$(7).c$$S$I$I,["Dialog", 0, 10]));
this.label3.setBounds$I$I$I$I(93, 56, 44, 22);
this.numberInput.setText$S("1e3");
this.add$java_awt_Component(this.numberInput);
this.numberInput.setBackground$java_awt_Color($I$(6).white);
this.numberInput.setFont$java_awt_Font(Clazz.new_($I$(7).c$$S$I$I,["Dialog", 0, 10]));
this.numberInput.setBounds$I$I$I$I(141, 346, 47, 20);
this.dtInput.setText$S("1e-6");
this.add$java_awt_Component(this.dtInput);
this.dtInput.setBackground$java_awt_Color($I$(6).white);
this.dtInput.setFont$java_awt_Font(Clazz.new_($I$(7).c$$S$I$I,["Dialog", 0, 10]));
this.dtInput.setBounds$I$I$I$I(40, 347, 72, 19);
this.label9.setText$S("#:");
this.add$java_awt_Component(this.label9);
this.label9.setBounds$I$I$I$I(126, 343, 16, 23);
this.label10.setText$S("dt (s):");
this.add$java_awt_Component(this.label10);
this.label10.setBounds$I$I$I$I(5, 344, 34, 24);
this.inputfile.setText$S("lists/default.txt");
this.add$java_awt_Component(this.inputfile);
this.inputfile.setBackground$java_awt_Color($I$(6).white);
this.inputfile.setBounds$I$I$I$I(59, 5, 129, 24);
p$1.addBtn$java_awt_Button$S$I$I$I$I.apply(this, [this.setGridButton, "Set grid", 5, 32, 59, 48]);
p$1.addBtn$java_awt_Button$S$I$I$I$I.apply(this, [this.loadButton, "Load", 6, 5, 52, 25]);
p$1.addBtn$java_awt_Button$S$I$I$I$I.apply(this, [this.arrows, "Show ->", 139, 58, 50, 23]);
p$1.addBtn$java_awt_Button$S$I$I$I$I.apply(this, [this.listButton, "List", 138, 32, 51, 23]);
p$1.addBtn$java_awt_Button$S$I$I$I$I.apply(this, [this.calculateButton, "Calculate", 6, 371, 67, 25]);
p$1.addBtn$java_awt_Button$S$I$I$I$I.apply(this, [this.forwarding, "Start", 75, 371, 56, 25]);
p$1.addBtn$java_awt_Button$S$I$I$I$I.apply(this, [this.resetting, "Reset", 132, 371, 58, 25]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.resistorBorder, true, 5, 99, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.capacitorBorder, true, 5, 127, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.inductorBorder, true, 5, 155, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.diodeBorder, true, 5, 191, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.sourceBorder, true, 5, 226, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.batteryBorder, true, 5, 254, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.currentsourceBorder, true, 5, 282, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.bulbBorder, true, 69, 99, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.wireBorder, true, 69, 127, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.switchBorder, true, 69, 155, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.sinwaveBorder, true, 69, 226, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.squarewaveBorder, true, 69, 254, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.transformerBorder, true, 133, 99, 56, 42]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.scopeBorder, true, 133, 226, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.vmeterBorder, true, 133, 254, 56, 28]);
p$1.set$symantec_itools_awt_BorderPanel$Z$I$I$I$I.apply(this, [this.ameterBorder, true, 133, 282, 56, 28]);
p$1.addComponents$circuitsimulator_Circuit.apply(this, [circuit]);
p$1.addListeners.apply(this, []);
p$1.setText$circuitsimulator_CircuitBuilder.apply(this, [this.circuitBuilder]);
}, 1);

Clazz.newMeth(C$, 'addBtn$java_awt_Button$S$I$I$I$I', function (b, label, x, y, w, h) {
b.setLabel$S(label);
b.setBackground$java_awt_Color(Clazz.new_($I$(6).c$$I$I$I,[0, 169, 251]));
b.setBounds$I$I$I$I(x, y, w, h);
this.add$java_awt_Component(b);
}, p$1);

Clazz.newMeth(C$, 'set$symantec_itools_awt_BorderPanel$Z$I$I$I$I', function (bp, andAdd, x, y, w, h) {
bp.setBackground$java_awt_Color(Clazz.new_($I$(6).c$$I$I$I,[0, 169, 251]));
try {
bp.setBevelStyle$I(1);
bp.setPadding$I$I$I$I(0, 0, 0, 0);
bp.setIPadBottom$I(1);
bp.setIPadSides$I(1);
bp.setIPadTop$I(1);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
bp.setLayout$java_awt_LayoutManager(null);
if (bp !== this ) {
this.add$java_awt_Component(bp);
bp.setBounds$I$I$I$I(x, y, w, h);
}}, p$1);

Clazz.newMeth(C$, 'addListeners', function () {
var lSymAction=Clazz.new_($I$(8), [this, null]);
var aSymMouse=Clazz.new_($I$(9), [this, null]);
this.setGridButton.addActionListener$java_awt_event_ActionListener(lSymAction);
this.listButton.addActionListener$java_awt_event_ActionListener(lSymAction);
this.calculateButton.addActionListener$java_awt_event_ActionListener(lSymAction);
var lSymText=Clazz.new_($I$(10), [this, null]);
this.numberInput.addTextListener$java_awt_event_TextListener(lSymText);
this.dtInput.addTextListener$java_awt_event_TextListener(lSymText);
this.arrows.addActionListener$java_awt_event_ActionListener(lSymAction);
this.loadButton.addActionListener$java_awt_event_ActionListener(lSymAction);
this.inputfile.addActionListener$java_awt_event_ActionListener(lSymAction);
this.forwarding.addActionListener$java_awt_event_ActionListener(lSymAction);
this.resetting.addActionListener$java_awt_event_ActionListener(lSymAction);
this.resistor.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.wire.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.capacitor.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.inductor.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.switch1.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.bulb.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.transformercoil.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.diode.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.source.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.battery.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.currentsource.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.sinwave.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.squarewave.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.scope.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.vmeter.addMouseListener$java_awt_event_MouseListener(aSymMouse);
this.ameter.addMouseListener$java_awt_event_MouseListener(aSymMouse);
}, p$1);

Clazz.newMeth(C$, 'addComponents$circuitsimulator_Circuit', function (circuit) {
this.wire=Clazz.new_($I$(11).c$$circuitsimulator_Circuit,[circuit]);
this.resistor=Clazz.new_($I$(12).c$$circuitsimulator_Circuit,[circuit]);
this.capacitor=Clazz.new_($I$(13).c$$circuitsimulator_Circuit,[circuit]);
this.inductor=Clazz.new_($I$(14).c$$circuitsimulator_Circuit,[circuit]);
this.switch1=Clazz.new_($I$(15).c$$circuitsimulator_Circuit,[circuit]);
this.bulb=Clazz.new_($I$(16).c$$circuitsimulator_Circuit,[circuit]);
this.transformercoil=Clazz.new_($I$(17).c$$circuitsimulator_Circuit,[circuit]);
this.diode=Clazz.new_($I$(18).c$$circuitsimulator_Circuit,[circuit]);
this.source=Clazz.new_($I$(19).c$$circuitsimulator_Circuit,[circuit]);
this.battery=Clazz.new_($I$(20).c$$circuitsimulator_Circuit,[circuit]);
this.currentsource=Clazz.new_($I$(21).c$$circuitsimulator_Circuit,[circuit]);
this.sinwave=Clazz.new_($I$(22).c$$circuitsimulator_Circuit,[circuit]);
this.squarewave=Clazz.new_($I$(23).c$$circuitsimulator_Circuit,[circuit]);
this.vmeter=Clazz.new_($I$(24).c$$circuitsimulator_Circuit,[circuit]);
this.ameter=Clazz.new_($I$(25).c$$circuitsimulator_Circuit,[circuit]);
this.scope=Clazz.new_($I$(26).c$$circuitsimulator_Circuit,[circuit]);
this.wireBorder.add$java_awt_Component(this.wire);
this.resistorBorder.add$java_awt_Component(this.resistor);
this.inductorBorder.add$java_awt_Component(this.inductor);
this.capacitorBorder.add$java_awt_Component(this.capacitor);
this.switchBorder.add$java_awt_Component(this.switch1);
this.bulbBorder.add$java_awt_Component(this.bulb);
this.transformerBorder.add$java_awt_Component(this.transformercoil);
this.diodeBorder.add$java_awt_Component(this.diode);
this.sourceBorder.add$java_awt_Component(this.source);
this.batteryBorder.add$java_awt_Component(this.battery);
this.currentsourceBorder.add$java_awt_Component(this.currentsource);
this.sinwaveBorder.add$java_awt_Component(this.sinwave);
this.squarewaveBorder.add$java_awt_Component(this.squarewave);
this.scopeBorder.add$java_awt_Component(this.scope);
this.vmeterBorder.add$java_awt_Component(this.vmeter);
this.ameterBorder.add$java_awt_Component(this.ameter);
}, p$1);

Clazz.newMeth(C$, 'setText$circuitsimulator_CircuitBuilder', function (cb) {
this.label1.setText$S(cb.cirProp.getProperty$S("rows"));
this.label3.setText$S(cb.cirProp.getProperty$S("cols"));
this.loadButton.setLabel$S(cb.cirProp.getProperty$S("Load"));
this.setGridButton.setLabel$S(cb.cirProp.getProperty$S("setgrid"));
this.listButton.setLabel$S(cb.cirProp.getProperty$S("List"));
this.arrows.setLabel$S(cb.cirProp.getProperty$S("arrows"));
this.calculateButton.setLabel$S(cb.cirProp.getProperty$S("Calculate"));
this.forwarding.setLabel$S(cb.cirProp.getProperty$S("Start"));
this.resetting.setLabel$S(cb.cirProp.getProperty$S("Reset"));
this.dtInput.setText$S(String.format$S$OA("%.6f", [new Double(this.circuitBuilder.dt)]));
this.numberInput.setText$S(Integer.toString$I(this.circuitBuilder.numberofdt));
}, p$1);

Clazz.newMeth(C$, 'setGridButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var r=this.rowSpin.getCurrent$();
var c=this.colSpin.getCurrent$();
this.circuitBuilder.setGrid$I$I(r, c);
});

Clazz.newMeth(C$, 'resetButtons$', function () {
try {
this.resistorBorder.setBevelStyle$I(1);
this.capacitorBorder.setBevelStyle$I(1);
this.inductorBorder.setBevelStyle$I(1);
this.wireBorder.setBevelStyle$I(1);
this.switchBorder.setBevelStyle$I(1);
this.bulbBorder.setBevelStyle$I(1);
this.transformerBorder.setBevelStyle$I(1);
this.diodeBorder.setBevelStyle$I(1);
this.sourceBorder.setBevelStyle$I(1);
this.batteryBorder.setBevelStyle$I(1);
this.currentsourceBorder.setBevelStyle$I(1);
this.sinwaveBorder.setBevelStyle$I(1);
this.squarewaveBorder.setBevelStyle$I(1);
this.scopeBorder.setBevelStyle$I(1);
this.vmeterBorder.setBevelStyle$I(1);
this.ameterBorder.setBevelStyle$I(1);
this.dtInput.setText$S(Double.toString$D(this.circuitBuilder.dt));
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'changeProperties$', function () {
var title="" + this.circuitBuilder.cirProp.getProperty$S("changevalue_title");
Clazz.new_($I$(27).c$$S$circuitsimulator_CircuitBuilder$java_awt_Component,[title, this.circuitBuilder, p$1.getAnchorPoint.apply(this, [])]);
});

Clazz.newMeth(C$, 'getAnchorPoint', function () {
var anchorpoint=this.getParent$();
while (anchorpoint != null  && !(Clazz.instanceOf(anchorpoint, "java.awt.Frame"))  && !(Clazz.instanceOf(anchorpoint, "java.applet.Applet")) )anchorpoint=(anchorpoint).getParent$();

return anchorpoint;
}, p$1);

Clazz.newMeth(C$, 'listButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
var s=this.circuitBuilder.cirgrid.getcomponentList$();
var title=this.circuitBuilder.cirProp.getProperty$S("circuitlist");
var anchorpoint=this.getParent$();
while (!(Clazz.instanceOf(anchorpoint, "java.awt.Frame")))anchorpoint=(anchorpoint).getParent$();

var listOutput=Clazz.new_($I$(28).c$$S$S$java_awt_Frame$circuitsimulator_CircuitBuilder,[title, s, anchorpoint, this.circuitBuilder]);
});

Clazz.newMeth(C$, 'parseButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.circuitBuilder.parse$();
this.circuitBuilder.repaintMeters$();
});

Clazz.newMeth(C$, 'calculateButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.circuitBuilder.repaintMeters$();
if ((this.circuitBuilder.debugLevel & $I$(29).DEBUG_IO) > 0) System.out.println$S("Next period calculated");
});

Clazz.newMeth(C$, 'arrows_ActionPerformed$java_awt_event_ActionEvent', function (event) {
if (this.circuitBuilder.showCurrent) this.circuitBuilder.setShowCurrent$I(0);
 else this.circuitBuilder.setShowCurrent$I(1);
this.circuitBuilder.circanvas.redraw$();
});

Clazz.newMeth(C$, 'absoluteP$java_awt_Point$java_awt_Component', function (relativeP, anchor) {
var returnP=Clazz.new_($I$(30).c$$java_awt_Point,[relativeP]);
var p1;
var anchorpoint=anchor;
while (anchorpoint !== this ){
p1=(anchorpoint).getLocation$();
returnP.setLocation$I$I(returnP.x + p1.x, returnP.y + p1.y);
anchorpoint=(anchorpoint).getParent$();
}
returnP.setLocation$I$I(returnP.x + this.getLocation$().x, returnP.y + this.getLocation$().y);
if ((this.circuitBuilder.debugLevel & $I$(29).DEBUG_IO) > 0) System.out.println$S("coords : " + returnP.toString());
return returnP;
});

Clazz.newMeth(C$, 'updateTextFields$', function () {
this.dtInput.setText$S(Double.toString$D(this.circuitBuilder.dt));
this.numberInput.setText$S(Integer.toString$I(this.circuitBuilder.numberofdt));
});

Clazz.newMeth(C$, 'numberInput_TextValueChanged$java_awt_event_TextEvent', function (event) {
this.circuitBuilder.setNumberOfDT$I(Integer.parseInt$S(this.numberInput.getText$()));
this.circuitBuilder.repaintMeters$();
});

Clazz.newMeth(C$, 'dtInput_TextValueChanged$java_awt_event_TextEvent', function (event) {
this.circuitBuilder.setDT$D((Double.valueOf$S(this.dtInput.getText$())).doubleValue$());
this.circuitBuilder.setFPS$D(1.0 / (this.circuitBuilder.noc * this.circuitBuilder.dt));
this.circuitBuilder.repaintMeters$();
});

Clazz.newMeth(C$, 'loadButton_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.circuitBuilder.reset$();
this.forwarding.setLabel$S(this.circuitBuilder.cirProp.getProperty$S("Start"));
this.circuitBuilder.loadList$S(this.inputfile.getText$());
this.updateTextFields$();
this.circuitBuilder.parse$();
this.circuitBuilder.calculateCircuit$();
});

Clazz.newMeth(C$, 'forwarding_ActionPerformed$java_awt_event_ActionEvent', function (event) {
if (this.forwarding.getLabel$().equals$O(this.circuitBuilder.cirProp.getProperty$S("Start"))) {
this.circuitBuilder.forward$();
this.forwarding.setLabel$S(this.circuitBuilder.cirProp.getProperty$S("Pause"));
} else {
this.circuitBuilder.pause$();
this.forwarding.setLabel$S(this.circuitBuilder.cirProp.getProperty$S("Start"));
}});

Clazz.newMeth(C$, 'resetting_ActionPerformed$java_awt_event_ActionEvent', function (event) {
this.circuitBuilder.pause$();
this.circuitBuilder.reset$();
this.forwarding.setLabel$S(this.circuitBuilder.cirProp.getProperty$S("Start"));
});
;
(function(){var C$=Clazz.newClass(P$.BuilderPanel, "SymAction", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.ActionListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed$'], function (event) {
var object=event.getSource$();
if (object === this.this$0.setGridButton ) this.this$0.setGridButton_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.listButton ) this.this$0.listButton_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.calculateButton ) this.this$0.calculateButton_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.arrows ) this.this$0.arrows_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.loadButton ) this.this$0.loadButton_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.forwarding ) this.this$0.forwarding_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.resetting ) this.this$0.resetting_ActionPerformed$java_awt_event_ActionEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.BuilderPanel, "SymMouse", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'java.awt.event.MouseAdapter');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
try {
if (object === this.this$0.resistor ) this.this$0.resistorBorder.setBevelStyle$I(0);
 else if (object === this.this$0.capacitor ) this.this$0.capacitorBorder.setBevelStyle$I(0);
 else if (object === this.this$0.inductor ) this.this$0.inductorBorder.setBevelStyle$I(0);
 else if (object === this.this$0.wire ) this.this$0.wireBorder.setBevelStyle$I(0);
 else if (object === this.this$0.switch1 ) this.this$0.switchBorder.setBevelStyle$I(0);
 else if (object === this.this$0.bulb ) this.this$0.bulbBorder.setBevelStyle$I(0);
 else if (object === this.this$0.transformercoil ) this.this$0.transformerBorder.setBevelStyle$I(0);
 else if (object === this.this$0.diode ) this.this$0.diodeBorder.setBevelStyle$I(0);
 else if (object === this.this$0.source ) this.this$0.sourceBorder.setBevelStyle$I(0);
 else if (object === this.this$0.battery ) this.this$0.batteryBorder.setBevelStyle$I(0);
 else if (object === this.this$0.currentsource ) this.this$0.currentsourceBorder.setBevelStyle$I(0);
 else if (object === this.this$0.sinwave ) this.this$0.sinwaveBorder.setBevelStyle$I(0);
 else if (object === this.this$0.squarewave ) this.this$0.squarewaveBorder.setBevelStyle$I(0);
 else if (object === this.this$0.scope ) this.this$0.scopeBorder.setBevelStyle$I(0);
 else if (object === this.this$0.vmeter ) this.this$0.vmeterBorder.setBevelStyle$I(0);
 else if (object === this.this$0.ameter ) this.this$0.ameterBorder.setBevelStyle$I(0);
} catch (e) {
if (Clazz.exceptionOf(e,"java.beans.PropertyVetoException")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (event) {
var object=event.getSource$();
var stat=-1;
this.this$0.coordStr=this.this$0.circuitBuilder.coordString$java_awt_Point$Z(this.this$0.absoluteP$java_awt_Point$java_awt_Component.apply(this.this$0, [event.getPoint$(), object]), true);
var name="" + (object).getMyName$();
if (name.equals$O("transformercoil")) stat=this.this$0.circuitBuilder.addObject$S$S("transformer", this.this$0.coordStr);
 else stat=this.this$0.circuitBuilder.addObject$S$S(name, this.this$0.coordStr);
if (stat != -1) {
this.this$0.circuitBuilder.currentElement=this.this$0.circuitBuilder.getComponent$S(this.this$0.coordStr);
if (!name.equals$O("wire") && !name.equals$O("scope") && !name.equals$O("ameter") && !name.equals$O("vmeter")  ) this.this$0.changeProperties$.apply(this.this$0, []);
this.this$0.circuitBuilder.reset$();
this.this$0.forwarding.setLabel$S(this.this$0.circuitBuilder.cirProp.getProperty$S("Start"));
this.this$0.circuitBuilder.parse$();
this.this$0.circuitBuilder.repaintMeters$();
}this.this$0.resetButtons$.apply(this.this$0, []);
});

Clazz.newMeth(C$);
})()
;
(function(){var C$=Clazz.newClass(P$.BuilderPanel, "SymText", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'java.awt.event.TextListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['textValueChanged$java_awt_event_TextEvent','textValueChanged$'], function (event) {
var object=event.getSource$();
if (object === this.this$0.numberInput ) this.this$0.numberInput_TextValueChanged$java_awt_event_TextEvent.apply(this.this$0, [event]);
 else if (object === this.this$0.dtInput ) this.this$0.dtInput_TextValueChanged$java_awt_event_TextEvent.apply(this.this$0, [event]);
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:48 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
