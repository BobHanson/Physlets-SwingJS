(function(){var P$=Clazz.newPackage("mathapps"),I$=[['mathapps.FFT2DTransformer','edu.davidson.graphics.EtchedBorder','java.awt.Panel','java.awt.Button','java.awt.TextField','java.awt.Label','java.awt.BorderLayout','mathapps.VerticalFlowLayout','java.awt.FlowLayout','edu.davidson.display.SNumber','edu.davidson.display.SInteger','Boolean','java.awt.Color','mathapps.FFT2D$1','java.awt.Frame','java.awt.Toolkit','edu.davidson.numerics.Parser']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FFT2D", null, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SStepable');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.parser = null;
this.transformer = null;
this.localTime = 0;
this.$isStandalone = false;
this.xmin = 0;
this.ymin = 0;
this.xmax = 0;
this.ymax = 0;
this.rowPts = 0;
this.colPts = 0;
this.functionStr = null;
this.xVariableStr = null;
this.yVariableStr = null;
this.showControls = false;
this.explicitTime = false;
this.validFunction = false;
this.dx = 0;
this.dy = 0;
this.dataArray = null;
this.etchedBorder1 = null;
this.panel5 = null;
this.panel6 = null;
this.setBtn = null;
this.funcField = null;
this.label1 = null;
this.borderLayout1 = null;
this.borderLayout2 = null;
this.verticalFlowLayout1 = null;
this.maxLabel1 = null;
this.buttonPanel1 = null;
this.flowLayout2 = null;
this.numLabel1 = null;
this.yMaxField = null;
this.yMinField = null;
this.panel4 = null;
this.panel7 = null;
this.panel8 = null;
this.yNumField = null;
this.minLabel3 = null;
this.maxLabel = null;
this.buttonPanel = null;
this.flowLayout1 = null;
this.numLabel = null;
this.xMaxField = null;
this.xMinField = null;
this.panel3 = null;
this.panel2 = null;
this.panel1 = null;
this.xNumField = null;
this.minLabel2 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.parser = null;
this.transformer = Clazz.new_((I$[1]||$incl$(1)).c$$edu_davidson_tools_SApplet,[this]);
this.localTime = 0;
this.$isStandalone = false;
this.explicitTime = false;
this.validFunction = false;
this.dx = 1;
this.dy = 1;
this.dataArray = null;
this.etchedBorder1 = Clazz.new_((I$[2]||$incl$(2)));
this.panel5 = Clazz.new_((I$[3]||$incl$(3)));
this.panel6 = Clazz.new_((I$[3]||$incl$(3)));
this.setBtn = Clazz.new_((I$[4]||$incl$(4)));
this.funcField = Clazz.new_((I$[5]||$incl$(5)));
this.label1 = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout1 = Clazz.new_((I$[7]||$incl$(7)));
this.borderLayout2 = Clazz.new_((I$[7]||$incl$(7)));
this.verticalFlowLayout1 = Clazz.new_((I$[8]||$incl$(8)));
this.maxLabel1 = Clazz.new_((I$[6]||$incl$(6)));
this.buttonPanel1 = Clazz.new_((I$[3]||$incl$(3)));
this.flowLayout2 = Clazz.new_((I$[9]||$incl$(9)));
this.numLabel1 = Clazz.new_((I$[6]||$incl$(6)));
this.yMaxField = Clazz.new_((I$[10]||$incl$(10)));
this.yMinField = Clazz.new_((I$[10]||$incl$(10)));
this.panel4 = Clazz.new_((I$[3]||$incl$(3)));
this.panel7 = Clazz.new_((I$[3]||$incl$(3)));
this.panel8 = Clazz.new_((I$[3]||$incl$(3)));
this.yNumField = Clazz.new_((I$[11]||$incl$(11)));
this.minLabel3 = Clazz.new_((I$[6]||$incl$(6)));
this.maxLabel = Clazz.new_((I$[6]||$incl$(6)));
this.buttonPanel = Clazz.new_((I$[3]||$incl$(3)));
this.flowLayout1 = Clazz.new_((I$[9]||$incl$(9)));
this.numLabel = Clazz.new_((I$[6]||$incl$(6)));
this.xMaxField = Clazz.new_((I$[10]||$incl$(10)));
this.xMinField = Clazz.new_((I$[10]||$incl$(10)));
this.panel3 = Clazz.new_((I$[3]||$incl$(3)));
this.panel2 = Clazz.new_((I$[3]||$incl$(3)));
this.panel1 = Clazz.new_((I$[3]||$incl$(3)));
this.xNumField = Clazz.new_((I$[11]||$incl$(11)));
this.minLabel2 = Clazz.new_((I$[6]||$incl$(6)));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.xmin=Double.$valueOf(this.getParameter$S$S("XMin", "-1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xmax=Double.$valueOf(this.getParameter$S$S("XMax", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ymin=Double.$valueOf(this.getParameter$S$S("YMin", "-1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.ymax=Double.$valueOf(this.getParameter$S$S("YMax", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.rowPts=Integer.parseInt(this.getParameter$S$S("XPts", "64"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.colPts=Integer.parseInt(this.getParameter$S$S("YPts", "64"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.functionStr=this.getParameter$S$S("Function", "sin(x*y)");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xVariableStr=this.getParameter$S$S("XVariable", "x");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.yVariableStr=this.getParameter$S$S("YVariable", "y");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls=(I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.buttonPanel.setVisible$Z(this.showControls);
this.funcField.setText$S(this.functionStr);
this.setFunction$S$S$S(this.functionStr, this.xVariableStr, this.yVariableStr);
this.setNumPts$I$I(this.rowPts, this.colPts);
this.clock.addClockListener$edu_davidson_tools_SStepable(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.etchedBorder1.setBackground$java_awt_Color((I$[13]||$incl$(13)).lightGray);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.verticalFlowLayout1);
this.setBtn.setLabel$S("Set");
this.setBtn.setLabel$S("Set");
this.setBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "FFT2D$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['mathapps.FFT2D'].setBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[14]||$incl$(14)).$init$, [this, null])));
this.funcField.setText$S("textField1");
this.label1.setAlignment$I(2);
this.label1.setText$S("f(x,y,t) = ");
this.panel6.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.panel5.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.maxLabel1.setText$S("Max");
this.maxLabel1.setAlignment$I(2);
this.maxLabel1.setText$S("Y Max");
this.maxLabel1.setAlignment$I(2);
this.buttonPanel1.setLayout$java_awt_LayoutManager(this.flowLayout2);
this.buttonPanel1.setBackground$java_awt_Color((I$[13]||$incl$(13)).lightGray);
this.numLabel1.setAlignment$I(2);
this.numLabel1.setText$S("#");
this.numLabel1.setAlignment$I(2);
this.numLabel1.setText$S("#");
this.yMaxField.setValue$D(100.0);
this.yNumField.setValue$I(64);
this.minLabel3.setText$S("Min");
this.minLabel3.setAlignment$I(2);
this.minLabel3.setAlignment$I(2);
this.minLabel3.setText$S("Y Min");
this.maxLabel.setAlignment$I(2);
this.maxLabel.setText$S("Max");
this.maxLabel.setAlignment$I(2);
this.maxLabel.setText$S("X Max");
this.buttonPanel.setBackground$java_awt_Color((I$[13]||$incl$(13)).lightGray);
this.buttonPanel.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.numLabel.setAlignment$I(2);
this.numLabel.setText$S("#");
this.xMaxField.setValue$D(100.0);
this.xNumField.setValue$I(64);
this.minLabel2.setText$S("Min");
this.minLabel2.setAlignment$I(2);
this.minLabel2.setAlignment$I(2);
this.minLabel2.setText$S("X Min");
this.setBackground$java_awt_Color((I$[13]||$incl$(13)).lightGray);
this.add$java_awt_Component$O(this.etchedBorder1, null);
this.etchedBorder1.add$java_awt_Component$O(this.buttonPanel, null);
this.buttonPanel.add$java_awt_Component$O(this.panel3, null);
this.panel3.add$java_awt_Component$O(this.minLabel2, null);
this.panel3.add$java_awt_Component$O(this.xMinField, null);
this.buttonPanel.add$java_awt_Component$O(this.panel2, null);
this.panel2.add$java_awt_Component$O(this.maxLabel, null);
this.panel2.add$java_awt_Component$O(this.xMaxField, null);
this.buttonPanel.add$java_awt_Component$O(this.panel1, null);
this.panel1.add$java_awt_Component$O(this.numLabel, null);
this.panel1.add$java_awt_Component$O(this.xNumField, null);
this.etchedBorder1.add$java_awt_Component$O(this.buttonPanel1, null);
this.buttonPanel1.add$java_awt_Component$O(this.panel4, null);
this.panel4.add$java_awt_Component$O(this.minLabel3, null);
this.panel4.add$java_awt_Component$O(this.yMinField, null);
this.buttonPanel1.add$java_awt_Component$O(this.panel7, null);
this.panel7.add$java_awt_Component$O(this.maxLabel1, null);
this.panel7.add$java_awt_Component$O(this.yMaxField, null);
this.buttonPanel1.add$java_awt_Component$O(this.panel8, null);
this.panel8.add$java_awt_Component$O(this.numLabel1, null);
this.panel8.add$java_awt_Component$O(this.yNumField, null);
this.etchedBorder1.add$java_awt_Component$O(this.panel5, null);
this.panel5.add$java_awt_Component$O(this.setBtn, "East");
this.panel5.add$java_awt_Component$O(this.panel6, "Center");
this.panel6.add$java_awt_Component$O(this.label1, "West");
this.panel6.add$java_awt_Component$O(this.funcField, "Center");
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Analytic Physlet evaluates an analytic function at a specified number of points.";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["Min", "double", "Minimum value"]), Clazz.array(java.lang.String, -1, ["Max", "double", "Maximum value"]), Clazz.array(java.lang.String, -1, ["NumPts", "int", "Number of Points"]), Clazz.array(java.lang.String, -1, ["Function", "String", "The function string"]), Clazz.array(java.lang.String, -1, ["Variable", "String", "The independent variable."]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the user interface"])]);
return pinfo;
});

Clazz.newMeth(C$, 'main', function (args) {
var applet = Clazz.new_(C$);
applet.$isStandalone=true;
var frame;
frame=((
(function(){var C$=Clazz.newClass(P$, "FFT2D$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('java.awt.Frame'), null, 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'processWindowEvent$java_awt_event_WindowEvent', function (e) {
C$.superclazz.prototype.processWindowEvent$java_awt_event_WindowEvent.apply(this, [e]);
if (e.getID() == 201) {
System.exit(0);
}});

Clazz.newMeth(C$, ['setTitle$S','setTitle'], function (title) {
C$.superclazz.prototype.setTitle$S.apply(this, [title]);
this.enableEvents$J(64);
});
})()
), Clazz.new_((I$[15]||$incl$(15)), [this, null],P$.FFT2D$2));
frame.setTitle$S("Applet Frame");
frame.add$java_awt_Component$O(applet, "Center");
applet.init();
applet.start();
frame.setSize$I$I(400, 320);
var d = (I$[16]||$incl$(16)).getDefaultToolkit().getScreenSize();
frame.setLocation$I$I(((d.width - frame.getSize().width)/2|0), ((d.height - frame.getSize().height)/2|0));
frame.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, ['setGutter$I','setGutter'], function (pts) {
if (pts < 0) pts=0;
if (this.transformer.getGutter() != pts) {
this.transformer.setGutter$I(pts);
if (this.autoRefresh) {
}}});

Clazz.newMeth(C$, ['setNumPts$I$I','setNumPts'], function (nx, ny) {
if (nx < 1) {
System.out.println$S("Number of x points must be >0.");
}this.rowPts=Math.max(1, nx);
if (ny < 1) {
System.out.println$S("Number of y points must be >0.");
}this.colPts=Math.max(1, ny);
if (this.dataArray == null  || this.dataArray.length != this.rowPts  || this.dataArray[0].length != this.colPts ) this.dataArray=Clazz.array(Double.TYPE, [this.rowPts, this.colPts]);
if (this.showControls && this.getBounds().width > 50 ) {
this.xNumField.setValue$I(this.rowPts);
this.yNumField.setValue$I(this.colPts);
}});

Clazz.newMeth(C$, ['setMinMax$D$D$D$D','setMinMax'], function (xmin_, xmax_, ymin_, ymax_) {
if (this.parser == null  || !this.validFunction ) {
System.out.println$S("Invalid function.");
return;
}this.xmax=xmax_;
this.xmin=xmin_;
this.ymax=ymax_;
this.ymin=ymin_;
if (this.xmax < this.xmin ) {
System.out.println$S("X Maximum must be >  minimum.");
var temp = this.xmax;
this.xmax=this.xmin;
this.xmin=temp;
}if (this.xmax == this.xmin ) {
System.out.println$S("X Maximum cannot be =  minimum.");
this.xmax=this.xmax + 1.0;
}this.dx=(this.xmax - this.xmin) / (this.rowPts - 1);
if (this.ymax < this.ymin ) {
System.out.println$S("Y Maximum must be >  minimum.");
var temp = this.ymax;
this.ymax=this.ymin;
this.ymin=temp;
}if (this.ymax == this.ymin ) {
System.out.println$S("Y Maximum cannot be =  minimum.");
this.ymax=this.ymax + 1.0;
}if (this.showControls && this.getBounds().width > 50 ) {
this.xMinField.setValue$D(this.xmin);
this.xMaxField.setValue$D(this.xmax);
this.yMinField.setValue$D(this.ymin);
this.yMaxField.setValue$D(this.ymax);
}});

Clazz.newMeth(C$, 'destroy', function () {
this.transformer.destroy();
C$.superclazz.prototype.destroy.apply(this, []);
});

Clazz.newMeth(C$, 'evaluate', function () {
var dx = (this.xmax - this.xmin) / (this.rowPts - 1);
var dy = (this.ymax - this.ymin) / (this.colPts - 1);
var xval = this.xmin;
var yval = this.ymin;
var offset = 0;
for (var i = 0; i < this.rowPts; i++) {
offset=i * this.colPts;
for (var j = 0; j < this.colPts; j++) {
this.dataArray[i][j]=0;
if (this.explicitTime) this.dataArray[i][j]=this.parser.evaluate$D$D$D(xval, yval, this.localTime);
 else this.dataArray[i][j]=this.parser.evaluate$D$D(xval, yval);
yval += dy;
}
yval=this.ymin;
xval += dx;
}
this.transformer.setDataArray$DAA(this.dataArray);
});

Clazz.newMeth(C$, 'parseVariables$S', function (string) {
var oneFunc = Clazz.new_((I$[17]||$incl$(17)).c$$I,[2]);
var str =  String.instantialize(string);
oneFunc.defineVariable$I$S(1, this.xVariableStr);
oneFunc.defineVariable$I$S(2, this.yVariableStr);
oneFunc.define$S(str.toLowerCase());
oneFunc.parse();
if (oneFunc.getErrorCode() != 0) {
System.out.println$S("variable 1: " + this.xVariableStr);
System.out.println$S("variable 2: " + this.yVariableStr);
System.out.println$S("Failed to parse f(one,two)): " + str);
this.validFunction=false;
return false;
}this.validFunction=true;
this.explicitTime=false;
this.parser=oneFunc;
this.functionStr=string;
return true;
});

Clazz.newMeth(C$, 'parseTimeVariables$S', function (string) {
var twoFunc = Clazz.new_((I$[17]||$incl$(17)).c$$I,[3]);
var str =  String.instantialize(string);
twoFunc.defineVariable$I$S(1, this.xVariableStr);
twoFunc.defineVariable$I$S(2, this.yVariableStr);
twoFunc.defineVariable$I$S(3, "t");
twoFunc.define$S(str.toLowerCase());
twoFunc.parse();
if (twoFunc.getErrorCode() != 0) {
System.out.println$S("variable one: " + this.xVariableStr);
System.out.println$S("variable two: " + this.yVariableStr);
System.out.println$S("Failed to parse f(one,two,t)): " + str);
System.out.println$S("Parse error in MathFunction: " + twoFunc.getErrorString() + " at function 1, position " + twoFunc.getErrorPosition() );
p$.parseVariables$S.apply(this, ["0"]);
this.validFunction=false;
return false;
}this.validFunction=true;
this.explicitTime=true;
this.parser=twoFunc;
this.functionStr=string;
return true;
});

Clazz.newMeth(C$, ['setAutoRefresh$Z','setAutoRefresh'], function (refresh) {
if (this.autoRefresh == refresh ) return;
this.autoRefresh=refresh;
if (refresh) this.evaluate();
});

Clazz.newMeth(C$, ['setFFTScale$D','setFFTScale'], function (scale) {
this.transformer.setFFTScale$D(scale);
if (this.autoRefresh) this.evaluate();
});

Clazz.newMeth(C$, 'setDefault', function () {
this.deleteDataConnections();
this.clock.stopClock();
this.clock.setTime$D(0);
this.localTime=0;
this.transformer.setDefault();
});

Clazz.newMeth(C$, 'reset', function () {
this.clock.stopClock();
this.clock.setTime$D(0);
this.localTime=0;
});

Clazz.newMeth(C$, ['setFunction$S$S$S','setFunction'], function ($function, xvar, yvar) {
this.xVariableStr= String.instantialize(xvar.trim().toLowerCase());
this.yVariableStr= String.instantialize(yvar.trim().toLowerCase());
var str = $function.trim();
if (!p$.parseVariables$S.apply(this, [$function.trim()])) p$.parseTimeVariables$S.apply(this, [$function.trim()]);
this.setMinMax$D$D$D$D(this.xmin, this.xmax, this.ymin, this.ymax);
if (this.validFunction && this.showControls ) {
this.funcField.setText$S(str);
this.functionStr=str;
}return this.validFunction;
});

Clazz.newMeth(C$, ['setFunctionStr$S','setFunctionStr'], function ($function) {
var str = $function.trim();
this.setFunction$S$S$S(str, this.xVariableStr, this.yVariableStr);
return this.validFunction;
});

Clazz.newMeth(C$, ['getFunctionStr$S','getFunctionStr'], function (string) {
return this.functionStr;
});

Clazz.newMeth(C$, ['step$D$D','step'], function (dt, time) {
if (this.parser == null  || !this.validFunction ) {
System.out.println$S("Invalid function.");
return;
}this.localTime=time + dt;
if (this.explicitTime) this.evaluate();
});

Clazz.newMeth(C$, 'getFFTID', function () {
return this.transformer.getID();
});

Clazz.newMeth(C$, 'getEvenID', function () {
return this.transformer.getEvenID();
});

Clazz.newMeth(C$, 'getOddID', function () {
return this.transformer.getOddID();
});

Clazz.newMeth(C$, 'setBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.xmin=this.xMinField.getValue();
this.xmax=this.xMaxField.getValue();
this.ymin=this.yMinField.getValue();
this.ymax=this.yMaxField.getValue();
this.rowPts=this.xNumField.getValue();
this.colPts=this.yNumField.getValue();
this.setNumPts$I$I(this.rowPts, this.colPts);
this.setFunctionStr$S(this.funcField.getText());
if (!this.explicitTime || !this.clock.isRunning() ) this.evaluate();
if (this.explicitTime) this.clock.startClock();
});
})();
//Created 2018-07-20 18:09:37
