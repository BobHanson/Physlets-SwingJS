(function(){var P$=Clazz.newPackage("bfield"),I$=[];
var C$=Clazz.newClass(P$, "FieldBox", null, 'edu.davidson.display.BoxThing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.fieldPanel = null;
this.integral = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.integral = 0;
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$bfield_FieldPanel$D$D$I$I', function (owner, fp, x, y, width, height) {
C$.superclazz.c$$edu_davidson_tools_SApplet$edu_davidson_display_SScalable$D$D$I$I.apply(this, [owner, fp, x, y, width, height]);
C$.$init$.apply(this);
this.fieldPanel = fp;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "bx", "by", "path"]);
this.ds = Clazz.array(Double.TYPE, [1, 5]);
}, 1);

Clazz.newMeth(C$, 'doLineIntegral', function () {
var sum1 = 0;
var sum2 = 0;
var sum3 = 0;
var sum4 = 0;
if (this.w < 2 || this.h < 2 ) return 0;
var ptX = this.fieldPanel.pixFromX$D(this.x) - (this.w/2|0) + this.xDisplayOff;
var ptY = this.fieldPanel.pixFromY$D(this.y) - (this.h/2|0) - this.yDisplayOff;
var xlocal1;
var ylocal1;
var xlocal2;
var ylocal2;
xlocal1 = this.fieldPanel.xFromPix$I(ptX);
xlocal2 = this.fieldPanel.xFromPix$I(ptX + this.w);
var dx = (xlocal2 - xlocal1) / this.w;
ylocal1 = this.fieldPanel.yFromPix$I(ptY);
ylocal2 = this.fieldPanel.yFromPix$I(ptY + this.h);
var dy = (ylocal2 - ylocal1) / this.h;
var x0 = xlocal1 + dx / 2;
for (var i = 0; i < this.w; i++) {
sum1 -= this.fieldPanel.getBx$D$D$bfield_Wire(x0, ylocal1, null);
sum2 += this.fieldPanel.getBx$D$D$bfield_Wire(x0, ylocal2, null);
x0 += dx;
}
var y0 = ylocal1 + dy / 2;
for (var j = 0; j < this.h; j++) {
sum3 -= this.fieldPanel.getBy$D$D$bfield_Wire(xlocal1, y0, null);
sum4 += this.fieldPanel.getBy$D$D$bfield_Wire(xlocal2, y0, null);
y0 += dy;
}
this.integral = (sum1 * dx + sum2 * dx - sum3 * dy - sum4 * dy);
return this.integral;
});

Clazz.newMeth(C$, 'getVariables', function () {
this.ds[0][0] = this.x;
this.ds[0][1] = this.y;
this.ds[0][2] = this.fieldPanel.getBx$D$D$bfield_Wire(this.x, this.y, null);
this.ds[0][3] = this.fieldPanel.getBy$D$D$bfield_Wire(this.x, this.y, null);
;this.ds[0][4] = this.doLineIntegral();
return this.ds;
});

Clazz.newMeth(C$);
})();
//Created 2018-03-17 21:36:54
