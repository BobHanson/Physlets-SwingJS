(function(){var P$=Clazz.newPackage("eField4"),I$=[[0,'java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "Shell", null, 'eField4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$D$D$I', function (canvas, x, y, radius) {
C$.superclazz.c$$eField4_OdeCanvas$D$D$D$D.apply(this, [canvas, x, y, 0, 0]);
C$.$init$.apply(this);
this.s=1;
this.w=radius;
this.h=radius;
this.vars[0]=0;
this.vars[1]=x;
this.vars[2]=y;
this.initVars[0]=0;
this.initVars[1]=x;
this.initVars[2]=y;
this.ds=Clazz.array(Double.TYPE, [1, 8]);
this.varStrings=Clazz.array(String, -1, ["t", "x", "y", "vx", "vy", "ax", "ay", "f"]);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (osg) {
if (this.hideThing) return;
var ptX=this.p.pixFromX$D(this.vars[1]) - this.w + this.xDisplayOff;
var ptY=this.p.pixFromY$D(this.vars[2]) - this.w - this.yDisplayOff ;
osg.setColor$java_awt_Color(this.color);
for (var i=0; i <= this.s; i++) {
osg.drawOval$I$I$I$I(ptX + i, ptY + i, 2 * this.w - 2 * i + 1, 2 * this.h - 2 * i + 1);
}
});

Clazz.newMeth(C$, 'paintHighlight$java_awt_Graphics', function (osg) {
if (this.hideThing) return;
var ptX=this.p.pixFromX$D(this.vars[1]) - this.w + this.xDisplayOff;
var ptY=this.p.pixFromY$D(this.vars[2]) - this.w - this.yDisplayOff ;
if (this.color === $I$(1).red ) osg.setColor$java_awt_Color($I$(1).blue);
 else osg.setColor$java_awt_Color($I$(1).red);
for (var i=0; i <= this.s; i++) {
osg.drawOval$I$I$I$I(ptX + i, ptY + i, 2 * this.w - 2 * i + 1, 2 * this.h - 2 * i + 1);
osg.drawOval$I$I$I$I(ptX + i - 1, ptY + i - 1, 2 * this.w - 2 * i + 3, 2 * this.h - 2 * i + 3);
}
});

Clazz.newMeth(C$, 'isInsideThing$I$I', function (xPix, yPix) {
var ptX=this.p.pixFromX$D(this.vars[1]) + this.xDisplayOff;
var ptY=this.p.pixFromY$D(this.vars[2]) - this.yDisplayOff;
if ((xPix - ptX) * (xPix - ptX) + (yPix - ptY) * (yPix - ptY) < this.w * this.w + 1) return true;
 else return false;
});

Clazz.newMeth(C$, 'getVariables$', function () {
this.ds[0][0]=this.vars[0];
this.ds[0][1]=this.vars[1];
this.ds[0][2]=this.vars[2];
this.ds[0][3]=this.vars[3];
this.ds[0][4]=this.vars[4];
this.ds[0][5]=this.vars[5];
this.ds[0][6]=this.vars[6];
this.ds[0][7]=this.calcFlux$();
return this.ds;
});

Clazz.newMeth(C$, 'calculateState$', function () {
this.calcFlux$();
});

Clazz.newMeth(C$, 'calcFlux$', function () {
var numPts=Math.max(50, ((4 * 3.141592653589793 * this.w )|0));
var sum=0;
var ptX=this.p.pixFromX$D(this.vars[1]);
var r=this.p.xFromPix$I(ptX + this.w) - this.p.xFromPix$I(ptX);
var x;
var y;
var theta=0;
var dTheta=6.283185307179586 / (numPts);
for (var i=0; i < numPts; i++) {
x=this.vars[1] + r * Math.cos(theta);
y=this.vars[2] + r * Math.sin(theta);
sum=sum + Math.cos(theta) * (-this.p.dudx$D$D(x, y));
sum=sum - Math.sin(theta) * (this.p.dudy$D$D(x, y));
theta += dTheta;
}
this.flux=3.141592653589793 * r * sum  / numPts + 3.141592653589793 * this.enclosedCharge$() * 4 ;
return this.flux;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.07');//Created 2019-09-29 20:01:52 Java2ScriptVisitor version 3.2.4.07 net.sf.j2s.core.jar version 3.2.4.07
