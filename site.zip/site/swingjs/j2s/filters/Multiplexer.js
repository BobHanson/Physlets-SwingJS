(function(){var P$=Clazz.newPackage("filters"),I$=[['edu.davidson.tools.SApplet','java.util.Vector','edu.davidson.numerics.Parser',['filters.Multiplexer','.Listener']]],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Multiplexer", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SDataSource');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone = false;
this.varStrings = null;
this.ds = null;
this.listeners = null;
this.parserVars = null;
this.parserValues = null;
this.xParser = null;
this.xFunc = null;
this.yParser = null;
this.yFunc = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone = false;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y"]);
this.ds = Clazz.array(Double.TYPE, [1, 2]);
this.listeners = Clazz.new_((I$[2]||$incl$(2)));
this.parserVars = null;
this.parserValues = null;
this.xParser = null;
this.xFunc = "0";
this.yParser = null;
this.yFunc = "0";
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.xFunc="0";
this.xParser=Clazz.new_((I$[3]||$incl$(3)).c$$I,[1]);
this.xParser.defineVariable$I$S(1, "x");
this.xParser.define$S(this.xFunc);
this.xParser.parse();
this.yFunc="0";
this.yParser=Clazz.new_((I$[3]||$incl$(3)).c$$I,[1]);
this.yParser.define$S(this.yFunc);
this.yParser.defineVariable$I$S(1, "y");
this.yParser.parse();
edu.davidson.tools.SApplet.addDataSource$O(this);
});

Clazz.newMeth(C$, 'jbInit', function () {
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Multiplexer Physlet writen by Wolfgang Christian.  wochristian@davidson.edu";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
return null;
});

Clazz.newMeth(C$, 'getVariables', function () {
if (this.listeners.size() <= 0) {
System.out.println$S("Warning: no data listeners in Multiplexer Physlet.");
this.ds=Clazz.array(Double.TYPE, [1, 2]);
this.ds[0][0]=0;
this.ds[0][1]=0;
return this.ds;
}var maxRows = p$.getNumValues.apply(this, []);
if (maxRows != this.ds.length) {
this.ds=Clazz.array(Double.TYPE, [maxRows, 2]);
}for (var row = 0; row < maxRows; row++) {
for (var i = 0; i < this.listeners.size(); i++) {
var listener = this.listeners.elementAt$I(i);
if (row < listener.lastValues.length) {
this.parserValues[2 * i]=listener.lastValues[row][0];
this.parserValues[2 * i + 1]=listener.lastValues[row][1];
} else {
this.parserValues[2 * i]=listener.lastValues[0][0];
this.parserValues[2 * i + 1]=listener.lastValues[0][1];
}}
this.ds[row][0]=this.xParser.evaluate$DA(this.parserValues);
this.ds[row][1]=this.yParser.evaluate$DA(this.parserValues);
}
return this.ds;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, 'setDefault', function () {
this.clock.stopClock();
this.deleteDataConnections();
this.clock.setContinuous();
this.clock.setTime$D(0);
this.listeners.removeAllElements();
this.xFunc="0";
this.xParser=Clazz.new_((I$[3]||$incl$(3)).c$$I,[1]);
this.xParser.defineVariable$I$S(1, "x");
this.xParser.define$S(this.xFunc);
this.xParser.parse();
this.yFunc="0";
this.yParser=Clazz.new_((I$[3]||$incl$(3)).c$$I,[1]);
this.yParser.defineVariable$I$S(1, "y");
this.yParser.define$S(this.yFunc);
this.yParser.parse();
});

Clazz.newMeth(C$, ['setFunctions$S$S','setFunctions'], function (xFunction, yFunction) {
if (this.listeners.size() <= 0) {
System.out.println$S("Create data listeners before you define the output function.");
xFunction="0";
yFunction="0";
}this.xFunc=xFunction;
this.xParser.defineVariables$SA(this.parserVars);
this.xParser.define$S(this.xFunc);
this.xParser.parse();
if (this.xParser.getErrorCode() != 0) {
System.out.println$S("Failed to parse function: " + this.xFunc);
System.out.println$S("Parse error in Multiplexer x function: " + this.xParser.getErrorString() + " at math fuinction, position " + this.xParser.getErrorPosition() );
System.out.println$S("Create data listeners before you define the output function.");
return false;
}this.yFunc=yFunction;
this.yParser.defineVariables$SA(this.parserVars);
this.yParser.define$S(this.yFunc);
this.yParser.parse();
if (this.yParser.getErrorCode() != 0) {
System.out.println$S("Failed to parse function: " + this.yFunc);
System.out.println$S("Parse error in Multiplexer y function: " + this.yParser.getErrorString() + " at math fuinction, position " + this.yParser.getErrorPosition() );
System.out.println$S("Create data listeners before you define the output function.");
return false;
}return true;
});

Clazz.newMeth(C$, ['setActiveListener$I$Z','setActiveListener'], function (index, active) {
var listener = null;
for (var i = 0; i < this.listeners.size(); i++) {
listener=this.listeners.elementAt$I(i);
if (listener.index == index) {
listener.active=active;
return true;
}}
return false;
});

Clazz.newMeth(C$, ['addMultiplexListener$I','addMultiplexListener'], function (index) {
var listener = null;
for (var i = 0; i < this.listeners.size(); i++) {
listener=this.listeners.elementAt$I(i);
if (listener.index == index) return listener.getID();
}
listener=Clazz.new_((I$[4]||$incl$(4)).c$$I, [this, null, index]);
this.listeners.addElement$TE(listener);
p$.setParserVars.apply(this, []);
return listener.getID();
});

Clazz.newMeth(C$, ['addDataListener$I','addDataListener'], function (index) {
return this.addMultiplexListener$I(index);
});

Clazz.newMeth(C$, 'setParserVars', function () {
var numVars = 2 * this.listeners.size();
this.xParser=Clazz.new_((I$[3]||$incl$(3)).c$$I,[numVars]);
this.yParser=Clazz.new_((I$[3]||$incl$(3)).c$$I,[numVars]);
this.parserVars=Clazz.array(java.lang.String, [numVars]);
this.parserValues=Clazz.array(Double.TYPE, [numVars]);
for (var i = 0; i < this.listeners.size(); i++) {
var listener = this.listeners.elementAt$I(i);
this.parserVars[2 * i]=listener.xStr;
this.parserVars[2 * i + 1]=listener.yStr;
}
});

Clazz.newMeth(C$, 'getNumValues', function () {
var num = 0;
for (var i = 0; i < this.listeners.size(); i++) {
var listener = this.listeners.elementAt$I(i);
num=Math.max(num, listener.lastValues.length);
}
return num;
});
;
(function(){var C$=Clazz.newClass(P$.Multiplexer, "Listener", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'edu.davidson.tools.SDataListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.index = 0;
this.xStr = null;
this.yStr = null;
this.active = false;
this.lastValues = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.index = 0;
this.xStr = "x0";
this.yStr = "y0";
this.active = false;
this.lastValues = Clazz.array(Double.TYPE, [1, 2]);
}, 1);

Clazz.newMeth(C$, 'c$$I', function (i) {
C$.$init$.apply(this);
this.index=i;
this.xStr="x" + i;
this.yStr="y" + i;
try {
(I$[1]||$incl$(1)).addDataListener$O(this);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'setOwner$edu_davidson_tools_SApplet', function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this.this$0;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.this$0.varStrings;
});

Clazz.newMeth(C$, 'getID', function () {
return this.hashCode();
});

Clazz.newMeth(C$, 'deleteSeries$I', function (id) {
;});

Clazz.newMeth(C$, 'clearSeries$I', function (id) {
;});

Clazz.newMeth(C$, 'addDatum$edu_davidson_tools_SDataSource$I$D$D', function (s, id, x, y) {
this.lastValues[0][0]=x;
this.lastValues[0][1]=y;
if (this.active) this.this$0.updateDataConnections();
});

Clazz.newMeth(C$, 'addData$edu_davidson_tools_SDataSource$I$DA$DA', function (s, id, x, y) {
if (x.length != this.lastValues.length) {
this.lastValues=Clazz.array(Double.TYPE, [x.length, 2]);
}for (var i = 0; i < x.length; i++) {
this.lastValues[i][0]=x[i];
this.lastValues[i][1]=y[i];
}
if (this.active) this.this$0.updateDataConnections();
});

Clazz.newMeth(C$);
})()
})();
//Created 2018-07-20 18:09:32
