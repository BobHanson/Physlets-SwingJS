(function(){var P$=Clazz.newPackage("eField4"),I$=[];
var C$=Clazz.newClass(P$, "ConnectorLine", null, 'eField4.Connector');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$eField4_OdeCanvas$eField4_Thing$eField4_Thing', function (o, t1, t2) {
C$.superclazz.c$$eField4_OdeCanvas$eField4_Thing$eField4_Thing.apply(this, [o, t1, t2]);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (this.hideThing) return;
if (this.thing1 == null  || this.thing2 == null  ) return;
var ptX1 = this.p.pixFromX$D(this.thing1.vars[1]);
var ptY1 = this.p.pixFromY$D(this.thing1.vars[2]);
var ptX2 = this.p.pixFromX$D(this.thing2.vars[1]);
var ptY2 = this.p.pixFromY$D(this.thing2.vars[2]);
g.setColor$java_awt_Color(this.color);
g.drawLine$I$I$I$I(ptX1, ptY1, ptX2, ptY2);
});

Clazz.newMeth(C$);
})();
//Created 2018-02-08 01:51:50
