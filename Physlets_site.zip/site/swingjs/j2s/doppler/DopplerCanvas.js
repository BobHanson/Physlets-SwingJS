(function(){var P$=Clazz.newPackage("doppler"),I$=[['Boolean','doppler.DopplerFrame','java.awt.BorderLayout','a2s.Panel','java.awt.Color','a2s.CheckboxGroup','java.awt.GridLayout','a2s.Checkbox','doppler.VarScrollBar','edu.davidson.graphics.EtchedBorder','doppler.SizedButton','doppler.DopplerCanvas','javax.swing.Timer','Thread','java.net.URL','java.util.Vector','java.awt.Font','doppler.DopplerWaveCrest','edu.davidson.display.Format']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DopplerCanvas", null, 'a2s.Canvas');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.applet = null;
this.lastTime = 0;
this.xs = 0;
this.ys = 0;
this.vxs = 0;
this.genVec = null;
this.sourceTime = 0;
this.labTime = 0;
this.buff_image = null;
this.buff_width = 0;
this.buff_height = 0;
this.relativistic = false;
this.showCoord = false;
this.xCoord = 0;
this.yCoord = 0;
this.pixPerUnit = 0;
this.f = null;
this.timeDisplay = false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.applet = null;
this.xs = 0;
this.genVec = Clazz.new_((I$[16]||$incl$(16)));
this.sourceTime = 0;
this.labTime = 0;
this.buff_image = null;
this.buff_width = 0;
this.buff_height = 0;
this.relativistic = false;
this.showCoord = false;
this.pixPerUnit = 10;
this.f = Clazz.new_((I$[17]||$incl$(17)).c$$S$I$I,["Helvetica", 1, 14]);
this.timeDisplay = true;
}, 1);

Clazz.newMeth(C$, 'c$$doppler_Doppler', function (a) {
Clazz.super_(C$, this,1);
this.applet = a;
}, 1);

Clazz.newMeth(C$, 'reset', function () {
this.xs = 0;
this.ys = (this.size().height/2|0);
this.labTime = 0;
this.sourceTime = 10;
this.genVec.removeAllElements();
});

Clazz.newMeth(C$, 'resetSource', function () {
this.xs = 0;
this.ys = (this.size().height/2|0);
this.labTime = 0;
this.sourceTime = 0;
this.genVec.removeAllElements();
});

Clazz.newMeth(C$, 'setX$I', function (newx) {
this.xs = newx;
this.ys = (this.size().height/2|0);
this.labTime = 0;
this.sourceTime = 0;
this.genVec.removeAllElements();
});

Clazz.newMeth(C$, 'translateSource$I', function (x) {
var len = this.genVec.size();
var i;
var gen;
this.xs = this.xs + x;
this.ys = (this.size().height/2|0);
if (len > 0) {
for (i = 0; i < len; i++) {
gen = (this.genVec.elementAt$I(i));
gen.translate$I(x);
}
}});

Clazz.newMeth(C$, 'setSpeed$D$D', function (vx_, vy_) {
this.vxs = vx_;
});

Clazz.newMeth(C$, 'setRelativistic$Z', function (r) {
if (this.relativistic != r ) {
this.reset();
}this.relativistic = r;
});

Clazz.newMeth(C$, 'incTime$D', function (speed) {
this.labTime = this.labTime + 1.0;
if (this.relativistic) {
this.sourceTime = this.sourceTime + 1.0 * Math.sqrt(1 - speed * speed);
} else {
this.sourceTime = this.sourceTime + 1.0;
}this.xs = (this.xs + this.vxs);
if (this.xs > this.size().width ) {
this.translateSource$I(-this.size().width);
}if (this.sourceTime > this.pixPerUnit ) {
this.sourceTime = this.sourceTime - this.pixPerUnit;
if (this.genVec.size() > 10) {
this.genVec.removeElementAt$I(0);
}this.genVec.addElement$TE(Clazz.new_((I$[18]||$incl$(18)).c$$D$I$I$D$D,[this.labTime, (this.xs|0), (this.ys|0), this.vxs, this.vxs]));
}var thisTime = System.currentTimeMillis();
this.lastTime = thisTime;
this.repaint();
});

Clazz.newMeth(C$, 'calcBuffImage', function () {
var i;
var len = this.genVec.size();
var g = this.buff_image.getGraphics();
var gen;
g.setColor$java_awt_Color((I$[5]||$incl$(5)).white);
g.fillRect$I$I$I$I(0, 0, this.buff_width, this.buff_height);
if (len > 0) {
for (i = 0; i < len; i++) {
g.setColor$java_awt_Color(Clazz.new_((I$[5]||$incl$(5)).c$$I$I$I,[(255 * (len - i)/len|0), (255 * (len - i)/len|0), (255 * (len - i)/len|0)]));
gen = (this.genVec.elementAt$I(i));
gen.draw$D$java_awt_Graphics(this.labTime, g);
}
}g.setColor$java_awt_Color((I$[5]||$incl$(5)).red);
g.fillOval$I$I$I$I(((this.xs - 2)|0), ((this.ys - 2)|0), 4, 4);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).black);
g.setFont$java_awt_Font(this.f);
var fm = g.getFontMetrics$java_awt_Font(this.f);
g.drawString$S$I$I(this.applet.label_caption, ((this.buff_width - fm.stringWidth$S(this.applet.label_caption))/2|0), 20);
g.dispose();
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
try {
if ((this.buff_image == null ) || (this.size().width != this.buff_width) || (this.size().height != this.buff_height)  ) {
this.ys = (this.size().height/2|0);
this.buff_width = this.size().width;
this.buff_height = this.size().height;
this.buff_image = this.createImage$I$I(this.buff_width, this.buff_height);
this.reset();
}p$.calcBuffImage.apply(this, []);
g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.buff_image, 0, 0, this);
var tStr = Clazz.new_((I$[19]||$incl$(19)).c$$S,["%7.4g"]).form$D(this.labTime / this.pixPerUnit);
var pStr = Clazz.new_((I$[19]||$incl$(19)).c$$S,["%7.4g"]).form$D(p$.pixToX$I.apply(this, [((this.xs)|0)]));
if (this.timeDisplay) {
g.drawString$S$I$I(this.applet.label_time + tStr, 10, 15);
if (!this.showCoord) {
g.drawString$S$I$I(this.applet.label_position + pStr, 10, this.buff_height - 15);
}}if (this.showCoord) p$.paintCoords$java_awt_Graphics.apply(this, [g]);
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
this.buff_image = null;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'pixToX$I', function (x) {
var xo = (this.buff_width/2|0);
return (x - xo) / (1.0 * this.pixPerUnit);
});

Clazz.newMeth(C$, 'pixToY$I', function (y) {
var yo = (this.buff_height/2|0);
return -(y - yo) / (1.0 * this.pixPerUnit);
});

Clazz.newMeth(C$, 'startDrawCoord$I$I', function (x, y) {
this.applet.stop();
this.xCoord = x;
this.yCoord = y;
this.showCoord = true;
this.repaint();
});

Clazz.newMeth(C$, 'paintCoords$java_awt_Graphics', function (g) {
g.clearRect$I$I$I$I(8, this.buff_height - 30, 150, 20);
g.drawString$S$I$I("X: " + new Double(p$.pixToX$I.apply(this, [this.xCoord])).toString() + "  Y: " + new Double(p$.pixToY$I.apply(this, [this.yCoord])).toString() , 10, this.buff_height - 15);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).red);
g.drawLine$I$I$I$I(this.xCoord - 10, this.yCoord, this.xCoord + 10, this.yCoord);
g.drawLine$I$I$I$I(this.xCoord, this.yCoord - 10, this.xCoord, this.yCoord + 10);
});

Clazz.newMeth(C$, 'endDrawCoord$I$I', function (x, y) {
this.applet.start();
this.showCoord = false;
this.repaint();
});

Clazz.newMeth(C$, 'drawCoord$I$I', function (x, y) {
this.xCoord = x;
this.yCoord = y;
if (this.showCoord) {
var g = this.getGraphics();
this.paint$java_awt_Graphics(g);
g.clearRect$I$I$I$I(8, this.buff_height - 30, 150, 20);
g.drawString$S$I$I("X: " + new Double(p$.pixToX$I.apply(this, [this.xCoord])).toString() + "  Y: " + new Double(p$.pixToY$I.apply(this, [this.yCoord])).toString() , 10, this.buff_height - 15);
g.setColor$java_awt_Color((I$[5]||$incl$(5)).red);
g.drawLine$I$I$I$I(this.xCoord - 10, this.yCoord, this.xCoord + 10, this.yCoord);
g.drawLine$I$I$I$I(this.xCoord, this.yCoord - 10, this.xCoord, this.yCoord + 10);
g.dispose();
}});

Clazz.newMeth(C$, 'mouseDown$java_awt_Event$I$I', function (evt, x, y) {
if (((evt.modifiers & 4) != 0) || ((evt.modifiers & 8) != 0) ) {
return false;
}this.startDrawCoord$I$I(x, y);
return true;
});

Clazz.newMeth(C$, 'mouseUp$java_awt_Event$I$I', function (evt, x, y) {
if (((evt.modifiers & 4) != 0) || ((evt.modifiers & 8) != 0) ) {
return false;
}this.endDrawCoord$I$I(x, y);
return true;
});

Clazz.newMeth(C$, 'mouseDrag$java_awt_Event$I$I', function (evt, x, y) {
if (((evt.modifiers & 4) != 0) || ((evt.modifiers & 8) != 0) ) {
return false;
}this.drawCoord$I$I(x, y);
return true;
});

Clazz.newMeth(C$);
})();
//Created 2018-03-16 05:18:34
