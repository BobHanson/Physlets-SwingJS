(function(){var P$=Clazz.newPackage("dataGraph"),p$1={},I$=[[0,'edu.davidson.graphics.EtchedBorder','java.awt.Panel','edu.davidson.display.SNumber','java.awt.Label','java.awt.BorderLayout','java.awt.FlowLayout']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "DataListener", null, 'edu.davidson.tools.SApplet', 'edu.davidson.tools.SDataListener');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.$isStandalone=false;
this.numFields=0;
this.etchedBorder1=null;
this.panel1=null;
this.panel2=null;
this.fField=null;
this.gField=null;
this.label1=null;
this.label2=null;
this.borderLayout1=null;
this.borderLayout2=null;
this.borderLayout3=null;
this.flowLayout1=null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.$isStandalone=false;
this.etchedBorder1=Clazz.new_(Clazz.load('edu.davidson.graphics.EtchedBorder'));
this.panel1=Clazz.new_(Clazz.load('java.awt.Panel'));
this.panel2=Clazz.new_($I$(2));
this.fField=Clazz.new_(Clazz.load('edu.davidson.display.SNumber'));
this.gField=Clazz.new_($I$(3));
this.label1=Clazz.new_(Clazz.load('java.awt.Label'));
this.label2=Clazz.new_($I$(4));
this.borderLayout1=Clazz.new_(Clazz.load('java.awt.BorderLayout'));
this.borderLayout2=Clazz.new_($I$(5));
this.borderLayout3=Clazz.new_($I$(5));
this.flowLayout1=Clazz.new_(Clazz.load('java.awt.FlowLayout'));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty$S$S(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
try {
this.numFields=Integer.parseInt$S(this.getParameter$S$S("NumFields", "2"));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
try {
p$1.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
edu.davidson.tools.SApplet.addDataListener$O(this);
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
});

Clazz.newMeth(C$, ['getOwner$','getOwner'], function () {
return this;
});

Clazz.newMeth(C$, 'jbInit', function () {
this.panel1.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.panel2.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.fField.setText$S("0");
this.gField.setText$S("0");
this.label1.setAlignment$I(1);
this.label1.setText$S("Func. 2 =");
this.label2.setAlignment$I(1);
this.label2.setText$S("Func. 1 =");
this.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.add$java_awt_Component$O(this.etchedBorder1, null);
this.etchedBorder1.add$java_awt_Component$O(this.panel1, "West");
this.panel1.add$java_awt_Component$O(this.label2, "West");
this.panel1.add$java_awt_Component$O(this.fField, "Center");
this.etchedBorder1.add$java_awt_Component$O(this.panel2, "East");
this.panel2.add$java_awt_Component$O(this.label1, "West");
this.panel2.add$java_awt_Component$O(this.gField, "Center");
}, p$1);

Clazz.newMeth(C$, ['start$','start'], function () {
});

Clazz.newMeth(C$, ['stop$','stop'], function () {
});

Clazz.newMeth(C$, ['getAppletInfo$','getAppletInfo'], function () {
return "Applet Information";
});

Clazz.newMeth(C$, ['getParameterInfo$','getParameterInfo'], function () {
var pinfo=Clazz.array(String, -2, [Clazz.array(String, -1, ["NumFields", "int", "Number of output fields.  Must be 1 or 2."])]);
return pinfo;
});

Clazz.newMeth(C$, ['addDatum$I$D$D','addDatum'], function (id, x, y) {
this.fField.setValue$D(x);
this.gField.setValue$D(y);
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, x, y) {
this.addDatum$I$D$D(id, x, y);
});

Clazz.newMeth(C$, ['addData$I$DA$DA','addData'], function (id, x, y) {
var n=x.length;
this.fField.setValue$D(x[n - 1]);
this.gField.setValue$D(y[n - 1]);
});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
this.addData$I$DA$DA(id, x, y);
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.fField.setValue$D(0);
this.gField.setValue$D(0);
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
this.fField.setValue$D(0);
this.gField.setValue$D(0);
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:17 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
