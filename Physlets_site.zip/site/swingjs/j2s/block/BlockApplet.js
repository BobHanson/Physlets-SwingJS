(function(){var P$=Clazz.newPackage("block"),I$=[[0,'java.awt.Panel','java.awt.Button','java.awt.TextField','block.Block','java.awt.Color']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "BlockApplet", null, 'java.applet.Applet');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.mouseP=null;
this.anim=null;
this.cg=null;
this.area=null;
this.cnt=0;
this.b=null;
this.bc=null;
this.bgColor=null;
this.rts=null;
this.STR=null;
this.offset=0;
this.xMax=0;
this.id=0;
this.xs=0;
this.moving=false;
this.cgStatus=false;
this.offImage=null;
this.g=null;
this.yoffset=0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['init$','init'], function () {
this.setSize$I$I(700, 600);
this.setBackground$java_awt_Color(this.bgColor);
for (var i=0; i < this.STR.length; ++i) {
if ((this.rts=this.getParameter$S(this.STR[i])) != null ) {
this.STR[i]= String.instantialize(this.rts);
}}
var panel=Clazz.new_(Clazz.load('java.awt.Panel'));
panel.add$java_awt_Component(this.cg=Clazz.new_(Clazz.load('java.awt.Button').c$$S,[this.STR[0]]));
panel.add$java_awt_Component(this.mouseP=Clazz.new_(Clazz.load('java.awt.TextField').c$$S$I,["0 , 0", 10]));
panel.add$java_awt_Component(Clazz.new_($I$(2).c$$S,[this.STR[2]]));
this.add$S$java_awt_Component("North", panel);
this.setBackground$java_awt_Color(this.bgColor);
for (var j=0; j < this.cnt; ++j) {
this.b[j]=Clazz.new_(Clazz.load('block.Block'));
}
this.reset$Z(true);
});

Clazz.newMeth(C$, ['action$java_awt_Event$O','action'], function (event, o) {
if (Clazz.instanceOf(event.target, "java.awt.Button")) {
var s=o;
if (s.equals$O(this.STR[2])) {
this.reset$Z(true);
} else if (s.equals$O(this.STR[1])) {
this.cgState$Z(false);
this.cg.setLabel$S(this.STR[0]);
} else if (s.equals$O(this.STR[0])) {
this.cgState$Z(true);
this.cg.setLabel$S(this.STR[1]);
}}return true;
});

Clazz.newMeth(C$, ['reset$Z','reset'], function (b) {
this.area=this.size$();
var area=this.area;
area.height-=this.yoffset;
$I$(4).width=120;
this.xMax=0;
for (var i=1; i < this.cnt; ++i) {
this.xMax+=($I$(4).width/i|0);
}
this.xMax=(this.xMax/(2)|0);
$I$(4).height=(this.area.height/(this.cnt + 1)|0);
this.offset=-$I$(4).width / 2.0;
var n=this.area.height - $I$(4).height;
if (b) {
this.b[0].init$I$I(0, n);
for (var j=1; j < this.cnt; ++j) {
n-=$I$(4).height;
this.b[j].init$I$I(0, n);
this.bc[j]=this.offset;
}
} else {
for (var k=0; k < this.cnt; ++k, n-=$I$(4).height) {
this.b[k].changeY$I(n);
}
}this.repaint$();
});

Clazz.newMeth(C$, ['mouseDown$java_awt_Event$I$I','mouseDown'], function (event, xs, n) {
if ((n-=this.yoffset) < 0) {
return true;
}this.xs=xs;
this.id=1;
while (this.id < this.cnt){
if (this.b[this.id].inside$I$I(xs, n)) {
return this.moving=true;
}++this.id;
}
this.id=0;
this.repaint$();
return true;
});

Clazz.newMeth(C$, ['mouseDrag$java_awt_Event$I$I','mouseDrag'], function (event, xs, n) {
if ((n-=this.yoffset) < 0) {
return true;
}var n2=xs - this.xs;
if (this.moving) {
var i;
for (i=this.id; i < this.cnt; ++i) {
this.b[i].moveX$I(n2);
}
--i;
this.bc[i]=this.b[i].x + this.offset;
for (var j=this.cnt - 2; j > 0; --j) {
this.bc[j]=(this.bc[j + 1] * (this.cnt - j - 1 ) + this.b[j].x + this.offset) / (this.cnt - j);
}
this.writeText$I$I(this.xs=xs, n);
this.repaint$();
}return true;
});

Clazz.newMeth(C$, ['mouseUp$java_awt_Event$I$I','mouseUp'], function (event, n, n2) {
if ((n2-=this.yoffset) < 0) {
return true;
}if (this.moving) {
this.repaint$();
}this.moving=false;
return true;
});

Clazz.newMeth(C$, 'writeText$I$I', function (n, n2) {
this.mouseP.setText$S(String.valueOf$I(n) + " , " + String.valueOf$I(this.b[0].y - n2) );
});

Clazz.newMeth(C$, ['mouseMove$java_awt_Event$I$I','mouseMove'], function (event, n, n2) {
if ((n2-=this.yoffset) < 0) {
return true;
}this.writeText$I$I(n, n2);
return true;
});

Clazz.newMeth(C$, 'cgState$Z', function (cgStatus) {
this.cgStatus=cgStatus;
this.repaint$();
});

Clazz.newMeth(C$, ['paint$java_awt_Graphics','paint'], function (g) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
this.updateScreen$java_awt_Graphics(g);
});

Clazz.newMeth(C$, ['updateScreen$java_awt_Graphics','updateScreen'], function (graphics) {
var y=this.b[0].y;
if (this.g == null ) {
this.offImage=this.createImage$I$I(this.area.width, this.area.height);
this.g=this.offImage.getGraphics$();
$I$(4).g=this.g;
}this.g.setColor$java_awt_Color(this.getBackground$());
this.g.fillRect$I$I$I$I(0, 0, this.area.width, this.area.height);
this.g.setColor$java_awt_Color(Clazz.load('java.awt.Color').black);
this.g.drawRect$I$I$I$I(0, 0, this.area.width - 1, this.area.height - 1);
var n=($I$(4).height/5|0);
var n2=($I$(4).width/10|0);
this.g.fillRect$I$I$I$I(0, y, $I$(4).width + 1, n);
this.g.fillRect$I$I$I$I(n2, y + n, n, $I$(4).height - n);
this.g.fillRect$I$I$I$I($I$(4).width - 2 * n2, y + n, n, $I$(4).height - n);
this.g.drawString$S$I$I(String.valueOf$I($I$(4).width), $I$(4).width, this.b[0].y + ($I$(4).height/2|0));
var color=$I$(5).green;
for (var i=1; i < this.cnt; ++i) {
if (color === $I$(5).green ) {
var n3=this.b[i - 1].x - this.bc[i];
if (n3 > 0.0 ) {
color=$I$(5).green;
} else if (n3 == 0.0 ) {
color=$I$(5).yellow;
} else {
color=$I$(5).red;
}}this.b[i].draw$java_awt_Color(color);
}
for (var j=this.cnt - 1; j > 0; --j) {
if (this.cgStatus) {
var n4=(this.bc[j]|0) + $I$(4).width;
var n5=((this.b[this.cnt - 1].y + this.b[j].y + $I$(4).height )/2|0);
this.g.setColor$java_awt_Color($I$(5).black);
this.g.drawOval$I$I$I$I(n4 - 2, n5 - 2, 4, 4);
var n6=n5 + ((this.cnt - j) * $I$(4).height/2|0);
this.g.drawLine$I$I$I$I(n4, n6, n4, n6 - ((this.cnt - j) * $I$(4).height/2|0));
this.g.drawLine$I$I$I$I(n4, n6, n4 - 3, n6 - 3);
this.g.drawLine$I$I$I$I(n4, n6, n4 + 3, n6 - 3);
this.g.drawString$S$I$I(this.d2String$D(this.bc[j] + $I$(4).width), n4, n6);
}}
var n7=(this.b[this.cnt - 1].x/this.xMax|0);
if (n7 == 1.0  && color !== $I$(5).red  ) {
this.g.setColor$java_awt_Color($I$(5).red);
var n8=this.b[1].x + $I$(4).width + 30 ;
var n9=this.b[0].y - 10;
this.g.setColor$java_awt_Color($I$(5).blue);
this.g.drawOval$I$I$I$I(n8, n9, 2, 2);
var n10=n8 - 10;
this.g.drawOval$I$I$I$I(n10, n9, 2, 2);
this.g.drawArc$I$I$I$I$I$I(n10, n9, 12, 12, -132, 92);
this.g.drawString$S$I$I(this.STR[3], n10 + 20, n9 + 10);
}if (color === $I$(5).red ) {
n7=0.0;
}this.g.drawString$S$I$I(this.d2String$D(n7 * 100.0) + "%", this.b[this.cnt - 1].x + $I$(4).width + 5 , this.b[this.cnt - 1].y);
graphics.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.offImage, 0, this.yoffset, this);
});

Clazz.newMeth(C$, 'd2String$D', function (n) {
var s=String.valueOf$F((((100.0 * n)|0) / 100.0));
if (s.indexOf$S(".") == -1) {
s += ".0";
}return s;
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
this.cnt=5;
this.b=Clazz.array($I$(4), [this.cnt]);
this.bc=Clazz.array(Double.TYPE, [this.cnt]);
this.bgColor=Clazz.new_($I$(5).c$$I$I$I,[200, 223, 208]);
this.STR=Clazz.array(String, -1, ["SHOW", "HIDE", "RESET", "MSG"]);
this.id=0;
this.xs=0;
this.moving=false;
this.cgStatus=false;
this.g=null;
this.yoffset=40;
}, 1);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:11 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
