(function(){var P$=Clazz.newPackage("filters"),I$=[['edu.davidson.graphics.EtchedBorder','java.awt.Panel','java.awt.Button','java.awt.BorderLayout','java.awt.Label','java.awt.TextField','edu.davidson.display.VerticalFlowLayout','edu.davidson.display.SInteger','edu.davidson.display.SNumber','java.awt.FlowLayout','java.awt.Choice','Boolean','filters.FFT$1','filters.FFT$2','edu.davidson.numerics.Parser','filters.FFTransform','java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "FFT", null, 'edu.davidson.tools.SApplet', ['edu.davidson.tools.SDataListener', 'edu.davidson.tools.SDataSource']);
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.transformMode = 0;
this.$isStandalone = false;
this.fftPts = 0;
this.showControls = false;
this.funcStr = null;
this.transformType = null;
this.xmin = 0;
this.xmax = 0;
this.$x = null;
this.$y = null;
this.fft = null;
this.$function = null;
this.varStrings = null;
this.variables = null;
this.etchedBorder1 = null;
this.panel1 = null;
this.transBtn = null;
this.panel2 = null;
this.borderLayout1 = null;
this.label1 = null;
this.panel4 = null;
this.funcField = null;
this.borderLayout2 = null;
this.verticalFlowLayout1 = null;
this.borderLayout3 = null;
this.paramPanel = null;
this.label3 = null;
this.panel6 = null;
this.ptsField = null;
this.label4 = null;
this.panel7 = null;
this.minField = null;
this.label5 = null;
this.panel8 = null;
this.maxField = null;
this.flowLayout1 = null;
this.flowLayout2 = null;
this.choice = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.transformMode = 0;
this.$isStandalone = false;
this.fftPts = 128;
this.$x = Clazz.array(Double.TYPE, [this.fftPts + 1]);
this.$y = Clazz.array(Double.TYPE, [this.fftPts + 1]);
this.fft = Clazz.array(Double.TYPE, [this.fftPts + 1]);
this.$function = null;
this.varStrings = Clazz.array(java.lang.String, -1, ["x", "y", "n", "fft"]);
this.variables = Clazz.array(Double.TYPE, [this.fftPts, 4]);
this.etchedBorder1 = Clazz.new_((I$[1]||$incl$(1)));
this.panel1 = Clazz.new_((I$[2]||$incl$(2)));
this.transBtn = Clazz.new_((I$[3]||$incl$(3)));
this.panel2 = Clazz.new_((I$[2]||$incl$(2)));
this.borderLayout1 = Clazz.new_((I$[4]||$incl$(4)));
this.label1 = Clazz.new_((I$[5]||$incl$(5)));
this.panel4 = Clazz.new_((I$[2]||$incl$(2)));
this.funcField = Clazz.new_((I$[6]||$incl$(6)));
this.borderLayout2 = Clazz.new_((I$[4]||$incl$(4)));
this.verticalFlowLayout1 = Clazz.new_((I$[7]||$incl$(7)));
this.borderLayout3 = Clazz.new_((I$[4]||$incl$(4)));
this.paramPanel = Clazz.new_((I$[1]||$incl$(1)));
this.label3 = Clazz.new_((I$[5]||$incl$(5)));
this.panel6 = Clazz.new_((I$[2]||$incl$(2)));
this.ptsField = Clazz.new_((I$[8]||$incl$(8)));
this.label4 = Clazz.new_((I$[5]||$incl$(5)));
this.panel7 = Clazz.new_((I$[2]||$incl$(2)));
this.minField = Clazz.new_((I$[9]||$incl$(9)));
this.label5 = Clazz.new_((I$[5]||$incl$(5)));
this.panel8 = Clazz.new_((I$[2]||$incl$(2)));
this.maxField = Clazz.new_((I$[9]||$incl$(9)));
this.flowLayout1 = Clazz.new_((I$[10]||$incl$(10)));
this.flowLayout2 = Clazz.new_((I$[10]||$incl$(10)));
this.choice = Clazz.new_((I$[11]||$incl$(11)));
}, 1);

Clazz.newMeth(C$, ['getParameter$S$S','getParameter'], function (key, def) {
return this.$isStandalone ? System.getProperty(key, def) : (this.getParameter$S(key) != null  ? this.getParameter$S(key) : def);
});

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
try {
this.fftPts=Integer.parseInt(this.getParameter$S$S("NumPts", "256"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls=(I$[12]||$incl$(12)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.funcStr=this.getParameter$S$S("Function", "sin(pi*x)");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.transformType=this.getParameter$S$S("Type", "Real");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xmin=Double.$valueOf(this.getParameter$S$S("XMin", "0")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.xmax=Double.$valueOf(this.getParameter$S$S("XMax", "1")).doubleValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.choice.addItem$S("Real");
this.choice.addItem$S("Sin");
this.choice.addItem$S("Cos");
this.transformType=this.transformType.toLowerCase();
if (this.transformType.equals$O("sin")) {
this.choice.select$S("Sin");
this.transformMode=1;
} else if (this.transformType.equals$O("cos")) {
this.choice.select$S("Cos");
this.transformMode=2;
} else if (this.transformType.equals$O("real")) {
this.choice.select$S("Real");
this.transformMode=0;
}this.ptsField.setValue$I(this.fftPts);
this.funcField.setText$S(this.funcStr);
this.minField.setValue$D(this.xmin);
this.maxField.setValue$D(this.xmax);
this.variables=Clazz.array(Double.TYPE, [this.fftPts, 4]);
this.$x=Clazz.array(Double.TYPE, [this.fftPts + 1]);
this.$y=Clazz.array(Double.TYPE, [this.fftPts + 1]);
this.fft=Clazz.array(Double.TYPE, [this.fftPts + 1]);
p$.parseFunction.apply(this, []);
this.packRealData$I(this.ptsField.getValue());
edu.davidson.tools.SApplet.addDataListener$O(this);
edu.davidson.tools.SApplet.addDataSource$O(this);
this.doFFT();
});

Clazz.newMeth(C$, 'jbInit', function () {
this.transBtn.setLabel$S("FFT");
this.transBtn.addActionListener$java_awt_event_ActionListener(((
(function(){var C$=Clazz.newClass(P$, "FFT$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['actionPerformed$java_awt_event_ActionEvent','actionPerformed'], function (e) {
this.b$['filters.FFT'].transBtn_actionPerformed$java_awt_event_ActionEvent(e);
});
})()
), Clazz.new_((I$[13]||$incl$(13)).$init$, [this, null])));
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.label1.setAlignment$I(2);
this.label1.setText$S("F(x)=");
this.panel2.setLayout$java_awt_LayoutManager(this.borderLayout2);
this.funcField.setText$S("textField1");
this.panel4.setLayout$java_awt_LayoutManager(this.verticalFlowLayout1);
this.etchedBorder1.setLayout$java_awt_LayoutManager(this.borderLayout3);
this.label3.setText$S("# Pts");
this.label3.setAlignment$I(2);
this.ptsField.setColumns$I(5);
this.label4.setText$S("Min");
this.label4.setAlignment$I(2);
this.minField.setColumns$I(5);
this.minField.setValue$D(-1.0);
this.label5.setText$S("Max");
this.label5.setAlignment$I(2);
this.maxField.setColumns$I(5);
this.maxField.setValue$D(1.0);
this.panel6.setLayout$java_awt_LayoutManager(this.flowLayout1);
this.paramPanel.setLayout$java_awt_LayoutManager(this.flowLayout2);
this.choice.addItemListener$java_awt_event_ItemListener(((
(function(){var C$=Clazz.newClass(P$, "FFT$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ItemListener', 1);

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['itemStateChanged$java_awt_event_ItemEvent','itemStateChanged'], function (e) {
this.b$['filters.FFT'].choice_itemStateChanged$java_awt_event_ItemEvent(e);
});
})()
), Clazz.new_((I$[14]||$incl$(14)).$init$, [this, null])));
this.add$java_awt_Component$O(this.etchedBorder1, "North");
this.etchedBorder1.add$java_awt_Component$O(this.panel1, "West");
this.panel1.add$java_awt_Component$O(this.transBtn, null);
this.etchedBorder1.add$java_awt_Component$O(this.panel2, "Center");
this.panel2.add$java_awt_Component$O(this.label1, "West");
this.panel2.add$java_awt_Component$O(this.panel4, "Center");
this.panel4.add$java_awt_Component$O(this.funcField, null);
this.add$java_awt_Component$O(this.paramPanel, "South");
this.paramPanel.add$java_awt_Component$O(this.choice, null);
this.paramPanel.add$java_awt_Component$O(this.panel7, null);
this.panel7.add$java_awt_Component$O(this.label4, null);
this.panel7.add$java_awt_Component$O(this.minField, null);
this.paramPanel.add$java_awt_Component$O(this.panel8, null);
this.panel8.add$java_awt_Component$O(this.label5, null);
this.panel8.add$java_awt_Component$O(this.maxField, null);
this.paramPanel.add$java_awt_Component$O(this.panel6, null);
this.panel6.add$java_awt_Component$O(this.label3, null);
this.panel6.add$java_awt_Component$O(this.ptsField, null);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Applet Information";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["NumPts", "int", "Number of points"]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show the unser interface."]), Clazz.array(java.lang.String, -1, ["Function", "String", "Function string"]), Clazz.array(java.lang.String, -1, ["Type", "String", "Type of tranform"]), Clazz.array(java.lang.String, -1, ["XMin", "double", "Minimum value for x"]), Clazz.array(java.lang.String, -1, ["XMax", "double", "Maximum value for x"])]);
return pinfo;
});

Clazz.newMeth(C$, 'parseFunction', function () {
this.funcStr=this.funcStr.trim();
this.funcStr=this.funcStr.toLowerCase();
this.$function=Clazz.new_((I$[15]||$incl$(15)).c$$I,[1]);
this.$function.defineVariable$I$S(1, "x");
this.$function.define$S(this.funcStr);
this.$function.parse();
if (this.$function.getErrorCode() != 0) {
System.out.println$S("Failed to parse the function in FFT: " + this.funcStr);
System.out.println$S("Parse error: " + this.$function.getErrorString() + " at function 1, position " + this.$function.getErrorPosition() );
this.$function=null;
return false;
}return true;
});

Clazz.newMeth(C$, 'sinTransform', function () {
(I$[16]||$incl$(16)).sinft$DA$I$I(this.fft, this.fftPts, 1);
for (var n = 0; n < this.fftPts - 1; n++) {
this.variables[n][2]=n + 1;
this.variables[n][3]=2 * this.fft[n + 2] / this.fftPts;
}
this.variables[this.fftPts - 1][2]=this.fftPts;
this.variables[this.fftPts - 1][3]=0;
this.updateDataConnections();
});

Clazz.newMeth(C$, 'cosTransform', function () {
(I$[16]||$incl$(16)).cosft$DA$I$I(this.fft, this.fftPts, 1);
for (var n = 0; n < this.fftPts - 1; n++) {
this.variables[n][2]=n + 1;
this.variables[n][3]=2 * this.fft[n + 2] / this.fftPts;
}
this.variables[this.fftPts - 1][2]=this.fftPts;
this.variables[this.fftPts - 1][3]=0;
this.updateDataConnections();
});

Clazz.newMeth(C$, 'realTransform', function () {
var cosTemp;
var sinTemp;
(I$[16]||$incl$(16)).realft$DA$I$I(this.fft, (this.fftPts/2|0), 1);
for (var n = 2; n < (this.fftPts/2|0); n++) {
cosTemp=this.fft[2 * n - 1];
sinTemp=this.fft[2 * n];
this.variables[n - 2][2]=n - 1;
this.variables[n - 2][3]=2 * Math.sqrt(cosTemp * cosTemp + sinTemp * sinTemp) / this.fftPts;
}
for (var n = (this.fftPts/2|0); n < this.fftPts; n++) {
this.variables[n - 2][2]=n - 1;
this.variables[n - 2][3]=0;
}
this.updateDataConnections();
});

Clazz.newMeth(C$, ['packRealData$I','packRealData'], function (numPts) {
var h = (this.xmax - this.xmin) / (numPts - 1);
for (var i = 1; i <= this.fftPts; i++) {
this.$x[i]=(i - 1) * h + this.xmin;
this.$y[i]=this.$function.evaluate$D(this.$x[i]);
this.fft[i]=this.$y[i];
this.variables[i - 1][0]=this.$x[i];
this.variables[i - 1][1]=this.$y[i];
}
});

Clazz.newMeth(C$, ['addDatum$edu_davidson_tools_SDataSource$I$D$D','addDatum'], function (s, id, x, y) {
if (this.$function == null  && this.funcStr != null  ) p$.parseFunction.apply(this, []);
this.updateDataConnections();
});

Clazz.newMeth(C$, ['addData$edu_davidson_tools_SDataSource$I$DA$DA','addData'], function (s, id, x, y) {
if (this.$function == null  && this.funcStr != null  ) p$.parseFunction.apply(this, []);
this.ptsField.setValue$I(x.length);
this.xmin=x[0];
this.minField.setValue$D(this.xmin);
var newPts = p$.calcPoints$I.apply(this, [x.length]);
this.xmax=x[newPts];
this.maxField.setValue$D(this.xmax);
if (newPts != this.fftPts) {
this.fftPts=newPts;
this.variables=Clazz.array(Double.TYPE, [this.fftPts, 4]);
this.$x=Clazz.array(Double.TYPE, [this.fftPts + 1]);
this.$y=Clazz.array(Double.TYPE, [this.fftPts + 1]);
this.fft=Clazz.array(Double.TYPE, [this.fftPts + 1]);
}for (var i = 1; i <= this.fftPts; i++) {
this.$x[i]=x[i];
this.$y[i]=y[i];
this.fft[i]=y[i];
this.variables[i - 1][0]=x[i];
this.variables[i - 1][1]=y[i];
}
switch (this.transformMode) {
case 0:
p$.realTransform.apply(this, []);
break;
case 1:
p$.sinTransform.apply(this, []);
break;
case 2:
p$.cosTransform.apply(this, []);
break;
}
this.updateDataConnections();
});

Clazz.newMeth(C$, ['deleteSeries$I','deleteSeries'], function (id) {
this.reset();
});

Clazz.newMeth(C$, ['clearSeries$I','clearSeries'], function (id) {
this.reset();
});

Clazz.newMeth(C$, 'getVariables', function () {
return this.variables;
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, ['setOwner$edu_davidson_tools_SApplet','setOwner'], function (owner) {
;});

Clazz.newMeth(C$, 'getOwner', function () {
return this;
});

Clazz.newMeth(C$, 'calcPoints$I', function (n) {
n=Math.max(1, n);
var pts = 1;
while (n >= pts)pts*=2;

return (pts/2|0);
});

Clazz.newMeth(C$, ['setFunction$S','setFunction'], function (str) {
this.funcStr=str;
this.funcField.setText$S(str);
if (!p$.parseFunction.apply(this, [])) {
this.funcField.setBackground$java_awt_Color((I$[17]||$incl$(17)).red);
return false;
}this.funcField.setBackground$java_awt_Color((I$[17]||$incl$(17)).white);
return true;
});

Clazz.newMeth(C$, ['setTransformType$S','setTransformType'], function (tt) {
this.transformType=tt;
this.transformType=this.transformType.toLowerCase();
if (this.transformType.equals$O("sin")) {
this.choice.select$S("Sin");
this.transformMode=1;
} else if (this.transformType.equals$O("cos")) {
this.choice.select$S("Cos");
this.transformMode=2;
} else {
this.transformType="real";
this.choice.select$S("Real");
this.transformMode=0;
}});

Clazz.newMeth(C$, 'doFFT', function () {
var newPts = this.ptsField.getValue();
newPts=p$.calcPoints$I.apply(this, [newPts]);
if (newPts != this.fftPts) {
this.fftPts=newPts;
this.variables=Clazz.array(Double.TYPE, [this.fftPts, 4]);
this.$x=Clazz.array(Double.TYPE, [this.fftPts + 1]);
this.$y=Clazz.array(Double.TYPE, [this.fftPts + 1]);
this.fft=Clazz.array(Double.TYPE, [this.fftPts + 1]);
}if (!p$.parseFunction.apply(this, [])) {
this.funcField.setBackground$java_awt_Color((I$[17]||$incl$(17)).red);
return;
} else this.funcField.setBackground$java_awt_Color((I$[17]||$incl$(17)).white);
switch (this.transformMode) {
case 0:
this.packRealData$I(this.ptsField.getValue());
p$.realTransform.apply(this, []);
break;
case 1:
this.packRealData$I(this.ptsField.getValue());
p$.sinTransform.apply(this, []);
break;
case 2:
this.packRealData$I(this.ptsField.getValue());
p$.cosTransform.apply(this, []);
break;
}
});

Clazz.newMeth(C$, 'transBtn_actionPerformed$java_awt_event_ActionEvent', function (e) {
this.xmax=this.maxField.getValue();
this.xmin=this.minField.getValue();
this.funcStr=this.funcField.getText();
this.doFFT();
});

Clazz.newMeth(C$, 'choice_itemStateChanged$java_awt_event_ItemEvent', function (e) {
if (this.choice.getSelectedItem().equals$O("Real")) this.transformMode=0;
 else if (this.choice.getSelectedItem().equals$O("Sin")) this.transformMode=1;
 else this.transformMode=2;
});
})();
//Created 2018-07-20 18:09:32
