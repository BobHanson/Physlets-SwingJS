(function(){var P$=Clazz.newPackage("faraday"),I$=[['java.awt.Font','edu.davidson.numerics.Parser','edu.davidson.display.Format','java.util.Vector','faraday.Schematic_mouseMotionAdapter','faraday.Schematic_mouseAdapter','java.awt.Color','java.awt.Dimension','edu.davidson.graphics.Util','java.awt.Cursor']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Schematic", null, 'a2s.Panel', 'edu.davidson.display.SScalable');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.f = null;
this.message = null;
this.varStrings = null;
this.posFunc = null;
this.checkFunc = null;
this.fieldFunc = null;
this.explicitTime = false;
this.zmin = 0;
this.zmax = 0;
this.autoscalez = false;
this.backgroundInvalid = false;
this.osiInvalid = false;
this.fieldValues = null;
this.showCurrentArrow = false;
this.showMeter = false;
this.showTime = false;
this.coordDisplay = false;
this.dragThing = null;
this.iwidth = 0;
this.iheight = 0;
this.format = null;
this.backgroundOSI = null;
this.osi = null;
this.fillApplet = false;
this.pixPerUnit = 0;
this.showSchematic = false;
this.showGrid = false;
this.showColor = false;
this.showBOnDrag = false;
this.xOffset = 0;
this.yOffset = 0;
this.things = null;
this.boxWidth = 0;
this.metermin = 0;
this.metermax = 0;
this.time = 0;
this.dragMode = false;
this.preferredWidth = 0;
this.mouseX = 0;
this.mouseY = 0;
this.$mouseDown = false;
this.owner = null;
this.defaultCircuit = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.f = Clazz.new_((I$[1]||$incl$(1)).c$$S$I$I,["Helvetica", 1, 12]);
this.message = null;
this.varStrings = Clazz.array(java.lang.String, -1, ["t", "x", "v", "f"]);
this.posFunc = Clazz.new_((I$[2]||$incl$(2)).c$$I,[1]);
this.checkFunc = Clazz.new_((I$[2]||$incl$(2)).c$$I,[1]);
this.fieldFunc = Clazz.new_((I$[2]||$incl$(2)).c$$I,[2]);
this.explicitTime = true;
this.zmin = -2;
this.zmax = 2;
this.autoscalez = false;
this.backgroundInvalid = true;
this.osiInvalid = true;
this.fieldValues = null;
this.showCurrentArrow = true;
this.showMeter = true;
this.showTime = true;
this.coordDisplay = true;
this.dragThing = null;
this.iwidth = 0;
this.iheight = 0;
this.format = Clazz.new_((I$[3]||$incl$(3)).c$$S,["%-+6.2f"]);
this.backgroundOSI = null;
this.osi = null;
this.fillApplet = false;
this.pixPerUnit = 10;
this.showSchematic = true;
this.showGrid = true;
this.showColor = true;
this.showBOnDrag = false;
this.xOffset = 0;
this.yOffset = 0;
this.things = Clazz.new_((I$[4]||$incl$(4)));
this.boxWidth = 0;
this.metermin = -200;
this.metermax = 200;
this.time = 0;
this.dragMode = true;
this.preferredWidth = 200;
this.mouseX = 0;
this.mouseY = 0;
this.$mouseDown = false;
this.owner = null;
this.defaultCircuit = null;
}, 1);

Clazz.newMeth(C$, 'c$$faraday_Faraday', function (app) {
Clazz.super_(C$, this,1);
this.owner = app;
this.addMouseMotionListener$java_awt_event_MouseMotionListener(Clazz.new_((I$[5]||$incl$(5)).c$$faraday_Schematic,[this]));
this.addMouseListener$java_awt_event_MouseListener(Clazz.new_((I$[6]||$incl$(6)).c$$faraday_Schematic,[this]));
this.setBackground$java_awt_Color(Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I,[224, 224, 224]));
}, 1);

Clazz.newMeth(C$, 'setShowCurrentArrow$Z', function (show) {
this.showCurrentArrow = show;
if ((this.defaultCircuit != null ) && (Clazz.instanceOf(this.defaultCircuit, "faraday.Fluxable")) ) (this.defaultCircuit).setShowCurrentArrow$Z(show);
});

Clazz.newMeth(C$, 'setShowCurrentArrow$I$Z', function (id, show) {
var t = this.getThing$I(id);
if (t != null  && Clazz.instanceOf(t, "faraday.Fluxable") ) (t).setShowCurrentArrow$Z(show);
});

Clazz.newMeth(C$, 'setShowMeter$Z', function (show) {
this.showMeter = show;
if (this.defaultCircuit != null  && Clazz.instanceOf(this.defaultCircuit, "faraday.UWire") ) (this.defaultCircuit).setShowMeter$Z(show);
});

Clazz.newMeth(C$, 'setShowMeter$I$Z', function (id, show) {
var t = this.getThing$I(id);
if (t != null  && Clazz.instanceOf(t, "faraday.UWire") ) (t).setShowMeter$Z(show);
});

Clazz.newMeth(C$, 'addThing$edu_davidson_display_Thing', function (t) {
this.things.addElement$TE(t);
if (this.defaultCircuit == null ) {
this.defaultCircuit = t;
if (this.posFunc != null  && this.posFunc.getFunctionString() != null   && !this.posFunc.getFunctionString().equals$O("") ) {
t.setX$D(this.posFunc.evaluate$D(this.time));
t.updateMySlaves();
if (Clazz.instanceOf(t, "faraday.Fluxable")) (t).doFluxIntegral();
}}if (Clazz.instanceOf(t, "faraday.Fluxable")) (t).setShowCurrentArrow$Z(this.showCurrentArrow);
if (Clazz.instanceOf(t, "faraday.Fluxable")) (t).doFluxIntegral();
if (Clazz.instanceOf(t, "faraday.UWire")) (t).setShowMeter$Z(this.showMeter);
this.osiInvalid = true;
return t.hashCode();
});

Clazz.newMeth(C$, 'getThing$I', function (id) {
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (t.hashCode() == id) {
return t;
}}
return null;
});

Clazz.newMeth(C$, 'update$java_awt_Graphics', function (g) {
if ((this.owner == null ) || ((this.owner != null ) && !this.owner.isClockRunning() ) ) this.paint$java_awt_Graphics(g);
});

Clazz.newMeth(C$, 'getVarStrings', function () {
return this.varStrings;
});

Clazz.newMeth(C$, 'getPixWidth', function () {
return this.iwidth;
});

Clazz.newMeth(C$, 'getPixHeight', function () {
return this.iheight;
});

Clazz.newMeth(C$, 'getFieldValue$I', function (i) {
if (this.fieldValues == null ) return 0;
if ((i < 0) || (i >= this.iwidth) ) {
var x = this.xFromPix$I(i);
return this.fieldFunc.evaluate$D$D(x, this.time);
}return this.fieldValues[i];
});

Clazz.newMeth(C$, 'getFieldValue$D', function (x) {
return this.fieldFunc.evaluate$D$D(x, this.time);
});

Clazz.newMeth(C$, 'xFromPix$I', function (xpix) {
return (xpix - this.xOffset - (this.iwidth/2|0) ) / this.pixPerUnit;
});

Clazz.newMeth(C$, 'yFromPix$I', function (ypix) {
return -(ypix - this.yOffset - (this.iheight/2|0) ) / this.pixPerUnit;
});

Clazz.newMeth(C$, 'pixFromX$D', function (x) {
return ((x * this.pixPerUnit + this.xOffset + (this.iwidth/2|0))|0);
});

Clazz.newMeth(C$, 'pixFromY$D', function (y) {
return ((-y * this.pixPerUnit + this.yOffset + (this.iheight/2|0))|0);
});

Clazz.newMeth(C$, 'setFormat$S', function (str) {
try {
this.format = Clazz.new_((I$[3]||$incl$(3)).c$$S,[str]);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.IllegalArgumentException")){
return false;
} else {
throw e;
}
}
return true;
});

Clazz.newMeth(C$, 'getMinimumSize', function () {
return Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[200, 200]);
});

Clazz.newMeth(C$, 'getPreferredSize', function () {
var a = (I$[9]||$incl$(9)).getApplet$java_awt_Component(this);
if (this.fillApplet && a != null  ) {
return Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[a.getBounds().width - 6, a.getBounds().height]);
} else return Clazz.new_((I$[8]||$incl$(8)).c$$I$I,[this.preferredWidth, this.preferredWidth]);
});

Clazz.newMeth(C$, 'paint', function () {
try {
var g = this.getGraphics();
this.backgroundInvalid = true;
this.paint$java_awt_Graphics(g);
g.dispose();
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
this.osiInvalid = true;
this.backgroundInvalid = true;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
try {
if (!this.showSchematic) {
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
return;
}if (this.getSize().width <= 2 || this.getSize().height <= 2 ) return;
if (this.backgroundOSI == null  || this.backgroundInvalid  || this.iwidth != this.getSize().width  || this.iheight != this.getSize().height ) {
this.paintBackgroundOSI();
this.osiInvalid = true;
}if (this.osiInvalid) {
this.paintOSI();
}g.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
this.paintMessage$java_awt_Graphics$S(g, this.message);
} catch (ex) {
if (Clazz.exceptionOf(ex, "java.lang.Exception")){
this.osiInvalid = true;
this.backgroundInvalid = true;
} else {
throw ex;
}
}
});

Clazz.newMeth(C$, 'paintMessage$java_awt_Graphics$S', function (osg, msg) {
if (msg == null ) return;
var fm = osg.getFontMetrics$java_awt_Font(this.f);
osg.setColor$java_awt_Color((I$[7]||$incl$(7)).yellow);
var w = 15 + fm.stringWidth$S(msg);
osg.fillRect$I$I$I$I(this.iwidth - w - 5 , this.iheight - 15, w, 15);
osg.setColor$java_awt_Color((I$[7]||$incl$(7)).black);
osg.drawString$S$I$I(msg, this.iwidth - w + 2, this.iheight - 3);
});

Clazz.newMeth(C$, 'paintTime', function () {
var g = this.getGraphics();
this.paintTime$java_awt_Graphics(g);
g.dispose();
});

Clazz.newMeth(C$, 'paintTime$java_awt_Graphics', function (g) {
if (!this.showTime) return;
var msg = this.owner.label_time + this.format.form$D(this.time);
g.setColor$java_awt_Color((I$[7]||$incl$(7)).black);
g.drawString$S$I$I(msg, 10, 15);
});

Clazz.newMeth(C$, 'paintGrid$java_awt_Graphics', function (g) {
if (!this.showGrid) return;
var x;
var b;
g.setColor$java_awt_Color((I$[7]||$incl$(7)).gray);
for (var i = 0; i < 1 + (this.iheight/this.pixPerUnit|0); i++) for (var j = 0; j < 1 + (this.iwidth/this.pixPerUnit|0); j++) {
x = this.xFromPix$I(this.pixPerUnit * j);
b = this.fieldFunc.evaluate$D$D(x, this.time);
if (b >= 0 ) g.drawLine$I$I$I$I(this.pixPerUnit * j, this.pixPerUnit * i, this.pixPerUnit * j, this.pixPerUnit * i);
 else {
g.drawLine$I$I$I$I(this.pixPerUnit * j - 2, this.pixPerUnit * i, this.pixPerUnit * j + 2, this.pixPerUnit * i);
g.drawLine$I$I$I$I(this.pixPerUnit * j, this.pixPerUnit * i - 2, this.pixPerUnit * j, this.pixPerUnit * i + 2);
}}

g.setColor$java_awt_Color((I$[7]||$incl$(7)).black);
});

Clazz.newMeth(C$, 'paintBackground$java_awt_Graphics', function (g) {
if (this.fieldValues == null ) return;
var x;
var b;
x = this.xFromPix$I(0);
if (this.fieldFunc == null ) return;
b = this.fieldFunc.evaluate$D$D(x, this.time);
this.fieldValues[0] = b;
var max = b;
var min = b;
for (var j = 1; j < this.iwidth; j++) {
x = this.xFromPix$I(j);
b = this.fieldFunc.evaluate$D$D(x, this.time);
this.fieldValues[j] = b;
if (b > max ) max = b;
if (b < min ) min = b;
}
if (!this.showColor) {
g.setColor$java_awt_Color(Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I,[223, 223, 223]));
g.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
return;
}if (this.autoscalez) {
max = Math.max(0, max);
min = Math.min(0, min);
if (max == min ) {
max = Math.max(2, max);
min = Math.min(-2, min);
}var scale = max - min;
if (scale == 0 ) {
g.setColor$java_awt_Color(this.getBackground());
g.fillRect$I$I$I$I(0, 0, this.iwidth, this.iheight);
return;
}} else {
min = this.zmin;
max = this.zmax;
}for (var j = 0; j < this.iwidth; j++) {
b = this.fieldValues[j];
b = Math.min(b, max);
b = Math.max(b, min);
if (b > 0 ) {
if (max > -min ) b = 255 * b / max;
 else b = -255 * b / min;
g.setColor$java_awt_Color(Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I,[255, 255 - (b|0), 255 - (b|0)]));
g.drawLine$I$I$I$I(j, 0, j, this.iheight);
} else if (b < 0 ) {
if (max > -min ) b = -255 * b / max;
 else b = 255 * b / min;
g.setColor$java_awt_Color(Clazz.new_((I$[7]||$incl$(7)).c$$I$I$I,[255 - (b|0), 255 - (b|0), 255]));
g.drawLine$I$I$I$I(j, 0, j, this.iheight);
} else {
g.setColor$java_awt_Color((I$[7]||$incl$(7)).white);
g.drawLine$I$I$I$I(j, 0, j, this.iheight);
}}
g.setColor$java_awt_Color((I$[7]||$incl$(7)).black);
});

Clazz.newMeth(C$, 'paintThings$java_awt_Graphics', function (g) {
this.owner.lock.getBusyFlag();
for (var i = 0; i < this.things.size(); i++) {
var t = this.things.elementAt$I(i);
t.paint$java_awt_Graphics(g);
}
this.owner.lock.freeBusyFlag();
});

Clazz.newMeth(C$, 'invalidateOSI', function () {
this.osiInvalid = true;
this.backgroundInvalid = true;
});

Clazz.newMeth(C$, 'paintOSI', function () {
if (this.osi == null  || this.iwidth != this.getSize().width  || this.iheight != this.getSize().height ) {
this.backgroundInvalid = true;
return;
}var osg = this.osi.getGraphics();
osg.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.osi, 0, 0, this);
osg.drawImage$java_awt_Image$I$I$java_awt_image_ImageObserver(this.backgroundOSI, 0, 0, this);
this.paintThings$java_awt_Graphics(osg);
this.paintTime$java_awt_Graphics(osg);
if (this.$mouseDown) this.paintCoords$java_awt_Graphics$I$I(osg, this.mouseX, this.mouseY);
osg.dispose();
this.osiInvalid = false;
return;
});

Clazz.newMeth(C$, 'paintBackgroundOSI', function () {
if (this.backgroundOSI == null  || this.iwidth != this.getSize().width  || this.iheight != this.getSize().height ) {
this.iwidth = this.getSize().width;
this.iheight = this.getSize().height;
this.backgroundOSI = this.createImage$I$I(this.iwidth, this.iheight);
this.osi = this.createImage$I$I(this.iwidth, this.iheight);
this.fieldValues = Clazz.array(Double.TYPE, [this.iwidth]);
}var osg = this.backgroundOSI.getGraphics();
this.paintBackground$java_awt_Graphics(osg);
this.paintGrid$java_awt_Graphics(osg);
osg.dispose();
this.updateFlux();
this.backgroundInvalid = false;
return;
});

Clazz.newMeth(C$, 'setDragMode$Z', function (dm) {
this.dragMode = dm;
if (this.defaultCircuit != null ) this.defaultCircuit.setDragable$Z(this.dragMode);
});

Clazz.newMeth(C$, 'setPreferredWidth$I', function (pw) {
this.preferredWidth = pw;
});

Clazz.newMeth(C$, 'setMeterMinMax$D$D', function (min, max) {
this.metermin = min;
this.metermax = max;
if (this.defaultCircuit != null  && Clazz.instanceOf(this.defaultCircuit, "faraday.UWire") ) {
(this.defaultCircuit).meter.min = min;
(this.defaultCircuit).meter.max = max;
}});

Clazz.newMeth(C$, 'setBScale$D$D', function (min, max) {
this.zmin = min;
this.zmax = max;
this.backgroundInvalid = true;
});

Clazz.newMeth(C$, 'step$D$D', function (dt, t) {
this.time = t + dt;
if (this.explicitTime) this.backgroundInvalid = true;
if (!this.dragMode && this.defaultCircuit != null   && this.posFunc != null  ) {
this.defaultCircuit.setX$D(this.posFunc.evaluate$D(this.time));
this.defaultCircuit.updateMySlaves();
}this.paint();
var volt = 0;
if (this.defaultCircuit != null  && Clazz.instanceOf(this.defaultCircuit, "faraday.Fluxable") ) volt = (this.defaultCircuit).getVolt();
this.owner.updateDataConnections();
return volt;
});

Clazz.newMeth(C$, 'setDefaultCircuit$edu_davidson_display_Thing', function (t) {
this.defaultCircuit = t;
if (t != null  && Clazz.instanceOf(t, "faraday.Fluxable") ) this.defaultCircuit = t;
 else {
this.defaultCircuit = null;
return;
}if (this.posFunc != null  && this.posFunc.getFunctionString() != null   && !this.posFunc.getFunctionString().equals$O("") ) {
t.setX$D(this.posFunc.evaluate$D(this.time));
t.updateMySlaves();
(t).doFluxIntegral();
}});

Clazz.newMeth(C$, 'setDefault', function () {
this.time = 0;
this.message = null;
this.defaultCircuit = null;
this.things.removeAllElements();
this.osiInvalid = true;
this.backgroundInvalid = true;
});

Clazz.newMeth(C$, 'resetTime', function () {
this.time = 0;
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (Clazz.instanceOf(t, "faraday.Fluxable")) {
(t).reset();
(t).doFluxIntegral();
}}
this.backgroundInvalid = true;
});

Clazz.newMeth(C$, 'setMessage$S', function (msg) {
if (msg == null  || msg.trim().equals$O("") ) this.message = null;
 else this.message = msg;
if ((this.owner == null ) || ((this.owner != null ) && !this.owner.isClockRunning() ) ) {
this.osiInvalid = true;
this.repaint();
}});

Clazz.newMeth(C$, 'setTime$D', function (t) {
this.time = t;
this.backgroundInvalid = true;
});

Clazz.newMeth(C$, 'checkFieldFunctionForTime$S', function (fieldStr) {
var str =  String.instantialize(fieldStr);
this.checkFunc.defineVariable$I$S(1, "x");
this.checkFunc.define$S(str.toLowerCase());
this.checkFunc.parse();
if (this.checkFunc.getErrorCode() != 0) {
this.explicitTime = true;
}this.explicitTime = false;
});

Clazz.newMeth(C$, 'parseFieldFunction$S', function (fieldStr) {
this.checkFieldFunctionForTime$S(fieldStr);
this.fieldFunc.defineVariable$I$S(1, "x");
this.fieldFunc.defineVariable$I$S(2, "t");
this.fieldFunc.define$S(fieldStr.toLowerCase());
this.fieldFunc.parse();
if (this.fieldFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse field function, B(x,t): " + fieldStr);
System.out.println$S("Parse error: " + this.fieldFunc.getErrorString() + " at B(x,t) function, position " + this.fieldFunc.getErrorPosition() );
return false;
}if (this.defaultCircuit != null  && Clazz.instanceOf(this.defaultCircuit, "faraday.Fluxable") ) {
(this.defaultCircuit).reset();
(this.defaultCircuit).doFluxIntegral();
}this.osiInvalid = true;
this.backgroundInvalid = true;
return true;
});

Clazz.newMeth(C$, 'parsePosFunction$S', function (posStr) {
if (posStr == null  || posStr.equals$O("") ) {
this.posFunc = null;
return true;
}if (this.posFunc == null ) this.posFunc = Clazz.new_((I$[2]||$incl$(2)).c$$I,[1]);
this.posFunc.defineVariable$I$S(1, "t");
this.posFunc.define$S(posStr.toLowerCase());
this.posFunc.parse();
if (this.posFunc.getErrorCode() != 0) {
System.out.println$S("Failed to parse x(t): " + posStr);
System.out.println$S("Parse error: " + this.posFunc.getErrorString() + " at x(t) function, charcter " + this.posFunc.getErrorPosition() );
return false;
}if (this.defaultCircuit != null ) {
if (Clazz.instanceOf(this.defaultCircuit, "faraday.Fluxable")) (this.defaultCircuit).reset();
this.defaultCircuit.setX$D(this.posFunc.evaluate$D(this.time));
this.defaultCircuit.updateMySlaves();
if (Clazz.instanceOf(this.defaultCircuit, "faraday.Fluxable")) (this.defaultCircuit).doFluxIntegral();
}this.osiInvalid = true;
return true;
});

Clazz.newMeth(C$, 'paintCoords$I$I', function (xPix, yPix) {
if (!this.coordDisplay) return;
var g = this.getGraphics();
this.paintCoords$java_awt_Graphics$I$I(g, xPix, yPix);
g.dispose();
});

Clazz.newMeth(C$, 'paintCoords$java_awt_Graphics$I$I', function (g, xPix, yPix) {
if (!this.coordDisplay) return;
var x = (xPix - this.xOffset - (this.iwidth/2|0) ) / this.pixPerUnit;
var y = -(yPix - this.yOffset - (this.iheight/2|0) ) / this.pixPerUnit;
var msg;
msg = "x=" + this.format.form$D(x) + "  y=" + this.format.form$D(y) ;
if (this.showBOnDrag) msg += "  B=" + this.format.form$D(this.fieldFunc.evaluate$D$D(x, this.time));
var r = this.getBounds();
g.setColor$java_awt_Color((I$[7]||$incl$(7)).yellow);
var fm = g.getFontMetrics$java_awt_Font(g.getFont());
this.boxWidth = Math.max(20 + fm.stringWidth$S(msg), this.boxWidth);
g.fillRect$I$I$I$I(0, r.height - 20, this.boxWidth, 20);
g.setColor$java_awt_Color((I$[7]||$incl$(7)).black);
g.drawString$S$I$I(msg, 10, r.height - 5);
});

Clazz.newMeth(C$, 'updateFlux', function () {
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (Clazz.instanceOf(t, "faraday.Fluxable")) (t).doFluxIntegral();
}
});

Clazz.newMeth(C$, 'isInsideDragableThing$I$I', function (x, y) {
var t = null;
for (var e = this.things.elements(); e.hasMoreElements(); ) {
t = e.nextElement();
if (!t.isNoDrag() && t.isInsideThing$I$I(x, y) ) {
return t;
}}
return null;
});

Clazz.newMeth(C$, 'schematic_mousePressed$java_awt_event_MouseEvent', function (e) {
this.$mouseDown = true;
this.mouseX = e.getX();
this.mouseY = e.getY();
if (this.isInsideDragableThing$I$I(this.mouseX, this.mouseY) != null ) {
this.dragThing = this.isInsideDragableThing$I$I(this.mouseX, this.mouseY);
}this.paintCoords$I$I(this.mouseX, this.mouseY);
});

Clazz.newMeth(C$, 'schematic_mouseDragged$java_awt_event_MouseEvent', function (e) {
this.mouseX = e.getX();
this.mouseY = e.getY();
var x;
var y;
var maxPix = this.iwidth;
var minPix = 0;
if (this.mouseX < minPix) this.mouseX = minPix;
 else if (this.mouseX > maxPix - 2) this.mouseX = maxPix - 2;
x = this.xFromPix$I(this.mouseX);
minPix = 0;
maxPix = this.iheight;
if (this.mouseY < minPix) this.mouseY = minPix;
 else if (this.mouseY > maxPix - 2) this.mouseY = maxPix - 2;
y = this.yFromPix$I(this.mouseY);
if (this.dragThing != null ) {
this.owner.lock.getBusyFlag();
this.dragThing.setXY$D$D(x, y);
this.dragThing.updateMySlaves();
this.owner.lock.freeBusyFlag();
if ((this.owner == null ) || ((this.owner != null ) && !this.owner.isClockRunning() ) ) {
if (Clazz.instanceOf(this.dragThing, "faraday.Fluxable")) (this.dragThing).doFluxIntegral();
this.owner.updateDataConnections();
this.osiInvalid = true;
this.paint();
}}if (this.owner != null  && !this.owner.isClockRunning() ) this.paintCoords$I$I(this.mouseX, this.mouseY);
});

Clazz.newMeth(C$, 'schematic_mouseReleased$java_awt_event_MouseEvent', function (e) {
this.$mouseDown = false;
this.dragThing = null;
this.boxWidth = 0;
var r = this.getBounds();
if ((this.owner == null ) || ((this.owner != null ) && !this.owner.isClockRunning() ) ) {
this.osiInvalid = true;
this.repaint();
}});

Clazz.newMeth(C$, 'schematic_mouseEntered$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor((I$[10]||$incl$(10)).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$, 'schematic_mouseExited$java_awt_event_MouseEvent', function (e) {
this.setCursor$java_awt_Cursor((I$[10]||$incl$(10)).getPredefinedCursor$I(0));
});

Clazz.newMeth(C$, 'schematic_mouseMoved$java_awt_event_MouseEvent', function (e) {
var xPix = e.getX();
var yPix = e.getY();
if (this.isInsideDragableThing$I$I(xPix, yPix) != null ) this.setCursor$java_awt_Cursor((I$[10]||$incl$(10)).getPredefinedCursor$I(12));
 else this.setCursor$java_awt_Cursor((I$[10]||$incl$(10)).getPredefinedCursor$I(1));
});

Clazz.newMeth(C$);
})();
//Created 2018-02-24 16:21:06
