(function(){var P$=Clazz.newPackage("circuit"),I$=[['java.awt.Color']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Resistor", null, 'circuit.Part');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I', function (o, c, i1, j1, i2, j2) {
C$.superclazz.c$$edu_davidson_tools_SApplet$circuit_Circuit$I$I$I$I.apply(this, [o, c, i1, j1, i2, j2]);
C$.$init$.apply(this);
this.label = "R";
this.voltRMS = 0;
this.res = 100;
this.showV = true;
this.showR = true;
this.showZ = false;
this.showL = false;
}, 1);

Clazz.newMeth(C$, 'drawLabel$java_awt_Graphics$I$I$I$I', function (g, x, y, xOff, yOff) {
if (this.label == null ) return;
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
if (this.i1 == this.i2) g.drawString$S$I$I(this.label, x - 4, y - 8);
 else if (this.j1 == this.j2) g.drawString$S$I$I(this.label, x - 18, y + 5);
 else g.drawString$S$I$I(this.label, x, y);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$, 'drawSymbol$java_awt_Graphics$I$I$I$I$I', function (g, xx1, yy1, xx2, yy2, s) {
g.setColor$java_awt_Color(this.color);
var x = xx2 - xx1;
var y = -(yy2 - yy1);
var h = Math.sqrt(x * x + y * y);
if (h < 2 ) return;
var w = (h / 2.0 - s / 4.0);
var base_x1 = ((xx1 + (x * w) / h)|0);
var base_y1 = ((yy1 - (y * w) / h)|0);
var base_x2 = ((xx2 - (x * w) / h)|0);
var base_y2 = ((yy2 + (y * w) / h)|0);
g.drawLine$I$I$I$I(xx1, yy1, base_x1, base_y1);
g.drawLine$I$I$I$I(xx2, yy2, base_x2, base_y2);
var x1 = base_x1;
var y1 = base_y1;
var x2 = base_x2;
var y2 = base_y2;
x = x2 - x1;
y = -(y2 - y1);
h = Math.sqrt(x * x + y * y);
var u = (x / 16.0);
var v = -(y / 16.0);
var u0 = 8 * x / h;
var v0 = -8 * y / h;
x2 = ((x1 + u)|0);
y2 = ((y1 + v)|0);
var x3 = (x1 + 2 * u);
var y3 = (y1 + 2 * v);
for (var count = 0; count < 4; count++) {
x2 = ((x2 - v0)|0);
y2 = ((y2 + u0)|0);
g.drawLine$I$I$I$I(((x1)|0), ((y1)|0), ((x2)|0), ((y2)|0));
g.drawLine$I$I$I$I(((x2)|0), ((y2)|0), ((x3)|0), ((y3)|0));
x1 = x3;
y1 = y3;
x2 = x1 + u;
y2 = y1 + v;
x3 = x1 + 2 * u;
y3 = y1 + 2 * v;
x2 = x2 + v0;
y2 = y2 - u0;
g.drawLine$I$I$I$I(((x1)|0), ((y1)|0), ((x2)|0), ((y2)|0));
g.drawLine$I$I$I$I(((x2)|0), ((y2)|0), ((x3)|0), ((y3)|0));
x1 = x3;
y1 = y3;
x2 = x1 + u;
y2 = y1 + v;
x3 = x1 + 2 * u;
y3 = y1 + 2 * v;
}
var oldFont = g.getFont();
g.setFont$java_awt_Font(this.f);
g.setColor$java_awt_Color((I$[1]||$incl$(1)).black);
g.setFont$java_awt_Font(oldFont);
});

Clazz.newMeth(C$);
})();
//Created 2018-03-16 05:18:38
