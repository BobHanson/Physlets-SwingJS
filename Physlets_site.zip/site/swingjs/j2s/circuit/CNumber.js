(function(){var P$=Clazz.newPackage("circuit"),I$=[];
var C$=Clazz.newClass(P$, "CNumber");
C$.pi = 0;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.pi = 3.141592653589793;
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.re = 0;
this.im = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.re = 0;
this.im = 0;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$D$D', function (re, im) {
C$.$init$.apply(this);
this.re = re;
this.im = im;
}, 1);

Clazz.newMeth(C$, 'getMag', function () {
return Math.sqrt(this.re * this.re + this.im * this.im);
});

Clazz.newMeth(C$, 'getPhase', function () {
return Math.atan2(this.im, this.re);
});

Clazz.newMeth(C$, 'getDegree', function () {
return 180 * Math.atan2(this.im, this.re) / C$.pi;
});
})();
//Created 2018-03-17 21:36:43
