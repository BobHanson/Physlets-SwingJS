(function(){var P$=Clazz.newPackage("circuit"),I$=[['circuit.Resources']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "Common");
C$.CIRCUIT = null;
C$.VOLTAGE = null;
C$.VOLTAGE_V = null;
C$.CURRENT = null;
C$.CURRENT_A = null;
C$.CURRENT_RMS = null;
C$.CURRENT_RMS_A = null;
C$.VOLTAGE_CURRENT = null;
C$.TIME = null;
C$.TIME_SEC = null;
C$.FREQUENCY = null;
C$.FREQUENCY_HZ = null;
C$.PHASE = null;
C$.DEG = null;
C$.DEGREE = null;
C$.EMF = null;
C$.OHM = null;
C$.BATTERY = null;
C$.BATTERY_EMF = null;
C$.SWITCH_ON = null;
C$.SWITCH_OFF = null;
C$.LOAD_RESISTOR = null;
C$.LOAD_POWER = null;
C$.LEGEND_V = null;
C$.LEGEND_VEQU = null;
C$.LEGEND_VTIME = null;
C$.LEGEND_DELTAV = null;
C$.LEGEND_I = null;
C$.LEGEND_A = null;
C$.LEGEND_R = null;
C$.LEGEND_C = null;
C$.LEGEND_VAC = null;
C$.LEGEND_VC = null;
C$.LEGEND_VR = null;
C$.LEGEND_VL = null;
C$.LEGEND_SELECT = null;
C$.LEGEND_NOVALUE = null;
C$.LEGEND_NOVOLTAGE = null;
C$.LEGEND_VOLTMETER = null;
C$.LEGEND_AMMETER = null;
C$.LEGEND_CURRENTPHASE = null;
C$.LEGEND_FREQ = null;
C$.rc = null;
C$.rc_set = false;

C$.$clinit$ = function() {Clazz.load(C$, 1);
C$.CIRCUIT = "Circuit";
C$.VOLTAGE = "Voltage";
C$.VOLTAGE_V = "Voltage (V)";
C$.CURRENT = "Current";
C$.CURRENT_A = "Current (A)";
C$.CURRENT_RMS = "RMS Current";
C$.CURRENT_RMS_A = "RMS Current (A)";
C$.VOLTAGE_CURRENT = "Voltage and Current";
C$.TIME = "Time";
C$.TIME_SEC = "Time (s)";
C$.FREQUENCY = "Frequency";
C$.FREQUENCY_HZ = "Frequency (Hz)";
C$.PHASE = "Phase";
C$.DEG = "deg";
C$.DEGREE = "degree";
C$.EMF = "emf";
C$.OHM = "Ohm";
C$.BATTERY = "Battery";
C$.BATTERY_EMF = "Battery emf=";
C$.SWITCH_ON = "Switch on.";
C$.SWITCH_OFF = "Switch off.";
C$.LOAD_RESISTOR = "Load Resistor";
C$.LOAD_POWER = "Load Power";
C$.LEGEND_V = "V";
C$.LEGEND_VEQU = "V=";
C$.LEGEND_VTIME = "V(t)";
C$.LEGEND_DELTAV = "delta V=";
C$.LEGEND_I = "I";
C$.LEGEND_A = "A";
C$.LEGEND_R = "R";
C$.LEGEND_C = "C";
C$.LEGEND_VAC = "Vac";
C$.LEGEND_VC = "Vc";
C$.LEGEND_VR = "Vr";
C$.LEGEND_VL = "Vl";
C$.LEGEND_SELECT = "Select a component.";
C$.LEGEND_NOVALUE = "Values are not available.";
C$.LEGEND_NOVOLTAGE = "Voltage is not available.";
C$.LEGEND_VOLTMETER = "Voltmeter: ";
C$.LEGEND_AMMETER = "Ammeter: ";
C$.LEGEND_CURRENTPHASE = "Current Phase=";
C$.LEGEND_FREQ = "F=";
C$.rc = null;
C$.rc_set = false;
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'initResources$java_io_InputStream', function (is) {
C$.rc = Clazz.new_((I$[1]||$incl$(1)));
try {
C$.rc.load$java_io_InputStream(is);
} catch (x) {
if (Clazz.exceptionOf(x, "java.lang.Exception")){
} else {
throw x;
}
}
}, 1);

Clazz.newMeth(C$, 'setResources', function () {
C$.CIRCUIT = C$.rc.getString$S$S("circuit", "Circuit");
C$.VOLTAGE = C$.rc.getString$S$S("voltage", "Voltage");
C$.VOLTAGE_V = C$.rc.getString$S$S("voltage.v", "Voltage (V)");
C$.CURRENT = C$.rc.getString$S$S("current", "Current");
C$.CURRENT_A = C$.rc.getString$S$S("current.a", "Current (A)");
C$.CURRENT_RMS = C$.rc.getString$S$S("current.rms", "RMS Current");
C$.CURRENT_RMS_A = C$.rc.getString$S$S("current.rms.a", "RMS Current (A)");
C$.VOLTAGE_CURRENT = C$.rc.getString$S$S("voltage.current", "Voltage and Current");
C$.TIME = C$.rc.getString$S$S("time", "Time");
C$.TIME_SEC = C$.rc.getString$S$S("time.sec", "Time (s)");
C$.FREQUENCY = C$.rc.getString$S$S("frequency", "Frequency");
C$.FREQUENCY_HZ = C$.rc.getString$S$S("frequency.hz", "Frequency (Hz)");
C$.PHASE = C$.rc.getString$S$S("phase", "Phase");
C$.DEG = C$.rc.getString$S$S("deg", "deg");
C$.DEGREE = C$.rc.getString$S$S("degree", "degree");
C$.EMF = C$.rc.getString$S$S("emf", "emf");
C$.OHM = C$.rc.getString$S$S("ohm", "Ohm");
C$.BATTERY = C$.rc.getString$S$S("battery", "Battery");
C$.BATTERY_EMF = C$.rc.getString$S$S("battery.emf", "Battery emf=");
C$.SWITCH_ON = C$.rc.getString$S$S("switch.on", "Switch on.");
C$.SWITCH_OFF = C$.rc.getString$S$S("switch.off", "Switch off.");
C$.LOAD_RESISTOR = C$.rc.getString$S$S("load.resistor", "Load Resistor");
C$.LOAD_POWER = C$.rc.getString$S$S("load.power", "Load Power");
C$.LEGEND_V = C$.rc.getString$S$S("legend.v", "V");
C$.LEGEND_VEQU = C$.rc.getString$S$S("legend.vequ", "V=");
C$.LEGEND_VTIME = C$.rc.getString$S$S("legend.vtime", "V(t)");
C$.LEGEND_DELTAV = C$.rc.getString$S$S("legend.deltav", "delta V=");
C$.LEGEND_I = C$.rc.getString$S$S("legend.i", "I");
C$.LEGEND_A = C$.rc.getString$S$S("legend.a", "A");
C$.LEGEND_R = C$.rc.getString$S$S("legend.r", "R");
C$.LEGEND_C = C$.rc.getString$S$S("legend.c", "C");
C$.LEGEND_VAC = C$.rc.getString$S$S("legend.vac", "Vac");
C$.LEGEND_VR = C$.rc.getString$S$S("legend.vr", "Vr");
C$.LEGEND_VL = C$.rc.getString$S$S("legend.vl", "Vl");
C$.LEGEND_VC = C$.rc.getString$S$S("legend.vc", "Vc");
C$.LEGEND_SELECT = C$.rc.getString$S$S("legend.select", "Select a component.");
C$.LEGEND_NOVALUE = C$.rc.getString$S$S("legend.novalue", "Values are not available.");
C$.LEGEND_NOVOLTAGE = C$.rc.getString$S$S("legend.novoltage", "Voltage is not available.");
C$.LEGEND_VOLTMETER = C$.rc.getString$S$S("legend.voltmeter", "Voltmeter: ");
C$.LEGEND_AMMETER = C$.rc.getString$S$S("legend.ammeter", "Ammeter: ");
C$.LEGEND_CURRENTPHASE = C$.rc.getString$S$S("legend.currentphase", "Current Phase=");
C$.LEGEND_FREQ = C$.rc.getString$S$S("legend.freq", "F=");
C$.rc_set = true;
}, 1);
})();
//Created 2018-02-24 16:20:43
