(function(){var P$=Clazz.newPackage("qTime"),I$=[['java.awt.Color','java.awt.BorderLayout','qTime.TabSelector','qTime.TabbedDisplayPanel','java.awt.CardLayout','java.util.Vector','java.awt.Font','java.awt.Dimension','java.awt.Insets']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "TabbedDisplayPanel", null, 'a2s.Panel');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.hi = null;
this.lo = null;
this.card = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$java_awt_Color$java_awt_Color', function (h, l) {
Clazz.super_(C$, this,1);
this.hi=h;
this.lo=l;
this.setLayout$java_awt_LayoutManager(this.card=Clazz.new_((I$[5]||$incl$(5))));
}, 1);

Clazz.newMeth(C$, 'addItem$S$java_awt_Component', function (n, c) {
this.add$S$java_awt_Component(n, c);
});

Clazz.newMeth(C$, 'choose$S', function (n) {
(this.getLayout()).show$java_awt_Container$S(this, n);
});

Clazz.newMeth(C$, 'insets', function () {
return Clazz.new_((I$[9]||$incl$(9)).c$$I$I$I$I,[5, 5, 5, 5]);
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
g.setColor$java_awt_Color(this.hi);
g.drawLine$I$I$I$I(0, 0, 0, this.getSize().height - 1);
g.drawLine$I$I$I$I(1, 0, 1, this.getSize().height - 1);
g.setColor$java_awt_Color(this.lo);
g.drawLine$I$I$I$I(0, this.getSize().height - 1, this.getSize().width - 1, this.getSize().height - 1);
g.drawLine$I$I$I$I(0, this.getSize().height - 2, this.getSize().width - 1, this.getSize().height - 2);
g.drawLine$I$I$I$I(this.getSize().width - 1, this.getSize().height - 1, this.getSize().width - 1, 0);
g.drawLine$I$I$I$I(this.getSize().width - 2, this.getSize().height - 1, this.getSize().width - 2, 0);
});

Clazz.newMeth(C$);
})();
//Created 2018-07-20 18:09:38
