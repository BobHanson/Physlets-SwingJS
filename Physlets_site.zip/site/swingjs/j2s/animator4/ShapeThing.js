(function(){var P$=Clazz.newPackage("animator4"),I$=[['edu.davidson.tools.SUtil']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "ShapeThing", null, 'animator4.Thing');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.horz = null;
this.vert = null;
this.horz2 = null;
this.vert2 = null;
this.num = 0;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$animator4_AnimatorCanvas$I$IA$IA$S$S', function (o, n, h, v, xStr, yStr) {
C$.superclazz.c$$animator4_AnimatorCanvas$S$S.apply(this, [o, xStr, yStr]);
C$.$init$.apply(this);
this.s = 1;
this.horz = Clazz.array(Integer.TYPE, [n]);
this.vert = Clazz.array(Integer.TYPE, [n]);
this.horz2 = Clazz.array(Integer.TYPE, [n]);
this.vert2 = Clazz.array(Integer.TYPE, [n]);
this.num = n;
for (var i = 0; i < n; i++) {
this.horz[i] = h[i];
this.vert[i] = -v[i];
}
}, 1);

Clazz.newMeth(C$, 'getHorz$I', function (off) {
for (var i = 0; i < this.num; i++) {
this.horz2[i] = this.horz[i] + off;
}
return this.horz2;
});

Clazz.newMeth(C$, 'getVert$I', function (off) {
for (var i = 0; i < this.num; i++) {
this.vert2[i] = this.vert[i] + off;
}
return this.vert2;
});

Clazz.newMeth(C$, 'paint$java_awt_Graphics', function (g) {
if (!this.visible) return;
this.paintGhosts$java_awt_Graphics(g);
var ptX = Math.round(this.canvas.pixFromX$D(this.vars[1])) + this.xDisplayOff;
var ptY = Math.round(this.canvas.pixFromY$D(this.vars[2])) - this.yDisplayOff;
g.setColor$java_awt_Color(this.color);
g.fillPolygon$IA$IA$I(this.getHorz$I(ptX), this.getVert$I(ptY), this.num);
this.paintTrail$java_awt_Graphics(g);
if (this.showCoordinates) this.paintCoordinates$java_awt_Graphics$I$I(g, ptX, ptY);
C$.superclazz.prototype.paint$java_awt_Graphics.apply(this, [g]);
});

Clazz.newMeth(C$, 'paintGhosts$java_awt_Graphics', function (g) {
if (!this.visible) return;
if (this.ghost && this.footPrints > 0  && this.trailSize > 1  && this.trail.npoints > 1 ) {
g.setColor$java_awt_Color((I$[1]||$incl$(1)).veryPaleColor$java_awt_Color(this.color));
for (var i = 0; i < this.trail.npoints; i = i+(this.footPrints)) {
g.fillPolygon$IA$IA$I(this.getHorz$I(this.trail.xpoints[i] + this.xDisplayOff), this.getVert$I(this.trail.ypoints[i] - this.yDisplayOff), this.num);
}
}});

Clazz.newMeth(C$);
})();
//Created 2018-02-25 19:20:14
