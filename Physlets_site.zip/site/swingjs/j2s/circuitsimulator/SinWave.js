(function(){var P$=Clazz.newPackage("circuitsimulator"),I$=[[0,'edu.davidson.tools.SUtil']],$I$=function(i){return I$[i]||(I$[i]=Clazz.load(I$[0][i]))};
var C$=Clazz.newClass(P$, "SinWave", null, 'circuitsimulator.Source');

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'c$$circuitsimulator_Circuit$I$I$I$S$D$D$D', function (circ, pol, r, c, t, amp, ph, freq) {
C$.superclazz.c$$circuitsimulator_Circuit$I$I$I$S.apply(this, [circ, pol, r, c, t]);
C$.$init$.apply(this);
this.amplitude=amp;
this.phase=ph;
this.frequency=freq;
this.$function=Double.toString$D(this.amplitude) + "*sin(2*pi*" + Double.toString$D(this.frequency) + "*(t+" + Double.toString$D(this.phase) + "))" ;
}, 1);

Clazz.newMeth(C$, 'c$', function () {
C$.superclazz.c$.apply(this, []);
C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getStringAdditions$', function () {
return ",amp=" + new Double(this.amplitude).toString() + ",phase=" + new Double(this.phase).toString() + ",freq=" + new Double(this.frequency).toString() ;
});

Clazz.newMeth(C$, 'set$S', function (list) {
var t=this.gett$();
var Vnow=this.getV$D(t);
var Vprev=this.getV$D(t - this.circuit.dt);
var ret=C$.superclazz.prototype.set$S.apply(this, [list]);
var newFreq=0;
if (Clazz.load('edu.davidson.tools.SUtil').parameterExist$S$S(list, "amp=")) this.amplitude=$I$(1).getParam$S$S(list, "amp=");
if ($I$(1).parameterExist$S$S(list, "phase=")) if ($I$(1).getParamStr$S$S(list, "phase=").equals$O("continuous")) this.phase=this.getPhase$D$D$D(t, Vnow, Vprev);
 else this.phase=$I$(1).getParam$S$S(list, "phase=");
this.$function=Double.toString$D(this.amplitude) + "*sin(2*pi*" + Double.toString$D(this.frequency) + "*(t+" + Double.toString$D(this.phase) + "))" ;
return ret;
});

Clazz.newMeth(C$, 'getV$D', function (t) {
return this.amplitude * Math.sin(2 * 3.141592653589793 * this.frequency * (t + this.phase) );
});

Clazz.newMeth(C$, 'parsefunction$', function () {
});

Clazz.newMeth(C$, 'getPhase$D$D$D', function (t, Vnow, Vprev) {
if (Vnow > Vprev ) return (Math.asin(Vnow / this.amplitude) / (6.283185307179586) - (this.frequency * t) % 1.0) / this.frequency;
 else return (0.5 - (Math.asin(Vnow / this.amplitude)) / (6.283185307179586) - (this.frequency * t) % 1.0) / this.frequency;
});
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:16 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
