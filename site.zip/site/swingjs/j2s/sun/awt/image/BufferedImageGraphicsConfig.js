(function(){var P$=Clazz.newPackage("sun.awt.image"),I$=[];
var C$=Clazz.newClass(P$, "BufferedImageGraphicsConfig");

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$);
})();
//Created 2018-05-24 08:47:26
