(function(){var P$=Clazz.newPackage("dynamics");
var C$=Clazz.newClass(P$, "SFront");

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.x0=0;
this.y0=0;
this.x=0;
this.y=0;
this.vx=0;
this.vy=0;
this.on=false;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, 'setup$D$D$D$D', function (n, n2, vx, vy) {
this.x=n;
this.x0=n;
this.y=n2;
this.y0=n2;
this.vx=vx;
this.vy=vy;
this.on=true;
});

Clazz.newMeth(C$, 'moving$D', function (n) {
this.x += this.vx * n;
this.y += this.vy * n;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.4.01');//Created 2018-10-29 12:20:12 Java2ScriptVisitor version 3.2.4.01 net.sf.j2s.core.jar version 3.2.4.01
