(function(){var P$=Clazz.newPackage("dataTable"),I$=[['java.awt.BorderLayout','Boolean','edu.davidson.views.SGridPanel','edu.davidson.tools.SApplet']],$incl$=function(i){return I$[i]=Clazz.load(I$[0][i-1])};
var C$=Clazz.newClass(P$, "DataTable", null, 'edu.davidson.tools.SApplet');
var p$=C$.prototype;

C$.$clinit$ = function() {Clazz.load(C$, 1);
}

Clazz.newMeth(C$, '$init0$', function () {
var c;if((c = C$.superclazz) && (c = c.$init0$))c.apply(this);
this.dataFile = null;
this.numRows = 0;
this.numCols = 0;
this.cellWidth = 0;
this.showControls = false;
this.showRowHeader = false;
this.showColHeader = false;
this.showScrollBars = false;
this.lastOnTop = false;
this.$sizeToFit = false;
this.grid = null;
this.borderLayout1 = null;
}, 1);

Clazz.newMeth(C$, '$init$', function () {
this.dataFile = "";
this.showScrollBars = true;
this.borderLayout1 = Clazz.new_((I$[1]||$incl$(1)));
}, 1);

Clazz.newMeth(C$, 'c$', function () {
Clazz.super_(C$, this,1);
}, 1);

Clazz.newMeth(C$, 'init', function () {
this.initResources$S(null);
try {
this.numRows = Integer.parseInt(this.getParameter$S$S("NumRows", "10"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.cellWidth = Integer.parseInt(this.getParameter$S$S("CellWidth", "40"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.numCols = Integer.parseInt(this.getParameter$S$S("NumCols", "2"));
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showControls = (I$[2]||$incl$(2)).$valueOf(this.getParameter$S$S("ShowControls", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showRowHeader = (I$[2]||$incl$(2)).$valueOf(this.getParameter$S$S("ShowRowHeader", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showColHeader = (I$[2]||$incl$(2)).$valueOf(this.getParameter$S$S("ShowColHeader", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.lastOnTop = (I$[2]||$incl$(2)).$valueOf(this.getParameter$S$S("LastOnTop", "false")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.showScrollBars = (I$[2]||$incl$(2)).$valueOf(this.getParameter$S$S("ShowScrollBars", "true")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.$sizeToFit = (I$[2]||$incl$(2)).$valueOf(this.getParameter$S$S("SizeToFit", "false")).booleanValue();
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
try {
this.dataFile = this.getParameter$S$S("DataFile", "");
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.grid = Clazz.new_((I$[3]||$incl$(3)).c$$edu_davidson_tools_SApplet$Z,[this, this.showScrollBars]);
try {
p$.jbInit.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e, "java.lang.Exception")){
e.printStackTrace();
} else {
throw e;
}
}
this.grid.setDefaultCellWidth$I(this.cellWidth);
this.grid.setLastOnTop$Z(this.lastOnTop);
this.grid.setShowRowHeader$Z(this.showRowHeader);
this.grid.setShowColHeader$Z(this.showColHeader);
this.grid.initCells$I$I(this.numRows, this.numCols);
this.grid.setShowControls$Z(this.showControls);
});

Clazz.newMeth(C$, 'jbInit', function () {
this.setLayout$java_awt_LayoutManager(this.borderLayout1);
this.add$java_awt_Component$O(this.grid, "Center");
});

Clazz.newMeth(C$, 'getAppletCount', function () {
if (this.firstTime) return 0;
 else return C$.superclazz.prototype.getAppletCount.apply(this, []);
});

Clazz.newMeth(C$, 'start', function () {
this.validate();
if (this.$sizeToFit) this.sizeToFit$Z(true);
if (this.firstTime) {
this.firstTime = false;
if (this.dataFile != null  && !this.dataFile.equals$O("") ) this.grid.loadFile$I$S(1, this.dataFile);
}C$.superclazz.prototype.start.apply(this, []);
});

Clazz.newMeth(C$, 'getAppletInfo', function () {
return "Data Table Applet by W. Christian";
});

Clazz.newMeth(C$, 'getParameterInfo', function () {
var pinfo = Clazz.array(java.lang.String, -2, [Clazz.array(java.lang.String, -1, ["NumRows", "int", "Number of rows"]), Clazz.array(java.lang.String, -1, ["NumCols", "int", "Number of cols."]), Clazz.array(java.lang.String, -1, ["ShowControls", "boolean", "Show controls at start up."]), Clazz.array(java.lang.String, -1, ["ShowRowHeader", "boolean", "Show the fixed row header"]), Clazz.array(java.lang.String, -1, ["ShowColHeader", "boolean", "Show the fixed col header"]), Clazz.array(java.lang.String, -1, ["SizeToFit", "boolean", "Fit the table to size of the panel."])]);
return pinfo;
});

Clazz.newMeth(C$, 'loadDataFile$I$S', function (sid, fileName) {
this.grid.loadFile$I$S(sid, fileName);
});

Clazz.newMeth(C$, 'clearSeries$I', function (s) {
this.grid.clearSeries$I(s);
});

Clazz.newMeth(C$, 'clearAllSeries', function () {
this.grid.clearAllSeries();
});

Clazz.newMeth(C$, 'addDatum$I$D', function (sid, x) {
this.grid.addDatum$I$D$D(sid, x, 0);
});

Clazz.newMeth(C$, 'getTableID', function () {
return this.grid.hashCode();
});

Clazz.newMeth(C$, 'setAutoRefresh$Z', function (autoRefresh) {
this.grid.setAutoRefresh$Z(autoRefresh);
});

Clazz.newMeth(C$, 'sizeToFit$Z', function (stf) {
this.grid.sizeToFit$Z(stf);
});

Clazz.newMeth(C$, 'setDefault', function () {
this.grid.setDefault();
});

Clazz.newMeth(C$, 'setDataStride$I$I', function (sid, stride) {
this.grid.setDataStride$I$I(sid, stride);
});

Clazz.newMeth(C$, 'getSeriesID$I', function (sid) {
return this.grid.getSeriesID$I(sid);
});

Clazz.newMeth(C$, 'getSeriesWidth$I', function (sid) {
return this.grid.getSeriesWidth$I(sid);
});

Clazz.newMeth(C$, 'setSeriesWidth$I$I', function (id, width) {
this.grid.setSeriesWidth$I$I(id, width);
});

Clazz.newMeth(C$, 'setSeriesLabel$I$S', function (sid, str) {
return this.grid.setSeriesLabel$I$S(sid, str);
});

Clazz.newMeth(C$, 'setNumericFormat$I$S', function (sid, str) {
this.grid.setNumericFormat$I$S(sid, str);
});

Clazz.newMeth(C$, 'setFormat$I$S', function (id, str) {
var ds = (I$[4]||$incl$(4)).getDataSource$I(id);
if (ds == null  && id == 0 ) {
return this.grid.setFormat$S(str);
}return this.grid.setFormat$edu_davidson_tools_SDataSource$S(ds, str);
});

Clazz.newMeth(C$, 'setShowActiveCell$Z', function (show) {
this.grid.setShowActiveCell$Z(show);
});

Clazz.newMeth(C$, 'getActiveCellValue', function () {
return this.grid.getActiveCellValue();
});

Clazz.newMeth(C$, 'getActiveCellRow', function () {
return this.grid.getActiveCellRow();
});

Clazz.newMeth(C$, 'getActiveCellCol', function () {
return this.grid.getActiveCellCol();
});

Clazz.newMeth(C$, 'setActiveCellValue$D', function (val) {
return this.grid.setActiveCellValue$D(val);
});

Clazz.newMeth(C$, 'setActiveCell$I$I', function (row, col) {
return this.grid.setActiveCell$I$I(row, col);
});
})();
//Created 2018-02-06 13:41:48
