(function(){var P$=Clazz.newPackage("edu.davidson.tools"),I$=[];
var C$=Clazz.newInterface(P$, "SStepable");
})();
//Created 2018-03-17 21:37:13
